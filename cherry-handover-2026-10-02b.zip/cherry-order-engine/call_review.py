#!/usr/bin/env python3
"""Review one finished call: did the model do what the prompt asked of it?

The tests prove the ENGINE behaves. They cannot prove a live voice model uses
the engine the way `voice/inworld_bridge.py`'s prompt says. This reads what one
real call left in the database and answers the questions that matter before a
restaurant's forwarded number goes live:

  * did the model ask for the name and the allergy and hand the answers to the
    right tools (`set_name`, `note_allergy`) — or push them through `add_item`?
  * did it call a tool more than once for one request (Gemini 3.8 Live's
    documented habit)? How often did the engine have to absorb a repeat?
  * did any tool call come back "bad arguments", "no match", "low confidence"?
  * how long did the engine take on each tool (the model's own thinking time is
    not in here)?
  * with the voice provider's output transcription saved one reply per line, did
    it SAY the engine's words — or paraphrase them, or change a price?
  * what did the call cost, on today's stack and on Gemini 3.8 Live?

    python3 call_review.py --db cherry.db --latest
    python3 call_review.py --db "$CHERRY_DATABASE_URL" --call <telephony call id>
    python3 call_review.py --db cherry.db --latest --spoken spoken.txt --expect set_name,note_allergy,store_info

Exit code 0 when nothing failed (warnings do not fail), 3 when something did.
It reads the database only. It sends nothing and changes nothing.
"""

from __future__ import annotations

import _ensure_deps  # noqa: F401  (re-runs under .venv, or says how to install, if PyYAML is missing)
import argparse
import difflib
import json
import re
import statistics
import sys
from typing import Any, Dict, Iterable, List, Optional

import call_cost
from order_store import json_value

# Reasons a tool came back unhappy, and how much each says about the MODEL.
_ARG_ERRORS = {"argument_error", "bad_arguments", "misrouted"}
_GATE_TOOLS = {"answer", "set_name", "note_allergy"}
# The engine's own questions (the waiter's name/allergy gate): normal, not a problem.
_EXPECTED_ISSUES = {"allergy_check", "name_check"}
_SLOW_ENGINE_MS = 1500


def _norm(text: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9$ ]+", " ", (text or "").lower())).strip()


def _numbers(text: str) -> List[str]:
    return re.findall(r"\d+(?:\.\d+)?", text or "")


def find_session(store, call_id: Optional[str] = None, *, latest: bool = False):
    """The session for a telephony call id, or the newest voice session."""
    if call_id:
        row = store.conn.execute("SELECT * FROM session WHERE external_id=?", (call_id,)).fetchone()
        if row is None:
            row = store.conn.execute("SELECT * FROM session WHERE id=?", (call_id,)).fetchone()
        return row
    if latest:
        return store.conn.execute(
            "SELECT * FROM session WHERE channel='voice' ORDER BY started_at DESC LIMIT 1").fetchone()
    return None


def tool_trace(store, session_id: str) -> List[Dict[str, Any]]:
    """Every tool the model called, in order, with what the caller said to
    cause it, what the engine answered, how long it took and why it failed.

    The server records one caller turn (when the call carried `text`) and one
    agent turn per tool, both tagged with the tool's name. A repeat the server
    absorbed within 2.5 s is not a turn; those are `call.duplicate_tool` events."""
    rows = store.conn.execute(
        "SELECT seq, speaker, text, intent, engine_issue_code, latency_ms, created_at "
        "FROM turn WHERE session_id=? ORDER BY seq", (session_id,)).fetchall()
    trace: List[Dict[str, Any]] = []
    heard = ""
    for r in rows:
        if r["speaker"] == "caller":
            heard = r["text"] or ""
        elif r["speaker"] == "agent":
            trace.append({"seq": int(r["seq"]), "tool": r["intent"] or "?", "heard": heard,
                          "said": r["text"] or "", "ms": r["latency_ms"],
                          "issue": r["engine_issue_code"], "at": r["created_at"]})
            heard = ""
    return trace


def verbatim_report(trace: List[Dict[str, Any]], spoken: List[str]) -> Dict[str, Any]:
    """Compare what the voice actually said (provider output transcription, one
    reply per line, in order) with what the engine told it to say."""
    expected = [t["said"] for t in trace]
    findings: List[Dict[str, Any]] = []
    for i, (want, got) in enumerate(zip(expected, spoken)):
        a, b = _norm(want), _norm(got)
        if a == b:
            continue
        ratio = difflib.SequenceMatcher(None, a, b).ratio()
        nums_a, nums_b = _numbers(want), _numbers(got)
        changed_number = bool(nums_a and nums_b and nums_a != nums_b)
        findings.append({"turn": i + 1, "tool": trace[i]["tool"], "engine": want, "spoken": got,
                         "similarity": round(ratio, 2),
                         "severity": "fail" if (ratio < 0.6 or changed_number) else "warn"})
    return {"compared": min(len(expected), len(spoken)), "engine_lines": len(expected),
            "spoken_lines": len(spoken), "drift": findings}


def review(store, call_id: Optional[str] = None, *, latest: bool = False,
           spoken: Optional[List[str]] = None, expect: Iterable[str] = ()) -> Dict[str, Any]:
    ses = find_session(store, call_id, latest=latest)
    if ses is None:
        raise LookupError("no such call" if call_id else "no voice calls in this database")
    sid = str(ses["id"])
    trace = tool_trace(store, sid)
    events = [dict(e) for e in store.events(session_id=sid)]
    findings: List[Dict[str, str]] = []

    def add(level: str, text: str) -> None:
        findings.append({"level": level, "text": text})

    used: Dict[str, int] = {}
    for t in trace:
        used[t["tool"]] = used.get(t["tool"], 0) + 1

    # 1. the greeting
    if trace and trace[0]["tool"] == "greeting":
        add("ok", "the call opened with the engine's greeting")
    else:
        add("warn", "the first thing said was not the engine's greeting")

    # 2. tools the prompt asks for
    for tool in expect:
        if used.get(tool):
            add("ok", f"the model called {tool} ({used[tool]}×)")
        else:
            add("warn", f"the model never called {tool}")

    # 3. the waiter's question: the caller's answer must reach name/allergy tools
    for i, t in enumerate(trace):
        if t["tool"] == "ready_to_place" and re.search(r"allerg|dietary", t["said"], re.I):
            nxt = trace[i + 1] if i + 1 < len(trace) else None
            if nxt is None:
                add("warn", "the engine asked for a name and allergies and the call ended there")
            elif nxt["tool"] in _GATE_TOOLS:
                add("ok", f"the answer to the name/allergy question went to {nxt['tool']}")
            else:
                add("fail", f"the name/allergy answer went to {nxt['tool']!r} (heard: "
                            f"{nxt['heard'][:60]!r}) instead of answer/set_name/note_allergy")
            break

    # 4. repeats
    absorbed = [e for e in events if e["kind"] == "call.duplicate_tool"]
    if absorbed:
        add("warn", f"the engine absorbed {len(absorbed)} repeated tool call(s) inside 2.5 s "
                    f"(tools: {', '.join(sorted({json_value(e['detail']).get('tool', '?') for e in absorbed}))}) "
                    "— the model retries; the prompt says call each tool once")
    else:
        add("ok", "no repeated tool calls were absorbed")
    for a, b in zip(trace, trace[1:]):
        if a["tool"] == b["tool"] and a["heard"] and a["heard"] == b["heard"] and a["tool"] not in ("answer",):
            add("warn", f"{a['tool']} was called twice for {a['heard'][:50]!r} (turns {a['seq']} and {b['seq']})")

    # 5. tools that came back unhappy
    issues: Dict[str, int] = {}
    for t in trace:
        if t["issue"]:
            issues[t["issue"]] = issues.get(t["issue"], 0) + 1
    bad_args = sum(n for k, n in issues.items() if k in _ARG_ERRORS)
    if bad_args:
        add("warn", f"{bad_args} tool call(s) had bad arguments — the model is not following the tool schemas")
    other = {k: n for k, n in issues.items() if k not in _ARG_ERRORS and k not in _EXPECTED_ISSUES}
    if other:
        add("info", "engine replies that were not a plain success: "
                    + ", ".join(f"{k}×{n}" for k, n in sorted(other.items())))

    # 6. engine-side latency
    ms = [t["ms"] for t in trace if t["ms"] is not None]
    latency: Dict[str, Any] = {}
    if ms:
        ordered = sorted(ms)
        latency = {"calls": len(ms), "median_ms": int(statistics.median(ms)),
                   "p95_ms": ordered[min(len(ordered) - 1, int(len(ordered) * 0.95))], "max_ms": max(ms)}
        level = "warn" if latency["max_ms"] > _SLOW_ENGINE_MS else "ok"
        add(level, f"engine time per tool: median {latency['median_ms']} ms, max {latency['max_ms']} ms "
                   "(the model's own thinking time is not included here)")

    # 7. what the voice actually said
    verbatim = None
    if spoken is not None:
        verbatim = verbatim_report(trace, spoken)
        if verbatim["spoken_lines"] != verbatim["engine_lines"]:
            add("warn", f"the engine produced {verbatim['engine_lines']} lines but the voice spoke "
                        f"{verbatim['spoken_lines']}: lines were added or dropped")
        for d in verbatim["drift"]:
            add(d["severity"], f"line {d['turn']} ({d['tool']}): engine said {d['engine']!r}, "
                               f"voice said {d['spoken']!r} (similarity {d['similarity']})")
        if not verbatim["drift"]:
            add("ok", f"all {verbatim['compared']} spoken lines match the engine's words")

    # 8. the outcome
    order = store.conn.execute('SELECT * FROM "order" WHERE session_id=?', (sid,)).fetchone()
    outcome: Dict[str, Any] = {"ended": ses["ended_at"] is not None, "end_reason": ses["end_reason"]}
    if order is not None:
        snap = json_value(order["snapshot"]) or {}
        outcome.update(order_placed=True, short_code=order["short_code"], total_cents=int(order["total_cents"]),
                       name=order["customer_name"], allergy=(snap.get("allergy") or {}).get("note", ""),
                       items=[(ln.get("item_name"), ln.get("quantity")) for ln in (snap.get("lines") or [])])
        add("info", f"order {order['short_code']} placed for {order['customer_name']!r}, "
                    f"{len(outcome['items'])} line(s)"
                    + (f", allergy on ticket: {outcome['allergy']!r}" if outcome["allergy"] else ", no allergy on the ticket"))
    else:
        outcome["order_placed"] = False
        add("info", f"no order was placed (ended: {ses['end_reason'] or 'still open'})")

    # 9. cost
    cost = None
    a, b = call_cost._parse(ses["started_at"]), call_cost._parse(ses["ended_at"])
    if a and b:
        seconds = max(1.0, (b - a).total_seconds())
        chars = float(sum(len(t["said"]) for t in trace))
        prof = call_cost.Profile(call_seconds=seconds, chars_spoken=chars, lily_speaks_seconds=chars / 15.0,
                                 tool_turns=max(1, len(trace)))
        cost = {"seconds": round(seconds), "chars_spoken": int(chars),
                "today": call_cost.total(call_cost.call_cost("inworld_cascade", prof)),
                "gemini_3_8_low": call_cost.total(call_cost.call_cost("gemini_live_3_8", prof)),
                "gemini_3_8_high": call_cost.total(call_cost.call_cost("gemini_live_3_8", prof, high=True))}

    worst = "fail" if any(f["level"] == "fail" for f in findings) else \
        "warn" if any(f["level"] == "warn" for f in findings) else "ok"
    return {"session": sid, "call_id": ses["external_id"], "restaurant": ses["restaurant_id"],
            "started_at": ses["started_at"], "tools_used": used, "trace": trace, "latency": latency,
            "verbatim": verbatim, "outcome": outcome, "cost": cost, "findings": findings, "verdict": worst}


def render(r: Dict[str, Any], *, show_trace: bool = True) -> str:
    out = [f"Call {r['call_id'] or r['session'][:8]} at {r['restaurant']}  ({r['started_at']})", ""]
    if show_trace:
        out.append("What the model did:")
        for t in r["trace"]:
            heard = f'  <- "{t["heard"][:60]}"' if t["heard"] else ""
            issue = f"  [{t['issue']}]" if t["issue"] else ""
            ms = f"{t['ms']:>4} ms" if t["ms"] is not None else "      "
            out.append(f"  {t['seq']:>3}  {t['tool']:<16}{ms}{heard}{issue}")
            out.append(f"       {t['said'][:110]}")
        out.append("")
    mark = {"ok": "  ok  ", "warn": " WARN ", "fail": " FAIL ", "info": " info "}
    out.append("Checks:")
    for f in r["findings"]:
        out.append(f"  [{mark[f['level']].strip():>4}] {f['text']}")
    if r["cost"]:
        c = r["cost"]
        out += ["", f"This call: {c['seconds']} s, {c['chars_spoken']} characters spoken.",
                f"  today's stack ${c['today']:.4f}   Gemini 3.8 Live ${c['gemini_3_8_low']:.4f} .. ${c['gemini_3_8_high']:.4f}"
                "   (estimates from the rate card; the invoice is the truth)"]
    out += ["", {"ok": "Verdict: nothing failed and nothing looked off.",
                 "warn": "Verdict: nothing failed, but read the warnings before going live.",
                 "fail": "Verdict: FAILED — the model is not using the engine the way the prompt says."}[r["verdict"]]]
    return "\n".join(out)


def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--db", required=True, help="SQLite path or a postgres:// DSN")
    which = ap.add_mutually_exclusive_group(required=True)
    which.add_argument("--call", help="the telephony call id (or the session id)")
    which.add_argument("--latest", action="store_true", help="the newest voice call")
    ap.add_argument("--spoken", help="file of what the voice said, one reply per line (output transcription)")
    ap.add_argument("--expect", default="set_name,note_allergy",
                    help="tools the model should have called on this call (comma separated)")
    ap.add_argument("--json", action="store_true", help="machine-readable output")
    ap.add_argument("--no-trace", action="store_true")
    args = ap.parse_args(argv)

    from order_store import OrderStore
    store = OrderStore.open(args.db)
    spoken = None
    if args.spoken:
        with open(args.spoken, encoding="utf-8") as fh:
            spoken = [ln.strip() for ln in fh if ln.strip()]
    try:
        r = review(store, args.call, latest=args.latest, spoken=spoken,
                   expect=[x.strip() for x in args.expect.split(",") if x.strip()])
    except LookupError as exc:
        print(f"call_review: {exc}", file=sys.stderr)
        return 2
    print(json.dumps(r, indent=2, default=str) if args.json else render(r, show_trace=not args.no_trace))
    return 3 if r["verdict"] == "fail" else 0


if __name__ == "__main__":
    sys.exit(main())
