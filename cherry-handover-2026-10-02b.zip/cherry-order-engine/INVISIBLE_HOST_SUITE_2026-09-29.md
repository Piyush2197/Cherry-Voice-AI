# The Invisible Host suite — making the owner's work easier (2026-09-29)

Extended version of the "Digital Waitstaff" concept, adapted to Cherry's rules:
Cherry never touches money, never invents menu knowledge, and nothing is
promised to an owner before it is built. Each item is tagged:

**[BUILT]** — in the repo, tested. Sellable today.
**[SCOPED]** — decided and specified; scheduled behind the Square bridge.
**[LATER]** — needs a provider, a policy decision, or density. Never a pitch line.

The pitch in one sentence: **Cherry is the second employee — it answers the
phone, works the counter, hands the kitchen a clean ticket, collects payment
on the restaurant's own POS link, and tells the owner what happened tonight.
For less than one shift a week of wages.**

## 1. The phone — stop losing orders to a ringing phone [BUILT]

- Every call answered on the first ring, orders taken on the live menu, no
  hold music, no "can you hold on one second."
- Checkout failure or complex orders transfer to a direct staff line; if the
  transfer fails, the caller is told the number — nobody is left on a dead line.
- Missed-call replacement is measured: sessions, orders, abandoned calls are
  in the ops feed, so the owner sees recovered revenue, not vibes.

## 2. The counter and the table — the second employee on the floor [SCOPED]

- Counter/table QR opens a conversational agent (`channel='web'`): menu
  questions (allergens, spice, substitutions) answered only from menu data,
  on-screen read-back, pay link on the guest's own screen.
- Multilingual by design — the guest orders in their language; the POS page
  cannot do this.
- Frees the lone front-of-house person to run food, seat guests, and handle
  exceptions. Rules in `QR_CHANNEL.md` (revision 2026-09-29).

## 3. The kitchen — a clean ticket, no re-keying [BUILT for bridge; fallback exists]

- Bridged locations: order lands in the POS the way the POS intends, with
  acknowledgement tracking and an alert when the kitchen never confirms.
- Un-bridged locations: Manual SMS fallback, and the agent refuses no-checkout
  traffic straight to staff so no caller repeats an order for nothing.
- Reconciliation runs nightly: paid orders, missing tickets, stuck links.

## 4. The money — payment happens where it always did [BUILT]

- Pay link on the restaurant's own POS; the guest checks the itemized order
  and total before paying. No wallet, no commission, no chargeback exposure
  for the owner from Cherry's side.
- Expired links are revoked automatically; paid orders are reconciled against
  the POS with amount-bearing proof, never an ID guess.

## 5. The owner's morning — know what happened without asking [BUILT]

- Nightly brief: calls, orders, revenue, escalations, what callers asked for
  that the menu does not cover (`store.unresolved`), dishes guests confuse
  (`store.confusions`) — the menu-improvement list writes itself.
- Alerts to the owner's phone, once per condition: failed delivery, stuck
  payment, failed transfer, Square token expiring, usage trending over plan.
- Transcript review queue flags the calls worth listening to (engine issues,
  escalations, slow turns) so quality is checked in minutes, not hours.

## 6. The guest's phone — fewer "where is my order" interruptions [BUILT/partial]

- Checkout link, confirmation and (bridged) ready-status reach the guest's
  phone directly; staff stop playing messenger.
- STOP/opt-out is honored automatically; no carrier violations.

## 7. The concierge extras — the "friction tasks," Cherry-style [LATER]

From the Manus Cue concept, adapted. Each needs a real provider and a failure
path; a concierge action that silently fails is worse than no feature.

- **Split the bill:** N pay links from one order snapshot — Square-hosted,
  so payments stay on the POS. Build after bridges, only if owners ask.
- **"Text me when my table/order is ready":** already half-built via POS
  acknowledgement; a waitlist needs a policy decision per owner.
- **Taxi/ride note when the bill closes:** only via a real ride API with a
  fallback; otherwise it is a text that might nobody reads. Not before density.
- **Reservations, catering, delivery:** unchanged — each needs its owner
  decision and provider, as in `TASKS.md` later scope.

## What we refuse (from the Manus Cue pitch)

- **Standalone digital wallets.** Cherry never touches money. The wallet's
  stated benefit — processor setup delays — is already answered by the Manual
  SMS fallback and the bridges, and "your money stays on your POS" is a
  selling point, not a limitation.
- **Bundling unbuilt concierge promises.** Every extra above is a scoped
  project with a provider and a failure path, sold when built — the same
  discipline as the voice product's "do not say yet" list.

## Sequencing

Bridge → first pilots → counter QR agent → the concierge extras only where
owners ask and a provider exists. The suite is mostly *already built* — the
sales work is telling owners what exists, not building more.
