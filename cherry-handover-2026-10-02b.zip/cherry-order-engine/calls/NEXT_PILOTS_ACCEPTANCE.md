# Spoken acceptance calls — next pilot restaurants

Run these after each Telnyx number is routed but before public traffic. Use a
normal mobile phone, let the agent finish each question, and speak the lines
below naturally rather than reading like a robot. The caller must hear the
exact total shown. The kitchen/POS must receive the same items and modifiers.

## Pink Garlic — each location

Caller sequence:

1. “Can I get a lamb saag?”
2. “Medium plus.”
3. “Boneless lamb.”
4. “Add extra vegetables.”
5. “And two garlic naan.”
6. “Read that back.”

Pass conditions: the agent never guesses lamb versus goat; the ticket says
Lamb/Goat Saag, Medium Plus, Lamb (Boneless), Extra Vegetable, and two Garlic
Naan. Shelby's expected total is **$25.43**. Oak Park and Allen Park totals
must come from their own completed Square catalogs, not Shelby's price.

## Miyazaki — Hall Road

Caller sequence:

1. “I want the Calcifer tray.”
2. “California, spicy tuna, shrimp tempura, eel avocado, and Philadelphia.”
3. “Dragon and rainbow for the special rolls.”
4. “Read it back.”

Pass conditions: Cherry keeps asking until it has exactly five basic and two
special rolls, accepts no sixth basic roll, and reads back **$74.20**.

## Tamago Sushi & Bowl — Hall Road

Caller sequence:

1. “A bibimbap bowl.”
2. “Add chicken.”
3. “And a spicy tuna roll.”
4. “Read that back.”

Pass conditions: included noodles and greens do not create questions or extra
charges; chicken adds $2.00; the final total is **$23.32**.

## Human fallback drill — every storefront

After the successful order call, make one controlled call while Cherry's
backend is intentionally unavailable. The caller must hear the safe failure
sentence and then reach that exact restaurant's published phone number. Check
the operations event log for one `voice.handoff_succeeded` event—never two.
