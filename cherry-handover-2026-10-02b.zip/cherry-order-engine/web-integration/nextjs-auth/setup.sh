#!/bin/bash
# Quick setup script for Cherry Voice AI Next.js integration

echo "🍒 Cherry Voice AI - Next.js Integration Setup"
echo "=========================================="
echo ""

# Check if we're in a Next.js project
if [ ! -f "package.json" ]; then
    echo "❌ Error: Not in a Next.js project directory"
    echo "   Please run this script from your Next.js project root"
    exit 1
fi

# Install jose for JWT
echo "📦 Installing jose package..."
npm install jose

# Create lib directory if it doesn't exist
mkdir -p lib

# Check if files exist in current directory
if [ -f "middleware.ts" ]; then
    echo "⚠️  middleware.ts already exists - skipping"
else
    echo "✅ Ready to copy middleware.ts"
fi

if [ -f "lib/auth.ts" ]; then
    echo "⚠️  lib/auth.ts already exists - skipping"
else
    echo "✅ Ready to copy lib/auth.ts"
fi

if [ -f "lib/cherry-api.ts" ]; then
    echo "⚠️  lib/cherry-api.ts already exists - skipping"
else
    echo "✅ Ready to copy lib/cherry-api.ts"
fi

echo ""
echo "📋 Next Steps:"
echo "1. Copy files from web-integration/nextjs-auth/ to your project:"
echo "   cp middleware.ts ."
echo "   cp lib/*.ts lib/        # auth, session, cherry-api, rate-limit, safe-redirect"
echo "   cp -r app/api app/"
echo "   cp -r app/login app/"
echo "   cp -r app/dashboard app/"
echo ""
echo "2. Add to .env.local:"
echo "   CHERRY_API_URL=https://your-cherry-api.com"
echo "   CHERRY_API_KEY=your-api-key"
echo "   ADMIN_USERNAME=you@yourcompany.com   # you choose this"
echo "   ADMIN_PASSWORD=$(openssl rand -base64 18)   # generated now: keep it, it is your sign-in"
echo "   JWT_SECRET=$(openssl rand -hex 32)"
echo "   (no defaults exist: sign-in stays off until all three are set)"
echo ""
echo "3. Run: npm run dev"
echo ""
echo "4. Open: http://localhost:3000/login"
echo ""
echo "📚 See DOCUMENTATION.md for full details"
