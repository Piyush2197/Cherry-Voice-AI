#!/usr/bin/env python3
"""Credential-free tests for Telnyx voice transfer routing."""

from __future__ import annotations

import asyncio
import traceback
from pathlib import Path

import telnyx_voice as tv
import menu_schema as ms
from order_store import OrderStore
from pilot_deploy import load_manifest


_passed = _failed = 0


def check(name, condition, detail=""):
    global _passed, _failed
    if condition:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


class FakeTransport:
    def __init__(self, status=200, payload=None):
        self.status = status
        self.payload = payload or {"data": {"result": "ok"}}
        self.calls = []

    async def post(self, url, headers, body, timeout):
        self.calls.append((url, headers, body, timeout))
        return self.status, self.payload


def t_manifest_routes_only_activated_locations() -> None:
    rows = load_manifest()
    first = rows[0]
    routes = tv.routes_from_manifest(rows, {first.inbound_env: "+13135550101"})
    check("one configured number creates one route", len(routes) == 1, str(routes))
    check("the route uses the published human fallback",
          routes["+13135550101"] == first.fallback_phone)


def t_transfer_uses_call_control_endpoint_and_idempotency() -> None:
    async def run():
        fake = FakeTransport()
        transfer = tv.TelnyxCallTransfer(
            {"+13135550101": "+13135550102"}, api_key="secret", transport=fake)
        await transfer("v3:call/id", "+13135550101", "backend unavailable")
        await transfer("v3:call/id", "+13135550101", "retry")
        return fake.calls

    calls = asyncio.run(run())
    url, headers, body, timeout = calls[0]
    check("transfer uses the encoded Call Control endpoint",
          url.endswith("/calls/v3%3Acall%2Fid/actions/transfer"), url)
    check("the API key stays in the authorization header",
          headers == {"Authorization": "Bearer secret"}, str(headers))
    check("the restaurant receives the transfer", body["to"] == "+13135550102")
    check("transfer timeout is bounded", body["timeout_secs"] == 30)
    check("retries use the same command id",
          calls[0][2]["command_id"] == calls[1][2]["command_id"])


def t_missing_route_and_telnyx_failure_are_loud() -> None:
    async def missing():
        transfer = tv.TelnyxCallTransfer(
            {"+13135550101": "+13135550102"}, api_key="secret",
            transport=FakeTransport())
        await transfer("call", "+13135550999", "failure")

    try:
        asyncio.run(missing())
        check("missing fallback cannot silently pass", False)
    except LookupError:
        check("missing fallback cannot silently pass", True)

    failed_audits = []

    async def rejected():
        transfer = tv.TelnyxCallTransfer(
            {"+13135550101": "+13135550102"}, api_key="secret",
            transport=FakeTransport(422, {"errors": ["bad call"]}),
            audit=lambda **row: failed_audits.append(row))
        await transfer("call", "+13135550101", "failure")

    try:
        asyncio.run(rejected())
        check("Telnyx rejection cannot silently pass", False)
    except RuntimeError as exc:
        check("Telnyx rejection includes the status", "422" in str(exc), str(exc))
        check("Telnyx rejection is audited",
              len(failed_audits) == 1
              and failed_audits[0]["status"] == "failed", str(failed_audits))


def t_transfer_results_are_written_to_the_operations_log() -> None:
    store = OrderStore.sqlite()
    cfg = ms.load_yaml(Path(__file__).resolve().parent /
                       "menus" / "tamago-sushi-bowl.yaml")
    store.upsert_restaurant(cfg.id, cfg.name, cfg.cuisine,
                            inbound_phone="+13135550101", active=True)
    version = store.publish_menu(
        cfg.id, ms.dump_yaml(cfg), item_count=len(cfg.items))
    store.start_session(cfg.id, version, external_id="call-a")

    async def run():
        transfer = tv.TelnyxCallTransfer(
            {"+13135550101": "+13135550102"}, api_key="secret",
            transport=FakeTransport(), audit=tv.StoreTransferAudit(store))
        await transfer("call-a", "+13135550101", "offline")

    asyncio.run(run())
    events = store.events(kind="voice.handoff_succeeded")
    check("a successful handoff reaches the operations log", len(events) == 1)
    check("handoff audit stays attached to its restaurant",
          events[0]["restaurant_id"] == cfg.id, str(dict(events[0])))


def main() -> int:
    for name, fn in sorted(globals().items()):
        if not name.startswith("t_"):
            continue
        try:
            fn()
        except Exception:
            global _failed
            _failed += 1
            print(f"\n--- FAIL {name}\n{traceback.format_exc()}")
    print(f"\n{_passed} passed, {_failed} failed (Telnyx voice transfer)")
    return 1 if _failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
