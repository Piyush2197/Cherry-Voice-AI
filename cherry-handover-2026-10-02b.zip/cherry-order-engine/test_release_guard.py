#!/usr/bin/env python3
import release_guard as rg

def main():
    good=rg.evaluate([100]*95+[1200]*5,0)
    bad_latency=rg.evaluate([100]*90+[2000]*10,0)
    bad_errors=rg.evaluate([100]*98,2)
    assert good.passes
    assert not bad_latency.passes and bad_latency.p95_ms==2000
    assert not bad_errors.passes and bad_errors.error_percent>1
    print("3 passed, 0 failed (release guard)");return 0
if __name__=="__main__":raise SystemExit(main())
