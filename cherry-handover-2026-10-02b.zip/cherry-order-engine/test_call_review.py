#!/usr/bin/env python3
"""`call_review.py`: after one real call, did the model use the engine as told?

Calls are driven through the real server and gateway (rehearsal.Stack), the way
a voice worker would, then reviewed from what they left in the database. A
well-behaved sequence passes; a model that pushes an allergy through add_item,
retries a tool, or paraphrases the engine's words is caught.
"""

from __future__ import annotations

import contextlib
import io
import json
import os
import tempfile
import time
import traceback

import call_review
import rehearsal

_passed = _failed = 0


def check(name, cond, detail=""):
    global _passed, _failed
    if cond:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


def levels(report, level):
    return [f["text"] for f in report["findings"] if f["level"] == level]


def a_good_call(st, cid="good-1"):
    st.call(cid)
    st.tool(cid, "add_item", text="chicken korma")
    st.tool(cid, "answer", text="medium")
    st.tool(cid, "add_item", text="two garlic naan")
    st.tool(cid, "ready_to_place")
    st.tool(cid, "set_name", text="Sam")
    st.tool(cid, "note_allergy", text="peanut allergy")
    st.finish(cid)


def t_a_well_behaved_call_passes_and_shows_what_the_model_did() -> None:
    st = rehearsal.Stack()
    try:
        a_good_call(st)
        r = call_review.review(st.store, "good-1", expect=["set_name", "note_allergy", "reorder_last"])
        check("it finds the call by its telephony id", r["call_id"] == "good-1" or r["session"], str(r["call_id"]))
        used = r["tools_used"]
        check("the trace lists every tool, in order, starting with the greeting",
              [t["tool"] for t in r["trace"]][:6] == ["greeting", "add_item", "answer", "add_item", "ready_to_place", "set_name"],
              str([t["tool"] for t in r["trace"]]))
        check("…with what the caller said that caused each", r["trace"][1]["heard"] == "chicken korma", str(r["trace"][1]))
        check("set_name and note_allergy were used", used.get("set_name") == 1 and used.get("note_allergy") == 1, str(used))
        ok = " ".join(levels(r, "ok"))
        check("it reports the opening greeting", "greeting" in ok)
        check("…that the name and allergy answers reached the right tools", "went to set_name" in ok, ok)
        check("…and no repeats", "no repeated tool calls" in ok)
        check("a tool the model never used is a warning, not a failure",
              any("never called reorder_last" in w for w in levels(r, "warn")) and r["verdict"] == "warn", r["verdict"])
        check("the outcome: order placed with the name and the allergy on the ticket",
              r["outcome"]["order_placed"] and r["outcome"]["name"] == "Sam" and "peanut" in r["outcome"]["allergy"], str(r["outcome"]))
        check("the cost is estimated for today's stack and for Gemini 3.8 Live",
              r["cost"] and 0 < r["cost"]["today"] < r["cost"]["gemini_3_8_high"] and r["cost"]["gemini_3_8_low"] <= r["cost"]["gemini_3_8_high"], str(r["cost"]))
        check("engine latency is summarised", r["latency"] and r["latency"]["max_ms"] >= r["latency"]["median_ms"], str(r["latency"]))
        text = call_review.render(r)
        check("the printout shows the trace, the checks and a verdict",
              "What the model did:" in text and "Checks:" in text and "Verdict:" in text and "chicken korma" in text)
        check("--latest finds the same call", call_review.find_session(st.store, latest=True)["id"] == r["session"])
    finally:
        st.close()


def t_a_model_that_pushes_the_allergy_through_add_item_fails() -> None:
    st = rehearsal.Stack()
    try:
        st.call("bad-1")
        st.tool("bad-1", "add_item", text="chicken korma")
        st.tool("bad-1", "answer", text="medium")
        st.tool("bad-1", "ready_to_place")                       # the engine asks for name + allergies
        st.tool("bad-1", "add_item", text="my name is Sam and I have a peanut allergy")   # …and the model misroutes it
        r = call_review.review(st.store, "bad-1")
        fails = levels(r, "fail")
        check("the misrouted answer is a failure naming the tool it went to",
              any("went to 'add_item'" in f for f in fails), str(fails))
        check("the verdict is FAILED", r["verdict"] == "fail")
        check("the allergy never reached the order", not r["outcome"]["order_placed"])
        check("the printout says so", "FAILED" in call_review.render(r))
        check("the CLI exits 3", _cli(st, "--call", "bad-1") == 3)
    finally:
        st.close()


def t_a_retrying_model_is_counted() -> None:
    st = rehearsal.Stack()
    try:
        st.call("dup-1")
        st.tool("dup-1", "add_item", text="garlic naan")
        st.tool("dup-1", "add_item", text="garlic naan")       # inside 2.5 s: absorbed, not added twice
        st.tool("dup-1", "add_item", text="garlic naan")
        snap = st.app.live["dup-1"].call.snapshot()
        check("the engine put the dish on once", [(l["item_name"], l["quantity"]) for l in snap["lines"]] == [("Garlic Naan", 1)], str(snap["lines"]))
        r = call_review.review(st.store, "dup-1")
        warn = " ".join(levels(r, "warn"))
        check("the review says the model retries, and how often", "absorbed 2 repeated tool call(s)" in warn and "add_item" in warn, warn)
    finally:
        st.close()


def t_what_the_voice_said_is_compared_with_what_the_engine_said() -> None:
    st = rehearsal.Stack()
    try:
        a_good_call(st, "say-1")
        r0 = call_review.review(st.store, "say-1")
        engine = [t["said"] for t in r0["trace"]]
        r = call_review.review(st.store, "say-1", spoken=list(engine))
        check("a voice that said exactly the engine's words passes", any("match the engine's words" in f for f in levels(r, "ok")), str(levels(r, "warn") + levels(r, "fail")))
        # punctuation and capitals are not paraphrase
        r = call_review.review(st.store, "say-1", spoken=[e.upper().replace(",", "") for e in engine])
        check("capitals and commas do not count as drift", not r["verbatim"]["drift"], str(r["verbatim"]["drift"][:1]))
        # a friendly paraphrase is a warning
        said = list(engine)
        said[1] = "Sure thing, one chicken korma coming right up, how spicy would you like it today?"
        r = call_review.review(st.store, "say-1", spoken=said)
        d = r["verbatim"]["drift"]
        check("a paraphrase is caught on the right line", len(d) == 1 and d[0]["turn"] == 2 and d[0]["tool"] == "add_item", str(d))
        # a changed number is a failure: a spoken price is the one thing that cannot drift
        numbered = next(i for i, e in enumerate(engine) if any(ch.isdigit() for ch in e))
        said = list(engine)
        said[numbered] = "".join("9" if ch.isdigit() else ch for ch in engine[numbered])
        r = call_review.review(st.store, "say-1", spoken=said)
        check("a changed price or quantity FAILS the review",
              r["verdict"] == "fail" and any(f["severity"] == "fail" for f in r["verbatim"]["drift"]), str(r["verbatim"]["drift"]))
        # lines added or dropped
        r = call_review.review(st.store, "say-1", spoken=engine[:-2])
        check("fewer lines spoken than the engine produced is reported", any("added or dropped" in w for w in levels(r, "warn")))
        # the file form through the CLI
        path = tempfile.mkdtemp() + "/spoken.txt"
        open(path, "w").write("\n".join(engine) + "\n")
        check("the CLI accepts --spoken and passes", _cli(st, "--call", "say-1", "--spoken", path) in (0,))
    finally:
        st.close()


def _cli(st, *argv):
    with contextlib.redirect_stdout(io.StringIO()):
        return call_review.main(["--db", rehearsal.URL, *argv])


def t_the_command_line_and_its_edges() -> None:
    st = rehearsal.Stack()
    try:
        a_good_call(st, "cli-1")
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            rc = call_review.main(["--db", rehearsal.URL, "--latest", "--json"])
        doc = json.loads(buf.getvalue())
        check("--json is machine-readable and complete", rc == 0 and doc["verdict"] in ("ok", "warn") and doc["trace"] and doc["outcome"]["order_placed"], buf.getvalue()[:200])
        check("--no-trace drops the transcript", "What the model did" not in _render_cli(st, "--latest", "--no-trace"))
        check("an unknown call is exit 2, not a traceback", _cli(st, "--call", "no-such-call") == 2)
        check("a restaurant's own session id also works", _cli(st, "--call", doc["session"]) == 0)
    finally:
        st.close()


def _render_cli(st, *argv):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        call_review.main(["--db", rehearsal.URL, *argv])
    return buf.getvalue()


def t_it_reads_and_changes_nothing() -> None:
    st = rehearsal.Stack()
    try:
        a_good_call(st, "ro-1")
        tables = ("turn", "call_journal", '"order"', "event", "session")
        before = {t: st.store.conn.execute(f"SELECT COUNT(*) c FROM {t}").fetchone()["c"] for t in tables}
        call_review.review(st.store, "ro-1", spoken=["x"])
        after = {t: st.store.conn.execute(f"SELECT COUNT(*) c FROM {t}").fetchone()["c"] for t in tables}
        check("a review writes nothing", before == after, f"{before} vs {after}")
    finally:
        st.close()


def main() -> int:
    global _failed
    for name, fn in sorted((k, v) for k, v in globals().items() if k.startswith("t_")):
        try:
            fn()
        except Exception:                                    # noqa: BLE001
            _failed += 1
            print(f"\n--- FAIL {name} raised")
            traceback.print_exc()
    print(f"{_passed} passed, {_failed} failed (call review)")
    return 1 if _failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
