# Cherry two-business-day restaurant onboarding

For draft, offline owner demonstrations across a larger location roster, use
`DEMO_ONBOARDING.md`. A demo packet does not start this live-launch workflow or
meet the payment and provider acceptance checks below.

## The promise

> Once Cherry receives the complete menu, owner confirmations, fallback phone,
> operating hours and required POS/phone-provider authorization, we will prepare
> the restaurant for live acceptance within two business days. Launch occurs
> only after the restaurant passes the signed acceptance checklist.

The clock does not run while an owner, POS company or carrier is withholding a
required input. Do not promise “zero bugs”; promise a repeatable gate, a human
fallback and fast correction. Software cannot guarantee that a carrier approves
a number or that an owner supplied a correct price.

## One workflow

Every customer gets an onboarding case. Create it on the sales call:

```bash
./cherry.py onboard new \
  --out onboarding/acme-burger \
  --case-id acme-burger \
  --business-name "Acme Burger" \
  --location-id acme-burger-main \
  --location-name "Acme Burger — Main" \
  --cuisine burger \
  --pos toast
```

The case contains `intake.yaml`, a raw-menu slot and instructions. It refuses
credentials: the file records only whether authorization exists. Tokens remain
in the deployment secret manager.

Build the menu with the existing source-specific path:

```bash
# Owner/PDF/web text
./cherry.py ingest onboarding/acme-burger/raw-menu.txt \
  --cuisine burger --id acme-burger-main --name "Acme Burger — Main" \
  -o onboarding/acme-burger/menu.yaml

# Or a saved Square export
python3 location_catalog.py ...

./cherry.py check onboarding/acme-burger/menu.yaml
./cherry.py onboard status onboarding/acme-burger/intake.yaml
```

Only after that status has no sales, owner or menu blockers should sales set
`intake_completed_at`. That timestamp starts the two-business-day clock.

Generate the developer handoff:

```bash
./cherry.py onboard packet onboarding/acme-burger/intake.yaml \
  --out onboarding/acme-burger/launch
```

The packet contains:

- `deployment.yaml`: accepted directly by `pilot_deploy.py --manifest`.
- `controls.yaml`: hours, holidays, prep/wait time and languages.
- `calls/<location>-smoke.txt`: a generated pricing/read-back call.
- `audit.json`: machine-readable blockers grouped by owner.
- `LAUNCH_REPORT.md`: human checklist and SLA deadline.
- `acceptance.yaml`: the live acceptance record.

## Required intake before the clock starts

Sales collects these in one sitting:

1. Legal/display name and every location name.
2. Complete current menu, including fine print and every modifier price.
3. Owner confirmation of prices, modifiers, tax and combos/bundles.
4. Weekly hours, holiday closures, prep time and wait-time policy.
5. Direct restaurant fallback number in `+1...` format.
6. POS type and POS location identity.
7. Owner approval for hosted payment links and SMS messages.
8. Supported call languages.
9. The person authorized to approve the launch.
10. **The phrases their callers actually say** — for each best-seller, the
    exact words regulars use, in English, transliterated Arabic, and Spanish
    ("shish tawook", "pollo", "number 3 with a pop", "sin cebolla"). These go
    into menu `aliases` at ingest; this is the Level-1 multilingual wedge from
    `ENGINE_MOAT.md`, and it is data, not code.
11. Merchant/provider authorization completed outside the case file.

For the current paid-first flow, the intake must name `checkout_provider:
square` and record `checkout_authorized: true` only after the merchant has
authorized itemized checkout. These are proof flags, never credentials. A
manual-only POS or a generic website link cannot pass the launch audit.

Missing information is not “work in progress”; it is a named blocker owned by
sales, the restaurant, Cherry or the deployment developer.

## Forty-eight-hour operating schedule

### Day 0 — qualification and complete intake

- Sales creates the case while talking to the owner.
- Owner sends the authoritative menu or grants catalog access.
- Cherry imports the menu and returns one consolidated question list.
- Owner answers once and approves the modeled menu.
- `intake_completed_at` is set; the SLA clock begins.

### Day 1 — configuration and automated proof

- Run schema, lint, price sweep and all conformance invariants.
- Generate ASR terms, location controls, deployment manifest and smoke call.
- Map Square variations or Toast item/group GUIDs.
- Assign the location's separate phone route and direct fallback.
- Clear every machine-readable blocker in `audit.json`.

### Day 2 — staging and signed live acceptance

- Deploy database/menu/controls without directing customer traffic.
- Run routing, order, modifier, combo, sold-out, kitchen, payment, fallback,
  hours, concurrency and rollback checks.
- Owner listens to representative calls and compares the POS ticket and price.
- Complete `acceptance.yaml` and issue the launch certificate.
- Route production traffic and monitor the first calls in `/ops`.

## Deployment commands

```bash
python3 pilot_deploy.py plan \
  --manifest onboarding/acme-burger/launch/deployment.yaml

python3 pilot_deploy.py apply --sink square --db "$CHERRY_DATABASE_URL" \
  --manifest onboarding/acme-burger/launch/deployment.yaml

./cherry.py onboard apply-controls \
  onboarding/acme-burger/launch/controls.yaml \
  --db "$CHERRY_DATABASE_URL"

python3 pilot_deploy.py verify --db "$CHERRY_DATABASE_URL" \
  --manifest onboarding/acme-burger/launch/deployment.yaml

python3 pilot_deploy.py checkout-ready --db "$CHERRY_DATABASE_URL" \
  --manifest onboarding/acme-burger/launch/deployment.yaml
```

`checkout-ready` checks configuration, not an actual charge. The live
acceptance record must still prove an exact itemized total, delivered checkout
SMS, paid Square order visibility to staff, and no duplicate Cherry kitchen
ticket. The Square payment webhook is optional for the checkout-handoff-only
call flow; if enabled, it must not release another order.

Complete every check in `acceptance.yaml`, record any defect and its test, then:

```bash
./cherry.py onboard certify \
  onboarding/acme-burger/intake.yaml \
  onboarding/acme-burger/launch/acceptance.yaml \
  --out onboarding/acme-burger/launch/LAUNCH_CERTIFICATE.json
```

Certification fails if a check is false, the owner has not signed, a menu has
changed, or a discovered issue lacks both a resolution and regression-test name.
The certificate hashes every launched menu.

## Managing many simultaneous restaurants

```bash
./cherry.py onboard portfolio onboarding/
./cherry.py onboard portfolio onboarding/ --json
```

This gives sales and operations one view of cases, locations, deadlines and
blocker owners without exposing contacts or credentials. Prioritize `overdue`,
then `activation`; do not spend engineering time on `waiting_intake` cases.

## Learning from the first ten restaurants

For every launch defect:

1. Transfer the live caller to the verified direct staff line. Do not issue an
   unpaid manual kitchen ticket or transfer to the forwarded public number.
2. Record the exact issue in `acceptance.yaml` or the production incident.
3. Fix the shared engine/tool when general, or menu data when restaurant-only.
4. Add a regression test named in the issue record.
5. Run the complete suite across every existing restaurant.
6. Only then certify the affected launch.

This makes restaurant eleven inherit everything learned from restaurants one
through ten. Cuisine-specific forks are forbidden; one shared engine plus
versioned restaurant data is what lets fixes improve the entire fleet.

## Capacity rule

A two-day promise is sustainable only when active complete-intake cases do not
exceed team capacity. Start with no more than two simultaneous activation cases
per trained onboarding operator. Cases waiting for owners or providers do not
consume the SLA queue. Measure median time in each state before raising the cap.
