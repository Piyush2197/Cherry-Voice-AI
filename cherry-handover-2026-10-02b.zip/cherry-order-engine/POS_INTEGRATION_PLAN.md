# POS integration plan — Metro Detroit

Written 2026-09-30, prompted by "we can't deploy due to POS strains" and
"connect the most-used POS with API access available in market used by
restaurants in Metro Detroit". Platform facts researched from vendor developer
documentation the same day; confidence flags are inline.

## The reframe first: POS strain is not a deploy blocker

Cherry's launch design (`NEW_CHAT_HANDOFF.md`) is **checkout-handoff-only**:
Cherry takes the order by voice, texts the customer an itemized Square
checkout link, and Square makes the paid order visible to the merchant's POS
and kitchen. In this mode Cherry needs **no POS API at all** — the merchant's
own POS picks up the paid order through Square. What a POS API adds is
injection of the *unpaid voice order* into the kitchen display before payment
(faster pickup, dine-in, phone-in-tickets for non-Square merchants).

So the dependency order is:

1. **Deploy on Square-authorized merchants** — works today, zero POS
   integration. This is the pilot path and it is not blocked.
2. **Menu sync via Square Catalog** (engineering, self-serve API) — stops
   owner re-keying menus; makes onboarding faster.
3. **POS order injection** for non-Square merchants — the actual "POS strain";
   see the matrix.

## The matrix

| Platform | API reality | Access path | Realistic for us? |
|---|---|---|---|
| **Square** | Full self-serve: Orders, Catalog, Webhooks. Already integrated | Open | **Done** — deepen with Catalog menu sync |
| **Toast** | Private Orders API with order *injection* (POST), Menus API. Partner-gated | Application → vetting → signed agreement → sandbox → alpha/beta/GA. **Months**. Loman AI (our exact category) is approved — precedent exists | **Start the application now** — biggest share of independent table-service; slowest clock |
| **Clover** | Open sandbox today; production via App Market review (weeks) | Developer account + app approval | **Second integration** — big QSR share, self-serve start |
| **SpotOn** | Public docs are **export/read-oriented**; no documented order-write | Integration intake form | Watch — submit the form, low effort |
| **Heartland Restaurant** | "Open API" marketing claim; no public endpoint docs | Partner program contact | Watch (Miyazaki's pilot POS is Heartland-adjacent) |
| **SkyTab (Shift4)** | Only pay-at-table docs; ordering via marketplace partners | Authorized-partner program | Do not bother yet |
| **HungerRush/Menufy** | API exists, partner-gated, no public portal | Partnership | Do not bother yet |
| **Chowly** | Aggregator with Menu+Orders APIs; pushes into 50+ POSes | Partnership/SDK contact | **The bridge that unlocks closed POSes** — one deal, many POSes |
| **Slice** | "Slice Public API" portal exists; gating unclear | Unclear | Pizzeria fallback only |
| **BeyondMenu, SpotApps, Smile Dining, epipay** | No public API found | Direct vendor contact only | No API path — see below |

Uber Direct / DoorDash Drive are documented and cheap but are *courier*
APIs, not POS injection — relevant only when we sell delivery.

## The no-API tail is our opportunity, not our blocker

BeyondMenu, SpotApps, Smile Dining and epipay are exactly the white-label
ordering pages our Clinton prospects use (`Platform view` sheet: 2 BeyondMenu,
2 Menufy, 1 SpotApps, 1 Smile Dining, 1 epipay, plus pilots). These are the
restaurants with **the worst ordering experience and the most missed calls** —
which is why they picked a white-label site in the first place. For them:

- The Square checkout-handoff flow **is** the integration (they all take
  card payments; Square account is the merchant's own).
- The kitchen ticket path is: paid Square order visible to staff, plus the
  existing ticket sink (`/t/{code}`) and the manual acknowledged-ticket
  fallback. It is slower than injection but it works on day one.
- Long-term these merchants are the best candidates to **replace** their
  white-label ordering page with Cherry's QR channel (`QR_CHANNEL.md`).

## Payments without integration — the layered answer (2026-10-01)

Standing principle: **Cherry never accepts payments.** No card data enters
our systems, no restaurant's money ever passes through us — the money path
always belongs to the restaurant. Per restaurant type:

1. **On Square:** itemized checkout link, money settles in their Square
   account (built, tested).
2. **Not on Square — Path A, pay at pickup:** `pay_now_threshold_cents` is
   per-location; set high, every order is "pay at pickup." Cherry takes the
   order, the tablet ticket reaches the kitchen, the customer pays the
   counter exactly as they always have — their Toast terminal, their cash
   drawer. Works for every restaurant with zero integration; the no-show
   risk is the same one they already accept on every call-in order.
3. **Not on Square — Path B, the free Square drawer:** the upgrade pitch.
   Square accounts are free and take ten minutes; the restaurant keeps its
   Toast/Clover as the main register and adds Square purely as the drawer
   for the phone channel. Money settles to their bank; Square's ~2.6% applies
   only to the incremental orders Cherry recovers from voicemail. This is
   the same math DoorDash tablets normalized for owners.
4. **Future (Toast/Clover partner APIs):** order injected into their POS,
   payment collected by their system. Until then, 2 and 3 cover the tail.

Sales framing that defuses the trust objection: *"We never touch your
money. It goes from your customer to your account, and we bill our
subscription separately."* Under-threshold orders default to pay-at-pickup
already; owners who want links on everything can set the threshold to zero.

## The tablet bridge — the interim path until a real POS API (built 2026-10-01)

Waiting months for Toast partner access does not mean waiting for a kitchen
path. This is the DoorDash-tablet pattern, and it is **already built**:

- **No app store.** `GET /kds?r=<id>&k=<display-key>` is a single
  dependency-free page the restaurant opens in Safari on the iPad they
  already have. Add to Home Screen and it behaves like an app.
- **It chimes.** The page polls every 8 seconds; a new paid order appears as
  a full-screen card with a three-tone chime (WebAudio — no sound files,
  audio unlocks on the first staff tap, per iPad policy).
- **It shows the kitchen what a cook needs:** quantity, item, size, and the
  separation the ticket format already enforces — *what the caller asked for*
  (bright, `+no onion`) versus *what the item ships with* (dimmed). Caller
  phone numbers and transcripts never reach the tablet.
- **Accept is the existing ack.** The big green button calls the same
  `/t/{code}/accept` the SMS-ticket flow uses, so `order_delivery.acknowledged`
  is the single source of truth for "kitchen saw it."
- **Fallbacks stack:** the staff-phone SMS still fires as before, so the
  tablet is an upgrade, not a single point of failure.
- **Security without per-store secrets:** the display key is an HMAC of the
  restaurant id under the server secret (`server.kds_key`) — derived, not
  stored, scoped to one restaurant, and rotating the server key retires every
  tablet at once. `cherry.py kds <restaurant-id> --base-url https://…`
  prints the URL to text to the owner.

Test coverage: `test_kds.py` (5 checks) — key scoping and cross-restaurant
refusal, page auth, the kitchen-only feed (no customer phone in the payload),
and staff acceptance end to end over a real socket.

When a real POS API lands (Toast/Clover per this plan), the tablet remains
the fallback for every restaurant the API doesn't reach — which, per the
matrix above, is most of the tail.

## Decision

1. **Do not gate any launch on a POS integration.** Square handoff deploys.
2. **This week:** submit the Toast partner application (longest clock) and the
   SpotOn intake form (cheap). Start a Clover developer sandbox.
3. **This month:** build Square Catalog menu sync — it removes the biggest
   onboarding cost (menu data entry) for the most merchants.
4. **When a non-Square cluster justifies it:** pursue Chowly as the bridge
   before any individual closed-POS partnership.
5. Every prospect conversation logs POS + payment processor in the workbook
   Tracker — the matrix above only matters in proportion to what our route
   actually hits.
