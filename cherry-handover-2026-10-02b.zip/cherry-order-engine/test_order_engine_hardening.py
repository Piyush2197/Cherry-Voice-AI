#!/usr/bin/env python3
"""The four hardening tests — unit edge cases, integration journey, the
Friday-night rush, and idempotency — written against the engine AS IT IS.

Mapping notes (read before "fixing" anything):

- **Currency and tax.** Every amount is integer cents; tax is Decimal at
  basis-points over the *taxable* subtotal with explicit half-up rounding.
  The LLM never sees a number it may change.
- **Discounts.** There is deliberately no discount/promo path in the voice
  engine: the engine prices the catalog verbatim, and promotions belong to
  the itemized Square checkout the owner controls. The unit tests below
  prove the negative instead — no client-supplied amount can enter, and a
  negative price cannot survive menu validation.
- **Inventory.** Restaurants do not count down per-unit stock here; the
  owner 86s an item (availability override) and every new call is refused
  it. The "last item sold twice" race of a web store does not exist in this
  shape — the race that DOES exist is double-payment / double-release, and
  that is what the concurrency section hammers.
- **Status vocabulary.** The database status is ``placed`` (immutable
  snapshot) with payment state held in a separate row — not a web-style
  mutable ``Pending``. The kitchen receives the ticket only after payment,
  exactly once.
"""
from __future__ import annotations

import _ensure_deps  # noqa: F401  (re-runs under .venv, or says how to install, if PyYAML is missing)
import copy
import threading
import unittest
from pathlib import Path

import yaml

import menu_schema as ms
import payments
import restaurants
import square_webhook
from agent_api import CallSession
from config_validator import lint_config
from dev_checkout import DevCheckoutProvider
from order_engine import OrderEngine, parse_quantity
from order_store import OrderStore
from sinks import FakeSmsSender

HERE = Path(__file__).parent


def minimal_menu() -> dict:
    return {
        "schema_version": 1,
        "restaurant": {"id": "edge-x", "name": "Edge X", "cuisine": "burger",
                       "tax_rate_bps": 600, "pay_now_threshold_cents": 0,
                       "pay_now_basis": "subtotal", "pos_type": "manual",
                       "currency": "USD"},
        "options": [{"id": "x_patty", "name": "Extra patty", "price": 1.50}],
        "groups": [{"id": "x_addons", "name": "Add-ons",
                    "prompt": "Any add-ons?",
                    "options": ["x_patty"], "max": 1}],
        "items": [
            {"id": "x_burger", "name": "Hamburger", "price": 8.99,
             "groups": ["x_addons"]},
            {"id": "x_pop", "name": "Fountain Pop", "price": 1.99,
             "taxable": False},
        ],
    }


def build(doc):
    problems = ms.validate_doc(doc)
    assert not problems, problems
    cfg = ms.build_config(doc)
    errs = [f for f in lint_config(cfg) if f.level == "ERROR"]
    assert not errs, errs
    return cfg


def paid_order_fixture(sink="manual", quantity=1, with_session=False):
    """A real order through the real path, ready for payment (test_payment_gate
    fixture pattern)."""
    store = OrderStore.sqlite()
    path = HERE / "menus" / "bun-n-run-ferndale.yaml"
    cfg = ms.load_yaml(path)
    store.upsert_restaurant(cfg.id, cfg.name, cfg.cuisine, sink=sink,
                            tax_rate_bps=cfg.tax_rate_bps,
                            staff_phone="+13135550999", active=True)
    mv = store.publish_menu(cfg.id, path.read_text(), item_count=len(cfg.items))
    engine = OrderEngine(cfg)
    line = engine.add_line("double_cheeseburger", quantity=quantity)
    for gid in engine.active_group_ids(line):
        group = cfg.group(gid)
        if group and group.required:
            engine.apply_option(line.line_id, gid, group.option_ids[0])
    snapshot = engine.to_normalized_order()
    sid = store.start_session(cfg.id, mv, external_id="call-hardening") \
        if with_session else None
    order_id, code = store.place_order(cfg.id, mv, snapshot,
                                       session_id=sid,
                                       customer_phone="+13135550123")
    return store, order_id, code, snapshot


# ---------------------------------------------------------------------------
# 1. Unit edge cases


class TestUnitEdgeCases(unittest.TestCase):
    """Exact tax, the discount non-path, hostile quantities, sold-out items."""

    def test_exact_tax_rounding_on_a_half_cent(self):
        # $1.00 at 29.5% (2950 bps) is exactly 29.5 cents -> half-up to 30.
        doc = minimal_menu()
        doc["restaurant"]["tax_rate_bps"] = 2950
        doc["items"] = [{"id": "x_burger", "name": "Hamburger", "price": 1.00}]
        cfg = build(doc)
        e = OrderEngine(cfg)
        e.add_line("x_burger", quantity=1)
        p = e.price()
        self.assertEqual(p.subtotal_cents, 100)
        self.assertEqual(p.tax_cents, 30)           # 100 * 2950 / 10000 = 29.5

        # the same math at realistic rates, where a float would drift
        doc["restaurant"]["tax_rate_bps"] = 777     # 7.77%
        doc["items"][0]["price"] = 9.99             # 999 * 777 = 776,223
        cfg = build(doc)
        e2 = OrderEngine(cfg)
        e2.add_line("x_burger", quantity=1)
        self.assertEqual(e2.price().tax_cents, 78)  # 77.6223 -> 78

    def test_tax_rate_schema_guard(self):
        # the menu schema itself refuses nonsense rates before any math runs
        doc = minimal_menu()
        doc["restaurant"]["tax_rate_bps"] = 3001
        self.assertTrue(ms.validate_doc(doc),
                        "a 30.01% 'tax rate' must not validate")
        doc["restaurant"]["tax_rate_bps"] = -1
        self.assertTrue(ms.validate_doc(doc),
                        "a negative tax rate must not validate")

    def test_tax_only_on_taxable_items(self):
        # burger taxable, pop not: tax applies to the burger's line only.
        doc = minimal_menu()
        doc["restaurant"]["tax_rate_bps"] = 1000    # easy 10%
        cfg = build(doc)
        e = OrderEngine(cfg)
        e.add_line("x_burger", quantity=1)          # 899
        e.add_line("x_pop", quantity=1)             # 199, taxable=False
        p = e.price()
        self.assertEqual(p.subtotal_cents, 1098)
        self.assertEqual(p.tax_cents, 90)           # 10% of 899 = 89.9 -> 90
        self.assertEqual(p.total_cents, 1188)

    def test_modifier_taxed_with_its_item(self):
        # A paid extra patty changes the taxable base with the item.
        doc = minimal_menu()
        doc["restaurant"]["tax_rate_bps"] = 1000
        cfg = build(doc)
        e = OrderEngine(cfg)
        line = e.add_line("x_burger", quantity=1)
        e.apply_option(line.line_id, "x_addons", "x_patty")   # +150
        p = e.price()
        self.assertEqual(p.subtotal_cents, 1049)
        self.assertEqual(p.tax_cents, 105)          # 104.9 -> 105

    def test_no_client_price_path_exists(self):
        # The only totals in the system are engine-computed from config; the
        # snapshot the database stores is the engine's, re-printed verbatim.
        doc = minimal_menu()
        cfg = build(doc)
        e = OrderEngine(cfg)
        e.add_line("x_burger", quantity=2)
        snapshot = e.to_normalized_order()
        self.assertEqual(snapshot["total_cents"], e.price().total_cents)
        self.assertEqual(snapshot["subtotal_cents"], e.price().subtotal_cents)
        # and there is no API to hand the engine a total from outside
        for forbidden in ("set_total", "set_price", "apply_discount",
                          "set_subtotal", "add_discount"):
            self.assertFalse(hasattr(e, forbidden), forbidden)
            self.assertFalse(hasattr(CallSession(cfg), forbidden), forbidden)

    def test_negative_price_cannot_enter_the_catalog(self):
        doc = minimal_menu()
        doc["items"].append({"id": "x_free", "name": "Cash Back",
                             "price": -5.00})
        self.assertTrue(ms.validate_doc(doc), "negative price must not validate")

    def test_hostile_quantities(self):
        # loose speech clamps into 1..99
        self.assertEqual(parse_quantity("0 cokes"), 1)
        self.assertEqual(parse_quantity("-3 burgers"), 1)
        self.assertEqual(parse_quantity("150 tacos"), 1)
        self.assertEqual(parse_quantity("three tacos"), 3)
        # engine layer floors at 1 no matter what the tool layer passes
        doc = minimal_menu()
        cfg = build(doc)
        e = OrderEngine(cfg)
        line = e.add_line("x_burger", quantity=-7)
        self.assertEqual(line.quantity, 1)
        # tool layer: zero or negative quantity removes the line entirely
        s = CallSession(cfg)
        s.add_item("hamburger")
        r = s.set_quantity(0)
        self.assertEqual(s.e.price().subtotal_cents, 0)
        self.assertIn("off", r["say"].lower())      # "taken off."

    def test_sold_out_item_is_refused_politely(self):
        # the 86: owner marks the item unavailable; new calls cannot order it.
        # The engine is more precise than "not found" — it says unavailable.
        doc = minimal_menu()
        cfg = build(doc)
        sold_out = restaurants.apply_availability(
            cfg, unavailable_item_ids=frozenset({"x_burger"}))
        s = CallSession(sold_out)
        r = s.add_item("hamburger")
        self.assertFalse(r["ok"])
        self.assertEqual(r["error"], "item_unavailable")
        self.assertTrue(r["ok"] is False)
        # and no alias phrasing sneaks past the 86
        for phrasing in ("hamburgers", "burger", "2 burgers"):
            r2 = s.add_item(phrasing)
            self.assertFalse(r2["ok"], phrasing)

        # option-level 86: the item is fine, the extra patty is not
        opt_out = restaurants.apply_availability(
            cfg, unavailable_option_ids=frozenset({"x_patty"}))
        s2 = CallSession(opt_out)
        s2.add_item("hamburger")
        r3 = s2.add_modifier("extra patty")
        self.assertFalse(r3["ok"])
        self.assertEqual(r3["error"], "option_unavailable")

    def test_closed_kitchen_and_stale_cart_guards(self):
        # a caller cannot order a sold-out item by naming it differently, and
        # a modifier for an item not on the order is refused, not invented.
        doc = minimal_menu()
        cfg = build(doc)
        sold_out = restaurants.apply_availability(
            cfg, unavailable_item_ids=frozenset({"x_burger"}))
        s = CallSession(sold_out)
        for phrasing in ("hamburger", "hamburgers", "burger", "2 burgers"):
            r = s.add_item(phrasing)
            self.assertFalse(r["ok"], phrasing)


# ---------------------------------------------------------------------------
# 2. Integration journey: cart -> pay -> kitchen ticket (pickup voice shape)


class TestIntegrationJourney(unittest.TestCase):
    """The full voice journey, payment before kitchen, exactly one ticket.

    There is no delivery-address step: Cherry places PICKUP orders and the
    restaurant's Square checkout owns the review-and-pay page. The three
    simultaneous facts verified are the voice-flow equivalents of the brief:
    an immutable order row (status 'placed', payment pending), one kitchen
    ticket after payment, and the 86 sheet untouched by automation.
    """

    def test_full_journey_add_pay_release_once(self):
        store, oid, code, snapshot = paid_order_fixture(sink="manual")
        sms = FakeSmsSender()
        provider = DevCheckoutProvider()

        # cart -> checkout: link sent, order held, nothing to any kitchen
        mode = payments.arrange_payment(store, oid, sms=sms, provider=provider)
        self.assertEqual(mode, "link_sent")
        row = store.order(oid)
        self.assertEqual(row["status"], "placed")            # immutable record
        payment = payments.payment_for(store, oid)
        self.assertEqual(payment["status"], "link_sent")
        self.assertIsNone(store.conn.execute(
            "SELECT 1 FROM order_delivery WHERE order_id=?",
            (oid,)).fetchone(), "no kitchen ticket before payment")
        self.assertEqual(len(sms.sent), 1)

        # payment succeeds -> release to the kitchen, exactly once
        self.assertTrue(payments.mark_paid(store, oid, "dev-pay-1"))
        release = payments.release_paid_order(store, oid, sms=sms)
        self.assertTrue(release["released"])
        deliveries = store.conn.execute(
            "SELECT * FROM order_delivery WHERE order_id=?", (oid,)).fetchall()
        self.assertEqual(len(deliveries), 1, "exactly one kitchen ticket")
        ticket = store.conn.execute(
            "SELECT snapshot FROM \"order\" WHERE id=?", (oid,)).fetchone()
        self.assertIn("Double Cheeseburger", ticket["snapshot"])

        # the 86 sheet: automation never decrements stock; owners decide
        overrides = store.conn.execute(
            "SELECT COUNT(*) c FROM availability_override").fetchone()["c"]
        self.assertEqual(overrides, 0)


# ---------------------------------------------------------------------------
# 3. Concurrency: the Friday-night rush


class TestFridayNightRush(unittest.TestCase):
    """N simultaneous payments of the same order: one ticket, no duplicates.

    The inventory race of a web store is replaced here by the payment race:
    Square retries webhooks and the kitchen must never cook one order twice.
    ``release_paid_order`` claims an ``order_release`` row with INSERT .. ON
    CONFLICT DO NOTHING inside the store's serialized write transaction —
    the losers must see ``already_claimed`` and nothing else may happen.
    """

    def test_simultaneous_release_exactly_once(self):
        store, oid, code, snapshot = paid_order_fixture(sink="manual")
        sms = FakeSmsSender()
        provider = DevCheckoutProvider()
        payments.arrange_payment(store, oid, sms=sms, provider=provider)
        self.assertTrue(payments.mark_paid(store, oid, "dev-pay-rush"))

        results, errors = [], []
        barrier = threading.Barrier(8)

        def rush(n):
            try:
                barrier.wait()                      # same millisecond, as asked
                results.append(
                    payments.release_paid_order(store, oid, sms=sms))
            except Exception as exc:                # pragma: no cover
                errors.append(exc)

        threads = [threading.Thread(target=rush, args=(i,)) for i in range(8)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        self.assertFalse(errors, errors)
        released = [r for r in results if r.get("released")]
        self.assertEqual(len(released), 1, results)
        self.assertEqual(len([r for r in results
                              if r.get("reason") == "already_claimed"]), 7)
        tickets = store.conn.execute(
            "SELECT COUNT(*) c FROM order_release WHERE order_id=?",
            (oid,)).fetchone()["c"]
        self.assertEqual(tickets, 1, "one claim row, whatever the thread count")
        deliveries = store.conn.execute(
            "SELECT COUNT(*) c FROM order_delivery WHERE order_id=?",
            (oid,)).fetchone()["c"]
        self.assertEqual(deliveries, 1)
        self.assertEqual(store.order(oid)["status"], "sent")

    def test_simultaneous_payment_webhooks_one_charge(self):
        store, oid, code, snapshot = paid_order_fixture(sink="manual")
        sms = FakeSmsSender()
        provider = DevCheckoutProvider()
        self.assertEqual(payments.arrange_payment(store, oid, sms=sms,
                                                  provider=provider),
                         "link_sent")
        outcomes, errors = [], []
        barrier = threading.Barrier(2)

        def pay(ref):
            try:
                barrier.wait()
                outcomes.append(payments.mark_paid(store, oid, ref))
            except Exception as exc:                # pragma: no cover
                errors.append(exc)

        threads = [threading.Thread(target=pay, args=(r,))
                   for r in ("ref-first", "ref-second")]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        self.assertFalse(errors, errors)
        self.assertEqual(sorted(outcomes), [False, True],
                         "first webhook wins, the replay loses")
        rows = store.conn.execute(
            "SELECT pos_payment_ref FROM payment WHERE order_id=?",
            (oid,)).fetchall()
        self.assertEqual(len(rows), 1)
        # the provider-registered reference is immutable: a late webhook
        # carrying a different ref cannot overwrite it (COALESCE guard)
        self.assertTrue(rows[0]["pos_payment_ref"].startswith("dev-"))


# ---------------------------------------------------------------------------
# 4. Idempotency: the same webhook three times in five seconds


class TestIdempotency(unittest.TestCase):
    """Same Square event replayed 3x: one charge, one release, cached replies."""

    def event(self, ref, amount):
        return {"event_id": "evt-idem-1", "type": "payment.updated",
                "data": {"object": {"payment": {
                    "id": ref, "order_id": ref, "status": "COMPLETED",
                    "amount_money": {"amount": amount, "currency": "USD"}}}}}

    def test_same_webhook_three_times(self):
        store, oid, code, snapshot = paid_order_fixture(sink="manual")
        sms = FakeSmsSender()
        provider = DevCheckoutProvider()
        payments.arrange_payment(store, oid, sms=sms, provider=provider)
        amount = snapshot["total_cents"]
        # the reference the checkout provider actually registered
        ref = payments.payment_for(store, oid)["pos_payment_ref"]
        results = [
            square_webhook.handle(store, self.event(ref, amount),
                on_paid=lambda order: payments.release_paid_order(store,
                                                                  order,
                                                                  sms=sms))
            for _ in range(3)
        ]
        self.assertEqual(results[0]["action"], "paid")
        self.assertTrue(results[0]["release"]["released"])
        for replay in results[1:]:
            self.assertNotEqual(replay["action"], "paid",
                                "a replay must not re-charge or re-release")
        charges = store.conn.execute(
            "SELECT COUNT(*) c FROM payment WHERE order_id=?", (oid,)
        ).fetchone()["c"]
        self.assertEqual(charges, 1)
        releases = store.conn.execute(
            "SELECT COUNT(*) c FROM order_release WHERE order_id=?", (oid,)
        ).fetchone()["c"]
        self.assertEqual(releases, 1)
        deliveries = store.conn.execute(
            "SELECT COUNT(*) c FROM order_delivery WHERE order_id=?", (oid,)
        ).fetchone()["c"]
        self.assertEqual(deliveries, 1)
        # one checkout link to the caller + one kitchen ticket to staff —
        # and the two replays added neither a charge, a text, nor a ticket
        self.assertEqual(len(sms.sent), 2)
        self.assertIn("revie", sms.sent[0]["body"].lower())

    def test_same_call_creates_one_session(self):
        store, oid, code, snapshot = paid_order_fixture()
        sids = {store.start_session("bun-n-run-ferndale", 1,
                                    external_id="telnyx-call-42")
                for _ in range(3)}
        self.assertEqual(len(sids), 1, "replayed telephony webhook: one call")

    def test_one_session_one_order(self):
        """Two finishes in one call cannot place two orders."""
        store, oid, code, snapshot = paid_order_fixture(with_session=True)
        sid = store.conn.execute(
            "SELECT session_id FROM \"order\" WHERE id=?", (oid,)
        ).fetchone()["session_id"]
        second_id, second_code = store.place_order(
            "bun-n-run-ferndale", 1, snapshot, session_id=sid,
            customer_phone="+13135550123")
        self.assertEqual(second_id, oid,
                         "the session's existing order is returned verbatim")
        self.assertEqual(second_code, code)
        events = store.conn.execute(
            "SELECT COUNT(*) c FROM event WHERE kind='order.duplicate_suppressed'"
        ).fetchone()["c"]
        self.assertGreaterEqual(events, 1, "the suppression is auditable")


if __name__ == "__main__":
    unittest.main(verbosity=1)
