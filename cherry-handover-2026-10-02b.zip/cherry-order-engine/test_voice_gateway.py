#!/usr/bin/env python3
"""Voice gateway contract and forwarding-loop safety tests."""

import asyncio
import json
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from types import SimpleNamespace

from pilot_deploy import Location, direct_fallback
from telnyx_voice import routes_from_manifest
from voice_gateway import Gateway, handler_for


def _loc(lid: str, inbound_env: str, published: str, *,
         fallback_env: str = "") -> Location:
    """A real Location, not a duck-typed stand-in.

    These tests used SimpleNamespace until `direct_fallback` needed the
    `fallback_env_name` property, which a namespace cannot carry — and using the
    real dataclass means the test breaks when the real thing changes, which is
    the point.
    """
    return Location(id=lid, group="g", name=lid, menu=None,
                    catalog_status="ready", inbound_env=inbound_env,
                    fallback_phone=published, pos_type="manual_fallback",
                    fallback_env=fallback_env)


class FakeBridge:
    def __init__(self):
        self.calls = []

    async def tool_schemas(self):
        return [{"name": "add_item"}]

    async def start(self, call_id, *, dialled, caller):
        self.calls.append(("start", call_id, dialled, caller))
        return "Hello"

    async def handle_tool_call(self, call_id, tool, body):
        self.calls.append(("tool", call_id, tool, body))
        return "What size?"

    async def finish(self, call_id, name):
        self.calls.append(("finish", call_id, name))
        return "Checkout link sent"

    async def abandon(self, call_id, reason):
        self.calls.append(("abandon", call_id, reason))

    async def request_handoff(self, call_id):
        self.calls.append(("handoff", call_id))
        return "Connecting now"


class GatewayTests(unittest.TestCase):
    def setUp(self):
        self.bridge = FakeBridge()
        self.gateway = Gateway(self.bridge, {"+13135550101": "+13135550102"},
                               "voice-secret")

    def dispatch(self, method, path, body=None):
        return asyncio.run(self.gateway.dispatch(method, path, body or {}))

    def test_call_and_tool_keep_telnyx_id_and_number(self):
        status, catalog = self.dispatch("GET", "/v1/voice/tools")
        self.assertEqual(status, 200)
        self.assertEqual(catalog["tools"], [{"name": "add_item"}])
        self.assertIn("Speak every tool", catalog["system_prompt"])
        status, result = self.dispatch("POST", "/v1/voice/calls", {
            "call_control_id": "v3:call/1", "to": "+13135550101",
            "from": "+13135550199"})
        self.assertEqual((status, result), (200, {"say": "Hello"}))
        status, result = self.dispatch(
            "POST", "/v1/voice/calls/v3%3Acall%2F1/tools/add_item",
            {"text": "burger"})
        self.assertEqual((status, result), (200, {"say": "What size?"}))
        self.assertEqual(self.bridge.calls[0],
                         ("start", "v3:call/1", "+13135550101", "+13135550199"))
        self.assertEqual(self.bridge.calls[1],
                         ("tool", "v3:call/1", "add_item", {"text": "burger"}))

    def test_unknown_number_is_rejected_before_call_starts(self):
        status, _ = self.dispatch("POST", "/v1/voice/calls", {
            "call_control_id": "c", "to": "+13135550999"})
        self.assertEqual(status, 400)
        self.assertEqual(self.bridge.calls, [])

    def test_checkout_finish_and_human_handoff(self):
        self.dispatch("POST", "/v1/voice/calls/c/finish",
                      {"customer_name": "Sam"})
        self.dispatch("POST", "/v1/voice/calls/c/handoff")
        self.assertEqual(self.bridge.calls,
                         [("finish", "c", "Sam"), ("handoff", "c")])

    def test_direct_fallback_rejects_public_forwarded_number(self):
        location = _loc("shop", "CHERRY_INBOUND_SHOP", "+13135550100")
        env = {"CHERRY_INBOUND_SHOP": "+13135550101",
               "CHERRY_DIRECT_FALLBACK_SHOP": "+13135550100"}
        with self.assertRaisesRegex(ValueError, "forwarding_loop"):
            direct_fallback(location, env, required=True)
        env["CHERRY_DIRECT_FALLBACK_SHOP"] = "+13135550102"
        self.assertEqual(direct_fallback(location, env, required=True),
                         "+13135550102")

    def test_direct_fallback_cannot_route_into_another_location(self):
        first = _loc("first", "CHERRY_INBOUND_FIRST", "+13135550100")
        second = _loc("second", "CHERRY_INBOUND_SECOND", "+13135550200")
        env = {"CHERRY_INBOUND_FIRST": "+13135550101",
               "CHERRY_INBOUND_SECOND": "+13135550201",
               "CHERRY_DIRECT_FALLBACK_FIRST": "+13135550201",
               "CHERRY_DIRECT_FALLBACK_SECOND": "+13135550202"}
        with self.assertRaisesRegex(ValueError, "forwarding loop"):
            routes_from_manifest([first, second], env, require_direct=True)

    def test_a_locally_named_fallback_variable_is_honoured(self):
        """The trap this guards: a location whose inbound var was named by hand.

        For tamago-sushi-bowl the inbound var is CHERRY_INBOUND_TAMAGO_HALL_RD
        while the fallback would otherwise derive to ..._TAMAGO_SUSHI_BOWL.
        Declaring `fallback_env` lets the two match; without it the published
        number is used and a transfer loops.
        """
        location = _loc("tamago-sushi-bowl", "CHERRY_INBOUND_TAMAGO_HALL_RD",
                        "+12489388095",
                        fallback_env="CHERRY_DIRECT_FALLBACK_TAMAGO_HALL_RD")
        env = {"CHERRY_INBOUND_TAMAGO_HALL_RD": "+12485550107",
               "CHERRY_DIRECT_FALLBACK_TAMAGO_HALL_RD": "+12485559907"}
        self.assertEqual(direct_fallback(location, env, required=True),
                         "+12485559907")
        # The derived name alone must NOT satisfy it any more.
        env2 = {"CHERRY_INBOUND_TAMAGO_HALL_RD": "+12485550107",
                "CHERRY_DIRECT_FALLBACK_TAMAGO_SUSHI_BOWL": "+12485559908"}
        with self.assertRaisesRegex(ValueError, "missing_env"):
            direct_fallback(location, env2, required=True)

    def test_http_rejects_missing_key_and_accepts_authorized_call(self):
        server = ThreadingHTTPServer(("127.0.0.1", 0), handler_for(self.gateway))
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            url = f"http://127.0.0.1:{server.server_address[1]}/v1/voice/calls"
            body = json.dumps({"call_control_id": "c", "to": "+13135550101"}).encode()
            with self.assertRaises(urllib.error.HTTPError) as denied:
                urllib.request.urlopen(urllib.request.Request(
                    url, data=body, headers={"Content-Type": "application/json"}),
                    timeout=2)
            self.assertEqual(denied.exception.code, 401)
            request = urllib.request.Request(
                url, data=body,
                headers={"Content-Type": "application/json",
                         "X-Voice-Key": "voice-secret"})
            with urllib.request.urlopen(request, timeout=2) as response:
                self.assertEqual(json.load(response), {"say": "Hello"})
        finally:
            server.shutdown()
            server.server_close()


if __name__ == "__main__":
    unittest.main()
