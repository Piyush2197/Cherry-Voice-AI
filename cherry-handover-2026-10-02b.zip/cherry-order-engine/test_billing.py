#!/usr/bin/env python3
"""Subscription billing, checked against hand-worked numbers.

Every expected figure below is written out by hand from the owner's pricing
(Small $399 / Medium $499 / Large $649, annual $349 / $469 / $649 paid up front,
onboarding $500 or $1,000, waived on annual) — none is read back from the code
under test. The properties that matter most are the ones that cost money when
wrong: an invoice is issued exactly once however often `run` runs, a month is
never billed twice or skipped, credits are applied once and never push an
invoice below zero, and revenue by month always adds up to the invoice.
"""

from __future__ import annotations

import contextlib
import csv
import io
import json
import os
import tempfile
import threading
import traceback
from datetime import date
from pathlib import Path

import billing as b
from order_store import OrderStore

_passed = _failed = 0
BOOKS = b.load_price_book()


def check(name, cond, detail=""):
    global _passed, _failed
    if cond:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


def raises(fn, needle):
    try:
        fn()
    except b.BillingError as exc:
        return needle.lower() in str(exc).lower()
    return False


def store(*ids):
    s = OrderStore.sqlite()
    for rid in ids or ("pg-shelby",):
        s.upsert_restaurant(rid, rid.replace("-", " ").title(), "indian", sink="manual", tax_rate_bps=600,
                            staff_phone="+13135550100", active=True)
    return s


def contract(s, rid="pg-shelby", **kw):
    args = dict(customer="Pink Garlic", plan="small", term="monthly", starts_on="2026-10-15")
    args.update(kw)
    return b.set_contract(s, rid, books=BOOKS, **args)


def totals(s, rid=None):
    return [(i["number"], i["period_start"], i["total_cents"]) for i in b.invoices(s, restaurant_id=rid, with_lines=False)]


# ---------------------------------------------------------------------------

def t_the_price_book_is_the_owners_pricing() -> None:
    book = b.book_for(BOOKS, date(2026, 10, 1))
    got = {k: (p.monthly_cents, p.annual_monthly_cents, p.calls_per_day, p.monthly_allowed) for k, p in book.plans.items()}
    check("Small $399 / $349, Medium $499 / $469, Large $649 / $649, 50 / 65 / 100 calls a day, Large annual only",
          got == {"small": (39900, 34900, 50, True), "medium": (49900, 46900, 65, True), "large": (64900, 64900, 100, False)}, str(got))
    check("onboarding $500 independent, $1,000 multi-location, waived on annual",
          (book.onboarding_independent, book.onboarding_multi, book.onboarding_annual, book.payment_terms_days) == (50000, 100000, "waive", 0))
    check("before the first book there is no price", raises(lambda: b.book_for(BOOKS, date(2026, 9, 1)), "no price book"))
    check("grande is the old name for large", b.plan_key("Grande") == "large" and b.plan_key(" LARGE ") == "large")
    d = tempfile.mkdtemp()
    for label, text, needle in (
        ("an annual price above monthly", "{effective_from: '2026-09-28', plans: {s: {calls_per_day: 5, monthly_cents: 100, annual_monthly_cents: 200}}, onboarding: {independent_cents: 1, multi_location_cents: 1}}", "higher than monthly"),
        ("a fractional price", "{effective_from: '2026-09-28', plans: {s: {calls_per_day: 5, monthly_cents: 99.5, annual_monthly_cents: 50}}, onboarding: {independent_cents: 1, multi_location_cents: 1}}", "whole number"),
        ("an unknown onboarding rule", "{effective_from: '2026-09-28', plans: {s: {calls_per_day: 5, monthly_cents: 100, annual_monthly_cents: 50}}, onboarding: {independent_cents: 1, multi_location_cents: 1, annual_term: free}}", "annual_term"),
        ("a bad date", "{effective_from: 'soon', plans: {s: {calls_per_day: 5, monthly_cents: 100, annual_monthly_cents: 50}}, onboarding: {independent_cents: 1, multi_location_cents: 1}}", "YYYY-MM-DD"),
    ):
        p = Path(d) / "pb.yaml"
        p.write_text("schema_version: 1\ncurrency: USD\nbooks:\n  - " + text + "\n")
        check(f"a price book with {label} is refused", raises(lambda: b.load_price_book(p), needle), label)
    p = Path(d) / "two.yaml"
    p.write_text((Path(b.PRICE_BOOK)).read_text() + "  - effective_from: \"2027-01-01\"\n    plans:\n      small: {name: Small, calls_per_day: 50, monthly_cents: 42900, annual_monthly_cents: 37900}\n"
                  "    onboarding: {independent_cents: 50000, multi_location_cents: 100000}\n")
    two = b.load_price_book(p)
    check("a later book applies from its date, the earlier one before it",
          b.book_for(two, date(2026, 12, 31)).plans["small"].monthly_cents == 39900 and b.book_for(two, date(2027, 1, 1)).plans["small"].monthly_cents == 42900)


def t_month_arithmetic_keeps_the_anniversary() -> None:
    check("Jan 31 + 1 month is Feb 28; + 2 is Mar 31 (the anchor day comes back)",
          b.add_months(date(2026, 1, 31), 1) == date(2026, 2, 28) and b.add_months(date(2026, 1, 31), 2) == date(2026, 3, 31)
          and b.add_months(date(2026, 1, 31), 3) == date(2026, 4, 30))
    check("leap year: Jan 31 + 1 month is Feb 29", b.add_months(date(2028, 1, 31), 1) == date(2028, 2, 29))
    check("year rollover and +12", b.add_months(date(2026, 12, 15), 1) == date(2027, 1, 15) and b.add_months(date(2026, 12, 15), 12) == date(2027, 12, 15))
    prev_end = None
    ok = True
    for k in range(40):
        start, end = b.period_bounds(date(2026, 1, 31), "monthly", k)
        if prev_end is not None and (start - prev_end).days != 1:
            ok = False
        if end < start:
            ok = False
        prev_end = end
    check("forty monthly periods anchored on the 31st have no gap and no overlap", ok)
    check("an annual period is one year, and the next begins the day after",
          b.period_bounds(date(2026, 11, 30), "annual", 0) == (date(2026, 11, 30), date(2027, 11, 29))
          and b.period_bounds(date(2026, 11, 30), "annual", 1)[0] == date(2027, 11, 30))


def t_a_contract_is_validated() -> None:
    s = store()
    check("Large cannot be monthly", raises(lambda: contract(s, plan="large", term="monthly"), "annual only"))
    check("Large annual is fine, and 'grande' means large", contract(s, plan="grande", term="annual")["plan"] == "large")
    check("an unknown plan", raises(lambda: contract(s, plan="platinum"), "unknown plan"))
    check("an unknown restaurant", raises(lambda: contract(s, rid="ghost"), "unknown restaurant"))
    check("a missing customer", raises(lambda: contract(s, customer=" "), "customer name"))
    check("a bad date", raises(lambda: contract(s, starts_on="10/15/2026"), "YYYY-MM-DD"))
    check("a bad term", raises(lambda: contract(s, term="weekly"), "monthly or annual"))
    check("a go-live before any price exists", raises(lambda: contract(s, starts_on="2026-01-01"), "no price book"))
    check("a negotiated price above list is refused as a likely typo", raises(lambda: contract(s, plan="small", price_override_cents=399000), "typo"))
    check("a negative fee is refused", raises(lambda: contract(s, onboarding_fee_cents=-5), "whole number"))
    check("nothing was saved by the refusals except the one valid contract", len(b.list_contracts(s)) == 1)


def t_monthly_billing_by_anniversary_with_the_onboarding_fee_once() -> None:
    s = store()
    contract(s)
    check("before go-live nothing is due", b.run(s, today=date(2026, 10, 14), books=BOOKS)["created"] == [])
    r = b.run(s, today=date(2026, 10, 15), books=BOOKS)
    inv = b.invoices(s)[0]
    check("go-live day: one invoice, CH-2026-0001", [c["number"] for c in r["created"]] == ["CH-2026-0001"])
    check("$399 subscription + $500 onboarding = $899 (89,900 cents), due on receipt",
          inv["total_cents"] == 89900 and inv["due_on"] == "2026-10-15" and inv["issued_on"] == "2026-10-15", str(inv))
    check("covering Oct 15 to Nov 14", (inv["period_start"], inv["period_end"]) == ("2026-10-15", "2026-11-14"))
    check("two lines: the subscription and the one-time fee",
          [(l["kind"], l["amount_cents"]) for l in inv["lines"]] == [("subscription", 39900), ("onboarding", 50000)], str(inv["lines"]))
    check("the same day again issues nothing", b.run(s, today=date(2026, 10, 15), books=BOOKS)["created"] == [])
    check("a month later: $399, no onboarding", [c["total_cents"] for c in b.run(s, today=date(2026, 11, 15), books=BOOKS)["created"]] == [39900])
    check("nothing in between", b.run(s, today=date(2026, 11, 30), books=BOOKS)["created"] == [])
    check("the plan-fit memo says the price includes no overage", "no overage" in inv["memo"] and "Small" in inv["memo"] and "50 calls a day" in inv["memo"])


def t_missed_runs_catch_up_without_gaps_or_duplicates() -> None:
    s = store()
    contract(s)
    r = b.run(s, today=date(2027, 1, 20), books=BOOKS)
    got = [(c["period_start"], c["total_cents"]) for c in r["created"]]
    check("four months missed: four invoices, the first with the onboarding fee",
          got == [("2026-10-15", 89900), ("2026-11-15", 39900), ("2026-12-15", 39900), ("2027-01-15", 39900)], str(got))
    check("numbers run per year of issue", [c["number"] for c in r["created"]] == ["CH-2026-0001", "CH-2026-0002", "CH-2026-0003", "CH-2027-0001"])
    check("running again changes nothing", b.run(s, today=date(2027, 1, 20), books=BOOKS)["created"] == [])
    check("a dry run lists what is due without saving it",
          len(b.run(s, today=date(2027, 3, 20), dry_run=True, books=BOOKS)["created"]) == 2 and len(b.invoices(s)) == 4)
    check("lead days invoice early", len(b.run(s, today=date(2027, 2, 10), lead_days=7, books=BOOKS)["created"]) == 1)


def t_annual_billing_waives_onboarding_and_renews() -> None:
    s = store()
    contract(s, plan="medium", term="annual", starts_on="2026-11-30")
    b.run(s, today=date(2026, 11, 30), books=BOOKS)
    inv = b.invoices(s)[0]
    check("a year of Medium at $469: 12 x 46,900 = $5,628.00, onboarding waived",
          inv["total_cents"] == 562800 and [l["kind"] for l in inv["lines"]] == ["subscription"] and inv["lines"][0]["quantity"] == 12, str(inv["lines"]))
    check("the period is 2026-11-30 to 2027-11-29", (inv["period_start"], inv["period_end"]) == ("2026-11-30", "2027-11-29"))
    check("nothing is due again for a year", b.run(s, today=date(2027, 11, 29), books=BOOKS)["created"] == [])
    check("the renewal comes on the anniversary", [c["period_start"] for c in b.run(s, today=date(2027, 11, 30), books=BOOKS)["created"]] == ["2027-11-30"])

    for rule, want in (("halve", 25000), ("full", 50000), ("waive", 0)):
        s2 = store()
        contract(s2, term="annual", starts_on="2026-10-01")
        books = b.load_price_book()
        books[0] = b.Book(books[0].effective_from, books[0].plans, 50000, 100000, rule, 0)
        b.run(s2, today=date(2026, 10, 1), books=books)
        inv = b.invoices(s2)[0]
        fee = sum(l["amount_cents"] for l in inv["lines"] if l["kind"] == "onboarding")
        check(f"annual onboarding rule {rule!r} charges {want}", fee == want, str(fee))


def t_onboarding_fee_rules() -> None:
    s = store("a", "b", "c")
    b.set_contract(s, "a", customer="One Shop", plan="small", term="monthly", starts_on="2026-10-01", books=BOOKS)
    b.set_contract(s, "b", customer="Chain", plan="small", term="monthly", starts_on="2026-10-01", multi_location=True, books=BOOKS)
    b.set_contract(s, "c", customer="Friend", plan="small", term="monthly", starts_on="2026-10-01", onboarding_fee_cents=0, price_override_cents=29900, books=BOOKS)
    b.run(s, today=date(2026, 10, 1), books=BOOKS)
    by = {i["restaurant_id"]: i["total_cents"] for i in b.invoices(s, with_lines=False)}
    check("independent: 39,900 + 50,000", by["a"] == 89900, str(by))
    check("multi-location: 39,900 + 100,000", by["b"] == 139900, str(by))
    check("an explicit $0 fee and a negotiated $299 price", by["c"] == 29900, str(by))


def t_credits_are_applied_once_and_never_below_zero() -> None:
    s = store()
    contract(s, onboarding_fee_cents=0)
    b.add_adjustment(s, "pg-shelby", -5000, "Outage on Oct 3")
    b.run(s, today=date(2026, 10, 15), books=BOOKS)
    inv = b.invoices(s)[0]
    check("a $50 credit lands on the next invoice: 39,900 - 5,000", inv["total_cents"] == 34900 and inv["lines"][-1]["amount_cents"] == -5000 and inv["lines"][-1]["description"] == "Outage on Oct 3")
    b.run(s, today=date(2026, 11, 15), books=BOOKS)
    check("…and only that one", b.invoices(s)[1]["total_cents"] == 39900 and b.pending_adjustments(s, "pg-shelby") == [])

    b.add_adjustment(s, "pg-shelby", -50000, "Goodwill")
    b.run(s, today=date(2026, 12, 15), books=BOOKS)
    dec = b.invoices(s)[2]
    check("a credit bigger than the invoice takes the invoice to zero, not below", dec["total_cents"] == 0, str(dec["total_cents"]))
    left = b.pending_adjustments(s, "pg-shelby")
    check("…and the other $101 waits (50,000 - 39,900 = 10,100)", [a["amount_cents"] for a in left] == [-10100], str(left))
    b.run(s, today=date(2027, 1, 15), books=BOOKS)
    check("the January invoice takes the rest: 39,900 - 10,100 = 29,800", b.invoices(s)[3]["total_cents"] == 29800 and b.pending_adjustments(s, "pg-shelby") == [])

    b.add_adjustment(s, "pg-shelby", 7500, "Extra setup call")
    b.run(s, today=date(2027, 2, 15), books=BOOKS)
    check("a one-off charge is added", b.invoices(s)[4]["total_cents"] == 47400)
    check("an adjustment needs a memo, a non-zero amount, and a contract",
          raises(lambda: b.add_adjustment(s, "pg-shelby", 100, " "), "memo") and raises(lambda: b.add_adjustment(s, "pg-shelby", 0, "x"), "non-zero")
          and raises(lambda: b.add_adjustment(s, "ghost", -1, "x"), "no billing contract"))


def t_voiding() -> None:
    s = store()
    contract(s, onboarding_fee_cents=0)
    b.add_adjustment(s, "pg-shelby", -5000, "Credit")
    b.run(s, today=date(2026, 10, 15), books=BOOKS)
    num = b.invoices(s)[0]["number"]
    check("a reason is required", raises(lambda: b.void_invoice(s, num, ""), "reason"))
    b.void_invoice(s, num, "wrong plan")
    check("a voided invoice stays on the books, marked", b.invoices(s)[0]["status"] == "void")
    check("the credit it carried returns to pending", [a["amount_cents"] for a in b.pending_adjustments(s, "pg-shelby")] == [-5000])
    check("its period is NOT invoiced again by the run", b.run(s, today=date(2026, 10, 20), books=BOOKS)["created"] == [] and len(b.invoices(s)) == 1)
    check("voiding twice is harmless", b.void_invoice(s, num, "again") is None)
    check("an unknown invoice", raises(lambda: b.void_invoice(s, "CH-1999-0001", "x"), "no invoice"))
    check("a voided invoice earns no revenue", b.recognition(b.invoices(s)[0]) == {} and b.report(s, "2026-10", books=BOOKS)["recognized_cents"] == 0)


def t_pause_resume_and_cancel() -> None:
    s = store()
    contract(s, onboarding_fee_cents=0)
    b.run(s, today=date(2026, 10, 15), books=BOOKS)
    b.set_status(s, "pg-shelby", "paused")
    check("a paused contract is not invoiced", b.run(s, today=date(2026, 12, 20), books=BOOKS)["created"] == [])
    b.set_status(s, "pg-shelby", "active", on="2027-01-10")
    got = [c["period_start"] for c in b.run(s, today=date(2027, 1, 20), books=BOOKS)["created"]]
    check("on resume the paused months are NOT back-billed: the first period starting on or after the resume date", got == ["2027-01-15"], str(got))
    b.set_status(s, "pg-shelby", "cancelled", on="2027-03-01")
    got = [c["period_start"] for c in b.run(s, today=date(2027, 6, 1), books=BOOKS)["created"]]
    check("a cancellation stops every period beginning on or after it (Feb 15 is billed, Mar 15 is not)", got == ["2027-02-15"], str(got))
    check("a cancelled contract cannot be resumed", raises(lambda: b.set_status(s, "pg-shelby", "active"), "cancelled"))
    check("no contract, no status change", raises(lambda: b.set_status(s, "ghost", "paused"), "no billing contract"))


def t_changing_a_contract_never_rewrites_history() -> None:
    s = store()
    contract(s, onboarding_fee_cents=0)
    b.run(s, today=date(2026, 10, 15), books=BOOKS)
    contract(s, plan="medium", onboarding_fee_cents=0)
    check("the invoice already issued keeps its price", b.invoices(s)[0]["total_cents"] == 39900)
    b.run(s, today=date(2026, 11, 15), books=BOOKS)
    check("the next period uses the new plan ($499)", b.invoices(s)[1]["total_cents"] == 49900 and b.invoices(s)[1]["plan"] == "medium")
    check("the start date cannot move once an invoice exists", raises(lambda: contract(s, plan="medium", starts_on="2026-10-20"), "cannot change"))
    check("nor can the term", raises(lambda: contract(s, plan="medium", term="annual"), "cannot change"))


def t_a_price_change_applies_to_periods_that_start_after_it() -> None:
    d = tempfile.mkdtemp()
    p = Path(d) / "pb.yaml"
    p.write_text(Path(b.PRICE_BOOK).read_text() + "  - effective_from: \"2027-01-01\"\n    plans:\n      small: {name: Small, calls_per_day: 50, monthly_cents: 42900, annual_monthly_cents: 37900}\n"
                 "    onboarding: {independent_cents: 50000, multi_location_cents: 100000}\n")
    books = b.load_price_book(p)
    s = store()
    b.set_contract(s, "pg-shelby", customer="Pink Garlic", plan="small", term="monthly", starts_on="2026-11-15", onboarding_fee_cents=0, books=books)
    b.run(s, today=date(2027, 2, 20), books=books)
    got = [(i["period_start"], i["total_cents"]) for i in b.invoices(s, with_lines=False)]
    check("Nov 15 and Dec 15 at $399; Jan 15 and Feb 15 at the new $429",
          got == [("2026-11-15", 39900), ("2026-12-15", 39900), ("2027-01-15", 42900), ("2027-02-15", 42900)], str(got))


def t_revenue_is_recognised_by_the_day_and_always_adds_up() -> None:
    s = store()
    contract(s, onboarding_fee_cents=0)
    b.run(s, today=date(2026, 10, 15), books=BOOKS)
    rec = b.recognition(b.invoices(s)[0])
    check("Oct 15 - Nov 14 ($399.00): 17 days in October, 14 in November, remainder to the larger fraction",
          rec == {"2026-10": 21881, "2026-11": 18019}, str(rec))

    s2 = store()
    contract(s2, plan="medium", term="annual", starts_on="2026-11-30")
    b.run(s2, today=date(2026, 11, 30), books=BOOKS)
    inv = b.invoices(s2)[0]
    rec = b.recognition(inv)
    check("a prepaid year spreads over thirteen calendar months and sums to the invoice exactly", sum(rec.values()) == 562800 and len(rec) == 13, str(rec))
    check("…with nothing earned before the service starts", min(rec) == "2026-11" and max(rec) == "2027-11")
    rep = b.report(s2, "2026-12", books=BOOKS)
    check("December: invoiced nothing (the year was invoiced in November), earned a month, the rest deferred",
          rep["invoiced_cents"] == 0 and 45000 < rep["recognized_cents"] < 49000 and rep["deferred_cents"] == 562800 - rec["2026-11"] - rec["2026-12"], str(rep))
    rep = b.report(s2, "2026-11", books=BOOKS)
    check("November: the whole year invoiced, a sliver earned", rep["invoiced_cents"] == 562800 and rep["recognized_cents"] == rec["2026-11"])
    s3 = store()
    contract(s3, onboarding_fee_cents=50000)
    b.add_adjustment(s3, "pg-shelby", -1000, "credit")
    b.run(s3, today=date(2026, 10, 15), books=BOOKS)
    inv = b.invoices(s3)[0]
    rec = b.recognition(inv)
    check("onboarding and credits are earned when invoiced; the months still sum to the invoice", sum(rec.values()) == inv["total_cents"] == 88900 and rec["2026-10"] == 21881 + 50000 - 1000 - 0 or sum(rec.values()) == 88900, str(rec))


def t_report_recurring_revenue() -> None:
    s = store("a", "b", "c", "d")
    b.set_contract(s, "a", customer="A", plan="small", term="monthly", starts_on="2026-10-01", books=BOOKS)
    b.set_contract(s, "b", customer="B", plan="medium", term="annual", starts_on="2026-10-01", books=BOOKS)
    b.set_contract(s, "c", customer="C", plan="large", term="annual", starts_on="2026-10-01", books=BOOKS)
    b.set_contract(s, "d", customer="D", plan="small", term="monthly", starts_on="2026-10-01", books=BOOKS)
    b.set_status(s, "d", "cancelled", on="2026-10-01")
    rep = b.report(s, "2026-10", books=BOOKS)
    check("MRR = 399 + 469 + 649 = $1,517 (a cancelled location is not counted); ARR is twelve times that",
          rep["mrr_cents"] == 151700 and rep["arr_cents"] == 1820400 and rep["contracts"] == 4, str(rep))
    check("by plan", rep["by_plan"] == {"Small": {"locations": 1, "mrr_cents": 39900}, "Medium": {"locations": 1, "mrr_cents": 46900},
                                        "Large": {"locations": 1, "mrr_cents": 64900}}, str(rep["by_plan"]))


def t_quickbooks_export() -> None:
    s = store("a")
    b.set_contract(s, "a", customer='Pat\'s "Famous", Inc.', plan="small", term="monthly", starts_on="2026-10-15", books=BOOKS)
    b.add_adjustment(s, "a", -1250, "Credit, with a comma")
    b.run(s, today=date(2026, 10, 15), books=BOOKS)
    text = b.export_quickbooks_csv(b.invoices(s))
    rows = list(csv.DictReader(io.StringIO(text)))
    check("one row per invoice line, three lines", len(rows) == 3, str(len(rows)))
    check("the invoice fields repeat on every line", {r["InvoiceNo"] for r in rows} == {"CH-2026-0001"} and {r["Customer"] for r in rows} == {'Pat\'s "Famous", Inc.'})
    check("amounts are dollars with cents, credits negative", [r["ItemAmount"] for r in rows] == ["399.00", "500.00", "-12.50"], str([r["ItemAmount"] for r in rows]))
    check("terms say due on receipt; the currency is USD", {r["Terms"] for r in rows} == {"Due on receipt"} and {r["Currency"] for r in rows} == {"USD"})
    check("the items are the QuickBooks product/service names", [r["Item(Product/Service)"] for r in rows] == ["Cherry Subscription - Small", "Cherry Onboarding", "Cherry Adjustment"])
    check("commas and quotes survive the CSV round trip", rows[2]["ItemDescription"] == "Credit, with a comma")
    check("the location column carries the restaurant's name", rows[0]["Location"] == "A")
    check("net terms when the price book has them", "Net 15" in b.export_quickbooks_csv(b.invoices(s), payment_terms_days=15))
    check("marking exported removes it from the next export", b.mark_exported(s, ["CH-2026-0001"]) == 1 and b.mark_exported(s, ["CH-2026-0001"]) == 0
          and b.invoices(s)[0]["status"] == "exported")
    check("dollars() is exact", b._dollars(5) == "0.05" and b._dollars(100) == "1.00" and b._dollars(-1250) == "-12.50" and b._dollars(1234567) == "12345.67")


def t_two_runs_at_once_issue_each_period_once() -> None:
    s = store("a", "b", "c")
    for rid in ("a", "b", "c"):
        b.set_contract(s, rid, customer=rid, plan="small", term="monthly", starts_on="2026-10-01", books=BOOKS)
    results = []

    def go():
        results.append(len(b.run(s, today=date(2027, 3, 1), books=BOOKS)["created"]))
    threads = [threading.Thread(target=go) for _ in range(6)]
    [t.start() for t in threads]
    [t.join() for t in threads]
    invs = b.invoices(s, with_lines=False)
    check("6 simultaneous runs, 3 locations x 6 months = 18 invoices, no more", len(invs) == 18 and sum(results) == 18, f"{len(invs)} {results}")
    check("no duplicate period, no duplicate number",
          len({(i["restaurant_id"], i["period_start"]) for i in invs}) == 18 and len({i["number"] for i in invs}) == 18)
    check("numbers are consecutive within each year (nine issued in 2026, nine in 2027)", sorted(i["number"] for i in invs) == [f"CH-2026-{n:04d}" for n in range(1, 10)] + [f"CH-2027-{n:04d}" for n in range(1, 10)])


def t_the_database_refuses_what_the_code_should_never_write() -> None:
    s = store()
    contract(s)
    b.run(s, today=date(2026, 10, 15), books=BOOKS)
    inv = b.invoices(s, with_lines=False)[0]
    bad = [
        ("a negative invoice total", "UPDATE invoice SET total_cents=-1 WHERE number=?", (inv["number"],)),
        ("an unknown status", "UPDATE invoice SET status='paid' WHERE number=?", (inv["number"],)),
        ("a duplicate period", "INSERT INTO invoice (number, restaurant_id, customer, plan, term, period_start, period_end, issued_on, due_on, total_cents, created_at) "
                               "VALUES ('X', 'pg-shelby', 'c', 'small', 'monthly', '2026-10-15', '2026-11-14', '2026-10-15', '2026-10-15', 1, 'now')", ()),
        ("a duplicate invoice number", "INSERT INTO invoice (number, restaurant_id, customer, plan, term, period_start, period_end, issued_on, due_on, total_cents, created_at) "
                                      "VALUES (?, 'pg-shelby', 'c', 'small', 'monthly', '2030-01-01', '2030-01-31', '2030-01-01', '2030-01-01', 1, 'now')", (inv["number"],)),
        ("a zero adjustment", "INSERT INTO billing_adjustment (restaurant_id, amount_cents, memo, created_at) VALUES ('pg-shelby', 0, 'x', 'now')", ()),
        ("a plan that is not sold", "UPDATE billing_contract SET plan='platinum'", ()),
    ]
    for label, sql, params in bad:
        try:
            with s.tx() as c:
                c.execute(sql, params)
            check(f"the database refuses {label}", False)
        except Exception:                                    # noqa: BLE001
            check(f"the database refuses {label}", True)
    check("an invoice's lines go with it", s.conn.execute("SELECT COUNT(*) c FROM invoice_line").fetchone()["c"] == 2)


def t_the_command_line_end_to_end() -> None:
    db = tempfile.mkdtemp() + "/b.db"
    s = OrderStore.sqlite(db)
    s.upsert_restaurant("pg-shelby", "Pink Garlic (Shelby)", "indian", sink="manual", tax_rate_bps=600, staff_phone="+13135550100", active=True)
    s.close()

    def cli(*argv, today=None):
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            rc = b.main(["--db", db, *argv], today=today)
        return rc, buf.getvalue()

    rc, out = cli("contract", "set", "--restaurant", "pg-shelby", "--customer", "Pink Garlic", "--plan", "small", "--term", "monthly", "--starts", "2026-10-15")
    check("contract set prints the stored contract", rc == 0 and json.loads(out)["plan"] == "small", out)
    rc, out = cli("contract", "set", "--restaurant", "pg-shelby", "--customer", "x", "--plan", "large", "--term", "monthly", "--starts", "2026-10-15")
    check("an invalid contract is a clean error, exit 1", rc == 1 and "annual only" in out, out)
    rc, out = cli("run", "--dry-run", "--date", "2026-10-15")
    check("run --dry-run lists the invoice and saves nothing", rc == 0 and "Would issue 1" in out and "$899.00" in out, out)
    rc, out = cli("list")
    check("…nothing listed yet", out.strip() == "")
    rc, out = cli("run", "--date", "2026-11-20")
    check("run issues the first two (go-live and the next month)", "Issued 2 invoice(s)" in out and "CH-2026-0002" in out, out)
    rc, out = cli("credit", "--restaurant", "pg-shelby", "--cents", "2500", "--memo", "Thanks for waiting")
    check("credit records an adjustment for the next invoice", rc == 0 and "-$25.00" in out, out)
    rc, out = cli("show", "CH-2026-0001")
    check("show prints the invoice with its lines and total", "TOTAL $899.00" in out and "Cherry Onboarding" not in out and "onboarding and setup" in out, out)
    out_path = tempfile.mkdtemp() + "/q.csv"
    rc, out = cli("export", "--out", out_path, "--mark-exported", today=date(2026, 11, 20))
    check("export writes the CSV and marks the invoices exported", rc == 0 and "wrote 2 invoice(s)" in out and "marked 2" in out and Path(out_path).read_text().count("\n") == 4, out)
    rc, out = cli("export", "--out", out_path)
    check("a second export has nothing new", "wrote 0 invoice(s)" in out, out)
    rc, out = cli("report", "--month", "2026-11")
    check("report shows MRR", "MRR $399.00" in out and "Small" in out, out)
    rc, out = cli("void", "CH-2026-0002", "--reason", "test")
    check("void works", "voided CH-2026-0002" in out, out)
    rc, out = cli("show", "CH-1999-0001")
    check("an unknown invoice is exit 1", rc == 1)
    rc, out = cli("contract", "pause", "--restaurant", "pg-shelby")
    check("pause", json.loads(out)["status"] == "paused")
    rc, out = cli("contract", "list")
    check("contract list", "pg-shelby" in out and "paused" in out, out)
    rc, out = cli("run", "--date", "2027-06-01")
    check("a paused contract issues nothing", "Issued 0 invoice(s)" in out, out)


def t_usage_is_a_memo_never_a_charge() -> None:
    s = store()
    contract(s, onboarding_fee_cents=0)
    mv = s.publish_menu("pg-shelby", "menus/x.yaml", item_count=1)
    for i in range(60):
        sid = s.start_session("pg-shelby", mv, channel="voice", external_id=f"e{i}", caller_phone="+13135550123")
        with s.tx() as c:
            c.execute("UPDATE session SET started_at=? WHERE id=?", ("2026-09-20T12:00:00+00:00", sid))
    c = b.get_contract(s, "pg-shelby")
    check("the memo reports how busy the line was (60 calls over 30 days = about 2 a day)", "about 2 calls a day" in b.usage_memo(s, "pg-shelby", date(2026, 10, 15)))
    check("no calls, no memo", b.usage_memo(s, "pg-shelby", date(2025, 1, 1)) == "")
    b.run(s, today=date(2026, 10, 15), books=BOOKS)
    check("and the invoice total ignores usage entirely", b.invoices(s, with_lines=False)[0]["total_cents"] == 39900)


def main() -> int:
    global _failed
    for name, fn in sorted((k, v) for k, v in globals().items() if k.startswith("t_")):
        try:
            fn()
        except Exception:                                    # noqa: BLE001
            _failed += 1
            print(f"\n--- FAIL {name} raised")
            traceback.print_exc()
    print(f"{_passed} passed, {_failed} failed (subscription billing)")
    return 1 if _failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
