# Cherry production database runbook

## What is complete

- One repository supports SQLite locally and PostgreSQL in production.
- PostgreSQL connections come from a bounded `psycopg_pool` pool.
- The production schema is repeatable and preserves immutable order contents,
  exact menu versions, transcripts, delivery acknowledgements, payment state,
  messages and audit events.
- Schema version 1 is recorded in `schema_migration`, providing the baseline
  for future forward-only migration files.
- JSONB values are adapted correctly while SQLite continues to use JSON text.
- The server, deployment commands, smoke checks, readiness report and
  operations feed accept `CHERRY_DATABASE_URL`.
- Backup archives are created with owner-only permissions and a SHA-256 hash.
- Restore drills refuse to touch a database unless its name contains `restore`
  or `drill` and the operator supplies `--confirm-target`.
- Database URLs come only from environment variables; no credential belongs in
  this repository or in a command-line argument.

## First production setup

```bash
pip install -r requirements-postgres.txt
export CHERRY_DATABASE_URL='postgresql://...'
python3 production_db.py bootstrap
python3 production_db.py verify
```

`bootstrap` is idempotent. Run it for a new database and again during a deploy;
it will not erase existing records. `verify` checks every required table, the
immutable-order trigger and basic record counts.

Start Cherry without putting the URL on the command line:

```bash
export CHERRY_API_KEY='...'
python3 server.py --key "$CHERRY_API_KEY"
```

## Backup

Use the managed provider's point-in-time recovery as the primary protection.
Also create a portable custom-format archive:

```bash
python3 production_db.py backup --out backups/cherry-$(date +%F).dump
```

The command refuses to overwrite an archive unless `--overwrite` is explicit.
Store the archive outside the application host with encryption and restricted
access.

## Restoration drill

Create a separate disposable database. Its name must contain `restore` or
`drill`; never use the production database as the target.

```bash
export CHERRY_RESTORE_DATABASE_URL='postgresql://.../cherry_restore_drill'
python3 production_db.py restore-drill \
  --archive backups/cherry-YYYY-MM-DD.dump \
  --confirm-target
```

The drill cleans only that explicitly named target, restores the archive, then
verifies all tables and the immutable-order trigger. Record the duration and
repeat quarterly and after material schema changes.

## Testing against a real PostgreSQL

The store, sink, payment and HTTP suites also run against a real database
(this found bugs SQLite could not: `pg_restore` needed `--dbname`, and UUID
and timestamp columns must come back as strings because `server.py` returns
rows as JSON). Use a throwaway database whose name contains `test`:

```bash
createdb cherry_test
CHERRY_TEST_POSTGRES_URL=postgresql://localhost/cherry_test python3 test_postgres_live.py
```

The run drops the `public` schema each time and refuses any database whose
name lacks `test`. It includes 20 simultaneous callers.

## Still deployment-owned

- Create the managed PostgreSQL instance in the selected cloud account.
- Put `CHERRY_DATABASE_URL` in the deployment secret manager.
- Enable encrypted storage, point-in-time recovery and provider monitoring.
- Run the first real backup and restoration drill.
- Approve transcript, customer-contact and audit retention periods.
- Decide whether approved call recordings live at the voice provider and for
  how long; Cherry should store only the provider reference.
