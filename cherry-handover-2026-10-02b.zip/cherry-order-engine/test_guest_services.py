#!/usr/bin/env python3
from datetime import datetime,timedelta,timezone
import guest_services as gs
from order_store import OrderStore

def main():
    s=OrderStore.sqlite();s.upsert_restaurant("r","R","test")
    future=(datetime.now(timezone.utc)+timedelta(days=2)).isoformat()
    rid=gs.create_reservation(s,"r",guest_name="Guest",guest_phone="+13135550123",party_size=4,reserved_at=future)
    gs.update_reservation(s,rid,"confirmed")
    assert s.conn.execute("SELECT status FROM reservation WHERE id=?",(rid,)).fetchone()["status"]=="confirmed"
    assert gs.get_reservation_policy(s,"r")["enabled"] is False
    try:
        gs.request_phone_reservation(s,"r",guest_name="Guest",guest_phone="+13135550123",party_size=4,reserved_at=future)
        raise AssertionError("disabled reservations accepted")
    except PermissionError: pass
    policy=gs.set_reservation_policy(s,"r",enabled=True,max_party_size=6,min_notice_minutes=30,max_advance_days=30)
    assert policy["enabled"] and policy["max_party_size"]==6
    request=gs.request_phone_reservation(s,"r",guest_name="Guest",guest_phone="+13135550123",party_size=4,reserved_at=future)
    assert len(request["confirmation_code"])==8 and request["status"]=="requested"
    cancelled=gs.cancel_phone_reservation(s,"r",confirmation_code=request["confirmation_code"],guest_phone="+13135550123")
    assert cancelled["status"]=="cancelled"
    try:
        gs.update_reservation(s,request["reservation_id"],"confirmed")
        raise AssertionError("terminal reservation changed")
    except ValueError: pass
    class P:
        def quote(self,r,a):return gs.DeliveryQuote(True,399,35)
    q=gs.quote_delivery(s,"r",gs.Address("1 Main","Detroit","MI","48201"),P())
    assert q.deliverable and q.fee_cents==399
    assert s.events("delivery.quoted",restaurant_id="r")
    print("9 passed, 0 failed (guest services)");return 0
if __name__=="__main__":raise SystemExit(main())
