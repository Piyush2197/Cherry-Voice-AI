#!/usr/bin/env python3
"""The shipped nginx config must expose exactly what a provider, the voice
worker or a restaurant tablet needs — and nothing else.

There is no nginx on a developer machine, so this reads `deploy/nginx/cherry.conf`
and applies nginx's own matching order (exact `=`, then regex in file order,
then the longest prefix; the catch-all `location /` is a prefix). It cannot
replace `nginx -t` on the server, but it catches the failure that actually
happened: a route the code serves that the config answers with 404.
"""

from __future__ import annotations

import re
import traceback
from pathlib import Path

import server

HERE = Path(__file__).parent
_passed = _failed = 0


def check(name, cond, detail=""):
    global _passed, _failed
    if cond:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


def _locations(conf: str):
    """[(kind, pattern, upstream-or-None)] for the 443 server block.

    Braces are matched properly, so a one-line `location /t/ { proxy_pass ...; }`
    is seen as readily as a multi-line block."""
    block = conf[conf.index("listen 443"):]
    out = []
    for m in re.finditer(r"location\s+(=\s+|~\s+|)(\S+)\s*\{", block):
        depth, i = 1, m.end()
        while depth and i < len(block):
            depth += {"{": 1, "}": -1}.get(block[i], 0)
            i += 1
        body = block[m.end():i - 1]
        kind = {"=": "exact", "~": "regex"}.get(m.group(1).strip(), "prefix")
        proxy = re.search(r"proxy_pass\s+http://[\d.]+:(\d+)", body)
        out.append((kind, m.group(2), proxy.group(1) if proxy else None))
    return out


def route(locations, path: str):
    """The port nginx would send `path` to, or None for a 404/redirect."""
    for kind, pat, port in locations:
        if kind == "exact" and path == pat:
            return port
    for kind, pat, port in locations:
        if kind == "regex" and re.search(pat, path):
            return port
    best = None
    for kind, pat, port in locations:
        if kind == "prefix" and path.startswith(pat) and (best is None or len(pat) > len(best[0])):
            best = (pat, port)
    return best[1] if best else None


def t_the_parser_sees_one_line_and_nested_blocks() -> None:
    conf = "listen 443 ssl;\n    location /t/ { proxy_pass http://127.0.0.1:8080; }\n" \
           "    location = /a {\n        if ($x) { return 403; }\n        proxy_pass http://127.0.0.1:8090;\n    }\n" \
           "    location / { return 404; }\n"
    locs = _locations(conf)
    check("a one-line block is parsed", ("prefix", "/t/", "8080") in locs, str(locs))
    check("a block with a nested { } is parsed whole", ("exact", "/a", "8090") in locs, str(locs))
    check("the catch-all is parsed and routes nowhere", ("prefix", "/", None) in locs and route(locs, "/zzz") is None, str(locs))
    check("a path under a one-line prefix block routes to it", route(locs, "/t/4821") == "8080")


def t_the_tablet_and_the_oauth_redirects_are_reachable() -> None:
    locs = _locations((HERE / "deploy/nginx/cherry.conf").read_text())
    check("the config parses into locations", len(locs) >= 8, str(locs))
    for path in ("/kds", "/kds/orders", "/kds/accept",
                 "/v1/oauth/square/callback", "/v1/oauth/clover/callback",
                 "/v1/webhooks/telnyx/sms", "/v1/webhooks/square/payment", "/health"):
        check(f"{path} reaches Cherry's API", route(locs, path) == "8080", str(route(locs, path)))
    for path in ("/v1/voice/start", "/v1/voice/calls/x/tool", "/v1/inworld/events"):
        check(f"{path} reaches the voice gateway", route(locs, path) == "8090", str(route(locs, path)))


def t_nothing_else_is_public() -> None:
    locs = _locations((HERE / "deploy/nginx/cherry.conf").read_text())
    for path in ("/t/4821", "/t/4821/accept", "/t/1000", "/ops", "/v1/calls/abc/turn",
                 "/v1/restaurants/x/controls", "/kds/orders/extra", "/kdsx", "/kds/",
                 "/v1/dev/pay/abc", "/"):
        check(f"{path} is a 404 at the edge", route(locs, path) is None, str(route(locs, path)))


def t_every_path_the_tablet_page_calls_is_proxied() -> None:
    locs = _locations((HERE / "deploy/nginx/cherry.conf").read_text())
    page = server._KDS_HTML
    paths = set(re.findall(r"fetch\('(/[^'?]*)", page))
    check("the page calls the feed and the accept endpoint", {"/kds/orders", "/kds/accept"} <= paths, str(paths))
    for p in paths:
        check(f"the tablet's {p} is proxied", route(locs, p) == "8080")
    check("the tablet does not use the unscoped four-digit /t/ routes", "/t/" not in page)


def t_credentials_in_urls_stay_out_of_the_logs() -> None:
    conf = (HERE / "deploy/nginx/cherry.conf").read_text()
    check("a log format that omits the query string exists",
          "log_format cherry_nokey" in conf and '$uri"' in conf.split("log_format cherry_nokey")[1].split(";")[0])
    check("the logged line does not use $request or $request_uri",
          "$request " not in conf.split("log_format cherry_nokey")[1].split(";")[0]
          and "$request_uri" not in conf.split("log_format cherry_nokey")[1].split(";")[0])
    for loc in ("location ~ ^/kds", "location = /v1/oauth/square/callback", "location = /v1/oauth/clover/callback"):
        body = conf.split(loc)[1].split("}")[0]
        check(f"{loc.split()[-1]} logs without the query string", "cherry_nokey" in body)


def main() -> int:
    global _failed
    for name, fn in sorted((k, v) for k, v in globals().items() if k.startswith("t_")):
        try:
            fn()
        except Exception:                                    # noqa: BLE001
            _failed += 1
            print(f"\n--- FAIL {name} raised")
            traceback.print_exc()
    print(f"{_passed} passed, {_failed} failed (nginx edge routes)")
    return 1 if _failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
