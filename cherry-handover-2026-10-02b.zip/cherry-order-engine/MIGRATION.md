# Bun N Run — migration off the old engine

Status: **done and verified.** 263 tests pass, 16/16 mutants caught, config
lints clean with zero findings.

Bun N Run now lives in `restaurants.py` as a `RestaurantConfig` in the new
modifier model, migrated from the old `restaurant_configs.py`. Every price,
default topping, combo price and Toast GUID below was taken from that file.
Nothing was invented; the three places the old config was silent are listed at
the bottom as open questions rather than filled in with a guess.

## Delete these

Once `restaurants.py` is in your repo, these are dead and should be removed in
the same commit — leaving them is how someone edits the wrong file in three
weeks' time.

| Delete | Replaced by |
|---|---|
| old `order_engine.py` (MenuCache, MenuItem with `default_toppings`, OrderEngine) | new `order_engine.py` |
| old `restaurant_configs.py` (RestaurantConfig, `bun_n_run_menu()`, the Toast name maps, `build_stack`) | `restaurants.py` + `cuisine_packs.py` |
| `test_order_engine.py`, `stress_test_order_engine.py` | `test_conformance.py` |
| `demo_multi_restaurant.py` | `demo_all_cuisines.py` |
| `MOTOR_CITY_CONEY` | It was a synthetic second restaurant proving the engine generalised. Eight cuisine packs now do that far harder. Nothing to migrate. |

**Keep** `toast_bridge.py`, `test_toast_bridge.py`, `stress_test_full_stack.py`
and `schema.sql` for now — the bridge still needs rewiring to consume
`to_normalized_order()` instead of the old cart object, which is a separate
piece of work. See "What the bridge now needs" below.

## Old model → new model

| Old | New | Note |
|---|---|---|
| `MenuItem.price` (float dollars) | `base_price_cents` (int) | 5.99 → 599. No float touches money now |
| `MenuItem.keywords` | `aliases` | Same purpose |
| `MenuItem.default_toppings` | `ModifierGroup.default_option_ids` | See below — this is the one real structural change |
| `MenuItem.combo_price` (absolute) | `bnr_combo` option at +$4.00 | Old absolute prices reproduced exactly; see parity tests |
| `toast_name_map`, `toast_modifier_name_map` | `pos_refs` on items and options | GUIDs directly, no name-matching round trip |
| `sample_toast_menu_response` `outOfStock` | `from_toast_menu_response()` | Availability is now a sync, not a menu fact |
| `MenuCache`, `build_stack` | `RestaurantConfig` + `OrderEngine(config)` | Config is immutable and shared; the engine is per call |

**The one structural change.** The old model put default toppings on the item,
so cheeseburgers and hamburgers each carried their own list. The new model puts
defaults on the group. The migration is therefore two groups over one shared
option list — `bnr_toppings_plain` (tomato, onion, ketchup, mayo) and
`bnr_toppings_cheese` (the same plus cheese) — and each burger points at the
right one. No engine change, no per-item special case. It's the same pattern
the pizza pack uses for its build-your-own and three-topping groups.

## Two old bugs, now pinned

Both bugs your earlier testing found are now regression tests rather than
comments:

- `t_bnr_single_cheeseburger_does_not_match_the_double` — "cheeseburger",
  "single cheeseburger", "one cheeseburger" and "just a cheeseburger" all
  resolve decisively to Cheeseburger.
- `t_bnr_hamburger_combo_with_extra_cheese` — combo and extra cheese both land
  on the line.

**Pickle is now correctly absent.** The old config's modifier name map listed
`"pickle" -> "Pickle"`, but Bun N Run's actual Toast modifier group has no
Pickle option and no item defaulted to one. That mismatch is what made "no
pickle" a known bad case. Pickle is off the menu now, so the matcher finds
nothing and Lily says so, rather than accepting a change Toast cannot represent.

## A new bug found during the migration

Writing the parity tests surfaced a matcher bug that would have hit live calls
constantly: **a spoken quantity was being fed into the similarity score.** "one
cheeseburger" scored 0.83 against Cheeseburger and 0.80 against Double
Cheeseburger — inside the ambiguity margin, so the engine would have stopped
and asked "did you want the Cheeseburger or the Double Cheeseburger?" on a
completely unambiguous order.

Fixed by stripping leading quantity words (and the connector in "a couple
**of**") before matching, while leaving "of" alone everywhere else so items
genuinely named "Cup of Hummus" and "Side of Rice" still match. It's now an
invariant across all nine configs: every item must still resolve decisively
when prefixed with "two", "3", or "a couple of". That check immediately caught
two more instances in the pizza and burger-template packs.

## What the bridge now needs

`ToastBridge` currently reads the old cart object. It should read
`to_normalized_order()`, where each line already carries:

```
pos_refs: {"toast_guid": "a1b2-double-cheeseburger",
           "toast_combo_guid": "a1b2-double-cheeseburger-combo"}
modifiers: [{"option_name": "Onion", "pos_refs": {"toast_guid": "mo-onion"}, ...}]
removed_defaults: ["Onion"]
```

One thing to get right: **the combo is a separate Toast item, not a modifier.**
Toast has `a1b2-hamburger` and `a1b2-hamburger-combo` as distinct items. When
`bnr_combo` is selected the bridge must submit `toast_combo_guid` *instead of*
`toast_guid` — submitting the base GUID with a "combo" modifier attached will
be rejected. That mapping is why the combo GUID is stored on the item.

## Three open questions for the owner

These are blocking for go-live, not nice-to-have. All three are places the old
config was silent, and each one is a real money or accuracy difference.

**1. What do extra toppings cost?** The old config priced no modifier at all,
and Toast's fixture carries no modifier prices. Cheese and bacon are currently
set to **$0.00** — a deliberate placeholder that shows up immediately in any
test order, rather than an invented $1.00 that would ship silently wrong. Ask
what bacon and extra cheese add.

**2. Does the combo let the caller choose a side and a drink?** The old config
treated combo as a flat +$4.00 with no choices, and Toast's combo items carry
only the toppings modifier group. Either the combo genuinely is fixed (burger,
fries, a drink, no options), or Bun N Run's Toast menu is under-modeled — and
if it's the latter, that's a problem for the bridge too, not just for Lily. The
template in `cuisine_packs.py` shows how it's configured if choices do exist:
one option revealing two required groups, no engine change.

**3. Is the $30 rule measured on subtotal or post-tax total?** Still open from
your original thread. Currently `pay_now_basis="subtotal"`. At Bun N Run's 6%
that moves the cutoff by about $1.70 of order value.

One more worth confirming: the old engine's tax was an acknowledged hardcoded
stand-in. It's set to **6.00%** here — Michigan state sales tax on prepared
food, with no Ferndale local addition. Worth a glance at a real receipt.
