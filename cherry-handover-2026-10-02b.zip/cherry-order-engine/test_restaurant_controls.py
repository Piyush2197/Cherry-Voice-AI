#!/usr/bin/env python3
"""Restaurant self-service controls and safe call gating."""

from datetime import datetime
from zoneinfo import ZoneInfo
from pathlib import Path
import traceback

import menu_schema as ms
import restaurant_controls as rc
from order_store import OrderStore

HERE=Path(__file__).resolve().parent
_passed=_failed=0
def check(name,cond,detail=""):
    global _passed,_failed
    if cond:_passed+=1
    else:_failed+=1;print(f"  FAIL {name}"+(f" — {detail}" if detail else ""))

def fixture():
    s=OrderStore.sqlite();p=HERE/"menus"/"bun-n-run-ferndale.yaml";c=ms.load_yaml(p)
    s.upsert_restaurant(c.id,c.name,c.cuisine,active=True)
    s.publish_menu(c.id,p.read_text(),item_count=len(c.items));return s,c

def t_hours_holidays_wait_language_and_kill_switch():
    s,c=fixture();rc.set_controls(s,c.id,
        weekly_hours={"mon":["11:00","22:00"]},holiday_closures=["2026-12-25"],
        prep_minutes=25,wait_minutes=15,languages=["en","es"])
    noon=datetime(2026,9,21,12,0,tzinfo=ZoneInfo("America/Detroit"))
    night=datetime(2026,9,21,23,0,tzinfo=ZoneInfo("America/Detroit"))
    open_state=rc.service_state(s,c.id,now=noon);closed=rc.service_state(s,c.id,now=night)
    check("configured service hours open correctly",open_state["accepting_orders"])
    check("closed hours refuse automated ordering",not closed["accepting_orders"] and closed["reason"]=="closed")
    check("prep, wait and languages round trip",(open_state["prep_minutes"],open_state["wait_minutes"],open_state["languages"])==(25,15,["en","es"]))
    rc.set_controls(s,c.id,ai_enabled=False)
    check("AI kill switch takes priority",rc.service_state(s,c.id,now=noon)["reason"]=="ai_disabled")
    check("control changes are audited",len(s.events("restaurant.controls_updated",restaurant_id=c.id))==2)

def main():
    for name,fn in sorted(globals().items()):
        if name.startswith("t_"):
            try:fn()
            except Exception:
                global _failed;_failed+=1;print(f"\n--- FAIL {name}\n{traceback.format_exc()}")
    print(f"\n{_passed} passed, {_failed} failed (restaurant controls)");return 1 if _failed else 0
if __name__=="__main__":raise SystemExit(main())
