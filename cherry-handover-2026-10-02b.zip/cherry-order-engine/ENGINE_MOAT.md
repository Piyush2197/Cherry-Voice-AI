# The order engine as the moat

Written 2026-09-30. Answers: "how do we make the order engine better and
proprietary — it is an employee, a brain, a voice — and become our moat?"

The one-line strategy: **the LLM is rented; the moat is owned.** Anyone can
wire GPT to a phone line. What competitors cannot copy in an afternoon is a
constrained engine that provably cannot lie about food, plus the compounding
data every real call deposits. Everything below is either already built or a
concrete next step.

## 1. The architecture is already the differentiator

A thin competitor builds "prompt the LLM with the menu." That product
hallucinates prices, invents dishes, and guesses when ambiguous — fatal in a
domain where a wrong answer bills a customer.

Cherry is the opposite shape. The LLM is only ears and mouth; the engine is a
deterministic state machine:

- Matching, ambiguity, quantities, per-unit modifiers, exact pricing and tax
  are engine code under **432 conformance invariants**, mutation-tested
  (`START_HERE.md`).
- The model must speak every `say` field **verbatim** — it cannot paraphrase a
  price ("about thirteen dollars" is a bug with a test).
- Ambiguity comes back as a question, never a guess. The engine cannot
  pretend an item exists; it correctly refuses what the restaurant doesn't
  sell.

This is the "employee, not chatbot" property the user asked for: an employee
knows the menu exactly, asks before guessing, and never makes up an answer.
The conformance suite is not just QA — it is the artifact that lets you make
claims competitors can't: *provably exact totals, provably no invented
dishes.*

## 2. The data flywheel — where proprietary really lives

Every real call deposits data only we have. Build the loop deliberately:

### Correction mining (highest value, build first)
Every transcript already stores the full trace (`cherry.py trace`,
`cherry.py evidence`). The gold is in **corrections**: the caller says
something, the engine asks a clarifying question, the caller re-phrases; or
the caller says "no, I said..." Add a weekly job that flags correction patterns
and unmatched phrases, and turn each one into a **menu alias** (`aliases` is
already a first-class field on items, modifier options and sizes — zero schema
change). After 500 real calls you own a phrase-to-dish graph for Metro
Detroit food vocabulary — "double cheese", "DBL chz", "number 3 with a pop" —
that a competitor cannot replicate without their own call volume. That is a
data network effect per cuisine, and it compounds per-restaurant: the engine
gets better at *that* restaurant the longer it works there, which is exactly
what makes it an employee rather than software.

### Accent corpus (the Spanish/Arabic moat, see §3)
Missed/misheard utterances from Arabic- and Spanish-accented callers become
the labeled corpus no one else is collecting at the counter level.

### Proprietary ops analytics (sellable)
Attach rates, combo conversion, best-seller-by-channel, peak missed-call
recovery — the ops snapshot already collects identity-free metrics. Owners
pay for "your voice channel sells 22% more combos" and the data is ours to
aggregate across the fleet.

## 3. Spanish and Arabic — three levels, start with the free one

Metro Detroit's Arabic (Dearborn) and Spanish communities are a real wedge:
small independents whose phone orders are hardest for generic products to
handle. The `localization.py` allow-list and protected-terms translation
already exist per location.

**Level 1 — data only, no code, do it now.** The menu schema already accepts
`aliases` on items, modifier options and sizes. So:

- When ingesting a menu (`cherry.py ingest`), ask the owner the 5–10 phrases
  their callers actually use — in English, transliterated Arabic ("shish
  tawook", "dajaj", "foul"), and Spanish ("pollo", "torta", "sin cebolla").
  Put them in `aliases`. The matcher now hits on Spanish and Arabic words
  **today**, on every menu, with no schema or provider change.
- This is proprietary onboarding knowledge: the intake form becomes part of
  the moat ("we captured how *your* customers order").

**Level 2 — provider configuration, when SIP lands.** Configure STT with
language hints / multilingual recognition (Deepgram, Speechmatics and
similar support Arabic-English and Spanish-English code-switching) and pick
bilingual TTS voices. The Inworld `Dialect` env-var design
(`inworld_adapter.py`) already isolates provider field names, so this is
configuration, not a rewrite.

**Level 3 — fine-tuning/boosting, only after volume.** Custom STT vocabulary
or a pronunciation model fed by the Level-1 corpus and real transcripts.
Do **not** start here — it needs consent policy, data volume, and a baseline
of real calls. Parked deliberately, like provider audio retention
(`DEPLOYMENT_STATUS.md`).

Also in-repo and cheap: the engine's `say` strings are English. A per-location
language allow-list exists; before claiming bilingual service, decide which
fixed phrases (greeting, "for pickup or delivery", read-back) get owner-approved
translations through `localization.py`'s protected-terms path — protected terms
exist precisely so prices and dish names survive translation intact.

## 4. What makes it feel like an employee (roadmap, in order)

1. **Reliability** (built): refuses wrong items, exact prices, never hangs up
   mid-question, human fallback that provably transfers once
   (`failover_drill.py`).
2. **Memory** (later, outside pilot promise): regulars' usual orders,
   "the usual?", allergy memory — the highest-emotion "employee" feature.
   Sequenced after pilots by design.
3. **Judgment** (later): kitchen-load awareness ("it's about a 20-minute
   ticket right now"), weather/rush patterns. The controls API (hours, wait,
   prep, AI disable) is the interface an owner uses to *manage* the employee.
4. **Trust** (built): immutable evidence packet for disputed orders — the
   feature no consumer chatbot thinks to build and every owner asks about
   eventually.

## 5. Ranked next engineering steps

1. **Correction-mining job** → alias pipeline (§2). Smallest effort, first
   true flywheel turn; works on demo and pilot data from day one.
2. **Spanish/Arabic alias pass** on the 19 shipped menus + intake question
   added to `ONBOARDING.md` (Level 1, data only).
3. **Square Catalog menu sync** (`POS_INTEGRATION_PLAN.md` #3) — removes the
   biggest onboarding cost and deepens the Square moat.
4. **Voice-prompt hardening for accented callers**: read-back plays a bigger
   role when STT is imperfect — the read-back-and-confirm loop is already the
   engine's design; keep tests pinning that read-back is mandatory, never
   skippable.
5. Owner-approved fixed-phrase translations through the localization
   allow-list for the first two bilingual merchants.
6. Only after 1,000+ real calls: STT vocabulary boosting (Level 3).

## What not to do

- Don't chase closed-POS APIs one by one (see `POS_INTEGRATION_PLAN.md`).
- Don't fine-tune STT before there are real transcripts to tune on.
- Don't let the LLM generate menu content or prices, ever — every extension
  keeps the engine as the only source of truth. The moat *is* the
  constraint: competitors can rent the same model, but they cannot rent our
  invariants, our alias graph, or our accent corpus.
