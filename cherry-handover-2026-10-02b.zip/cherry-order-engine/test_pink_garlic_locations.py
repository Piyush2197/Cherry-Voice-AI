#!/usr/bin/env python3
"""Location-specific catalog, price, and spoken-order regressions."""

from __future__ import annotations

import traceback
from pathlib import Path

import menu_schema as ms
from config_validator import lint_config
from order_engine import OrderEngine


ROOT = Path(__file__).resolve().parent
_passed = _failed = 0


def check(name, condition, detail=""):
    global _passed, _failed
    if condition:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


def engine(location: str) -> OrderEngine:
    return OrderEngine(ms.load_yaml(ROOT / "menus" / f"{location}.yaml"))


def spoken_add(e: OrderEngine, words: str, quantity: int = 1):
    candidates = e.matcher.match_items(words)
    check(f"'{words}' resolves decisively", e.matcher.is_decisive(candidates), str(candidates[:3]))
    if not candidates:
        raise AssertionError(f"no match for {words}")
    return e.add_line(candidates[0].target_id, quantity=quantity)


def t_each_location_is_a_clean_independent_catalog() -> None:
    for location in ("pink-garlic-oak-park", "pink-garlic-allen-park"):
        cfg = ms.load_yaml(ROOT / "menus" / f"{location}.yaml")
        errors = [str(f) for f in lint_config(cfg) if f.level == "ERROR"]
        check(f"{location} id is not Shelby", cfg.id == location, cfg.id)
        check(f"{location} has no structural errors", not errors, "; ".join(errors))
        check(f"{location} has no copied Shelby POS references",
              all(not item.pos_refs for item in cfg.items))


def t_oak_park_prices_and_spoken_order() -> None:
    e = engine("pink-garlic-oak-park")
    curry = spoken_add(e, "one butter chicken")
    e.apply_option(curry.line_id, "pg_spice", "pg_med")
    spoken_add(e, "two garlic naan", quantity=2)
    spoken_add(e, "mango lassi")
    price = e.price()
    check("Oak Park subtotal uses Oak Park prices", price.subtotal_cents == 2696, str(price))
    check("Oak Park tax and total are pinned",
          (price.tax_cents, price.total_cents) == (162, 2858), str(price))
    check("Oak Park order is submittable", e.is_submittable(), str(e.validate()))


def t_allen_park_prices_and_spoken_order() -> None:
    e = engine("pink-garlic-allen-park")
    curry = spoken_add(e, "one butter chicken")
    e.apply_option(curry.line_id, "pg_spice", "pg_med")
    spoken_add(e, "two garlic naan", quantity=2)
    spoken_add(e, "mango lassi")
    price = e.price()
    check("Allen Park subtotal uses Allen Park prices", price.subtotal_cents == 2646, str(price))
    check("Allen Park tax and total are pinned",
          (price.tax_cents, price.total_cents) == (159, 2805), str(price))
    check("Allen Park order is submittable", e.is_submittable(), str(e.validate()))


def t_location_price_differences_cannot_collapse_back_to_shelby() -> None:
    oak = engine("pink-garlic-oak-park")
    allen = engine("pink-garlic-allen-park")
    checks = (
        ("plain naan", "pg_plain_naan", 249, 299),
        ("mango lassi", "pg_mango_lassi", 499, 449),
        ("chicken tikka", "pg_chk_tikka", 1399, 1349),
        ("French fries", "pg_french_fries", 349, 449),
    )
    for label, item_id, oak_cents, allen_cents in checks:
        check(f"Oak Park {label} price", oak.config.item(item_id).base_price_cents == oak_cents)
        check(f"Allen Park {label} price", allen.config.item(item_id).base_price_cents == allen_cents)


def main() -> int:
    for name, fn in sorted(globals().items()):
        if not name.startswith("t_"):
            continue
        try:
            fn()
        except Exception:
            global _failed
            _failed += 1
            print(f"\n--- FAIL {name}\n{traceback.format_exc()}")
    print(f"\n{_passed} passed, {_failed} failed (Pink Garlic locations)")
    return 1 if _failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
