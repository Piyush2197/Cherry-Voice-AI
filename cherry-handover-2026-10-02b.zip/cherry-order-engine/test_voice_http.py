#!/usr/bin/env python3
"""Voice bridge through a real Cherry HTTP socket, without credentials."""

from __future__ import annotations

import asyncio
import traceback

from test_server import Harness
from voice.inworld_bridge import CherryBridge

_passed = _failed = 0


def check(name, condition, detail=""):
    global _passed, _failed
    if condition:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


def t_real_http_call_places_the_exact_ferndale_order():
    h = Harness()

    async def run():
        b = CherryBridge(f"http://127.0.0.1:{h.port}", "test-secret")
        greeting = await b.start("voice-ferndale", dialled="+13135551000",
                                 caller="+13135550123")
        check("Ferndale routes by dialled number", "Ferndale" in greeting,
              greeting)
        tools = await b.tool_schemas()
        from server import ALL_TOOL_SCHEMAS
        check("live service exposes every published tool",
              {t["name"] for t in tools} == {t["name"] for t in ALL_TOOL_SCHEMAS}, str(len(tools)))

        say = await b.handle_tool_call(
            "voice-ferndale", "add_item",
            {"text": "double cheeseburger combo"})
        check("burger changes are asked", "changes" in say.lower(), say)
        say = await b.handle_tool_call("voice-ferndale", "confirm_mods", {})
        check("combo drink is then asked", "drink" in say.lower(), say)
        say = await b.handle_tool_call("voice-ferndale", "answer",
                                       {"text": "Coke"})
        check("included drink is accepted", "Coke" in say, say)
        asked = await b.finish("voice-ferndale", "Sam")
        check("the caller is asked about allergies before the order is placed",
              "allerg" in asked.lower(), asked)
        await b.handle_tool_call("voice-ferndale", "note_allergy", {"text": "no"})
        closing = await b.finish("voice-ferndale", "Sam")
        check("finish reads the exact total", "$14.83" in closing, closing)

        row = h.store.conn.execute(
            'SELECT * FROM "order" WHERE customer_name=?', ("Sam",)).fetchone()
        check("voice order reached the store", row is not None)
        check("voice order total is exact", row["total_cents"] == 1483,
              str(row["total_cents"]))
        check("voice order stayed in Ferndale",
              row["restaurant_id"] == "bun-n-run-ferndale", row["restaurant_id"])
        check("no speech drift in direct relay",
              not b.verbatim_audit([x["returned"] for x in b.spoken_log]))

    try:
        asyncio.run(run())
    finally:
        h.stop()


def t_real_http_call_routes_clinton_independently():
    h = Harness()

    async def run():
        b = CherryBridge(f"http://127.0.0.1:{h.port}", "test-secret")
        greeting = await b.start("voice-clinton", dialled="+15865551000",
                                 caller="+15865550123")
        check("Clinton routes by its own number", "Clinton Township" in greeting,
              greeting)
        await b.handle_tool_call("voice-clinton", "add_item",
                                 {"text": "fresh shake"})
        await b.finish("voice-clinton", "Lee")                   # the allergy question
        await b.handle_tool_call("voice-clinton", "note_allergy", {"text": "no"})
        closing = await b.finish("voice-clinton", "Lee")
        check("standalone shake can finish", "$4.76" in closing, closing)
        row = h.store.conn.execute(
            'SELECT * FROM "order" WHERE customer_name=?', ("Lee",)).fetchone()
        check("Clinton order stayed in Clinton",
              row is not None and row["restaurant_id"] == "bun-n-run-clinton",
              str(dict(row)) if row else "missing")

    try:
        asyncio.run(run())
    finally:
        h.stop()


def main():
    for name, fn in sorted(globals().items()):
        if not name.startswith("t_"):
            continue
        try:
            fn()
        except Exception:
            global _failed
            _failed += 1
            print(f"\n--- FAIL {name}\n{traceback.format_exc()}")
    print(f"\n{_passed} passed, {_failed} failed (voice bridge over HTTP)")
    return 1 if _failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
