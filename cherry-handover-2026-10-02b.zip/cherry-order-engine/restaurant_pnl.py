#!/usr/bin/env python3
"""
HISTORICAL per-restaurant P&L — superseded by company_model.py.

Do not use this file to quote Cherry's current costs or pricing. It models
TTS-2 Flash as a per-minute charge, which is not Inworld's billing unit, and
it assumes checkout links on only 30% of orders plus kitchen-ticket SMS. The
current launch uses an itemized checkout link for every completed order and
does not send a separate Cherry kitchen ticket. The current company model
uses TTS characters and STT audio hours separately.

    python3 restaurant_pnl.py

WHAT THIS ANSWERS
-----------------
For ONE restaurant at 50 calls/day: what does it cost to serve, what do you
bill, and what does each cost-reduction lever actually save. Every lever is
costed separately so you can rank them instead of guessing.

THE PRICING RULE YOU SET
------------------------
REVENUE: $299 per LOCATION per month. Five locations bill 5 x $299.
COST:    $20 per CUSTOMER per month for the developer/backend, because one
         backend serves up to 5 locations. Past 5, it counts as a second
         customer and the $20 doubles.

So multi-location customers are strictly better for you: revenue scales
linearly with locations while the developer line is amortised across them.

ON VENDOR RATES
---------------
Still zero by default. Fill RATES from your own contracts. Everything else —
minutes, characters, SMS segments, cacheable fraction — is measured from the
real engine and the real menus, so once the rates are in, the answer is real.
"""

from __future__ import annotations

import statistics
from dataclasses import dataclass, field
from typing import Dict, List, Tuple

# ---------------------------------------------------------------------------
# THE PROFILE YOU ASKED ABOUT
# ---------------------------------------------------------------------------

CALLS_PER_DAY = 50
DAYS_PER_MONTH = 30.44          # 365/12, so a month is not 4 weeks
ORDER_CONVERSION = 0.80         # calls that become orders
PAY_LINK_SHARE = 0.30           # orders over the $30 threshold

# Measured by sizing.py / unit_economics.py against the real engine.
AVG_CALL_SECONDS = 90.0
CHARS_SPOKEN_PER_CALL = 246     # measured average across the three pilots
CACHEABLE_FRACTION = 0.97       # measured: only money and codes are unique
TICKET_SMS_SEGMENTS = 2.7       # measured: a ticket is NOT one message
PAYLINK_SMS_SEGMENTS = 1.0      # short by design

# ---------------------------------------------------------------------------
# YOUR RATES — fill these in
# ---------------------------------------------------------------------------

# From the Telnyx and Inworld rate cards, 2026-09.
#
# ONE IMPORTANT CHOICE IS ENCODED HERE. Inworld's TTS is sold two ways:
#   * through Telnyx, per CHARACTER  (Inworld Mini $0.0000055/char)
#   * direct from Inworld, per MINUTE (TTS-2 Flash, 1.5c/min on-demand)
# Per-character is far cheaper at our volume AND it is the only one where
# pre-recording saves money, because a per-minute rate bills the same whether
# the audio was cached or synthesised. See the lever table.
RATES: Dict[str, float] = {
    # Telnyx inbound local number: $0.002/min inbound + $0.002 SIP trunking.
    "telephony_per_min": 0.004,

    # --- INWORLD REALTIME API -------------------------------------------
    # Billed PER MINUTE, not per character. This is the decisive fact for
    # every cost lever: a per-minute rate bills identically whether the audio
    # was synthesised fresh or served from a cache, so PRE-RECORDING SAVES
    # NOTHING ON COST here. It remains a latency win and nothing more.
    #
    # Tier is set by INWORLD_TIER below. TTS-2 Flash assumed — it is the
    # cheaper realtime voice and adequate for order-taking.
    "stt_per_min": 0.0,             # set from the tier table
    "tts_per_1k_chars": 0.0,        # not how Realtime bills
    "inworld_tts_per_min": 0.0,     # set from the tier table
    "inworld_stt_per_min": 0.0,     # set from the tier table

    # Gemma 4 26B A4B via Inworld, priced per MILLION tokens
    # ($0.07 in / $0.34 out). Realtime sessions bill the underlying LLM
    # separately, so this line stays.
    "llm_per_1k_tokens": (0.07 * 0.70 + 0.34 * 0.30) / 1000,
    "llm_tokens_per_min": 4000.0,

    "bundled_voice_per_min": 0.0,
    # $0.004/message part + ~$0.004 carrier fee.
    "sms_per_segment": 0.008,
    "phone_number_per_month": 1.0,
    "tenpdlc_per_month": 12.0,
    "db_hosting_per_month": 25.0,
    "server_hosting_per_month": 20.0,
}

# Inworld Realtime tiers: (monthly platform fee, TTS-2 Flash $/min, STT $/min)
INWORLD_TIERS = {
    "on_demand": (0.0,    0.015,  0.0025),
    "creator":   (25.0,   0.010,  0.0017),
    "builder":   (100.0,  0.009,  0.0017),
    "developer": (300.0,  0.008,  0.0017),
    "growth":    (1500.0, 0.007,  0.0017),
}
INWORLD_TIER = "on_demand"

# How many LOCATIONS share one Inworld platform fee. The fee is per account,
# not per restaurant, so it amortises across every location you run.
LOCATIONS_SHARING_INWORLD = 3

# What you charge: $299 PER LOCATION per month — five locations
# is 5 x 299, not 299 shared. The $20 is a COST line (the developer), charged
# once per customer because the backend is shared up to 5 locations.
PRICE_PER_LOCATION_MONTH = 299.0
DEVELOPER_COST_PER_CUSTOMER = 20.0
MAX_LOCATIONS_PER_CUSTOMER = 5

# How many customers share the fixed infrastructure
CUSTOMERS_SHARING_INFRA = 3


def developer_cost(locations: int) -> Tuple[float, int]:
    """The $20 developer line. One customer up to 5 locations, then it splits.

    This is a COST, not revenue. Returns (monthly cost, billable customers).
    """
    customers = max(1, -(-locations // MAX_LOCATIONS_PER_CUSTOMER))
    return DEVELOPER_COST_PER_CUSTOMER * customers, customers


def revenue(locations: int) -> float:
    """Revenue scales per LOCATION. Five locations is 5 x $299."""
    return PRICE_PER_LOCATION_MONTH * locations


# ---------------------------------------------------------------------------
# Volumes for one restaurant-month
# ---------------------------------------------------------------------------


@dataclass
class Volumes:
    calls: float
    minutes: float
    orders: float
    tts_chars: float
    sms_segments: float

    @classmethod
    def for_month(cls, calls_day: float = CALLS_PER_DAY,
                  call_seconds: float = AVG_CALL_SECONDS,
                  chars: float = CHARS_SPOKEN_PER_CALL,
                  ticket_segments: float = TICKET_SMS_SEGMENTS,
                  paylink_share: float = PAY_LINK_SHARE,
                  sms_tickets: bool = True) -> "Volumes":
        calls = calls_day * DAYS_PER_MONTH
        orders = calls * ORDER_CONVERSION
        segments = 0.0
        if sms_tickets:
            segments += orders * ticket_segments
        segments += orders * paylink_share * PAYLINK_SMS_SEGMENTS
        return cls(calls=calls,
                   minutes=calls * call_seconds / 60,
                   orders=orders,
                   tts_chars=calls * chars,
                   sms_segments=segments)


@dataclass
class Costs:
    lines: Dict[str, float] = field(default_factory=dict)

    @property
    def total(self) -> float:
        return sum(self.lines.values())


def monthly_cost(v: Volumes, rates: Dict[str, float], *,
                 cache_hit: float = 0.0,
                 infra_share: int = CUSTOMERS_SHARING_INFRA,
                 tier: str = None,
                 locations_sharing: int = LOCATIONS_SHARING_INWORLD) -> Costs:
    """Cost for one location-month on the Inworld Realtime API.

    `cache_hit` is accepted and deliberately IGNORED for voice: Realtime bills
    per minute of session, so cached audio costs exactly what synthesised
    audio costs. Keeping the parameter makes the lever table honest — it shows
    a zero saving rather than silently omitting the lever.
    """
    tier = tier or INWORLD_TIER
    platform_fee, tts_min, stt_min = INWORLD_TIERS[tier]

    c = Costs()
    c.lines["telephony"] = v.minutes * rates["telephony_per_min"]
    c.lines["inworld tts"] = v.minutes * tts_min
    c.lines["inworld stt"] = v.minutes * stt_min
    c.lines["inworld tier"] = platform_fee / max(1, locations_sharing)
    c.lines["llm"] = (v.minutes * rates["llm_tokens_per_min"] / 1000
                      * rates["llm_per_1k_tokens"])
    c.lines["sms"] = v.sms_segments * rates["sms_per_segment"]
    c.lines["phone number"] = rates["phone_number_per_month"]
    c.lines["10dlc"] = rates["tenpdlc_per_month"] / max(1, infra_share)
    c.lines["database"] = rates["db_hosting_per_month"] / max(1, infra_share)
    c.lines["server"] = rates["server_hosting_per_month"] / max(1, infra_share)
    return c


# ---------------------------------------------------------------------------
# The levers, each costed on its own
# ---------------------------------------------------------------------------


@dataclass
class Lever:
    name: str
    what: str
    build_effort: str
    risk: str
    volumes: Volumes
    cache_hit: float = 0.0


def levers() -> List[Lever]:
    base = Volumes.for_month()
    return [
        Lever("0. Baseline",
              "90s calls, everything synthesised live, SMS tickets",
              "—", "—", base),

        Lever("1. Pre-record fixed speech",
              f"{CACHEABLE_FRACTION:.0%} of spoken characters served from cached "
              f"clips",
              "2-3 days, ~200 clips per restaurant, regenerated per menu version",
              "None. Deterministic, and it also cuts latency",
              base, cache_hit=0.95),

        Lever("2. Shorten the call by 15s",
              "Tighter prompts, no pointless required questions, no repeated "
              "read-backs",
              "Prompt and config work, no new code",
              "Rushing a caller costs orders. Measure before trusting",
              Volumes.for_month(call_seconds=AVG_CALL_SECONDS - 15)),

        Lever("3. Shorten the call by 30s",
              "Aggressive: barge-in, no confirmation of unambiguous items",
              "Real conversation design work",
              "Higher. This is where accuracy starts to trade against cost",
              Volumes.for_month(call_seconds=AVG_CALL_SECONDS - 30)),

        Lever("4. POS bridge instead of SMS tickets",
              "Order goes to Square/Toast over the API; no ticket SMS at all",
              "SquareSink is built. ToastSink is not",
              "None — it is strictly better for the kitchen too",
              Volumes.for_month(sms_tickets=False)),

        Lever("5. Shorter SMS ticket",
              "Trim the ticket from 2.7 segments to 1.5",
              "An hour. Drop the 'as usual' line and the address",
              "A cook loses context. Only do this if they use the POS bridge "
              "as the real ticket",
              Volumes.for_month(ticket_segments=1.5)),

        Lever("6. Everything together",
              "Cached speech + 15s shorter + POS bridge",
              "Sum of 1, 2 and 4",
              "Combined",
              Volumes.for_month(call_seconds=AVG_CALL_SECONDS - 15,
                                sms_tickets=False),
              cache_hit=0.95),
    ]


# ---------------------------------------------------------------------------


def _fmt(x: float) -> str:
    return f"${x:,.2f}"


def main() -> int:
    print("=" * 74)
    print(f"ONE RESTAURANT — {CALLS_PER_DAY} CALLS/DAY, 7 DAYS A WEEK")
    print("=" * 74)

    v = Volumes.for_month()
    print(f"\nMONTHLY VOLUME (per location)")
    print(f"  calls            {v.calls:>10,.0f}   "
          f"({CALLS_PER_DAY}/day x {DAYS_PER_MONTH:.2f} days)")
    print(f"  talk minutes     {v.minutes:>10,.0f}   "
          f"(at {AVG_CALL_SECONDS:.0f}s average)")
    print(f"  orders           {v.orders:>10,.0f}   "
          f"(at {ORDER_CONVERSION:.0%} conversion)")
    print(f"  spoken chars     {v.tts_chars:>10,.0f}   "
          f"({CHARS_SPOKEN_PER_CALL}/call, {CACHEABLE_FRACTION:.0%} cacheable)")
    print(f"  SMS segments     {v.sms_segments:>10,.0f}   "
          f"(tickets at {TICKET_SMS_SEGMENTS} segments each — NOT 1)")
    print(f"\n  Annual: {v.calls * 12:,.0f} calls, {v.minutes * 12:,.0f} minutes, "
          f"{v.orders * 12:,.0f} orders")

    print(f"\n{'=' * 74}")
    print("REVENUE AND THE DEVELOPER LINE")
    print("=" * 74)
    print(f"\n  {'locations':>10}{'revenue':>11}{'dev cost':>11}"
          f"{'dev/location':>14}{'calls/mo':>11}")
    for locs in (1, 3, 5, 6, 10, 20):
        rev = revenue(locs)
        dev, customers = developer_cost(locs)
        print(f"  {locs:>10}{_fmt(rev):>11}{_fmt(dev):>11}"
              f"{_fmt(dev / locs):>14}{v.calls * locs:>11,.0f}")
    print(f"\n  Revenue scales with locations; the developer line is amortised.")
    print(f"  A 5-location customer pays {_fmt(revenue(5))} and costs "
          f"{_fmt(developer_cost(5)[0])} in developer time —")
    print(f"  {_fmt(developer_cost(5)[0] / 5)} per location instead of "
          f"{_fmt(DEVELOPER_COST_PER_CUSTOMER)}. Multi-location is your best customer.")

    print(f"\n{'=' * 74}")
    print("COST LEVERS — WHAT EACH ONE IS WORTH")
    print("=" * 74)

    ls = levers()
    base_v = ls[0].volumes
    print(f"\n  {'lever':<34}{'minutes':>9}{'chars':>11}{'SMS seg':>9}")
    for l in ls:
        billable_chars = l.volumes.tts_chars * (1 - CACHEABLE_FRACTION * l.cache_hit)
        print(f"  {l.name:<34}{l.volumes.minutes:>9,.0f}"
              f"{billable_chars:>11,.0f}{l.volumes.sms_segments:>9,.0f}")

    print(f"\n  Reduction vs baseline:")
    for l in ls[1:]:
        bc = l.volumes.tts_chars * (1 - CACHEABLE_FRACTION * l.cache_hit)
        base_bc = base_v.tts_chars
        dm = (base_v.minutes - l.volumes.minutes) / base_v.minutes * 100
        dc = (base_bc - bc) / base_bc * 100
        ds = ((base_v.sms_segments - l.volumes.sms_segments)
              / base_v.sms_segments * 100)
        print(f"    {l.name:<34} minutes -{dm:>5.1f}%  "
              f"chars -{dc:>5.1f}%  SMS -{ds:>5.1f}%")

    # bundled_voice_per_min is deliberately 0 — we price the components
    # separately — so it is not "missing".
    missing = []   # Realtime tiers supply the voice rates
    if missing:
        print(f"\n{'=' * 74}")
        print("DOLLARS — BLOCKED ON YOUR RATES")
        print("=" * 74)
        print("\n  These are still 0.00, so no cost figures are printed:\n")
        for k in missing:
            print(f"    {k}")
        print(f"""
  Fill them at the top of this file from your own contracts, then
  re-run. You will get, per restaurant-month: cost by line, cost per
  call, cost per order, gross margin against your {_fmt(PRICE_PER_LOCATION_MONTH)}
  price, and the dollar value of each lever above.

  WHAT THE VOLUMES ALREADY TELL YOU, WITHOUT ANY RATES:

  * Levers 2 and 3 cut MINUTES, and minutes drive four billed lines at
    once (telephony, STT, LLM, orchestration). A 15-second cut is a
    16.7% reduction on all four simultaneously.

  * Lever 1 cuts CHARACTERS by 92%, but characters drive ONE line. If
    your vendor bundles voice per minute, caching saves you nothing at
    all on cost — it is then purely a latency improvement.

  * Lever 4 removes {base_v.sms_segments - ls[4].volumes.sms_segments:,.0f}
    SMS segments a month per restaurant. SMS is the one line billed per
    unit rather than per minute, so it is the easiest to reason about
    and the easiest to eliminate entirely.

  RANK THE LEVERS BY (saving x certainty) / effort. On the volumes
  alone, the order is almost certainly: 2 (shorter calls) > 4 (POS
  bridge) > 1 (pre-recording) > 5 (shorter SMS).""")
        return 0

    print(f"\n{'=' * 74}")
    print(f"MONTHLY P&L PER LOCATION — {_fmt(PRICE_PER_LOCATION_MONTH)}/MONTH")
    print("=" * 74)
    base_cost = monthly_cost(base_v, RATES, cache_hit=0.0)
    dev, _ = developer_cost(1)
    for l in ls:
        c = monthly_cost(l.volumes, RATES, cache_hit=l.cache_hit)
        total = c.total + dev
        saved = (base_cost.total + dev) - total
        margin = PRICE_PER_LOCATION_MONTH - total
        print(f"\n  {l.name}")
        for k, val in c.lines.items():
            if val:
                print(f"      {k:<18}{_fmt(val):>10}")
        print(f"      {'developer':<18}{_fmt(dev):>10}")
        print(f"      {'TOTAL COST':<18}{_fmt(total):>10}   "
              f"per call {_fmt(total / l.volumes.calls)}  "
              f"per order {_fmt(total / l.volumes.orders)}")
        print(f"      {'GROSS PROFIT':<18}{_fmt(margin):>10}   "
              f"({margin / PRICE_PER_LOCATION_MONTH * 100:.1f}% margin)"
              + (f"   lever saves {_fmt(saved)}/mo" if saved else ""))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
