"""
Eight sample restaurant configs, one per cuisine.

These are the onboarding templates. Onboarding a real restaurant means
copying the pack closest to its cuisine, swapping in the real menu and real
prices, and running config_validator.assert_config_ok() over the result.
The engine is never touched.

Every pack deliberately exercises at least one menu shape the others do not:

  Indian .......... required-with-no-default (spice), priced protein swap
  Mexican ......... free allowance then priced (2 free salsas, then $0.75)
  Mediterranean ... two bundled zero-cost required choices on one entree
  Japanese ........ choose-exactly-3-of-N, with premium picks upcharged
  Korean .......... informational included group (banchan), stacked quantity
  Burger .......... defaults + negation, and combo upgrade revealing groups
  Pizza ........... size-dependent modifier pricing, half/half placement,
                    per-option quantity, an option absent at one size
  Italian ......... two required free choices plus optional priced add-ons
"""

from __future__ import annotations

from decimal import Decimal
from typing import Dict, List, Tuple

from order_engine import (
    FreeAllowancePolicy,
    MenuItem,
    ModifierGroup,
    ModifierOption,
    RestaurantConfig,
    SizeVariant,
)


# ---------------------------------------------------------------------------
# tiny builders, to keep the data readable
# ---------------------------------------------------------------------------


def opt(
    id: str,
    name: str,
    price: int = 0,
    *,
    aliases: Tuple[str, ...] = (),
    by_size: Dict[str, int] | None = None,
    default: bool = False,
    reveals: Tuple[str, ...] = (),
    max_qty: int = 1,
    available: bool = True,
) -> ModifierOption:
    return ModifierOption(
        id=id, name=name, price_cents=price, aliases=aliases,
        price_by_size=by_size or {}, is_default=default,
        reveals_group_ids=reveals, max_quantity=max_qty, available=available,
    )


def grp(
    id: str,
    name: str,
    prompt: str,
    options: Tuple[str, ...],
    *,
    more: str = "",
    mn: int = 0,
    mx: int = 1,
    free: int = 0,
    defaults: Tuple[str, ...] = (),
    placement: bool = False,
    half_mult: str = "0.5",
    reveal_only: bool = False,
    informational: bool = False,
    free_policy: FreeAllowancePolicy = FreeAllowancePolicy.MOST_EXPENSIVE,
) -> ModifierGroup:
    return ModifierGroup(
        id=id, name=name, prompt=prompt, prompt_more=more, option_ids=options,
        min_select=mn, max_select=mx, free_select=free,
        default_option_ids=defaults, placement_enabled=placement,
        half_placement_multiplier=Decimal(half_mult),
        reveal_only=reveal_only, informational=informational,
        free_policy=free_policy,
    )


def item(
    id: str,
    name: str,
    price: int = 0,
    *,
    aliases: Tuple[str, ...] = (),
    groups: Tuple[str, ...] = (),
    sizes: Tuple[SizeVariant, ...] = (),
    category: str = "entree",
    available: bool = True,
    taxable: bool = True,
) -> MenuItem:
    return MenuItem(
        id=id, name=name, base_price_cents=price, aliases=aliases,
        modifier_group_ids=groups, sizes=sizes, category=category,
        available=available, taxable=taxable,
    )


def sz(id: str, name: str, price: int, *aliases: str) -> SizeVariant:
    return SizeVariant(id=id, name=name, price_cents=price, aliases=aliases)


# ===========================================================================
# 1. INDIAN — required choice with no default; priced protein swap
# ===========================================================================

INDIAN = RestaurantConfig(
    id="saffron_house",
    name="Saffron House Indian Kitchen",
    cuisine="indian",
    tax_rate_bps=600,
    options=(
        opt("spice_mild", "Mild", aliases=("not spicy", "no spice")),
        opt("spice_medium", "Medium", aliases=("normal", "regular spice")),
        opt("spice_hot", "Hot", aliases=("spicy",)),
        opt("spice_indian_hot", "Indian Hot",
            aliases=("very spicy", "extra hot", "indian spicy")),

        opt("prot_chicken", "Chicken", aliases=("chicken breast",)),
        opt("prot_paneer", "Paneer", aliases=("cheese", "vegetarian", "veg")),
        opt("prot_chickpea", "Chickpea", aliases=("chana", "garbanzo")),
        opt("prot_lamb", "Lamb", 250, aliases=("goat",)),
        opt("prot_shrimp", "Shrimp", 350, aliases=("prawn", "prawns")),

        opt("add_rice", "Side of Basmati Rice", 300, aliases=("extra rice", "rice"), max_qty=3),
        opt("add_naan", "Garlic Naan", 350, aliases=("naan", "bread"), max_qty=4),
        opt("add_raita", "Raita", 250, aliases=("yogurt", "yoghurt")),
        opt("add_papad", "Papad", 150, aliases=("papadum", "poppadom")),
        opt("add_gravy", "Extra Gravy", 200, aliases=("extra sauce", "more sauce")),
    ),
    groups=(
        grp("spice", "Spice Level",
            "How spicy would you like that — mild, medium, hot, or Indian hot?",
            ("spice_mild", "spice_medium", "spice_hot", "spice_indian_hot"),
            mn=1, mx=1),
        grp("protein", "Protein",
            "Would you like that with chicken, paneer, lamb, or shrimp?",
            ("prot_chicken", "prot_paneer", "prot_lamb", "prot_shrimp"),
            mn=1, mx=1),
        grp("protein_veg", "Protein",
            "Would you like that with paneer or chickpeas?",
            ("prot_paneer", "prot_chickpea"), mn=1, mx=1),
        grp("indian_addons", "Add-ons",
            "Anything on the side — rice, naan, raita?",
            ("add_rice", "add_naan", "add_raita", "add_papad", "add_gravy"),
            mn=0, mx=5),
    ),
    items=(
        item("tikka_masala", "Tikka Masala", 1695,
             aliases=("chicken tikka masala", "tikka", "ctm"),
             groups=("spice", "protein", "indian_addons")),
        item("butter_masala", "Butter Masala", 1650,
             aliases=("makhani", "butter curry"),
             groups=("spice", "protein", "indian_addons")),
        item("rogan_josh", "Rogan Josh", 1895,
             aliases=("lamb curry",),
             groups=("spice", "protein", "indian_addons")),
        item("saag", "Saag", 1595,
             aliases=("palak", "spinach curry"),
             groups=("spice", "protein_veg", "indian_addons")),
        item("biryani", "Biryani", 1795,
             aliases=("rice dish",),
             groups=("spice", "protein", "indian_addons")),
        item("samosa", "Samosa (2 pc)", 595,
             aliases=("samosas", "samosa"), category="appetizer"),
        item("mango_lassi", "Mango Lassi", 550,
             aliases=("lassi", "mango drink"), category="drink"),
        item("gulab_jamun", "Gulab Jamun", 495, category="dessert"),
    ),
)


# ===========================================================================
# 2. MEXICAN — free allowance then priced; per-item protein; informational
#              bundled sides on the burrito
# ===========================================================================

MEXICAN = RestaurantConfig(
    id="casa_verde",
    name="Casa Verde Taqueria",
    cuisine="mexican",
    tax_rate_bps=825,
    options=(
        opt("mx_asada", "Carne Asada", aliases=("asada", "steak", "beef")),
        opt("mx_pollo", "Pollo", aliases=("chicken",)),
        opt("mx_carnitas", "Carnitas", aliases=("pork",)),
        opt("mx_pastor", "Al Pastor", aliases=("pastor", "pork pineapple")),
        opt("mx_camaron", "Camarón", 200, aliases=("shrimp", "camaron")),
        opt("mx_veggie", "Veggie", aliases=("vegetarian", "no meat")),

        opt("tort_corn", "Corn Tortilla", aliases=("corn",)),
        opt("tort_flour", "Flour Tortilla", aliases=("flour",)),

        opt("salsa_verde", "Salsa Verde", 75, aliases=("green salsa", "verde")),
        opt("salsa_roja", "Salsa Roja", 75, aliases=("red salsa", "roja")),
        opt("salsa_habanero", "Habanero", 75, aliases=("hot salsa", "habanero")),
        opt("salsa_pico", "Pico de Gallo", 75, aliases=("pico",)),
        opt("salsa_crema", "Crema", 75, aliases=("sour cream", "mexican crema")),

        opt("add_guac", "Guacamole", 250, aliases=("guac", "avocado"), max_qty=2),
        opt("add_queso", "Queso", 225, aliases=("cheese dip", "nacho cheese")),
        opt("add_jalapeno", "Jalapeños", 50, aliases=("jalapenos", "peppers")),

        opt("inc_rice", "Mexican Rice", default=True, aliases=("rice",)),
        opt("inc_beans", "Pinto Beans", default=True, aliases=("beans",)),
    ),
    groups=(
        grp("mx_protein", "Protein",
            "What protein would you like — asada, pollo, carnitas, al pastor, "
            "shrimp, or veggie?",
            ("mx_asada", "mx_pollo", "mx_carnitas", "mx_pastor",
             "mx_camaron", "mx_veggie"), mn=1, mx=1),
        grp("mx_tortilla", "Tortilla",
            "Corn or flour tortilla?", ("tort_corn", "tort_flour"), mn=1, mx=1),
        # Two free salsas, then $0.75 each. The free allowance is spent on the
        # most expensive picks, which here are all equal — but the mechanism is
        # what matters, and it is shared with the pizza and poke packs.
        grp("mx_salsa", "Salsa",
            "Any salsa? The first two are on us.",
            ("salsa_verde", "salsa_roja", "salsa_habanero", "salsa_pico",
             "salsa_crema"), mn=0, mx=5, free=2),
        grp("mx_addons", "Add-ons",
            "Want to add guacamole or queso?",
            ("add_guac", "add_queso", "add_jalapeno"), mn=0, mx=3),
        grp("mx_included", "Included",
            "", ("inc_rice", "inc_beans"), mn=0, mx=2,
            defaults=("inc_rice", "inc_beans"), informational=True),
    ),
    items=(
        item("taco", "Taco", 375, aliases=("tacos", "street taco"),
             groups=("mx_protein", "mx_tortilla", "mx_salsa", "mx_addons")),
        item("burrito", "Burrito", 1195, aliases=("burritos",),
             groups=("mx_protein", "mx_salsa", "mx_addons", "mx_included")),
        item("quesadilla", "Quesadilla", 1050, aliases=("quesadillas", "cheese quesadilla"),
             groups=("mx_protein", "mx_salsa", "mx_addons")),
        item("torta", "Torta", 1125, aliases=("mexican sandwich",),
             groups=("mx_protein", "mx_salsa", "mx_addons")),
        item("nachos", "Nachos", 1195, aliases=("nacho",),
             groups=("mx_protein", "mx_salsa", "mx_addons"), category="appetizer"),
        item("chips_guac", "Chips & Guacamole", 725,
             aliases=("chips and guac", "chips guac"), category="appetizer"),
        item("horchata", "Horchata", 425, aliases=("rice drink",), category="drink"),
        item("churros", "Churros", 550, category="dessert"),
    ),
)


# ===========================================================================
# 3. MEDITERRANEAN — two bundled, required, zero-cost choices per entree
#    ("all entrees include rice or fries, and salad or soup")
# ===========================================================================

MEDITERRANEAN = RestaurantConfig(
    id="olive_ember",
    name="Olive & Ember Mediterranean",
    cuisine="mediterranean",
    tax_rate_bps=700,
    options=(
        opt("side_rice", "Rice Pilaf", aliases=("rice", "pilaf")),
        opt("side_fries", "Fries", aliases=("french fries", "chips")),
        opt("side_fattoush", "Fattoush", 250, aliases=("fattoush salad",)),
        opt("side_hummus_cup", "Cup of Hummus", 300, aliases=("hummus side",)),

        opt("start_salad", "House Salad", aliases=("salad", "green salad")),
        opt("start_soup", "Lentil Soup", aliases=("soup", "lentil")),

        opt("sauce_tzatziki", "Tzatziki", aliases=("cucumber sauce", "white sauce")),
        opt("sauce_garlic", "Garlic Sauce", aliases=("toum", "garlic")),
        opt("sauce_hot", "Hot Sauce", aliases=("shatta", "harissa", "spicy sauce")),
        opt("sauce_tahini", "Tahini", aliases=("sesame sauce",)),
        opt("sauce_extra_cup", "Extra Sauce Cup", 100, aliases=("extra sauce",), max_qty=4),

        opt("bread_pita", "Pita", default=True, aliases=("pita bread",)),
        opt("prot_extra_meat", "Extra Meat", 500, aliases=("double meat", "more meat")),
    ),
    groups=(
        grp("med_side", "Included Side",
            "Every plate comes with a side — would you like rice pilaf or fries?",
            ("side_rice", "side_fries", "side_fattoush", "side_hummus_cup"),
            mn=1, mx=1),
        grp("med_starter", "Included Starter",
            "And it comes with either a house salad or lentil soup — which "
            "would you prefer?",
            ("start_salad", "start_soup"), mn=1, mx=1),
        grp("med_sauce", "Sauces",
            "Any sauces? Tzatziki, garlic, hot, or tahini.",
            ("sauce_tzatziki", "sauce_garlic", "sauce_hot", "sauce_tahini",
             "sauce_extra_cup"), mn=0, mx=5),
        grp("med_bread", "Bread",
            "", ("bread_pita",), mn=0, mx=1, defaults=("bread_pita",)),
        grp("med_extras", "Extras",
            "Want to add extra meat?", ("prot_extra_meat",), mn=0, mx=1),
    ),
    items=(
        item("chicken_kabob", "Chicken Kabob Plate", 1695,
             aliases=("chicken kebab", "chicken kabob", "shish tawook"),
             groups=("med_side", "med_starter", "med_sauce", "med_bread", "med_extras")),
        item("koobideh", "Beef Koobideh Plate", 1895,
             aliases=("koobideh", "beef kabob", "ground beef kebab"),
             groups=("med_side", "med_starter", "med_sauce", "med_bread", "med_extras")),
        item("gyro_plate", "Gyro Plate", 1595,
             aliases=("gyro", "gyros plate"),
             groups=("med_side", "med_starter", "med_sauce", "med_bread", "med_extras")),
        item("falafel_plate", "Falafel Plate", 1395,
             aliases=("falafel", "veggie plate"),
             groups=("med_side", "med_starter", "med_sauce", "med_bread", "med_extras")),
        item("shawarma_wrap", "Shawarma Wrap", 1195,
             aliases=("shawarma", "wrap", "shawarma sandwich"),
             groups=("med_sauce", "med_extras")),
        item("hummus_app", "Hummus & Pita", 795,
             aliases=("hummus",), category="appetizer"),
        item("baklava", "Baklava", 450, category="dessert"),
        item("ayran", "Ayran", 395, aliases=("yogurt drink",), category="drink"),
    ),
)


# ===========================================================================
# 4. JAPANESE / SUSHI — choose exactly 3 of N, premium picks upcharged
# ===========================================================================

JAPANESE = RestaurantConfig(
    id="kaiso_sushi",
    name="Kaiso Sushi House",
    cuisine="japanese",
    tax_rate_bps=650,
    options=(
        opt("roll_cali", "California Roll", aliases=("california", "cali roll")),
        opt("roll_spicy_tuna", "Spicy Tuna Roll", aliases=("spicy tuna",)),
        opt("roll_salmon_avo", "Salmon Avocado Roll", aliases=("salmon avocado",)),
        opt("roll_cucumber", "Cucumber Roll", aliases=("kappa maki", "cucumber")),
        opt("roll_dragon", "Dragon Roll", 400, aliases=("dragon",)),
        opt("roll_rainbow", "Rainbow Roll", 400, aliases=("rainbow",)),

        opt("fish_salmon", "Salmon", aliases=("sake", "salmon nigiri")),
        opt("fish_tuna", "Tuna", aliases=("maguro",)),
        opt("fish_yellowtail", "Yellowtail", 150, aliases=("hamachi",)),
        opt("fish_eel", "Eel", 200, aliases=("unagi",)),
        opt("fish_uni", "Uni", 600, aliases=("sea urchin",), available=False),

        opt("rice_white", "White Rice", default=True, aliases=("white",)),
        opt("rice_brown", "Brown Rice", 100, aliases=("brown",)),
        opt("rice_none", "No Rice", aliases=("salad base", "no rice")),

        opt("poke_topping_edamame", "Edamame", 100, aliases=("edamame",)),
        opt("poke_topping_avocado", "Avocado", 150, aliases=("avocado",)),
        opt("poke_topping_mango", "Mango", 100, aliases=("mango",)),
        opt("poke_topping_seaweed", "Seaweed Salad", 150, aliases=("seaweed",)),
        opt("poke_topping_crab", "Crab Salad", 200, aliases=("krab", "crab")),
        opt("poke_topping_masago", "Masago", 100, aliases=("roe", "fish eggs")),

        opt("pref_no_wasabi", "No Wasabi", aliases=("without wasabi",)),
        opt("pref_extra_ginger", "Extra Ginger", aliases=("more ginger",)),
        opt("pref_sauce_side", "Sauce on the Side", aliases=("sauce on side",)),
        opt("pref_no_sesame", "No Sesame", aliases=("without sesame",)),
    ),
    groups=(
        grp("boat_rolls", "Choose 3 Rolls",
            "The boat comes with any three rolls — which three would you like?",
            ("roll_cali", "roll_spicy_tuna", "roll_salmon_avo", "roll_cucumber",
             "roll_dragon", "roll_rainbow"), mn=3, mx=3,
            more="And what else? {remaining} more roll{s} to go."),
        grp("nigiri_fish", "Fish",
            "Which fish for the nigiri?",
            ("fish_salmon", "fish_tuna", "fish_yellowtail", "fish_eel", "fish_uni"),
            mn=1, mx=1),
        grp("bowl_base", "Base",
            "White rice, brown rice, or over salad?",
            ("rice_white", "rice_brown", "rice_none"), mn=1, mx=1),
        grp("poke_protein", "Protein",
            "Salmon, tuna, or yellowtail for the bowl?",
            ("fish_salmon", "fish_tuna", "fish_yellowtail"), mn=1, mx=2),
        grp("poke_toppings", "Toppings",
            "Pick your toppings — the first four are included.",
            ("poke_topping_edamame", "poke_topping_avocado", "poke_topping_mango",
             "poke_topping_seaweed", "poke_topping_crab", "poke_topping_masago"),
            mn=0, mx=6, free=4),
        grp("sushi_prefs", "Preferences",
            "Anything to leave off?",
            ("pref_no_wasabi", "pref_extra_ginger", "pref_sauce_side",
             "pref_no_sesame"), mn=0, mx=4),
    ),
    items=(
        item("sushi_boat", "Sushi Boat", 3295,
             aliases=("boat", "sushi platter", "party boat"),
             groups=("boat_rolls", "sushi_prefs")),
        item("nigiri", "Nigiri (2 pc)", 650,
             aliases=("nigiri", "sushi piece"),
             groups=("nigiri_fish", "sushi_prefs")),
        item("poke_bowl", "Poke Bowl", 1595,
             aliases=("poke", "poki bowl"),
             groups=("bowl_base", "poke_protein", "poke_toppings", "sushi_prefs")),
        item("chirashi", "Chirashi Bowl", 2295,
             aliases=("chirashi", "sashimi bowl"),
             groups=("sushi_prefs",)),
        item("cali_roll_item", "California Roll", 795,
             aliases=("cali roll",), groups=("sushi_prefs",)),
        item("spicy_tuna_item", "Spicy Tuna Roll", 895,
             aliases=("spicy tuna roll",), groups=("sushi_prefs",)),
        item("edamame_app", "Edamame", 595, category="appetizer"),
        item("miso_soup", "Miso Soup", 395, aliases=("miso",), category="appetizer"),
        item("green_tea", "Green Tea", 350, aliases=("tea",), category="drink"),
    ),
)


# ===========================================================================
# 5. KOREAN — informational included group (banchan), stacked quantity,
#             sized fried chicken with size-scoped sauce cups
# ===========================================================================

KOREAN = RestaurantConfig(
    id="seoul_stone",
    name="Seoul Stone BBQ",
    cuisine="korean",
    tax_rate_bps=600,
    options=(
        opt("ban_kimchi", "Kimchi", default=True),
        opt("ban_sprouts", "Bean Sprouts", default=True),
        opt("ban_radish", "Pickled Radish", default=True),
        opt("ban_potato", "Braised Potato", default=True),

        opt("kr_beef", "Bulgogi Beef", 250, aliases=("beef", "bulgogi")),
        opt("kr_pork", "Spicy Pork", 200, aliases=("pork", "jeyuk")),
        opt("kr_chicken", "Chicken", 150, aliases=("chicken",)),
        opt("kr_tofu", "Tofu", aliases=("vegetarian", "veggie", "dubu")),

        opt("kr_mild", "Mild", aliases=("not spicy",)),
        opt("kr_medium", "Medium", aliases=("regular",)),
        opt("kr_spicy", "Spicy", aliases=("hot",)),
        opt("kr_extra_spicy", "Extra Spicy", aliases=("very spicy", "maeun")),

        opt("kfc_soy_garlic", "Soy Garlic", aliases=("soy", "garlic")),
        opt("kfc_yangnyeom", "Yangnyeom (Sweet & Spicy)",
            aliases=("yangnyeom", "sweet and spicy", "sweet spicy")),
        opt("kfc_plain", "Plain", aliases=("original", "no sauce")),
        opt("kfc_half_half", "Half & Half", 200, aliases=("half and half", "mixed")),

        opt("kr_sauce_cup", "Extra Sauce Cup",
            by_size={"kfc_small": 100, "kfc_large": 150},
            aliases=("extra sauce", "sauce cup"), max_qty=4),
        opt("kr_add_rice", "Side of Rice", 300,
            aliases=("rice", "extra rice", "bap"), max_qty=4),
        opt("kr_add_egg", "Fried Egg", 200, aliases=("egg", "sunny side egg"), max_qty=2),
        opt("kr_add_cheese", "Cheese", 200, aliases=("mozzarella", "cheese")),
        opt("kr_pickled_radish", "Pickled Radish Cup", 100, aliases=("radish",)),
    ),
    groups=(
        grp("banchan", "Banchan (included)", "",
            ("ban_kimchi", "ban_sprouts", "ban_radish", "ban_potato"),
            mn=0, mx=4,
            defaults=("ban_kimchi", "ban_sprouts", "ban_radish", "ban_potato"),
            informational=True),
        grp("kr_protein", "Protein",
            "Would you like that with bulgogi beef, spicy pork, chicken, or tofu?",
            ("kr_beef", "kr_pork", "kr_chicken", "kr_tofu"), mn=1, mx=1),
        grp("kr_spice", "Spice Level",
            "How spicy — mild, medium, spicy, or extra spicy?",
            ("kr_mild", "kr_medium", "kr_spicy", "kr_extra_spicy"), mn=1, mx=1),
        grp("kfc_sauce", "Sauce",
            "Soy garlic, yangnyeom, plain, or half and half?",
            ("kfc_soy_garlic", "kfc_yangnyeom", "kfc_plain", "kfc_half_half"),
            mn=1, mx=1),
        grp("kr_addons", "Add-ons",
            "Anything on the side?",
            ("kr_sauce_cup", "kr_add_rice", "kr_add_egg", "kr_add_cheese",
             "kr_pickled_radish"), mn=0, mx=5),
    ),
    items=(
        item("bibimbap", "Bibimbap", 1595,
             aliases=("bibimbap", "rice bowl", "bibim bap"),
             groups=("kr_protein", "kr_spice", "banchan", "kr_addons")),
        item("bulgogi_plate", "Bulgogi Plate", 1995,
             aliases=("bulgogi plate", "bbq beef plate"),
             groups=("kr_spice", "banchan", "kr_addons")),
        item("kimchi_jjigae", "Kimchi Jjigae", 1495,
             aliases=("kimchi stew", "jjigae", "kimchi soup"),
             groups=("kr_protein", "kr_spice", "banchan", "kr_addons")),
        item("korean_fried_chicken", "Korean Fried Chicken",
             aliases=("kfc", "fried chicken", "korean chicken"),
             sizes=(sz("kfc_small", "Small (8 pc)", 1795, "small", "8 piece", "eight piece"),
                    sz("kfc_large", "Large (16 pc)", 3195, "large", "16 piece", "sixteen piece")),
             groups=("kfc_sauce", "kr_addons")),
        item("japchae", "Japchae", 1495,
             aliases=("glass noodles", "japchae"),
             groups=("kr_protein", "banchan", "kr_addons")),
        item("mandu", "Mandu (6 pc)", 795,
             aliases=("dumplings", "mandu"), category="appetizer"),
        item("tteokbokki", "Tteokbokki", 1095,
             aliases=("rice cakes", "ddeokbokki", "topokki"),
             groups=("kr_spice",), category="appetizer"),
        item("barley_tea", "Barley Tea", 300, aliases=("tea", "boricha"), category="drink"),
    ),
)


# ===========================================================================
# 6. BURGER — TEMPLATE ONLY. Not a real restaurant.
#
#    The real Bun N Run lives in restaurants.py, migrated from the old
#    engine's config with its actual menu and prices. This pack stays as the
#    generic burger template AND as the only pack exercising reveal-groups
#    (a combo upgrade that unlocks a required side and drink), because the
#    real Bun N Run combo turned out not to offer either. Do not treat any
#    price here as Bun N Run's.
# ===========================================================================

BURGER_TEMPLATE = RestaurantConfig(
    id="burger_template",
    name="Generic Burger Template",
    cuisine="burger",
    tax_rate_bps=600,
    options=(
        opt("top_lettuce", "Lettuce", default=True),
        opt("top_tomato", "Tomato", default=True),
        opt("top_onion", "Onion", default=True, aliases=("onions", "raw onion")),
        opt("top_pickle", "Pickle", default=True, aliases=("pickles",)),
        opt("top_ketchup", "Ketchup", default=True),
        opt("top_mustard", "Mustard", default=True),
        opt("top_mayo", "Mayo", aliases=("mayonnaise",)),
        opt("top_bacon", "Bacon", 200, aliases=("bacon strips",), max_qty=3),
        opt("top_extra_cheese", "Extra Cheese", 100,
            aliases=("more cheese", "double cheese"), max_qty=2),
        opt("top_jalapeno", "Jalapeños", 50, aliases=("jalapenos", "peppers")),
        opt("top_grilled_onion", "Grilled Onions", 50, aliases=("fried onions",)),
        opt("top_egg", "Fried Egg", 150, aliases=("egg",)),

        opt("combo_yes", "Make it a Combo", 450,
            aliases=("combo", "make it a meal", "meal", "as a combo"),
            reveals=("combo_side", "combo_drink")),

        opt("cside_fries", "Fries", aliases=("french fries",)),
        opt("cside_rings", "Onion Rings", 150, aliases=("rings", "onion ring")),
        opt("cside_tots", "Tater Tots", 100, aliases=("tots",)),
        opt("cside_salad", "Side Salad", 200, aliases=("salad",)),

        opt("cdrink_coke", "Coke", aliases=("coca cola", "cola")),
        opt("cdrink_diet", "Diet Coke", aliases=("diet",)),
        opt("cdrink_sprite", "Sprite", aliases=("lemon lime",)),
        opt("cdrink_tea", "Iced Tea", aliases=("tea",)),
        opt("cdrink_lemonade", "Lemonade", aliases=("lemon aid",)),
        opt("cdrink_water", "Bottled Water", aliases=("water",)),
    ),
    groups=(
        grp("toppings", "Toppings",
            "Any changes to the toppings?",
            ("top_lettuce", "top_tomato", "top_onion", "top_pickle",
             "top_ketchup", "top_mustard", "top_mayo", "top_bacon",
             "top_extra_cheese", "top_jalapeno", "top_grilled_onion", "top_egg"),
            mn=0, mx=12,
            defaults=("top_lettuce", "top_tomato", "top_onion", "top_pickle",
                      "top_ketchup", "top_mustard")),
        grp("combo_upgrade", "Combo",
            "Would you like to make that a combo with fries and a drink?",
            ("combo_yes",), mn=0, mx=1),
        grp("combo_side", "Combo Side",
            "Which side with the combo — fries, onion rings, tots, or a side salad?",
            ("cside_fries", "cside_rings", "cside_tots", "cside_salad"),
            mn=1, mx=1, reveal_only=True),
        grp("combo_drink", "Combo Drink",
            "And what would you like to drink?",
            ("cdrink_coke", "cdrink_diet", "cdrink_sprite", "cdrink_tea",
             "cdrink_lemonade", "cdrink_water"), mn=1, mx=1, reveal_only=True),
    ),
    items=(
        item("single_cheeseburger", "Single Cheeseburger", 725,
             # no bare "cheeseburger" alias: this menu names Single and
             # Double explicitly, so a bare one has to be asked about
             aliases=("single with cheese", "one with cheese"),
             groups=("toppings", "combo_upgrade")),
        item("double_cheeseburger", "Double Cheeseburger", 995,
             aliases=("double with cheese", "double cheese burger", "big cheese"),
             groups=("toppings", "combo_upgrade")),
        item("single_hamburger", "Single Hamburger", 650,
             aliases=("plain single", "single no cheese"),
             groups=("toppings", "combo_upgrade")),
        item("double_hamburger", "Double Hamburger", 895,
             aliases=("double no cheese", "double plain", "two patty no cheese"),
             groups=("toppings", "combo_upgrade")),
        item("chicken_sandwich", "Chicken Sandwich", 875,
             aliases=("chicken burger", "chicken"),
             groups=("toppings", "combo_upgrade")),
        item("veggie_burger", "Veggie Burger", 850,
             aliases=("veggie", "black bean burger"),
             groups=("toppings", "combo_upgrade")),
        item("fries_side", "Fries", 375, aliases=("french fries", "order of fries"),
             category="side"),
        item("onion_rings_side", "Onion Rings", 495,
             aliases=("rings",), category="side"),
        item("shake", "Milkshake", 595, aliases=("shake", "milk shake"),
             category="drink"),
    ),
)


# ===========================================================================
# 7. PIZZA — the hard one. Size drives topping price, half/half placement,
#            per-option quantity, and an option that does not exist at the
#            largest size.
# ===========================================================================

_PIZZA_SIZES = (
    sz("p_sm", '10" Small', 1195, "small", "ten inch", "10 inch", "personal"),
    sz("p_md", '14" Medium', 1695, "medium", "fourteen inch", "14 inch"),
    sz("p_lg", '18" Large', 2195, "large", "eighteen inch", "18 inch", "big"),
)

_VEG = {"p_sm": 150, "p_md": 200, "p_lg": 275}
_MEAT = {"p_sm": 250, "p_md": 325, "p_lg": 400}

PIZZA = RestaurantConfig(
    id="vesuvio",
    name="Vesuvio Pizza Co.",
    cuisine="pizza",
    tax_rate_bps=700,
    options=(
        opt("crust_regular", "Regular Crust", default=True, aliases=("regular", "classic")),
        opt("crust_thin", "Thin Crust", aliases=("thin",)),
        opt("crust_deep", "Deep Dish", by_size={"p_md": 300, "p_lg": 400},
            aliases=("deep dish", "pan", "chicago")),
        # Gluten free is only made in small and medium. The linter warns about
        # this at onboarding; the engine refuses it at large mid-call.
        opt("crust_gf", "Gluten Free Crust", by_size={"p_sm": 300, "p_md": 400},
            aliases=("gluten free", "gf crust", "celiac")),

        opt("sauce_red", "Red Sauce", default=True, aliases=("tomato", "marinara", "red")),
        opt("sauce_white", "White Sauce", aliases=("alfredo", "white", "garlic cream")),
        opt("sauce_pesto", "Pesto", 150, aliases=("pesto sauce", "basil sauce")),
        opt("sauce_bbq", "BBQ Sauce", aliases=("barbecue", "bbq")),
        opt("sauce_none", "No Sauce", aliases=("no sauce", "without sauce")),

        opt("t_pepperoni", "Pepperoni", by_size=_MEAT, aliases=("peperoni", "pep"), max_qty=3),
        opt("t_sausage", "Italian Sausage", by_size=_MEAT, aliases=("sausage",), max_qty=3),
        opt("t_bacon", "Bacon", by_size=_MEAT, aliases=("bacon",), max_qty=3),
        opt("t_ham", "Ham", by_size=_MEAT, aliases=("canadian bacon", "ham"), max_qty=2),
        opt("t_chicken", "Grilled Chicken", by_size=_MEAT, aliases=("chicken",), max_qty=2),
        opt("t_meatball", "Meatball", by_size=_MEAT, aliases=("meatballs",), max_qty=2),
        opt("t_mushroom", "Mushrooms", by_size=_VEG, aliases=("mushroom", "shrooms"), max_qty=3),
        opt("t_onion", "Onions", by_size=_VEG, aliases=("onion", "red onion"), max_qty=2),
        opt("t_pepper", "Green Peppers", by_size=_VEG,
            aliases=("peppers", "bell peppers", "green pepper"), max_qty=2),
        opt("t_olive", "Black Olives", by_size=_VEG, aliases=("olives", "olive"), max_qty=2),
        opt("t_jalapeno", "Jalapeños", by_size=_VEG, aliases=("jalapenos", "hot peppers"), max_qty=2),
        opt("t_pineapple", "Pineapple", by_size=_VEG, aliases=("pineapple",), max_qty=2),
        opt("t_spinach", "Spinach", by_size=_VEG, aliases=("spinach",), max_qty=2),
        opt("t_extra_cheese", "Extra Cheese", by_size=_VEG,
            aliases=("more cheese", "double cheese"), max_qty=3),

        opt("dip_ranch", "Ranch Cup", 89, aliases=("ranch",), max_qty=6),
        opt("dip_garlic", "Garlic Butter Cup", 89, aliases=("garlic butter", "garlic dip"), max_qty=6),
        opt("dip_marinara", "Marinara Cup", 89, aliases=("marinara cup", "dipping sauce"), max_qty=6),
    ),
    groups=(
        grp("crust", "Crust",
            "What crust — regular, thin, deep dish, or gluten free?",
            ("crust_regular", "crust_thin", "crust_deep", "crust_gf"), mn=1, mx=1),
        grp("pizza_sauce", "Sauce",
            "Red sauce, white, pesto, or BBQ?",
            ("sauce_red", "sauce_white", "sauce_pesto", "sauce_bbq", "sauce_none"),
            mn=1, mx=1),
        grp("toppings_byo", "Toppings",
            "What would you like on it?",
            ("t_pepperoni", "t_sausage", "t_bacon", "t_ham", "t_chicken",
             "t_meatball", "t_mushroom", "t_onion", "t_pepper", "t_olive",
             "t_jalapeno", "t_pineapple", "t_spinach", "t_extra_cheese"),
            mn=0, mx=14, placement=True, half_mult="0.5"),
        # Same options, three of them free. A distinct group, because
        # free_select differs — never a special case in the engine.
        grp("toppings_special", "Toppings (3 included)",
            "Pick your three toppings.",
            ("t_pepperoni", "t_sausage", "t_bacon", "t_ham", "t_chicken",
             "t_meatball", "t_mushroom", "t_onion", "t_pepper", "t_olive",
             "t_jalapeno", "t_pineapple", "t_spinach", "t_extra_cheese"),
            mn=3, mx=14, free=3, placement=True, half_mult="0.5",
            more="What else? {remaining} more included topping{s}."),
        grp("dips", "Dipping Sauces",
            "Any dipping sauces?",
            ("dip_ranch", "dip_garlic", "dip_marinara"), mn=0, mx=3),
    ),
    items=(
        MenuItem(id="byo_pizza", name="Build Your Own Pizza",
                 aliases=("build your own", "make my own", "custom pizza"),
                 sizes=_PIZZA_SIZES,
                 modifier_group_ids=("crust", "pizza_sauce", "toppings_byo", "dips")),
        MenuItem(id="cheese_pizza", name="Cheese Pizza",
                 aliases=("plain pizza", "just cheese", "cheese pie"),
                 sizes=_PIZZA_SIZES,
                 modifier_group_ids=("crust", "pizza_sauce", "toppings_byo", "dips")),
        MenuItem(id="three_topping", name="Three Topping Special",
                 aliases=("three topping", "3 topping", "special"),
                 sizes=(sz("p_sm", '10" Small', 1595, "small", "ten inch"),
                        sz("p_md", '14" Medium', 2095, "medium", "fourteen inch"),
                        sz("p_lg", '18" Large', 2595, "large", "eighteen inch")),
                 modifier_group_ids=("crust", "pizza_sauce", "toppings_special", "dips")),
        MenuItem(id="margherita", name="Margherita",
                 aliases=("margarita", "marg"),
                 sizes=_PIZZA_SIZES,
                 modifier_group_ids=("crust", "toppings_byo", "dips")),
        item("garlic_knots", "Garlic Knots (6)", 695,
             aliases=("knots", "garlic knot"), groups=("dips",), category="appetizer"),
        item("wings", "Wings (10)", 1395,
             aliases=("chicken wings", "wings"), groups=("dips",), category="appetizer"),
        item("house_salad", "House Salad", 795,
             aliases=("salad",), category="side"),
        item("two_liter", "2-Liter Soda", 395,
             aliases=("two liter", "soda", "pop"), category="drink"),
    ),
)


# ===========================================================================
# 8. ITALIAN / PASTA — two required free choices, optional priced add-ons,
#                      portion sizes
# ===========================================================================

_PASTA_SIZES = (
    sz("it_lunch", "Lunch", 1295, "lunch portion", "small", "lunch size"),
    sz("it_dinner", "Dinner", 1795, "dinner portion", "regular", "dinner size"),
    sz("it_family", "Family", 3295, "family size", "family style", "large", "for the table"),
)

ITALIAN = RestaurantConfig(
    id="trattoria_nonna",
    name="Trattoria Nonna",
    cuisine="italian",
    tax_rate_bps=700,
    options=(
        opt("shape_spaghetti", "Spaghetti", aliases=("spagetti", "spaghetti noodles")),
        opt("shape_penne", "Penne", aliases=("penne pasta",)),
        opt("shape_fettuccine", "Fettuccine", aliases=("fettucine", "fettuccini", "flat noodles")),
        opt("shape_rigatoni", "Rigatoni", aliases=("rigatoni pasta",)),
        opt("shape_gf", "Gluten Free Penne", 300,
            aliases=("gluten free", "gf pasta", "gluten free pasta")),

        opt("sauce_marinara", "Marinara", aliases=("red sauce", "tomato sauce")),
        opt("sauce_alfredo", "Alfredo", aliases=("white sauce", "cream sauce")),
        opt("sauce_bolognese", "Bolognese", 200, aliases=("meat sauce", "bolognaise")),
        opt("sauce_pesto_it", "Pesto", 150, aliases=("basil pesto",)),
        opt("sauce_vodka", "Vodka Sauce", 200, aliases=("pink sauce", "vodka")),
        opt("sauce_aglio", "Aglio e Olio", aliases=("garlic and oil", "oil and garlic")),

        opt("add_chicken_it", "Grilled Chicken", 500, aliases=("chicken",), max_qty=2),
        opt("add_shrimp_it", "Shrimp", 700, aliases=("prawns", "shrimp")),
        opt("add_meatballs", "Meatballs", 400, aliases=("meatball",), max_qty=3),
        opt("add_sausage_it", "Italian Sausage", 450, aliases=("sausage",), max_qty=2),
        opt("add_mushrooms_it", "Mushrooms", 200, aliases=("mushroom",)),
        opt("add_ricotta", "Ricotta", 250, aliases=("cheese dollop", "ricotta cheese")),

        opt("side_bread", "Garlic Bread", 300, aliases=("bread", "garlic toast"), max_qty=3),
        opt("side_caesar", "Side Caesar", 450, aliases=("caesar", "side salad")),
        opt("cheese_parm", "Grated Parmesan", default=True, aliases=("parmesan", "parm")),
    ),
    groups=(
        grp("pasta_shape", "Pasta",
            "Which pasta — spaghetti, penne, fettuccine, or rigatoni? "
            "We also have gluten free.",
            ("shape_spaghetti", "shape_penne", "shape_fettuccine",
             "shape_rigatoni", "shape_gf"), mn=1, mx=1),
        grp("pasta_sauce", "Sauce",
            "And which sauce — marinara, alfredo, bolognese, pesto, vodka, "
            "or aglio e olio?",
            ("sauce_marinara", "sauce_alfredo", "sauce_bolognese",
             "sauce_pesto_it", "sauce_vodka", "sauce_aglio"), mn=1, mx=1),
        grp("it_addons", "Add Protein",
            "Would you like to add chicken, shrimp, meatballs, or sausage?",
            ("add_chicken_it", "add_shrimp_it", "add_meatballs",
             "add_sausage_it", "add_mushrooms_it", "add_ricotta"), mn=0, mx=4),
        grp("it_sides", "Sides",
            "Any garlic bread or a side Caesar?",
            ("side_bread", "side_caesar"), mn=0, mx=2),
        grp("it_cheese", "Cheese", "",
            ("cheese_parm",), mn=0, mx=1, defaults=("cheese_parm",)),
    ),
    items=(
        MenuItem(id="pasta_bowl", name="Pasta",
                 aliases=("pasta bowl", "noodles", "build your own pasta"),
                 sizes=_PASTA_SIZES,
                 modifier_group_ids=("pasta_shape", "pasta_sauce", "it_addons",
                                     "it_sides", "it_cheese")),
        MenuItem(id="baked_ziti", name="Baked Ziti",
                 aliases=("ziti",),
                 sizes=_PASTA_SIZES,
                 modifier_group_ids=("it_addons", "it_sides", "it_cheese")),
        item("lasagna", "Lasagna", 1895,
             aliases=("lasagne", "meat lasagna"),
             groups=("it_addons", "it_sides", "it_cheese")),
        item("chicken_parm", "Chicken Parmigiana", 2095,
             aliases=("chicken parm", "chicken parmesan", "chicken parmigiana"),
             groups=("pasta_shape", "it_sides", "it_cheese")),
        item("eggplant_parm", "Eggplant Parmigiana", 1895,
             aliases=("eggplant parm", "eggplant parmesan", "aubergine parm"),
             groups=("pasta_shape", "it_sides", "it_cheese")),
        item("caesar_entree", "Caesar Salad", 1095,
             aliases=("caesar salad", "big caesar"),
             groups=("it_addons",), category="salad"),
        item("garlic_bread_item", "Garlic Bread", 495,
             aliases=("bread basket",), category="appetizer"),
        item("tiramisu", "Tiramisu", 795, aliases=("tirimisu",), category="dessert"),
    ),
)


# ---------------------------------------------------------------------------

ALL_PACKS: Dict[str, RestaurantConfig] = {
    "indian": INDIAN,
    "mexican": MEXICAN,
    "mediterranean": MEDITERRANEAN,
    "japanese": JAPANESE,
    "korean": KOREAN,
    "burger_template": BURGER_TEMPLATE,
    "pizza": PIZZA,
    "italian": ITALIAN,
}
