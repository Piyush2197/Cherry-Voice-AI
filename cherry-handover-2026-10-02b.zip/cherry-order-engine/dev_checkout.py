"""
A local checkout that behaves like a hosted one — development only.

WHY THIS EXISTS
---------------
Out of the box, Cherry could not complete an order. Every restaurant needs an
itemized checkout provider, and the only real one is Square, so a fresh
checkout with no Square account behaved like this:

    $ curl .../finish
    {"placed": true, ..., "payment": "link_pending", "delivered": false}

    "I could not deliver the secure checkout. The restaurant has not received
     the order; staff will need to help you."

That is the documented 60-second quickstart's ending. Nothing was broken in the
engine — `arrange_payment` correctly reported that no provider issued a link —
but the product was not runnable, demonstrable, or rehearsable without a live
merchant account. You could not show an owner what they were buying, and you
could not rehearse an onboarding before risking a real customer.

This module closes that gap without pretending the money is real.

WHAT IT IS, AND WHAT IT IS NOT
------------------------------
It IS a `PayLinkProvider` (see `payments.py`) that issues a well-formed
`https://` link, records the request, and supports revocation — so the whole
lifecycle runs: link created -> link texted -> payment recorded -> order
released to the kitchen sink, exactly once.

It is NOT a payment. No card is taken, no money moves, and **the link does not
resolve** — no DNS name exists at `dev-checkout.cherry.test`. Payment is
completed by `POST /v1/dev/pay/<order_id>` on a server started with
`--dev-checkout`, which calls the *same* `payments.mark_paid()` and
`payments.release_paid_order()` that Square's signed webhook calls. So what a
demo exercises is the real release logic, with the provider swapped.

The link is deliberately not made to resolve. `PayLink` refuses any non-https
URL, because a payment link is texted to a customer and a card must never be
entered over plain http. Loosening that guard to make a local demo clickable
would trade a real customer-safety property for a convenience, so instead the
dev flow is explicit and non-clickable.

KEEPING IT OUT OF PRODUCTION
----------------------------
Three independent things make that hard to do by accident:

1. It is only ever constructed behind the explicit `--dev-checkout` flag.
2. `/health` reports `"checkout": "dev"`, so a monitor can see it.
3. `/v1/dev/pay/...` returns 404 unless the flag is set.

`is_real = False` marks it for any code that wants to check.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from payments import PayLink

#: Reserved, non-resolving host. `.test` is guaranteed never to be delegated,
#: so this can never accidentally become a real address someone pays on.
DEV_HOST = "https://dev-checkout.cherry.test"

BANNER = (
    "\n"
    "  ============================================================\n"
    "   DEV CHECKOUT ENABLED — THIS IS NOT A REAL PAYMENT PATH\n"
    "   Links point at %s and do not resolve.\n"
    "   Complete a payment with:  POST /v1/dev/pay/<order_id>\n"
    "   Never start a pilot, a demo to an owner, or production\n"
    "   traffic with --dev-checkout.\n"
    "  ============================================================" % DEV_HOST
)


class DevCheckoutError(RuntimeError):
    """Misuse of the development checkout."""


class DevCheckoutProvider:
    """A `PayLinkProvider` for local runs. Issues links; takes no money."""

    name = "dev"
    #: Lets callers distinguish this from Square without isinstance checks.
    is_real = False

    def __init__(self, base_url: str = DEV_HOST,
                 checkout_minutes: int = 30) -> None:
        if not base_url.startswith("https://"):
            raise DevCheckoutError(
                f"dev checkout base must be https, got {base_url!r} — the "
                f"same rule real providers follow")
        self.base_url = base_url.rstrip("/")
        self.checkout_minutes = checkout_minutes
        # Kept so a test or a demo can inspect what was asked for.
        self.created: List[PayLink] = []
        self.requests: List[Dict[str, Any]] = []
        self.revoked: List[str] = []

    # --- PayLinkProvider -------------------------------------------------
    def create_pay_link(self, order_id: str, amount_cents: int,
                        pos_order_ref: Optional[str] = None, *,
                        snapshot: dict,
                        context: Dict[str, Any]) -> PayLink:
        if snapshot.get("total_cents") is not None and int(snapshot["total_cents"]) != int(amount_cents):
            raise ValueError("checkout amount does not match immutable order")
        self.requests.append({"order_id": order_id,
                              "amount_cents": amount_cents,
                              "snapshot": snapshot,
                              "context": context})
        link = PayLink(
            url=f"{self.base_url}/pay/{order_id}",
            expires_at=(datetime.now(timezone.utc)
                        + timedelta(minutes=self.checkout_minutes)
                        ).isoformat(timespec="seconds"),
            pos_ref=pos_order_ref or f"dev-{order_id[:8]}",
            provider_link_ref=f"devlink-{order_id}")
        self.created.append(link)
        return link

    def revoke_pay_link(self, provider_link_ref: str) -> None:
        self.revoked.append(provider_link_ref)

    # --- introspection ---------------------------------------------------
    def describe(self) -> Dict[str, Any]:
        return {"name": self.name, "is_real": False, "host": self.base_url,
                "links_created": len(self.created),
                "links_revoked": len(self.revoked)}
