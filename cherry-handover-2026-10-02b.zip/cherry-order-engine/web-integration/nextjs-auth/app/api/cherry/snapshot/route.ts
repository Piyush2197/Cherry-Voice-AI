import { NextRequest, NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'
import { getSnapshot } from '@/lib/cherry-api'

export async function GET(request: NextRequest) {
  // Check authentication
  const user = await getCurrentUser()
  if (!user) {
    return NextResponse.json(
      { error: 'Unauthorized' },
      { status: 401 }
    )
  }
  
  // Hours from the query, default 24; the Cherry server accepts 1-720.
  const { searchParams } = new URL(request.url)
  const requested = parseInt(searchParams.get('hours') || '24', 10)
  const hours = Number.isFinite(requested) ? Math.min(720, Math.max(1, requested)) : 24
  
  // Fetch from CHERRY API
  const response = await getSnapshot(hours)
  
  if (!response.ok) {
    return NextResponse.json(
      { error: response.error || 'Failed to fetch snapshot' },
      { status: 502 }
    )
  }
  
  return NextResponse.json(response.data)
}
