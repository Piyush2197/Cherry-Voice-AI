"""
The order store.

Production is PostgreSQL (db/schema.sql). This module talks plain DB-API so
the same code runs on SQLite for tests and local development — the logical
model is identical, and SQLITE_SCHEMA below is the same tables with Postgres
types swapped out. Nothing here uses a Postgres-only feature at the query
level, so what the tests exercise is what production runs.

WHY POSTGRES, AND WHY ONE OF IT
-------------------------------
The three pilots are 50, 75 and 100 calls a day. That is at most ~225 orders
daily, ~7k a month, a handful of writes per minute at peak. A single small
Postgres instance is several orders of magnitude more than enough, and will
still be enough at fifty restaurants. Reach for anything more elaborate — a
queue, a cache, read replicas, a document store — only when a measurement
says to. At this volume the database is not going to be the problem; the
phone line is.

Postgres rather than SQLite for production because of concurrent writers (one
process per live call), real transactions across the order/delivery/payment
triple, JSONB for the order snapshot, and because every host gives you managed
backups. Backups matter more than throughput here: losing an order is worse
than serving it slowly.

THE TWO INVARIANTS THIS MODULE EXISTS TO PROTECT
------------------------------------------------
1. A placed order is immutable. It stores the full priced snapshot and the
   menu version it was priced against. A price edit tomorrow cannot restate
   what a customer was quoted today.
2. No payment data. Cherry relays a POS-hosted link and stores a status word.
   There is no column here that could hold a card number, and a test asserts
   it stays that way.
"""

from __future__ import annotations

import _ensure_deps  # noqa: F401  (re-runs under .venv, or says how to install, if PyYAML is missing)
import collections
import hashlib
import json
import random
import sqlite3
import tempfile
import threading
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

HERE = Path(__file__).parent


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


# Parsed menus, keyed by the SHA-256 of their YAML. A published menu version is
# immutable and RestaurantConfig is a frozen dataclass, so one parse can be
# shared by every call. Without this each call start re-parsed the whole menu
# with PyYAML's pure-Python loader (~0.2 s, twice): ten callers ringing at
# once made the last one wait several seconds for a greeting.
_CONFIG_CACHE: "collections.OrderedDict[str, Any]" = collections.OrderedDict()
_CONFIG_CACHE_LOCK = threading.Lock()
_CONFIG_CACHE_MAX = 64


def _parsed_menu(yaml_text: str):
    import menu_schema as ms
    import yaml as _yaml
    key = hashlib.sha256(yaml_text.encode()).hexdigest()
    with _CONFIG_CACHE_LOCK:
        cfg = _CONFIG_CACHE.get(key)
        if cfg is not None:
            _CONFIG_CACHE.move_to_end(key)
            return cfg
    # libyaml's parser is ~10x faster than the pure-Python one when present.
    loader = getattr(_yaml, "CSafeLoader", _yaml.SafeLoader)
    cfg = ms.build_config(_yaml.load(yaml_text, Loader=loader))
    with _CONFIG_CACHE_LOCK:
        _CONFIG_CACHE[key] = cfg
        while len(_CONFIG_CACHE) > _CONFIG_CACHE_MAX:
            _CONFIG_CACHE.popitem(last=False)
    return cfg


def redact_dsn(db: object) -> str:
    """postgresql://user:SECRET@host/db -> postgresql://user:***@host/db

    A connection string is a credential; anything that logs or prints one
    (startup banners, preflight reports) must go through this.
    """
    import re as _re
    return _re.sub(r"(://[^:/@\s]+:)[^@\s]*@", r"\1***@", str(db))


def json_value(value: Any) -> Any:
    """Normalize SQLite TEXT JSON and psycopg's already-decoded JSONB."""
    return json.loads(value) if isinstance(value, str) else value


def _is_unique_violation(exc: Exception) -> bool:
    """A duplicate key on either database (SQLite or PostgreSQL 23505)."""
    if isinstance(exc, sqlite3.IntegrityError):
        return "UNIQUE" in str(exc).upper()
    return getattr(exc, "sqlstate", None) == "23505"


def _postgres_sql(sql: str) -> str:
    """Translate the deliberately small SQLite-flavoured query surface."""
    ignored = "INSERT OR IGNORE INTO" in sql.upper()
    if ignored:
        sql = sql.replace("INSERT OR IGNORE INTO", "INSERT INTO")
        sql = sql.rstrip().rstrip(";") + " ON CONFLICT DO NOTHING"
    return sql.replace("?", "%s")


def _configure_postgres_connection(connection: Any) -> None:
    """Make Postgres rows look exactly like SQLite rows to the rest of Cherry.

    The application treats ids and timestamps as plain strings (they are
    compared with str ids from the API and passed to ``json.dumps``). psycopg
    would otherwise hand back ``uuid.UUID`` and ``datetime`` objects, which
    silently break equality checks and crash JSON serialisation in server.py.
    """
    from psycopg.adapt import Loader
    from psycopg.types.datetime import TimestamptzLoader
    from psycopg.types.string import TextLoader

    class IsoTimestamptz(TimestamptzLoader):
        def load(self, data):
            value = super().load(data)
            return value.astimezone(timezone.utc).isoformat(timespec="seconds")

    connection.adapters.register_loader("uuid", TextLoader)
    connection.adapters.register_loader("timestamptz", IsoTimestamptz)


class _PostgresCursor:
    """Expose the tiny cursor subset used by OrderStore."""

    def __init__(self, cursor: Any, connection: Any) -> None:
        self._cursor = cursor
        self._connection = connection

    @property
    def rowcount(self) -> int:
        return self._cursor.rowcount

    @property
    def lastrowid(self) -> int:
        # PostgreSQL has no DB-API lastrowid. Every generated id in this
        # repository is backed by a sequence, and lastval() is scoped to this
        # exact pooled connection and transaction.
        row = self._connection.execute("SELECT lastval() AS id").fetchone()
        return int(row["id"])

    def fetchone(self):
        return self._cursor.fetchone()

    def fetchall(self):
        return self._cursor.fetchall()


class _PostgresConnection:
    """DB-API compatibility wrapper: qmark parameters and mapping rows."""

    def __init__(self, connection: Any) -> None:
        self._connection = connection

    def execute(self, sql: str, params: Iterable[Any] = ()) -> _PostgresCursor:
        cursor = self._connection.execute(_postgres_sql(sql), tuple(params))
        return _PostgresCursor(cursor, self._connection)


class _PostgresReadCursor(_PostgresCursor):
    """Return a read-only pooled connection as soon as results are consumed."""

    def __init__(self, cursor: Any, connection: Any, lease: Any) -> None:
        super().__init__(cursor, connection)
        self._lease = lease
        self._released = False

    def _release(self, exc_type=None, exc=None, tb=None) -> None:
        if not self._released:
            self._released = True
            self._lease.__exit__(exc_type, exc, tb)

    def fetchone(self):
        try:
            return super().fetchone()
        except Exception as exc:
            self._release(type(exc), exc, exc.__traceback__)
            raise
        finally:
            if not self._released:
                self._release()

    def fetchall(self):
        try:
            return super().fetchall()
        except Exception as exc:
            self._release(type(exc), exc, exc.__traceback__)
            raise
        finally:
            if not self._released:
                self._release()


class _PostgresReader:
    """A connection-like read facade backed by psycopg_pool."""

    def __init__(self, pool: Any) -> None:
        self._pool = pool

    def execute(self, sql: str, params: Iterable[Any] = ()) -> _PostgresReadCursor:
        lease = self._pool.connection()
        connection = lease.__enter__()
        try:
            cursor = connection.execute(_postgres_sql(sql), tuple(params))
        except Exception as exc:
            lease.__exit__(type(exc), exc, exc.__traceback__)
            raise
        return _PostgresReadCursor(cursor, connection, lease)


# SQLite mirror of db/schema.sql. Same tables, same columns, same checks where
# SQLite supports them. Postgres owns production; this owns the tests.
SQLITE_SCHEMA = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS schema_migration (
    version INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    applied_at TEXT NOT NULL
);
INSERT OR IGNORE INTO schema_migration (version, name, applied_at)
VALUES (1, 'initial production schema', CURRENT_TIMESTAMP);

CREATE TABLE IF NOT EXISTS restaurant (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    cuisine TEXT NOT NULL,
    timezone TEXT NOT NULL DEFAULT 'America/Detroit',
    tax_rate_bps INTEGER NOT NULL DEFAULT 0,
    pos_type TEXT NOT NULL DEFAULT 'manual_fallback',
    sink TEXT NOT NULL DEFAULT 'manual',
    staff_phone TEXT,
    inbound_phone TEXT UNIQUE,
    active INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS menu_version (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    restaurant_id TEXT NOT NULL REFERENCES restaurant(id),
    version INTEGER NOT NULL,
    yaml TEXT NOT NULL,
    yaml_sha256 TEXT NOT NULL,
    item_count INTEGER NOT NULL,
    published_by TEXT,
    published_at TEXT NOT NULL,
    is_live INTEGER NOT NULL DEFAULT 0,
    UNIQUE (restaurant_id, version)
);
CREATE UNIQUE INDEX IF NOT EXISTS one_live_menu_per_restaurant
    ON menu_version (restaurant_id) WHERE is_live = 1;

CREATE TABLE IF NOT EXISTS availability_override (
    restaurant_id TEXT NOT NULL REFERENCES restaurant(id),
    target_kind TEXT NOT NULL CHECK (target_kind IN ('item','option')),
    target_id TEXT NOT NULL,
    available INTEGER NOT NULL,
    reason TEXT,
    set_by TEXT,
    set_at TEXT NOT NULL,
    expires_at TEXT,
    PRIMARY KEY (restaurant_id, target_kind, target_id)
);

CREATE TABLE IF NOT EXISTS restaurant_control (
    restaurant_id TEXT PRIMARY KEY REFERENCES restaurant(id),
    weekly_hours TEXT NOT NULL DEFAULT '{}',
    holiday_closures TEXT NOT NULL DEFAULT '[]',
    prep_minutes INTEGER NOT NULL DEFAULT 20 CHECK (prep_minutes >= 0),
    wait_minutes INTEGER NOT NULL DEFAULT 0 CHECK (wait_minutes >= 0),
    ai_enabled INTEGER NOT NULL DEFAULT 1,
    languages TEXT NOT NULL DEFAULT '["en"]',
    -- greet a returning caller by name and offer their last order (see
    -- CALL_SOUND_GUIDE.md "Remembering callers"); the owner's switch
    remember_callers INTEGER NOT NULL DEFAULT 1,
    updated_by TEXT,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS reservation (
    id TEXT PRIMARY KEY,
    restaurant_id TEXT NOT NULL REFERENCES restaurant(id),
    guest_name TEXT NOT NULL, guest_phone TEXT NOT NULL,
    party_size INTEGER NOT NULL CHECK (party_size BETWEEN 1 AND 100),
    reserved_at TEXT NOT NULL, notes TEXT,
    status TEXT NOT NULL CHECK (status IN ('requested','confirmed','declined','cancelled','seated','completed')),
    created_at TEXT NOT NULL, updated_at TEXT
);

CREATE TABLE IF NOT EXISTS reservation_reference (
    reservation_id TEXT PRIMARY KEY REFERENCES reservation(id) ON DELETE CASCADE,
    confirmation_code TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS reservation_policy (
    restaurant_id TEXT PRIMARY KEY REFERENCES restaurant(id),
    enabled INTEGER NOT NULL DEFAULT 0,
    mode TEXT NOT NULL DEFAULT 'request_only'
        CHECK (mode IN ('request_only')),
    max_party_size INTEGER NOT NULL DEFAULT 12 CHECK (max_party_size BETWEEN 1 AND 100),
    min_notice_minutes INTEGER NOT NULL DEFAULT 60 CHECK (min_notice_minutes >= 0),
    max_advance_days INTEGER NOT NULL DEFAULT 90 CHECK (max_advance_days BETWEEN 1 AND 365),
    updated_by TEXT,
    updated_at TEXT NOT NULL
);
INSERT OR IGNORE INTO schema_migration (version, name, applied_at)
VALUES (2, 'reservation request workflow', CURRENT_TIMESTAMP);

CREATE TABLE IF NOT EXISTS session (
    id TEXT PRIMARY KEY,
    restaurant_id TEXT NOT NULL REFERENCES restaurant(id),
    menu_version_id INTEGER NOT NULL REFERENCES menu_version(id),
    channel TEXT NOT NULL CHECK (channel IN ('voice','sms','web','manual')),
    external_id TEXT UNIQUE,
    caller_phone TEXT,
    started_at TEXT NOT NULL,
    ended_at TEXT,
    end_reason TEXT,
    cart TEXT,
    escalated_at TEXT,
    escalation_reason TEXT
);

CREATE TABLE IF NOT EXISTS voice_usage (
    session_id TEXT PRIMARY KEY REFERENCES session(id),
    provider TEXT NOT NULL,
    processed_characters INTEGER NOT NULL DEFAULT 0 CHECK (processed_characters >= 0),
    transcribed_audio_ms INTEGER NOT NULL DEFAULT 0 CHECK (transcribed_audio_ms >= 0),
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS turn (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL REFERENCES session(id) ON DELETE CASCADE,
    seq INTEGER NOT NULL,
    speaker TEXT NOT NULL CHECK (speaker IN ('caller','agent','system')),
    text TEXT,
    asr_confidence REAL,
    intent TEXT,
    engine_issue_code TEXT,
    latency_ms INTEGER,
    created_at TEXT NOT NULL,
    UNIQUE (session_id, seq)
);

CREATE TABLE IF NOT EXISTS "order" (
    id TEXT PRIMARY KEY,
    restaurant_id TEXT NOT NULL REFERENCES restaurant(id),
    session_id TEXT REFERENCES session(id),
    menu_version_id INTEGER NOT NULL REFERENCES menu_version(id),
    short_code TEXT NOT NULL,
    channel TEXT NOT NULL CHECK (channel IN ('voice','sms','web','manual')),
    customer_name TEXT,
    customer_phone TEXT,
    fulfilment TEXT NOT NULL DEFAULT 'pickup',
    snapshot TEXT NOT NULL,
    subtotal_cents INTEGER NOT NULL CHECK (subtotal_cents >= 0),
    tax_cents INTEGER NOT NULL CHECK (tax_cents >= 0),
    total_cents INTEGER NOT NULL CHECK (total_cents >= 0),
    status TEXT NOT NULL DEFAULT 'placed'
        CHECK (status IN ('placed','sent','acknowledged','ready','completed',
                          'cancelled','failed')),
    placed_at TEXT NOT NULL,
    UNIQUE (restaurant_id, short_code)
);

-- One call, one order. A replayed telephony webhook re-enters the same
-- session, and without this the kitchen cooks the order twice.
CREATE UNIQUE INDEX IF NOT EXISTS one_order_per_session
    ON "order" (session_id) WHERE session_id IS NOT NULL;

CREATE TRIGGER IF NOT EXISTS order_immutable
BEFORE UPDATE OF snapshot, subtotal_cents, tax_cents, total_cents,
                 menu_version_id ON "order"
BEGIN
    SELECT RAISE(ABORT, 'order is immutable: cancel it and place a new one');
END;

CREATE TABLE IF NOT EXISTS order_delivery (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id TEXT NOT NULL REFERENCES "order"(id),
    sink TEXT NOT NULL,
    attempt INTEGER NOT NULL DEFAULT 1,
    status TEXT NOT NULL CHECK (status IN ('pending','sent','acknowledged',
                                           'failed','abandoned')),
    external_ref TEXT,
    error_kind TEXT,
    error_detail TEXT,
    acknowledged_by TEXT,
    sent_at TEXT,
    acknowledged_at TEXT,
    created_at TEXT NOT NULL,
    UNIQUE (order_id, sink, attempt)
);

CREATE TABLE IF NOT EXISTS payment (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id TEXT NOT NULL UNIQUE REFERENCES "order"(id),
    collected_by TEXT NOT NULL DEFAULT 'restaurant_pos'
        CHECK (collected_by = 'restaurant_pos'),
    method TEXT NOT NULL CHECK (method IN ('pay_link','at_pickup','unknown')),
    status TEXT NOT NULL DEFAULT 'not_required'
        CHECK (status IN ('not_required','link_pending','link_sent','paid',
                          'expired','failed','refunded')),
    amount_cents INTEGER NOT NULL CHECK (amount_cents >= 0),
    pay_url TEXT CHECK (pay_url IS NULL OR pay_url LIKE 'https://%'),
    pay_url_expires_at TEXT,
    pos_payment_ref TEXT,
    provider_link_ref TEXT,
    link_sent_at TEXT,
    settled_at TEXT,
    updated_at TEXT NOT NULL
);
-- Every cart-changing tool call, in order. If the server restarts mid-call the
-- cart is rebuilt by replaying these against the same menu version.
CREATE TABLE IF NOT EXISTS call_journal (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL REFERENCES session(id) ON DELETE CASCADE,
    seq INTEGER NOT NULL,
    tool TEXT NOT NULL,
    args TEXT NOT NULL,
    created_at TEXT NOT NULL,
    UNIQUE (session_id, seq)
);
INSERT OR IGNORE INTO schema_migration (version, name, applied_at)
VALUES (4, 'call journal for mid-call resume', CURRENT_TIMESTAMP);
-- What the matcher heard and chose (accuracy log; never read by the call path).
CREATE TABLE IF NOT EXISTS resolution (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL REFERENCES session(id) ON DELETE CASCADE,
    restaurant_id TEXT NOT NULL,
    tool TEXT NOT NULL,
    kind TEXT NOT NULL CHECK (kind IN ('item', 'option', 'size')),
    heard TEXT NOT NULL,
    outcome TEXT NOT NULL CHECK (outcome IN ('matched', 'ambiguous', 'no_match')),
    resolved_id TEXT,
    resolved_name TEXT,
    score REAL,
    runner_up_id TEXT,
    runner_up_name TEXT,
    runner_up_score REAL,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS resolution_restaurant_outcome
    ON resolution (restaurant_id, outcome, created_at DESC);
INSERT OR IGNORE INTO schema_migration (version, name, applied_at)
VALUES (5, 'resolution log', CURRENT_TIMESTAMP);

-- The per-location subscription plan (PRICING_PLANS_2026-09-23.md). One row
-- per location; a missing row means Small, the launch default. The monthly
-- minute allowance is the controlling limit; the daily-call figure is a
-- usage-review signal, never a cutoff — see cost_control.PLANS.
CREATE TABLE IF NOT EXISTS location_plan (
    restaurant_id TEXT PRIMARY KEY REFERENCES restaurant(id) ON DELETE CASCADE,
    plan TEXT NOT NULL CHECK (plan IN ('small','medium','grande')),
    updated_at TEXT NOT NULL
);
INSERT OR IGNORE INTO schema_migration (version, name, applied_at)
VALUES (6, 'per-location plan storage', CURRENT_TIMESTAMP);

-- Subscription billing (billing.py). Cherry never touches a restaurant's
-- money; this records what each location OWES Cherry, so invoices can be
-- created in QuickBooks (card or ACH) from one reviewed export. Amounts are
-- whole cents, dates are ISO text. An invoice is never edited: it is voided.
-- Amounts are before tax: QuickBooks applies the tax code.
CREATE TABLE IF NOT EXISTS billing_contract (
    restaurant_id TEXT PRIMARY KEY REFERENCES restaurant(id) ON DELETE CASCADE,
    customer TEXT NOT NULL,
    billing_email TEXT,
    plan TEXT NOT NULL CHECK (plan IN ('small','medium','large')),
    term TEXT NOT NULL CHECK (term IN ('monthly','annual')),
    starts_on TEXT NOT NULL,
    bill_from TEXT,
    ends_on TEXT,
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','paused','cancelled')),
    multi_location INTEGER NOT NULL DEFAULT 0,
    onboarding_fee_cents INTEGER CHECK (onboarding_fee_cents IS NULL OR onboarding_fee_cents >= 0),
    price_override_cents INTEGER CHECK (price_override_cents IS NULL OR price_override_cents >= 0),
    notes TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS invoice (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    number TEXT NOT NULL UNIQUE,
    restaurant_id TEXT NOT NULL REFERENCES restaurant(id),
    customer TEXT NOT NULL,
    plan TEXT NOT NULL,
    term TEXT NOT NULL,
    period_start TEXT NOT NULL,
    period_end TEXT NOT NULL,
    issued_on TEXT NOT NULL,
    due_on TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'issued' CHECK (status IN ('issued','exported','void')),
    total_cents INTEGER NOT NULL CHECK (total_cents >= 0),
    memo TEXT,
    exported_at TEXT,
    void_reason TEXT,
    created_at TEXT NOT NULL,
    UNIQUE (restaurant_id, period_start)
);
CREATE TABLE IF NOT EXISTS invoice_line (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    invoice_id INTEGER NOT NULL REFERENCES invoice(id) ON DELETE CASCADE,
    seq INTEGER NOT NULL,
    kind TEXT NOT NULL CHECK (kind IN ('subscription','onboarding','adjustment')),
    item TEXT NOT NULL,
    description TEXT NOT NULL,
    quantity INTEGER NOT NULL DEFAULT 1,
    unit_cents INTEGER NOT NULL,
    amount_cents INTEGER NOT NULL,
    UNIQUE (invoice_id, seq)
);
CREATE TABLE IF NOT EXISTS billing_adjustment (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    restaurant_id TEXT NOT NULL REFERENCES restaurant(id),
    amount_cents INTEGER NOT NULL CHECK (amount_cents <> 0),
    memo TEXT NOT NULL,
    created_at TEXT NOT NULL,
    applied_invoice_id INTEGER REFERENCES invoice(id)
);
CREATE INDEX IF NOT EXISTS invoice_period ON invoice (period_start, status);
INSERT OR IGNORE INTO schema_migration (version, name, applied_at)
VALUES (8, 'subscription billing', CURRENT_TIMESTAMP);

CREATE TABLE IF NOT EXISTS order_release (
    order_id TEXT PRIMARY KEY REFERENCES "order"(id),
    status TEXT NOT NULL CHECK (status IN ('claimed','sent')),
    claimed_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sms_message (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    restaurant_id TEXT REFERENCES restaurant(id),
    order_id TEXT REFERENCES "order"(id),
    session_id TEXT REFERENCES session(id),
    direction TEXT NOT NULL CHECK (direction IN ('out','in')),
    to_phone TEXT NOT NULL,
    from_phone TEXT,
    kind TEXT NOT NULL CHECK (kind IN ('ticket','pay_link','confirmation',
                                       'ready','escalation','reply')),
    body TEXT NOT NULL,
    provider_ref TEXT,
    status TEXT NOT NULL DEFAULT 'queued'
        CHECK (status IN ('queued','sent','delivered','failed')),
    error_detail TEXT,
    created_at TEXT NOT NULL
);

-- Numbers that must never be texted again.
--
-- A caller who replies STOP has opted out, and texting them after that is a
-- carrier violation, not a preference we get to weigh. Telnyx reports the
-- block ASYNCHRONOUSLY (error 40300 on the message webhook, not in the send
-- response), so by the time we hear about it the message has already gone.
-- That is exactly why this list exists: the only way to honour an opt-out is
-- to remember it and check BEFORE sending.
CREATE TABLE IF NOT EXISTS sms_suppression (
    phone TEXT PRIMARY KEY,
    reason TEXT NOT NULL,
    source TEXT NOT NULL,       -- inbound_stop | provider_error | manual
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS event (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    restaurant_id TEXT REFERENCES restaurant(id),
    session_id TEXT REFERENCES session(id),
    order_id TEXT REFERENCES "order"(id),
    kind TEXT NOT NULL,
    detail TEXT,
    created_at TEXT NOT NULL
);

-- Provider event ids are stable across retries. Claiming one before applying
-- it prevents a replay from duplicating inbound messages or opt-out events.
CREATE TABLE IF NOT EXISTS webhook_receipt (
    provider TEXT NOT NULL,
    event_id TEXT NOT NULL,
    event_type TEXT,
    received_at TEXT NOT NULL,
    PRIMARY KEY (provider, event_id)
);
"""


class OrderStore:
    """Repository over the schema. One instance per process.

    SQLite connections are thread-affine here even though the store itself is
    shared by ``ThreadingHTTPServer``.  Sharing one connection between request
    threads can corrupt cursor state (including read-only queries) and has
    caused interpreter crashes under concurrent calls.  ``sqlite()`` therefore
    keeps one connection per thread, backed by the same file or shared-memory
    database.
    """

    def __init__(self, conn: Any = None, *,
                 sqlite_target: Optional[str] = None,
                 sqlite_uri: bool = False,
                 temp_dir: Any = None,
                 postgres_pool: Any = None) -> None:
        self._anchor_conn = conn
        self._sqlite_target = sqlite_target
        self._sqlite_uri = sqlite_uri
        self._postgres_pool = postgres_pool
        self._postgres_reader = (_PostgresReader(postgres_pool)
                                 if postgres_pool is not None else None)
        # Keeps an ephemeral on-disk database alive for stores requested as
        # ``:memory:``. A real file supports WAL; SQLite shared-cache memory
        # databases do not, and can raise SQLITE_LOCKED under ordinary reads.
        self._temp_dir = temp_dir
        self._thread_connections = threading.local()
        if conn is not None:
            self._thread_connections.conn = conn
            conn.row_factory = sqlite3.Row
        # The server serves each request on its own thread, so writes from two
        # calls can overlap. SQLite serialises writers anyway; this lock keeps
        # a transaction from interleaving with another thread's, which is what
        # turns "slow" into "wrong". Postgres does not need it — the real
        # deployment gets a connection per request from a pool.
        self._write_lock = threading.RLock()

    @property
    def conn(self) -> Any:
        """The connection owned by the current request thread."""
        if self._postgres_reader is not None:
            return self._postgres_reader
        conn = getattr(self._thread_connections, "conn", None)
        if conn is not None:
            return conn
        if self._sqlite_target is None:
            # Reserved for a future non-SQLite DB-API constructor.  Such a
            # connector should supply its own per-request pooling policy.
            return self._anchor_conn
        conn = sqlite3.connect(
            self._sqlite_target, uri=self._sqlite_uri,
            check_same_thread=False, timeout=30.0)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        self._thread_connections.conn = conn
        return conn

    @classmethod
    def sqlite(cls, path: str = ":memory:") -> "OrderStore":
        temp_dir = None
        if path == ":memory:":
            # Use an ephemeral file rather than SQLite shared-cache memory.
            # The file is still private to this store and automatically
            # removed, but it supports WAL and one connection per thread.
            temp_dir = tempfile.TemporaryDirectory(prefix="cherry-sqlite-")
            target = str(Path(temp_dir.name) / "store.db")
            uri = False
        else:
            target = str(path)
            uri = False
        conn = sqlite3.connect(target, uri=uri, check_same_thread=False,
                               timeout=30.0)
        conn.row_factory = sqlite3.Row
        conn.executescript(SQLITE_SCHEMA)
        # CREATE TABLE IF NOT EXISTS cannot add a column to a pilot database
        # created by an older build. This additive migration preserves every
        # existing order and its evidence trail.
        payment_columns = {
            row["name"] for row in conn.execute("PRAGMA table_info(payment)")
        }
        if "provider_link_ref" not in payment_columns:
            conn.execute("ALTER TABLE payment ADD COLUMN provider_link_ref TEXT")
        control_columns = {
            row["name"] for row in conn.execute("PRAGMA table_info(restaurant_control)")
        }
        if "remember_callers" not in control_columns:
            conn.execute("ALTER TABLE restaurant_control ADD COLUMN "
                         "remember_callers INTEGER NOT NULL DEFAULT 1")
        conn.execute("""INSERT OR IGNORE INTO schema_migration
            (version,name,applied_at) VALUES
            (7,'per-restaurant caller memory switch',CURRENT_TIMESTAMP)""")
        conn.execute("""INSERT OR IGNORE INTO schema_migration
            (version,name,applied_at) VALUES
            (3,'payment-gated POS release',CURRENT_TIMESTAMP)""")
        # WAL lets a reader run while a writer commits — without it, a second
        # caller's read blocks behind the first caller's write.
        try:
            conn.execute("PRAGMA journal_mode=WAL")
        except sqlite3.Error:
            pass                    # an in-memory database cannot use WAL
        conn.commit()
        return cls(conn, sqlite_target=target, sqlite_uri=uri,
                   temp_dir=temp_dir)

    @classmethod
    def postgres(cls, dsn: str, *, min_size: int = 1, max_size: int = 10,
                 bootstrap: bool = False, timeout: float = 10.0) -> "OrderStore":
        """Create a production store backed by a bounded psycopg pool.

        The dependency is optional so local SQLite development remains a
        two-package install. Production installs ``requirements-postgres.txt``.
        """
        if not dsn.startswith(("postgres://", "postgresql://")):
            raise ValueError("Postgres DSN must start with postgres:// or postgresql://")
        if min_size < 1 or max_size < min_size:
            raise ValueError("pool sizes must satisfy 1 <= min_size <= max_size")
        try:
            from psycopg.rows import dict_row
            from psycopg_pool import ConnectionPool
        except ImportError as exc:
            raise RuntimeError(
                "Postgres support is not installed; install "
                "requirements-postgres.txt") from exc

        pool = ConnectionPool(
            conninfo=dsn, min_size=min_size, max_size=max_size,
            timeout=timeout, kwargs={"row_factory": dict_row},
            configure=_configure_postgres_connection, open=True,
            # Test each connection as it is handed out. Without this, the
            # first requests after a database restart or failover get dead
            # sockets from the pool and fail live calls until it recycles.
            check=ConnectionPool.check_connection)
        try:
            pool.wait(timeout=timeout)
            if bootstrap:
                schema = (HERE / "db" / "schema.sql").read_text()
                with pool.connection() as connection:
                    connection.execute(schema)
                    connection.commit()
        except Exception:
            pool.close()
            raise
        return cls(postgres_pool=pool)

    @classmethod
    def open(cls, target: str = ":memory:", **postgres_options) -> "OrderStore":
        """Open SQLite paths locally or Postgres URLs in production."""
        if target.startswith(("postgres://", "postgresql://")):
            return cls.postgres(target, **postgres_options)
        if postgres_options:
            unsupported = ", ".join(sorted(postgres_options))
            raise ValueError(f"Postgres-only option(s) for SQLite: {unsupported}")
        return cls.sqlite(target)

    def close(self) -> None:
        if self._postgres_pool is not None:
            self._postgres_pool.close()
            return
        connections = {self._anchor_conn,
                       getattr(self._thread_connections, "conn", None)}
        for connection in connections:
            if connection is not None:
                connection.close()

    def _json_param(self, value: Any) -> Any:
        if self._postgres_pool is not None:
            from psycopg.types.json import Jsonb
            return Jsonb(value)
        return json.dumps(value, sort_keys=True)

    @contextmanager
    def tx(self):
        if self._postgres_pool is not None:
            with self._postgres_pool.connection() as connection:
                with connection.transaction():
                    yield _PostgresConnection(connection)
            return
        with self._write_lock:
            try:
                yield self.conn
                self.conn.commit()
            except Exception:
                self.conn.rollback()
                raise

    # -- restaurants ----------------------------------------------------

    def upsert_restaurant(self, id: str, name: str, cuisine: str, *,
                          tax_rate_bps: int = 0, pos_type: str = "manual_fallback",
                          sink: str = "manual", staff_phone: Optional[str] = None,
                          inbound_phone: Optional[str] = None,
                          timezone_name: str = "America/Detroit",
                          active: bool = False) -> None:
        with self.tx() as c:
            c.execute("""
                INSERT INTO restaurant (id, name, cuisine, timezone, tax_rate_bps,
                                        pos_type, sink, staff_phone, inbound_phone,
                                        active, created_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(id) DO UPDATE SET
                    name=excluded.name, cuisine=excluded.cuisine,
                    timezone=excluded.timezone, tax_rate_bps=excluded.tax_rate_bps,
                    pos_type=excluded.pos_type, sink=excluded.sink,
                    staff_phone=excluded.staff_phone,
                    inbound_phone=excluded.inbound_phone, active=excluded.active
            """, (id, name, cuisine, timezone_name, tax_rate_bps, pos_type, sink,
                  staff_phone, inbound_phone, bool(active), _now()))

    def restaurant(self, id: str) -> Optional[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM restaurant WHERE id=?", (id,)).fetchone()

    def restaurant_for_number(self, inbound_phone: str) -> Optional[sqlite3.Row]:
        """Telephony entry point: the dialled number picks the restaurant."""
        return self.conn.execute(
            "SELECT * FROM restaurant WHERE inbound_phone=?",
            (inbound_phone,)).fetchone()

    # -- menu versions --------------------------------------------------

    def publish_menu(self, restaurant_id: str, yaml_text: str, *,
                     item_count: int, published_by: str = "cli",
                     go_live: bool = True) -> int:
        """Publish a new version. Never updates a previous one.

        Republishing identical YAML returns the existing version rather than
        creating a duplicate — menu publishes get re-run, and a version
        history full of identical rows makes the real edits impossible to see.
        """
        sha = hashlib.sha256(yaml_text.encode()).hexdigest()
        existing = self.conn.execute(
            "SELECT id FROM menu_version WHERE restaurant_id=? AND yaml_sha256=?",
            (restaurant_id, sha)).fetchone()
        if existing:
            if go_live:
                self._set_live(restaurant_id, existing["id"])
            return int(existing["id"])
        with self.tx() as c:
            row = c.execute(
                "SELECT COALESCE(MAX(version),0)+1 AS v FROM menu_version "
                "WHERE restaurant_id=?", (restaurant_id,)).fetchone()
            version = int(row["v"])
            cur = c.execute("""
                INSERT INTO menu_version (restaurant_id, version, yaml,
                    yaml_sha256, item_count, published_by, published_at, is_live)
                VALUES (?,?,?,?,?,?,?,FALSE)
            """, (restaurant_id, version, yaml_text, sha, item_count,
                  published_by, _now()))
            new_id = int(cur.lastrowid)
        if go_live:
            self._set_live(restaurant_id, new_id)
        return new_id

    def _set_live(self, restaurant_id: str, menu_version_id: int) -> None:
        with self.tx() as c:
            c.execute("UPDATE menu_version SET is_live=FALSE WHERE restaurant_id=?",
                      (restaurant_id,))
            c.execute("UPDATE menu_version SET is_live=TRUE WHERE id=?",
                      (menu_version_id,))

    def live_menu(self, restaurant_id: str) -> Optional[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM menu_version WHERE restaurant_id=? AND is_live=TRUE",
            (restaurant_id,)).fetchone()

    def menu_version(self, menu_version_id: int) -> Optional[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM menu_version WHERE id=?", (menu_version_id,)).fetchone()

    def activate_menu_version(self, restaurant_id: str,
                              menu_version_id: int, *, by: str = "operator") -> None:
        """Rollback/roll-forward to an immutable version, with an audit event."""
        row = self.menu_version(menu_version_id)
        if row is None or row["restaurant_id"] != restaurant_id:
            raise ValueError("menu version does not belong to restaurant")
        self._set_live(restaurant_id, menu_version_id)
        self.log_event("menu.activated", restaurant_id=restaurant_id,
                       detail={"menu_version_id": menu_version_id, "by": by})

    # -- availability ---------------------------------------------------

    def set_availability(self, restaurant_id: str, target_id: str,
                         available: bool, *, kind: str = "item",
                         reason: str = "", set_by: str = "staff",
                         expires_at: Optional[str] = None) -> None:
        with self.tx() as c:
            c.execute("""
                INSERT INTO availability_override
                    (restaurant_id, target_kind, target_id, available, reason,
                     set_by, set_at, expires_at)
                VALUES (?,?,?,?,?,?,?,?)
                ON CONFLICT(restaurant_id, target_kind, target_id) DO UPDATE SET
                    available=excluded.available, reason=excluded.reason,
                    set_by=excluded.set_by, set_at=excluded.set_at,
                    expires_at=excluded.expires_at
            """, (restaurant_id, kind, target_id, bool(available), reason,
                  set_by, _now(), expires_at))

    def availability_overrides(self, restaurant_id: str) -> Dict[str, set]:
        """{'item': {ids off}, 'option': {ids off}}, ignoring expired rows."""
        now = _now()
        rows = self.conn.execute("""
            SELECT target_kind, target_id FROM availability_override
            WHERE restaurant_id=? AND available=FALSE
              AND (expires_at IS NULL OR expires_at > ?)
        """, (restaurant_id, now)).fetchall()
        out = {"item": set(), "option": set()}
        for r in rows:
            out[r["target_kind"]].add(r["target_id"])
        return out

    def load_live_config(self, restaurant_id: str):
        """The live menu with tonight's 86s applied — what a call should use.

        Menu and availability are stored apart on purpose: the menu is what
        the restaurant sells, the overrides are what they ran out of at 7pm.
        Joining them belongs here, at load time, not in either source.
        """
        from restaurants import apply_availability

        mv = self.live_menu(restaurant_id)
        if mv is None:
            raise LookupError(f"no live menu for {restaurant_id}")
        cfg = _parsed_menu(mv["yaml"])
        off = self.availability_overrides(restaurant_id)
        if off["item"] or off["option"]:
            cfg = apply_availability(cfg, frozenset(off["item"]),
                                     frozenset(off["option"]))
        return cfg, int(mv["id"])

    # -- sessions -------------------------------------------------------

    def start_session(self, restaurant_id: str, menu_version_id: int, *,
                      channel: str = "voice", external_id: Optional[str] = None,
                      caller_phone: Optional[str] = None) -> str:
        """Idempotent on external_id — a replayed Telnyx webhook must not
        create a second session for the same call."""
        if external_id:
            row = self.conn.execute(
                "SELECT id FROM session WHERE external_id=?",
                (external_id,)).fetchone()
            if row:
                return str(row["id"])
        sid = str(uuid.uuid4())
        with self.tx() as c:
            c.execute("""
                INSERT INTO session (id, restaurant_id, menu_version_id, channel,
                                     external_id, caller_phone, started_at)
                VALUES (?,?,?,?,?,?,?)
            """, (sid, restaurant_id, menu_version_id, channel, external_id,
                  caller_phone, _now()))
        return sid

    def journal_tool(self, session_id: str, tool: str, args: dict) -> None:
        """Append one cart-changing tool call so a restart can replay it."""
        with self.tx() as c:
            row = c.execute("SELECT COALESCE(MAX(seq),0)+1 AS s FROM call_journal "
                            "WHERE session_id=?", (session_id,)).fetchone()
            c.execute("INSERT INTO call_journal (session_id, seq, tool, args, created_at) "
                      "VALUES (?,?,?,?,?)",
                      (session_id, int(row["s"]), tool, self._json_param(args), _now()))

    def record_resolution(self, session_id: str, r: dict) -> None:
        """Log one matcher decision. Best effort: never raises into a call."""
        row = self.conn.execute("SELECT restaurant_id FROM session WHERE id=?",
                                (session_id,)).fetchone()
        if row is None:
            return
        with self.tx() as c:
            c.execute("""INSERT INTO resolution (session_id, restaurant_id, tool, kind,
                         heard, outcome, resolved_id, resolved_name, score,
                         runner_up_id, runner_up_name, runner_up_score, created_at)
                         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                      (session_id, row["restaurant_id"], r["tool"], r["kind"],
                       str(r["heard"])[:500], r["outcome"], r.get("resolved_id"),
                       r.get("resolved_name"), r.get("score"), r.get("runner_up_id"),
                       r.get("runner_up_name"), r.get("runner_up_score"), _now()))

    def unresolved(self, restaurant_id: str, limit: int = 50):
        """Phrases callers used that matched nothing, most frequent first."""
        return [dict(r) for r in self.conn.execute(
            """SELECT heard, COUNT(*) AS n FROM resolution
               WHERE restaurant_id=? AND outcome='no_match'
               GROUP BY heard ORDER BY n DESC, heard LIMIT ?""",
            (restaurant_id, limit)).fetchall()]

    def confusions(self, restaurant_id: str, limit: int = 50):
        """Pairs of dishes callers could not tell apart, most frequent first."""
        return [dict(r) for r in self.conn.execute(
            """SELECT resolved_id AS a, runner_up_id AS b, COUNT(*) AS n
               FROM resolution WHERE restaurant_id=? AND outcome='ambiguous'
               AND runner_up_id IS NOT NULL
               GROUP BY resolved_id, runner_up_id ORDER BY n DESC LIMIT ?""",
            (restaurant_id, limit)).fetchall()]

    def load_journal(self, session_id: str) -> List[Tuple[str, dict]]:
        rows = self.conn.execute("SELECT tool, args FROM call_journal "
                                 "WHERE session_id=? ORDER BY seq",
                                 (session_id,)).fetchall()
        return [(str(r["tool"]), json_value(r["args"]) or {}) for r in rows]

    def open_session_for_call(self, external_id: str):
        """The unfinished voice session for a telephony call id, if any."""
        return self.conn.execute(
            "SELECT * FROM session WHERE external_id=? AND ended_at IS NULL",
            (external_id,)).fetchone()

    def load_config_for_version(self, restaurant_id: str, menu_version_id: int):
        """The exact menu a call started on (with tonight's 86s applied)."""
        from restaurants import apply_availability
        row = self.conn.execute("SELECT yaml FROM menu_version WHERE id=? "
                                "AND restaurant_id=?",
                                (menu_version_id, restaurant_id)).fetchone()
        if row is None:
            raise LookupError(f"no menu version {menu_version_id}")
        cfg = _parsed_menu(row["yaml"])
        off = self.availability_overrides(restaurant_id)
        if off["item"] or off["option"]:
            cfg = apply_availability(cfg, frozenset(off["item"]),
                                     frozenset(off["option"]))
        return cfg

    def save_cart(self, session_id: str, cart: Any) -> None:
        with self.tx() as c:
            c.execute("UPDATE session SET cart=? WHERE id=?",
                      (self._json_param(cart), session_id))

    def load_cart(self, session_id: str) -> Any:
        row = self.conn.execute("SELECT cart FROM session WHERE id=?",
                                (session_id,)).fetchone()
        return json_value(row["cart"]) if row and row["cart"] else None

    def record_turn(self, session_id: str, speaker: str, text: str, *,
                    seq: Optional[int] = None, asr_confidence: Optional[float] = None,
                    intent: Optional[str] = None,
                    engine_issue_code: Optional[str] = None,
                    latency_ms: Optional[int] = None) -> int:
        with self.tx() as c:
            if seq is None:
                row = c.execute("SELECT COALESCE(MAX(seq),0)+1 AS s FROM turn "
                                "WHERE session_id=?", (session_id,)).fetchone()
                seq = int(row["s"])
            cur = c.execute("""
                INSERT INTO turn (session_id, seq, speaker, text, asr_confidence,
                                  intent, engine_issue_code, latency_ms, created_at)
                VALUES (?,?,?,?,?,?,?,?,?)
            """, (session_id, seq, speaker, text, asr_confidence, intent,
                  engine_issue_code, latency_ms, _now()))
            return int(cur.lastrowid)

    def record_voice_usage(self, external_id: str, *, provider: str,
                           processed_characters: int,
                           transcribed_audio_ms: int) -> None:
        if processed_characters < 0 or transcribed_audio_ms < 0:
            raise ValueError("voice usage cannot be negative")
        row = self.conn.execute(
            "SELECT id,restaurant_id FROM session WHERE external_id=?",
            (external_id,)).fetchone()
        if not row:
            raise LookupError("voice session not found")
        with self.tx() as conn:
            conn.execute("""INSERT INTO voice_usage
              (session_id,provider,processed_characters,transcribed_audio_ms,updated_at)
              VALUES (?,?,?,?,?) ON CONFLICT(session_id) DO UPDATE SET
                provider=excluded.provider,
                processed_characters=CASE WHEN voice_usage.processed_characters > excluded.processed_characters THEN voice_usage.processed_characters ELSE excluded.processed_characters END,
                transcribed_audio_ms=CASE WHEN voice_usage.transcribed_audio_ms > excluded.transcribed_audio_ms THEN voice_usage.transcribed_audio_ms ELSE excluded.transcribed_audio_ms END,
                updated_at=excluded.updated_at""",
              (row["id"], provider, int(processed_characters),
               int(transcribed_audio_ms), _now()))
        self.log_event("voice.usage_updated", restaurant_id=row["restaurant_id"],
                       session_id=row["id"], detail={"provider": provider,
                       "processed_characters": processed_characters,
                       "transcribed_audio_ms": transcribed_audio_ms})

    def end_session(self, session_id: str, reason: str) -> None:
        with self.tx() as c:
            c.execute("UPDATE session SET ended_at=?, end_reason=?, cart=NULL "
                      "WHERE id=?", (_now(), reason, session_id))

    def close_stale_sessions(self, older_than_iso: str) -> int:
        """End voice sessions left open since before ``older_than_iso``.

        A server restart or deploy drops the in-memory calls but leaves their
        rows open, and nothing else ever closes them: two hours later each one
        pages the owner as "call session did not close".
        """
        with self.tx() as c:
            return c.execute(
                "UPDATE session SET ended_at=?, end_reason='timed_out', cart=NULL "
                "WHERE ended_at IS NULL AND channel='voice' AND started_at < ?",
                (_now(), older_than_iso)).rowcount

    def escalate(self, session_id: str, reason: str) -> None:
        with self.tx() as c:
            c.execute("UPDATE session SET escalated_at=?, escalation_reason=? "
                      "WHERE id=?", (_now(), reason, session_id))
        self.log_event("session.escalated", session_id=session_id,
                       detail={"reason": reason})

    def open_sessions(self, restaurant_id: str) -> List[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM session WHERE restaurant_id=? AND ended_at IS NULL",
            (restaurant_id,)).fetchall()

    # -- orders ---------------------------------------------------------

    def place_order(self, restaurant_id: str, menu_version_id: int,
                    snapshot: dict, *, session_id: Optional[str] = None,
                    channel: str = "voice",
                    customer_name: Optional[str] = None,
                    customer_phone: Optional[str] = None,
                    fulfilment: str = "pickup") -> Tuple[str, str]:
        """Store a priced order. Returns (order_id, short_code).

        The snapshot is to_normalized_order() verbatim. It is the record: the
        menu may change tomorrow, and this order must still reprint exactly as
        the kitchen first saw it.
        """
        for key in ("subtotal_cents", "tax_cents", "total_cents", "lines"):
            if key not in snapshot:
                raise ValueError(f"snapshot is missing {key!r} — refusing to "
                                 f"store an order that cannot be reprinted")

        # Idempotent per call. Telnyx retries webhooks, and a retry that
        # placed a second order would have the kitchen cook it twice — which
        # nobody notices until the food is on the pass.
        if session_id:
            prior = self.conn.execute(
                'SELECT id, short_code FROM "order" WHERE session_id=?',
                (session_id,)).fetchone()
            if prior:
                self.log_event("order.duplicate_suppressed",
                               restaurant_id=restaurant_id, order_id=prior["id"],
                               session_id=session_id,
                               detail={"note": "session already has an order"})
                return str(prior["id"]), str(prior["short_code"])

        oid = str(uuid.uuid4())
        # Choosing a free code and inserting it are two steps, so two callers
        # finishing at the same moment can pick the same one. The database's
        # UNIQUE constraint is the real guard: on a collision take a fresh
        # code rather than losing the order.
        for attempt in range(8):
            code = self._short_code(restaurant_id)
            try:
                with self.tx() as c:
                    c.execute("""
                        INSERT INTO "order" (id, restaurant_id, session_id, menu_version_id,
                            short_code, channel, customer_name, customer_phone, fulfilment,
                            snapshot, subtotal_cents, tax_cents, total_cents, status, placed_at)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?, 'placed', ?)
                    """, (oid, restaurant_id, session_id, menu_version_id, code, channel,
                          customer_name, customer_phone, fulfilment,
                          self._json_param(snapshot),
                          int(snapshot["subtotal_cents"]), int(snapshot["tax_cents"]),
                          int(snapshot["total_cents"]), _now()))
                break
            except Exception as exc:                          # noqa: BLE001
                if not _is_unique_violation(exc):
                    raise
                if session_id:
                    prior = self.conn.execute(
                        'SELECT id, short_code FROM "order" WHERE session_id=?',
                        (session_id,)).fetchone()
                    if prior:            # the same call finished twice at once
                        return str(prior["id"]), str(prior["short_code"])
        else:
            raise RuntimeError("could not allocate a unique order code")
        self.log_event("order.placed", restaurant_id=restaurant_id, order_id=oid,
                       detail={"total_cents": snapshot["total_cents"],
                               "channel": channel, "short_code": code})
        return oid, code

    def _short_code(self, restaurant_id: str) -> str:
        """Four digits, unique per restaurant per day's worth of orders.

        Spoken aloud and read off a ticket, so it must be short. Random rather
        than sequential so two restaurants do not both say 'order 1'."""
        for _ in range(50):
            code = f"{random.randint(1000, 9999)}"
            hit = self.conn.execute(
                'SELECT 1 FROM "order" WHERE restaurant_id=? AND short_code=?',
                (restaurant_id, code)).fetchone()
            if not hit:
                return code
        return uuid.uuid4().hex[:6].upper()

    def order(self, order_id: str) -> Optional[sqlite3.Row]:
        return self.conn.execute('SELECT * FROM "order" WHERE id=?',
                                 (order_id,)).fetchone()

    def order_snapshot(self, order_id: str) -> Optional[dict]:
        row = self.order(order_id)
        return json_value(row["snapshot"]) if row else None

    def set_order_status(self, order_id: str, status: str) -> None:
        with self.tx() as c:
            c.execute('UPDATE "order" SET status=? WHERE id=?', (status, order_id))

    def orders_awaiting_kitchen(self, restaurant_id: str) -> List[sqlite3.Row]:
        return self.conn.execute("""
            SELECT * FROM "order" WHERE restaurant_id=?
              AND status IN ('placed','sent') ORDER BY placed_at
        """, (restaurant_id,)).fetchall()

    # -- delivery -------------------------------------------------------

    def record_delivery(self, order_id: str, sink: str, status: str, *,
                        external_ref: Optional[str] = None,
                        error_kind: Optional[str] = None,
                        error_detail: Optional[str] = None) -> int:
        with self.tx() as c:
            row = c.execute("SELECT COALESCE(MAX(attempt),0)+1 AS a FROM "
                            "order_delivery WHERE order_id=? AND sink=?",
                            (order_id, sink)).fetchone()
            cur = c.execute("""
                INSERT INTO order_delivery (order_id, sink, attempt, status,
                    external_ref, error_kind, error_detail, sent_at, created_at)
                VALUES (?,?,?,?,?,?,?,?,?)
            """, (order_id, sink, int(row["a"]), status, external_ref, error_kind,
                  error_detail, _now() if status == "sent" else None, _now()))
            did = int(cur.lastrowid)
        if status == "sent":
            self.set_order_status(order_id, "sent")
        elif status == "failed":
            self.log_event("delivery.failed", order_id=order_id,
                           detail={"sink": sink, "error_kind": error_kind})
        return did

    def acknowledge_delivery(self, order_id: str, by: str) -> bool:
        """A human or a POS confirming the order was actually received.

        This is the difference between 'we sent a text' and 'the kitchen has
        it'. Without it, a fallback order that nobody read looks identical to
        one being cooked."""
        with self.tx() as c:
            cur = c.execute("""
                UPDATE order_delivery SET status='acknowledged',
                    acknowledged_by=?, acknowledged_at=?
                WHERE order_id=? AND status IN ('pending','sent')
            """, (by, _now(), order_id))
            changed = cur.rowcount > 0
        if changed:
            self.set_order_status(order_id, "acknowledged")
            self.log_event("delivery.acknowledged", order_id=order_id,
                           detail={"by": by})
        return changed

    def unacknowledged_orders(self, restaurant_id: str,
                              older_than_iso: Optional[str] = None) -> List[sqlite3.Row]:
        """Orders sent but never confirmed. The thing to alert on."""
        q = """SELECT o.* FROM "order" o
               JOIN order_delivery d ON d.order_id = o.id
               WHERE o.restaurant_id=? AND d.status='sent'"""
        params: List[Any] = [restaurant_id]
        if older_than_iso:
            q += " AND d.sent_at < ?"
            params.append(older_than_iso)
        return self.conn.execute(q + " ORDER BY o.placed_at", params).fetchall()

    # -- sms ------------------------------------------------------------

    def log_sms(self, to_phone: str, body: str, kind: str, *,
                direction: str = "out", restaurant_id: Optional[str] = None,
                order_id: Optional[str] = None, session_id: Optional[str] = None,
                from_phone: Optional[str] = None,
                provider_ref: Optional[str] = None,
                status: str = "queued",
                error_detail: Optional[str] = None) -> int:
        with self.tx() as c:
            cur = c.execute("""
                INSERT INTO sms_message (restaurant_id, order_id, session_id,
                    direction, to_phone, from_phone, kind, body, provider_ref,
                    status, error_detail, created_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
            """, (restaurant_id, order_id, session_id, direction, to_phone,
                  from_phone, kind, body, provider_ref, status, error_detail,
                  _now()))
            return int(cur.lastrowid)

    def suppress(self, phone: str, reason: str, source: str) -> None:
        """Never text this number again."""
        with self.tx() as c:
            c.execute("""INSERT INTO sms_suppression (phone, reason, source,
                         created_at) VALUES (?,?,?,?)
                         ON CONFLICT(phone) DO UPDATE SET reason=excluded.reason,
                         source=excluded.source""",
                      (phone, reason, source, _now()))
        self.log_event("sms.suppressed", detail={"phone": phone,
                                                 "reason": reason,
                                                 "source": source})

    def previous_order_for_caller(self, restaurant_id: str, phone: str,
                                  before: str, since: str):
        """A caller's most recent REAL order at this restaurant, for 'welcome
        back'. Real means paid, or released to the kitchen: an order whose
        checkout link was never paid is not anyone's "usual"."""
        if not phone:
            return None
        return self.conn.execute("""
            SELECT o.id, o.customer_name, o.snapshot, o.placed_at
            FROM "order" o LEFT JOIN payment p ON p.order_id = o.id
            WHERE o.restaurant_id=? AND o.customer_phone=?
              AND o.placed_at <= ? AND o.placed_at >= ?
              AND o.status NOT IN ('cancelled','failed')
              AND (p.status IN ('paid','not_required')
                   OR o.status IN ('sent','acknowledged','ready','completed'))
            ORDER BY o.placed_at DESC LIMIT 1""",
            (restaurant_id, phone, before, since)).fetchone()

    def is_suppressed(self, phone: str) -> bool:
        return self.conn.execute(
            "SELECT 1 FROM sms_suppression WHERE phone=?",
            (phone,)).fetchone() is not None

    def unsuppress(self, phone: str) -> bool:
        """Only for an explicit opt back in (the caller texts START)."""
        with self.tx() as c:
            return c.execute("DELETE FROM sms_suppression WHERE phone=?",
                             (phone,)).rowcount > 0

    def update_sms_status(self, provider_ref: str, status: str,
                          error_detail: Optional[str] = None) -> bool:
        """Apply what the provider later said actually happened.

        A 200 from the send API means 'queued', never 'delivered'. Delivery is
        only known from the webhook, which is why this exists separately from
        log_sms.
        """
        # A late "still in flight" receipt must never undo a final outcome:
        # webhooks arrive out of order, and a failed checkout text that was
        # overwritten with 'sent' is a failure nobody is alerted to.
        guard = " AND status NOT IN ('delivered','failed')" if status == "sent" else ""
        with self.tx() as c:
            return c.execute(
                "UPDATE sms_message SET status=?, error_detail=? "
                "WHERE provider_ref=?" + guard,
                (status, error_detail, provider_ref)).rowcount > 0

    def sms_by_ref(self, provider_ref: str) -> Optional[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM sms_message WHERE provider_ref=?",
            (provider_ref,)).fetchone()

    def messages_for_order(self, order_id: str) -> List[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM sms_message WHERE order_id=? ORDER BY id",
            (order_id,)).fetchall()

    # -- events ---------------------------------------------------------

    def claim_webhook(self, provider: str, event_id: str,
                      event_type: str = "") -> bool:
        """Atomically claim a provider event; false means it is a retry."""
        with self.tx() as c:
            cur = c.execute(
                "INSERT INTO webhook_receipt "
                "(provider, event_id, event_type, received_at) VALUES (?,?,?,?) "
                "ON CONFLICT(provider, event_id) DO NOTHING",
                (provider, event_id, event_type or None, _now()))
            return cur.rowcount == 1

    def release_webhook(self, provider: str, event_id: str) -> None:
        """Release a failed claim so the provider's retry can run it again."""
        with self.tx() as c:
            c.execute("DELETE FROM webhook_receipt WHERE provider=? AND event_id=?",
                      (provider, event_id))

    def log_event(self, kind: str, *, restaurant_id: Optional[str] = None,
                  session_id: Optional[str] = None, order_id: Optional[str] = None,
                  detail: Optional[dict] = None) -> int:
        with self.tx() as c:
            cur = c.execute("""
                INSERT INTO event (restaurant_id, session_id, order_id, kind,
                                   detail, created_at)
                VALUES (?,?,?,?,?,?)
            """, (restaurant_id, session_id, order_id, kind,
                  self._json_param(detail or {}), _now()))
            return int(cur.lastrowid)

    def events(self, kind: Optional[str] = None,
               restaurant_id: Optional[str] = None,
               order_id: Optional[str] = None,
               session_id: Optional[str] = None) -> List[sqlite3.Row]:
        """The audit log. Filter by order for 'what happened to #1234'."""
        q, params = "SELECT * FROM event WHERE 1=1", []
        for col, val in (("kind", kind), ("restaurant_id", restaurant_id),
                         ("order_id", order_id), ("session_id", session_id)):
            if val:
                q += f" AND {col}=?"
                params.append(val)
        return self.conn.execute(q + " ORDER BY id", params).fetchall()
