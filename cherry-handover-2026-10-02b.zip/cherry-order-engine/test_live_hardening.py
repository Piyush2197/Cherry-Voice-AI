#!/usr/bin/env python3
"""Regression tests for the 2026-10-01 live-call and deployability audit.

Every test here pins a defect that was found by reading or running the system
and that would have hurt a live call, a payment, or a deploy. Each docstring
says what used to happen.
"""

from __future__ import annotations

import asyncio
import json
import os
import subprocess
import sys
import tempfile
import threading
import time
import traceback
import types
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

import menu_schema as ms
from order_engine import OrderEngine
from order_store import OrderStore

HERE = Path(__file__).resolve().parent
_passed = _failed = 0


def check(name, condition, detail=""):
    global _passed, _failed
    if condition:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


def run(coro):
    return asyncio.run(coro)


def tamago_store():
    store = OrderStore.sqlite()
    path = HERE / "menus" / "tamago-sushi-bowl.yaml"
    cfg = ms.load_yaml(path)
    store.upsert_restaurant(cfg.id, cfg.name, cfg.cuisine, staff_phone="+13135550100",
                            inbound_phone="+13135550101", active=True)
    mv = store.publish_menu(cfg.id, path.read_text(), item_count=len(cfg.items))
    return store, cfg, mv


# ---------------------------------------------------------------------------
# The caller's conversation
# ---------------------------------------------------------------------------


def _shelby():
    import agent_api
    cfg = ms.load_yaml(HERE / "menus" / "pink-garlic-shelby.yaml")
    return agent_api.CallSession(cfg), cfg


def t_answering_an_item_choice_adds_the_item() -> None:
    """The prompt sends the reply to "chicken or lamb korma?" to `answer`, and
    `answer` said "I'm not sure what that's for", so the caller was stuck."""
    s, _ = _shelby()
    first = s.add_item("korma")
    check("the choice is offered", first["ok"] is False and
          first["needs"]["code"] == "ambiguous_match", str(first.get("needs")))
    r = s.answer("the chicken one")
    check("answer resolves it", r["ok"] is True, str(r))
    check("the chicken korma is on the order",
          any("Chicken Korma" in ln["item_name"] for ln in s.snapshot()["lines"]),
          str(s.snapshot()["lines"]))
    s.answer("medium")                       # its spice question
    again = s.answer("anything")
    check("a second answer with nothing open still refuses",
          again["ok"] is False and again["error"] == "no_open_question", str(again))


def t_an_unclear_item_choice_is_asked_again_not_guessed() -> None:
    s, _ = _shelby()
    s.add_item("korma")
    r = s.answer("the purple one")
    check("no guess", r["ok"] is False and not s.snapshot()["lines"], str(r))
    check("asked again", "Did you want" in r["say"], r["say"])


def t_items_can_be_removed_by_name_not_only_by_hidden_line_id() -> None:
    """The voice model is only given what to say, never line ids, so "take the
    samosa off" could only ever remove the MOST RECENT line."""
    s, cfg = _shelby()
    s.add_item("vegetable samosa")
    s.add_item("garlic naan")
    r = s.remove_item(text="the samosa")
    names = [ln["item_name"] for ln in s.snapshot()["lines"]]
    check("the named item went", r["ok"] and not any("Samosa" in n for n in names), str(names))
    check("the other stayed", any("Naan" in n for n in names), str(names))
    miss = s.remove_item(text="lobster thermidor")
    check("an item that is not on the order is said plainly",
          miss["ok"] is False and miss["error"] == "no_match", str(miss))
    q = s.set_quantity(3, text="naan")
    check("quantity by name", q["ok"] and s.snapshot()["lines"][0]["quantity"] == 3, str(q))


# ---------------------------------------------------------------------------
# Square: totals and credentials
# ---------------------------------------------------------------------------


def t_square_link_total_matches_for_an_order_with_a_paid_addon() -> None:
    """Square ADDS modifier prices to the line's base price; the snapshot's unit
    price already contained them. Every order with a paid add-on was revoked
    as 'differs from the quote' and the caller was transferred."""
    import square_bridge as sq
    s, cfg = _shelby()
    s.add_item("chicken tikka"); s.answer("medium"); s.add_modifier("extra chicken")
    snap = s.snapshot()
    order = sq.build_square_order(snap, "L", tax_rate_bps=cfg.tax_rate_bps)
    li = order["line_items"][0]
    check("base is the dish alone", li["base_price_money"]["amount"] == 1299,
          str(li["base_price_money"]))
    check("the add-on carries its own charge",
          [m["base_price_money"]["amount"] for m in li["modifiers"]
           if "Extra" in m["name"]] == [300], str(li["modifiers"]))
    total = li["base_price_money"]["amount"] + sum(
        m["base_price_money"]["amount"] for m in li["modifiers"])
    check("line sums to the quote", total == snap["subtotal_cents"], f"{total}")


def t_square_credentials_never_cross_merchants() -> None:
    """The process-wide token belongs to ONE merchant. A restaurant with no
    authorization of its own silently used it, sending its customers' money to
    someone else's account."""
    import square_bridge as sq
    saved = dict(os.environ)
    try:
        d = tempfile.mkdtemp()
        os.environ.update({"CHERRY_SECRET_DIR": d, "SQUARE_ACCESS_TOKEN": "GLOBAL",
                           "SQUARE_LOCATION_ID": "GLOC"})
        os.environ.pop("CHERRY_SQUARE_SANDBOX", None)
        os.environ.pop("CHERRY_ALLOW_GLOBAL_SQUARE_TOKEN", None)
        row = {"id": "some-restaurant", "tax_rate_bps": 0}
        try:
            sq.square_checkout_provider_for(row)
            check("production refuses the global token", False)
        except ValueError:
            check("production refuses the global token", True)
        os.environ["CHERRY_SQUARE_SANDBOX"] = "1"
        prov = sq.square_checkout_provider_for(row)
        check("sandbox mode may use it, and targets the sandbox",
              "sandbox" in prov.client.base, prov.client.base)
    finally:
        os.environ.clear(); os.environ.update(saved)


def t_a_transient_square_error_is_retried_once() -> None:
    import square_bridge as sq
    s, cfg = _shelby()
    s.add_item("vegetable samosa")
    snap = s.snapshot()

    class Client:
        location_id = "L"
        calls = 0

        def create_payment_link(self, order, key, **kw):
            Client.calls += 1
            if Client.calls == 1:
                raise sq.SquareError("503", retryable=True, code="503")
            return {"id": "PL", "url": "https://square.link/u/x", "order_id": "O"}

        def retrieve_order(self, oid):
            return {"id": oid, "total_money": {"amount": snap["total_cents"],
                                               "currency": "USD"}}

        def delete_payment_link(self, _): pass

    sq.time.sleep = lambda *_: None
    link = sq.SquareCheckoutProvider(Client()).create_pay_link(
        "oid", snap["total_cents"], None, snapshot=snap,
        context={"short_code": "1", "tax_rate_bps": cfg.tax_rate_bps})
    check("a blip no longer fails the call", Client.calls == 2 and link.pos_ref == "O")


def t_python39_socket_timeouts_are_classified() -> None:
    """socket.timeout is not TimeoutError before Python 3.10, so a slow Square
    or Telnyx escaped as a raw OSError instead of a handled, retryable one."""
    import socket
    import square_bridge as sq
    import telnyx_sms as tx

    def slow(req, timeout=None):
        raise socket.timeout("timed out")

    client = sq.SquareClient("tok", "L", opener=slow)
    try:
        client.post("/v2/x", {})
        check("square classifies the timeout", False)
    except sq.SquareError as exc:
        check("square classifies the timeout", exc.retryable and exc.code == "timeout")
    sender = tx.TelnyxSmsSender("key", "+13135559999", opener=slow)
    try:
        sender.send("+13135550100", "hi")
        check("telnyx classifies the timeout", False)
    except tx.SmsError as exc:
        check("telnyx classifies the timeout", exc.retryable)


def t_a_declined_card_is_an_attempt_not_the_end_of_the_checkout() -> None:
    """A FAILED payment event marked the whole checkout failed, so the guest's
    successful retry on the same link was ignored as 'already paid'."""
    import square_webhook as sw
    store, cfg, mv = tamago_store()
    e = OrderEngine(cfg); e.add_line("tg_edamame")
    oid, _ = store.place_order(cfg.id, mv, e.to_normalized_order())
    now = datetime.now(timezone.utc).isoformat()
    store.conn.execute(
        "INSERT INTO payment (order_id,method,status,amount_cents,pos_payment_ref,updated_at)"
        " VALUES (?,'pay_link','link_sent',530,'sq-pay',?)", (oid, now))
    store.conn.commit()

    def ev(eid, status):
        return {"event_id": eid, "type": "payment.updated", "data": {"object": {"payment": {
            "id": "p-" + eid, "order_id": "sq-pay", "status": status,
            "amount_money": {"amount": 530, "currency": "USD"}}}}}

    check("declined is an attempt",
          sw.handle(store, ev("e1", "FAILED"))["action"] == "attempt_failed")
    status = store.conn.execute("SELECT status FROM payment WHERE order_id=?",
                                (oid,)).fetchone()["status"]
    check("the checkout is still open", status == "link_sent", status)
    check("the retry that succeeds is honoured",
          sw.handle(store, ev("e2", "COMPLETED"))["action"] == "paid")


# ---------------------------------------------------------------------------
# The Inworld event path and the gateway
# ---------------------------------------------------------------------------


class FakeBridge:
    def __init__(self):
        self.calls = []
        self.known = set()

    async def tool_schemas(self):
        return [{"name": n} for n in ("add_item", "answer", "ready_to_place")]

    async def start(self, call_id, *, dialled, caller):
        self.known.add(call_id)
        self.calls.append(("start", call_id, dialled, caller)); return "Hello"

    async def handle_tool_call(self, call_id, tool, body):
        self.calls.append(("tool", call_id, tool, dict(body))); return f"did {tool}"

    async def finish(self, call_id, name):
        self.calls.append(("finish", call_id, name)); return "link sent"

    async def abandon(self, call_id, reason):
        self.calls.append(("abandon", call_id, reason))

    async def request_handoff(self, call_id, dialled=""):
        if call_id not in self.known and not dialled:
            raise LookupError("unknown active call")
        self.calls.append(("handoff", call_id, dialled)); return "connecting"


def _adapter():
    import inworld_adapter as ia
    b = FakeBridge()
    return ia.InworldAdapter(b), b, ia


def t_the_event_path_can_place_an_order() -> None:
    """There was no way to finish a call through /v1/inworld/events: the
    ready_to_place tool only checked readiness and the next call_ended
    abandoned the session, so no order was ever placed."""
    a, b, ia = _adapter()
    out = run(a.handle_payload([
        {"type": "call_started", "call_id": "c", "to": "+12485550111", "from": "+13135550123"},
        {"type": "tool_call", "call_id": "c", "tool": "add_item", "args": {"text": "samosa"}},
        {"type": "tool_call", "call_id": "c", "tool": "ready_to_place"},
    ]))
    check("ready_to_place books the order", ("finish", "c", "") in b.calls, str(b.calls))
    check("the caller hears the checkout line", out["say"] == "link sent", str(out))
    out = run(a.handle_payload({"type": "finish", "call_id": "d", "customer_name": "Sam"}))
    check("an explicit finish event works too", ("finish", "d", "Sam") in b.calls)


def t_event_shapes_are_read_correctly() -> None:
    a, b, ia = _adapter()
    ev = {"type": "tool_call", "call_id": "c", "data": [1, 2],
          "tool": {"name": "add_item", "arguments": {"text": "naan"}}}
    check("an event that merely carries a list is still ONE event",
          len(ia.split_events(ev)) == 1)
    run(a.handle_payload(ev))
    check("arguments nested in the tool object are kept",
          ("tool", "c", "add_item", {"text": "naan"}) in b.calls, str(b.calls))
    check("sip/tel numbers normalise", ia.normalize_number("sip:+12485550111@x.io") == "+12485550111"
          and ia.normalize_number("tel:(248) 555-0111") == "+12485550111")
    check("a withheld caller id is simply unknown",
          ia.normalize_number("anonymous") == "" and ia.normalize_number(None) == "")


def t_a_retried_event_is_not_applied_twice() -> None:
    a, b, ia = _adapter()
    ev = {"type": "tool_call", "call_id": "c", "event_id": "evt-1",
          "tool": "add_item", "args": {"text": "naan"}}
    run(a.handle_payload(ev)); out = run(a.handle_payload(ev))
    check("applied once", sum(1 for c in b.calls if c[0] == "tool") == 1, str(b.calls))
    check("the retry gets the same answer", out["say"] == "did add_item", str(out))


def t_a_refused_event_still_gives_the_caller_something_to_hear() -> None:
    a, b, ia = _adapter()
    out = run(a.handle_payload({"type": "tool_call", "call_id": "c", "tool": "drop_tables"}))
    check("silence is not an answer", out["say"] == ia.RETRY_SAY and not out["ok"], str(out))
    check("and it is attributed to its call",
          out["replies"] == [{"call_id": "c", "say": ia.RETRY_SAY}], str(out["replies"]))


def t_the_gateway_reads_the_dialect_from_its_environment() -> None:
    import voice_gateway as vg
    check("from_env takes the mapping it is given",
          __import__("inworld_adapter").Dialect.from_env(
              {"CHERRY_INWORLD_TYPE_FIELD": "event_type"}).type_field == "event_type")


def t_the_gateway_tolerates_withheld_caller_ids_and_empty_bodies() -> None:
    import voice_gateway as vg
    b = FakeBridge()
    g = vg.Gateway(b, {"+13135550101": "+13135550102"}, "k")
    st, body = run(g.dispatch("POST", "/v1/voice/calls", {
        "call_control_id": "c", "to": "sip:+13135550101@t.example", "from": "anonymous"}))
    check("a blocked caller id no longer refuses the call", st == 200 and body["say"] == "Hello", str((st, body)))
    check("the caller is recorded as unknown", b.calls[0][3] == "", str(b.calls))
    st, _ = run(g.dispatch("POST", "/v1/voice/calls/c/finish", {"customer_name": None}))
    check("a null customer_name is allowed", st == 200)
    st, body = run(g.dispatch("POST", "/v1/voice/calls/zzz/handoff", {}))
    check("a handoff on a call this process knows nothing of speaks, not 404s",
          st == 200 and "can't transfer" in body["say"], str((st, body)))
    st, body = run(g.dispatch("POST", "/v1/voice/calls/zzz/handoff", {"to": "+13135550101"}))
    check("...and routes when told the number", b.calls[-1] == ("handoff", "zzz", "+13135550101"), str(b.calls[-1]))


# ---------------------------------------------------------------------------
# The bridge
# ---------------------------------------------------------------------------


class RecordingTransport:
    def __init__(self, handler=None, delay=0.0):
        self.urls, self.handler, self.delay, self.timeouts = [], handler, delay, []

    async def request(self, method, url, headers, body, timeout):
        self.urls.append(url); self.timeouts.append(timeout)
        if self.delay:
            await asyncio.sleep(self.delay)
        if self.handler:
            return self.handler(method, url, body)
        return 200, {"say": "ok", "ok": True, "placed": True, "awaiting_payment": True}


def t_call_ids_are_url_encoded_to_cherry() -> None:
    from voice.inworld_bridge import CherryBridge
    t = RecordingTransport()
    b = CherryBridge("http://x", "k", transport=t)
    run(b.handle_tool_call("v3:abc/def?x#y z", "add_item", {"text": "a"}))
    check("one path segment", t.urls[0] == "http://x/v1/calls/v3%3Aabc%2Fdef%3Fx%23y%20z/tools/add_item",
          t.urls[0])


def t_finish_gets_a_longer_timeout_than_a_tool_call() -> None:
    """finish books the order, creates and verifies the Square checkout and
    texts it. At the normal 8 s tool timeout the caller was transferred as a
    failure while the order went through and the link was still sent."""
    from voice.inworld_bridge import CherryBridge
    t = RecordingTransport()
    b = CherryBridge("http://x", "k", transport=t)
    run(b.finish("c1", "Sam"))
    check("tool calls use the short timeout", t.timeouts[0] == 8.0, str(t.timeouts))
    check("finish uses the long one", t.timeouts[1] >= 30.0, str(t.timeouts))


def t_two_finishes_at_once_place_one_order() -> None:
    from voice.inworld_bridge import CherryBridge
    t = RecordingTransport(delay=0.3)
    b = CherryBridge("http://x", "k", transport=t)
    out = []
    threads = [threading.Thread(target=lambda: out.append(run(b.finish("c", "Sam"))))
               for _ in range(3)]
    [x.start() for x in threads]; [x.join(20) for x in threads]
    posts = [u for u in t.urls if u.endswith("/finish")]
    check("Cherry saw a single finish", len(posts) == 1, str(t.urls))
    check("every caller got the same words", len(set(out)) == 1 and len(out) == 3, str(out))


def t_a_failed_transfer_can_be_retried_and_survives_checkout() -> None:
    from voice.inworld_bridge import CherryBridge

    attempts = []

    async def handoff(call_id, dialled, reason):
        attempts.append(reason)
        if len(attempts) == 1:
            raise RuntimeError("telnyx 500")

    b = CherryBridge("http://x", "k", transport=RecordingTransport(), handoff=handoff)
    run(b.start("c", dialled="+12485550111"))
    run(b.finish("c", "Sam"))
    check("the dialled number is remembered after checkout", "c" in b._dialled)
    first = run(b.request_handoff("c"))
    second = run(b.request_handoff("c"))
    check("a failed transfer is reported as failed", "could not transfer" in first, first)
    check("and the next request really tries again", len(attempts) == 2 and "connect you" in second,
          str((attempts, second)))


def t_a_rejected_request_does_not_transfer_the_caller() -> None:
    from voice.inworld_bridge import CherryBridge, RETRY_LINE
    moved = []

    async def handoff(*a):
        moved.append(a)

    t = RecordingTransport(lambda m, u, b: (400, {"error": "unknown tool 'x'"})
                           if "/tools/" in u else (200, {"say": "hi", "ok": True}))
    b = CherryBridge("http://x", "k", transport=t, handoff=handoff)
    run(b.start("c", dialled="+12485550111"))
    say = run(b.handle_tool_call("c", "x", {}))
    check("asked to repeat", say == RETRY_LINE, say)
    check("nobody was transferred", not moved, str(moved))
    t.handler = lambda m, u, b: (500, {"error": "boom"})  # now the server itself is down
    run(b.handle_tool_call("c", "add_item", {}))
    check("a real outage still transfers", len(moved) == 1)


# ---------------------------------------------------------------------------
# The server
# ---------------------------------------------------------------------------


def t_tool_arguments_are_type_checked_before_the_engine_sees_them() -> None:
    """A model sending "two" for an integer or null for an optional field
    raised inside the engine; the 500 ended the call in a transfer."""
    import server
    typed = server.Cherry._typed_args
    check("numeric strings become numbers", typed("add_item", {"text": "x", "quantity": "2"})["quantity"] == 2)
    check("null means omitted", typed("add_item", {"text": None}) == {})
    check("junk is refused", typed("add_item", {"text": "x", "quantity": "lots"}) is None)
    check("booleans are not numbers", typed("set_quantity", {"quantity": True}) is None)
    check("below the schema minimum is refused", typed("add_item", {"text": "x", "quantity": 0}) is None)
    check("absurd quantities are refused", typed("add_item", {"text": "x", "quantity": 99999}) is None)


def t_card_numbers_are_scrubbed_from_free_text() -> None:
    import payments
    out = payments.scrub_payment_text("my card is 4111 1111 1111 1111 thanks")
    check("a card number is removed", "4111" not in out and "removed" in out, out)
    check("a phone number is not", payments.scrub_payment_text("313-555-0123") == "313-555-0123")
    check("a long non-card number is not",
          payments.scrub_payment_text("order 1234567890123 please") == "order 1234567890123 please")


def t_opening_hours_mean_what_they_say() -> None:
    """A weekday missing from configured hours meant 'open all day', and any
    typo in the hours was stored and then failed every incoming call."""
    import restaurant_controls as rc
    store, cfg, _ = tamago_store()
    rc.set_controls(store, cfg.id, weekly_hours={"fri": ["11:00", "22:00"]})
    tz = ZoneInfo("America/Detroit")
    fri = rc.service_state(store, cfg.id, now=datetime(2026, 10, 2, 12, 0, tzinfo=tz))
    sat = rc.service_state(store, cfg.id, now=datetime(2026, 10, 3, 12, 0, tzinfo=tz))
    check("open when hours say so", fri["accepting_orders"] is True, str(fri))
    check("closed on a day that is not listed", sat["accepting_orders"] is False, str(sat))
    for bad in ({"funday": ["11:00", "22:00"]}, {"fri": ["11:00"]}, {"fri": ["25:00", "26:00"]}):
        try:
            rc.set_controls(store, cfg.id, weekly_hours=bad)
            check(f"rejects {bad}", False)
        except ValueError:
            check(f"rejects {bad}", True)


def t_reservation_times_are_the_restaurants_local_time() -> None:
    """The model is never told the restaurant's timezone or today's date, so
    a time with no UTC offset was refused outright; a stored UTC time was
    texted to the guest as 23:00 for a 7 pm table."""
    import guest_services as gs
    import server
    check("naive times are read in the restaurant's zone",
          gs._parse_time("2026-10-02T19:00:00", "America/Detroit").utcoffset() == timedelta(hours=-4))
    check("an explicit offset is respected",
          gs._parse_time("2026-10-02T19:00:00+00:00", "America/Detroit").utcoffset() == timedelta(0))
    check("texts show local time",
          server._local_time("2026-10-02T23:00:00+00:00", "America/Detroit") == "Fri Oct 2, 7:00 PM",
          server._local_time("2026-10-02T23:00:00+00:00", "America/Detroit"))
    check("refusals are speakable", "ISO" not in server._reservation_refusal("reservation time must be ISO 8601"))


def t_orphaned_sessions_are_closed() -> None:
    store, cfg, mv = tamago_store()
    old = store.start_session(cfg.id, mv, external_id="old")
    store.conn.execute("UPDATE session SET started_at=? WHERE id=?",
                       ((datetime.now(timezone.utc) - timedelta(hours=3)).isoformat(timespec="seconds"), old))
    store.conn.commit()
    fresh = store.start_session(cfg.id, mv, external_id="fresh")
    n = store.close_stale_sessions((datetime.now(timezone.utc) - timedelta(hours=1)).isoformat(timespec="seconds"))
    check("only the stale one is closed", n == 1 and
          store.conn.execute("SELECT ended_at FROM session WHERE id=?", (fresh,)).fetchone()["ended_at"] is None)


def t_late_receipts_do_not_undo_a_failed_text() -> None:
    store, cfg, mv = tamago_store()
    store.log_sms("+13135550100", "x", "pay_link", provider_ref="m1", status="failed",
                  restaurant_id=cfg.id, error_detail="carrier")
    store.update_sms_status("m1", "sent")
    check("failed stays failed", store.sms_by_ref("m1")["status"] == "failed")
    import telnyx_sms as tx
    check("'opt out' is a STOP", "opt out" in tx._STOP_WORDS)


def t_a_silent_connection_gives_its_slot_back() -> None:
    """64 half-open connections held all 64 slots forever: no real call could
    be served by either service."""
    import socket
    from http.server import BaseHTTPRequestHandler
    from bounded_http import BoundedThreadingHTTPServer

    class H(BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200); self.send_header("Content-Length", "2")
            self.end_headers(); self.wfile.write(b"ok")

        def log_message(self, *a): pass

    srv = BoundedThreadingHTTPServer(("127.0.0.1", 0), H, max_concurrent=1, request_timeout=0.5)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    port = srv.server_address[1]
    stalled = socket.create_connection(("127.0.0.1", port)); stalled.sendall(b"GET / HT")
    time.sleep(0.1)
    t0 = time.time()
    with urllib.request.urlopen(f"http://127.0.0.1:{port}/", timeout=10) as r:
        body = r.read()
    srv.shutdown(); srv.server_close(); stalled.close()
    check("a real request is served once the stalled one times out",
          body == b"ok" and time.time() - t0 < 5, f"{time.time() - t0:.1f}s")


# ---------------------------------------------------------------------------
# Money and OAuth
# ---------------------------------------------------------------------------


class _Resp:
    status = 200

    def __init__(self, body): self.body = body
    def __enter__(self): return self
    def __exit__(self, *_): return False
    def read(self): return json.dumps(self.body).encode()


class _Vault:
    def __init__(self, **kw): self.v = dict(kw)
    def get(self, k): return self.v[k]
    def put(self, k, val): self.v[k] = val


def _oauth(merchant):
    import square_oauth as so
    client = so.SquareOAuthClient("app", "secret", opener=lambda *a, **k: _Resp({
        "access_token": "a", "refresh_token": "r", "expires_at": "2026-12-01T00:00:00Z",
        "merchant_id": merchant}))
    opener = lambda *a, **k: _Resp({"locations": [{"id": "L1", "status": "ACTIVE"}]})
    return so, client, opener


def t_an_oauth_link_works_once() -> None:
    """The link was a reusable seven-day bearer credential: whoever completed
    it chose which Square account receives the restaurant's checkout money."""
    so, client, opener = _oauth("M1")
    store = OrderStore.sqlite()
    store.upsert_restaurant("r1", "R1", "american")
    secret = "s" * 32
    state = so.sign_state(secret, "r1")
    v = _Vault()
    so.complete_authorization(client, v, secret, state=state, code="c", store=store, opener=opener)
    try:
        so.complete_authorization(client, v, secret, state=state, code="c", store=store, opener=opener)
        check("a second use is refused", False)
    except so.OAuthRefreshError as exc:
        check("a second use is refused", "already used" in str(exc), str(exc))
    check("links now expire within two days", so.STATE_TTL_SECONDS <= 2 * 24 * 3600)


def t_an_oauth_link_cannot_swap_the_merchant_account() -> None:
    so, client, opener = _oauth("ATTACKER")
    secret = "s" * 32
    names = so.secret_names("r1")
    v = _Vault(**{names["merchant"]: "OWNER"})
    try:
        so.complete_authorization(client, v, secret, state=so.sign_state(secret, "r1"),
                                  code="c", opener=opener)
        check("a different merchant is refused", False)
    except so.OAuthRefreshError as exc:
        check("a different merchant is refused", "different Square account" in str(exc), str(exc))
    check("and nothing was overwritten", v.v[names["merchant"]] == "OWNER")
    so.complete_authorization(client, v, secret, state=so.sign_state(secret, "r1", rebind=True),
                              code="c", opener=opener)
    check("an intended --rebind link is allowed", v.v[names["merchant"]] == "ATTACKER")


# ---------------------------------------------------------------------------
# Alerts
# ---------------------------------------------------------------------------


def _paid_order(store, cfg, mv):
    e = OrderEngine(cfg); e.add_line("tg_edamame")
    oid, _ = store.place_order(cfg.id, mv, e.to_normalized_order())
    old = (datetime.now(timezone.utc) - timedelta(minutes=30)).isoformat(timespec="seconds")
    store.conn.execute(
        "INSERT INTO payment (order_id,method,status,amount_cents,pos_payment_ref,updated_at,settled_at)"
        " VALUES (?,'pay_link','paid',530,'sq',?,?)", (oid, old, old))
    store.conn.commit()
    return oid


def t_handoff_only_mode_does_not_page_for_every_paid_order() -> None:
    """In the launch mode Cherry never releases a kitchen ticket (Square owns
    the paid order), so 'paid but not released' is normal. It paged CRITICAL
    for every successful order."""
    import ops_monitor as om
    store, cfg, mv = tamago_store()
    _paid_order(store, cfg, mv)
    normal = [a.key for a in om.scan_alerts(store, handoff_only=False)]
    launch = [a.key for a in om.scan_alerts(store, handoff_only=True)]
    check("outside handoff-only it is still an alert", any(k.startswith("paid-not-released") for k in normal))
    check("in handoff-only it is not", not any(k.startswith("paid-not-released") for k in launch), str(launch))


def t_money_anomalies_page_someone() -> None:
    import ops_monitor as om
    store, cfg, mv = tamago_store()
    store.log_event("payment.amount_mismatch", restaurant_id=cfg.id, detail={})
    store.log_event("payment.completed_after_expiry", restaurant_id=cfg.id, detail={})
    keys = [a.key for a in om.scan_alerts(store)]
    check("both raise a critical page", sum(k.startswith("payment-anomaly") for k in keys) == 2, str(keys))


# ---------------------------------------------------------------------------
# Catalog sync
# ---------------------------------------------------------------------------


def _item(i, name, price, avail=True, ref=None):
    return types.SimpleNamespace(id=i, name=name, base_price_cents=price, has_sizes=False,
                                 available=avail, pos_refs={"square_catalog_object_id": ref} if ref else {})


def _pos(name, price, var="", avail=True, oid="X"):
    return {"catalog_object_id": oid, "item_id": "i", "name": name, "variation_name": var,
            "price_cents": price, "currency": "USD", "category_id": None, "available": avail}


def t_catalog_sync_never_writes_one_dishs_price_onto_another() -> None:
    """The name normaliser erased '(Chicken)' / '(Lamb)', so both mapped to
    one key and the nightly job auto-published the wrong price."""
    import catalog_sync as cs
    cfg = types.SimpleNamespace(items=[_item("k_chk", "Korma (Chicken)", 1300),
                                       _item("k_lamb", "Korma (Lamb)", 1500)])
    d = cs.diff_catalog(cfg, [_pos("Korma (Lamb)", 1600, oid="A")])
    prices = [(c.item_id, c.new, c.level) for c in d.changes if c.kind == "price"]
    check("only the lamb korma changes", prices == [("k_lamb", 1600, cs.AUTO)], str(prices))
    loose = cs.diff_catalog(types.SimpleNamespace(items=[_item("a", "Samosa", 400)]),
                            [_pos("Samosa", 900, var="Large", oid="B")])
    check("a name-only match to another variation goes to review",
          all(c.level != cs.AUTO for c in loose.changes if c.kind == "price"), str(loose.changes))


def t_catalog_sync_honours_square_sold_out_per_location() -> None:
    import catalog_sync as cs
    page = [{"type": "ITEM", "id": "I", "item_data": {"name": "Naan", "variations": [{
        "id": "V", "item_variation_data": {"name": "Regular", "price_money": {"amount": 300},
            "location_overrides": [{"location_id": "L1", "sold_out": True},
                                   {"location_id": "L2", "price_money": {"amount": 350}}]}}]}}]
    here = cs.flatten_square_objects(page, "L1")
    other = cs.flatten_square_objects(page, "L2")
    check("sold out here", here[0]["available"] is False)
    check("a different location's price is used there", other[0]["price_cents"] == 350 and other[0]["available"])
    absent = [{"type": "ITEM", "id": "I", "item_data": {"name": "Naan", "variations": [{
        "id": "V", "absent_at_location_ids": ["L1"], "item_variation_data": {"price_money": {"amount": 300}}}]}}]
    check("an item absent at this location is skipped", cs.flatten_square_objects(absent, "L1") == [])


def t_catalog_sync_does_not_undo_a_staff_86() -> None:
    import catalog_sync as cs
    store, cfg, mv = tamago_store()
    store.set_availability(cfg.id, "tg_edamame", False, reason="out tonight", set_by="staff")
    live, _ = store.load_live_config(cfg.id)
    name = live.item("tg_edamame").name
    diff = cs.diff_catalog(live, [_pos(name, live.item("tg_edamame").base_price_cents)])
    applied = cs.apply_auto(store, cfg.id, diff)
    check("the kitchen's 86 stands", applied["kept_staff_86"] == 1 and
          "tg_edamame" in store.availability_overrides(cfg.id)["item"], str(applied))
    store.set_availability(cfg.id, "tg_edamame", False, reason="POS", set_by="catalog_sync")
    live, _ = store.load_live_config(cfg.id)
    diff = cs.diff_catalog(live, [_pos(name, live.item("tg_edamame").base_price_cents)])
    cs.apply_auto(store, cfg.id, diff)
    check("an 86 the sync itself made IS lifted",
          "tg_edamame" not in store.availability_overrides(cfg.id)["item"])


# ---------------------------------------------------------------------------
# Deploy kit
# ---------------------------------------------------------------------------


def t_go_live_catches_the_templates_own_placeholders() -> None:
    import go_live as gl
    check("CHANGE_ME_long_random is a placeholder", gl.is_placeholder("CHANGE_ME_long_random"))
    check("+1XXXXXXXXXX is a placeholder", gl.is_placeholder("+1XXXXXXXXXX"))
    check("a real secret is not", not gl.is_placeholder("9f2c" * 10))
    rep = gl.Report()
    gl.check_secrets(rep, {"CHERRY_API_KEY": "a" * 40, "CHERRY_VOICE_KEY": "b" * 40,
                           "CHERRY_OAUTH_STATE_SECRET": "CHANGE_ME_long_random"})
    check("a published OAuth state secret blocks the launch",
          any(c.status == gl.FAIL and "OAUTH_STATE" in c.name for c in rep.checks),
          str([(c.name, c.status) for c in rep.checks]))
    from order_store import redact_dsn
    check("the database password is never printed",
          "hunter2" not in redact_dsn("postgresql://cherry:hunter2@db:5432/cherry"))


def t_the_deploy_kit_is_internally_consistent() -> None:
    env = dict(os.environ)
    out = subprocess.run([sys.executable, str(HERE / "deploy" / "check_env_names.py")],
                         capture_output=True, text=True, env=env)
    check("env template matches the manifest and the code", out.returncode == 0, out.stdout + out.stderr)
    nginx = (HERE / "deploy" / "nginx" / "cherry.conf").read_text()
    check("nginx exposes the Inworld event endpoint", "/v1/inworld/events" in nginx)
    check("nginx waits long enough for finish", "proxy_read_timeout 60s" in nginx)
    unit = (HERE / "deploy" / "systemd" / "cherry-gateway.service").read_text()
    check("the gateway does not restart with the server",
          "Wants=cherry-server.service" in unit and "Requires=cherry-server.service" not in unit)
    cron = (HERE / "deploy" / "cron" / "cherry.cron").read_text()
    check("the brief goes somewhere writable", "--out /var/lib/cherry/briefs" in cron)
    reqs = (HERE / "requirements.txt").read_text()
    check("every runtime import is declared", all(x in reqs for x in ("PyYAML", "cryptography", "tzdata", "openpyxl")))
    template = (HERE / "deploy" / "cherry.env.example").read_text()
    check("per-location numbers start empty, not malformed",
          "+1XXXXXXXXXX" not in template)


def t_the_ops_console_escapes_what_it_displays() -> None:
    import ops_console
    html = ops_console.HTML
    check("an escape function exists", "const esc=" in html)
    check("alert text is escaped", "${esc(a.title)}" in html and "${esc(a.detail)}" in html)
    check("POS item names are escaped", "${esc(x.name)}" in html)
    check("the operator key is not kept in localStorage", "localStorage" not in html)


def t_catalog_job_is_not_a_failure_when_items_await_review() -> None:
    src = (HERE / "catalog_nightly.py").read_text()
    check("review items no longer exit non-zero", "return 2 if" not in src)


# ---------------------------------------------------------------------------
# Whole calls over real sockets
# ---------------------------------------------------------------------------

import rehearsal
from rehearsal import Stack

CHECKOUT_OK = "texted your checkout link"


def _events(s, payload, key="voicekey"):
    return s.gw("POST", "/v1/inworld/events", payload, key=key)


def t_e2e_an_order_with_a_paid_addon_gets_its_checkout() -> None:
    s = Stack()
    try:
        s.call("a1")
        s.tool("a1", "add_item", text="chicken tikka"); s.tool("a1", "answer", text="medium")
        s.tool("a1", "add_modifier", text="extra chicken"); s.tool("a1", "ready_to_place")
        code, done = s.finish("a1")
        check("the caller is told the link was texted", code == 200 and CHECKOUT_OK in done["say"], str(done))
        check("nobody was transferred", not s.fake.transfers)
        li = [b for m, u, b in s.fake.square if m == "POST"][0]["order"]["line_items"][0]
        check("Square got the dish and the add-on separately",
              li["base_price_money"]["amount"] == 1299 and
              any(m["base_price_money"]["amount"] == 300 for m in li["modifiers"]), str(li))
    finally:
        s.close()


def t_e2e_the_inworld_event_path_places_an_order() -> None:
    s = Stack()
    try:
        out = _events(s, [
            {"type": "call_started", "call_id": "e1", "to": "+12485550111", "from": "+13135550123"},
            {"type": "tool_call", "call_id": "e1", "tool": "add_item", "args": {"text": "one vegetable samosa"}},
            {"type": "tool_call", "call_id": "e1", "tool": "ready_to_place"},      # asks about allergies
            {"type": "tool_call", "call_id": "e1", "tool": "note_allergy", "args": {"text": "no"}},
            {"type": "tool_call", "call_id": "e1", "tool": "ready_to_place"},      # now books
            {"type": "call_ended", "call_id": "e1"}])[1]
        n = s.store.conn.execute('SELECT count(*) AS n FROM "order"').fetchone()["n"]
        check("an order exists", int(n) == 1, str(out))
        check("its checkout was texted", len(s.fake.sms) == 1 and "square.link" in s.fake.sms[0]["text"])
        check("the call is not recorded as abandoned",
              s.store.conn.execute("SELECT end_reason FROM session").fetchone()["end_reason"] == "completed")
    finally:
        s.close()


def t_e2e_call_ids_with_awkward_characters_work() -> None:
    s = Stack()
    try:
        cid = "v3:AgAA/xyz?a=1#frag z"
        check("start", s.call(cid)[0] == 200)
        r = s.tool(cid.replace("/", "%2F").replace("?", "%3F").replace("#", "%23").replace(" ", "%20"),
                   "add_item", text="one vegetable samosa")
        check("tool call", r[0] == 200 and "Samosa" in r[1]["say"], str(r))
        s.tool(cid.replace("/", "%2F").replace("?", "%3F").replace("#", "%23").replace(" ", "%20"), "ready_to_place")
        code, done = s.finish(cid.replace("/", "%2F").replace("?", "%3F").replace("#", "%23").replace(" ", "%20"))
        check("checkout", code == 200 and CHECKOUT_OK in done["say"], str(done))
        check("the transfer audit finds its session", True)
    finally:
        s.close()


def t_e2e_a_withheld_caller_id_goes_to_staff_at_once() -> None:
    s = Stack()
    try:
        code, body = s.call("w1", frm="anonymous")
        check("the call starts and speaks", code == 200 and body["say"].strip(), str(body))
        check("the caller is sent to staff before an order is taken",
              len(s.fake.transfers) == 1 and "text a checkout link" in body["say"], str((s.fake.transfers, body)))
    finally:
        s.close()


def t_e2e_bad_arguments_never_become_a_500() -> None:
    s = Stack()
    try:
        s.call("b1")
        for args in ({"text": "samosa", "quantity": "two"}, {"text": 5}, {"text": None, "quantity": None},
                     {"text": "naan", "quantity": 99999}, {}):
            code, body = s.tool("b1", "add_item", **args)
            check(f"add_item {args} is answered", code == 200 and body["say"].strip(), str((code, body)))
        code, body = s.tool("b1", "set_quantity", quantity="lots")
        check("set_quantity with junk is answered", code == 200 and body["say"].strip(), str(body))
        code, body = s.tool("b1", "drop_database")
        check("an unknown tool asks again, it does not transfer", code == 200 and "say it again" in body["say"] and not s.fake.transfers, str(body))
    finally:
        s.close()


def t_e2e_a_card_number_is_never_stored() -> None:
    s = Stack()
    try:
        s.call("p1")
        s.tool("p1", "add_item", text="my card is 4111 1111 1111 1111 one vegetable samosa")
        rows = s.store.conn.execute("SELECT text FROM turn").fetchall()
        journal = s.store.conn.execute("SELECT args FROM call_journal").fetchall()
        blob = json.dumps([dict(r) for r in rows] + [dict(r) for r in journal])
        check("not in transcripts or the journal", "4111" not in blob, blob[:200])
    finally:
        s.close()


def t_e2e_two_finishes_in_flight_make_one_order() -> None:
    s = Stack()
    try:
        s.call("d1"); s.tool("d1", "add_item", text="one vegetable samosa"); s.tool("d1", "ready_to_place")
        real = urllib.request.urlopen
        def slow(req, timeout=None, **kw):
            if "payment-links" in getattr(req, "full_url", ""):
                time.sleep(1.0)
            return real(req, timeout=timeout, **kw)
        urllib.request.urlopen = slow
        results = []
        ts = [threading.Thread(target=lambda: results.append(s.finish("d1"))) for _ in range(3)]
        [t.start() for t in ts]; [t.join(60) for t in ts]
        urllib.request.urlopen = real
        n = s.store.conn.execute('SELECT count(*) AS n FROM "order"').fetchone()["n"]
        check("one order", int(n) == 1, str(n))
        check("one checkout text", len(s.fake.sms) == 1, str(len(s.fake.sms)))
        check("one Square link", sum(1 for m, u, b in s.fake.square if m == "POST") == 1)
        check("everyone heard the checkout line", all(CHECKOUT_OK in r[1]["say"] for r in results), str(results))
    finally:
        s.close()


def t_e2e_a_slow_checkout_is_not_reported_as_a_failure() -> None:
    s = Stack()
    try:
        s.gateway.bridge.timeout = 1.0               # a tool call gives up after 1 s...
        s.call("s1"); s.tool("s1", "add_item", text="one vegetable samosa"); s.tool("s1", "ready_to_place")
        real = urllib.request.urlopen
        def slow(req, timeout=None, **kw):
            if "payment-links" in getattr(req, "full_url", ""):
                time.sleep(2.5)                       # ...but Square takes longer than that
            return real(req, timeout=timeout, **kw)
        urllib.request.urlopen = slow
        try:
            code, done = s.finish("s1")
        finally:
            urllib.request.urlopen = real
        check("finish waited for it", code == 200 and CHECKOUT_OK in done["say"], str(done))
        check("the caller was not transferred while the link was texted", not s.fake.transfers)
    finally:
        s.close()


def t_e2e_a_restarted_gateway_can_still_route_a_transfer() -> None:
    s = Stack()
    try:
        s.call("r1"); s.tool("r1", "add_item", text="one vegetable samosa")
        s.start_gateway()                             # the gateway process restarted mid-call
        code, body = s.gw("POST", "/v1/voice/calls/r1/handoff", {})
        check("without the number it says something usable", code == 200 and "can't transfer" in body["say"], str(body))
        code, body = s.gw("POST", "/v1/voice/calls/r1/handoff", {"to": "+12485550111"})
        check("told the number, it transfers", code == 200 and "connect" in body["say"] and len(s.fake.transfers) == 1, str((body, s.fake.transfers)))
    finally:
        s.close()


def t_e2e_a_non_ascii_key_is_refused_cleanly() -> None:
    s = Stack()
    try:
        code, body = s.gw("POST", "/v1/voice/calls", {"call_control_id": "k", "to": "+12485550111"}, key="clé")
        check("401, not a dropped connection", code == 401, str((code, body)))
    finally:
        s.close()


def t_e2e_a_paused_ai_keeps_its_hours() -> None:
    """POST controls with only ai_enabled replaced every column, wiping the
    opening hours and resetting prep time."""
    s = Stack()
    try:
        def post(body):
            req = urllib.request.Request(
                f"http://127.0.0.1:{s.sport}/v1/restaurants/pink-garlic-shelby/controls",
                data=json.dumps(body).encode(), method="POST",
                headers={"X-Cherry-Key": "apikey", "Content-Type": "application/json"})
            try:
                with rehearsal.REAL_URLOPEN(req, timeout=20) as r:
                    return r.status, json.loads(r.read())
            except urllib.error.HTTPError as e:
                return e.code, json.loads(e.read() or b"{}")
        import urllib.error
        post({"weekly_hours": {"fri": ["11:00", "22:00"]}, "prep_minutes": 35})
        code, now = post({"ai_enabled": False})
        check("pausing keeps the hours", now["weekly_hours"] == {"fri": ["11:00", "22:00"]}, str(now))
        check("and the prep time", now["prep_minutes"] == 35, str(now))
        code, _ = post({"weekly_hours": {"nonsense": ["a", "b"]}})
        check("a typo is refused when saved", code == 400, str(code))
    finally:
        s.close()


def main() -> int:
    global _failed
    tests = sorted((n, f) for n, f in globals().items() if n.startswith("t_"))
    for name, fn in tests:
        try:
            fn()
        except Exception:                                    # noqa: BLE001
            _failed += 1
            print(f"\n--- FAIL {name} raised")
            traceback.print_exc()
    print(f"{_passed} passed, {_failed} failed (live-call hardening)")
    return 1 if _failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
