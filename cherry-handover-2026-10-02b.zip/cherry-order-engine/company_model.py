#!/usr/bin/env python3
"""
The whole company, at 10 / 50 / 100 restaurants.

    python3 company_model.py

This replaces the scattered half-models. One file, every cost line, every
scale point, and an explicit statement of which numbers are MEASURED, which
come from a RATE CARD, and which are ASSUMPTIONS you should challenge.

WHAT IS MEASURED (from the real engine and the real menus)
    calls, minutes, orders per location
    characters Lily speaks per call      -> 175 (Bun N Run) to 350 (Pink Garlic)
    seconds Lily speaks per call         -> 12s to 23s at 15 chars/sec
    SMS segments per kitchen ticket      -> 2.7
    engine latency per turn              -> 0.9ms median, 7.1ms worst

WHAT COMES FROM A RATE CARD (Telnyx + Inworld, 2026-09)
    telephony, STT, TTS, LLM, SMS, carrier fees

WHAT IS AN ASSUMPTION (challenge these)
    ORDER_CONVERSION, PAY_LINK_SHARE, SUPPORT_HOURS, ONBOARD_HOURS,
    LLM_TOKENS_PER_MIN, and above all BILLING_MODE below.

INWORLD BILLING — RESOLVED 2026-09-14
-------------------------------------
From docs.inworld.ai/portal/billing, verbatim:

    "Text-to-Speech usage is billed per million characters synthesized"
    "Speech-to-Text usage is billed based on audio duration"
    "Usage is billed based on the underlying TTS, STT, and LLM usage at
     your tier's rates"

And from inworld.ai/pricing:  "Assumes one minute of audio is ~1,000 characters"

So the per-minute figures on the rate card are a PRESENTATION of a
per-character rate, not a metering unit. TTS bills CHARACTERS SYNTHESISED.
Silence is never synthesised, so silence is free. There is no session,
connection or concurrency charge — the Realtime API is a pass-through to
three component meters.

The $25/$100/$300 tier fees are CREDITS, not fees on top: "Paid plans include
credits equal to the monthly plan price each billing cycle." So Creator is a
$25 prepayment against usage, not $25 of overhead.

STILL UNKNOWN, and modelled pessimistically:
  * Does streaming STT meter the audio you SEND (wall-clock, if the client
    does not gate silence) or only detected speech? Modelled as full call.
  * Any per-session rounding? Not published.
  * Does an interrupted (barged-in) response bill the whole generated buffer
    or only what played? Not published. Matters if barge-in is common.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Tuple

# ---------------------------------------------------------------------------
# MEASURED
# ---------------------------------------------------------------------------

CALLS_PER_DAY = 50
DAYS_PER_MONTH = 30.44
AVG_CALL_SECONDS = 90.0

# Lily's speaking time, measured across the real menus. A simple burger menu
# is 12s; a 144-item Indian menu with spice prompts is 23s. Use the average.
LILY_SPEAKS_SECONDS = 17.0
CALLER_SPEAKS_SECONDS = 22.0
# MEASURED from the real engine: characters Lily speaks per call, averaged
# across the pilots (175 at Bun N Run, 350 at Pink Garlic). This is the
# actual TTS billing unit.
CHARS_SPOKEN_PER_CALL = 246.0
TICKET_SMS_SEGMENTS = 2.7
PAYLINK_SMS_SEGMENTS = 1.0

# ---------------------------------------------------------------------------
# ASSUMPTIONS — challenge these
# ---------------------------------------------------------------------------

ORDER_CONVERSION = 0.80
PAY_LINK_SHARE = 0.30
LLM_TOKENS_PER_MIN = 4000.0

# FOUNDER TIME IS NOT A COST LINE.
#
# The founder is paid out of profit, not out of COGS. Charging his hours as an
# expense double-counts: it reduces the profit that IS his compensation. So
# the model reports hours as a CAPACITY constraint — the thing that actually
# limits how many restaurants can be run — and leaves the money in profit.
#
# That reframing does not make the hours matter less. It makes them matter
# differently: they stop being $1,250/mo of expense and start being a hard
# ceiling on growth. You can raise money; you cannot buy more of your own
# hours.
ONBOARD_HOURS_PER_RESTAURANT = 6.0      # menu modelling + owner review
SUPPORT_HOURS_PER_REST_MONTH = 0.5      # 86s, menu edits, "it got one wrong"
HOURS_AVAILABLE_PER_MONTH = 160.0       # one full-time person

# ---------------------------------------------------------------------------
# RATE CARD
# ---------------------------------------------------------------------------

TELEPHONY_PER_MIN = 0.004               # $0.002 inbound + $0.002 SIP trunk
SMS_PER_SEGMENT = 0.004                 # Telnyx
SMS_CARRIER_FEE = 0.004                 # blended AT&T/T-Mobile/Verizon
SMS_ALL_IN = SMS_PER_SEGMENT + SMS_CARRIER_FEE

LLM_PER_1M_BLENDED = 0.07 * 0.70 + 0.34 * 0.30      # Gemma 4 26B A4B

# Inworld tiers: (monthly credit, TTS-2 Flash $ per 1M chars, STT $/hour)
#
# The fee is a CREDIT against usage, not an extra cost — so it only bites if
# you would not otherwise spend it. Creator is granted free to us, so its
# credit is pure upside.
#
# STT is a flat $0.10/hr on EVERY paid tier — it does not keep falling.
INWORLD_TIERS: Dict[str, Tuple[float, float, float]] = {
    "on_demand": (0.0,    15.0, 0.15),
    "creator":   (25.0,   10.0, 0.10),
    "builder":   (100.0,   9.0, 0.10),
    "developer": (300.0,   8.0, 0.10),
    "growth":    (1500.0,  7.0, 0.10),
}
CREATOR_IS_FREE = True          # Inworld granted it at no charge

# Free allowance on On-Demand only: 70 min TTS, 400 min STT per month.
FREE_TTS_MINUTES = 70.0
FREE_STT_MINUTES = 400.0

# Inworld's own conversion, used only to sanity-check against their table.
CHARS_PER_MINUTE_OF_AUDIO = 1000.0

# Fixed infrastructure, for the WHOLE company, not per restaurant.
PHONE_NUMBER_PER_MONTH = 1.0            # per location — each needs its own
TENDLC_PER_MONTH = 12.0                 # one brand + campaign, company-wide
DB_TIERS = [(25, 25.0), (100, 100.0), (500, 400.0)]   # (max rest, $/mo)
SERVER_TIERS = [(25, 20.0), (100, 80.0), (500, 300.0)]

# Developer: nothing until 10 restaurants, then $20 per customer from #11.
DEVELOPER_FREE_UNTIL = 10
DEVELOPER_PER_CUSTOMER = 20.0
LOCATIONS_PER_CUSTOMER = 1.6            # some customers are multi-location

# Launch offer: first 50 restaurants, per location. There is no surprise
# overage charge. A location moves to the next plan after three consecutive
# completed billing months over the included amount.
PRICE_PER_LOCATION = 299.0
INCLUDED_MINUTES_PER_LOCATION = 3000.0
UPGRADE_AFTER_CONSECUTIVE_MONTHS = 3

# Does Inworld bill the whole session, or only generated audio?
BILLING_MODE = "session"                # "session" (pessimistic) | "audio"


def _tiered(n: int, tiers: List[Tuple[int, float]]) -> float:
    for limit, cost in tiers:
        if n <= limit:
            return cost
    return tiers[-1][1]


@dataclass
class Scenario:
    restaurants: int
    tier: str
    sms_tickets: bool = True
    billing: str = BILLING_MODE
    call_seconds: float = AVG_CALL_SECONDS

    # -- volumes -------------------------------------------------------
    @property
    def calls(self) -> float:
        return CALLS_PER_DAY * DAYS_PER_MONTH * self.restaurants

    @property
    def minutes(self) -> float:
        return self.calls * self.call_seconds / 60

    @property
    def orders(self) -> float:
        return self.calls * ORDER_CONVERSION

    @property
    def tts_chars(self) -> float:
        """The real TTS meter: characters synthesised. Silence is free."""
        return self.calls * CHARS_SPOKEN_PER_CALL

    @property
    def stt_minutes(self) -> float:
        """STT bills audio duration. Whether that is the stream you SEND or
        only detected speech is not published, so `billing` switches between
        the pessimistic and optimistic readings."""
        if self.billing == "session":
            return self.minutes                       # ungated stream
        return self.calls * CALLER_SPEAKS_SECONDS / 60

    @property
    def sms_segments(self) -> float:
        """ONE message per order: the pay link.

        Cherry's job ends at handing the order to the POS. The customer opens
        the link, sees their order, pays, and the POS confirms and routes it to
        the kitchen — all of that is the POS's job, not ours. So there is no
        Cherry kitchen ticket, and `sms_tickets` only exists to price the
        fallback for restaurants with no POS bridge at all.
        """
        seg = self.orders * PAY_LINK_SHARE * PAYLINK_SMS_SEGMENTS
        if self.sms_tickets:
            seg += self.orders * TICKET_SMS_SEGMENTS
        return seg

    # -- costs ---------------------------------------------------------
    def costs(self) -> Dict[str, float]:
        credit, tts_per_1m, stt_per_hr = INWORLD_TIERS[self.tier]
        customers = max(1, round(self.restaurants / LOCATIONS_PER_CUSTOMER))
        dev = 0.0 if self.restaurants <= DEVELOPER_FREE_UNTIL else \
            DEVELOPER_PER_CUSTOMER * customers

        return {
            "telephony": self.minutes * TELEPHONY_PER_MIN,
            "inworld tts": self.tts_chars / 1e6 * tts_per_1m,
            "inworld stt": self.stt_minutes / 60 * stt_per_hr,
            # A tier fee is a CREDIT against usage, so it is only a real cost
            # when it exceeds what you would have spent anyway. Creator was
            # granted free, so it costs nothing at all.
            "inworld tier": (0.0 if (self.tier == "creator" and CREATOR_IS_FREE)
                             else max(0.0, credit - (
                                 self.tts_chars / 1e6 * tts_per_1m
                                 + self.stt_minutes / 60 * stt_per_hr))),
            "llm": self.minutes * LLM_TOKENS_PER_MIN / 1e6 * LLM_PER_1M_BLENDED,
            "sms": self.sms_segments * SMS_ALL_IN,
            "phone numbers": self.restaurants * PHONE_NUMBER_PER_MONTH,
            "10dlc": TENDLC_PER_MONTH,
            "database": _tiered(self.restaurants, DB_TIERS),
            "servers": _tiered(self.restaurants, SERVER_TIERS),
            "developer": dev,
        }

    @property
    def founder_hours(self) -> float:
        """Hours of YOUR time per month. Not a cost — a ceiling."""
        return self.restaurants * SUPPORT_HOURS_PER_REST_MONTH

    @property
    def capacity_used(self) -> float:
        return self.founder_hours / HOURS_AVAILABLE_PER_MONTH * 100

    @property
    def revenue(self) -> float:
        return self.restaurants * PRICE_PER_LOCATION

    def summary(self) -> Dict[str, float]:
        c = self.costs()
        total = sum(c.values())
        return {"revenue": self.revenue, "cost": total,
                "profit": self.revenue - total,
                "margin": (self.revenue - total) / self.revenue * 100,
                "per_location": total / self.restaurants,
                "per_call": total / self.calls,
                "per_order": total / self.orders}


def best_tier(restaurants: int, billing: str = BILLING_MODE,
              sms_tickets: bool = True) -> str:
    return min(INWORLD_TIERS,
               key=lambda t: sum(Scenario(restaurants, t, sms_tickets,
                                          billing).costs().values()))


def _money(x: float) -> str:
    return f"${x:,.0f}" if abs(x) >= 1000 else f"${x:,.2f}"


def main() -> int:
    print("=" * 76)
    print("CHERRY — COMPANY MODEL")
    print("=" * 76)
    print(f"\nEvery restaurant: {CALLS_PER_DAY} calls/day, 7 days, "
          f"{AVG_CALL_SECONDS:.0f}s average call, ${PRICE_PER_LOCATION:.0f}/mo")
    one = Scenario(1, best_tier(1))
    print(f"Launch plan includes {INCLUDED_MINUTES_PER_LOCATION:,.0f} minutes; "
          f"modelled usage is {one.minutes:,.0f}, leaving "
          f"{INCLUDED_MINUTES_PER_LOCATION-one.minutes:,.0f} minutes headroom.")
    print(f"Developer cost: $0 through {DEVELOPER_FREE_UNTIL} restaurants, "
          f"then ${DEVELOPER_PER_CUSTOMER:.0f}/customer from #{DEVELOPER_FREE_UNTIL+1}")

    for billing in ("session", "audio"):
        label = ("PESSIMISTIC — Inworld bills the whole session"
                 if billing == "session" else
                 "OPTIMISTIC — Inworld bills only generated audio")
        print(f"\n{'=' * 76}\n{label}\n{'=' * 76}")
        print(f"\n  {'rests':>6}{'tier':>11}{'revenue':>11}{'cost':>10}"
              f"{'profit':>11}{'margin':>8}{'$/loc':>9}{'$/call':>8}")
        for n in (10, 50, 100):
            t = best_tier(n, billing)
            s = Scenario(n, t, billing=billing)
            m = s.summary()
            print(f"  {n:>6}{t:>11}{_money(m['revenue']):>11}"
                  f"{_money(m['cost']):>10}{_money(m['profit']):>11}"
                  f"{m['margin']:>7.1f}%{_money(m['per_location']):>9}"
                  f"{m['per_call']:>8.3f}")

    print(f"\n{'=' * 76}")
    print("WHERE THE MONEY GOES — 50 RESTAURANTS, PESSIMISTIC BILLING")
    print("=" * 76)
    t = best_tier(50)
    s = Scenario(50, t)
    c = s.costs()
    total = sum(c.values())
    print(f"\n  tier: {t}\n")
    for k, v in sorted(c.items(), key=lambda kv: -kv[1]):
        if v <= 0:
            continue
        bar = "#" * int(v / total * 46)
        print(f"  {k:<22}{_money(v):>10}{v/total*100:>7.1f}%  {bar}")
    print(f"  {'TOTAL':<22}{_money(total):>10}")

    print(f"\n{'=' * 76}")
    print("THE LEVERS, IN DOLLARS, AT EACH SCALE")
    print("=" * 76)
    for n in (10, 50, 100):
        base_t = best_tier(n)
        base = sum(Scenario(n, base_t).costs().values())
        nosms_t = best_tier(n, sms_tickets=False)
        nosms = sum(Scenario(n, nosms_t, sms_tickets=False).costs().values())
        shorter = sum(Scenario(n, base_t, call_seconds=75).costs().values())
        audio = sum(Scenario(n, best_tier(n, "audio"), billing="audio").costs().values())
        print(f"\n  {n} restaurants (baseline {_money(base)}/mo):")
        print(f"    POS bridge, no SMS tickets   -{_money(base - nosms):>9}/mo"
              f"   -{_money((base-nosms)*12):>9}/yr")
        print(f"    15s shorter calls            -{_money(base - shorter):>9}/mo"
              f"   -{_money((base-shorter)*12):>9}/yr")
        print(f"    if Inworld bills audio only  -{_money(base - audio):>9}/mo"
              f"   -{_money((base-audio)*12):>9}/yr")

    print(f"\n{'=' * 76}")
    print("SMS — WHY IT IS BIG AND HOW FAR IT CAN FALL")
    print("=" * 76)
    s50 = Scenario(50, best_tier(50))
    print(f"\n  At 50 restaurants: {s50.orders:,.0f} orders/mo")
    options = [
        ("Ticket (2.7 seg) + pay link", 2.7, PAY_LINK_SHARE),
        ("Trim ticket to 1.5 segments", 1.5, PAY_LINK_SHARE),
        ("Pay link only, POS gets order", 0.0, PAY_LINK_SHARE),
        ("Pay link only, 100% pay-now", 0.0, 1.0),
        ("Nothing — POS handles both", 0.0, 0.0),
    ]
    for label, tick, share in options:
        seg = s50.orders * (tick + share * PAYLINK_SMS_SEGMENTS)
        print(f"  {label:<32}{seg:>9,.0f} seg{_money(seg*SMS_ALL_IN):>10}/mo"
              f"{_money(seg*SMS_ALL_IN*12):>11}/yr")
    print(f"\n  Carrier fee is {SMS_CARRIER_FEE/SMS_ALL_IN:.0%} of every segment and")
    print(f"  you cannot negotiate it — only send fewer segments.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
