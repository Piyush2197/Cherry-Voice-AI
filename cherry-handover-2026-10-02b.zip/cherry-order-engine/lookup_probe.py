#!/usr/bin/env python3
"""How often does Telnyx's carrier lookup give a DEFINITE answer for your callers?

Idea on the task list: if the caller is on a landline, say so at the start of the call and
ask for a mobile number then, instead of failing to text the checkout link at the end. Whether
that is worth building depends on one measurable thing: for US numbers, how often does the lookup say
"fixed line" or "mobile" for sure, rather than "fixed line or mobile" / "unknown" (which is what
the North American numbering plan allows it to say about many numbers)?

    TELNYX_API_KEY=... python3 lookup_probe.py --db cherry.db --limit 100
    python3 lookup_probe.py --numbers +15865550123 +13135550123        # specific numbers

This READS the database and makes one lookup per distinct caller (Telnyx prices lookups per
request, in fractions of a cent: check your rate before a large --limit). It prints counts by
type and NEVER prints a phone number unless you pass --show, and then only the last four digits.
Nothing is stored. The key is read from the environment by name and never printed.

A landline is only worth acting on if the share of definite "fixed line" answers is meaningful AND
those numbers really cannot receive texts; the other types (mobile, voip, fixed line or mobile,
unknown) must be treated as textable, so that no caller is ever asked a needless question.
"""

from __future__ import annotations

import _ensure_deps  # noqa: F401  (re-runs under .venv, or says how to install, if PyYAML is missing)
import argparse
import json
import os
import re
import sys
import urllib.error
import urllib.parse
import urllib.request
from collections import Counter
from typing import Callable, Dict, Iterable, List, Optional

TELNYX_API = "https://api.telnyx.com/v2"
_E164 = re.compile(r"^\+[1-9][0-9]{7,14}$")
# Telnyx's documented carrier.type values, grouped by what they mean for texting.
CANNOT_TEXT = {"fixed line", "toll free", "premium rate", "shared cost", "pager", "voicemail", "uan"}
CAN_TEXT = {"mobile", "voip", "personal number"}
AMBIGUOUS = {"fixed line or mobile", "unknown", ""}


def lookup(number: str, key: str, *, opener: Optional[Callable] = None, timeout: float = 10.0) -> str:
    """The carrier type Telnyx reports for ``number`` ("unknown" when it cannot say)."""
    req = urllib.request.Request(f"{TELNYX_API}/number_lookup/{urllib.parse.quote(number, safe='')}?type=carrier",
                                 headers={"Authorization": f"Bearer {key}", "Accept": "application/json"})
    try:
        with (opener or urllib.request.urlopen)(req, timeout=timeout) as resp:
            doc = json.loads(resp.read())
    except urllib.error.HTTPError as exc:
        return f"error {exc.code}"
    except (urllib.error.URLError, OSError, ValueError):
        return "error network"
    return str(((doc.get("data") or {}).get("carrier") or {}).get("type") or "unknown").strip().lower()


def classify(carrier_type: str) -> str:
    if carrier_type.startswith("error"):
        return "error"
    if carrier_type in CANNOT_TEXT:
        return "cannot-text"
    if carrier_type in CAN_TEXT:
        return "can-text"
    return "ambiguous"


def callers(store, limit: int) -> List[str]:
    rows = store.conn.execute("SELECT DISTINCT caller_phone FROM session WHERE channel='voice' AND caller_phone IS NOT NULL "
                              "ORDER BY started_at DESC LIMIT ?", (int(limit),)).fetchall()
    return [r["caller_phone"] for r in rows if _E164.match(r["caller_phone"] or "")]


def probe(numbers: Iterable[str], key: str, *, opener: Optional[Callable] = None) -> Dict[str, object]:
    types: Counter = Counter()
    groups: Counter = Counter()
    masked: List[tuple] = []
    for n in numbers:
        t = lookup(n, key, opener=opener)
        types[t] += 1
        groups[classify(t)] += 1
        masked.append(("…" + n[-4:], t))
    total = sum(groups.values())
    definite = groups["cannot-text"] + groups["can-text"]
    return {"looked_up": total, "by_type": dict(types.most_common()), "by_group": dict(groups),
            "definite_share": (definite / total) if total else None,
            "landline_share": (groups["cannot-text"] / total) if total else None, "masked": masked}


def main(argv: Optional[List[str]] = None, *, env: Optional[dict] = None, opener: Optional[Callable] = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    src = ap.add_mutually_exclusive_group(required=True)
    src.add_argument("--db")
    src.add_argument("--numbers", nargs="+")
    ap.add_argument("--limit", type=int, default=100)
    ap.add_argument("--show", action="store_true", help="also list each type against the LAST FOUR digits")
    args = ap.parse_args(argv)
    env = os.environ if env is None else env
    key = str(env.get("TELNYX_API_KEY", "")).strip()
    if not key:
        print("TELNYX_API_KEY is not set: export it in your shell first (it is read by name and never printed)")
        return 2
    if args.numbers:
        nums = [n for n in args.numbers if _E164.match(n)]
    else:
        from order_store import OrderStore
        nums = callers(OrderStore.open(args.db), args.limit)
    if not nums:
        print("no E.164 numbers to look up")
        return 1
    r = probe(nums, key, opener=opener)
    print(f"{r['looked_up']} numbers looked up")
    for t, n in r["by_type"].items():
        print(f"  {t or 'unknown':22} {n:4}  ({n / r['looked_up'] * 100:.0f}%)")
    print(f"definite answers (mobile/voip/fixed line/...): {r['definite_share'] * 100:.0f}%   "
          f"definite landlines: {r['landline_share'] * 100:.0f}%")
    print("Worth building only if definite landlines are a real share of callers and the lookup is reliable on them;\n"
          "'fixed line or mobile' and 'unknown' must be treated as textable.")
    if args.show:
        for m, t in r["masked"]:
            print(f"  {m}  {t}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
