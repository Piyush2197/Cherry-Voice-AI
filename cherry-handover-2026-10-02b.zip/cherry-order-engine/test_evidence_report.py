#!/usr/bin/env python3
"""Checks for complaint-ready order evidence."""

from __future__ import annotations

import hashlib
import json
import traceback
from dataclasses import replace
from pathlib import Path

import evidence_report as er
import menu_schema as ms
from order_engine import OrderEngine
from order_store import OrderStore
from sinks import FakeSmsSender, ManualSink, deliver


HERE = Path(__file__).resolve().parent
_passed = _failed = 0


def check(name, condition, detail=""):
    global _passed, _failed
    if condition:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


def fixture():
    store = OrderStore.sqlite()
    path = HERE / "menus" / "tamago-sushi-bowl.yaml"
    # This fixture proves legacy pay-at-pickup evidence. The seven pilot menus
    # now use the paid-first branch, covered by test_payment_gate.py.
    cfg = replace(ms.load_yaml(path), pay_now_threshold_cents=3000)
    store.upsert_restaurant(cfg.id, cfg.name, cfg.cuisine, sink="manual",
                            staff_phone="+13135550100",
                            inbound_phone="+13135550101", active=True)
    mv = store.publish_menu(cfg.id, path.read_text(), item_count=len(cfg.items))
    sid = store.start_session(cfg.id, mv, external_id="telnyx-call-abc",
                              caller_phone="+13135550123")
    store.record_turn(sid, "agent", "What can I get you?", intent="greeting")
    store.record_turn(sid, "caller", "I'm Casey at +13135550123; edamame",
                      intent="add_item")
    engine = OrderEngine(cfg)
    engine.add_line("tg_edamame")
    store.record_turn(sid, "agent", engine.read_back(), intent="read_back")
    oid, code = store.place_order(
        cfg.id, mv, engine.to_normalized_order(), session_id=sid,
        customer_name="Casey", customer_phone="+13135550123")
    deliver(store, oid, ManualSink(FakeSmsSender()), sleep=lambda _: None)
    store.acknowledge_delivery(oid, "staff-phone")
    store.end_session(sid, "completed")
    return store, code


def t_packet_joins_final_order_transcript_and_delivery() -> None:
    store, code = fixture()
    packet = er.build(store, code)
    check("packet identifies the final order", packet["order"]["short_code"] == code)
    check("packet contains the normalized order",
          packet["final_order"]["lines"][0]["item_name"] == "Edamame")
    check("packet contains the complete transcript", len(packet["transcript"]) == 3)
    check("packet proves restaurant acknowledgement",
          packet["order"]["delivery_outcome"] == "acknowledged_by_restaurant")
    check("packet contains delivery and SMS evidence",
          len(packet["delivery_attempts"]) == 1 and len(packet["messages"]) == 1)


def t_packet_is_redacted_and_integrity_hash_recomputes() -> None:
    store, code = fixture()
    packet = er.build(store, code)
    raw = json.dumps(packet)
    check("customer name is redacted", "Casey" not in raw)
    check("full customer phone is redacted", "+13135550123" not in raw)
    canonical = json.dumps(packet["final_order"], sort_keys=True,
                           separators=(",", ":"))
    expected = hashlib.sha256(canonical.encode()).hexdigest()
    check("snapshot integrity hash is reproducible",
          packet["integrity"]["final_order_sha256"] == expected)
    check("audio limitation is explicit",
          packet["audio_recording"]["available_in_cherry"] is False)


def t_contact_requires_an_explicit_flag_and_unknown_orders_fail() -> None:
    store, code = fixture()
    packet = er.build(store, code, include_contact=True)
    check("explicit support export includes customer name",
          packet["order"]["customer_name"] == "Casey")
    check("explicit support export includes customer phone",
          packet["order"]["customer_phone"] == "+13135550123")
    try:
        er.build(store, "0000")
        check("unknown order is rejected", False)
    except LookupError:
        check("unknown order is rejected", True)


def main() -> int:
    for name, fn in sorted(globals().items()):
        if not name.startswith("t_"):
            continue
        try:
            fn()
        except Exception:
            global _failed
            _failed += 1
            print(f"\n--- FAIL {name}\n{traceback.format_exc()}")
    print(f"\n{_passed} passed, {_failed} failed (complaint evidence)")
    return 1 if _failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
