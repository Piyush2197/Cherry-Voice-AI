#!/usr/bin/env python3
"""
Build the complete Pink Garlic config from the live Square menu.

WHERE THE DATA CAME FROM
------------------------
raw/pink-garlic-full.tsv — 147 items with prices, read off
pink-garlic-indian-cuisine.square.site (Shelby Twp, LE6SK09FR3EAY) on
2026-09-13. The site's category headings render empty; the real menu is one
flat numbered list at the bottom of the page, which is what was captured.

WHAT IS INFERRED AND WHAT IS NOT
--------------------------------
Names and prices are verbatim from the site — nothing is invented.

Category and modifier-group assignment IS inferred, from the menu numbering
and the dish names, using the group bundles already verified against their
live item pages:

    curries/tandoori/biryani  -> Level of Spice (required) + ADD (optional)
    lamb or goat dishes       -> the above, plus Preference (required)
    breads/desserts/drinks/
    sides/condiments          -> no groups

That inference is the part a human must check. `PINK_GARLIC_REVIEW` at the
bottom lists every assumption in the owner's own terms, and `cherry.py check`
will not let anything unpriced or structurally broken through regardless.

SPOKEN NAMES
------------
The site writes "29. Butter Chk. (Creamy)". A caller says "butter chicken".
So each item gets a cleaned display name plus aliases covering the
abbreviations Square uses — Chk, Veg, SP, PG — because the matcher works on
what people say, not on what the POS prints.
"""

from __future__ import annotations

import _ensure_deps  # noqa: F401  (re-runs under .venv, or says how to install, if PyYAML is missing)
import re
from pathlib import Path
from typing import Dict, List, Tuple

HERE = Path(__file__).parent
RAW = HERE / "raw" / "pink-garlic-full.tsv"

# Square's abbreviations, expanded for the spoken name.
EXPAND = [
    (r"\bChk\.?\b", "Chicken"), (r"\bVeg\b", "Vegetable"),
    (r"\bSP\b", "Special"), (r"\bPG\b", "Pink Garlic"),
    (r"\bMIS\b", "Miscellaneous"), (r"\bJam\b", "Jamun"),
    (r"\bBaji\b", "Bhaji"), (r"\bDaal\b", "Dal"),
    (r"\bSagwa\b", "Saagwala"), (r"\bChetinado\b", "Chettinad"),
    (r"\bChetinad\b", "Chettinad"), (r"\bJalferzi\b", "Jalfrezi"),
    (r"\bTando Roti\b", "Tandoori Roti"), (r"\bRashmalai\b", "Rasmalai"),
    (r"\bBindi\b", "Bhindi"), (r"\bMomo's\b", "Momos"),
]

# Category is decided by the menu number, which is how the restaurant itself
# organises the menu. Ranges read off the printed numbering.
NUMBER_CATEGORIES: List[Tuple[int, int, str]] = [
    (1, 15, "appetizer"),
    (16, 19, "soup_salad"),
    (20, 28, "tandoori"),
    (29, 48, "chicken"),
    (49, 61, "lamb"),
    (62, 68, "biryani"),
    (69, 71, "indo_chinese"),
    (72, 77, "seafood"),
    (78, 89, "vegetable"),
    (90, 93, "party_tray"),
    (94, 96, "kids"),
    (97, 102, "rice"),
    (103, 113, "bread"),
    (114, 119, "dessert_drink"),
]

# Items with no menu number, placed by name.
BY_NAME = {
    "paneer biriyani": "biryani", "smoked tandoori biryani": "biryani",
    "shrimp korma": "seafood", "shrimp curry": "seafood",
    "saag baji. (vegan)": "vegetable", "saag daal (vegan)": "vegetable",
    "veg masala": "vegetable", "paneer korma": "vegetable",
    "veg mix st": "appetizer",
    "cheese naan": "bread", "chili cheese naan": "bread",
    "pure leaf": "dessert_drink",
    "half tray any seafood dish": "party_tray",
    "full tray any seafood dish": "party_tray",
    "half tray rice": "party_tray", "full tray rice": "party_tray",
    "chutney container large": "party_tray",
    "raita": "condiment", "mint chutney": "condiment",
    "mango chutney": "condiment", "hot sauce": "condiment",
    "pickle": "condiment", "red onion": "condiment",
    "butter sauce": "condiment", "onion salad": "condiment",
    "plain yogurt": "condiment",
}

# Which categories get which verified group bundle.
SPICE_AND_ADD = ("chicken", "lamb", "biryani", "indo_chinese", "seafood",
                 "vegetable", "tandoori")
NEEDS_PREFERENCE = ("lamb",)          # goat bone-in vs lamb boneless
SPICE_ONLY = ("party_tray",)
NO_GROUPS = ("bread", "dessert_drink", "rice", "condiment", "kids",
             "soup_salad", "appetizer")


def slug(name: str) -> str:
    s = re.sub(r"^\d+[a-z]?\.\s*", "", name).strip().lower()
    s = re.sub(r"[^a-z0-9]+", "_", s).strip("_")
    return f"pg_{s}"[:48]


def spoken(name: str) -> str:
    """The name as Lily says it out loud.

    Square's strings carry punctuation and tags that make sense on a screen
    and sound wrong in speech: "86. Chana Masala. (Vegan)" must be read as
    "Chana Masala". The vegan/vegetarian fact is real and worth keeping, but
    it belongs in an alias so a caller can ASK for vegan dishes — not in the
    sentence Lily reads back.
    """
    s = re.sub(r"^\d+[a-z]?\.\s*", "", name).strip()
    s = re.sub(r"\s*\((?:vegan|vegetarian)\)\s*$", "", s, flags=re.I)
    s = re.sub(r"\.\s*$", "", s)            # trailing full stop
    s = re.sub(r"\.\s+", " ", s)            # "Masala. (Creamy)" -> "Masala ..."
    for pat, rep in EXPAND:
        s = re.sub(pat, rep, s)
    return re.sub(r"\s{2,}", " ", s).strip()


def aliases_for(display: str, raw: str, cat: str = "") -> List[str]:
    """What a caller would actually say."""
    out = set()
    base = display.lower()
    out.add(base)
    # Drop the parenthetical: "Butter Chicken (Creamy)" -> "butter chicken"
    bare = re.sub(r"\s*\([^)]*\)", "", base).strip()
    # "(Creamy)" is a description, so the bare name is a fine alias. "(Starter)"
    # is what DISTINGUISHES this dish from an entree of the same name, so
    # stripping it would hand both dishes the same alias and make the cheaper
    # one unreachable.
    if bare and bare != base and "starter" not in base:
        out.add(bare)
    # "Lamb/Goat Curry" is said as "lamb curry" or "goat curry". It must NOT
    # also answer to a bare "curry" — the chicken version is a dollar cheaper
    # and guessing between them is a silent overcharge on every order.
    if "lamb/goat" in bare:
        out.add(bare.replace("lamb/goat", "lamb"))
        out.add(bare.replace("lamb/goat", "goat"))
    # The menu number is a real spoken handle: "number 29"
    m = re.match(r"^(\d+)[a-z]?\.", raw)
    if m:
        out.add(f"number {int(m.group(1))}")
    # Keep the dietary tag as something a caller can say, since "what's vegan"
    # is a real question at an Indian restaurant.
    if re.search(r"\((?:vegan|vegetarian)\)", raw, re.I):
        out.add(f"vegan {bare}")
    out.discard("")
    return sorted(a for a in out if len(a) > 2)


def category_for(raw: str, display: str) -> str:
    m = re.match(r"^(\d+)[a-z]?\.", raw)
    if m:
        n = int(m.group(1))
        for lo, hi, cat in NUMBER_CATEGORIES:
            if lo <= n <= hi:
                return cat
    key = raw.strip().lower()
    if key in BY_NAME:
        return BY_NAME[key]
    low = display.lower()
    if "tray" in low:
        return "party_tray"
    if "naan" in low or "roti" in low or "paratha" in low:
        return "bread"
    return "misc"


def groups_for(cat: str) -> Tuple[str, ...]:
    if cat in NEEDS_PREFERENCE:
        return ("pg_spice", "pg_add", "pg_preference")
    if cat in SPICE_AND_ADD:
        return ("pg_spice", "pg_add")
    if cat in SPICE_ONLY:
        return ("pg_spice",)
    return ()


def load_rows() -> List[Tuple[str, int, bool]]:
    rows = []
    for line in RAW.read_text().splitlines():
        if not line.strip():
            continue
        parts = line.split("\t")
        if len(parts) < 2:
            continue
        name, price = parts[0], parts[1]
        oos = len(parts) > 2 and parts[2].strip() == "1"
        cents = int(round(float(price) * 100))
        rows.append((name, cents, oos))
    return rows


def build() -> Dict:
    """Emit a menu_schema document."""
    # `import restaurant_pink_garlic as pg` used to sit here and was never
    # referenced; that module was deleted on 2026-09-30 along with the other
    # five per-restaurant Python configs (REDUNDANCY_AUDIT_2026-09-30.md §2).
    rows = load_rows()
    seen_ids = {}
    items = []
    for raw, cents, oos in rows:
        display = spoken(raw)
        cat = category_for(raw, display)
        # Square lists "09. PG Chk" ($6.99 starter) and "40. Pink garlic Chk"
        # ($13.99 entree) — the same spoken name for two dishes at different
        # prices. A caller cannot pronounce the capital letter, so the
        # category goes into the name and Lily can ask which one they meant.
        if cat == "appetizer" and display.lower() == "pink garlic chicken":
            display = "Pink Garlic Chicken (Starter)"
        iid = slug(raw)
        # Square has genuine duplicate names ("106. Naan" and "103. Plain
        # Naan"); keep both but keep the id unique.
        if iid in seen_ids:
            seen_ids[iid] += 1
            iid = f"{iid}_{seen_ids[iid]}"
        else:
            seen_ids[iid] = 0
        entry = {
            "id": iid,
            "name": display,
            "price": f"{cents // 100}.{cents % 100:02d}",
            "category": cat,
            "aliases": aliases_for(display, raw, cat),
        }
        g = groups_for(cat)
        if g:
            entry["groups"] = list(g)
        if oos:
            entry["available"] = False
        items.append(entry)
    return items


PINK_GARLIC_REVIEW = """
CONFIRM WITH THE OWNER BEFORE GOING LIVE
========================================
Names and prices are verbatim from the Square site. These are the judgements
made on top of them:

1. SPICE LEVEL is required on every curry, tandoori, biryani, seafood,
   vegetable and indo-chinese dish. It is NOT asked on breads, rice,
   desserts, drinks, sides, soups, salads, appetizers or kids items.
   -> Is spice asked on appetizers? Chicken 65 and pakora are often spiced.

2. PREFERENCE (goat bone-in vs lamb boneless) is asked ONLY on the
   thirteen "Lamb/Goat" dishes plus Lamb/Goat Biryani.
   -> Correct? Tandoori Lamb Chops does not get it. Should it?

3. PARTY TRAYS get spice level but not ADD.
   -> A tray is "any chicken dish" — does the caller also choose WHICH dish?
      The engine cannot yet express a modifier whose options are other menu
      items, so today this is a note to the kitchen.

4. Items 110, 117, 118, 15, 23 are absent from the online menu.
   -> Do they exist on the printed menu?

5. "106. Naan" ($1.99) and "106. Garlic Cheese Naan" ($3.50) share a number,
   and "113." is both Aloo Paratha and Gulab Jamun.
   -> Square data entry error, or two real items? Numbers are spoken by
      callers ("number 113"), so a duplicate is an ambiguity on a live call.

6. Out of stock right now: Paneer Tikka Shaslik, Gulab Jamun.
   -> Temporary, or delisted?

7. Three locations (Shelby Twp, Oak Park, Allen Park) share this menu. You
   said prices are the same at all three. Each still needs its own inbound
   number so the ticket reaches the right kitchen.
"""


if __name__ == "__main__":
    import yaml
    import menu_schema as ms

    items = build()
    existing = yaml.safe_load((HERE / "menus" / "pink-garlic-shelby.yaml").read_text())

    doc = {
        "schema_version": existing["schema_version"],
        "restaurant": existing["restaurant"],
        "options": existing["options"],
        "groups": existing["groups"],
        "items": items,
    }
    out = HERE / "menus" / "pink-garlic-shelby.yaml"
    out.write_text(yaml.safe_dump(doc, sort_keys=False, allow_unicode=True,
                                  width=100))
    cats: Dict[str, int] = {}
    for i in items:
        cats[i["category"]] = cats.get(i["category"], 0) + 1
    print(f"{len(items)} items written to {out.name}")
    for c, n in sorted(cats.items(), key=lambda kv: -kv[1]):
        print(f"   {c:16s} {n}")

# NOTE (2026-10-02): menus/*.yaml are now the SOURCE OF TRUTH.
# Re-running this builder REGENERATES the YAML from the captured TSV and
# will OVERWRITE hand-edits made since (spoken aliases added by the
# language pass — "papadams", "spright" — and any owner answers). Do not
# re-run without diffing against the current YAML first.
