#!/usr/bin/env python3
"""Restaurant-specific order scenarios for the next three pilot brands."""

from __future__ import annotations

import traceback
from pathlib import Path

import menu_schema as ms
from order_engine import OrderEngine


ROOT = Path(__file__).resolve().parent
_passed = _failed = 0


def check(name, condition, detail=""):
    global _passed, _failed
    if condition:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


def engine(menu: str) -> OrderEngine:
    return OrderEngine(ms.load_yaml(ROOT / "menus" / menu))


def t_pink_garlic_lamb_saag_and_two_naan() -> None:
    e = engine("pink-garlic-shelby.yaml")
    curry = e.add_line("pg_lamb_goat_saag")
    check("Pink Garlic accepts medium plus",
          not e.apply_option(curry.line_id, "pg_spice", "pg_med_plus"))
    check("Pink Garlic records boneless lamb",
          not e.apply_option(curry.line_id, "pg_preference", "pg_lamb"))
    check("Pink Garlic accepts extra vegetables",
          not e.apply_option(curry.line_id, "pg_add", "pg_add_veg"))
    e.add_line("pg_garlic_naan", quantity=2)
    price = e.price()
    check("the complete Pink Garlic order can submit", e.is_submittable(), str(e.validate()))
    check("Pink Garlic subtotal is exact", price.subtotal_cents == 2399, str(price))
    check("Pink Garlic tax and total are exact",
          (price.tax_cents, price.total_cents) == (144, 2543), str(price))


def t_miyazaki_calcifer_requires_exact_roll_counts() -> None:
    e = engine("miyazaki-hall-rd.yaml")
    tray = e.add_line("my_tray_calcifer")
    basics = ("my_basic_california", "my_basic_spicy_tuna",
              "my_basic_shrimp_tempura", "my_basic_eel_avocado",
              "my_basic_philadelphia")
    specials = ("my_special_dragon", "my_special_rainbow")
    for option in basics:
        e.apply_option(tray.line_id, "my_tray5_basic", option)
    check("Calcifer still asks for two special rolls", not e.is_submittable())
    for option in specials:
        e.apply_option(tray.line_id, "my_tray2_special", option)
    price = e.price()
    check("Calcifer submits after five basic and two special", e.is_submittable(), str(e.validate()))
    check("included rolls do not add hidden charges",
          (price.subtotal_cents, price.tax_cents, price.total_cents)
          == (7000, 420, 7420), str(price))

    e.apply_option(tray.line_id, "my_tray5_basic", "my_basic_salmon")
    check("a sixth basic roll blocks the tray", not e.is_submittable())


def t_tamago_bibimbap_protein_and_spicy_tuna_roll() -> None:
    e = engine("tamago-sushi-bowl.yaml")
    bowl = e.add_line("tg_rb_bibimbap")
    check("Tamago accepts add chicken",
          not e.apply_option(bowl.line_id, "tg_bibimbap_add", "tg_add_chicken"))
    e.add_line("tg_spicy_tuna_roll")
    price = e.price()
    check("Tamago informational defaults never block checkout",
          e.is_submittable(), str(e.validate()))
    check("Tamago subtotal is exact", price.subtotal_cents == 2200, str(price))
    check("Tamago tax and total are exact",
          (price.tax_cents, price.total_cents) == (132, 2332), str(price))


def main() -> int:
    for name, fn in sorted(globals().items()):
        if not name.startswith("t_"):
            continue
        try:
            fn()
        except Exception:
            global _failed
            _failed += 1
            print(f"\n--- FAIL {name}\n{traceback.format_exc()}")
    print(f"\n{_passed} passed, {_failed} failed (next pilot calls)")
    return 1 if _failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
