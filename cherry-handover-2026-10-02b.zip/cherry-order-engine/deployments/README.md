# Pilot locations

For the complete launch sequence, use `DEVELOPER_HANDOFF.md`. For the
forwarding-only phone setup and gateway request contract, use
`VOICE_FORWARDING.md`. Set
`CHERRY_REQUIRE_DIRECT_FALLBACK=1` and a distinct
`CHERRY_DIRECT_FALLBACK_<LOCATION>` before applying a live location. The
manifest fallback numbers are the public numbers and would loop once
they are forwarded to Telnyx.

`pilot-locations.yaml` is the routing plan for the first seven storefronts. It
keeps three things separate for every restaurant:

1. its price catalog;
2. its Telnyx inbound number;
3. its verified direct staff number for human fallback, injected at deployment.

Run the safe preflight at any time:

```bash
python3 pilot_deploy.py plan
```

To activate one location, put its Telnyx number in the environment and select
that location explicitly:

```bash
export CHERRY_INBOUND_MIYAZAKI_HALL_RD='+1...'
python3 pilot_deploy.py apply --db cherry.db --only miyazaki-hall-rd
python3 pilot_deploy.py verify --db cherry.db --only miyazaki-hall-rd
```

The command checks every selected menu before opening the database and makes no
changes when any selected location is incomplete. All seven locations can be
configured for offline menu/routing tests with the manual sink, but none may
take paid-review customer traffic that way: every pilot menu now requires an
itemized checkout on every order. A missing provider holds the order rather
than submitting an unpaid kitchen ticket.
Run `verify` after deployment and again immediately before switching Telnyx
traffic. It is read-only and fails on mismatched routes, fallbacks, live menus,
inactive restaurants, missing settings, or duplicate inbound numbers.

Before live traffic, connect each merchant's itemized checkout. Square is the
only production checkout provider implemented here; its checkout inlines the
full Cherry order and the paid Square order itself becomes the POS order.
Set per-location `SQUARE_TOKEN_<LOCATION_ID>` and
`SQUARE_LOCATION_<LOCATION_ID>` in the deployment secret manager, along with
real Telnyx SMS settings. Set `CHERRY_CHECKOUT_HANDOFF_ONLY=1` in the Cherry
server and scheduled jobs; the Square webhook is optional for call completion
and must never release a second kitchen ticket. Then reapply that
location with `--sink square`, run `checkout-ready`, and complete a real
payment/POS acceptance test. A generic restaurant website URL is **not** an
order-specific payment link. Bun N Run or another Toast-only restaurant must
remain held until an equivalent itemized checkout is connected or its owner
authorizes the supported Square path.

```bash
python3 pilot_deploy.py apply --db cherry.db --only bun-n-run-ferndale --sink square
python3 pilot_deploy.py checkout-ready --db cherry.db --only bun-n-run-ferndale
```

## Current readiness

| Location | Catalog | Remaining activation input |
|---|---|---|
| Bun N Run — Ferndale | Menu passes | Its Telnyx number + owner reconfirmation of fallback number |
| Bun N Run — Clinton Twp | Menu passes | Its Telnyx number + owner reconfirmation of fallback number |
| Pink Garlic — Shelby Twp | 144-item menu passes | Its Telnyx number |
| Pink Garlic — Oak Park | 128-item location menu passes | Owner price signoff + Telnyx number; Square mapping only when activated |
| Pink Garlic — Allen Park | 114-item location menu passes | Owner price signoff + Telnyx number; Square mapping only when activated |
| Miyazaki — Hall Rd | 48-item menu passes | Its Telnyx number |
| Tamago — Hall Rd | 120-item menu passes | Its Telnyx number |

Pink Garlic catalogs must stay separate. Public ordering pages checked on
2026-09-20 show location differences: Shelby lists Butter Chicken at $14.49;
Oak Park and Allen Park list it at $14.99, and Allen Park uses different menu
numbering for several dishes. Copying Shelby's file would silently undercharge.

The published restaurant numbers in the manifest are **not** valid human
fallback numbers once they forward to Cherry. Obtain and configure a separate
direct staff line for each location before live traffic.

## Verify the two location-specific Pink Garlic menus

The menus were built from their public location ordering pages on 2026-09-20.
Regenerate them with `python3 build_pink_garlic_locations.py`, then have the
owner confirm the resulting item/price diff. Once OAuth exists, the Square export
below becomes the authoritative automated check and supplies stable POS ids.

Run this on the deployment machine when Square OAuth is connected. Keep the
token in the environment; do not paste it into a command, document or chat.
Generated exports are git-ignored.

```bash
export SQUARE_ACCESS_TOKEN='set-this-locally'

python3 square_catalog_export.py \
  --location-id LSFWCTW65XAXP \
  --out catalog-exports/pink-garlic-oak-park.json

python3 location_catalog.py \
  --base menus/pink-garlic-shelby.yaml \
  --export catalog-exports/pink-garlic-oak-park.json \
  --square-location-id LSFWCTW65XAXP \
  --restaurant-id pink-garlic-oak-park \
  --restaurant-name 'Pink Garlic Indian Cuisine (Oak Park)' \
  --out menus/pink-garlic-oak-park.yaml

python3 square_catalog_export.py \
  --location-id L5CT4TPKS4CKA \
  --out catalog-exports/pink-garlic-allen-park.json

python3 location_catalog.py \
  --base menus/pink-garlic-shelby.yaml \
  --export catalog-exports/pink-garlic-allen-park.json \
  --square-location-id L5CT4TPKS4CKA \
  --restaurant-id pink-garlic-allen-park \
  --restaurant-name 'Pink Garlic Indian Cuisine (Allen Park)' \
  --out menus/pink-garlic-allen-park.yaml
```

The builder must report a passing Cherry gate before either file is kept. If
Square has an extra, missing, duplicated or ambiguous entry, it prints the
complete review list and writes no menu. After both files pass, set their
`menu` paths and `catalog_status: ready` in `pilot-locations.yaml`.
