"""Authenticated, idempotent Square payment webhook handling."""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
from datetime import datetime, timezone
from typing import Callable, Optional

import payments


class SquareWebhookError(ValueError): pass


def verify(raw: bytes, signature: str, signature_key: str,
           notification_url: str) -> None:
    if not signature_key or not notification_url:
        raise SquareWebhookError("Square webhook authentication is not configured")
    digest=hmac.new(signature_key.encode(),notification_url.encode()+raw,hashlib.sha256).digest()
    expected=base64.b64encode(digest).decode()
    if not hmac.compare_digest(expected,signature or ""):
        raise SquareWebhookError("invalid Square webhook signature")


def handle(store, payload: dict,
           on_paid: Optional[Callable[[str], dict]] = None) -> dict:
    event_id=str(payload.get("event_id") or "")
    event_type=str(payload.get("type") or "")
    if not event_id: raise SquareWebhookError("Square event has no event_id")
    if not store.claim_webhook("square",event_id,event_type):
        return {"action":"duplicate","event_id":event_id}
    try:
        if event_type not in {"payment.created","payment.updated"}:
            return {"action":"ignored","event_type":event_type}
        payment=(((payload.get("data") or {}).get("object") or {}).get("payment") or {})
        order_ref=str(payment.get("order_id") or "")
        payment_ref=str(payment.get("id") or "")
        if not order_ref or not payment_ref:
            return {"action":"ignored","reason":"no order/payment reference"}
        row=store.conn.execute(
            """SELECT p.order_id,p.status,p.amount_cents,
               p.pos_payment_ref,o.restaurant_id,o.session_id
               FROM payment p JOIN "order" o ON o.id=p.order_id
               WHERE p.pos_payment_ref=?""",
            (order_ref,)
        ).fetchone()
        if not row:return {"action":"ignored","reason":"unknown payment"}
        status=str(payment.get("status") or "").upper()
        if status=="COMPLETED":
            money=payment.get("amount_money") or {}
            amount=money.get("amount")
            currency=str(money.get("currency") or "").upper()
            if amount is None or int(amount) != int(row["amount_cents"]) \
                    or currency != "USD":
                detail={"expected_cents":int(row["amount_cents"]),
                        "received_cents":amount,"currency":currency}
                store.log_event("payment.amount_mismatch",
                    restaurant_id=row["restaurant_id"],order_id=row["order_id"],
                    detail=detail)
                if row["session_id"]:
                    store.escalate(row["session_id"],"payment amount mismatch")
                return {"action":"amount_mismatch","order_id":row["order_id"]}
            if row["status"]=="expired":
                store.log_event("payment.completed_after_expiry",
                    restaurant_id=row["restaurant_id"],order_id=row["order_id"],
                    detail={"pos_ref":payment_ref})
                if row["session_id"]:
                    store.escalate(row["session_id"],
                                   "payment completed after checkout expiry")
                return {"action":"paid_after_expiry","order_id":row["order_id"]}
            # Square may include card_details in the signed webhook. Never
            # pass that payload to the store or audit log; allow only the
            # fields needed to prove this specific order's payment.
            safe_payment={"id":payment_ref,"order_id":order_ref,
                          "status":status,"amount_money":{
                              "amount":amount,"currency":currency}}
            changed=payments.mark_paid(store,row["order_id"],payment_ref,
                                       {"payment":safe_payment})
            released=on_paid(row["order_id"]) if on_paid else None
            return {"action":"paid" if changed else "already_paid",
                    "order_id":row["order_id"],"release":released}
        if status in ("FAILED","CANCELED"):
            # One declined card is an ATTEMPT, not the end of the checkout:
            # the guest can retry on the same link, and a later COMPLETED must
            # still be honoured. Marking the order failed here made a paid
            # customer's money arrive on an order Cherry had given up on. The
            # link simply expires if they never succeed.
            store.log_event("payment.attempt_failed",
                            restaurant_id=row["restaurant_id"],
                            order_id=row["order_id"],
                            detail={"pos_ref":payment_ref,"status":status})
            return {"action":"attempt_failed","order_id":row["order_id"]}
        return {"action":"pending","status":status}
    except Exception:
        store.release_webhook("square",event_id)
        raise
