"""
The Inworld event adapter — Cherry's ears and mouth, as a contract.

WHY THIS EXISTS
---------------
`FIRST_CUSTOMER.md` says it plainly: the engine runs, the phone does not.
`voice_gateway.py` exposes the call-lifecycle contract and
`voice/inworld_bridge.py` implements it, but nothing translated *Inworld's*
events into that contract. That translation is this module, and it is the last
piece of code between the pilot menus and a live call.

WHAT IS STILL UNKNOWN, AND HOW THAT IS CONTAINED
-----------------------------------------------
Inworld's exact event and field names are not confirmed — that is the open
question in `DEVELOPER_HANDOFF.md` §Phase 3. Everything that depends on those
names is therefore isolated in ONE place: the `Dialect` below. Every field is
read through it and every name is overridable by environment variable, so when
SIP access arrives the answer changes a configuration value, not this file:

    CHERRY_INWORLD_CALL_ID_FIELD=conversation_id
    CHERRY_INWORLD_TYPE_FIELD=event_type

`python3 inworld_adapter.py dialect` prints the live mapping, and
`python3 inworld_adapter.py check` tells you whether a real payload from
Inworld can be understood — run it against one captured event before anything
else.

THE ONE RULE
------------
An event this adapter cannot understand is an ERROR, never a silent no-op.
A dropped `call_started` is a caller listening to silence; a dropped `tool_call`
is an order that never happens. So `normalize_event()` raises rather than
returning None, and unknown *tool names* are rejected before they reach Cherry
instead of being forwarded hopefully.

WHAT IT DELIBERATELY DOES NOT DO
--------------------------------
It does not terminate SIP or RTP and it does not synthesise audio. Inworld owns
ASR, tool selection and TTS; this returns the exact text to speak. That keeps
one owner per concern and matches `voice_gateway.py`'s stated contract.
"""

from __future__ import annotations

import argparse
import collections
import json
import logging
import os
import re
import time
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from voice.inworld_bridge import CherryBridge

log = logging.getLogger("cherry.inworld.adapter")


class UnknownEvent(ValueError):
    """An event shape this adapter does not understand. Never swallowed."""


class UnknownTool(ValueError):
    """A tool name that is not in Cherry's schema list."""


#: Spoken when an event cannot be acted on. A silent reply is a caller
#: listening to nothing; this at least invites them to try again.
RETRY_SAY = "Sorry, I didn't catch that — could you say it again?"
#: Spoken when a transfer is asked for on a call this process cannot route.
NO_ROUTE_SAY = ("I'm sorry, I can't transfer you from here. Please try again "
                "in a few minutes.")

_E164_DIGITS = re.compile(r"\d")


def normalize_number(raw: Any) -> str:
    """'sip:+12485550111@host', 'tel:+1 (248) 555-0111', '2485550111' -> E.164.

    Telephony providers hand over the dialled DID in several shapes and Cherry
    routes by exact match, so a SIP URI that "looks right" would silently find
    no restaurant. Returns "" for anything that is not a usable number (a
    withheld caller ID arrives as 'anonymous', 'private' or 'unknown').
    """
    if not isinstance(raw, str):
        return ""
    text = raw.strip()
    for prefix in ("sip:", "sips:", "tel:"):
        if text.lower().startswith(prefix):
            text = text[len(prefix):]
    text = text.split("@", 1)[0].split(";", 1)[0]
    digits = "".join(_E164_DIGITS.findall(text))
    if not 7 <= len(digits) <= 15:
        return ""
    if text.lstrip().startswith("+"):
        return "+" + digits
    if len(digits) == 10:                       # national number, North America
        return "+1" + digits
    if len(digits) == 11 and digits[0] == "1":
        return "+" + digits
    return "+" + digits


# ---------------------------------------------------------------------------
# The dialect: the ONLY place Inworld's field names appear
# ---------------------------------------------------------------------------

def _env(name: str, default: str, env: Optional[Dict[str, str]] = None) -> str:
    source = os.environ if env is None else env
    return (source.get(name) or default).strip()


@dataclass(frozen=True)
class Dialect:
    """How to read an Inworld payload. Every name is env-overridable.

    Defaults follow the most common voice-platform shape and the naming used in
    `DEVELOPER_HANDOFF.md` §8. They are a starting point to be confirmed against
    one real event, not a claim about Inworld's schema.
    """

    type_field: str = "type"
    call_id_field: str = "call_id"
    dialled_field: str = "to"
    caller_field: str = "from"
    tool_field: str = "tool"
    args_field: str = "args"
    reason_field: str = "reason"
    customer_name_field: str = "customer_name"
    language_field: str = "language"

    #: Event-type strings for "the call has begun".
    started_types: Tuple[str, ...] = (
        "call_started", "call.started", "session.started", "session_started",
        "conversation.started", "start")
    #: ...for "the model selected a tool".
    tool_types: Tuple[str, ...] = (
        "tool_call", "tool.call", "function_call", "tool.invoked",
        "tool_selected")
    #: ...for "the call is over".
    ended_types: Tuple[str, ...] = (
        "call_ended", "call.ended", "session.ended", "session_ended",
        "conversation.ended", "hangup", "abandon")
    #: ...for "put a human on the line".
    handoff_types: Tuple[str, ...] = (
        "handoff", "handoff.requested", "transfer", "escalate")
    #: ...for "the caller is done: place the order". Without one of these (or
    #: the `ready_to_place` tool, which does the same) an order is never
    #: placed and the call ends as an abandoned session.
    finish_types: Tuple[str, ...] = (
        "finish", "call_finish", "order_finish", "order_complete",
        "order.complete", "place_order", "checkout")
    #: Field names that may carry a tool's arguments.
    args_aliases: Tuple[str, ...] = ("arguments", "parameters", "input")
    #: Field names that may carry a per-event id, for replay protection.
    event_id_fields: Tuple[str, ...] = (
        "event_id", "tool_call_id", "id", "message_id")

    #: Payload keys that may hold a list of events instead of one event.
    batch_fields: Tuple[str, ...] = ("events", "data", "messages")

    @staticmethod
    def from_env(env: Optional[Dict[str, str]] = None) -> "Dialect":
        e = lambda name, default: _env(name, default, env)   # noqa: E731
        return Dialect(
            type_field=e("CHERRY_INWORLD_TYPE_FIELD", "type"),
            call_id_field=e("CHERRY_INWORLD_CALL_ID_FIELD", "call_id"),
            dialled_field=e("CHERRY_INWORLD_DIALLED_FIELD", "to"),
            caller_field=e("CHERRY_INWORLD_CALLER_FIELD", "from"),
            tool_field=e("CHERRY_INWORLD_TOOL_FIELD", "tool"),
            args_field=e("CHERRY_INWORLD_ARGS_FIELD", "args"),
            reason_field=e("CHERRY_INWORLD_REASON_FIELD", "reason"),
            customer_name_field=e("CHERRY_INWORLD_CUSTOMER_NAME_FIELD",
                                  "customer_name"),
            language_field=e("CHERRY_INWORLD_LANGUAGE_FIELD", "language"),
        )

    def describe(self) -> Dict[str, Any]:
        return {
            "type_field": self.type_field,
            "call_id_field": self.call_id_field,
            "dialled_field": self.dialled_field,
            "caller_field": self.caller_field,
            "tool_field": self.tool_field,
            "args_field": self.args_field,
            "started_types": list(self.started_types),
            "tool_types": list(self.tool_types),
            "ended_types": list(self.ended_types),
            "handoff_types": list(self.handoff_types),
            "finish_types": list(self.finish_types),
        }


DEFAULT_DIALECT = Dialect()


# ---------------------------------------------------------------------------
# Normalised event
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class CallEvent:
    kind: str                       # call_started | tool_call | call_ended | handoff
    call_id: str
    dialled: str = ""
    caller: str = ""
    tool: str = ""
    args: Dict[str, Any] = field(default_factory=dict)
    reason: str = ""
    customer_name: str = ""
    language: str = ""
    event_id: str = ""              # provider's id for this event, if any


def _first(payload: Dict[str, Any], names: Iterable[str]) -> Any:
    for n in names:
        if n in payload and payload[n] not in (None, ""):
            return payload[n]
    return None


def split_events(payload: Any, dialect: Dialect = DEFAULT_DIALECT
                 ) -> List[Dict[str, Any]]:
    """Accept one event, a list of events, or a wrapper holding a list.

    Voice platforms differ on this and it is not worth a config knob: all three
    shapes are unambiguous, so all three are accepted.
    """
    if isinstance(payload, list):
        return [p for p in payload if isinstance(p, dict)]
    if not isinstance(payload, dict):
        raise UnknownEvent(f"expected an event object, got {type(payload).__name__}")
    # An object that has its own event type and call id IS an event, even if
    # it also carries a list under "data" or "events" (a tool result, say).
    if dialect.type_field in payload and dialect.call_id_field in payload:
        return [payload]
    for key in dialect.batch_fields:
        inner = payload.get(key)
        if isinstance(inner, list):
            return [p for p in inner if isinstance(p, dict)]
    return [payload]


def normalize_event(raw: Dict[str, Any],
                    dialect: Dialect = DEFAULT_DIALECT) -> CallEvent:
    """One Inworld event -> one `CallEvent`. Raises on anything unrecognised."""
    if not isinstance(raw, dict):
        raise UnknownEvent(f"event must be an object, got {type(raw).__name__}")

    kind_raw = raw.get(dialect.type_field)
    if not isinstance(kind_raw, str) or not kind_raw.strip():
        raise UnknownEvent(
            f"no event type in field {dialect.type_field!r}; set "
            f"CHERRY_INWORLD_TYPE_FIELD if Inworld names it differently "
            f"(keys seen: {sorted(raw)[:12]})")
    kind = kind_raw.strip().lower().replace("-", "_")

    call_id = raw.get(dialect.call_id_field)
    if not isinstance(call_id, str) or not call_id.strip():
        raise UnknownEvent(
            f"event {kind_raw!r} has no call id in field "
            f"{dialect.call_id_field!r}; set CHERRY_INWORLD_CALL_ID_FIELD")
    call_id = call_id.strip()
    event_id = str(_first(raw, dialect.event_id_fields) or "")

    if kind in dialect.started_types:
        dialled = raw.get(dialect.dialled_field)
        if not isinstance(dialled, str) or not dialled.strip():
            raise UnknownEvent(
                f"call {call_id} started with no dialled number in field "
                f"{dialect.dialled_field!r}; Cherry routes calls by the DID, so "
                f"without it there is no menu to load")
        # The same normalisation /v1/voice/calls applies, so a DID that
        # passes `check` here cannot be refused by the live path.
        number = normalize_number(dialled)
        if not number:
            raise UnknownEvent(
                f"call {call_id} started with an unusable dialled number "
                f"{dialled!r}")
        caller = normalize_number(raw.get(dialect.caller_field))
        language = raw.get(dialect.language_field) or ""
        return CallEvent(kind="call_started", call_id=call_id,
                         dialled=number, caller=caller,
                         language=str(language).strip(), event_id=event_id)

    if kind in dialect.tool_types:
        tool = raw.get(dialect.tool_field)
        nested_args = None
        if isinstance(tool, dict):                    # {"tool": {"name": ...}}
            nested_args = _first(tool, (dialect.args_field,)
                                 + tuple(dialect.args_aliases))
            tool = tool.get("name") or tool.get("tool")
        if not isinstance(tool, str) or not tool.strip():
            raise UnknownEvent(
                f"tool event for call {call_id} names no tool in field "
                f"{dialect.tool_field!r}; set CHERRY_INWORLD_TOOL_FIELD")
        args = raw.get(dialect.args_field)
        if args is None:
            args = _first(raw, dialect.args_aliases)
        if args is None:
            args = nested_args
        if isinstance(args, str):
            try:
                args = json.loads(args)
            except ValueError as exc:
                raise UnknownEvent(
                    f"tool {tool!r} arguments are not valid JSON: {exc}") from exc
        if args is None:
            args = {}
        if not isinstance(args, dict):
            raise UnknownEvent(
                f"tool {tool!r} arguments must be an object, got "
                f"{type(args).__name__}")
        return CallEvent(kind="tool_call", call_id=call_id,
                         tool=tool.strip(), args=dict(args), event_id=event_id,
                         customer_name=str(args.get(dialect.customer_name_field)
                                           or ""))

    if kind in dialect.ended_types:
        return CallEvent(kind="call_ended", call_id=call_id, event_id=event_id,
                         reason=str(raw.get(dialect.reason_field)
                                    or "caller_hung_up").strip())

    if kind in dialect.finish_types:
        return CallEvent(kind="finish", call_id=call_id, event_id=event_id,
                         customer_name=str(
                             raw.get(dialect.customer_name_field) or "").strip())

    if kind in dialect.handoff_types:
        return CallEvent(kind="handoff", call_id=call_id, event_id=event_id,
                         dialled=normalize_number(raw.get(dialect.dialled_field)),
                         reason=str(raw.get(dialect.reason_field)
                                    or "worker requested handoff").strip())

    raise UnknownEvent(
        f"unrecognised event type {kind_raw!r}. Known: "
        f"{sorted(set(dialect.started_types) | set(dialect.tool_types) | set(dialect.ended_types) | set(dialect.handoff_types) | set(dialect.finish_types))}. "
        f"If Inworld names the FIELD differently, set "
        f"CHERRY_INWORLD_TYPE_FIELD. If it uses a different WORD for this "
        f"event, add it to Dialect's type lists — a dropped event is a silent "
        f"caller, so this is deliberately fatal rather than ignored.")


# ---------------------------------------------------------------------------
# The adapter
# ---------------------------------------------------------------------------


class InworldAdapter:
    """Inworld events in, text to speak out.

    Holds the tool list so an unknown tool is rejected here rather than sent to
    Cherry to fail there, and keeps the last spoken line per call so the worker
    can be checked against what the engine actually said.
    """

    def __init__(self, bridge: CherryBridge, *,
                 dialect: Optional[Dialect] = None,
                 tool_names: Optional[Iterable[str]] = None) -> None:
        self.bridge = bridge
        self.dialect = dialect or DEFAULT_DIALECT
        self.tool_names: Optional[set] = (set(tool_names)
                                          if tool_names is not None else None)
        # Bounded: this object lives as long as the gateway process.
        self.handled: "collections.deque[CallEvent]" = collections.deque(maxlen=500)
        # Replies to events already applied, so a provider retry of the same
        # event (a timeout, a re-delivery) repeats the answer instead of
        # adding the item twice.
        self._replies: "collections.OrderedDict[str, str]" = collections.OrderedDict()
        self._tools_failed_at: Optional[float] = None

    # -- startup ---------------------------------------------------------
    async def load_tools(self) -> List[Dict[str, Any]]:
        """The schemas to register with the Inworld agent before any call."""
        tools = await self.bridge.tool_schemas()
        names = []
        for t in tools:
            if not isinstance(t, dict) or not t.get("name"):
                raise UnknownEvent(f"malformed tool schema from Cherry: {t!r}")
            names.append(t["name"])
        self.tool_names = set(names)
        return tools

    async def ensure_tools(self) -> None:
        """Load the tool list once, lazily.

        Lazy on purpose: the gateway must start even if Cherry is restarting,
        because a gateway that refuses to boot takes every restaurant down with
        it. If loading fails the adapter keeps working and forwards tool calls
        to Cherry, which will refuse an unknown one anyway — the guard is a
        better error message, not the only line of defence.
        """
        if self.tool_names is not None:
            return
        # While Cherry is unreachable every tool call would otherwise spend
        # a full timeout here first, on top of its own: back off for a minute.
        if (self._tools_failed_at is not None
                and time.monotonic() - self._tools_failed_at < 60.0):
            return
        try:
            await self.load_tools()
            self._tools_failed_at = None
        except Exception as exc:                       # noqa: BLE001
            self._tools_failed_at = time.monotonic()
            log.warning("could not load Cherry's tool list, forwarding tools "
                        "unchecked: %s", exc)

    # -- dispatch --------------------------------------------------------
    async def dispatch(self, event: CallEvent) -> Optional[str]:
        """Run one event. Returns the text to speak, or None if there is none."""
        self.handled.append(event)

        if event.kind == "call_started":
            return await self.bridge.start(event.call_id,
                                           dialled=event.dialled,
                                           caller=event.caller)

        if event.kind == "finish" or (event.kind == "tool_call"
                                      and event.tool == "ready_to_place"):
            # `ready_to_place` is the model saying the caller is done. On the
            # worker path the worker then calls /finish; here nothing else
            # will, so this is what books the order and texts the checkout.
            # bridge.finish() re-checks readiness itself and, if the order is
            # not complete, returns the question to ask instead of placing it.
            return await self.bridge.finish(event.call_id, event.customer_name)

        if event.kind == "tool_call":
            await self.ensure_tools()
            if self.tool_names is not None and event.tool not in self.tool_names:
                # Do not forward: Cherry would 404 and the caller would hear
                # the generic failure line instead of a useful correction.
                raise UnknownTool(
                    f"{event.tool!r} is not one of Cherry's tools "
                    f"({len(self.tool_names)} loaded)")
            return await self.bridge.handle_tool_call(event.call_id, event.tool,
                                                      event.args)

        if event.kind == "call_ended":
            await self.bridge.abandon(event.call_id, event.reason)
            return None

        if event.kind == "handoff":
            try:
                if event.dialled:
                    return await self.bridge.request_handoff(
                        event.call_id, dialled=event.dialled)
                return await self.bridge.request_handoff(event.call_id)
            except LookupError:
                return NO_ROUTE_SAY

        raise UnknownEvent(f"unhandled event kind {event.kind!r}")

    async def handle_payload(self, payload: Any) -> Dict[str, Any]:
        """A whole webhook body in, an Inworld-shaped reply out.

        Events are processed in order. The reply carries every line the worker
        must speak, plus the last one as `say` for platforms that take a single
        utterance. `spoken` is what the worker is expected to have said, so
        `bridge.verbatim_audit()` can prove it did not improvise.
        """
        spoken: List[str] = []
        errors: List[str] = []
        handled = 0
        replies: List[Dict[str, str]] = []
        for raw in split_events(payload, self.dialect):
            call_hint = str(raw.get(self.dialect.call_id_field) or "") \
                if isinstance(raw, dict) else ""
            try:
                event = normalize_event(raw, self.dialect)
                key = (f"{event.call_id}:{event.event_id}"
                       if event.event_id else "")
                if key and key in self._replies:
                    said = self._replies[key]          # a retry: same answer
                else:
                    said = await self.dispatch(event)
                    if key:
                        CherryBridge._remember(self._replies, key, said or "",
                                               limit=5000)
                handled += 1
            except (UnknownEvent, UnknownTool) as exc:
                # Loud, but not fatal to the rest of the batch: one bad event
                # must not silence the other calls in the payload. The caller
                # is told to try again rather than left in silence.
                log.error("inworld event rejected: %s", exc)
                errors.append(str(exc))
                if call_hint:
                    replies.append({"call_id": call_hint, "say": RETRY_SAY})
                    spoken.append(RETRY_SAY)
                continue
            if said:
                spoken.append(said)
                replies.append({"call_id": event.call_id, "say": said})

        out: Dict[str, Any] = {
            "ok": not errors,
            "spoken": spoken,
            "say": spoken[-1] if spoken else "",
            # Events handled *in this payload*, not since the process started:
            # a worker retrying a batch needs to know what this call did.
            "events": handled,
            # `say` is only right for a single-call payload. A batch can
            # hold several calls, so each line is also given with its call.
            "replies": replies,
        }
        if errors:
            out["errors"] = errors
        return out


# ---------------------------------------------------------------------------
# CLI — the two things you need when SIP access lands
# ---------------------------------------------------------------------------


def _sample_events() -> List[Dict[str, Any]]:
    return [
        {"type": "call_started", "call_id": "demo-1",
         "to": "+12485550111", "from": "+12485551234"},
        {"type": "tool_call", "call_id": "demo-1", "tool": "add_item",
         "args": {"text": "butter chicken"}},
        {"type": "call_ended", "call_id": "demo-1", "reason": "caller_hung_up"},
    ]


def main(argv: Optional[Sequence[str]] = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("command", choices=("dialect", "check", "sample"))
    ap.add_argument("--file", help="a captured Inworld payload to check")
    args = ap.parse_args(argv)

    if args.command == "dialect":
        print(json.dumps(Dialect.from_env().describe(), indent=2))
        return 0

    if args.command == "sample":
        print(json.dumps(_sample_events(), indent=2))
        return 0

    # check: can this adapter actually read the payloads Inworld sends?
    if args.file:
        raw = json.loads(open(args.file).read())
    else:
        print("no --file given; checking the built-in sample instead")
        raw = _sample_events()

    dialect = Dialect.from_env()
    ok = bad = 0
    for item in split_events(raw, dialect):
        try:
            ev = normalize_event(item, dialect)
            print(f"  ok   {ev.kind:14} call={ev.call_id} "
                  f"{ev.tool or ev.dialled or ev.reason}")
            ok += 1
        except UnknownEvent as exc:
            print(f"  FAIL {exc}")
            bad += 1
    print(f"\n{ok} understood, {bad} not. "
          f"Fields in use: {json.dumps(dialect.describe(), indent=None)[:160]}...")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
