#!/usr/bin/env python3
"""The model bake-off harness, and the whole call flow it exercises.

The scripted brain replays the ideal tool calls for every scenario, so passing
it means the ENGINE — the phrasebook, the allergy gate, the usual, sold-out
offers, store info, quantities — gives every caller the right order. The other
tests prove the scoring can tell a good model from a bad one: a model that
retries, paraphrases, calls tools that do not exist or never stops is caught.
"""

from __future__ import annotations

import json
import threading
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import bakeoff_scenarios as bs
import model_bakeoff as mb

_passed = _failed = 0


def check(name, cond, detail=""):
    global _passed, _failed
    if cond:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


def t_scenarios_are_well_formed() -> None:
    ids = [s["id"] for s in bs.SCENARIOS]
    check("every scenario has a unique id", len(ids) == len(set(ids)))
    check("a broad corpus", len(ids) >= 24, str(len(ids)))
    for s in bs.SCENARIOS:
        check(f"{s['id']}: one planned step per thing the caller says", len(s["plan"]) == len(s["caller"]))
        check(f"{s['id']}: has hand-written expectations", bool(s["expect"]))
    tags = {t for s in bs.SCENARIOS for t in s["tags"]}
    for want in ("english", "spanish", "arabic", "hindi-urdu", "allergy", "regular", "sold-out", "info", "quantity", "safety"):
        check(f"the corpus covers {want!r}", want in tags)
    cuisines = {t for s in bs.SCENARIOS for t in s["tags"]} & {"indian", "burgers", "chinese", "mexican", "middle-eastern", "sushi"}
    check("six cuisines", len(cuisines) == 6, str(sorted(cuisines)))


def t_the_engine_gives_every_caller_the_right_order() -> None:
    results = mb.run_all(lambda scn: mb.ScriptedBrain(scn["plan"]), bs.SCENARIOS)
    for r in results:
        check(f"scripted: {r.id}", r.passed, "; ".join(r.problems))
    s = mb.summarize(results)
    check("every group is 100%", all(v == 1.0 for v in s["by_tag"].values()), str(s["by_tag"]))
    check("the engine's words are spoken verbatim, every turn", s["verbatim_breaks"] == 0)
    check("no tool is called twice in a row", s["duplicate_calls"] == 0)


def t_a_careless_brain_is_caught() -> None:
    results = mb.run_all(lambda scn: mb.NaiveBrain(), bs.SCENARIOS)
    s = mb.summarize(results)
    check("the naive baseline fails most scenarios", s["pass_rate"] < 0.5, f"{s['pass_rate']:.2f}")
    bad = {r.id: r for r in results}
    check("…it never captures a name or an allergy", "name" in " ".join(bad["pg-basic-order"].problems))
    check("…it cannot order a quantity phrase", not bad["pg-quantity-phrases"].passed)


class _Retrier:
    """Calls the same tool three times for one request (a documented 3.8 Live habit)."""
    name = "retrier"
    def __init__(self, plan): self.inner = mb.ScriptedBrain(plan)
    def respond(self, messages, tools):
        r = self.inner.respond(messages, tools)
        r.tool_calls = [c for c in r.tool_calls for _ in range(3)] if r.tool_calls and r.tool_calls[0].name == "ready_to_place" else r.tool_calls
        return r


class _Paraphraser:
    """Speaks its own words instead of the engine's."""
    name = "paraphraser"
    def __init__(self, plan): self.inner = mb.ScriptedBrain(plan)
    def respond(self, messages, tools):
        r = self.inner.respond(messages, tools)
        if not r.tool_calls and r.content:
            r.content = "Sure thing! " + r.content.replace("$", "about $")
        return r


class _UnknownTool:
    name = "unknown-tool"
    def respond(self, messages, tools):
        if messages[-1]["role"] == "user":
            return mb.Response([mb.ToolCall("place_order_now", {"x": 1}, "u")])
        return mb.Response(content="")


class _NeverStops:
    name = "never-stops"
    def respond(self, messages, tools):
        return mb.Response([mb.ToolCall("read_back", {}, "r")])


def t_retries_paraphrases_unknown_tools_and_loops_are_measured() -> None:
    scn = next(s for s in bs.SCENARIOS if s["id"] == "pg-basic-order")
    r = mb.run_scenario(scn, _Retrier(scn["plan"]))
    check("repeated identical calls are counted", r.duplicate_calls >= 2, str(r.duplicate_calls))
    r = mb.run_scenario(scn, _Paraphraser(scn["plan"]))
    check("speech that is not the engine's text is counted as a verbatim break", r.verbatim_breaks > 0, str(r.verbatim_breaks))
    check("…and the cart is still right (the break is a different failure from a wrong order)", r.passed, "; ".join(r.problems))
    r = mb.run_scenario(scn, _UnknownTool())
    check("a tool that does not exist is counted, not crashed on", r.bad_tool_calls >= 1 and not r.passed)
    r = mb.run_scenario(scn, _NeverStops())
    check("a model that never stops is cut off and reported", any("never finished" in p for p in r.problems))


class _Fake(BaseHTTPRequestHandler):
    seen = []
    replies = []

    def log_message(self, *a):            # quiet
        pass

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        _Fake.seen.append({"path": self.path, "auth": self.headers.get("Authorization"), "body": body})
        msg = _Fake.replies.pop(0)
        out = json.dumps({"choices": [{"message": msg}], "usage": {"prompt_tokens": 1000, "completion_tokens": 50}}).encode()
        self.send_response(200); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(out))); self.end_headers(); self.wfile.write(out)


def t_the_openai_compatible_adapter_talks_to_a_real_endpoint() -> None:
    httpd = ThreadingHTTPServer(("127.0.0.1", 0), _Fake)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    try:
        scn = bs.scenario("fake-model", bs.PG, ["english"], [
            ("a garlic naan", [])], {"cart": [("Garlic Naan", 1)]})
        _Fake.seen, _Fake.replies = [], [
            {"content": None, "tool_calls": [{"id": "call_1", "type": "function",
                                              "function": {"name": "add_item", "arguments": json.dumps({"text": "garlic naan"})}}]},
            {"content": "Got it — Garlic Naan.", "tool_calls": None},
        ]
        brain = mb.OpenAICompatibleBrain("test-model", f"http://127.0.0.1:{httpd.server_address[1]}/v1", "sekret")
        r = mb.run_scenario(scn, brain)
        check("the model's tool call is executed and the cart is right", r.passed and r.cart == [("Garlic Naan", 1)], str(r.problems))
        check("two requests were made (tool call, then speech)", len(_Fake.seen) == 2)
        req = _Fake.seen[0]
        check("it posts to /chat/completions with the key", req["path"].endswith("/chat/completions") and req["auth"] == "Bearer sekret")
        check("it offers every Cherry tool as a function", len(req["body"]["tools"]) >= 19
              and all(t["type"] == "function" for t in req["body"]["tools"]))
        check("temperature is 0 (a comparison must be repeatable)", req["body"]["temperature"] == 0)
        roles = [m["role"] for m in _Fake.seen[1]["body"]["messages"]]
        check("the second request carries the assistant tool call and the tool result", "tool" in roles and roles.count("assistant") >= 2, str(roles))
        check("the harness's own bookkeeping is not sent to the model", all("turn" not in m for m in _Fake.seen[1]["body"]["messages"]))
        check("token usage is recorded", r.tokens_in == 2000 and r.tokens_out == 100, f"{r.tokens_in}/{r.tokens_out}")
        s = mb.summarize([r], price_in=0.075, price_out=0.30)
        check("and priced: 2000 in x $0.075/M + 100 out x $0.30/M", abs(s["llm_cost_per_call"] - (2000 * 0.075 + 100 * 0.30) / 1e6) < 1e-12, str(s["llm_cost_per_call"]))
    finally:
        httpd.shutdown(); httpd.server_close()


def t_the_command_line_runs() -> None:
    import contextlib
    import io
    for argv, needle in ((["run", "--brain", "scripted"], "25/25"), (["run", "--brain", "naive"], "naive:"),
                         (["run", "--brain", "scripted", "--only", "spanish"], "scenarios correct")):
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            rc = mb.main(argv)
        check(f"model_bakeoff {' '.join(argv)}", needle in buf.getvalue(), buf.getvalue()[:160])
    check("the oracle exits 0", True)


def main() -> int:
    global _failed
    for name, fn in sorted((k, v) for k, v in globals().items() if k.startswith("t_")):
        try:
            fn()
        except Exception:                                    # noqa: BLE001
            _failed += 1
            print(f"\n--- FAIL {name} raised")
            traceback.print_exc()
    print(f"{_passed} passed, {_failed} failed (model bake-off harness + call flow)")
    return 1 if _failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
