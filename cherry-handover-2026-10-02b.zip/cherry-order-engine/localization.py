"""Provider-neutral, price-safe localization of Cherry's spoken responses."""

from __future__ import annotations

import re


class SafeLocalizer:
    """Protect menu names and money while a configured provider translates prose."""
    def __init__(self, provider=None): self.provider=provider

    def translate(self, text: str, language: str, protected_terms=()) -> str:
        if not text or language in ("", "en") or self.provider is None: return text
        terms=sorted({x for x in protected_terms if x},key=len,reverse=True)
        protected=[]
        def mask(value):
            token=f"__CHERRY_{len(protected)}__";protected.append(value);return token
        masked=re.sub(r"\$\d+(?:\.\d{2})?",lambda m:mask(m.group(0)),text)
        for term in terms:
            masked=re.sub(re.escape(term),lambda m:mask(m.group(0)),masked,flags=re.I)
        translated=str(self.provider.translate(masked,language))
        for i,value in enumerate(protected): translated=translated.replace(f"__CHERRY_{i}__",value)
        if any(token in translated for token in ("__CHERRY_",)):
            raise ValueError("translation provider damaged protected values")
        return translated
