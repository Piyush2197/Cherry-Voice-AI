#!/usr/bin/env python3
"""What a call costs, per architecture — measured where we can, bounded where we cannot.

    python3 call_cost.py compare                       # today's stack vs Gemini Live, per call and per month
    python3 call_cost.py forecast --restaurants 10     # monthly cost and margin at a scale
    python3 call_cost.py actual --db cherry.db         # what the calls in YOUR database cost
    python3 call_cost.py rates                         # every rate, with where it came from

WHY THIS EXISTS
---------------
Choosing a voice stack (the cascaded Inworld STT + LLM + TTS Cherry runs today,
or a native-audio model such as Gemini 3.8 Live) is a cost decision as much as
a quality one, and the two are billed differently:

  * the cascade bills characters spoken, audio transcribed and tokens;
  * Gemini Live bills AUDIO TOKENS in both directions, and Google confirms that
    silent input audio is billed like speech — so a phone call pays for its whole
    length, not just the words.

`company_model.py` already holds the measured call (90 s, 17 s of Lily speaking,
246 characters spoken). This builds on it, and is explicit about what is
VERIFIED (a published price), MEASURED (from our engine) or ASSUMED (a guess you
should challenge). Anything that cannot be known from documentation is given as
a LOW and HIGH estimate rather than one confident number: whether Gemini Live
re-bills the conversation context on every turn is the big one, and the honest
answer is "run one real call and read the bill".
"""

from __future__ import annotations

import argparse
import json
import statistics
import sys
from dataclasses import dataclass, field, replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

import company_model as cm

HERE = Path(__file__).resolve().parent

#: Provenance for every rate: where it came from and how far to trust it.
RATES: Dict[str, Dict[str, Any]] = {
    "inworld_cascade": {
        "label": "Today: Telnyx + Inworld STT + Gemma + Inworld TTS",
        "status": "RATE CARD in company_model.py (2026-09) — re-verify before quoting",
        "telephony_per_min": cm.TELEPHONY_PER_MIN,
        "tts_per_1m_chars": cm.INWORLD_TIERS["creator"][1],
        "stt_per_hour": cm.INWORLD_TIERS["creator"][2],
        "llm_per_1m_tokens": cm.LLM_PER_1M_BLENDED,
        "llm_tokens_per_min": cm.LLM_TOKENS_PER_MIN,          # ASSUMED
    },
    "gemini_live_3_8": {
        "label": "Gemini 3.8 Live (native audio, GA 2026-09-15)",
        "status": "VERIFIED 2026-10-01: ai.google.dev/gemini-api/docs/pricing (page dated 2026-10-01 UTC)",
        "telephony_per_min": cm.TELEPHONY_PER_MIN,             # Telnyx still carries the call
        "audio_in_per_1m": 3.00, "audio_out_per_1m": 12.00,
        "text_in_per_1m": 0.75, "text_out_per_1m": 4.50,
        "audio_tokens_per_second": 25,                         # Google's docs: 25 (a Google staff reply for 2.5 said 32)
        "audio_tokens_per_second_high": 32,
        "silent_audio_billed": True,                           # confirmed for 2.5 native audio; ASSUME the same for 3.8
    },
    "gemini_live_2_5": {
        "label": "Gemini 2.5 Flash native audio (preview; prior users only — being retired)",
        "status": "VERIFIED 2026-10-01: same page; the model is not available to new users",
        "telephony_per_min": cm.TELEPHONY_PER_MIN,
        "audio_in_per_1m": 3.00, "audio_out_per_1m": 12.00,
        "text_in_per_1m": 0.50, "text_out_per_1m": 2.00,
        "audio_tokens_per_second": 25, "audio_tokens_per_second_high": 32,
        "silent_audio_billed": True,
    },
}


def load_rates(path: Optional[str] = None) -> Dict[str, Dict[str, Any]]:
    """RATES, with any values in a YAML/JSON file laid over them — so a verified
    new price is a one-line edit, not a code change."""
    rates = {k: dict(v) for k, v in RATES.items()}
    if path:
        text = Path(path).read_text(encoding="utf-8")
        if path.endswith((".yaml", ".yml")):
            import yaml
            over = yaml.safe_load(text) or {}
        else:
            over = json.loads(text)
        for name, values in over.items():
            rates.setdefault(name, {}).update(values)
    return rates


@dataclass
class Profile:
    """One typical call. Defaults are the MEASURED pilots from company_model."""
    call_seconds: float = cm.AVG_CALL_SECONDS
    lily_speaks_seconds: float = cm.LILY_SPEAKS_SECONDS
    chars_spoken: float = cm.CHARS_SPOKEN_PER_CALL
    caller_speaks_seconds: float = cm.CALLER_SPEAKS_SECONDS
    tool_turns: int = 8                 # ASSUMED tool round trips in a call
    static_context_tokens: int = 0      # system prompt + tool schemas (0 = measure below)
    reasoning_tokens: int = 0           # ASSUMED; 3.8 reasons "interleaved", billing unpublished
    orders_per_call: float = cm.ORDER_CONVERSION
    sms_segments: float = cm.ORDER_CONVERSION * cm.PAY_LINK_SHARE * cm.PAYLINK_SMS_SEGMENTS
    free_native_speech_factor: float = 1.5   # a native-audio model speaks MORE than our verbatim text

    @property
    def minutes(self) -> float:
        return self.call_seconds / 60.0


def static_context_tokens() -> int:
    """The prompt and tool definitions the model carries every call, measured
    from the real artifacts (about four characters to a token)."""
    from voice.inworld_bridge import SYSTEM_PROMPT
    tools = (HERE / "tools.json").read_text(encoding="utf-8")
    return int((len(SYSTEM_PROMPT) + len(tools)) / 4)


def call_cost(arch: str, p: Profile, *, high: bool = False,
              rates: Optional[Dict[str, Dict[str, Any]]] = None) -> Dict[str, float]:
    """Dollars for ONE call, by line. ``high`` is the pessimistic reading of
    everything the documentation leaves open."""
    r = (rates or RATES)[arch]
    ctx = p.static_context_tokens or static_context_tokens()
    out: Dict[str, float] = {"telephony": p.minutes * r["telephony_per_min"]}
    if arch == "inworld_cascade":
        out["stt"] = p.minutes / 60.0 * r["stt_per_hour"]
        out["tts"] = p.chars_spoken / 1e6 * r["tts_per_1m_chars"]
        out["llm"] = p.minutes * r["llm_tokens_per_min"] / 1e6 * r["llm_per_1m_tokens"]
    else:
        tps = r["audio_tokens_per_second_high" if high else "audio_tokens_per_second"]
        # Input audio is billed for the WHOLE call — silence included.
        out["audio_in"] = p.call_seconds * tps / 1e6 * r["audio_in_per_1m"]
        speak = p.lily_speaks_seconds * (p.free_native_speech_factor if high else 1.0)
        out["audio_out"] = speak * tps / 1e6 * r["audio_out_per_1m"]
        # The static context is billed once at best, and on every tool turn at worst
        # (whether Live re-bills accumulated context per turn is not published).
        rebills = p.tool_turns if high else 1
        out["context_text_in"] = ctx * rebills / 1e6 * r["text_in_per_1m"]
        out["text_out"] = (300 + p.reasoning_tokens) / 1e6 * r["text_out_per_1m"]
    out["sms"] = p.sms_segments * cm.SMS_ALL_IN
    return out


def total(lines: Dict[str, float]) -> float:
    return sum(lines.values())


def monthly(arch: str, p: Profile, calls_per_day: float, locations: int = 1, *,
            high: bool = False, rates=None) -> Dict[str, float]:
    calls = calls_per_day * cm.DAYS_PER_MONTH * locations
    per = call_cost(arch, p, high=high, rates=rates)
    return {"calls": calls, "per_call": total(per), "month": total(per) * calls,
            "per_location_month": total(per) * calls / max(1, locations)}


# --------------------------------------------------------------------------
# What YOUR calls actually cost: read from the database
# --------------------------------------------------------------------------

def _parse(ts: Any) -> Optional[datetime]:
    try:
        d = datetime.fromisoformat(str(ts).replace("Z", "+00:00"))
        return d if d.tzinfo else d.replace(tzinfo=timezone.utc)
    except (ValueError, TypeError):
        return None


def observed_calls(store, *, days: int = 30, restaurant_id: Optional[str] = None,
                   now: Optional[datetime] = None) -> List[Dict[str, Any]]:
    """One row per ended voice call: minutes, characters Lily spoke, turns."""
    now = now or datetime.now(timezone.utc)
    since = (now.timestamp() - days * 86400)
    since_iso = datetime.fromtimestamp(since, timezone.utc).isoformat(timespec="seconds")
    q = ("SELECT s.id, s.restaurant_id, s.started_at, s.ended_at, s.end_reason, "
         "(SELECT COALESCE(SUM(LENGTH(t.text)),0) FROM turn t "
         " WHERE t.session_id=s.id AND t.speaker='agent') AS chars, "
         "(SELECT COUNT(*) FROM turn t WHERE t.session_id=s.id "
         " AND t.speaker='caller') AS caller_turns, "
         "(SELECT u.processed_characters FROM voice_usage u WHERE u.session_id=s.id) AS billed_chars, "
         "(SELECT u.transcribed_audio_ms FROM voice_usage u WHERE u.session_id=s.id) AS billed_ms "
         "FROM session s WHERE s.channel='voice' AND s.ended_at IS NOT NULL "
         "AND s.started_at >= ?")
    params: List[Any] = [since_iso]
    if restaurant_id:
        q += " AND s.restaurant_id=?"
        params.append(restaurant_id)
    out = []
    for r in store.conn.execute(q, params).fetchall():
        a, b = _parse(r["started_at"]), _parse(r["ended_at"])
        if a is None or b is None:
            continue
        out.append({"session": str(r["id"]), "restaurant": r["restaurant_id"],
                    "seconds": max(0.0, (b - a).total_seconds()),
                    "chars": float(r["billed_chars"] or r["chars"] or 0),
                    "caller_turns": int(r["caller_turns"] or 0),
                    "end_reason": r["end_reason"],
                    "billed": r["billed_chars"] is not None})
    return out


def observed_profile(calls: List[Dict[str, Any]]) -> Optional[Profile]:
    """The MEDIAN real call, as a Profile (medians: one runaway call must not
    drag the forecast; the runaways are reported separately)."""
    if not calls:
        return None
    secs = statistics.median(c["seconds"] for c in calls)
    chars = statistics.median(c["chars"] for c in calls)
    return Profile(call_seconds=secs,
                   lily_speaks_seconds=chars / 15.0,        # ~15 characters a second
                   chars_spoken=chars)


def long_calls(calls: List[Dict[str, Any]], *, minutes: float = 8.0) -> List[Dict[str, Any]]:
    """Calls that ran longer than they should — the ones a per-minute bill
    punishes: a line left open, a loop, a caller who never hung up."""
    return sorted((c for c in calls if c["seconds"] > minutes * 60),
                  key=lambda c: -c["seconds"])


# --------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------

def _money(x: float) -> str:
    return f"${x:,.4f}" if x < 1 else f"${x:,.2f}"


def _compare(args) -> int:
    rates = load_rates(args.rates)
    p = Profile(call_seconds=args.call_seconds, chars_spoken=args.chars,
                lily_speaks_seconds=args.chars / 15.0)
    print(f"One call: {p.call_seconds:.0f} s, Lily speaks {p.chars_spoken:.0f} characters "
          f"(~{p.lily_speaks_seconds:.0f} s), {p.tool_turns} tool turns, "
          f"{static_context_tokens():,} tokens of prompt+tools.\n")
    rows = []
    for arch in ("inworld_cascade", "gemini_live_3_8", "gemini_live_2_5"):
        lo = call_cost(arch, p, rates=rates)
        hi = call_cost(arch, p, high=True, rates=rates)
        rows.append((arch, total(lo), total(hi), lo, hi))
        print(f"{rates[arch]['label']}\n   {rates[arch]['status']}")
        for k in lo:
            print(f"     {k:17}{_money(lo[k]):>11}  ..  {_money(hi[k]):>10}")
        print(f"     {'TOTAL / call':17}{_money(total(lo)):>11}  ..  {_money(total(hi)):>10}\n")
    base = rows[0]
    cpd = args.calls_per_day
    print(f"At {cpd:.0f} calls/day per location ({cpd * cm.DAYS_PER_MONTH:,.0f}/month), plan price ${cm.PRICE_PER_LOCATION:.0f}:")
    for arch, lo, hi, _l, _h in rows:
        m_lo, m_hi = lo * cpd * cm.DAYS_PER_MONTH, hi * cpd * cm.DAYS_PER_MONTH
        extra = f"  (+{_money(m_lo - base[1] * cpd * cm.DAYS_PER_MONTH)} .. +{_money(m_hi - base[1] * cpd * cm.DAYS_PER_MONTH)} vs today)" if arch != "inworld_cascade" else ""
        print(f"   {arch:18} {_money(m_lo):>9} .. {_money(m_hi):>9} per location per month "
              f"= {m_lo / cm.PRICE_PER_LOCATION * 100:4.1f}%..{m_hi / cm.PRICE_PER_LOCATION * 100:4.1f}% of the plan{extra}")
    print("\nWhat decides between LOW and HIGH (not published — measure it):")
    print("  * does Gemini Live re-bill the accumulated context on every tool turn?")
    print("  * how are 3.8's interleaved reasoning tokens billed?  * 25 or 32 audio tokens a second?")
    print("  * a native-audio model speaks its OWN words, so output audio can exceed our verbatim text.")
    print("Run ONE real call on each candidate and read the invoice before committing.")
    return 0


def _forecast(args) -> int:
    rates = load_rates(args.rates)
    p = Profile(call_seconds=args.call_seconds, chars_spoken=args.chars,
                lily_speaks_seconds=args.chars / 15.0)
    for arch in ("inworld_cascade", "gemini_live_3_8"):
        lo = monthly(arch, p, args.calls_per_day, args.restaurants, rates=rates)
        hi = monthly(arch, p, args.calls_per_day, args.restaurants, high=True, rates=rates)
        rev = args.restaurants * cm.PRICE_PER_LOCATION
        print(f"{arch:18} voice cost/month {_money(lo['month'])} .. {_money(hi['month'])} "
              f"on revenue {_money(rev)}  (voice = {lo['month'] / rev * 100:.1f}%..{hi['month'] / rev * 100:.1f}%)")
    return 0


def _actual(args) -> int:
    from order_store import OrderStore
    store = OrderStore.open(args.db)
    calls = observed_calls(store, days=args.days, restaurant_id=args.restaurant)
    if not calls:
        print(f"No ended voice calls in the last {args.days} days.")
        return 0
    rates = load_rates(args.rates)
    prof = observed_profile(calls)
    per = [total(call_cost("inworld_cascade", Profile(call_seconds=c["seconds"], chars_spoken=c["chars"],
                                                      lily_speaks_seconds=c["chars"] / 15.0), rates=rates)) for c in calls]
    per_sorted = sorted(per)
    p95 = per_sorted[min(len(per_sorted) - 1, int(len(per_sorted) * 0.95))]
    billed = sum(1 for c in calls if c["billed"])
    print(f"{len(calls)} calls in {args.days} days ({billed} with provider-reported usage; the rest estimated from what Lily said).")
    print(f"Median call: {prof.call_seconds:.0f} s, {prof.chars_spoken:.0f} characters spoken.")
    print(f"Cost per call (today's stack): median {_money(statistics.median(per))}, 95th percentile {_money(p95)}, "
          f"total {_money(sum(per))}.")
    print(f"Same median call on Gemini 3.8 Live: {_money(total(call_cost('gemini_live_3_8', prof, rates=rates)))} .. "
          f"{_money(total(call_cost('gemini_live_3_8', prof, high=True, rates=rates)))}")
    runaways = long_calls(calls, minutes=args.long_minutes)
    if runaways:
        print(f"\n{len(runaways)} call(s) over {args.long_minutes:g} minutes (a per-minute bill punishes these):")
        for c in runaways[:10]:
            print(f"   {c['seconds'] / 60:5.1f} min  {c['restaurant']}  ended: {c['end_reason']}  session {c['session'][:8]}")
    return 0


def _rates(args) -> int:
    for name, r in load_rates(args.rates).items():
        print(f"{name}: {r['label']}\n   {r['status']}")
        for k, v in r.items():
            if k not in ("label", "status"):
                print(f"     {k:28} {v}")
    return 0


def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--rates", help="YAML/JSON file of rate overrides (verified new prices)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("compare", "forecast"):
        s = sub.add_parser(name)
        s.add_argument("--calls-per-day", type=float, default=cm.CALLS_PER_DAY)
        s.add_argument("--call-seconds", type=float, default=cm.AVG_CALL_SECONDS)
        s.add_argument("--chars", type=float, default=cm.CHARS_SPOKEN_PER_CALL)
        if name == "forecast":
            s.add_argument("--restaurants", type=int, default=1)
    a = sub.add_parser("actual")
    a.add_argument("--db", required=True)
    a.add_argument("--days", type=int, default=30)
    a.add_argument("--restaurant")
    a.add_argument("--long-minutes", type=float, default=8.0)
    sub.add_parser("rates")
    args = ap.parse_args(argv)
    return {"compare": _compare, "forecast": _forecast, "actual": _actual, "rates": _rates}[args.cmd](args)


if __name__ == "__main__":
    sys.exit(main())
