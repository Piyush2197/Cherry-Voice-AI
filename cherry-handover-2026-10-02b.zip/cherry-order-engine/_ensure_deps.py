"""Make "No module named 'yaml'" impossible to hit by accident.

The engine's dependencies (PyYAML, cryptography, ...) live in the project's own
virtual environment, `.venv`. The system `python3` has none of them, so running
`python3 server.py` from a plain terminal used to die with a bare
`ModuleNotFoundError: No module named 'yaml'`.

Import this module BEFORE the first third-party import (`import _ensure_deps`).
If a dependency is missing it either

  * re-runs the very same command under `<project>/.venv/bin/python`, when that
    interpreter exists (only for a script run directly, never for `python -m`,
    pytest or an interactive session, which keep their own interpreter), or
  * stops with the exact commands that fix it, instead of a traceback.

Set CHERRY_NO_REEXEC=1 to switch the re-run off (it is also skipped when the
current interpreter already is the venv's).
"""

from __future__ import annotations

import importlib.util
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
VENV_DIR = os.path.join(HERE, ".venv")
VENV_PYTHON = os.path.join(VENV_DIR, "bin", "python")

# import name -> the name in requirements.txt
PACKAGES = {"yaml": "PyYAML", "cryptography": "cryptography", "openpyxl": "openpyxl",
            "psycopg": "psycopg[binary]", "psycopg_pool": "psycopg-pool"}


def missing(names) -> list:
    return [n for n in names if importlib.util.find_spec(n) is None]


def _run_directly() -> bool:
    """True only for `python script.py` — not -m, -c, pytest or a REPL."""
    main = sys.modules.get("__main__")
    script = sys.argv[0] if sys.argv else ""
    return bool(main is not None and getattr(main, "__spec__", None) is None
                and script and os.path.isfile(script))


def ensure(names=("yaml",)) -> None:
    lacking = missing(names)
    if not lacking:
        return
    in_venv = os.path.abspath(sys.executable).startswith(VENV_DIR + os.sep)
    if (not in_venv and os.path.isfile(VENV_PYTHON) and _run_directly()
            and not os.environ.get("CHERRY_NO_REEXEC")):
        os.execv(VENV_PYTHON, [VENV_PYTHON] + sys.argv)       # same command, right interpreter
    pkgs = " ".join(PACKAGES.get(n, n) for n in lacking)
    sys.stderr.write(
        f"\nCherry cannot start: this Python ({sys.executable}) is missing {pkgs}.\n"
        f"The dependencies live in the project's virtual environment. From {HERE}:\n\n"
        f"    python3 -m venv .venv\n"
        f"    .venv/bin/pip install -r requirements.txt          # add requirements-postgres.txt for PostgreSQL\n"
        f"    .venv/bin/python {os.path.basename(sys.argv[0] or 'server.py')} ...\n\n"
        f"(or `source .venv/bin/activate` once, then use python3 as usual).\n\n")
    raise SystemExit(2)


ensure(("yaml",))
