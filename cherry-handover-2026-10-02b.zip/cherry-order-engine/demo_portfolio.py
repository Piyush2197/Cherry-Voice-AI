#!/usr/bin/env python3
"""Build offline, explicitly draft owner demos from a scalable location roster.

This tool never opens a database, calls a provider, sends an SMS, or routes a
phone number. It deliberately keeps demo readiness separate from the strict
live onboarding gate in onboarding_factory.py.
"""

from __future__ import annotations

import _ensure_deps  # noqa: F401  (re-runs under .venv, or says how to install, if PyYAML is missing)
import argparse
import json
import re
from pathlib import Path

import yaml

import menu_schema as ms
from config_validator import lint_config
from order_engine import IssueCode, OrderEngine, money


ROOT = Path(__file__).resolve().parent
DEFAULT_ROSTER = ROOT / "demos" / "locations.yaml"
SLUG = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
SCOPES = {"prepared_draft", "partial_catalog", "partial_options", "new_draft"}


def load_roster(path: Path) -> dict:
    doc = yaml.safe_load(path.read_text())
    if not isinstance(doc, dict) or doc.get("schema_version") != 1:
        raise ValueError("demo roster must have schema_version: 1")
    rows = doc.get("locations")
    if not isinstance(rows, list):
        raise ValueError("demo roster needs a locations list")
    target = doc.get("target_demo_locations")
    if not isinstance(target, int) or target < 1:
        raise ValueError("target_demo_locations must be a positive integer")
    seen = set()
    for index, row in enumerate(rows):
        if not isinstance(row, dict):
            raise ValueError(f"locations[{index}] must be a mapping")
        lid = row.get("id")
        if not isinstance(lid, str) or not SLUG.fullmatch(lid):
            raise ValueError(f"locations[{index}].id must be a lowercase slug")
        if lid in seen:
            raise ValueError(f"duplicate demo location id: {lid}")
        seen.add(lid)
        if row.get("scope") not in SCOPES:
            raise ValueError(f"{lid}: unknown demo scope")
        if not isinstance(row.get("menu"), str) or not row["menu"]:
            raise ValueError(f"{lid}: menu path is required")
    return doc


def resolve_menu(value: str) -> Path:
    path = Path(value)
    return path if path.is_absolute() else ROOT / path


def sample_order(cfg, item_id: str) -> tuple[list[str], int]:
    item = cfg.item(item_id)
    if item is None or not item.available:
        raise ValueError(f"sample item missing or unavailable: {item_id}")
    engine = OrderEngine(cfg)
    engine.add_line(item.id)
    conversation = [f"Caller: I'd like {item.name}."]
    for _ in range(35):
        issue = next((x for x in engine.validate() if x.blocking), None)
        if issue is None:
            break
        if issue.question:
            conversation.append(f"Cherry: {issue.question}")
        if issue.code == IssueCode.SIZE_REQUIRED:
            chosen = issue.candidates[0]
            size = item.size_by_id(chosen)
            engine.set_size(issue.line_id, chosen)
            conversation.append(f"Caller: {size.name}.")
        elif issue.code in (IssueCode.MISSING_REQUIRED_GROUP, IssueCode.TOO_FEW_SELECTED):
            line = engine.get_line(issue.line_id)
            used = {s.option_id for s in line.selections if s.group_id == issue.group_id}
            chosen = next((x for x in issue.candidates if x not in used), None)
            if not chosen:
                raise ValueError(f"no unused option for {issue.group_id}")
            option = cfg.option(chosen)
            failures = [x for x in engine.apply_option(issue.line_id, issue.group_id, chosen)
                        if x.blocking]
            if failures:
                raise ValueError(f"sample option blocked: {failures[0].message}")
            conversation.append(f"Caller: {option.name}.")
        elif issue.code == IssueCode.GROUP_CONFIRMATION_REQUIRED:
            engine.confirm_group(issue.line_id, issue.group_id)
            conversation.append("Caller: Yes.")
        else:
            raise ValueError(f"sample order blocked: {issue.code.value}: {issue.message}")
    if not engine.is_submittable():
        raise ValueError("sample order did not resolve within 35 choices")
    conversation.append("Cherry: " + engine.read_back())
    conversation.append(f"Practice total: {money(engine.price().total_cents)}")
    return conversation, engine.price().total_cents


def inspect(row: dict) -> dict:
    lid = row["id"]
    output = {"id": lid, "scope": row["scope"], "menu": row["menu"],
              "next_input": str(row.get("next_input") or "Owner must review the menu."),
              "demo_ready": False, "issues": []}
    menu = resolve_menu(row["menu"])
    if not menu.is_file():
        output["issues"].append("menu file missing")
        return output
    try:
        raw = yaml.safe_load(menu.read_text())
        shape_errors = ms.validate_doc(raw)
        if shape_errors:
            output["issues"].extend(shape_errors[:5])
            return output
        cfg = ms.build_config(raw)
        if cfg.id != lid:
            output["issues"].append(f"menu id {cfg.id} differs from roster id")
        output["issues"].extend(str(x) for x in lint_config(cfg) if x.level == "ERROR")
        output["name"] = cfg.name
        output["item_count"] = len(cfg.items)
        if not row.get("sample_item_id"):
            output["issues"].append("sample_item_id is required for a demo")
        elif not output["issues"]:
            transcript, total = sample_order(cfg, str(row["sample_item_id"]))
            output["sample_conversation"] = transcript
            output["sample_total_cents"] = total
    except Exception as exc:
        output["issues"].append(str(exc))
    output["demo_ready"] = not output["issues"]
    return output


def audit(roster: dict) -> dict:
    rows = [inspect(row) for row in roster["locations"]]
    ready = sum(x["demo_ready"] for x in rows)
    return {"target": roster["target_demo_locations"], "registered": len(rows),
            "demo_ready": ready,
            "remaining_to_target": max(0, roster["target_demo_locations"] - ready),
            "locations": rows}


def render_packet(row: dict) -> str:
    lines = [f"# Practice demo: {row['name']}", "",
             "**DRAFT DEMO — no customer call, payment, POS ticket, or live order.**", "",
             f"Menu scope: `{row['scope']}`; {row['item_count']} modeled items.",
             "The displayed prices and choices are from an unapproved menu snapshot.",
             "The owner must verify them before any live use.", "",
             "## Example conversation", ""]
    lines.extend(f"- {line}" for line in row["sample_conversation"])
    lines.extend(["", "## Before a live launch", "", row["next_input"],
                  "Live acceptance still requires the separate onboarding and provider checks.", ""])
    return "\n".join(lines)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--roster", type=Path, default=DEFAULT_ROSTER)
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("audit", help="check demo readiness against the target")
    suggest = commands.add_parser("suggest", help="show simple sample items from a menu")
    suggest.add_argument("--menu", required=True)
    build = commands.add_parser("build", help="create draft owner demo packets")
    build.add_argument("--out", type=Path, required=True)
    add = commands.add_parser("add", help="register one new menu for demos")
    add.add_argument("--id", required=True)
    add.add_argument("--menu", required=True)
    add.add_argument("--sample-item-id", required=True)
    add.add_argument("--menu-source", choices=("owner_menu", "pos_export", "public_menu"),
                     required=True, help="where this actual location's menu came from")
    add.add_argument("--scope", choices=sorted(SCOPES), default="new_draft")
    add.add_argument("--next-input", default="Owner must verify the menu and sample order.")
    args = parser.parse_args(argv)
    try:
        roster = load_roster(args.roster)
        if args.command == "suggest":
            cfg = ms.load_yaml(resolve_menu(args.menu))
            simple = [item for item in cfg.items if item.available and
                      not item.has_sizes and not item.modifier_group_ids and
                      item.base_price_cents > 0]
            choices = simple or [item for item in cfg.items if item.available]
            for item in choices[:10]:
                print(f"{item.id:34} {item.name}")
            return 0 if choices else 1
        if args.command == "add":
            if not SLUG.fullmatch(args.id):
                raise ValueError("id must be a lowercase slug")
            if any(x["id"] == args.id for x in roster["locations"]):
                raise ValueError(f"{args.id} is already registered")
            row = {"id": args.id, "menu": args.menu,
                   "sample_item_id": args.sample_item_id, "scope": args.scope,
                   "menu_source": args.menu_source,
                   "next_input": args.next_input}
            result = inspect(row)
            if not result["demo_ready"]:
                raise ValueError("demo failed: " + "; ".join(result["issues"]))
            roster["locations"].append(row)
            args.roster.write_text(yaml.safe_dump(roster, sort_keys=False,
                                                  allow_unicode=True, width=100))
            print(f"REGISTERED {args.id}: {result['item_count']} items")
            return 0
        result = audit(roster)
        if args.command == "audit":
            print(f"Draft practice demos {result['demo_ready']}/{result['target']} "
                  f"({result['registered']} registered; {result['remaining_to_target']} more needed)")
            for row in result["locations"]:
                state = "SAMPLE_OK" if row["demo_ready"] else "BLOCKED"
                print(f"{state:7} {row['id']:29} {row.get('item_count', 0):3} items "
                      f"[{row['scope']}]")
                for issue in row["issues"]:
                    print("        " + issue)
            return 0 if result["demo_ready"] >= result["target"] else 2
        args.out.mkdir(parents=True, exist_ok=True)
        for row in result["locations"]:
            if row["demo_ready"]:
                (args.out / f"{row['id']}.md").write_text(render_packet(row))
        (args.out / "audit.json").write_text(json.dumps(result, indent=2) + "\n")
        print(f"WROTE {result['demo_ready']} practice packets to {args.out}; "
              f"{result['remaining_to_target']} more needed for target")
        return 0 if result["demo_ready"] == result["registered"] else 1
    except (OSError, ValueError, yaml.YAMLError, ms.SchemaError) as exc:
        parser.error(str(exc))


if __name__ == "__main__":
    raise SystemExit(main())
