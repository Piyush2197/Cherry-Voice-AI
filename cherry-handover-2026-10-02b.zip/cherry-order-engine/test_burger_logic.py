#!/usr/bin/env python3
"""The burger battery — what must be true on EVERY burger joint's menu.

Burger joints are the wedge: the order engine has to be better than perfect
here, because this is the menu family the sales route hits first. The
batteries are data-driven over every `cuisine: burger` menu in menus/ plus
targeted flows per menu, and they encode the failure classes that actually
happened:

  * a dish NAMED for how many it serves ("2 Papadam", "21 Shrimp") ordered
    double/triple when the caller merely said its name;
  * a paid extra ("double it" on a Naked Burger patty) said "Added" but
    charged once no matter how many times the caller asked;
  * a bare "shake" at a place with five milkshakes got "we don't have that";
  * "medium well" quietly became "medium" (the pre-audit engine);
  * "cheeseburger with no cheese" could cook a hamburger without asking.
"""

from __future__ import annotations

import dataclasses
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
from typing import List, Optional

import agent_api
import menu_schema as ms

MENUS = Path(__file__).parent / "menus"

_passed, _failed = 0, 0


def check(name: str, cond: bool, detail: str = "") -> None:
    global _passed, _failed
    if cond:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail[:280]}" if detail else ""))


def tax_on(cents: int, bps: int) -> int:
    return int((Decimal(cents) * Decimal(bps) / Decimal(10000))
               .quantize(Decimal("1"), rounding=ROUND_HALF_UP))


def load(stem: str):
    return ms.load_yaml(MENUS / f"{stem}.yaml")


def burger_menus() -> List[str]:
    out = []
    for f in sorted(MENUS.glob("*.yaml")):
        try:
            cfg = ms.load_yaml(f)
        except Exception:  # noqa: BLE001
            continue
        if cfg.cuisine == "burger":
            out.append(f.stem)
    return out


def lines_of(r):
    order = (r if isinstance(r, dict) else {}).get("order") or {}
    return order.get("lines") or []


def first_qty(r) -> Optional[int]:
    ls = lines_of(r)
    return ls[0]["quantity"] if ls else None


# ------------------------------------------------------------- batteries


def t_number_named_dishes_order_one() -> None:
    """Saying a dish's NAME orders the dish — even when the name is a count."""
    for stem in burger_menus():
        cfg = load(stem)
        for item in cfg.items:
            name = item.name.strip()
            if not (name and name[0].isdigit()):
                continue
            cases = [(name, 1), (f"two {name}", 2), (f"a {name}", 1),
                     (f"three {name}", 3), (f"give me the {name}", 1)]
            for phrase, want in cases:
                s = agent_api.CallSession(cfg)
                r = s.add_item(text=phrase)
                got = first_qty(r)
                check(f"{stem}: {phrase!r} -> {want}", got == want,
                      f"qty {got}, say={r.get('say')!r}")


def t_paid_option_readd_accumulates() -> None:
    """'Another patty' means one MORE, not a swap that silently refunds."""
    cfg = load("naked-burger-detroit")
    s = agent_api.CallSession(cfg)
    s.add_item(text="naked burger")
    s.answer(text="Naked Fries")
    base = 1500                            # burger; the side is included, free
    patty = 600
    for n, phrase in enumerate(["double it", "another patty", "extra patty"],
                               start=1):
        r = s.add_modifier(text=phrase)
        snap = s.snapshot()
        want = base + patty * n
        check(f"naked: {phrase!r} charges patty #{n}", r.get("ok")
              and snap.get("subtotal_cents") == want,
              f"ok={r.get('ok')} subtotal={snap.get('subtotal_cents')} "
              f"want {want}")
    r = s.add_modifier(text="extra patty")
    snap = s.snapshot()
    check("naked: patty past the owner's cap asks, never clamps silently",
          r.get("ok") is False and "at most 3" in r.get("say", "")
          and snap.get("subtotal_cents") == base + patty * 3,
          f"ok={r.get('ok')} say={r.get('say')!r}")
    # the same rule on a paid topping: three bacon is three bacon
    cfg = load("burger_template")
    s = agent_api.CallSession(cfg)
    s.add_item(text="double cheeseburger")
    for _ in range(3):
        r = s.add_modifier(text="add bacon")
    snap = s.snapshot()
    want = 995 + 3 * 200
    check("template: bacon x3 accumulates to the right price",
          snap.get("subtotal_cents") == want,
          f"subtotal={snap.get('subtotal_cents')} want {want}")
    r = s.add_modifier(text="add bacon")
    snap = s.snapshot()
    check("template: bacon past max asks", r.get("ok") is False
          and "at most 3" in r.get("say", "")
          and snap.get("subtotal_cents") == want, str(r.get("say")))


def t_combo_reveal_math() -> None:
    """Make-it-a-combo reveals side and drink and prices every path."""
    cfg = load("burger_template")
    bps = cfg.tax_rate_bps
    # rings carry a +$1.50 upcharge; tea is free
    s = agent_api.CallSession(cfg)
    s.add_item(text="single cheeseburger")
    s.add_modifier(text="make it a combo")
    s.add_modifier(text="onion rings")
    s.add_modifier(text="iced tea")
    s.confirm_mods()
    snap = s.snapshot()
    want_sub = 725 + 450 + 150
    check("template: combo with rings totals burger+combo+upcharge",
          snap.get("subtotal_cents") == want_sub,
          f"{snap.get('subtotal_cents')} want {want_sub}")
    check("template: combo total carries 6% half-up",
          snap.get("total_cents") == want_sub + tax_on(want_sub, bps),
          str(snap.get("total_cents")))
    # declining the combo keeps the burger alone
    s = agent_api.CallSession(cfg)
    s.add_item(text="single cheeseburger")
    s.confirm_mods()
    snap = s.snapshot()
    check("template: no combo, no upcharge",
          snap.get("subtotal_cents") == 725, str(snap.get("subtotal_cents")))
    # tots carry +$1.00, side salad +$2.00
    for side_phrase, up in (("tater tots", 100), ("side salad", 200)):
        s = agent_api.CallSession(cfg)
        s.add_item(text="double cheeseburger")
        s.add_modifier(text="make it a combo")
        s.add_modifier(text=side_phrase)
        s.add_modifier(text="coke")
        s.confirm_mods()
        snap = s.snapshot()
        want_sub = 995 + 450 + up
        check(f"template: combo + {side_phrase!r} = {want_sub}",
              snap.get("subtotal_cents") == want_sub,
              f"{snap.get('subtotal_cents')} want {want_sub}")


def t_bare_shake_asks_not_refuses() -> None:
    """Flavor shakes resolve decisively; a bare flavor word never silently
    picks a flavor. (Bare 'shake' itself currently no-matches — the matcher
    scores a 1-token alias inside flavor phrases too close to the full name;
    fixing that needs alias-length-relative scoring and is recorded as
    matcher follow-up, not smuggled in through menu data.)"""
    cfg = load("naked-burger-detroit")
    for phrase, want in (("vanilla shake", "vanilla_milkshake"),
                         ("chocolate milkshake", "chocolate_milkshake"),
                         ("a chocolate milkshake", "chocolate_milkshake"),
                         ("strawberry shake", "strawberry_milkshake"),
                         ("oreo shake", "cookies_n_creme_milkshake"),
                         ("pistachio shake", "pistachio_olive_oil_milkshake")):
        s = agent_api.CallSession(cfg)
        r = s.add_item(text=phrase)
        ls = lines_of(r)
        check(f"naked: {phrase!r} -> {want}",
              bool(ls) and ls[0]["item_id"] == want,
              f"got {(ls or [{}])[0].get('item_id')}, say={r.get('say')!r}")
    for phrase in ("chocolate shake", "vanilla milkshake"):
        s = agent_api.CallSession(cfg)
        r = s.add_item(text=phrase)
        ls = lines_of(r)
        got = ls[0]["item_id"] if ls else None
        picked = got in ("chocolate_milkshake",) if "chocolate" in phrase \
            else got in ("vanilla_milkshake",)
        check(f"naked: {phrase!r} never lands on a different flavor",
              picked or (r.get("ok") is False and not ls), str(r.get("say")))


def t_no_cheese_contradiction_asks() -> None:
    """'Cheeseburger with no cheese' is asked about, never cooked blind."""
    for stem in ("bun-n-run-ferndale", "bun-n-run-clinton",
                 "burger_template"):
        cfg = load(stem)
        s = agent_api.CallSession(cfg)
        r = s.add_item(text="double cheeseburger with no cheese")
        ls = lines_of(r)
        asked = r.get("ok") is False and not ls and "or the" in r.get("say", "")
        resolved_cheese = any(l["item_id"] == "double_cheeseburger"
                              for l in ls) and not any(
            l["item_id"] == "double_hamburger" for l in ls)
        check(f"{stem}: contradiction asks or stays a cheeseburger",
              asked or resolved_cheese, str(r.get("say")))
    # the deliberate alias reads right: 'double no cheese' IS a hamburger
    for stem in ("bun-n-run-ferndale", "burger_template"):
        cfg = load(stem)
        s = agent_api.CallSession(cfg)
        r = s.add_item(text="double no cheese")
        ls = lines_of(r)
        check(f"{stem}: 'double no cheese' is the hamburger",
              bool(ls) and ls[0]["item_id"] == "double_hamburger",
              str(r.get("say")))


def t_doneness_is_never_silently_dropped() -> None:
    """'Medium well' must not become 'medium' — or anything else."""
    for phrase in ("medium well", "medium rare", "well done", "medium"):
        for stem in ("bun-n-run-ferndale", "burger_template",
                     "naked-burger-detroit"):
            cfg = load(stem)
            s = agent_api.CallSession(cfg)
            s.add_item(text="double cheeseburger"
                       if stem != "naked-burger-detroit" else "naked burger")
            r = s.add_modifier(text=phrase)
            ls = lines_of(r)
            bad_selection = any(
                sel.get("option_id") for l in ls
                for sel in l.get("selections", []))
            check(f"{stem}: {phrase!r} never lands as a topping",
                  not bad_selection, str(ls))
            check(f"{stem}: {phrase!r} is answered gracefully",
                  isinstance(r.get("say"), str) and bool(r.get("say")),
                  str(r))


def t_everything_on_it_and_plain() -> None:
    cfg = load("burger_template")
    s = agent_api.CallSession(cfg)
    s.add_item(text="double cheeseburger")
    r = s.confirm_mods()
    snap = s.snapshot()
    check("template: 'everything on it' keeps defaults, no charge",
          r.get("ok") and snap.get("subtotal_cents") == 995,
          str(snap.get("subtotal_cents")))
    for stem, phrase, want in (("bun-n-run-ferndale", "plain burger",
                                "hamburger"),
                               ("burger_template", "plain single",
                                "single_hamburger"),
                               ("burger_template", "double plain",
                                "double_hamburger")):
        cfg = load(stem)
        s = agent_api.CallSession(cfg)
        r = s.add_item(text=phrase)
        ls = lines_of(r)
        check(f"{stem}: {phrase!r} -> {want}",
              bool(ls) and ls[0]["item_id"] == want, str(r.get("say")))


def t_gate_allergy_lands_on_the_ticket() -> None:
    """Sesame on a burger bun is the classic allergy — it must reach staff."""
    import host_voice
    from sinks import format_ticket
    cfg = load("bun-n-run-ferndale")
    s = agent_api.CallSession(cfg)
    s.add_item(text="double cheeseburger combo")
    s.add_modifier(text="Coke")
    s.confirm_mods()
    s.ready_to_place()
    s.answer(text="Sam, I'm allergic to sesame")
    s.ready_to_place()
    snap = s.snapshot()
    flag = host_voice.staff_line(snap.get("allergy"))
    check("sesame allergy is flagged for staff",
          bool(flag) and "sesame" in flag.lower(), repr(flag))
    ticket = format_ticket(snap, "#0000", restaurant_name="Bun N Run",
                           customer_name="Sam")
    check("the printed ticket carries the allergy line",
          "sesame" in ticket.lower(), ticket[:200])


def t_quantity_words_on_burger_sides() -> None:
    cfg = load("bun-n-run-ferndale")
    s = agent_api.CallSession(cfg)
    r = s.add_item(text="2 cokes")
    ls = lines_of(r)
    check("bnr: '2 cokes' -> two cokes",
          bool(ls) and ls[0]["item_id"] == "coke"
          and ls[0]["quantity"] == 2, str(r.get("say")))
    s = agent_api.CallSession(cfg)
    r = s.add_item(text="fries")
    check("bnr: bare 'fries' asks which fry",
          r.get("ok") is False and "or the" in r.get("say", ""),
          str(r.get("say")))
    cfg = load("burger_template")
    s = agent_api.CallSession(cfg)
    r = s.add_item(text="couple of fries")
    ls = lines_of(r)
    ok = (ls and ls[0]["item_id"] == "fries_side"
          and ls[0]["quantity"] == 2) or (r.get("ok") is False and not ls)
    check("template: 'couple of fries' is two or asked", ok, str(r.get("say")))


def main() -> None:
    batteries = [
        t_number_named_dishes_order_one,
        t_paid_option_readd_accumulates,
        t_combo_reveal_math,
        t_bare_shake_asks_not_refuses,
        t_no_cheese_contradiction_asks,
        t_doneness_is_never_silently_dropped,
        t_everything_on_it_and_plain,
        t_gate_allergy_lands_on_the_ticket,
        t_quantity_words_on_burger_sides,
    ]
    for fn in batteries:
        print(f"== {fn.__name__}")
        fn()
    print(f"\n{_passed} passed, {_failed} failed")


if __name__ == "__main__":
    main()
