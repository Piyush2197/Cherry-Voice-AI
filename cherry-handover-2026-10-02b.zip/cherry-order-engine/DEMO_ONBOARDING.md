# Technical demo onboarding: 20 locations by December 2026

This workflow prepares a **practice ordering demonstration** from a draft menu. It does not activate a phone number, connect Inworld, create a POS order, collect payment, or certify a restaurant for public calls. Live launch remains governed by `ONBOARDING.md` and `DEVELOPER_HANDOFF.md`.

## Current inventory

`demos/locations.yaml` lists ten actual named storefronts. The demo preflight currently produces ten draft practice packets against a target of 20. The other YAML files in `menus/` include cuisine examples; those examples are **not ten more restaurant locations** and must not be counted toward the target.

The three menus formerly described simply as “still in work” have different reasons:

- **Juan Miguel's:** the public ordering site exposed only a small part of the menu. The practice packet uses one observed item. Obtain the full current menu from the owner before a whole-menu demo or launch.
- **Sam's Kabob:** the catalog is broad, but several second-size prices, sauces and combo choices are unknown. The packet uses a narrow observed item. Confirm those options before demonstrating the affected dishes or launching.
- **Cheng's Asian Bistro:** many items are modeled, but several ranges and combination plates are unresolved. The packet uses one straightforward item. Get the owner or POS export to confirm those gaps before broad demo or launch.

“Demo-ready” here means the selected sample order passes local schema, lint, and simulated-cart checks. It does not mean the complete catalog is verified. Every packet says this prominently.

## One repeatable workflow per new location

1. Get a current menu file or a current POS catalog export. Keep its source and date with the onboarding case. The owner must confirm missing prices and modifier choices; do not fill them with guessed values.
2. Turn the raw menu into a draft: `./cherry.py ingest onboarding/<id>/raw-menu.txt --cuisine <cuisine> --id <id> --name "<name>" -o menus/<id>.yaml`. If using a Square export, use the existing catalog import path in `ONBOARDING.md`.
3. Validate the menu: `./cherry.py check menus/<id>.yaml`. Correct all schema and lint errors. Owner questions may remain, but keep affected items out of the demonstration.
4. Choose an item with a known price: `python3 demo_portfolio.py suggest --menu menus/<id>.yaml`. Check it against the source; a suggested item is not automatically approved.
5. Register the actual location: `python3 demo_portfolio.py add --id <id> --menu menus/<id>.yaml --sample-item-id <item-id> --menu-source owner_menu --next-input "<what the owner must confirm>"`. Use `pos_export` or `public_menu` when that is the actual source. The command refuses duplicates and a sample order that cannot be completed. Do not register cuisine templates.
6. Run `python3 demo_portfolio.py audit`, then `python3 demo_portfolio.py build --out ../../business/demo-packets`. Review the generated location packet with the owner. This output folder keeps presentation material outside the technical repository and out of production routing and checkout workflows.
7. When the owner approves the complete menu and wants live service, start the separate `./cherry.py onboard new` case, gather provider access, and run the real-call/payment acceptance gate. A demo packet is never a launch certificate.

Run these commands from the repository directory with dependencies in `requirements.txt` installed. The current local sandbox lacks PyYAML on the default Python path, so local verification can use the already staged temporary dependency path: `PYTHONPATH=/private/tmp/cherry-test-deps python3 demo_portfolio.py audit`. The deployment environment should install pinned project requirements normally; a demo tool should not silently download packages.

## Quality and throughput

The roster reports the exact gap to 20. Ten additional **real named locations with source menus** are needed. At roughly fourteen weeks from September 21 to year-end, prepare one new menu most weeks and keep a second weekly slot for owner corrections or failed simulations. Do not count cuisine templates, duplicates, or a menu without a passing location-specific practice order.

Before each demonstration, confirm the sample item, price, tax and spoken name against the latest menu; demonstrate an unsupported item as a safe refusal; and show the owner the “before live launch” questions. If Inworld SIP becomes available, a voice demo may be added after its own test, but the draft menu label and no-live-order boundary remain until owner and provider acceptance.
