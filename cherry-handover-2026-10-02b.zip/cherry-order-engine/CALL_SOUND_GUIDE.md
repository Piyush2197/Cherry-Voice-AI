# How Lily sounds — and how to change it

Lily is the host who answers the phone. This is what makes a call feel welcoming,
where each piece lives, and what your voice provider must be set to. Every sample
below was produced by playing the call through the engine (the same text a caller
hears, after the speakable pass), not written by hand.

## What a call sounds like

**A new caller, on a weekday afternoon**

```
Lily:   Good afternoon, thank you for calling Pink Garlic Indian Cuisine, Shelby Township. This is Lily. What can I get started for you today?
Caller: Hi, I'd like to place an order.
Lily:   Absolutely, I'd be happy to help with that. What can I get started for you?
Caller: A chicken korma, and a couple of garlic naan.
Lily:   Perfect — Chicken Korma, Creamy. How spicy would you like that? We do mild, mild plus, medium, medium plus, hot, or extra hot. Lovely — 2 Garlic Naan.
Caller: Medium.
Lily:   Medium, got it.
Caller: That's all.
Lily:   Almost there. Can I get a name for the order, and are there any allergies or dietary needs I should flag for the kitchen?
Caller: It's Dana — and my son has a peanut allergy.
Lily:   Lovely to meet you, Dana! Thank you for telling me. I've flagged that for the kitchen. I can't check ingredients myself, so please mention it again when you pick up.
Caller: Okay.
Lily:   So that's Chicken Korma, Creamy, with Medium, and 2 Garlic Naan. Your total comes to $22.25. It should be ready about 20 minutes after you complete checkout.
```

**A regular, in the evening**

```
Lily:   Welcome back, Sam! This is Lily at Pink Garlic Indian Cuisine, Shelby Township. Would you like the same as last time, the Chicken Korma, Creamy, and 2 Garlic Naan, or something different today?
Caller: The usual, please.
Lily:   Wonderful, I've added your usual: the Chicken Korma, Creamy, and 2 Garlic Naan. For the Chicken Korma, Creamy, how spicy would you like that? We do mild, mild plus, medium, medium plus, hot, or extra hot.
Caller: Medium.
Lily:   Medium, got it.
Caller: What time do you close tonight?
Lily:   We're open until 9 PM today.
Caller: That's it.
Lily:   Almost there. Last time you mentioned peanut allergy. Does that still apply?
Caller: Yes, same as before.
Lily:   Thank you for telling me. I've flagged that for the kitchen. I can't check ingredients myself, so please mention it again when you pick up.
Caller: Thank you.
Lily:   So that's Chicken Korma, Creamy, with Medium, and 2 Garlic Naan. Your total comes to $22.25. It should be ready about 25 minutes after you complete checkout.
```

**A Spanish-speaking caller** (the caller's words go to the engine exactly as spoken; Lily's reply is the engine's English)

```
Lily:   Good afternoon, thank you for calling Juan Miguel's, Clinton Township. This is Lily. What can I get started for you today?
Caller: Hola, quiero dos burritos de pollo.
Lily:   Got it — 2 Burritos. Sorry, I'm not sure what that's for.
Caller: Y una quesabirria, por favor.
Lily:   Perfect — Quesabirria.
```

Two things to notice. The words are the **engine's**, spoken verbatim by the
voice model, so Lily can never invent a price or a dish. And everything a good
host does that must *always* happen — asking about allergies, getting a name,
giving an honest time — is enforced by the engine, not left to a model's mood.

## What makes it feel welcoming

| What Lily does | Where it lives |
|---|---|
| Greets by the restaurant's own clock ("Good afternoon…"), says who she is, silent in the small hours | `host_voice.day_part`, `CallSession.greeting` |
| Recognises a regular ("Welcome back, Sam!"), offers the same again, and re-asks the allergy instead of assuming | `order_store.previous_order_for_caller`, `server._prime`, `reorder_last` |
| Welcomes "I'd like to place an order" instead of answering "we don't have that" | `CallSession.add_item` + `host_voice.order_intent` |
| Varies her acknowledgements ("Got it", "Perfect", "Lovely") — the first is always the plain one | `host_voice.ACKS`, `CallSession._ack` |
| Asks a question once, in one breath; asked again later it names the dish ("For the Chicken Korma, how spicy…") | `CallSession._pending_question` |
| Repeats "anything else you'd like to change on the burger?" instead of re-listing the onion you just removed | same |
| Asks for a name and allergies the way a waiter does, once, and never loses the order if the caller hangs up first | `CallSession.ready_to_place`, `host_voice.GATE_*` |
| Says plainly she cannot check ingredients, and never calls a dish safe | `host_voice.ALLERGY_NOTED`, `item_info` |
| Apologises for a sold-out dish and offers the closest thing | `CallSession._sold_out` |
| Answers hours, wait time, delivery and the address **only** from what the restaurant configured | `store_info`, `restaurant_controls.hours_summary` |
| Gives an honest ready time (from checkout, because the kitchen starts when they have paid) | `ready_to_place`, `host_voice.READY_*` |
| Reads the order back like a person ("X, and Y") | `OrderEngine.read_back` |
| Signs off by name, only when the order really went through | `host_voice.sign_off` |
| Says "Lamb or Goat Korma, Creamy" and "two pieces", not "slash", "bracket" or "two P C S" | `speech.speakable` (applied to everything she says) |
| Texts the restaurant's staff phone who is calling, why, and what is in the cart whenever a call is transferred | `server.handoff_briefing` |

## Changing a phrase

Edit `host_voice.py` (the banks are plain strings) and run
`test_host_voice.py`, `test_call_experience.py` and `python3 model_bakeoff.py run
--brain scripted`. Keep the *first* acknowledgement "Got it": tests, and a
one-item call, rely on it. If you rename a tool or change when a question is
asked, the prompt in `voice/inworld_bridge.py` must change with it.

## Languages

Callers can order in **Spanish, Arabic and Hindi/Urdu** (as written in Latin
letters): numbers ("dos", "wahid", "paanch"), food and modifiers ("pollo", "sin
cebolla", "murgh", "bina mirch"), sizes ("grande"), a name ("me llamo Carlos"),
and "no allergies" ("sin alergias"). The caller's words are tried as spoken
**first**; a translation is used only when it matches clearly better, so a dish
said exactly as the menu writes it is never rewritten. `test_phrasebook.py` proves
that on every item name and alias of every menu.

Limits to know: Lily **replies in English** (a translation provider can be hooked
into `SafeLocalizer`; a native-audio model such as Gemini 3.8 Live, with 99
languages, would converse end to end); Hindi/Urdu "do", "teen", "char", "saat",
"nau", "das" are numbers only when another Hindi word is in the same sentence
(otherwise "do you have naan" would break); and the word lists are deliberately
short — add words only when certain, in `phrasebook.py`.

## What the voice provider must be set to

These are not enforceable from here; check each on the real line.

1. **Tools: blocking.** Declare every tool `BLOCKING` (Gemini 3.8 Live defaults to
   non-blocking, which lets the model talk over the engine). `GET /v1/voice/tools`
   returns `call_policy.tool_behavior`.
2. **Speak the tool text exactly.** Turn on output-audio transcription and compare
   it with the engine's text (`CherryBridge.verbatim_audit`).
3. **Idle and runaway calls.** Apply `call_policy`: prompt after 8 s of silence,
   release after two prompts, cap a call at 10 minutes. Per-minute providers bill
   silence like speech.
4. **The voice itself — choose by ear.** Play the same three lines (the greeting,
   the allergy question, the sign-off) in each candidate voice and pick the one that
   sounds unhurried and warm; then re-check after any provider update.
5. **Interruptions.** Let callers talk over Lily (barge-in). A blocking tool call is
   cancelled when new input arrives, so confirm the engine and the model agree on
   the cart after an interruption (`read_back`).

**Then prove all five with one real call.** Make a test order that includes a name,
an allergy, a "do you close tonight?" and a sentence in Spanish; save the provider's
output transcription one reply per line; and run

```bash
python3 call_review.py --db "$CHERRY_DATABASE_URL" --latest --spoken spoken.txt \
    --expect set_name,note_allergy,store_info
```

It prints every tool the model called with what the caller said to cause it, and
checks that the name/allergy answers reached `set_name`/`note_allergy` (not
`add_item`), counts the repeated calls the engine had to absorb, lists the tool
calls that came back with bad arguments, times the engine, compares the voice's
words with the engine's (a changed number or price is a **fail**), shows the
outcome on the ticket, and estimates the call's cost on each stack. Exit code 3 =
something failed. It only reads the database.
## Remembering callers

A regular is recognised **by caller ID, from this restaurant's own paid orders in
the last four months**, never from another restaurant and never from an unpaid
checkout. What is remembered: the last order's items, the name given, and the
allergy note (which is **asked again**, never assumed). **The owner's switch is per
restaurant**: `POST /v1/restaurants/{id}/controls` with `{"remember_callers": false}`
(operator access; on by default, kept when anything else is saved), and
`CHERRY_REMEMBER_CALLERS=0` switches it off for a whole deployment. If the switch
cannot be read the call is not recognised (fails closed). Caller ID can be spoofed and a number can be shared, so
whoever is on that number hears the last order's dishes in the greeting, and the
remembered allergy note when she asks "does that still apply?" — low sensitivity,
but a choice to make knowingly. Tell guests (the checkout text or the
restaurant's website is the natural place) and have counsel confirm the wording
for your state. Not built: a "forget my number" request (until it is, turning the
switch off stops recognition but keeps the order history).

## Testing it

```bash
python3 test_host_voice.py && python3 test_call_experience.py      # the words and the flow, end to end
python3 model_bakeoff.py run --brain scripted                      # 25 scripted calls: six cuisines, three other languages
python3 model_bakeoff.py run --brain openai --model … --base-url … --api-key-env …   # score a real model
python3 call_cost.py compare                                       # what a call costs on each stack
python3 call_review.py --db cherry.db --latest                     # after a real call: did the model use the engine as told?
```
