#!/usr/bin/env python3
"""
The development checkout: a whole order, no provider account.

These tests exist because the product could not complete an order out of the
box. Every restaurant needs an itemized checkout provider, the only real one is
Square, and so a fresh checkout ended every call with "I could not deliver the
secure checkout" — the documented quickstart included.

Two things therefore have to hold, and they pull in opposite directions:

1. WITH ``--dev-checkout``, a real order runs all the way through — link
   created, payment recorded, order released to the kitchen sink, exactly once.
2. WITHOUT it, nothing changes. The dev payment endpoint must not exist, and
   the original provider-missing behaviour must be byte-for-byte what it was.

The second is the more important of the two. It is easy to make a demo work;
it is easy to accidentally leave a way to mark orders paid in production.
"""

from __future__ import annotations

import json
import threading
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

import dev_checkout
import menu_schema as ms
import server as srv
from order_store import OrderStore
from sinks import FakeSmsSender

MENUS = Path(__file__).parent / "menus"
KEY = "test-secret"
INBOUND = "+13135551000"

_passed, _failed = 0, 0


def check(name: str, cond: bool, detail: str = "") -> None:
    global _passed, _failed
    if cond:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


class Harness:
    """A live server on a real port, torn down afterwards."""

    def __init__(self, **app_options):
        self.store = OrderStore.sqlite()
        cfg = ms.load_yaml(MENUS / "bun-n-run-ferndale.yaml")
        self.store.upsert_restaurant(
            cfg.id, cfg.name, cfg.cuisine, tax_rate_bps=cfg.tax_rate_bps,
            sink="manual", staff_phone="+13135550900", inbound_phone=INBOUND,
            active=True)
        self.store.publish_menu(
            cfg.id, (MENUS / "bun-n-run-ferndale.yaml").read_text(),
            item_count=len(cfg.items))
        self.sms = FakeSmsSender()
        self.app = srv.Cherry(self.store, sms=self.sms, api_key=KEY,
                              **app_options)
        self.httpd = srv.build_server(self.app, 0)
        self.port = self.httpd.server_address[1]
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()

    def stop(self):
        self.httpd.shutdown()

    def req(self, method: str, path: str, body: Optional[Dict] = None,
            key: Optional[str] = KEY) -> Tuple[int, Any]:
        data = json.dumps(body).encode() if body is not None else None
        r = urllib.request.Request(f"http://127.0.0.1:{self.port}{path}",
                                   data=data, method=method)
        if data:
            r.add_header("Content-Type", "application/json")
        if key is not None:
            r.add_header("X-Cherry-Key", key)
        try:
            with urllib.request.urlopen(r, timeout=10) as resp:
                return resp.status, json.loads(resp.read())
        except urllib.error.HTTPError as exc:
            raw = exc.read()
            try:
                return exc.code, json.loads(raw)
            except ValueError:
                return exc.code, raw.decode("utf-8", "replace")

    def post(self, path, body=None, key=KEY):
        return self.req("POST", path, body or {}, key)

    def get(self, path, key=KEY):
        return self.req("GET", path, None, key)

    def tool(self, call_id, name, **args):
        return self.post(f"/v1/calls/{call_id}/tools/{name}", args)

    def take_order(self, call_id: str) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        """Walk one order to the point of payment."""
        self.post("/v1/calls", {"call_id": call_id, "to": INBOUND,
                                "from": "+13135550123"})
        self.tool(call_id, "add_item", text="gimme a double cheeseburger")
        self.tool(call_id, "remove_modifier", text="no onion")
        self.tool(call_id, "confirm_mods")
        self.tool(call_id, "set_name", text="Sam")
        self.tool(call_id, "note_allergy", text="no")
        _, finish = self.post(f"/v1/calls/{call_id}/finish", {})
        return finish, self.store.order(finish["order_id"])


# ---------------------------------------------------------------------------
# The provider itself
# ---------------------------------------------------------------------------


def t_provider_issues_an_https_link_that_cannot_be_paid() -> None:
    p = dev_checkout.DevCheckoutProvider()
    link = p.create_pay_link("order-123", 1059, None, snapshot={}, context={})
    check("dev link is https", link.url.startswith("https://"), link.url)
    check("dev link uses the reserved .test host",
          ".test" in link.url, link.url)
    check("dev link names the order", "order-123" in link.url, link.url)
    check("provider is marked not real", p.is_real is False)
    check("provider name is dev", p.name == "dev")
    check("link expiry is set", bool(link.expires_at))
    check("request was recorded",
          p.requests and p.requests[0]["amount_cents"] == 1059)


def t_provider_refuses_a_non_https_base() -> None:
    try:
        dev_checkout.DevCheckoutProvider(base_url="http://localhost:8080")
    except dev_checkout.DevCheckoutError:
        check("http base is refused, same rule as a real provider", True)
        return
    check("http base is refused, same rule as a real provider", False,
          "constructor accepted http")


def t_provider_revoke_is_recorded() -> None:
    p = dev_checkout.DevCheckoutProvider()
    link = p.create_pay_link("o", 100, None, snapshot={}, context={})
    p.revoke_pay_link(link.provider_link_ref)
    check("revocation is recorded", p.revoked == [link.provider_link_ref])


# ---------------------------------------------------------------------------
# The whole order, end to end
# ---------------------------------------------------------------------------


def t_a_whole_order_completes_with_dev_checkout() -> None:
    h = Harness(pay_provider=dev_checkout.DevCheckoutProvider(),
                dev_checkout=True)
    try:
        finish, order = h.take_order("dev-one")

        check("the order is placed", finish.get("placed") is True)
        check("a checkout link was actually sent",
              finish.get("payment") == "link_sent", str(finish.get("payment")))
        check("the caller is told to pay, not that it failed",
              "I could not deliver" not in finish["say"], finish["say"])
        check("the customer is awaiting payment", finish["awaiting_payment"] is True)
        check("nothing reached the kitchen before payment",
              finish["delivered"] is False)

        paid = h.post(f"/v1/dev/pay/{finish['order_id']}")
        check("dev payment endpoint succeeded", paid[0] == 200, str(paid))
        check("payment is recorded", paid[1].get("paid") is True)
        check("the amount matches the order",
              paid[1]["amount_cents"] == finish["total_cents"])

        released = paid[1].get("release") or {}
        check("the order was released to the sink",
              released.get("released") is True, str(released))
        check("the sink is the restaurant's configured one",
              released.get("sink") == "manual", str(released))

        # The database, not the response, is the source of truth.
        pay = order and h.store.conn.execute(
            "SELECT status FROM payment WHERE order_id=?",
            (finish["order_id"],)).fetchone()
        check("payment row says paid", pay["status"] == "paid", str(dict(pay)))
        dl = h.store.conn.execute(
            "SELECT status FROM order_delivery WHERE order_id=?",
            (finish["order_id"],)).fetchone()
        check("delivery row says sent", dl is not None and dl["status"] == "sent",
              str(dict(dl)) if dl else "no delivery row")

        kinds = [r["kind"] for r in h.store.conn.execute(
            "SELECT kind FROM event WHERE order_id=? ORDER BY id",
            (finish["order_id"],))]
        check("the real release event fired",
              "order.released_after_payment" in kinds, str(kinds))
        check("the real payment event fired",
              "payment.paid" in kinds, str(kinds))
    finally:
        h.stop()


def t_paying_twice_is_refused() -> None:
    """A retried dev ping must not deliver a second kitchen ticket."""
    h = Harness(pay_provider=dev_checkout.DevCheckoutProvider(),
                dev_checkout=True)
    try:
        finish, _ = h.take_order("dev-twice")
        first = h.post(f"/v1/dev/pay/{finish['order_id']}")
        second = h.post(f"/v1/dev/pay/{finish['order_id']}")
        check("first payment succeeds", first[1].get("paid") is True)
        check("second payment is refused with a conflict", second[0] == 409,
              f"HTTP {second[0]}")
        check("the refusal says why",
              second[1].get("reason") == "payment is not awaiting settlement",
              str(second[1]))
        n = h.store.conn.execute(
            "SELECT count(*) AS n FROM order_delivery WHERE order_id=?",
            (finish["order_id"],)).fetchone()["n"]
        check("exactly one kitchen ticket exists", int(n) == 1, f"{n} tickets")
    finally:
        h.stop()


def t_unknown_order_is_a_404() -> None:
    h = Harness(pay_provider=dev_checkout.DevCheckoutProvider(),
                dev_checkout=True)
    try:
        status, body = h.post("/v1/dev/pay/does-not-exist")
        check("unknown order is 404", status == 404, f"HTTP {status}")
        check("and says so", body.get("error") == "unknown order", str(body))
    finally:
        h.stop()


def t_dev_payment_needs_the_api_key() -> None:
    h = Harness(pay_provider=dev_checkout.DevCheckoutProvider(),
                dev_checkout=True)
    try:
        finish, _ = h.take_order("dev-auth")
        status, _ = h.post(f"/v1/dev/pay/{finish['order_id']}", key=None)
        check("no key is rejected", status == 401, f"HTTP {status}")
        status, _ = h.post(f"/v1/dev/pay/{finish['order_id']}", key="wrong")
        check("wrong key is rejected", status == 401, f"HTTP {status}")
    finally:
        h.stop()


# ---------------------------------------------------------------------------
# The guards — this is the part that must not regress
# ---------------------------------------------------------------------------


def t_dev_endpoint_does_not_exist_without_the_flag() -> None:
    """404, not 403: a production server must not advertise the route."""
    h = Harness()          # no dev_checkout, no paying provider
    try:
        status, body = h.post("/v1/dev/pay/any-order-id")
        check("dev endpoint is 404 without the flag", status == 404,
              f"HTTP {status}")
        check("and leaks nothing",
              body.get("error") == "not found", str(body))
        check("health does not claim dev checkout",
              h.get("/health")[1]["checkout"] == "provider")
    finally:
        h.stop()


def t_without_dev_checkout_the_old_behaviour_is_unchanged() -> None:
    """The original dead end must still be the dead end. No silent fix."""
    h = Harness()
    try:
        finish, _ = h.take_order("no-provider")
        check("still placed", finish.get("placed") is True)
        check("still no link without a provider",
              finish.get("payment") == "link_pending",
              str(finish.get("payment")))
        check("still not delivered", finish["delivered"] is False)
        check("still tells the caller staff must help",
              "I could not deliver the secure checkout" in finish["say"],
              finish["say"])
        check("still escalates",
              h.store.conn.execute(
                  "SELECT count(*) AS n FROM event "
                  "WHERE kind='session.escalated'").fetchone()["n"] >= 1,
              "no session.escalated event")
    finally:
        h.stop()


def t_health_reports_dev_checkout() -> None:
    h = Harness(pay_provider=dev_checkout.DevCheckoutProvider(),
                dev_checkout=True)
    try:
        check("health says dev",
              h.get("/health")[1]["checkout"] == "dev")
    finally:
        h.stop()


def t_dev_checkout_still_respects_handoff_only() -> None:
    """Dev checkout must not bypass the payment-gated release decision."""
    h = Harness(pay_provider=dev_checkout.DevCheckoutProvider(),
                dev_checkout=True, checkout_handoff_only=True)
    try:
        finish, _ = h.take_order("dev-handoff")
        check("link sent under handoff-only",
              finish.get("payment") == "link_sent", str(finish.get("payment")))
        check("handoff-only flags the handoff",
              finish.get("checkout_handed_off") is True)
        check("handoff-only does not await payment",
              finish["awaiting_payment"] is False)
    finally:
        h.stop()


def main() -> int:
    tests = [v for k, v in sorted(globals().items())
             if k.startswith("t_") and callable(v)]
    for fn in tests:
        try:
            fn()
        except Exception as exc:                       # noqa: BLE001
            check(f"{fn.__name__} raised", False, repr(exc))
    if _failed:
        print(f"{_passed} passed, {_failed} failed (dev checkout)")
        return 1
    print(f"{_passed} passed, 0 failed (dev checkout)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
