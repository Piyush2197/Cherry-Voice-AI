#!/usr/bin/env python3
"""Nightly Square-to-Cherry catalog synchronization job."""

from __future__ import annotations

import _ensure_deps  # noqa: F401  (re-runs under .venv, or says how to install, if PyYAML is missing)
import argparse
import json
import os

import yaml

import catalog_sync
import menu_schema as ms
from config_validator import lint_config
from order_store import OrderStore


def sync_one(store: OrderStore, restaurant_id: str, pos_items: list) -> dict:
    cfg, _ = store.load_live_config(restaurant_id)
    diff = catalog_sync.diff_catalog(cfg, pos_items)
    applied = catalog_sync.apply_auto(store, restaurant_id, diff)
    price_changes = [c for c in diff.auto if c.kind == "price"]
    new_version = None
    if price_changes:
        live = store.live_menu(restaurant_id)
        doc = yaml.safe_load(live["yaml"])
        by_id = {row["id"]: row for row in doc.get("items", [])}
        for change in price_changes:
            cents = int(change.new)
            by_id[change.item_id]["price"] = f"{cents // 100}.{cents % 100:02d}"
            by_id[change.item_id].pop("price_cents", None)
        candidate = ms.build_config(doc)
        errors = [str(x) for x in lint_config(candidate) if x.level == "ERROR"]
        if errors:
            raise RuntimeError("synced menu failed gate: " + "; ".join(errors))
        text = yaml.safe_dump(doc, sort_keys=False, width=100)
        new_version = store.publish_menu(
            restaurant_id, text, item_count=len(candidate.items),
            published_by="catalog_nightly")
    review = [{"kind": c.kind, "item_id": c.item_id, "what": c.what}
              for c in diff.review]
    if review:
        store.log_event("catalog.review_required", restaurant_id=restaurant_id,
                        detail={"changes": review})
    return {"restaurant_id": restaurant_id, "summary": diff.summary(),
            "availability_applied": applied["availability"],
            "prices_applied": len(price_changes), "menu_version_id": new_version,
            "review": review}


from vault import secret as vault_secret

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument("--db",required=True);ap.add_argument("--restaurant",action="append",required=True)
    args=ap.parse_args();store=OrderStore.open(args.db);reports=[]
    for rid in args.restaurant:
        env_id=rid.upper().replace("-","_")
        token=vault_secret(f"SQUARE_TOKEN_{env_id}")
        location=vault_secret(f"SQUARE_LOCATION_{env_id}")
        if not token or not location: raise SystemExit(f"missing Square settings for {rid}")
        reports.append(sync_one(store,rid,catalog_sync.SquareCatalog(token,location,sandbox=os.environ.get("CHERRY_SQUARE_SANDBOX")=="1").items()))
    print(json.dumps(reports,indent=2))
    # Items waiting for an owner's review are NORMAL, not a failed job: they
    # are recorded as catalog.review_required and shown in the nightly brief.
    # A non-zero exit here made run-job.sh page the owner as "job failed"
    # every night for every Square location.
    return 0
if __name__=="__main__":raise SystemExit(main())
