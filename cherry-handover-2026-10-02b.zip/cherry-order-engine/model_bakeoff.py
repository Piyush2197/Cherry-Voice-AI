#!/usr/bin/env python3
"""Which model should run Lily? Measure it, don't guess.

    python3 model_bakeoff.py run --brain scripted                     # the oracle: the engine itself, on every scenario
    python3 model_bakeoff.py run --brain naive                        # a deliberately dumb baseline (proves the scoring bites)
    python3 model_bakeoff.py run --brain openai --model <name> \\
        --base-url https://.../v1 --api-key-env MY_KEY \\
        --price-in 0.075 --price-out 0.30                             # any OpenAI-compatible endpoint

A "brain" is whatever turns the caller's words into tool calls: today Gemma
through Inworld, tomorrow Gemini or anything else. This plays the same scripted
calls (`bakeoff_scenarios.py`: seven cuisines, Spanish, Arabic and Hindi/Urdu,
allergies, regulars, sold-out dishes, corrections) through the REAL engine —
`CallSession` and Cherry's own argument validation — and scores what matters:

  * the final cart, the name and the allergy note, against what the caller meant;
  * duplicate and failed tool calls (Gemini 3.8 Live is documented to retry a
    tool 2-5 times when it gets no result — an engine guard catches them, but a
    brain that does it constantly is costing you turns);
  * VERBATIM: whether what the model SPOKE equals what the engine told it to say
    (the guarantee that stops it inventing a price);
  * latency, tokens and the dollars they cost.

The scripted brain replays each scenario's ideal tool calls, so it is also the
regression test for the engine, the phrasebook and the call flow.
"""

from __future__ import annotations

import _ensure_deps  # noqa: F401  (re-runs under .venv, or says how to install, if PyYAML is missing)
import argparse
import inspect
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import agent_api
import menu_schema as ms
from agent_api import CallSession

HERE = Path(__file__).resolve().parent
MAX_ROUNDS = 6              # tool round trips a brain gets for ONE caller utterance


@dataclass
class ToolCall:
    name: str
    args: Dict[str, Any]
    id: str = ""


@dataclass
class Response:
    tool_calls: List[ToolCall] = field(default_factory=list)
    content: Optional[str] = None
    usage: Dict[str, int] = field(default_factory=dict)       # {"in": tokens, "out": tokens}


# ---------------------------------------------------------------------------
# Brains
# ---------------------------------------------------------------------------

class ScriptedBrain:
    """The ideal tool calls for each caller utterance — the oracle."""
    name = "scripted"

    def __init__(self, plan: Sequence[Sequence[Tuple[str, Dict[str, Any]]]]) -> None:
        self.plan = [list(p) for p in plan]
        self.turn = -1
        self.last_say = ""

    def respond(self, messages: List[Dict[str, Any]], tools) -> Response:
        last = messages[-1]
        if last["role"] == "user":
            self.turn += 1
            calls = self.plan[self.turn] if self.turn < len(self.plan) else []
            if calls:
                return Response([ToolCall(n, dict(a), f"c{self.turn}-{i}") for i, (n, a) in enumerate(calls)])
            return Response(content="")
        # tool results are in: speak what the engine said (verbatim)
        says = [json.loads(m["content"]).get("say", "") for m in messages if m["role"] == "tool"
                and m.get("turn") == self.turn]
        return Response(content=says[-1] if says else "")


class NaiveBrain:
    """What a careless integration does: every utterance is an item, unless the
    engine just asked something. Exists to prove the scoring can tell."""
    name = "naive"

    def respond(self, messages: List[Dict[str, Any]], tools) -> Response:
        last = messages[-1]
        if last["role"] != "user":
            says = [json.loads(m["content"]).get("say", "") for m in messages[::-1] if m["role"] == "tool"][:1]
            return Response(content=says[0] if says else "")
        text = last["content"]
        prior = next((json.loads(m["content"]) for m in reversed(messages) if m["role"] == "tool"), {})
        if re.search(r"\b(that'?s all|that is all|that'?s it)\b", text, re.I):
            return Response([ToolCall("ready_to_place", {}, "n")])
        if prior.get("needs"):
            return Response([ToolCall("answer", {"text": text}, "n")])
        return Response([ToolCall("add_item", {"text": text}, "n")])


class OpenAICompatibleBrain:
    """Any chat-completions endpoint with tool calling. No SDK: one POST."""

    def __init__(self, model: str, base_url: str, api_key: str, timeout: float = 60.0) -> None:
        self.name, self.model = model, model
        self.url = base_url.rstrip("/") + "/chat/completions"
        self.key, self.timeout = api_key, timeout

    def respond(self, messages: List[Dict[str, Any]], tools) -> Response:
        clean = []
        for m in messages:                       # strip the harness's own bookkeeping
            c = {k: v for k, v in m.items() if k != "turn"}
            clean.append(c)
        body = {"model": self.model, "messages": clean, "temperature": 0,
                "tools": [{"type": "function", "function": t} for t in tools]}
        req = urllib.request.Request(self.url, data=json.dumps(body).encode(), method="POST",
                                     headers={"Content-Type": "application/json",
                                              "Authorization": f"Bearer {self.key}"})
        with urllib.request.urlopen(req, timeout=self.timeout) as r:
            data = json.loads(r.read())
        msg = data["choices"][0]["message"]
        usage = data.get("usage") or {}
        calls = []
        for tc in msg.get("tool_calls") or []:
            raw = tc["function"].get("arguments") or "{}"
            try:
                args = json.loads(raw)
            except ValueError:
                args = {"_unparsed": raw}
            calls.append(ToolCall(tc["function"]["name"], args if isinstance(args, dict) else {}, tc.get("id", "")))
        return Response(calls, msg.get("content"), {"in": int(usage.get("prompt_tokens") or 0),
                                                    "out": int(usage.get("completion_tokens") or 0)})


# ---------------------------------------------------------------------------
# Running one scenario
# ---------------------------------------------------------------------------

@dataclass
class Result:
    id: str
    tags: List[str]
    passed: bool
    problems: List[str]
    tool_calls: int = 0
    duplicate_calls: int = 0
    failed_calls: int = 0
    bad_tool_calls: int = 0
    spoken: int = 0
    verbatim_breaks: int = 0
    latency_ms: float = 0.0
    tokens_in: int = 0
    tokens_out: int = 0
    cart: List[Tuple[str, int]] = field(default_factory=list)


def _load(menu: str):
    return ms.load_yaml(HERE / "menus" / f"{menu}.yaml")


def _norm(text: str) -> str:
    return " ".join((text or "").split())


def run_scenario(scn: Dict[str, Any], brain) -> Result:
    from server import ALL_TOOL_SCHEMAS, Cherry
    cfg = _load(scn["menu"])
    for sold_out in scn.get("unavailable", []):          # the kitchen has 86'd these
        object.__setattr__(next(i for i in cfg.items if i.name == sold_out), "available", False)
    session = CallSession(cfg)
    ctx = dict(scn.get("context") or {})
    if ctx:
        session.set_context(**ctx)
    greeting = session.greeting()["say"]
    messages: List[Dict[str, Any]] = [{"role": "system", "content": "You are Lily."},
                                      {"role": "assistant", "content": greeting}]
    res = Result(scn["id"], list(scn.get("tags", [])), True, [])
    last_sig: Optional[str] = None
    clock = [0.0]
    session.now = lambda: clock[0]
    for ti, utterance in enumerate(scn["caller"]):
        clock[0] += 8.0         # a real caller takes seconds: Lily's reply, then their words
        messages.append({"role": "user", "content": utterance})
        last_say = None
        for _round in range(MAX_ROUNDS):
            t0 = time.perf_counter()
            resp = brain.respond(messages, ALL_TOOL_SCHEMAS)
            res.latency_ms += (time.perf_counter() - t0) * 1000
            res.tokens_in += resp.usage.get("in", 0)
            res.tokens_out += resp.usage.get("out", 0)
            if not resp.tool_calls:
                if resp.content:
                    res.spoken += 1
                    if last_say is not None and _norm(resp.content) != _norm(last_say):
                        res.verbatim_breaks += 1
                    messages.append({"role": "assistant", "content": resp.content})
                break
            messages.append({"role": "assistant", "content": None, "tool_calls": [
                {"id": c.id or f"t{i}", "type": "function",
                 "function": {"name": c.name, "arguments": json.dumps(c.args)}}
                for i, c in enumerate(resp.tool_calls)]})
            for i, call in enumerate(resp.tool_calls):
                res.tool_calls += 1
                sig = json.dumps([call.name, call.args], sort_keys=True)
                if sig == last_sig:
                    res.duplicate_calls += 1
                last_sig = sig
                if call.name not in {t["name"] for t in ALL_TOOL_SCHEMAS}:
                    res.bad_tool_calls += 1
                    result = {"ok": False, "say": "Sorry, I didn't catch that — could you say it again?",
                              "error": "unknown_tool", "retryable": False}
                else:
                    typed = Cherry._typed_args(call.name, call.args)
                    if typed is None:
                        result = session.argument_error(call.name)
                    else:
                        fn = getattr(session, call.name)
                        accepted = set(inspect.signature(fn).parameters)
                        try:
                            result = fn(**{k: v for k, v in typed.items() if k in accepted})
                        except Exception as exc:                      # noqa: BLE001
                            result = {"ok": False, "say": "Sorry, say that again?", "error": repr(exc)[:60]}
                if not result.get("ok", True):
                    res.failed_calls += 1
                last_say = result.get("say", "")
                slim = {k: result.get(k) for k in ("ok", "say", "error", "needs", "retryable") if k in result}
                messages.append({"role": "tool", "tool_call_id": call.id or f"t{i}", "turn": ti,
                                 "content": json.dumps(slim)})
        else:
            res.problems.append(f"utterance {ti + 1}: the brain never finished (over {MAX_ROUNDS} rounds)")
    _score(session, scn.get("expect") or {}, res, messages)
    res.cart = [(ln["item_name"], ln["quantity"]) for ln in session.snapshot()["lines"]]
    return res


def _score(session: CallSession, expect: Dict[str, Any], res: Result, messages) -> None:
    snap = session.snapshot()
    got = sorted((ln["item_name"], ln["quantity"]) for ln in snap["lines"])
    if "cart" in expect:
        want = sorted((n, q) for n, q in expect["cart"])
        if got != want:
            res.problems.append(f"cart {got} != expected {want}")
    if "total_items" in expect:
        n = sum(ln["quantity"] for ln in snap["lines"])
        if n != expect["total_items"]:
            res.problems.append(f"{n} items on the order, expected {expect['total_items']}")
    if expect.get("submittable") and not session.e.is_submittable():
        res.problems.append("order is not complete (an open question remains)")
    if "name" in expect and session.customer_name != expect["name"]:
        res.problems.append(f"name {session.customer_name!r} != {expect['name']!r}")
    allergy = expect.get("allergy")
    note = (snap.get("allergy") or {}).get("note", "")
    if allergy == "none" and (note or not session._allergy_checked):
        res.problems.append(f"expected 'no allergies' recorded, got note={note!r} checked={session._allergy_checked}")
    elif allergy and allergy.startswith("contains:") and allergy.split(":", 1)[1].lower() not in note.lower():
        res.problems.append(f"allergy note {note!r} lacks {allergy.split(':', 1)[1]!r}")
    if expect.get("text_to") and session.text_to != expect["text_to"]:
        res.problems.append(f"text_to {session.text_to!r} != {expect['text_to']!r}")
    says = " ".join(json.loads(m["content"]).get("say", "") for m in messages if m["role"] == "tool")
    for needle in expect.get("says", []):
        if needle.lower() not in says.lower():
            res.problems.append(f"never said {needle!r}")
    for needle in expect.get("never_says", []):
        if needle.lower() in says.lower():
            res.problems.append(f"said {needle!r}, which it must not")
    if "max_tool_calls" in expect and res.tool_calls > expect["max_tool_calls"]:
        res.problems.append(f"{res.tool_calls} tool calls (limit {expect['max_tool_calls']})")
    res.passed = not res.problems


# ---------------------------------------------------------------------------
# The whole bake-off
# ---------------------------------------------------------------------------

def run_all(brain_factory, scenarios, *, only: Optional[str] = None) -> List[Result]:
    out = []
    for scn in scenarios:
        if only and only not in scn["id"] and only not in scn.get("tags", []):
            continue
        out.append(run_scenario(scn, brain_factory(scn)))
    return out


def summarize(results: List[Result], *, price_in: float = 0.0, price_out: float = 0.0) -> Dict[str, Any]:
    n = len(results) or 1
    tin, tout = sum(r.tokens_in for r in results), sum(r.tokens_out for r in results)
    by_tag: Dict[str, List[bool]] = {}
    for r in results:
        for t in r.tags:
            by_tag.setdefault(t, []).append(r.passed)
    return {
        "scenarios": len(results),
        "passed": sum(r.passed for r in results),
        "pass_rate": sum(r.passed for r in results) / n,
        "tool_calls_per_call": sum(r.tool_calls for r in results) / n,
        "duplicate_calls": sum(r.duplicate_calls for r in results),
        "failed_calls": sum(r.failed_calls for r in results),
        "bad_tool_calls": sum(r.bad_tool_calls for r in results),
        "verbatim_breaks": sum(r.verbatim_breaks for r in results),
        "spoken_turns": sum(r.spoken for r in results),
        "latency_ms_per_call": sum(r.latency_ms for r in results) / n,
        "tokens_in_per_call": tin / n, "tokens_out_per_call": tout / n,
        "llm_cost_per_call": (tin * price_in + tout * price_out) / 1e6 / n,
        "by_tag": {t: sum(v) / len(v) for t, v in sorted(by_tag.items())},
    }


def main(argv: Optional[List[str]] = None) -> int:
    from bakeoff_scenarios import SCENARIOS
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run")
    r.add_argument("--brain", choices=["scripted", "naive", "openai"], required=True)
    r.add_argument("--model", default="")
    r.add_argument("--base-url", default="")
    r.add_argument("--api-key-env", default="")
    r.add_argument("--price-in", type=float, default=0.0, help="USD per 1M input tokens for this model")
    r.add_argument("--price-out", type=float, default=0.0, help="USD per 1M output tokens for this model")
    r.add_argument("--only", help="a scenario id substring or tag")
    r.add_argument("--out", help="write the full JSON report here")
    r.add_argument("-v", "--verbose", action="store_true")
    args = ap.parse_args(argv)

    if args.brain == "scripted":
        factory = lambda scn: ScriptedBrain(scn["plan"])                       # noqa: E731
    elif args.brain == "naive":
        factory = lambda scn: NaiveBrain()                                     # noqa: E731
    else:
        key = os.environ.get(args.api_key_env, "")
        if not (args.model and args.base_url and key):
            print("openai brain needs --model, --base-url and --api-key-env naming a set variable")
            return 2
        brain = OpenAICompatibleBrain(args.model, args.base_url, key)
        factory = lambda scn: brain                                            # noqa: E731
    results = run_all(factory, SCENARIOS, only=args.only)
    s = summarize(results, price_in=args.price_in, price_out=args.price_out)
    print(f"{args.brain}: {s['passed']}/{s['scenarios']} scenarios correct ({s['pass_rate'] * 100:.0f}%)")
    print(f"  tool calls/call {s['tool_calls_per_call']:.1f} · duplicates {s['duplicate_calls']} · failed {s['failed_calls']} · "
          f"unknown tools {s['bad_tool_calls']} · verbatim breaks {s['verbatim_breaks']}/{s['spoken_turns']} spoken turns")
    print(f"  latency {s['latency_ms_per_call']:.0f} ms/call · tokens in/out {s['tokens_in_per_call']:.0f}/{s['tokens_out_per_call']:.0f} · "
          f"model cost ${s['llm_cost_per_call']:.4f}/call")
    print("  by group: " + ", ".join(f"{t} {v * 100:.0f}%" for t, v in s["by_tag"].items()))
    for res in results:
        if not res.passed:
            print(f"  FAIL {res.id}: " + "; ".join(res.problems))
        elif args.verbose:
            print(f"  ok   {res.id}: {res.cart}")
    if args.out:
        Path(args.out).write_text(json.dumps({"summary": s, "results": [r.__dict__ for r in results]}, indent=2, default=str))
    return 0 if s["passed"] == s["scenarios"] or args.brain != "scripted" else 1


if __name__ == "__main__":
    sys.exit(main())
