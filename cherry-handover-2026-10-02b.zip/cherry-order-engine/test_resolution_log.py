#!/usr/bin/env python3
"""The resolution log: what callers said, what the matcher chose, the runner-up."""
from __future__ import annotations

import sys
import traceback

from agent_api import CallSession

def _cfg():
    import menu_schema as ms
    return ms.load_yaml("menus/pink-garlic-shelby.yaml")


def t_call_session_notes_match_ambiguous_and_no_match() -> None:
    cfg = _cfg()
    call = CallSession(cfg)
    call.add_item("saag")                       # same dish, several proteins: ambiguous
    call.add_item("pepperoni pizza")             # not sold here
    call.add_item("garlic naan")                # plain match
    notes = call.take_resolutions()
    outcomes = [n["outcome"] for n in notes]
    assert outcomes == ["ambiguous", "no_match", "matched"], outcomes
    amb = notes[0]
    assert amb["runner_up_id"] and amb["resolved_id"] != amb["runner_up_id"], amb
    assert notes[1]["resolved_id"] is None and notes[1]["score"] is None, notes[1]
    assert notes[2]["resolved_name"] and notes[2]["score"] > 0.6, notes[2]
    assert call.take_resolutions() == [], "notes must be drained once taken"


def t_notes_never_change_the_call() -> None:
    cfg = _cfg()
    a, b = CallSession(cfg), CallSession(cfg)
    ra = a.add_item("garlic naan")
    b.resolutions.clear()
    rb = b.add_item("garlic naan")
    assert ra == rb


TESTS = [v for k, v in sorted(globals().items()) if k.startswith("t_")]


def main() -> int:
    fails = []
    for fn in TESTS:
        try:
            fn()
        except Exception:                                   # noqa: BLE001
            fails.append((fn.__name__, traceback.format_exc()))
    print(f"{len(TESTS) - len(fails)} passed, {len(fails)} failed")
    for n, tb in fails:
        print(f"\n--- FAIL {n}\n{tb}")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
