"""
One simulated phone order per cuisine, through the same engine.

This is the artefact to show a restaurant owner during onboarding: their menu,
their modifiers, their prices, their ticket — before a single line of POS
integration exists.

The driver below is a deliberately dumb stand-in for Lily. It only does what
the real voice layer will do:

    1. match the caller's words to a menu item
    2. read out engine.next_question()
    3. match the caller's answer against that question's own candidate list
    4. repeat until engine.is_submittable()
    5. read back and hand to_normalized_order() to a POS bridge

Note what the driver does NOT do: decide anything. Every question and every
legal answer comes from the config, which is why onboarding a new cuisine is
a data change.
"""

from __future__ import annotations

from typing import List, Optional

from cuisine_packs import ALL_PACKS
from order_engine import IssueCode, OrderEngine, Placement, money


class LilyDriver:
    def __init__(self, config, verbose: bool = True) -> None:
        self.engine = OrderEngine(config)
        self.verbose = verbose
        self.transcript: List[str] = []

    def _log(self, who: str, text: str) -> None:
        self.transcript.append(f"{who}: {text}")
        if self.verbose:
            colour = "\033[36m" if who == "Lily" else "\033[33m"
            print(f"  {colour}{who:8s}\033[0m {text}")

    # -- caller says an item ---------------------------------------------
    def caller_orders(self, utterance: str, quantity: int = 1) -> Optional[str]:
        self._log("Caller", utterance)
        cands = self.engine.matcher.match_items(utterance)
        if not cands:
            self._log("Lily", "I'm sorry, I didn't catch that — what would "
                              "you like?")
            return None
        if not self.engine.matcher.is_decisive(cands):
            names = " or the ".join(c.target_name for c in cands[:2])
            self._log("Lily", f"Did you want the {names}?")
            return None
        line = self.engine.add_line(cands[0].target_id, quantity=quantity)
        return line.line_id

    # -- caller answers the outstanding question -------------------------
    def caller_answers(self, utterance: str, placement: Placement = Placement.WHOLE,
                       quantity: int = 1) -> bool:
        issue = next((i for i in self.engine.validate()
                      if i.blocking and i.question), None)
        if issue is None:
            return False
        self._log("Lily", issue.question)
        self._log("Caller", utterance)
        line_id = issue.line_id
        if issue.code is IssueCode.SIZE_REQUIRED:
            item = self.engine.config.item(self.engine.get_line(line_id).item_id)
            sc = self.engine.matcher.match_size(utterance, item)
            if sc:
                self.engine.set_size(line_id, sc[0].target_id)
                return True
            self._log("Lily", "Sorry, which size was that?")
            return False
        oc = self.engine.matcher.match_options(utterance, issue.candidates)
        if not oc:
            self._log("Lily", "Sorry, I didn't get that — could you say it again?")
            return False
        self.engine.apply_option(line_id, issue.group_id, oc[0].target_id,
                                 quantity=quantity, placement=placement)
        return True

    # -- caller volunteers an extra ("and extra bacon") ------------------
    def caller_adds(self, line_id: str, group_id: str, utterance: str,
                    quantity: int = 1,
                    placement: Placement = Placement.WHOLE) -> None:
        self._log("Caller", utterance)
        group = self.engine.config.group(group_id)
        allowed = group.option_ids if group else None
        oc = self.engine.matcher.match_options(utterance, allowed)
        if not oc:
            self._log("Lily", "We don't have that, sorry.")
            return
        issues = self.engine.apply_option(line_id, group_id, oc[0].target_id,
                                          quantity=quantity, placement=placement)
        for i in issues:
            self._log("Lily", i.question or i.message)

    def caller_removes(self, line_id: str, utterance: str) -> None:
        self._log("Caller", utterance)
        oc = self.engine.matcher.match_options(utterance)
        if oc and self.engine.remove_option(line_id, oc[0].target_id):
            return
        self._log("Lily", "I'm not sure that's on there — could you say it again?")

    def resolve_outstanding(self, answers: List[str]) -> None:
        for a in answers:
            if self.engine.is_submittable():
                break
            self.caller_answers(a)

    def close(self) -> None:
        self._log("Lily", self.engine.read_back())
        p = self.engine.price()
        mode = ("we'll take payment now" if p.pay_now
                else "you can pay when you pick up")
        self._log("Lily", f"Subtotal {money(p.subtotal_cents)}, tax "
                          f"{money(p.tax_cents)} — {mode}.")
        assert self.engine.is_submittable(), "order left the call incomplete"


def header(cfg) -> None:
    print(f"\n\033[1m{'─' * 72}\n{cfg.name}  ({cfg.cuisine})\n{'─' * 72}\033[0m")


def ticket(driver: LilyDriver) -> None:
    n = driver.engine.to_normalized_order()
    print(f"\n  \033[2mKITCHEN TICKET → {n['pos_type']}\033[0m")
    for l in n["lines"]:
        size = f" [{l['size_name']}]" if l["size_name"] else ""
        print(f"    {l['quantity']}x {l['item_name']}{size}"
              f"  {money(l['line_total_cents'])}")
        for m in l["modifiers"]:
            tag = " (included)" if m["informational"] else ""
            q = f"{m['quantity']}x " if m["quantity"] > 1 else ""
            pl = f" [{m['placement']}]" if m["placement"] != "whole" else ""
            print(f"        + {q}{m['option_name']}{pl}{tag}")
        for r in l["removed_defaults"]:
            print(f"        - NO {r}")
    print(f"    {'':38s} TOTAL {money(n['total_cents'])}  "
          f"({n['payment_mode']})")


# ===========================================================================


def demo_indian():
    cfg = ALL_PACKS["indian"]
    header(cfg)
    d = LilyDriver(cfg)
    lid = d.caller_orders("uh yeah can I get a chicken tikka masala")
    d.resolve_outstanding(["medium please", "chicken"])
    d.caller_adds(lid, "indian_addons", "and two garlic naan", quantity=2)
    d.caller_orders("also a mango lassi")
    d.close()
    ticket(d)


def demo_mexican():
    cfg = ALL_PACKS["mexican"]
    header(cfg)
    d = LilyDriver(cfg)
    lid = d.caller_orders("three al pastor tacos", quantity=3)
    d.resolve_outstanding(["al pastor", "corn"])
    d.caller_adds(lid, "mx_salsa", "green salsa and some pico")
    d.caller_adds(lid, "mx_salsa", "and the habanero too")
    d.caller_adds(lid, "mx_addons", "add guac")
    d.close()
    ticket(d)


def demo_mediterranean():
    cfg = ALL_PACKS["mediterranean"]
    header(cfg)
    d = LilyDriver(cfg)
    lid = d.caller_orders("one chicken kabob plate")
    d.resolve_outstanding(["rice", "lentil soup"])
    d.caller_adds(lid, "med_sauce", "garlic sauce and tzatziki")
    d.caller_adds(lid, "med_sauce", "tzatziki as well")
    d.close()
    ticket(d)


def demo_japanese():
    cfg = ALL_PACKS["japanese"]
    header(cfg)
    d = LilyDriver(cfg)
    lid = d.caller_orders("we'd like the sushi boat")
    d.resolve_outstanding(["california", "spicy tuna", "dragon roll"])
    d.caller_adds(lid, "sushi_prefs", "no wasabi please")
    d.caller_orders("and a poke bowl")
    d.resolve_outstanding(["brown rice", "salmon"])
    d.close()
    ticket(d)


def demo_korean():
    cfg = ALL_PACKS["korean"]
    header(cfg)
    d = LilyDriver(cfg)
    lid = d.caller_orders("large korean fried chicken")
    d.resolve_outstanding(["large", "soy garlic"])
    d.caller_adds(lid, "kr_addons", "two extra sauce cups", quantity=2)
    d.caller_orders("and a bibimbap")
    d.resolve_outstanding(["tofu", "spicy"])
    d.close()
    ticket(d)


def demo_burger():
    cfg = ALL_PACKS["burger"]
    header(cfg)
    d = LilyDriver(cfg)
    lid = d.caller_orders("gimme a double with cheese")
    d.caller_removes(lid, "no onions")
    d.caller_adds(lid, "toppings", "extra bacon", quantity=2)
    d.caller_adds(lid, "combo_upgrade", "make it a combo")
    d.resolve_outstanding(["onion rings", "sprite"])
    d.close()
    ticket(d)


def demo_pizza():
    cfg = ALL_PACKS["pizza"]
    header(cfg)
    d = LilyDriver(cfg)
    lid = d.caller_orders("a large build your own")
    d.resolve_outstanding(["large", "regular crust", "red sauce"])
    d.caller_adds(lid, "toppings_byo", "pepperoni on the left only",
                  placement=Placement.LEFT)
    d.caller_adds(lid, "toppings_byo", "mushrooms on the other half",
                  placement=Placement.RIGHT)
    d.caller_adds(lid, "toppings_byo", "and double extra cheese on the whole thing",
                  quantity=2)
    d.caller_adds(lid, "dips", "couple ranch cups", quantity=2)
    d.close()
    ticket(d)


def demo_italian():
    cfg = ALL_PACKS["italian"]
    header(cfg)
    d = LilyDriver(cfg)
    lid = d.caller_orders("dinner size pasta")
    d.resolve_outstanding(["dinner", "gluten free", "bolognese"])
    d.caller_adds(lid, "it_addons", "add meatballs, make it three", quantity=3)
    d.caller_adds(lid, "it_sides", "and garlic bread")
    d.caller_orders("plus a tiramisu")
    d.close()
    ticket(d)


DEMOS = [demo_indian, demo_mexican, demo_mediterranean, demo_japanese,
         demo_korean, demo_burger, demo_pizza, demo_italian]


if __name__ == "__main__":
    for fn in DEMOS:
        fn()
    print(f"\n\033[1m{len(DEMOS)} cuisines, one engine, zero engine changes "
          f"between them.\033[0m\n")
