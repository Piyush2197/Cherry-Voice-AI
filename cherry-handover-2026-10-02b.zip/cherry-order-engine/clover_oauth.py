"""Clover POS OAuth for Cherry: merchant authorization and token management.

Written against Clover's own documentation (checked 2026-10-02):
  https://docs.clover.com/dev/docs/generate-expiring-tokens-using-v2-oauth-flow
  https://docs.clover.com/dev/docs/refresh-access-tokens
  https://docs.clover.com/dev/docs/high-trust-app-auth-flow
  https://docs.clover.com/dev/docs/oauth-and-tokens-faqs

What Clover actually does (and what the first version of this file got wrong):

* **The merchant id arrives on the redirect**, not in the token response:
  ``/v1/oauth/clover/callback?merchant_id=…&client_id=…&code=…`` (plus our
  ``state``, if Clover echoes it — see "Not proved" below).
* **Token exchange** is ``POST /oauth/v2/token`` with a *JSON* body
  ``{client_id, client_secret, code}``. There is no ``grant_type`` and no
  ``redirect_uri``. The reply is ``access_token``, ``access_token_expiration``,
  ``refresh_token``, ``refresh_token_expiration`` — the expirations are Unix
  timestamps in seconds, not ``expires_in``.
* **Access tokens last 30 minutes.** A daily refresh job cannot keep one alive:
  whatever uses Clover must call ``access_token()`` on every use, which
  refreshes when the token is within a few minutes of expiry.
* **Refresh** is ``POST /oauth/v2/refresh`` with JSON ``{client_id,
  refresh_token}`` — no client secret — and the refresh token is **single
  use**: the one we hold is dead the moment Clover answers. So the new one is
  written to the vault *first*, refreshes are serialized (in-process and across
  processes) so two callers can never spend the same token, and a refresh
  whose reply was lost means the restaurant must approve Cherry again.
* Lifetimes are read from the reply, never assumed.

Flow, once per restaurant:
  1. ``authorize-url`` prints a signed link; the owner opens it and approves Cherry.
  2. Clover redirects to ``/v1/oauth/clover/callback`` with the code.
  3. The server exchanges the code and stores the pair in the vault.
  4. Whatever talks to Clover calls ``access_token()``; ``refresh`` (weekly is
     plenty) rotates a refresh token that is nearing its own expiry.

Tokens never enter Cherry's database or logs. They live in the vault
(``vault.py``: owner-only files by default, or a managed secret manager).

    python3 clover_oauth.py authorize-url --restaurant bun-n-run-ferndale
    python3 clover_oauth.py status --restaurant bun-n-run-ferndale
    python3 clover_oauth.py refresh --restaurant bun-n-run-ferndale

NOT PROVED against a live Clover sandbox (nothing has been run against one):
  * that the authorize page echoes our ``state`` back (the docs list only
    ``client_id`` and the redirect; without ``state`` the callback refuses,
    because it cannot tell which restaurant is approving);
  * the authorize host for the EU and Latin America regions (North America
    only here — the token/refresh hosts for those regions are documented, the
    authorize hosts were not).
Permissions are not requested in the link: Clover keeps them on the app in
the developer dashboard.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Dict, Iterable, Optional, Protocol

from vault import default_vault, exclusive, restaurant_key

# Clover OAuth endpoints (North America)
CLOVER_OAUTH_AUTHORIZE_SANDBOX = "https://sandbox.dev.clover.com/oauth/v2/authorize"
CLOVER_OAUTH_AUTHORIZE_PROD = "https://www.clover.com/oauth/v2/authorize"
CLOVER_OAUTH_TOKEN_SANDBOX = "https://apisandbox.dev.clover.com/oauth/v2/token"
CLOVER_OAUTH_TOKEN_PROD = "https://api.clover.com/oauth/v2/token"
CLOVER_OAUTH_REFRESH_SANDBOX = "https://apisandbox.dev.clover.com/oauth/v2/refresh"
CLOVER_OAUTH_REFRESH_PROD = "https://api.clover.com/oauth/v2/refresh"

STATE_TTL_SECONDS = 60 * 60 * 24 * 2   # the owner may take a day or two
ACCESS_MARGIN = timedelta(minutes=5)   # refresh a 30-minute token this early
REFRESH_WITHIN = timedelta(days=90)    # rotate a refresh token this close to its end
_MERCHANT_ID = re.compile(r"^[A-Za-z0-9]{1,32}$")


class SecretVault(Protocol):
    def get(self, name: str) -> str: ...
    def put(self, name: str, value: str) -> None: ...


class CloverAuthError(RuntimeError):
    pass


@dataclass(frozen=True)
class CloverMerchant:
    restaurant_id: str
    access_token_secret: str
    refresh_token_secret: str
    expires_at_secret: str
    merchant_id_secret: str
    refresh_expires_at_secret: str = ""


def _from_unix(value) -> Optional[datetime]:
    """Clover's expirations are Unix seconds; anything else is unreadable."""
    if isinstance(value, bool):
        return None
    try:
        seconds = float(value)
    except (TypeError, ValueError):
        return None
    if seconds <= 0:
        return None
    try:
        return datetime.fromtimestamp(seconds, timezone.utc)
    except (OverflowError, OSError, ValueError):
        return None


class CloverOAuthClient:
    """Clover OAuth client for the high-trust (server-side) authorization code flow."""

    def __init__(self, client_id: str, client_secret: str, *,
                 sandbox: bool = False, opener=None, timeout: float = 15.0):
        if not client_id or not client_secret:
            raise ValueError("Clover client id and secret are required")
        self.client_id = client_id
        self.client_secret = client_secret
        self.sandbox = sandbox
        self.token_url = CLOVER_OAUTH_TOKEN_SANDBOX if sandbox else CLOVER_OAUTH_TOKEN_PROD
        self.refresh_url = CLOVER_OAUTH_REFRESH_SANDBOX if sandbox else CLOVER_OAUTH_REFRESH_PROD
        self.opener = opener or urllib.request.urlopen
        self.timeout = timeout

    def _post_json(self, url: str, body: dict) -> dict:
        request = urllib.request.Request(
            url, data=json.dumps(body).encode(), method="POST",
            headers={"Content-Type": "application/json", "Accept": "application/json"})
        try:
            with self.opener(request, timeout=self.timeout) as response:
                raw = response.read()
        except urllib.error.HTTPError as exc:
            # the status and Clover's own short message; never our request body
            detail = exc.read().decode(errors="replace") if hasattr(exc, "read") else ""
            detail = detail.replace(self.client_secret, "[secret]")
            raise CloverAuthError(f"Clover OAuth returned HTTP {exc.code}: {detail[:300]}") from exc
        except (urllib.error.URLError, OSError) as exc:   # incl. 3.9's socket.timeout
            raise CloverAuthError(f"Clover OAuth unavailable: {exc}") from exc
        try:
            result = json.loads(raw or b"{}")
        except ValueError as exc:
            raise CloverAuthError("Clover OAuth reply was not JSON") from exc
        if not isinstance(result, dict):
            raise CloverAuthError("Clover OAuth reply was not an object")
        return result

    @staticmethod
    def _pair(result: dict, what: str) -> Dict[str, object]:
        """A usable token pair or an error — never half of one. Expiring tokens
        always rotate, so a reply without a refresh token or without readable
        expiries would strand the merchant."""
        access, refresh = result.get("access_token"), result.get("refresh_token")
        if not access or not isinstance(access, str):
            raise CloverAuthError(f"Clover {what} reply lacks access_token")
        if not refresh or not isinstance(refresh, str):
            raise CloverAuthError(f"Clover {what} reply lacks refresh_token")
        access_exp = _from_unix(result.get("access_token_expiration"))
        refresh_exp = _from_unix(result.get("refresh_token_expiration"))
        if access_exp is None or refresh_exp is None:
            raise CloverAuthError(f"Clover {what} reply lacks readable expiry times")
        return {"access_token": access, "refresh_token": refresh,
                "access_expires_at": access_exp, "refresh_expires_at": refresh_exp}

    def exchange_code(self, code: str) -> Dict[str, object]:
        """Authorization code → token pair (JSON body, no grant_type/redirect_uri)."""
        return self._pair(self._post_json(self.token_url, {
            "client_id": self.client_id, "client_secret": self.client_secret,
            "code": code}), "token")

    def refresh_token(self, refresh_token: str) -> Dict[str, object]:
        """Single-use refresh token → a new pair (no client secret is sent)."""
        return self._pair(self._post_json(self.refresh_url, {
            "client_id": self.client_id, "refresh_token": refresh_token}), "refresh")


def secret_names(restaurant_id: str) -> Dict[str, str]:
    """Vault secret names for Clover tokens per restaurant."""
    key = restaurant_key(restaurant_id)
    return {
        "access": f"CLOVER_TOKEN_{key}",
        "refresh": f"CLOVER_REFRESH_{key}",
        "expires": f"CLOVER_EXPIRES_{key}",
        "refresh_expires": f"CLOVER_REFRESH_EXPIRES_{key}",
        "merchant": f"CLOVER_MERCHANT_{key}",
    }


def merchant_for(restaurant_id: str) -> CloverMerchant:
    """Create CloverMerchant for a restaurant."""
    names = secret_names(restaurant_id)
    return CloverMerchant(restaurant_id, names["access"], names["refresh"],
                          names["expires"], names["merchant"], names["refresh_expires"])


def _b64(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode().rstrip("=")


def sign_state(secret: str, restaurant_id: str, *, now: Optional[float] = None,
               rebind: bool = False) -> str:
    """Create tamper-proof, expiring state that also names the restaurant."""
    if len(secret) < 16:
        raise ValueError("state secret must be at least 16 characters")
    payload = _b64(json.dumps({
        "r": restaurant_id,
        "exp": int((now or time.time()) + STATE_TTL_SECONDS),
        "n": secrets.token_hex(12),
        "rb": bool(rebind)
    }).encode())
    sig = _b64(hmac.new(secret.encode(), payload.encode(), hashlib.sha256).digest())
    return f"{payload}.{sig}"


def verify_state(secret: str, state: str, *, now: Optional[float] = None) -> str:
    """Verify state and return restaurant id."""
    return str(_state_body(secret, state, now=now)["r"])


def _state_body(secret: str, state: str, *, now: Optional[float] = None) -> dict:
    """Parse and verify state."""
    try:
        payload, sig = state.split(".", 1)
        good = _b64(hmac.new(secret.encode(), payload.encode(), hashlib.sha256).digest())
        if not hmac.compare_digest(sig, good):
            raise ValueError("bad signature")
        body = json.loads(base64.urlsafe_b64decode(payload + "=" * (-len(payload) % 4)))
        if body["exp"] < (now or time.time()):
            raise ValueError("expired")
        body["r"]
        return body
    except Exception as exc:
        raise CloverAuthError(f"invalid or expired authorization link ({exc})") from exc


def authorize_url(client_id: str, secret: str, restaurant_id: str, redirect_uri: str,
                  *, sandbox: bool = False, rebind: bool = False) -> str:
    """The signed link an owner opens. Only parameters Clover documents, plus
    ``state``; permissions live on the app in Clover's developer dashboard."""
    query = urllib.parse.urlencode({
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "state": sign_state(secret, restaurant_id, rebind=rebind),
    })
    host = CLOVER_OAUTH_AUTHORIZE_SANDBOX if sandbox else CLOVER_OAUTH_AUTHORIZE_PROD
    return f"{host}?{query}"


# --- storing, locking ---------------------------------------------------------

def _refresh_lock(vault, restaurant_id: str):
    """One refresh at a time per restaurant — across threads and, when the
    vault is a directory, across processes. A single-use refresh token spent
    twice is a merchant who has to approve Cherry again."""
    return exclusive(vault, f"clover-{restaurant_key(restaurant_id)}")


def _store(vault, names: Dict[str, str], pair: dict, *, merchant_id: str = "") -> None:
    """Persist a pair, refresh token first: the one we held died when Clover
    answered, so the new one is the only copy that matters. Retried, because
    losing it costs a restaurant a re-approval."""
    last: Optional[Exception] = None
    for attempt in range(3):
        try:
            vault.put(names["refresh"], pair["refresh_token"])
            break
        except OSError as exc:
            last = exc
            time.sleep(0.05 * (attempt + 1))
    else:
        raise CloverAuthError("could not save the new Clover refresh token; this "
                              "restaurant must approve Cherry again") from last
    vault.put(names["refresh_expires"], pair["refresh_expires_at"].isoformat())
    vault.put(names["expires"], pair["access_expires_at"].isoformat())
    vault.put(names["access"], pair["access_token"])
    if merchant_id:
        vault.put(names["merchant"], merchant_id)


def complete_authorization(client: CloverOAuthClient, vault: SecretVault,
                           state_secret: str, *, state: str, code: str,
                           merchant_id: str, store=None, known_restaurants=None) -> dict:
    """Finish an owner's approval: verify the signed state, exchange the code,
    bind the restaurant to the merchant Clover named on the redirect."""
    body = _state_body(state_secret, state)
    restaurant_id = str(body["r"])

    if known_restaurants is not None and restaurant_id not in known_restaurants:
        raise CloverAuthError("authorization link names an unknown restaurant")
    if not _MERCHANT_ID.match(merchant_id or ""):
        raise CloverAuthError("Clover did not name the merchant that approved Cherry")

    # Prevent replay attacks
    claim = None
    if store is not None and body.get("n"):
        claim = str(body["n"])
        if not store.claim_webhook("oauth-state", claim, restaurant_id):
            raise CloverAuthError("this authorization link was already used")

    try:
        names = secret_names(restaurant_id)
        # Already bound to a different merchant? Check before spending the code.
        try:
            bound = vault.get(names["merchant"])
        except KeyError:
            bound = ""
        if bound and bound != merchant_id and not body.get("rb"):
            raise CloverAuthError(
                "this restaurant is already connected to a different Clover "
                "account; use --rebind if the change is intended")

        pair = client.exchange_code(code)
        with _refresh_lock(vault, restaurant_id):
            _store(vault, names, pair, merchant_id=merchant_id)

        result = {
            "restaurant_id": restaurant_id,
            "merchant_id": merchant_id,
            "expires_at": pair["access_expires_at"].isoformat(),
            "refresh_expires_at": pair["refresh_expires_at"].isoformat(),
        }
        if store is not None:
            store.log_event("clover.oauth_authorized", restaurant_id=restaurant_id,
                            detail={k: v for k, v in result.items() if k != "restaurant_id"})
        return result

    except Exception:
        if claim is not None:
            store.release_webhook("oauth-state", claim)
        raise


# --- reading state, refreshing -------------------------------------------------

def _parse_expiry(value: str) -> Optional[datetime]:
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        return None


def _read(vault, name: str) -> str:
    try:
        return vault.get(name)
    except KeyError:
        return ""


def token_status(vault: SecretVault, restaurant_id: str,
                 *, now: Optional[datetime] = None) -> dict:
    """Where a restaurant's Clover tokens stand.

    ``ok``            access token good for longer than the safety margin
    ``stale_access``  access token expired or about to — normal (they last 30
                      minutes); ``access_token()`` renews it on the next use
    ``due``           the refresh token itself is nearing its end: rotate it
    ``expired``       the refresh token is dead: the owner must approve again
    ``not_authorized`` / ``unknown_expiry``
    """
    now = now or datetime.now(timezone.utc)
    names = secret_names(restaurant_id)
    access, refresh = _read(vault, names["access"]), _read(vault, names["refresh"])
    access_exp = _parse_expiry(_read(vault, names["expires"]))
    refresh_exp = _parse_expiry(_read(vault, names["refresh_expires"]))

    if not access or not refresh:
        state = "not_authorized"
    elif access_exp is None or refresh_exp is None:
        state = "unknown_expiry"
    elif refresh_exp <= now:
        state = "expired"
    elif refresh_exp - now <= REFRESH_WITHIN:
        state = "due"
    elif access_exp - now <= ACCESS_MARGIN:
        state = "stale_access"
    else:
        state = "ok"

    return {
        "restaurant_id": restaurant_id,
        "state": state,
        "access_expires_at": access_exp.isoformat() if access_exp else None,
        "refresh_expires_at": refresh_exp.isoformat() if refresh_exp else None,
        "refresh_days_left": round((refresh_exp - now).total_seconds() / 86400, 1) if refresh_exp else None,
    }


def _refresh_locked(client: CloverOAuthClient, vault, restaurant_id: str, *, store=None) -> dict:
    """Spend the stored refresh token and save its replacement. Caller holds the lock."""
    names = secret_names(restaurant_id)
    old = _read(vault, names["refresh"])
    if not old:
        raise CloverAuthError("this restaurant has not authorized Clover")
    try:
        pair = client.refresh_token(old)
    except CloverAuthError as exc:
        if store is not None:
            store.log_event("clover.oauth_refresh_failed", restaurant_id=restaurant_id,
                            detail={"error": str(exc)[:300]})
        raise
    _store(vault, names, pair)
    if store is not None:
        store.log_event("clover.oauth_refreshed", restaurant_id=restaurant_id,
                        detail={"expires_at": pair["access_expires_at"].isoformat()})
    return pair


def access_token(client: CloverOAuthClient, vault: SecretVault, restaurant_id: str, *,
                 now: Optional[datetime] = None, margin: timedelta = ACCESS_MARGIN,
                 store=None) -> str:
    """A Clover access token that is good right now — the call every Clover
    request goes through. Refreshes (once, however many callers ask at the
    same moment) when the token is within ``margin`` of its 30-minute end."""
    now = now or datetime.now(timezone.utc)
    names = secret_names(restaurant_id)

    def fresh() -> str:
        token = _read(vault, names["access"])
        expiry = _parse_expiry(_read(vault, names["expires"]))
        return token if token and expiry and expiry - now > margin else ""

    token = fresh()
    if token:
        return token
    with _refresh_lock(vault, restaurant_id):
        token = fresh()                      # someone else may have just refreshed
        if token:
            return token
        status = token_status(vault, restaurant_id, now=now)
        if status["state"] == "not_authorized":
            raise CloverAuthError("this restaurant has not authorized Clover")
        if status["state"] == "expired":
            raise CloverAuthError("the Clover authorization has expired; the owner "
                                  "must approve Cherry again")
        return str(_refresh_locked(client, vault, restaurant_id, store=store)["access_token"])


def refresh_merchants(client: CloverOAuthClient, vault: SecretVault,
                      merchants: Iterable[CloverMerchant], *, store=None) -> dict:
    """Rotate the given merchants' tokens now (each under its lock)."""
    counts = {"checked": 0, "refreshed": 0, "failed": 0}
    for merchant in merchants:
        counts["checked"] += 1
        try:
            with _refresh_lock(vault, merchant.restaurant_id):
                _refresh_locked(client, vault, merchant.restaurant_id, store=store)
            counts["refreshed"] += 1
        except Exception as exc:                      # noqa: BLE001
            counts["failed"] += 1
            if store is not None and not isinstance(exc, CloverAuthError):
                store.log_event("clover.oauth_refresh_failed", restaurant_id=merchant.restaurant_id,
                                detail={"error": str(exc)[:300]})
    return counts


def refresh_due(client: CloverOAuthClient, vault: SecretVault,
                restaurant_ids: Iterable[str], *, store=None,
                now: Optional[datetime] = None, force: bool = False) -> dict:
    """Rotate refresh tokens that are nearing their own end (or of unknown age).
    A merely stale access token is left alone: refreshing spends the single-use
    refresh token, and ``access_token()`` does it on demand."""
    due, statuses = [], []
    for rid in restaurant_ids:
        status = token_status(vault, rid, now=now)
        statuses.append(status)
        if status["state"] in ("not_authorized", "expired"):
            continue
        if force or status["state"] in ("due", "unknown_expiry"):
            due.append(merchant_for(rid))

    counts = refresh_merchants(client, vault, due, store=store)
    counts["not_authorized"] = [s["restaurant_id"] for s in statuses if s["state"] == "not_authorized"]
    counts["reauthorize"] = [s["restaurant_id"] for s in statuses if s["state"] == "expired"]
    counts["skipped_ok"] = len(statuses) - len(due) - len(counts["not_authorized"]) - len(counts["reauthorize"])
    return counts


def _client_from_env(sandbox: bool) -> CloverOAuthClient:
    return CloverOAuthClient(
        os.environ.get("CLOVER_CLIENT_ID", ""),
        os.environ.get("CLOVER_CLIENT_SECRET", ""),
        sandbox=sandbox
    )


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--sandbox", action="store_true",
                        default=os.environ.get("CHERRY_CLOVER_SANDBOX") == "1")
    parser.add_argument("--redirect-uri",
                        default=os.environ.get("CLOVER_REDIRECT_URI",
                                               "https://your-server.com/v1/oauth/clover/callback"))
    sub = parser.add_subparsers(dest="command", required=True)

    link = sub.add_parser("authorize-url", help="print authorization link")
    link.add_argument("--restaurant", required=True)
    link.add_argument("--rebind", action="store_true")

    for name in ("status", "refresh"):
        p = sub.add_parser(name)
        p.add_argument("--restaurant", action="append", required=True)
        if name == "refresh":
            p.add_argument("--force", action="store_true")

    args = parser.parse_args(argv)

    vault = default_vault()
    if vault is None:
        print(json.dumps({"ok": False, "error": "CHERRY_SECRET_DIR is not set"}))
        return 1

    try:
        if args.command == "authorize-url":
            client = _client_from_env(args.sandbox)
            secret = os.environ.get("CHERRY_OAUTH_STATE_SECRET", "")
            url = authorize_url(client.client_id, secret, args.restaurant,
                                args.redirect_uri, sandbox=args.sandbox, rebind=args.rebind)
            print(url)
            return 0

        if args.command == "status":
            statuses = [token_status(vault, r) for r in args.restaurant]
            print(json.dumps(statuses, indent=2))
            return 0 if all(s["state"] in ("ok", "stale_access") for s in statuses) else 3

        result = refresh_due(_client_from_env(args.sandbox), vault, args.restaurant,
                             force=args.force)
        print(json.dumps(result, indent=2))
        return 0 if not (result["failed"] or result["not_authorized"] or result["reauthorize"]) else 3

    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}))
        return 1


if __name__ == "__main__":
    sys.exit(main())
