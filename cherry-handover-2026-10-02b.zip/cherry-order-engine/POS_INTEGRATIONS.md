> **SUPERSEDED 2026-10-02 — read `POS_INTEGRATION_PLAN.md` instead.** This
> overview was written before the vendor-doc research pass and its status
> marks are wrong: nothing is "Fully Implemented" at the integration level.
> What is built is the checkout-handoff launch (see `DEPLOYMENT_STATUS.md`);
> Square OAuth, Clover and Toast are built but need external proof per
> location. Kept for background, not authority.

# POS Integrations for Cherry

Cherry supports multiple POS systems for restaurant order integration. Each system has different authentication flows and requirements.

## Supported POS Systems

### 1. Square ✅ (Fully Implemented)
- **Best for**: Small to medium restaurants, cafes, quick service
- **Market share**: High among independents
- **Authentication**: OAuth 2.0 authorization code flow (per-restaurant)
- **Documentation**: `square_oauth.py`

**Setup:**
```bash
# Get Square OAuth credentials from Square Developer Portal
export SQUARE_OAUTH_CLIENT_ID="your-client-id"
export SQUARE_OAUTH_CLIENT_SECRET="your-client-secret"

# Authorize a restaurant
python3 square_oauth.py authorize-url --restaurant bun-n-run-ferndale
# Send the printed link to the restaurant owner

# Check status
python3 square_oauth.py status --restaurant bun-n-run-ferndale

# Refresh tokens (run daily via cron)
python3 square_oauth.py refresh --restaurant bun-n-run-ferndale
```

---

### 2. Toast POS ✅ (New - Fully Implemented)
- **Best for**: Full-service restaurants, table service, Detroit market leader
- **Market share**: #1 in Michigan independents (1,819 restaurants, 94% independent)
- **Authentication**: OAuth 2.0 client-credentials (partner model)
- **Documentation**: `toast_oauth.py`

**Key Difference**: Toast uses a partner model - single credentials for all restaurants, no per-restaurant OAuth needed.

**Setup:**
```bash
# Register as a Toast partner to get credentials
export TOAST_CLIENT_ID="your-client-id"
export TOAST_CLIENT_SECRET="your-client-secret"

# Authenticate once (shared across all restaurants)
python3 toast_oauth.py authenticate

# Check status
python3 toast_oauth.py status

# Do the credentials still work? (a health check, not what keeps the token alive)
python3 toast_oauth.py refresh
```

Toast has no refresh token: a new token is a new login. Toast returns the same
token until the last minute of its life, so whatever calls Toast must use
`toast_oauth.access_token(client, vault)` (logs in only when needed, once for
all workers) and `access_token(..., force=True)` after a 401. Written against
Toast's docs; the API hosts (`ws-api.toasttab.com`, sandbox
`ws-sandbox-api.eng.toasttab.com`) are overridable with `TOAST_API_BASE`.
Not yet proved against a live Toast account.

**Why Toast for Detroit:**
- 1,819 restaurants in Michigan use Toast
- 119 in Detroit alone
- 94% are independent (not chains)
- Top cuisines: Italian, Mexican, Mediterranean
- Partner model means easier onboarding

---

### 3. Clover POS ✅ (New - Fully Implemented)
- **Best for**: Single-location independents, cost-conscious restaurants
- **Market share**: Strong in Detroit through local resellers
- **Authentication**: OAuth 2.0 authorization code flow (per-restaurant)
- **Documentation**: `clover_oauth.py`

**Setup:**
```bash
# Register a Clover app to get credentials
export CLOVER_CLIENT_ID="your-client-id"
export CLOVER_CLIENT_SECRET="your-client-secret"
export CLOVER_REDIRECT_URI="https://your-server.com/v1/oauth/clover/callback"

# Authorize a restaurant
python3 clover_oauth.py authorize-url --restaurant bun-n-run-ferndale
# Send the printed link to the restaurant owner

# Check status
python3 clover_oauth.py status --restaurant bun-n-run-ferndale

# Rotate refresh tokens that are nearing their own end (weekly is plenty)
python3 clover_oauth.py refresh --restaurant bun-n-run-ferndale
```

Clover access tokens last **30 minutes** and the refresh token is **single use**,
so a scheduled job cannot keep a restaurant connected: whatever calls Clover must
use `clover_oauth.access_token(client, vault, restaurant_id)`, which renews on use
under a lock. The merchant id arrives on the redirect (`merchant_id=`), the token
exchange is a JSON POST with no `grant_type`, and the refresh call sends no client
secret — all per Clover's docs, now what the code does. Not yet proved against a
live Clover sandbox; in particular that the authorize page echoes our `state`.

**Why Clover for Detroit:**
- Open architecture (processing is shoppable)
- Lower total cost for independents
- Month-to-month terms available
- Strong local support through resellers like BSV Solution

---

## Comparison Table

| Feature | Square | Toast | Clover |
|---------|--------|-------|--------|
| **Authentication** | Per-restaurant OAuth | Partner credentials | Per-restaurant OAuth |
| **Setup Difficulty** | Medium | Easy | Medium |
| **Cost for Restaurant** | Per-transaction | Monthly + processing | Flexible |
| **Detroit Market Share** | High | #1 (1,819 locations) | Strong |
| **Independent Share** | High | 94% | High |
| **Onboarding Time** | Per restaurant | One-time | Per restaurant |
| **Best For** | Small/medium | Full-service | Cost-conscious |

---

## Detroit Market Strategy

### Primary Target: Toast POS
- **Why**: Largest independent POS in Detroit (119 locations)
- **Approach**: Register as Toast partner, get partner credentials
- **Onboarding**: One-time setup, add restaurants via Toast platform
- **Sales Pitch**: "We're Toast-certified, integrate in minutes"

### Secondary Target: Clover POS
- **Why**: Popular with cost-conscious independents
- **Approach**: Create Clover app, merchants install from App Market
- **Onboarding**: Per-restaurant authorization (similar to Square)
- **Sales Pitch**: "Keep your low Clover rates, add voice ordering"

### Existing: Square POS
- **Why**: Already integrated, easy migration path
- **Approach**: Continue supporting Square users
- **Onboarding**: Existing flow works perfectly

---

## Environment Variables

Add these to `deploy/cherry.env.example`:

```bash
# Toast POS
TOAST_CLIENT_ID=
TOAST_CLIENT_SECRET=
CHERRY_TOAST_SANDBOX=1  # Set for testing

# Clover POS
CLOVER_CLIENT_ID=
CLOVER_CLIENT_SECRET=
CLOVER_REDIRECT_URI=https://your-server.com/v1/oauth/clover/callback
CHERRY_CLOVER_SANDBOX=1  # Set for testing
```

---

## Token Refresh

Each provider ages its tokens differently, so the schedule differs:

```bash
# Square: tokens last ~30 days; refresh the ones nearing the end (daily is right)
0 2 * * * cd /path/to/cherry-order-engine && source .venv/bin/activate && python3 square_oauth.py refresh --restaurant bun-n-run-ferndale
# Toast: a health check that the credentials still work. The token itself is renewed on use.
0 2 * * * cd /path/to/cherry-order-engine && source .venv/bin/activate && python3 toast_oauth.py refresh
# Clover: rotates a refresh token nearing its end (weekly is plenty). Access tokens (30 min) are renewed on use.
0 3 * * 1 cd /path/to/cherry-order-engine && source .venv/bin/activate && python3 clover_oauth.py refresh --restaurant bun-n-run-ferndale
```

Exit code 3 from any of these means a restaurant needs a human (not authorized, or
authorization expired and the owner must approve again): wire it to the alert phone.

---

## Testing

```bash
# Test Toast OAuth
python3 test_toast_oauth.py

# Test Clover OAuth
python3 test_clover_oauth.py

# Test Square OAuth (existing)
python3 test_square_oauth.py
```

---

## Next Steps

1. **Register as Toast Partner**
   - Contact Toast integrations team
   - Get partner credentials
   - Test in sandbox environment

2. **Create Clover App**
   - Register in Clover Developer Dashboard
   - Configure OAuth settings
   - Set redirect URI

3. **Update Production Jobs**
   - Add Toast token refresh to `production_jobs.py`
   - Add Clover token refresh to `production_jobs.py`

4. **Sales Materials**
   - "Toast-certified" badge for marketing
   - "Works with your Clover" for existing users
   - Case studies from early adopters

---

## Security Notes

- All tokens stored in vault (`vault.py`), never in database
- Tokens never logged or printed in production
- Use sandbox environments for testing
- Rotate credentials if compromised
- Monitor token refresh failures via alerts
