#!/usr/bin/env python3
"""
Tests for POS catalog sync.

The thing these exist to prove: the sync is CONSERVATIVE. It must follow
prices and availability automatically, because a stale price is Cherry lying
on a live call — and it must never silently change what Lily ASKS, because a
wrong question is worse than a stale price.
"""

from __future__ import annotations

import io
import json
import traceback
import urllib.error
from pathlib import Path
from typing import Any, Dict, List

import menu_schema as ms
from catalog_sync import (AUTO, BLOCKED, REVIEW, SquareCatalog, apply_auto,
                          diff_catalog)
from order_store import OrderStore

MENUS = Path(__file__).parent / "menus"
_passed = _failed = 0


def check(name: str, cond: bool, detail: str = "") -> None:
    global _passed, _failed
    if cond:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


class _Resp(io.BytesIO):
    status = 200

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


class FakeSquare:
    """Serves a catalog, records the requests."""

    def __init__(self, objects: List[Dict[str, Any]], pages: int = 1):
        self.objects = objects
        self.requests: List[str] = []
        self.pages = pages
        self._served = 0

    def __call__(self, req, timeout=None):
        self.requests.append(req.full_url)
        self._served += 1
        body: Dict[str, Any] = {"objects": self.objects}
        if self._served < self.pages:
            body["cursor"] = f"page-{self._served}"
        return _Resp(json.dumps(body).encode())


def sq_item(oid: str, name: str, price: int, *, var_id: str = None,
            variation: str = "Regular", deleted: bool = False) -> Dict:
    return {
        "type": "ITEM", "id": oid, "is_deleted": deleted,
        "item_data": {"name": name, "variations": [{
            "id": var_id or f"{oid}-var",
            "item_variation_data": {
                "name": variation,
                "price_money": {"amount": price, "currency": "USD"},
                "present_at_all_locations": True}}]}}


def cfg():
    return ms.load_yaml(MENUS / "bun-n-run-ferndale.yaml")


def catalog_matching(c, **overrides) -> List[Dict[str, Any]]:
    """A POS catalog that mirrors our menu, with optional differences."""
    out = []
    for i in c.items:
        price = overrides.get(i.id, i.base_price_cents)
        if price is None:
            continue                      # simulate "not in the POS"
        out.append(sq_item(f"sq-{i.id}", i.name, price))
    return out


# --- reading ---------------------------------------------------------------


def t_catalog_read_flattens_variations() -> None:
    http = FakeSquare([sq_item("i1", "Cheeseburger", 699),
                       sq_item("i2", "Fries", 399)])
    cat = SquareCatalog("tok", "L1", opener=http)
    items = cat.items()
    check("both items read", len(items) == 2, str(len(items)))
    check("price is integer cents", items[0]["price_cents"] == 699)
    check("catalog id is the VARIATION id, not the item id",
          items[0]["catalog_object_id"] == "i1-var",
          items[0]["catalog_object_id"])
    check("uses the pinned API version",
          "catalog/list" in http.requests[0], http.requests[0])


def t_catalog_read_pages() -> None:
    http = FakeSquare([sq_item("i1", "Cheeseburger", 699)], pages=3)
    items = SquareCatalog("tok", "L1", opener=http).items()
    check("follows the cursor", len(http.requests) == 3, str(len(http.requests)))
    check("accumulates every page", len(items) == 3, str(len(items)))


def t_items_not_at_this_location_are_skipped() -> None:
    obj = sq_item("i1", "Cheeseburger", 699)
    obj["item_data"]["variations"][0]["item_variation_data"].update(
        {"present_at_all_locations": False, "present_at_location_ids": ["OTHER"]})
    items = SquareCatalog("tok", "L1", opener=FakeSquare([obj])).items()
    check("an item from another location is not synced", items == [], str(items))


def t_a_catalog_error_is_loud() -> None:
    def boom(req, timeout=None):
        raise urllib.error.HTTPError("u", 403, "Forbidden", {},
                                     io.BytesIO(b'{"errors":[{"code":"INSUFFICIENT_SCOPES"}]}'))
    try:
        SquareCatalog("tok", "L1", opener=boom).items()
    except RuntimeError as exc:
        check("a scope error names itself", "403" in str(exc), str(exc))
    else:
        check("a scope error raises", False, "silent")


# --- the diff, which is the whole point ------------------------------------


def t_identical_catalog_produces_no_changes() -> None:
    c = cfg()
    d = diff_catalog(c, [x for o in catalog_matching(c)
                         for x in SquareCatalog("t", "L", opener=FakeSquare([o])).items()])
    check("no changes when nothing changed", not d.changes,
          "; ".join(str(x) for x in d.changes[:3]))


def _read(objs):
    return SquareCatalog("t", "L", opener=FakeSquare(objs)).items()


def t_a_price_change_is_applied_automatically() -> None:
    """The most common change, and the one that makes Cherry wrong on a call."""
    c = cfg()
    d = diff_catalog(c, _read(catalog_matching(c, single_cheeseburger=999)))
    price = [x for x in d.changes if x.kind == "price"]
    check("the price change is found", len(price) == 1, str(d.changes))
    check("it is automatic", price[0].level == AUTO, price[0].level)
    check("old and new are both recorded",
          price[0].old == 899 and price[0].new == 999,
          f"{price[0].old}->{price[0].new}")


def t_availability_follows_the_pos_both_ways() -> None:
    c = cfg()
    objs = catalog_matching(c)
    for o in objs:
        if o["item_data"]["name"] == "French Fries":
            o["is_deleted"] = True
    d = diff_catalog(c, _read(objs))
    av = [x for x in d.changes if x.kind == "availability"]
    check("an unavailable item is detected", len(av) == 1, str(d.changes))
    check("and it is safe to apply", av[0].level == AUTO)
    check("direction is right", av[0].new is False)


def t_a_new_pos_item_is_never_sold_without_review() -> None:
    """Lily cannot sell something whose modifier groups nobody has modelled."""
    c = cfg()
    objs = catalog_matching(c) + [sq_item("new1", "Loaded Nachos", 899)]
    d = diff_catalog(c, _read(objs))
    new = [x for x in d.changes if x.kind == "new_item"]
    check("the new item is noticed", len(new) == 1, str(d.changes))
    check("but NOT applied automatically", new[0].level == REVIEW, new[0].level)
    check("and it says why", "modifier" in new[0].what.lower(), new[0].what)
    check("it is not in the auto list",
          not any(x.kind == "new_item" for x in d.auto))


def t_a_missing_item_is_never_deleted_automatically() -> None:
    """Square hides items for many innocent reasons."""
    c = cfg()
    objs = [o for o in catalog_matching(c)
            if o["item_data"]["name"] != "Fresh Shake"]
    d = diff_catalog(c, _read(objs))
    rm = [x for x in d.changes if x.kind == "removed"]
    check("the absence is noticed", len(rm) == 1, str(d.changes))
    check("it is BLOCKED, not merely review", rm[0].level == BLOCKED, rm[0].level)
    check("it never appears in auto", not d.auto or
          all(x.kind != "removed" for x in d.auto))
    check("it explains the ambiguity", "seasonal" in rm[0].what.lower())


def t_a_rename_is_flagged_because_aliases_may_break() -> None:
    c = cfg()
    objs = catalog_matching(c)
    for o in objs:
        if o["item_data"]["name"] == "Wild Fries":
            o["item_data"]["name"] = "Loaded Wild Fries"
    d = diff_catalog(c, _read(objs))
    ren = [x for x in d.changes if x.kind == "rename"]
    check("the rename is found", len(ren) == 1, str(d.changes))
    check("it needs review, not auto", ren[0].level == REVIEW)
    check("it warns about aliases", "alias" in ren[0].what.lower())


def t_matching_survives_pos_name_noise() -> None:
    """Square names carry numbers and parentheticals ours do not.

    Fed a FULL catalog (not one item), so the removed-item noise does not
    drown the signal — that is also how the real sync runs.
    """
    c = ms.load_yaml(MENUS / "pink-garlic-shelby.yaml")
    target = next(i for i in c.items if i.name == "Butter Chicken (Creamy)")

    objs = []
    for i in c.items:
        # Re-dress every name the way Square writes them: a leading number.
        price = i.base_price_cents + (100 if i.id == target.id else 0)
        objs.append(sq_item(f"sq-{i.id}", f"29. {i.name}", price))

    d = diff_catalog(c, _read(objs))
    price = [x for x in d.changes if x.kind == "price" and x.item_id == target.id]
    check("a noisy POS name still matches our item", len(price) == 1,
          str([str(x) for x in d.changes[:4]]))
    check("and it reads the new price",
          price and price[0].new == target.base_price_cents + 100)
    check("no phantom new items from the noise",
          not [x for x in d.changes if x.kind == "new_item"],
          str([str(x) for x in d.changes if x.kind == "new_item"][:2]))
    # Pink Garlic has two different dishes that normalise to the same name
    # ("Pink Garlic Chicken" the $6.99 starter and the $13.99 entree), so
    # exactly one of them cannot be matched by name alone and is correctly
    # queued for a human rather than guessed at.
    removed = [x for x in d.changes if x.kind == "removed"]
    check("at most the known duplicate-name dish is unmatched",
          len(removed) <= 1, str([str(x) for x in removed][:3]))
    check("and it is BLOCKED rather than auto-applied",
          all(x.level == BLOCKED for x in removed))


def t_variable_price_items_are_ignored() -> None:
    c = cfg()
    obj = sq_item("v1", "Catering Tray", 0)
    obj["item_data"]["variations"][0]["item_variation_data"]["price_money"] = {}
    d = diff_catalog(c, _read(catalog_matching(c) + [obj]))
    check("an item with no price is not synced",
          not any("Catering" in x.what for x in d.changes),
          str([str(x) for x in d.changes if "Catering" in x.what]))


def t_a_sized_item_does_not_get_a_flat_price_applied() -> None:
    """An item with sizes has no single base price to overwrite."""
    c = ms.load_yaml(MENUS / "chengs-sterling-heights.yaml")
    sized = [i for i in c.items if i.has_sizes]
    if not sized:
        # No sized items on this menu; the guard is still exercised by the
        # rename test, so skip rather than fail.
        check("sized-item guard: no sized items on this menu to test", True)
        return
    objs = [sq_item("s1", sized[0].name, 12345)]
    d = diff_catalog(c, _read(objs))
    check("no flat price change is proposed for a sized item",
          not any(x.kind == "price" and x.item_id == sized[0].id
                  for x in d.changes),
          str([str(x) for x in d.changes[:3]]))


# --- applying --------------------------------------------------------------


def t_apply_auto_only_touches_availability() -> None:
    c = cfg()
    store = OrderStore.sqlite()
    store.upsert_restaurant(c.id, c.name, c.cuisine, active=True)
    store.publish_menu(c.id, (MENUS / "bun-n-run-ferndale.yaml").read_text(),
                       item_count=len(c.items))

    objs = catalog_matching(c, single_cheeseburger=999)
    for o in objs:
        if o["item_data"]["name"] == "French Fries":
            o["is_deleted"] = True
    d = diff_catalog(c, _read(objs))

    applied = apply_auto(store, c.id, d)
    check("the 86 was applied", applied["availability"] == 1, str(applied))
    check("the price change is counted but not silently published",
          applied["price"] == 1, str(applied))

    off = store.availability_overrides(c.id)
    check("the item really is 86'd in the store",
          "french_fries" in off["item"], str(off))
    check("the change is in the audit log",
          any(e["kind"] == "catalog.synced" for e in store.events()))

    live, _ = store.load_live_config(c.id)
    check("the live menu still has the OLD price until republished",
          live.item("single_cheeseburger").base_price_cents == 899,
          str(live.item("single_cheeseburger").base_price_cents))


def t_review_changes_are_never_applied() -> None:
    c = cfg()
    store = OrderStore.sqlite()
    store.upsert_restaurant(c.id, c.name, c.cuisine, active=True)
    objs = [o for o in catalog_matching(c)
            if o["item_data"]["name"] != "Fresh Shake"]
    objs.append(sq_item("new1", "Nachos", 899))
    d = diff_catalog(c, _read(objs))
    applied = apply_auto(store, c.id, d)
    check("nothing from the review list was applied",
          applied["availability"] == 0 and applied["price"] == 0, str(applied))
    check("both items are queued for a human", len(d.review) >= 2,
          str([str(x) for x in d.review]))


def t_summary_reads_like_a_human_wrote_it() -> None:
    c = cfg()
    objs = catalog_matching(c, cheeseburger=799)
    objs.append(sq_item("new1", "Nachos", 899))
    d = diff_catalog(c, _read(objs))
    s = d.summary()
    check("summary counts auto and review", "auto" in s and "review" in s, s)
    check("empty diff says so", diff_catalog(c, _read(catalog_matching(c)))
          .summary() == "no changes")


def main() -> int:
    for name, fn in sorted(globals().items()):
        if not name.startswith("t_"):
            continue
        try:
            fn()
        except Exception:
            global _failed
            _failed += 1
            print(f"\n--- FAIL {name}")
            traceback.print_exc()
    print(f"\n{_passed} passed, {_failed} failed (POS catalog sync)")
    return 1 if _failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
