#!/usr/bin/env python3
"""Credential-free Inworld/Telnyx-to-Cherry bridge.

Inworld classifies intent; this bridge forwards the exact tool call to Cherry
and returns Cherry's ``say`` text unchanged.  The surrounding telephony worker
must send that text directly to TTS.  It may also provide ``handoff`` to
transfer a failed call to the restaurant's human number.
"""

from __future__ import annotations

import asyncio
import collections
import json
import logging
import threading
from typing import Any, Awaitable, Callable, Dict, List, Optional, Protocol, Tuple
import urllib.error
import urllib.parse
import urllib.request

log = logging.getLogger("cherry.inworld")

DEAD = ("I'm having trouble with our ordering system. Let me connect you "
        "with the restaurant.")

SYSTEM_PROMPT = """You are Lily, the host who answers the phone for a restaurant: warm,
unhurried and genuinely glad the caller rang, the way the best person at the
front of the house sounds. Greet people like guests, use their name once you
have it, say please and thank you, and keep sentences short and friendly. A
moment of small talk is welcome. But everything about food — dishes, prices,
totals, what is in a dish — comes only from the tools, never from you.
You take phone orders and reservation requests.

You do not know the menu. Never state a dish, price, size, or total from your
own knowledge. Pick the matching tool and pass the caller's words verbatim.
If Cherry's previous reply asked the caller a question — a required size,
side or drink, a choice between matching items, a name, or allergies — and the
caller's next words answer it, use `answer` (or the tool named below), not
`add_item`. If instead the caller names a NEW item or asks for something else,
ignore the open question and use the tool that fits (`add_item` for a new
dish); Cherry will ask the question again. If the caller is finished changing
an item, use `confirm_mods`. When a tool returns that it could not find
something, say so and ask again; never guess. Modifiers apply to one item, not
a whole line: for "three tacos, one with guac", call `split_line` first, then
`add_modifier` on the split.

Call each tool ONCE per thing the caller says. If a tool reports a problem
(`ok` is false), say its text and wait for the caller; do not call it again
with different words unless `retryable` is true or the caller says something
new. Never repeat a call that already worked.

If the caller says they want to order but names nothing yet ("I'd like to place
an order", "can I order for pickup"), call `add_item` with their words: Cherry
will welcome them and ask what they would like. If they ask for "the usual" or
"same as last time", call `reorder_last`. If they give a name, call `set_name`.
Questions about hours, closing time, wait time, delivery or the address go to
`store_info` — never answer them from memory. If the caller wants the checkout
link texted to a different number, call `set_text_number` before
`ready_to_place`.

Questions about allergies, ingredients or diets — "does it have nuts", "is it
vegan", "I'm allergic to peanuts" — go to `item_info`. Never answer them from
your own knowledge, and never tell a caller a dish is safe or free of anything.
Like a good waiter, note allergies: if the caller mentions one at any point,
call `note_allergy` with their words at once. When `ready_to_place` comes back
asking for a name and allergies, ask exactly that, then call `set_name` and
`note_allergy` with the caller's answers — even a plain "no" — and call
`ready_to_place` again.

If the caller speaks another language, understand it and pass their words
exactly as spoken, dish names and numbers included: Cherry understands common
Spanish, Arabic and Hindi/Urdu food words, so do not translate them yourself.
If the caller asks you to wait ("hold on", "let me ask my wife"), say a short,
kind "Of course, take your time" and wait; do not hang up. If the caller asks
what you recommend or what is popular, do not choose dishes from your own
knowledge: offer to go through the menu (`search_menu`) and let them choose.
Never end the call yourself; call `ready_to_place` first.
For reservations, collect the name, party size, exact date and time before
calling `request_reservation`. Say it is a request until the restaurant
confirms it. Use `cancel_reservation` only with the guest's confirmation code.
Speak every tool's returned text exactly, without adding or changing words."""

Handoff = Callable[[str, str, str], Awaitable[None]]

_DIGITS = "zero one two three four five six seven eight nine".split()


def speakable_phone(e164: str) -> str:
    """'+15869805199' -> 'five eight six, nine eight zero, five one nine nine'."""
    digits = [d for d in e164 if d.isdigit()]
    if len(digits) == 11 and digits[0] == "1":
        digits = digits[1:]
    if len(digits) != 10:
        return " ".join(_DIGITS[int(d)] for d in digits)
    words = [_DIGITS[int(d)] for d in digits]
    return ", ".join(" ".join(words[a:b]) for a, b in ((0, 3), (3, 6), (6, 10)))


def transfer_failed_say(direct_line: str = "") -> str:
    if direct_line:
        return ("I'm sorry, I could not transfer you. Please call the "
                f"restaurant directly at {speakable_phone(direct_line)}.")
    # No direct line is known. "Call the restaurant again" is wrong here: in a
    # forwarded-number deployment the restaurant's published number is the one
    # that brought this caller to Cherry, so redialling it reaches us again.
    return ("I'm sorry, I could not transfer you and I can't take your order "
            "right now. Please try again in a few minutes.")


def _staff_needed(done: Dict[str, Any]) -> bool:
    """True when Cherry placed an order but nothing reached the restaurant or
    the caller: checkout link not delivered and no ticket sent."""
    if not done.get("placed"):
        return False
    return not (done.get("checkout_handed_off") or done.get("awaiting_payment")
                or done.get("delivered"))


#: Spoken when Cherry rejects ONE request as malformed (a hallucinated tool
#: name, say) rather than being unavailable: ask again, do not transfer.
RETRY_LINE = "Sorry, I didn't catch that — could you say it again?"


class CherryHTTPError(RuntimeError):
    """Cherry answered, with an error status."""

    def __init__(self, status: int, message: str) -> None:
        super().__init__(message)
        self.status = status


class Transport(Protocol):
    async def request(self, method: str, url: str, headers: Dict[str, str],
                      body: Optional[Dict[str, Any]], timeout: float
                      ) -> Tuple[int, Any]: ...


class UrlLibTransport:
    """Small standard-library HTTP transport; no voice SDK dependency."""

    async def request(self, method: str, url: str, headers: Dict[str, str],
                      body: Optional[Dict[str, Any]], timeout: float
                      ) -> Tuple[int, Any]:
        def send() -> Tuple[int, Any]:
            raw = json.dumps(body).encode() if body is not None else None
            req_headers = dict(headers)
            if raw is not None:
                req_headers["Content-Type"] = "application/json"
            req = urllib.request.Request(url, data=raw, method=method,
                                         headers=req_headers)
            try:
                with urllib.request.urlopen(req, timeout=timeout) as response:
                    status, payload = response.status, response.read()
            except urllib.error.HTTPError as exc:
                status, payload = exc.code, exc.read()
            try:
                return status, json.loads(payload)
            except (TypeError, ValueError):
                return status, {"error": payload.decode("utf-8", "replace")}

        return await asyncio.to_thread(send)


class CherryBridge:
    """One bridge process can safely serve calls for every restaurant."""

    def __init__(self, base_url: str, api_key: str, *, timeout: float = 8.0,
                 finish_timeout: float = 45.0,
                 transport: Optional[Transport] = None,
                 handoff: Optional[Handoff] = None) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout
        # finish() books the order, creates and verifies the Square checkout
        # and texts the link — several outbound calls on Cherry's side. Giving
        # up on it at the normal tool timeout transfers a caller whose order
        # is in fact going through (and the link still arrives).
        self.finish_timeout = finish_timeout
        self.transport = transport or UrlLibTransport()
        self.handoff = handoff
        self._tasks: "set[asyncio.Task]" = set()    # briefings in flight
        # Long-lived process: every one of these is bounded so a month of
        # calls cannot exhaust memory.
        self.spoken_log = collections.deque(maxlen=2000)
        self._dialled: "collections.OrderedDict[str, str]" = collections.OrderedDict()
        self._handed_off: "collections.OrderedDict[str, bool]" = collections.OrderedDict()
        self._finished: "collections.OrderedDict[str, str]" = collections.OrderedDict()
        # One finish per call at a time. The gateway runs each request on its
        # own thread and event loop, so a worker retrying finish while the
        # first is still waiting on the checkout would otherwise start a
        # second one.
        self._finish_guard = threading.Lock()
        self._finish_locks: Dict[str, threading.Lock] = {}

    @staticmethod
    def _cid(call_id: str) -> str:
        """A call id as one URL path segment. Provider ids can hold '/', '?',
        '#', ':' or spaces, any of which would otherwise re-route the request."""
        return urllib.parse.quote(call_id, safe="")

    async def _request(self, method: str, path: str,
                       body: Optional[Dict[str, Any]] = None,
                       timeout: Optional[float] = None) -> Dict[str, Any]:
        status, payload = await self.transport.request(
            method, f"{self.base_url}{path}",
            {"X-Cherry-Key": self.api_key}, body,
            self.timeout if timeout is None else timeout)
        if not isinstance(payload, dict):
            raise RuntimeError("Cherry returned a non-object response")
        if status >= 400:
            raise CherryHTTPError(
                status, str(payload.get("say") or payload.get("error")
                            or f"Cherry returned HTTP {status}"))
        return payload

    def _brief_staff(self, call_id: str, reason: str) -> None:
        """Tell the server a person is taking over, so it can text staff who is
        calling and what is in the cart. Fire and forget: it must never delay,
        block or break the transfer (and when the transfer is happening
        BECAUSE the server is down, it simply fails quietly)."""
        async def go() -> None:
            try:
                await self._request("POST", f"/v1/calls/{self._cid(call_id)}/handoff",
                                    {"reason": reason}, timeout=4.0)
            except Exception:                                  # noqa: BLE001
                log.info("handoff briefing not sent for %s", call_id)
        try:
            task = asyncio.get_running_loop().create_task(go())
            self._tasks.add(task)
            task.add_done_callback(self._tasks.discard)
        except RuntimeError:                                   # no running loop
            pass

    async def _fail(self, call_id: str, reason: str) -> str:
        log.error("voice bridge failure on %s: %s", call_id, reason)
        if self.handoff is not None and call_id not in self._handed_off:
            self._remember(self._handed_off, call_id, True)
            self._brief_staff(call_id, reason)
            try:
                await self.handoff(call_id, self._dialled.get(call_id, ""), reason)
            except Exception:  # noqa: BLE001
                log.exception("human handoff failed on %s", call_id)
                # A transfer that did not happen must not be remembered as
                # one: the caller may ask again, and the next attempt has to
                # really try instead of repeating "I'll connect you".
                self._handed_off.pop(call_id, None)
                return transfer_failed_say(self._direct_line(call_id))
        return DEAD

    @staticmethod
    def _remember(store: "collections.OrderedDict", key: str, value: Any,
                  limit: int = 5000) -> None:
        store[key] = value
        while len(store) > limit:
            store.popitem(last=False)

    def _direct_line(self, call_id: str) -> str:
        lookup = getattr(self.handoff, "fallback_for", None)
        return lookup(self._dialled.get(call_id, "")) if lookup else ""

    async def request_handoff(self, call_id: str, dialled: str = "") -> str:
        """Transfer an active caller who asks for a human, at most once.

        ``dialled`` lets the caller of this method supply the number the guest
        rang when this process has no record of the call (the gateway was
        restarted mid-call). Without either, the call cannot be routed."""
        if call_id not in self._dialled and dialled:
            self._remember(self._dialled, call_id, dialled)
        if call_id not in self._dialled:
            raise LookupError("unknown active call")
        if self.handoff is None:
            raise RuntimeError("human handoff is not configured")
        if call_id not in self._handed_off:
            self._remember(self._handed_off, call_id, True)
            self._brief_staff(call_id, "caller asked for a person")
            try:
                await self.handoff(call_id, self._dialled[call_id],
                                   "caller requested a person")
            except Exception:
                self._handed_off.pop(call_id, None)
                log.exception("requested human handoff failed on %s", call_id)
                # Never leave the worker with a bare error: tell the caller
                # how to reach the restaurant themselves.
                return transfer_failed_say(self._direct_line(call_id))
        return "I'll connect you with the restaurant now."

    async def start(self, call_id: str, *, dialled: str,
                    caller: str = "") -> str:
        self._remember(self._dialled, call_id, dialled)
        try:
            env = await self._request("POST", "/v1/calls", {
                "call_id": call_id, "to": dialled, "from": caller})
            if env.get("handoff_required"):
                said = await self._fail(
                    call_id, "restaurant controls requested handoff")
                # Speak the reason Cherry gave ("not accepting automated
                # orders", "ordering isn't available here yet") unless the
                # transfer itself failed, which has its own instructions.
                if said == DEAD and env.get("say"):
                    return str(env["say"]).strip()
                return said
            return (env.get("say") or "").strip()
        except Exception as exc:  # noqa: BLE001
            return await self._fail(call_id, f"start: {exc}")

    async def tool_schemas(self) -> List[Dict[str, Any]]:
        env = await self._request("GET", "/v1/tools")
        tools = env.get("tools")
        if not isinstance(tools, list):
            raise RuntimeError("Cherry did not return a tool list")
        return tools

    async def handle_tool_call(self, call_id: str, name: str,
                               arguments: Optional[Dict[str, Any]] = None
                               ) -> str:
        try:
            env = await self._request(
                "POST", f"/v1/calls/{self._cid(call_id)}/tools/{name}",
                arguments or {})
            if env.get("handoff_required"):
                return await self._fail(call_id, f"tool {name} requested handoff")
            say = (env.get("say") or "").strip()
            if not say:
                raise RuntimeError("Cherry returned empty speech")
            self.spoken_log.append({"call_id": call_id, "tool": name,
                                    "returned": say})
            return say
        except CherryHTTPError as exc:
            if exc.status == 400:
                # Cherry is up and refused this one request. The call is not
                # broken; do not put a person on the line for a model slip.
                log.warning("tool %s rejected on %s: %s", name, call_id, exc)
                return RETRY_LINE
            return await self._fail(call_id, f"tool {name}: {exc}")
        except Exception as exc:  # noqa: BLE001
            return await self._fail(call_id, f"tool {name}: {exc}")

    async def finish(self, call_id: str, customer_name: str = "") -> str:
        with self._finish_guard:
            lock = self._finish_locks.setdefault(call_id, threading.Lock())
        await asyncio.to_thread(lock.acquire)
        try:
            return await self._finish_locked(call_id, customer_name)
        finally:
            lock.release()
            with self._finish_guard:
                if self._finish_locks.get(call_id) is lock:
                    del self._finish_locks[call_id]

    async def _finish_locked(self, call_id: str, customer_name: str = "") -> str:
        # A replayed finish (worker retry, duplicate event) must not bounce a
        # caller whose order already went through: answer with the same words.
        if call_id in self._finished:
            return self._finished[call_id]
        try:
            ready = await self._request(
                "POST", f"/v1/calls/{self._cid(call_id)}/tools/ready_to_place",
                {})
            if not ready.get("ok"):
                return (ready.get("say") or "").strip()
            done = await self._request(
                "POST", f"/v1/calls/{self._cid(call_id)}/finish",
                {"customer_name": customer_name or ""},
                timeout=self.finish_timeout)
            say = (done.get("say") or "").strip()
            self._remember(self._finished, call_id, say)
            if _staff_needed(done):
                # The order exists but the caller has no checkout link and
                # the kitchen has nothing. Saying "staff will help" is not
                # enough: put a person on the line.
                extra = await self._fail(call_id, "checkout was not delivered")
                if extra != DEAD:            # the transfer itself failed
                    say = f"{say} {extra}"
                    self._remember(self._finished, call_id, say)
            # _dialled is kept (it is bounded): a caller who asks for a person
            # AFTER checkout still has to be routed to the right restaurant.
            return say
        except Exception as exc:  # noqa: BLE001
            return await self._fail(call_id, f"finish: {exc}")

    async def abandon(self, call_id: str,
                      reason: str = "caller_hung_up") -> None:
        try:
            await self._request("POST",
                                f"/v1/calls/{self._cid(call_id)}/abandon",
                                {"reason": reason})
        except Exception as exc:  # noqa: BLE001
            log.error("abandon failed on %s: %s", call_id, exc)
        finally:
            self._dialled.pop(call_id, None)
            self._handed_off.pop(call_id, None)

    async def close(self) -> None:
        """Compatibility hook for transports that later need cleanup."""

    def verbatim_audit(self, actually_spoken: List[str]) -> List[Dict[str, str]]:
        drift = []
        for expected, heard in zip(self.spoken_log, actually_spoken):
            if expected["returned"] != (heard or "").strip():
                drift.append({"tool": expected["tool"],
                              "cherry_said": expected["returned"],
                              "caller_heard": heard})
        return drift
