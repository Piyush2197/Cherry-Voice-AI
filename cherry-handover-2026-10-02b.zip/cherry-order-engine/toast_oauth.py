"""Toast POS OAuth for Cherry: partner authentication using client-credentials.

Toast uses OAuth 2.0 client-credentials grant (not merchant authorization).
A single partner API client can access multiple restaurants that have granted
your app access. Authentication is shared across all locations.

Written against Toast's documentation (checked 2026-10-02):
  https://doc.toasttab.com/doc/devguide/authentication.html
  https://doc.toasttab.com/doc/devguide/apiAuthTokenRefresh.html
  https://doc.toasttab.com/openapi/authentication/operation/authenticationLoginPost/

What Toast says, and what this file does about it:

* There is **no refresh token** (``token.refreshToken`` is null for partner
  clients): a new token is a new login call. The first version stored that
  null in a vault that refuses empty values, so the first real login would
  have crashed while saving — and, because the "refresh" half was never
  stored, found no cached token on the next call and logged in again every time.
* Cache **one** token for every location (Toast rate-limits otherwise).
* Asking again inside the validity period returns the **same token** with the
  same expiry; a new one only comes in the **last minute** of the old one's
  life, or after it has expired. So a daily job almost never lands in that
  window — whatever calls Toast must use ``access_token()``, which logs in only
  when the token is expired or in its last minute (and once, however many
  workers ask at the same moment). ``refresh`` is a health check that the
  credentials still work, not what keeps the token alive.
* On a 401, stop using the token and call ``access_token(force=True)``.
* Lifetime comes from ``token.expiresIn`` (seconds remaining; the docs show
  24 hours, and say it depends on the environment). Never assumed.
* The API hosts are Toast's ``ws-api.toasttab.com`` (production) and
  ``ws-sandbox-api.eng.toasttab.com`` (sandbox), per its docs; the docs also say
  to confirm endpoints with Toast's integrations team, so ``TOAST_API_BASE``
  overrides both. NOT PROVED against a live Toast account.

Unlike Square/Clover, Toast does NOT require per-restaurant OAuth flow.
Restaurant access is granted through the Toast platform (partner model).

    python3 toast_oauth.py authenticate
    python3 toast_oauth.py status
    python3 toast_oauth.py refresh        # do the credentials still work?
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Dict, Optional, Protocol

from vault import default_vault, exclusive

# Toast API endpoints (see the docstring: confirm with Toast, override with TOAST_API_BASE)
TOAST_API_PROD = "https://ws-api.toasttab.com"
TOAST_API_SANDBOX = "https://ws-sandbox-api.eng.toasttab.com"
LOGIN_PATH = "/authentication/v1/authentication/login"
TOAST_AUTH_URL = TOAST_API_SANDBOX + LOGIN_PATH
TOAST_AUTH_URL_PROD = TOAST_API_PROD + LOGIN_PATH
USER_ACCESS_TYPE = "TOAST_MACHINE_CLIENT"
# Toast hands out a new token only in the LAST minute of the old one's life, so
# a wider margin would just fetch the same token again on every call.
TOKEN_REFRESH_BUFFER = timedelta(minutes=1)
DEFAULT_LIFETIME_SECONDS = 3600     # if expiresIn is missing: assume short, re-login sooner


class SecretVault(Protocol):
    def get(self, name: str) -> str: ...
    def put(self, name: str, value: str) -> None: ...


class ToastAuthError(RuntimeError):
    pass


@dataclass(frozen=True)
class ToastToken:
    access_token: str
    refresh_token: str
    expires_at: datetime
    scopes: list[str]


class ToastOAuthClient:
    """Toast OAuth client using client-credentials grant."""

    def __init__(self, client_id: str, client_secret: str, *, 
                 sandbox: bool = False, opener=None, timeout: float = 15.0):
        if not client_id or not client_secret:
            raise ValueError("Toast client id and secret are required")
        self.client_id = client_id
        self.client_secret = client_secret
        base = os.environ.get("TOAST_API_BASE", "").strip().rstrip("/")
        self.auth_url = (base + LOGIN_PATH if base
                         else TOAST_AUTH_URL if sandbox else TOAST_AUTH_URL_PROD)
        self.opener = opener or urllib.request.urlopen
        self.timeout = timeout

    def authenticate(self) -> ToastToken:
        """Authenticate using client-credentials grant."""
        body = {
            "clientId": self.client_id,
            "clientSecret": self.client_secret,
            "userAccessType": USER_ACCESS_TYPE
        }
        request = urllib.request.Request(
            self.auth_url,
            data=json.dumps(body).encode(),
            method="POST",
            headers={"Content-Type": "application/json"}
        )
        try:
            with self.opener(request, timeout=self.timeout) as response:
                result = json.loads(response.read() or b"{}")
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode(errors="replace") if hasattr(exc, "read") else ""
            raise ToastAuthError(f"Toast auth returned HTTP {exc.code}: {detail[:500]}") from exc
        except (urllib.error.URLError, OSError) as exc:   # incl. 3.9's socket.timeout
            raise ToastAuthError(f"Toast auth unavailable: {exc}") from exc
        
        if not isinstance(result, dict) or result.get("status") != "SUCCESS":
            raise ToastAuthError(f"Toast auth failed: {(result or {}).get('error', 'unknown error') if isinstance(result, dict) else 'unreadable reply'}")
        
        token_data = result.get("token") or {}
        access_token = token_data.get("accessToken")
        refresh_token = token_data.get("refreshToken")      # null for partner clients
        expires_in = token_data.get("expiresIn")
        
        if not access_token or not isinstance(access_token, str):
            raise ToastAuthError("Toast auth response lacks access_token")
        if isinstance(expires_in, bool) or not isinstance(expires_in, (int, float)) or expires_in <= 0:
            expires_in = DEFAULT_LIFETIME_SECONDS
        
        scopes = token_data.get("scope", "").split(",") if token_data.get("scope") else []
        expires_at = datetime.now(timezone.utc) + timedelta(seconds=expires_in)
        
        return ToastToken(
            access_token=access_token,
            refresh_token=refresh_token if isinstance(refresh_token, str) else "",
            expires_at=expires_at,
            scopes=scopes
        )


def secret_names() -> Dict[str, str]:
    """Vault secret names for Toast tokens (shared across all restaurants)."""
    return {
        "access": "TOAST_ACCESS_TOKEN",
        "refresh": "TOAST_REFRESH_TOKEN",
        "expires": "TOAST_TOKEN_EXPIRES_AT"
    }


def _read(vault: SecretVault, name: str) -> str:
    try:
        return vault.get(name) or ""
    except KeyError:
        return ""


def get_stored_token(vault: SecretVault) -> Optional[ToastToken]:
    """The cached token, or None if there is none or it cannot be read. Toast
    has no refresh token and many tokens have no scope, so only the access
    token and its expiry are required."""
    names = secret_names()
    access = _read(vault, names["access"])
    expires_str = _read(vault, names["expires"])
    if not access or not expires_str:
        return None
    try:
        expires = datetime.fromisoformat(expires_str.replace("Z", "+00:00"))
    except ValueError:
        return None                      # unreadable expiry: treat as no token, log in again
    scopes_str = _read(vault, "TOAST_TOKEN_SCOPES")
    return ToastToken(access, _read(vault, names["refresh"]), expires,
                      scopes_str.split(",") if scopes_str else [])


def store_token(vault: SecretVault, token: ToastToken) -> None:
    """Store the token. Empty values are skipped, not stored: a vault refuses
    them, and Toast sends no refresh token and often no scope."""
    names = secret_names()
    vault.put(names["expires"], token.expires_at.isoformat())
    if token.refresh_token:
        vault.put(names["refresh"], token.refresh_token)
    if token.scopes:
        vault.put("TOAST_TOKEN_SCOPES", ",".join(token.scopes))
    vault.put(names["access"], token.access_token)       # last: a reader never sees a token without its expiry


def _usable(token: Optional[ToastToken], now: datetime) -> bool:
    return token is not None and token.expires_at - now > TOKEN_REFRESH_BUFFER


def access_token(client: ToastOAuthClient, vault: SecretVault, *,
                 force: bool = False, now: Optional[datetime] = None) -> str:
    """A Toast access token that is good right now — the call every Toast
    request goes through. Logs in only when there is no token, it has expired,
    or it is in its last minute (or ``force``, after a 401); and once, however
    many workers ask at the same moment, because asking more often than that
    just returns the same token and counts against Toast's rate limit."""
    now = now or datetime.now(timezone.utc)
    current = get_stored_token(vault)
    if not force and _usable(current, now):
        return current.access_token
    with exclusive(vault, "toast-token"):
        current = get_stored_token(vault)
        if not force and _usable(current, now):          # a peer just renewed it
            return current.access_token
        token = client.authenticate()
        store_token(vault, token)
        return token.access_token


def refresh_if_needed(client: ToastOAuthClient, vault: SecretVault, *,
                     force: bool = False) -> dict:
    """Refresh token if expired or near expiry, return status."""
    current = get_stored_token(vault)
    now = datetime.now(timezone.utc)
    
    if current is None or force or not _usable(current, now):
        with exclusive(vault, "toast-token"):
            before = get_stored_token(vault)
            if not force and _usable(before, now):        # a peer just renewed it
                return {"action": "skipped", "expires_at": before.expires_at.isoformat(),
                        "time_left": str(before.expires_at - now)}
            token = client.authenticate()
            store_token(vault, token)
        return {"action": "authenticated" if current is None else "refreshed",
                "expires_at": token.expires_at.isoformat()}
    
    return {
        "action": "skipped",
        "expires_at": current.expires_at.isoformat(),
        "time_left": str(current.expires_at - now)
    }


def status(vault: SecretVault) -> dict:
    """Return current token status."""
    token = get_stored_token(vault)
    if token is None:
        return {"status": "not_authenticated", "expires_at": None}
    
    now = datetime.now(timezone.utc)
    time_left = token.expires_at - now
    
    if time_left.total_seconds() <= 0:
        status = "expired"
    elif time_left <= TOKEN_REFRESH_BUFFER:
        status = "due_for_refresh"
    else:
        status = "ok"
    
    return {
        "status": status,
        "expires_at": token.expires_at.isoformat(),
        "time_left": str(time_left),
        "scopes": token.scopes
    }


def _client_from_env(sandbox: bool) -> ToastOAuthClient:
    client_id = os.environ.get("TOAST_CLIENT_ID", "")
    client_secret = os.environ.get("TOAST_CLIENT_SECRET", "")
    return ToastOAuthClient(client_id, client_secret, sandbox=sandbox)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--sandbox", action="store_true",
                        default=os.environ.get("CHERRY_TOAST_SANDBOX") == "1",
                        help="Use Toast sandbox environment (or CHERRY_TOAST_SANDBOX=1)")
    parser.add_argument("--force", action="store_true",
                        help="Force authentication even if token is valid")
    sub = parser.add_subparsers(dest="command", required=True)
    
    sub.add_parser("authenticate", help="Authenticate and store token")
    sub.add_parser("status", help="Show current token status")
    sub.add_parser("refresh", help="Refresh token if needed")
    
    args = parser.parse_args(argv)
    
    vault = default_vault()
    if vault is None:
        print(json.dumps({"ok": False, "error": "CHERRY_SECRET_DIR is not set"}))
        return 1
    
    try:
        client = _client_from_env(args.sandbox)
        
        if args.command == "authenticate":
            token = client.authenticate()
            store_token(vault, token)
            print(json.dumps({
                "ok": True,
                "expires_at": token.expires_at.isoformat(),
                "scopes": token.scopes
            }, indent=2))
            return 0
        
        if args.command == "status":
            result = status(vault)
            print(json.dumps(result, indent=2))
            return 0 if result["status"] == "ok" else 3
        
        if args.command == "refresh":
            result = refresh_if_needed(client, vault, force=args.force)
            print(json.dumps(result, indent=2))
            return 0
    
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}))
        return 1


if __name__ == "__main__":
    sys.exit(main())
