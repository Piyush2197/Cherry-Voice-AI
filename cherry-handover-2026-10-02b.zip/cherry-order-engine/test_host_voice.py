#!/usr/bin/env python3
"""Lily as a host: the warm greeting, the waiter's allergy question, and the
note that carries an allergy to the kitchen.

The rules this pins:

  * the allergy question is asked by the ENGINE (`ready_to_place`), once, so a
    model cannot forget it; once asked it never blocks again, so a caller who
    hung up or a model that lost the answer does not cost the restaurant the
    order;
  * an allergy is only ever passed on — nothing Lily says calls a dish safe;
  * the note reaches every place a kitchen looks: the Square order, the printed
    ticket and the tablet — and a call that is restarted mid-way keeps it;
  * the warmth lives in the engine's own lines (the model speaks them verbatim),
    and "I'd like to place an order" is welcomed instead of refused.
"""

from __future__ import annotations

import json
import os
import random
import sqlite3
import tempfile
import threading
import time
import traceback
import urllib.request
from pathlib import Path

import agent_api
import host_voice as hv
import menu_schema as ms
from agent_api import CallSession

HERE = Path(__file__).resolve().parent
_passed = _failed = 0


def check(name, cond, detail=""):
    global _passed, _failed
    if cond:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


def menu(name="pink-garlic-shelby"):
    return ms.load_yaml(HERE / "menus" / f"{name}.yaml")


def t_classifier_tells_none_from_a_restriction_from_yes() -> None:
    cases = {
        "none": ["no", "No.", "nope", "nothing", "no allergies", "No, we're good", "none that I know of",
                 "I'm good", "not that I'm aware of", "no thanks", "nope, all good",
                 "I don't have any allergies", "nothing special", "no dietary restrictions"],
        "yes": ["yes", "yeah", "yeah I do", "yes allergies", "um yes", "we do"],
        "note": ["peanuts", "no peanuts", "my son is allergic to sesame", "I'm vegetarian",
                 "gluten free please", "no pork I'm Muslim", "no onions or garlic",
                 "yes my daughter has a shellfish allergy", "no, no peanuts", "nothing with nuts"],
        "empty": ["", "   ", "..."],
    }
    for want, texts in cases.items():
        for t in texts:
            check(f"{t!r} -> {want}", hv.classify_allergy(t) == want, hv.classify_allergy(t))
    check("'no peanuts' is a restriction and is KEPT, not read as a refusal",
          hv.classify_allergy("no peanuts") == "note")


def t_greeting_and_openers_are_warm_and_stable() -> None:
    s = CallSession(menu())
    g = s.greeting()["say"]
    check("greeting names the restaurant and Lily", "Pink Garlic" in g and "this is Lily" in g, g)
    check("…and invites the order", "What can I get started" in g, g)
    a = CallSession(menu()); b = CallSession(menu())
    seq = lambda c: [c.add_item(x)["say"].split(" —")[0] for x in ("garlic naan", "plain naan", "papadum", "samosa")]
    one, two = seq(a), seq(b)
    check("the first item still opens with 'Got it'", one[0] == "Got it", str(one))
    check("later items vary", len(set(one)) > 1, str(one))
    check("the same calls always say the same words (a restart replays them)", one == two, f"{one} {two}")


def t_wanting_to_order_is_welcomed_not_refused() -> None:
    for text in ("I'd like to place an order", "can I order for pickup", "takeout please"):
        r = CallSession(menu()).add_item(text)
        check(f"{text!r} is welcomed", r["ok"] and "we don't have that" not in r["say"].lower()
              and "?" in r["say"], r["say"])
        check(f"{text!r} adds nothing", not r["order"]["lines"])
    r = CallSession(menu()).add_item("a sushi roll")
    check("a dish that is not on the menu is still refused", not r["ok"], r["say"])
    s = CallSession(menu()); r = s.add_item("I'd like the vegetable samosa to go")
    check("an order that names a dish just orders it", len(r["order"]["lines"]) == 1, r["say"])


def t_the_engine_asks_about_allergies_once() -> None:
    s = CallSession(menu()); s.add_item("one vegetable samosa")
    r = s.ready_to_place()
    check("a finished order is asked about allergies first", not r["ok"] and r["error"] == "allergy_check", str(r))
    check("…as a question the voice layer can see", r["needs"]["code"] == "allergy_check" and r["needs"]["question"] == r["say"])
    check("the question is a waiter's", "allerg" in r["say"].lower() and "kitchen" in r["say"].lower(), r["say"])
    s.note_allergy("no")
    check("answering 'no' lets it through", s.ready_to_place()["ok"])
    check("…and leaves nothing on the ticket", "allergy" not in s.snapshot())

    s = CallSession(menu()); s.add_item("one vegetable samosa"); s.ready_to_place()
    r = s.ready_to_place()
    check("asked once and never answered, the order is NOT held hostage", r["ok"], str(r))
    check("…and the ticket says the guest was never asked, not that all is well",
          s.snapshot()["allergy"] == {"checked": False, "note": ""}, str(s.snapshot().get("allergy")))

    s = CallSession(menu()); s.add_item("chicken tikka")
    check("a required choice is asked before the allergy question",
          s.ready_to_place()["error"] == "incomplete")


def t_an_allergy_is_written_down_and_never_cleared() -> None:
    s = CallSession(menu()); s.add_item("one vegetable samosa")
    r = s.note_allergy("my daughter is allergic to peanuts")
    check("it is acknowledged", "flagged that for the kitchen" in r["say"], r["say"])
    check("…with the honest limit", "can't check ingredients myself" in r["say"], r["say"])
    check("…and never says anything is safe", not any(w in r["say"].lower() for w in ("safe", "free of", "no peanuts in")), r["say"])
    r = s.ready_to_place()
    check("a volunteered allergy means the allergy question is not asked again; only the name is",
          not r["ok"] and r["error"] == "name_check" and "allerg" not in r["say"].lower(), str(r["say"]))
    s.set_name("Sam")
    check("…and with the name given, the order goes through", s.ready_to_place()["ok"])
    check("the note rides on the order", s.snapshot()["allergy"] == {"checked": True, "note": "my daughter is allergic to peanuts"})
    s.note_allergy("and my husband avoids shellfish")
    check("a second note is added, not lost", "peanuts" in s.snapshot()["allergy"]["note"] and "shellfish" in s.snapshot()["allergy"]["note"])
    s.note_allergy("x " * 400)
    check("a note is bounded", len(s.snapshot()["allergy"]["note"]) <= hv.NOTE_LIMIT)

    s = CallSession(menu()); s.add_item("garlic naan"); s.ready_to_place()
    r = s.answer("yes")
    check("a bare 'yes' gets 'what should I tell the kitchen?'", not r["ok"] and "tell the kitchen" in r["say"], r["say"])
    r = s.answer("shellfish")
    check("the model using `answer` for the reply still lands it", s.snapshot()["allergy"]["note"] == "shellfish", str(r))

    s = CallSession(menu()); s.add_item("chicken korma")
    base = time.monotonic()
    s.now = lambda: base + 8.0          # the caller takes seconds to say their next thing
    r = s.note_allergy("peanut allergy")
    check("mid-item, the question the order was waiting on is asked again in the same reply",
          r["say"].rstrip().endswith("extra hot."), r["say"])
    check("empty text is asked for, not recorded", not CallSession(menu()).note_allergy("")["ok"])
    check("non-text is survived", not CallSession(menu()).note_allergy(None)["ok"])


def t_the_note_reaches_square_the_ticket_and_the_tablet() -> None:
    import server
    import sinks
    import square_bridge as sb
    s = CallSession(menu()); s.add_item("one vegetable samosa")
    s.note_allergy("peanut allergy, please be careful")
    snap = json.loads(json.dumps(s.snapshot()))
    order = sb.build_square_order(snap, "LOC")
    note = order["fulfillments"][0]["pickup_details"]["note"]
    check("Square's pickup note carries the allergy", "Taken by phone" in note and "peanut allergy" in note, note)
    check("…within Square's limit", len(note) <= 500)
    ticket = sinks.format_ticket(snap, "1234", restaurant_name="Pink Garlic")
    check("the kitchen ticket leads with it", "ALLERGY / DIET" in ticket.split("\n")[3] + ticket.split("\n")[2] or "ALLERGY / DIET" in ticket, ticket)
    check("…in a line that cannot be missed", "*** ALLERGY / DIET (caller said): peanut allergy" in ticket, ticket)
    quiet = CallSession(menu()); quiet.add_item("one vegetable samosa"); quiet.note_allergy("no")
    qsnap = quiet.snapshot()
    check("'no allergies' leaves Square's note and the ticket quiet",
          sb.build_square_order(qsnap, "LOC")["fulfillments"][0]["pickup_details"]["note"] == "Taken by phone"
          and "ALLERGY" not in sinks.format_ticket(qsnap, "1", restaurant_name="x"))
    unk = CallSession(menu()); unk.add_item("one vegetable samosa"); unk.ready_to_place(); unk.ready_to_place()
    check("never asked -> Square and the ticket say so explicitly",
          "NOT CONFIRMED" in sb.build_square_order(unk.snapshot(), "LOC")["fulfillments"][0]["pickup_details"]["note"]
          and "NOT CONFIRMED" in sinks.format_ticket(unk.snapshot(), "1", restaurant_name="x"))
    html = server._KDS_HTML
    check("the tablet shows the allergy as its own banner", "class=allergy" in html and "esc(o.allergy)" in html)
    # every line that writes caller/menu text into the page's HTML
    raw = [l for l in html.split("\n") if "<div" in l and any(
        k in l for k in ("ln.note", "ln.name", "ln.size", "o.code", "o.allergy", "o.placed_at", "o.channel", "m +"))]
    check("…and escapes everything it inserts (caller-spoken text reaches that page)",
          raw and all("esc(" in l for l in raw), str(raw))


def t_the_kitchen_tablet_feed_carries_the_allergy() -> None:
    import payments
    import server as srv
    from dev_checkout import DevCheckoutProvider
    from order_store import OrderStore
    from sinks import FakeSmsSender
    with tempfile.TemporaryDirectory() as tmp:
        store = OrderStore.sqlite(os.path.join(tmp, "c.db"))
        cfg = ms.load_yaml(HERE / "menus" / "bun-n-run-ferndale.yaml")
        store.upsert_restaurant(cfg.id, cfg.name, cfg.cuisine, sink="manual", tax_rate_bps=cfg.tax_rate_bps,
                                staff_phone="+13135550999", active=True)
        mv = store.publish_menu(cfg.id, "menus/bun-n-run-ferndale.yaml", item_count=len(cfg.items))
        s = CallSession(cfg); s.add_item("double cheeseburger")
        for _ in range(4):
            issue = s.pending()
            if issue is None:
                break
            s.answer(cfg.option(issue.candidates[0]).name if issue.candidates else "")
        s.note_allergy("<img src=x onerror=alert(1)> sesame allergy")
        oid, code = store.place_order(cfg.id, mv, json.loads(json.dumps(s.snapshot())), customer_phone="+13135550123")
        payments.arrange_payment(store, oid, sms=FakeSmsSender(), provider=DevCheckoutProvider())
        assert payments.mark_paid(store, oid, "dev-hv")
        assert payments.release_paid_order(store, oid, sms=FakeSmsSender())["released"]
        app = srv.Cherry(store, api_key="k", dev_checkout=True)
        httpd = srv.build_server(app, 0)
        threading.Thread(target=httpd.serve_forever, daemon=True).start()
        try:
            key = srv.kds_key("k", cfg.id)
            with urllib.request.urlopen(f"http://127.0.0.1:{httpd.server_address[1]}/kds/orders?r={cfg.id}&k={key}") as r:
                orders = json.loads(r.read())["orders"]
            check("the feed carries the allergy line", orders and "sesame allergy" in orders[0]["allergy"], str(orders)[:200])
            check("…in staff wording", orders[0]["allergy"].startswith("ALLERGY / DIET (caller said):"))
        finally:
            httpd.shutdown(); httpd.server_close(); store.close()


def t_a_restart_mid_call_keeps_the_allergy_and_the_order_goes_through() -> None:
    import rehearsal
    st = rehearsal.Stack()
    try:
        st.call("hv-1")
        st.tool("hv-1", "add_item", text="one vegetable samosa")
        code, b = st.tool("hv-1", "ready_to_place")
        check("over HTTP the gateway returns the allergy question", "allerg" in (b.get("say") or "").lower(), str(b)[:160])
        st.tool("hv-1", "note_allergy", text="my son is allergic to peanuts")
        st.restart_server()                              # a deploy mid-call
        code, done = st.finish("hv-1")
        check("the call is resumed after the restart and the order is placed",
              code == 200 and "texted" in (done.get("say") or ""), str(done)[:200])
        check("…with a warm sign-off", (done.get("say") or "").endswith("enjoy your meal!"), done.get("say"))
        posts = [b for (m, u, b) in st.fake.square if u.endswith("/payment-links") and m == "POST"]
        note = posts[-1]["order"]["fulfillments"][0]["pickup_details"]["note"] if posts else ""
        check("Square received the allergy in its pickup note", "peanuts" in note, note)
        row = st.store.conn.execute('SELECT snapshot FROM "order"').fetchone()
        check("the stored order carries it", row and "peanuts" in json.loads(row["snapshot"]).get("allergy", {}).get("note", ""))

        st.call("hv-2")
        st.tool("hv-2", "add_item", text="one vegetable samosa")
        st.fake.sms_down = True
        st.tool("hv-2", "ready_to_place"); st.tool("hv-2", "note_allergy", text="no")
        code, failed = st.finish("hv-2")
        check("a failed delivery never ends with 'enjoy your meal'", "enjoy your meal" not in (failed.get("say") or ""), str(failed)[:200])
    finally:
        st.close()


def t_no_sequence_of_tools_breaks_the_session() -> None:
    rng = random.Random(11)
    tools = [("add_item", lambda: {"text": rng.choice(["garlic naan", "chicken korma", "one vegetable samosa", "i'd like to order", "pad thai", ""])}),
             ("answer", lambda: {"text": rng.choice(["medium", "no", "yes", "peanuts", "mild", ""])}),
             ("note_allergy", lambda: {"text": rng.choice(["no", "yes", "peanuts", "", "my son is allergic to sesame"])}),
             ("ready_to_place", lambda: {}), ("read_back", lambda: {}), ("confirm_mods", lambda: {}),
             ("item_info", lambda: {"text": rng.choice(["does that have nuts", "i have an allergy", "vegan"])}),
             ("remove_item", lambda: {}), ("snapshot", lambda: {})]
    cfg = menu(); raised = 0; bad = []
    for _ in range(300):
        s = CallSession(cfg)
        for _ in range(rng.randint(2, 12)):
            name, mk = rng.choice(tools)
            try:
                r = getattr(s, name)(**mk())
                if name != "snapshot" and not (isinstance(r, dict) and isinstance(r.get("say"), str)):
                    bad.append((name, r))
            except Exception as exc:                          # noqa: BLE001
                raised += 1; bad.append((name, repr(exc)))
        try:
            snap = json.dumps(s.snapshot())
            json.loads(snap)
        except Exception as exc:                              # noqa: BLE001
            bad.append(("snapshot", repr(exc)))
    check("300 random calls: nothing raised, every reply is speakable, every snapshot serialises", not bad, str(bad[:3]))


def t_the_model_is_told_who_it_is_and_how_to_use_the_tool() -> None:
    from voice.inworld_bridge import SYSTEM_PROMPT
    p = " ".join(SYSTEM_PROMPT.split())
    check("the prompt gives the model Lily's character", "You are Lily" in p and "warm" in p)
    check("…routes 'I want to order' to add_item", "names nothing yet" in p and "add_item" in p)
    check("…tells it to call note_allergy and to re-call ready_to_place",
          "`note_allergy`" in p and "call `ready_to_place` again" in p)
    check("…and still forbids saying anything is safe", "never tell a caller a dish is safe" in p)


def t_a_question_is_asked_once_per_breath_and_a_sold_out_choice_is_never_offered() -> None:
    cfg = menu()
    s = CallSession(cfg)
    a = s.add_item("chicken korma")
    b = s.add_item("a couple of garlic naan")
    check("the korma's spice question is asked once when two dishes are named in one breath",
          "How spicy" in a["say"] and "How spicy" not in b["say"], f"{a['say']!r} / {b['say']!r}")
    base = time.monotonic()
    s.now = lambda: base + 8.0
    c = s.add_item("vegetable samosa")
    check("later, the question is asked again — and now says which dish it is about",
          c["say"].lower().count("how spicy") == 1 and "For the Chicken Korma" in c["say"], c["say"])

    bnr = menu("bun-n-run-ferndale")
    object.__setattr__(next(i for i in bnr.items if i.name == "French Fries"), "available", False)
    r = CallSession(bnr).add_item("some fries")
    check("when one of two matching dishes is sold out it is not offered as a choice: apology and the closest thing",
          "so sorry" in r["say"] and "Wild Fries" in r["say"] and "Did you want" not in r["say"], r["say"])
    r2 = CallSession(bnr).add_item("an order of fries")
    check("'an order of fries' is read as fries (not 'order'), then handled the same way", "Wild Fries" in r2["say"], r2["say"])
    r3 = CallSession(menu("juan-miguels-clinton")).add_item("a bag of chips")
    check("a menu that uses 'of' keeps it ('Bag of Chips')", "Bag of Chips" in r3["say"], r3["say"])


def main() -> int:
    global _failed
    for name, fn in sorted((k, v) for k, v in globals().items() if k.startswith("t_")):
        try:
            fn()
        except Exception:                                    # noqa: BLE001
            _failed += 1
            print(f"\n--- FAIL {name} raised")
            traceback.print_exc()
    print(f"{_passed} passed, {_failed} failed (host voice + allergy note)")
    return 1 if _failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
