#!/usr/bin/env python3
"""Payment-before-kitchen contract, without provider credentials or sockets."""
from __future__ import annotations

import tempfile
import traceback
from datetime import datetime, timedelta, timezone
from pathlib import Path

import menu_schema as ms
import payments
import square_bridge
import square_webhook
import pilot_deploy
from order_engine import OrderEngine
from order_store import OrderStore
from sinks import FakeSmsSender
from test_bridges import FakeHTTP

HERE = Path(__file__).parent


def fixture(*, sink="manual", quantity=5):
    store = OrderStore.sqlite()
    path = HERE / "menus" / "bun-n-run-ferndale.yaml"
    cfg = ms.load_yaml(path)
    store.upsert_restaurant(cfg.id, cfg.name, cfg.cuisine, sink=sink,
                            tax_rate_bps=cfg.tax_rate_bps,
                            staff_phone="+13135550999", active=True)
    mv = store.publish_menu(cfg.id, path.read_text(), item_count=len(cfg.items))
    engine = OrderEngine(cfg)
    line = engine.add_line("double_cheeseburger", quantity=quantity)
    for gid in engine.active_group_ids(line):
        group = cfg.group(gid)
        if group and group.required:
            engine.apply_option(line.line_id, gid, group.option_ids[0])
    snapshot = engine.to_normalized_order()
    assert snapshot["payment_mode"] == "pay_now"
    order_id, code = store.place_order(cfg.id, mv, snapshot,
                                        customer_phone="+13135550123")
    return store, order_id, code, snapshot


def payment_event(event_id, payment_ref, amount, *, status="COMPLETED"):
    return {"event_id": event_id, "type": "payment.updated",
            "data": {"object": {"payment": {
                "id": payment_ref, "order_id": payment_ref,
                "status": status,
                "amount_money": {"amount": amount, "currency": "USD"}}}}}


def test_itemized_checkout_and_paid_handoff():
    store, oid, code, snapshot = fixture(sink="square")
    http = FakeHTTP([{"payment_link": {
        "url": "https://square.link/u/abc", "order_id": "sq-order-1",
        "id": "sq-link-1"}}, {"order": {"id": "sq-order-1",
        "total_money": {"amount": snapshot["total_cents"],
                        "currency": "USD"}}}])
    provider = square_bridge.SquareCheckoutProvider(
        square_bridge.SquareClient("secret", "L-1", opener=http))
    sms = FakeSmsSender()
    assert payments.arrange_payment(store, oid, sms=sms, provider=provider) == "link_sent"
    assert len(http.requests) == 2
    wire = http.requests[0]["body"]
    assert wire["order"]["line_items"]
    assert wire["order"]["reference_id"] == code
    assert "https://square.link/u/abc" in sms.sent[0]["body"]
    assert "Wrong item? Do not pay; call +13135550999" in sms.sent[0]["body"]
    assert store.conn.execute("SELECT 1 FROM order_delivery WHERE order_id=?",
                              (oid,)).fetchone() is None
    amount = snapshot["total_cents"]
    event = payment_event("evt-1", "sq-order-1", amount)
    first = square_webhook.handle(store, event,
        on_paid=lambda order: payments.release_paid_order(store, order, sms=sms))
    assert first["action"] == "paid" and first["release"]["released"]
    assert square_webhook.handle(store, event)["action"] == "duplicate"
    second = square_webhook.handle(store,
        payment_event("evt-2", "sq-order-1", amount),
        on_paid=lambda order: payments.release_paid_order(store, order, sms=sms))
    assert second["action"] == "already_paid"
    assert second["release"]["reason"] == "already_claimed"
    deliveries = store.conn.execute(
        "SELECT * FROM order_delivery WHERE order_id=?", (oid,)).fetchall()
    assert len(deliveries) == 1 and deliveries[0]["external_ref"] == "sq-order-1"
    assert len(http.requests) == 2  # create and verify, never a second order


def test_square_total_mismatch_revokes_checkout_before_customer_sms():
    store, oid, _, snapshot = fixture(sink="square")
    http = FakeHTTP([{"payment_link": {
        "url": "https://square.link/u/bad", "order_id": "sq-wrong",
        "id": "sq-link-bad"}}, {"order": {"id": "sq-wrong",
            "total_money": {"amount": snapshot["total_cents"] + 1,
                            "currency": "USD"}}}, {}])
    provider = square_bridge.SquareCheckoutProvider(
        square_bridge.SquareClient("secret", "L-1", opener=http))
    sms = FakeSmsSender()
    assert payments.arrange_payment(store, oid, sms=sms,
                                    provider=provider) == "link_pending"
    assert not sms.sent
    assert http.requests[-1]["method"] == "DELETE"
    assert payments.payment_for(store, oid)["pay_url"] is None


def test_amount_mismatch_and_unpaid_cannot_release():
    store, oid, _, snapshot = fixture()
    sms, provider = FakeSmsSender(), payments.FakePayLinkProvider()
    payments.arrange_payment(store, oid, sms=sms, provider=provider)
    assert payments.release_paid_order(store, oid, sms=sms)["reason"] == "not_paid"
    mismatch = square_webhook.handle(store,
        payment_event("evt-bad", provider.created[0].pos_ref,
                      snapshot["total_cents"] - 1),
        on_paid=lambda order: payments.release_paid_order(store, order, sms=sms))
    assert mismatch["action"] == "amount_mismatch"
    assert payments.payment_for(store, oid)["status"] == "link_sent"
    assert store.conn.execute("SELECT 1 FROM order_delivery WHERE order_id=?",
                              (oid,)).fetchone() is None


def test_correction_revokes_old_link_and_keeps_old_order_immutable():
    store, oid, _, snapshot = fixture()
    provider, sms = payments.FakePayLinkProvider(), FakeSmsSender()
    payments.arrange_payment(store, oid, sms=sms, provider=provider)
    assert payments.cancel_unpaid_checkout(store, oid, provider=provider)
    assert provider.revoked == [provider.created[0].provider_link_ref]
    assert store.order(oid)["status"] == "cancelled"
    assert store.order_snapshot(oid) == snapshot
    assert not payments.cancel_unpaid_checkout(store, oid, provider=provider)
    late = square_webhook.handle(store,
        payment_event("evt-late", provider.created[0].pos_ref,
                      snapshot["total_cents"]),
        on_paid=lambda order: payments.release_paid_order(store, order, sms=sms))
    assert late["action"] == "paid_after_expiry"
    assert not store.conn.execute("SELECT 1 FROM order_delivery WHERE order_id=?",
                                  (oid,)).fetchone()


def test_expiry_requires_actual_provider_revocation():
    store, oid, _, _ = fixture()
    provider = payments.FakePayLinkProvider()
    payments.arrange_payment(store, oid, sms=FakeSmsSender(), provider=provider)
    past = (datetime.now(timezone.utc) - timedelta(minutes=1)).isoformat(
        timespec="seconds")
    with store.tx() as conn:
        conn.execute("UPDATE payment SET pay_url_expires_at=? WHERE order_id=?",
                     (past, oid))
    provider.fail = True
    result = payments.expire_due_links(store, provider_for=lambda _: provider)
    assert result["failed"] == 1
    assert payments.payment_for(store, oid)["status"] == "link_sent"
    provider.fail = False
    result = payments.expire_due_links(store, provider_for=lambda _: provider)
    assert result["expired"] == 1
    assert payments.payment_for(store, oid)["status"] == "expired"


def test_paid_manual_handoff_failure_requires_review_not_blind_duplicate():
    store, oid, _, snapshot = fixture()
    provider = payments.FakePayLinkProvider()
    payments.arrange_payment(store, oid, sms=FakeSmsSender(), provider=provider)
    sms = FakeSmsSender(fail_times=1)
    event = payment_event("evt-fail", provider.created[0].pos_ref,
                          snapshot["total_cents"])
    first = square_webhook.handle(store, event,
        on_paid=lambda order: payments.release_paid_order(store, order, sms=sms))
    assert first["action"] == "paid" and not first["release"]["released"]
    assert first["release"]["reason"] == "delivery_failed"
    assert payments.retry_paid_deliveries(store, sms=sms)["checked"] == 0
    assert not sms.sent  # uncertain send is not automatically duplicated


def test_existing_sqlite_database_migrates_without_losing_order():
    with tempfile.TemporaryDirectory() as temp:
        path = str(Path(temp) / "pilot.db")
        store = OrderStore.sqlite(path)
        row = store.conn.execute("SELECT count(*) AS n FROM schema_migration").fetchone()
        assert row["n"] >= 3
        store.close()
        reopened = OrderStore.sqlite(path)
        columns = {r["name"] for r in reopened.conn.execute(
            "PRAGMA table_info(payment)")}
        assert "provider_link_ref" in columns
        assert reopened.conn.execute("SELECT 1 FROM order_release").fetchone() is None
        reopened.close()


def test_every_pilot_location_requires_checkout_even_for_a_small_order():
    for loc in pilot_deploy.load_manifest():
        cfg = ms.load_yaml(loc.menu)
        assert cfg.pay_now_threshold_cents == 0, loc.id
        engine = OrderEngine(cfg)
        item = next(i for i in cfg.items if i.available)
        line = engine.add_line(item.id)
        for gid in engine.active_group_ids(line):
            group = cfg.group(gid)
            if group and group.required:
                engine.apply_option(line.line_id, gid, group.option_ids[0])
        assert engine.to_normalized_order()["payment_mode"] == "pay_now", loc.id


def main():
    tests = sorted((name, fn) for name, fn in globals().items()
                   if name.startswith("test_") and callable(fn))
    failed = 0
    for name, fn in tests:
        try:
            fn()
        except Exception:
            failed += 1
            print(f"FAIL {name}\n{traceback.format_exc()}")
    print(f"{len(tests)-failed} passed, {failed} failed (payment gate)")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
