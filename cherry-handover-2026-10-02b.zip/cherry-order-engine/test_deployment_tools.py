#!/usr/bin/env python3
"""Checks for the read-only deployment smoke and failover drills."""

from __future__ import annotations

import asyncio
import tempfile
import traceback
from pathlib import Path

import failover_drill
import menu_schema as ms
from order_store import OrderStore
import pilot_deploy as pd
import pilot_smoke


_passed = _failed = 0


def check(name, condition, detail=""):
    global _passed, _failed
    if condition:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


def t_smoke_prices_a_call_without_creating_an_order() -> None:
    loc = pd.selected(pd.load_manifest(), ["tamago-sushi-bowl"])[0]
    inbound = "+13135550121"
    with tempfile.TemporaryDirectory() as tmp:
        db = str(Path(tmp) / "pilot.db")
        cfg = ms.load_yaml(loc.menu)
        store = OrderStore.sqlite(db)
        store.upsert_restaurant(
            cfg.id, cfg.name, cfg.cuisine, tax_rate_bps=cfg.tax_rate_bps,
            staff_phone=loc.fallback_phone, inbound_phone=inbound, active=True)
        store.publish_menu(cfg.id, loc.menu.read_text(), item_count=len(cfg.items))
        rc = pilot_smoke.run([loc], db, {loc.inbound_env: inbound})
        orders = store.conn.execute('SELECT count(*) AS n FROM "order"').fetchone()["n"]
        sessions = store.conn.execute("SELECT count(*) AS n FROM session").fetchone()["n"]
        check("the deployment smoke passes", rc == 0, str(rc))
        check("the smoke creates no order or call session",
              (orders, sessions) == (0, 0), f"{orders}/{sessions}")


def t_failover_drill_checks_each_configured_route_once() -> None:
    rows = [x for x in pd.load_manifest() if x.catalog_status == "ready"][:2]
    env = {row.inbound_env: f"+1313555013{n}" for n, row in enumerate(rows)}
    rc = asyncio.run(failover_drill.drill(rows, env))
    check("the multi-location failover drill passes", rc == 0, str(rc))


def main() -> int:
    for name, fn in sorted(globals().items()):
        if not name.startswith("t_"):
            continue
        try:
            fn()
        except Exception:
            global _failed
            _failed += 1
            print(f"\n--- FAIL {name}\n{traceback.format_exc()}")
    print(f"\n{_passed} passed, {_failed} failed (deployment tools)")
    return 1 if _failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
