import { NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'
import { getRestaurants } from '@/lib/cherry-api'

export async function GET() {
  // Check authentication
  const user = await getCurrentUser()
  if (!user) {
    return NextResponse.json(
      { error: 'Unauthorized' },
      { status: 401 }
    )
  }
  
  // Fetch from CHERRY API
  const response = await getRestaurants()
  
  if (!response.ok) {
    return NextResponse.json(
      { error: response.error || 'Failed to fetch restaurants' },
      { status: 500 }
    )
  }
  
  return NextResponse.json(response.data)
}
