"""
Cherry Cuisine Library — menu literacy, as ONBOARDING-TIME priors.

THE ONE ARCHITECTURAL RULE
--------------------------
This library PROPOSES. The config DECIDES. The engine never reads this file.

It is tempting to make the engine "know" that Indian food has spice levels, so
it can ask even when the config is silent. Do not. The moment the engine
carries cuisine knowledge into a live call, it can assert something about a
restaurant that is not true — asking spice level at a place that doesn't do
spice levels, or worse, assuming a price. Runtime must stay dumb and
deterministic: it reads the config and nothing else.

So this library runs exactly once per restaurant, at onboarding, and its whole
output is a DRAFT plus a list of things a human has to confirm. After that it
is out of the loop forever.

WHAT IT ACTUALLY BUYS YOU
-------------------------
1. Aliases. A caller says "butter chicken"; the menu says "29. Butter Chk.
   (Creamy)". Generating that mapping by hand for 200 items is the slow part
   of onboarding, and it is mechanical.

2. Mishearings. This is the part no menu scrape gives you. ASR does not fail
   randomly — it fails into real English words. "naan" becomes "none",
   "margherita" becomes "margarita", "penne" becomes "penny", "gyro" becomes
   "hero". Those are order-breaking and they are predictable per cuisine.

3. Shape priors. "Serve with Rice" on every curry, "choice of" on every
   entree, "add $3" in a description — these are textual tells that a modifier
   group exists. The library knows which tells go with which shape, and turns
   them into questions for the owner instead of assumptions.

4. ASR keyterm budget. See asr_keyterms(). Speech recognisers cap how much
   vocabulary you can boost — Deepgram's keyterm prompting allows 100 terms
   and 500 tokens per request. Pink Garlic alone has 200+ items. You cannot
   boost a whole menu, so something has to choose, and choosing randomly
   wastes the budget on items nobody mishears.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class DishEntry:
    """One dish the library knows about."""

    canonical: str
    aliases: Tuple[str, ...] = ()
    # What a speech recogniser is likely to emit INSTEAD. Feed these to the
    # matcher as aliases so a misheard order still lands.
    mishears: Tuple[str, ...] = ()
    # Archetype ids this dish usually carries. A PROPOSAL, never a fact.
    implies: Tuple[str, ...] = ()
    category: str = "entree"


@dataclass(frozen=True)
class Archetype:
    """A modifier group shape that recurs across restaurants in a cuisine."""

    id: str
    name: str
    prompt: str
    # (option name, cents). 0 means "this cuisine usually includes it free" or
    # "price varies, must ask" — confirm_price says which.
    typical_options: Tuple[Tuple[str, int], ...] = ()
    min_select: int = 0
    max_select: int = 1
    confirm: str = ""          # what a human must check before this ships
    confirm_price: bool = False


@dataclass(frozen=True)
class CuisineProfile:
    id: str
    name: str
    dishes: Tuple[DishEntry, ...] = ()
    archetypes: Tuple[Archetype, ...] = ()
    # (lowercase substring found in menu text, archetype id it suggests)
    menu_signals: Tuple[Tuple[str, str], ...] = ()
    # Dish words that commonly appear in several proteins on one menu, so a
    # bare mention has to be disambiguated. Pink Garlic had thirteen.
    protein_split_dishes: Tuple[str, ...] = ()

    def dish(self, canonical: str) -> Optional[DishEntry]:
        for d in self.dishes:
            if d.canonical.lower() == canonical.lower():
                return d
        return None

    def archetype(self, aid: str) -> Optional[Archetype]:
        for a in self.archetypes:
            if a.id == aid:
                return a
        return None


# ---------------------------------------------------------------------------
# Cross-cuisine homophone traps
# ---------------------------------------------------------------------------
# These are not spelling variants. They are cases where the misheard form is
# itself a valid English word or a different menu item, so nothing downstream
# looks wrong — the order is simply incorrect. Each one is worth an explicit
# confirmation in the call.

HOMOPHONE_TRAPS: Tuple[Tuple[str, str, str], ...] = (
    ("naan", "none", "'two naan' and 'two, none' are the same audio. Always "
                     "confirm bread counts explicitly."),
    ("margherita", "margarita", "pizza vs cocktail. Harmless at a pizzeria "
                                "with no bar, order-breaking at one with."),
    ("penne", "penny", "'penne alfredo' reliably transcribes as 'penny'."),
    ("gyro", "hero", "also 'yee-ro' and 'jai-ro'. Three pronunciations, one "
                     "dish, and 'hero' is a different sandwich entirely."),
    ("pho", "foe", "also 'fuh'. Single syllable, very low confidence."),
    ("chai", "thai", "'chai tea' vs 'Thai tea' are different drinks and both "
                     "are plausible on an Asian menu."),
    ("no", "know", "negation words are the highest-cost transcription error "
                   "on the whole call: 'no onion' vs 'know onion'."),
    ("sprite", "spright", "short drink names have poor recall; boost them."),
)


# ---------------------------------------------------------------------------
# Shared archetypes
# ---------------------------------------------------------------------------


def _spice(levels: Tuple[str, ...], confirm: str) -> Archetype:
    return Archetype(
        id="spice_level", name="Spice Level",
        prompt="How spicy would you like that?",
        typical_options=tuple((l, 0) for l in levels),
        min_select=1, max_select=1, confirm=confirm)


_PROTEIN_SWAP = Archetype(
    id="protein_choice", name="Protein",
    prompt="Which protein would you like?",
    typical_options=(("Chicken", 0), ("Beef", 0), ("Pork", 0),
                     ("Shrimp", 0), ("Tofu", 0), ("Vegetable", 0)),
    min_select=1, max_select=1,
    confirm="Confirm which proteins this restaurant offers and which carry an "
            "upcharge — the upcharge is almost never on the printed menu.",
    confirm_price=True)

_BUNDLED_SIDES = Archetype(
    id="bundled_sides", name="Included Side",
    prompt="It comes with a side — which would you like?",
    typical_options=(("Rice", 0), ("Fries", 0), ("Salad", 0)),
    min_select=1, max_select=1,
    confirm="This is a REQUIRED, zero-cost choice, not an add-on. Look for "
            "'includes', 'served with', 'choice of' in the menu's fine print. "
            "Confirm whether any option carries an upgrade charge.",
    confirm_price=True)


# ---------------------------------------------------------------------------
# INDIAN
# ---------------------------------------------------------------------------

INDIAN = CuisineProfile(
    id="indian", name="Indian",
    protein_split_dishes=("korma", "vindaloo", "bhuna", "saag", "karahi",
                          "jalfrezi", "madras", "rogan josh", "tikka masala",
                          "curry", "biryani", "dansak", "balti", "achari",
                          "chettinad", "kadai", "masala"),
    dishes=(
        DishEntry("Butter Chicken", ("murgh makhani", "makhani", "butter chk"),
                  ("butter chicken", "butter chick in"), ("spice_level",)),
        DishEntry("Chicken Tikka Masala", ("tikka masala", "ctm"),
                  ("tika masala", "ticka masala", "tikka marsala",
                   "chicken tikka marsala"), ("spice_level",)),
        DishEntry("Korma", ("kurma",), ("korma", "coma", "karma"),
                  ("spice_level", "protein_choice")),
        DishEntry("Vindaloo", (), ("vin daloo", "windaloo", "vindalu"),
                  ("spice_level", "protein_choice")),
        DishEntry("Rogan Josh", ("rogan",), ("rogan josh", "rogen josh",
                                             "roganjosh"),
                  ("spice_level", "protein_choice")),
        DishEntry("Saag", ("palak", "spinach curry"), ("sag", "sog", "saab"),
                  ("spice_level", "protein_choice")),
        DishEntry("Jalfrezi", ("jalferzi",), ("jal frezi", "jelfrezi"),
                  ("spice_level", "protein_choice")),
        DishEntry("Bhuna", (), ("boona", "bhoona"),
                  ("spice_level", "protein_choice")),
        DishEntry("Madras", (), ("madras", "mattress"),
                  ("spice_level", "protein_choice")),
        DishEntry("Karahi", ("kadai", "kadhai"), ("karai", "korai"),
                  ("spice_level", "protein_choice")),
        DishEntry("Biryani", ("biriyani", "briyani"),
                  ("biryani", "brianni", "bar yani"),
                  ("spice_level", "protein_choice")),
        DishEntry("Chana Masala", ("chole", "chickpea curry"),
                  ("channa masala", "chana marsala"), ("spice_level",)),
        DishEntry("Paneer Tikka", ("paneer",), ("panir", "pan ear", "paneer"),
                  ("spice_level",)),
        DishEntry("Dal Makhani", ("dal", "daal", "lentils"),
                  ("doll makhani", "dahl"), ("spice_level",)),
        DishEntry("Garlic Naan", ("naan", "nan bread"),
                  ("garlic none", "garlic nan", "garlic non"),
                  (), "bread"),
        DishEntry("Plain Naan", ("naan",), ("none", "nan", "non"), (), "bread"),
        DishEntry("Roti", ("chapati", "chapatti"), ("rody", "roadie"),
                  (), "bread"),
        DishEntry("Samosa", ("samosas",), ("samosa", "sam osa", "some osa"),
                  (), "appetizer"),
        DishEntry("Pakora", ("bhaji", "fritters"), ("pakoda", "packora"),
                  (), "appetizer"),
        DishEntry("Raita", (), ("rye ta", "raita"), (), "side"),
        DishEntry("Mango Lassi", ("lassi",), ("lassie", "mango lassie"),
                  (), "drink"),
        DishEntry("Masala Chai", ("chai", "chai tea"),
                  ("thai tea", "chai tea", "shy"), (), "drink"),
        DishEntry("Gulab Jamun", (), ("gulab jamun", "goolab jamon"),
                  (), "dessert"),
        DishEntry("Tandoori Chicken", ("tandoori",), ("tandori", "tan doory"),
                  ("spice_level",)),
        DishEntry("Vegetable Biryani", ("veg biryani",), ("veg briyani",),
                  ("spice_level",)),
    ),
    archetypes=(
        _spice(("Mild", "Medium", "Hot", "Extra Hot"),
               "Spice scales vary a LOT. Pink Garlic runs six levels — Mild, "
               "Mild+, Med, Med+, Hot, X. Hot. Get the restaurant's exact "
               "ladder; do not assume three or four. Pairs that differ only "
               "by a '+' are a real phone-accuracy risk."),
        _PROTEIN_SWAP,
        Archetype(
            id="indian_addons", name="Add-ons",
            prompt="Anything on the side — rice, naan, raita?",
            typical_options=(("Extra Rice", 0), ("Naan", 0), ("Raita", 0),
                             ("Extra Gravy", 0), ("Papad", 0)),
            min_select=0, max_select=5,
            confirm="Add-on prices are rarely printed. Pink Garlic charged "
                    "$3.00 per extra protein and $2.00 for extra vegetable.",
            confirm_price=True),
        Archetype(
            id="included_rice", name="Included Rice",
            prompt="",
            typical_options=(("Rice", 0),),
            min_select=0, max_select=1,
            confirm="'Serve with Rice' on an Indian menu almost always means "
                    "the rice is INCLUDED and not chosen — model it as "
                    "informational so it reaches the kitchen ticket and Lily "
                    "never asks about it. Only make it a choice if the "
                    "restaurant actually offers rice OR naan."),
        Archetype(
            id="meat_preference", name="Preference",
            prompt="Would you like that bone-in or boneless?",
            typical_options=(("Goat (Bone In)", 0), ("Lamb (Boneless)", 0)),
            min_select=1, max_select=1,
            confirm="Appears on Lamb/Goat dishes at Indian restaurants that "
                    "sell them as one item. REQUIRED where present, and easy "
                    "to miss because it only shows on some items."),
    ),
    menu_signals=(
        ("serve with rice", "included_rice"),
        ("served with rice", "included_rice"),
        ("choice of spice", "spice_level"),
        ("level of spice", "spice_level"),
        ("mild", "spice_level"),
        ("lamb/goat", "meat_preference"),
        ("goat", "meat_preference"),
    ),
)


# ---------------------------------------------------------------------------
# MEXICAN
# ---------------------------------------------------------------------------

MEXICAN = CuisineProfile(
    id="mexican", name="Mexican",
    protein_split_dishes=("taco", "burrito", "quesadilla", "torta", "bowl",
                          "nachos", "enchiladas", "fajitas", "tamale"),
    dishes=(
        DishEntry("Taco", ("tacos", "street taco"), ("taco", "tako"),
                  ("protein_choice", "tortilla_choice")),
        DishEntry("Burrito", ("burritos",), ("burrito", "burito"),
                  ("protein_choice",)),
        DishEntry("Quesadilla", ("quesadillas",),
                  ("kesadilla", "kay sa dee ya", "quesa dia"),
                  ("protein_choice",)),
        DishEntry("Torta", ("mexican sandwich",), ("torta", "tortilla"),
                  ("protein_choice",)),
        DishEntry("Enchiladas", ("enchilada",), ("enchalada", "inchilada"),
                  ("protein_choice", "salsa_choice")),
        DishEntry("Fajitas", ("fajita",), ("fahitas", "fa jee tas"),
                  ("protein_choice",)),
        DishEntry("Tamale", ("tamales",), ("tamali", "ta molly"), ()),
        DishEntry("Carne Asada", ("asada", "steak"), ("carne asada", "carnay"),
                  ()),
        DishEntry("Al Pastor", ("pastor",), ("al pastore", "el pastor",
                                             "all pastor"), ()),
        DishEntry("Carnitas", (), ("car needas", "carnitas", "car neat as"),
                  ()),
        DishEntry("Barbacoa", (), ("barbacoa", "barbecue a"), ()),
        DishEntry("Pollo", ("chicken",), ("poyo", "polo"), ()),
        DishEntry("Camarones", ("shrimp", "camaron"), ("camarones",), ()),
        DishEntry("Chips and Guacamole", ("chips and guac", "guac"),
                  ("chips and wacka mole", "guacamole"), (), "appetizer"),
        DishEntry("Queso", ("cheese dip",), ("kay so", "queso"), (), "appetizer"),
        DishEntry("Elote", ("mexican street corn", "street corn"),
                  ("eh lo tay",), (), "side"),
        DishEntry("Horchata", (), ("orchata", "or chata", "hor chata"),
                  (), "drink"),
        DishEntry("Jarritos", (), ("haritos", "jaritos"), (), "drink"),
        DishEntry("Churros", ("churro",), ("cheros", "churos"), (), "dessert"),
        DishEntry("Jalapeño", ("jalapenos", "jalapeno"),
                  ("halapeno", "hala pain yo"), (), "modifier"),
        DishEntry("Pico de Gallo", ("pico",), ("peako de guy oh", "pico"),
                  (), "modifier"),
    ),
    archetypes=(
        _PROTEIN_SWAP,
        Archetype(
            id="tortilla_choice", name="Tortilla",
            prompt="Corn or flour tortilla?",
            typical_options=(("Corn", 0), ("Flour", 0)),
            min_select=1, max_select=1,
            confirm="Usually required and usually free. Confirm whether flour "
                    "carries an upcharge."),
        Archetype(
            id="salsa_choice", name="Salsa",
            prompt="Any salsa?",
            typical_options=(("Salsa Verde", 0), ("Salsa Roja", 0),
                             ("Pico de Gallo", 0), ("Habanero", 0),
                             ("Crema", 0)),
            min_select=0, max_select=5,
            confirm="Many taquerias give the first one or two free and charge "
                    "after. If so that is free_select, not a flat price.",
            confirm_price=True),
        Archetype(
            id="included_rice_beans", name="Included",
            prompt="",
            typical_options=(("Rice", 0), ("Beans", 0)),
            min_select=0, max_select=2,
            confirm="If rice and beans come with the burrito and cannot be "
                    "chosen, model as informational so it reaches the ticket "
                    "but Lily never asks."),
    ),
    menu_signals=(
        ("choice of meat", "protein_choice"),
        ("choice of protein", "protein_choice"),
        ("corn or flour", "tortilla_choice"),
        ("served with rice and beans", "included_rice_beans"),
        ("add guacamole", "salsa_choice"),
    ),
)


# ---------------------------------------------------------------------------
# MEDITERRANEAN
# ---------------------------------------------------------------------------

MEDITERRANEAN = CuisineProfile(
    id="mediterranean", name="Mediterranean",
    protein_split_dishes=("kabob", "kebab", "plate", "wrap", "shawarma",
                          "platter"),
    dishes=(
        DishEntry("Gyro", ("gyros",), ("hero", "yeero", "jai ro", "jiro",
                                       "euro"), ("bundled_sides",)),
        DishEntry("Chicken Kabob", ("chicken kebab", "shish tawook"),
                  ("chicken ka bob", "chicken kebob"), ("bundled_sides",)),
        DishEntry("Beef Koobideh", ("koobideh", "kubideh", "ground beef kebab"),
                  ("koo bee day", "kubeda"), ("bundled_sides",)),
        DishEntry("Shawarma", (), ("shwarma", "schwarma", "shu warma"),
                  ("bundled_sides",)),
        DishEntry("Falafel", (), ("felafel", "fallafel", "fa la fel"),
                  ("bundled_sides",)),
        DishEntry("Hummus", (), ("humus", "hoomus"), (), "appetizer"),
        DishEntry("Baba Ganoush", ("baba",), ("baba ganush", "baba ga noosh"),
                  (), "appetizer"),
        DishEntry("Tabbouleh", ("tabouli",), ("ta boo lee",), (), "salad"),
        DishEntry("Fattoush", (), ("fa toosh", "fattush"), (), "salad"),
        DishEntry("Dolma", ("grape leaves", "stuffed grape leaves"),
                  ("dolmas",), (), "appetizer"),
        DishEntry("Tzatziki", ("cucumber sauce", "white sauce"),
                  ("zat ziki", "sat seeky", "tzatziki"), (), "modifier"),
        DishEntry("Toum", ("garlic sauce",), ("tomb", "toom"), (), "modifier"),
        DishEntry("Lentil Soup", ("soup",), ("lentil soup",), (), "soup"),
        DishEntry("Pita", ("pita bread",), ("peter", "pitta"), (), "bread"),
        DishEntry("Baklava", (), ("bak lava", "back lava"), (), "dessert"),
        DishEntry("Ayran", ("yogurt drink",), ("i ran", "eye ron"), (), "drink"),
        DishEntry("Rice Pilaf", ("rice", "pilaf"), ("pilaf", "pee laf"),
                  (), "side"),
    ),
    archetypes=(
        _BUNDLED_SIDES,
        Archetype(
            id="bundled_starter", name="Included Starter",
            prompt="And it comes with a salad or soup — which would you like?",
            typical_options=(("House Salad", 0), ("Soup", 0)),
            min_select=1, max_select=1,
            confirm="Mediterranean plates very often bundle TWO required "
                    "zero-cost choices — a side AND a starter. Sam's Kabob's "
                    "menu says 'all entrees include rice or fries, salad or "
                    "soup' in one line of fine print. Miss it and every plate "
                    "goes to the kitchen incomplete."),
        Archetype(
            id="sauce_choice", name="Sauces",
            prompt="Any sauces?",
            typical_options=(("Tzatziki", 0), ("Garlic Sauce", 0),
                             ("Hot Sauce", 0), ("Tahini", 0)),
            min_select=0, max_select=4,
            confirm="Usually free in the plate, usually charged as an extra "
                    "cup. Confirm the cup price.",
            confirm_price=True),
    ),
    menu_signals=(
        ("all entrees include", "bundled_sides"),
        ("includes", "bundled_sides"),
        ("served with", "bundled_sides"),
        ("choice of", "bundled_sides"),
        ("rice or fries", "bundled_sides"),
        ("salad or soup", "bundled_starter"),
        ("comes with", "bundled_sides"),
    ),
)


# ---------------------------------------------------------------------------
# JAPANESE / SUSHI
# ---------------------------------------------------------------------------

JAPANESE = CuisineProfile(
    id="japanese", name="Japanese / Sushi",
    protein_split_dishes=("roll", "nigiri", "sashimi", "bowl", "don", "ramen"),
    dishes=(
        DishEntry("California Roll", ("cali roll",), ("california roll",), ()),
        DishEntry("Spicy Tuna Roll", ("spicy tuna",), ("spicy tuna roll",), ()),
        DishEntry("Dragon Roll", ("dragon",), ("dragon roll",), ()),
        DishEntry("Rainbow Roll", ("rainbow",), ("rainbow roll",), ()),
        DishEntry("Philadelphia Roll", ("philly roll", "philly"),
                  ("philadelphia roll",), ()),
        DishEntry("Salmon", ("sake",), ("salmon", "sammon"), ()),
        DishEntry("Tuna", ("maguro",), ("tuna",), ()),
        DishEntry("Yellowtail", ("hamachi",), ("yellow tail", "hama chi"), ()),
        DishEntry("Eel", ("unagi",), ("una gee", "you nagi"), ()),
        DishEntry("Uni", ("sea urchin",), ("oo nee", "you knee"), ()),
        DishEntry("Chirashi", ("chirashi bowl", "sashimi bowl"),
                  ("cheer ashi", "chi rashi"), ()),
        DishEntry("Poke Bowl", ("poke",), ("poki", "pokey", "poke ay"),
                  ("bowl_base", "protein_choice")),
        DishEntry("Ramen", (), ("ramen", "rah men"), ()),
        DishEntry("Udon", (), ("oo don", "you don"), ()),
        DishEntry("Katsu", ("tonkatsu", "chicken katsu"), ("cutlet", "cat su"),
                  ()),
        DishEntry("Teriyaki", (), ("terry yaki", "teri yaki"),
                  ("protein_choice",)),
        DishEntry("Edamame", (), ("edamamay", "edema me", "eda mame"),
                  (), "appetizer"),
        DishEntry("Gyoza", ("dumplings", "potstickers"),
                  ("gyoza", "goyza", "gee oza"), (), "appetizer"),
        DishEntry("Miso Soup", ("miso",), ("mee so", "miso"), (), "soup"),
        DishEntry("Wasabi", (), ("wa sabi", "wasabe"), (), "modifier"),
        DishEntry("Tempura", (), ("tem pura", "tempora"), ()),
        DishEntry("Green Tea", ("tea", "ocha"), ("green tea",), (), "drink"),
    ),
    archetypes=(
        Archetype(
            id="choose_n_rolls", name="Choose Your Rolls",
            prompt="Which rolls would you like?",
            typical_options=(),
            min_select=3, max_select=3,
            confirm="Boats, combos and party trays are 'choose exactly N of "
                    "M'. Confirm N, and confirm which picks carry an upcharge "
                    "— premium rolls usually do.",
            confirm_price=True),
        Archetype(
            id="bowl_base", name="Base",
            prompt="White rice, brown rice, or over salad?",
            typical_options=(("White Rice", 0), ("Brown Rice", 0),
                             ("Salad", 0)),
            min_select=1, max_select=1,
            confirm="Brown rice commonly carries a small upcharge.",
            confirm_price=True),
        Archetype(
            id="sushi_prefs", name="Preferences",
            prompt="Anything to leave off?",
            typical_options=(("No Wasabi", 0), ("Extra Ginger", 0),
                             ("Sauce on the Side", 0)),
            min_select=0, max_select=4,
            confirm="Free preferences. Worth modelling because callers say "
                    "them unprompted and they must reach the ticket."),
        _PROTEIN_SWAP,
    ),
    menu_signals=(
        ("choose any", "choose_n_rolls"),
        ("pick any", "choose_n_rolls"),
        ("choice of 3", "choose_n_rolls"),
        ("your choice of", "choose_n_rolls"),
        ("brown rice", "bowl_base"),
        ("boat", "choose_n_rolls"),
        ("combo", "choose_n_rolls"),
    ),
)


# ---------------------------------------------------------------------------
# KOREAN
# ---------------------------------------------------------------------------

KOREAN = CuisineProfile(
    id="korean", name="Korean",
    protein_split_dishes=("bibimbap", "jjigae", "bowl", "plate", "bulgogi"),
    dishes=(
        DishEntry("Bibimbap", ("bibim bap",),
                  ("bee bim bop", "bibim bop", "big im bop"),
                  ("protein_choice", "spice_level")),
        DishEntry("Bulgogi", ("bbq beef",), ("bull go gi", "bulgoki",
                                             "bull gogi"), ()),
        DishEntry("Galbi", ("kalbi", "short ribs"), ("gal bee", "kal bee"), ()),
        DishEntry("Japchae", ("glass noodles",),
                  ("jap chay", "chop che", "jop chae"), ()),
        DishEntry("Kimchi Jjigae", ("kimchi stew", "kimchi soup"),
                  ("kimchi chi gay", "kim chee jigae"), ("spice_level",)),
        DishEntry("Sundubu", ("soft tofu stew", "soondubu"),
                  ("soon doo boo",), ("spice_level",)),
        DishEntry("Tteokbokki", ("rice cakes", "ddeokbokki", "topokki"),
                  ("duck bokki", "took boki", "dukbokki"), ("spice_level",)),
        DishEntry("Korean Fried Chicken", ("kfc", "fried chicken"),
                  ("korean fried chicken",), ("kfc_sauce",)),
        DishEntry("Mandu", ("dumplings",), ("man do", "mando"),
                  (), "appetizer"),
        DishEntry("Kimchi", (), ("kim chee", "kimchi"), (), "side"),
        DishEntry("Banchan", ("side dishes",), ("ban chan", "bahn chan"),
                  (), "side"),
        DishEntry("Bibim Naengmyeon", ("cold noodles", "naengmyeon"),
                  ("neng myun",), ()),
        DishEntry("Haemul Pajeon", ("seafood pancake", "pajeon"),
                  ("pa jun", "pajun"), (), "appetizer"),
        DishEntry("Soju", (), ("so ju",), (), "drink"),
        DishEntry("Barley Tea", ("boricha", "tea"), ("bori cha",), (), "drink"),
    ),
    archetypes=(
        _PROTEIN_SWAP,
        _spice(("Mild", "Medium", "Spicy", "Extra Spicy"),
               "Korean spice ladders are usually shorter than Indian ones. "
               "Confirm the exact names the restaurant uses."),
        Archetype(
            id="banchan_included", name="Banchan (included)",
            prompt="",
            typical_options=(("Kimchi", 0), ("Bean Sprouts", 0),
                             ("Pickled Radish", 0)),
            min_select=0, max_select=6,
            confirm="Banchan is included and not chosen. Model as "
                    "informational: it reaches the ticket, Lily never asks, "
                    "and it is never priced."),
        Archetype(
            id="kfc_sauce", name="Sauce",
            prompt="Soy garlic, sweet and spicy, or plain?",
            typical_options=(("Soy Garlic", 0), ("Yangnyeom", 0), ("Plain", 0),
                             ("Half & Half", 0)),
            min_select=1, max_select=1,
            confirm="Half-and-half commonly carries a small upcharge. Portion "
                    "sizes (8 pc / 16 pc) are a SIZE axis, not a modifier.",
            confirm_price=True),
    ),
    menu_signals=(
        ("banchan", "banchan_included"),
        ("served with side dishes", "banchan_included"),
        ("soy garlic", "kfc_sauce"),
        ("choice of sauce", "kfc_sauce"),
        ("spicy", "spice_level"),
    ),
)


# ---------------------------------------------------------------------------
# BURGER
# ---------------------------------------------------------------------------

BURGER = CuisineProfile(
    id="burger", name="Burger / American",
    protein_split_dishes=("burger", "cheeseburger", "single", "double",
                          "fries", "shake"),
    dishes=(
        DishEntry("Cheeseburger", ("cheese burger",), ("cheeseburger",),
                  ("toppings_default", "combo_upgrade")),
        DishEntry("Hamburger", ("burger", "plain burger"), ("hamburger",),
                  ("toppings_default", "combo_upgrade")),
        DishEntry("Double Cheeseburger", ("double with cheese",),
                  ("double cheeseburger",),
                  ("toppings_default", "combo_upgrade")),
        DishEntry("Bacon Cheeseburger", ("bacon burger",),
                  ("bacon cheeseburger",),
                  ("toppings_default", "combo_upgrade")),
        DishEntry("Patty Melt", (), ("patty melt", "paddy melt"), ()),
        DishEntry("Chicken Sandwich", ("chicken burger",),
                  ("chicken sandwich",), ("toppings_default", "combo_upgrade")),
        DishEntry("Veggie Burger", ("veggie", "black bean burger"),
                  ("veggie burger",), ("toppings_default",)),
        DishEntry("French Fries", ("fries", "regular fries"),
                  ("french fries",), (), "side"),
        DishEntry("Onion Rings", ("rings",), ("onion rings",), (), "side"),
        DishEntry("Tater Tots", ("tots",), ("tater tots", "taters"),
                  (), "side"),
        DishEntry("Milkshake", ("shake",), ("milkshake", "milk shake"),
                  (), "drink"),
        DishEntry("Fountain Drink", ("soda", "pop", "coke", "drink"),
                  ("fountain drink",), (), "drink"),
    ),
    archetypes=(
        Archetype(
            id="toppings_default", name="Toppings",
            prompt="Any changes to the toppings?",
            typical_options=(("Lettuce", 0), ("Tomato", 0), ("Onion", 0),
                             ("Pickle", 0), ("Ketchup", 0), ("Mustard", 0),
                             ("Mayo", 0), ("Cheese", 0), ("Bacon", 0)),
            min_select=0, max_select=12,
            confirm="Which toppings are ON by default is per-item, not "
                    "per-restaurant — cheeseburgers default to cheese and "
                    "hamburgers do not. Confirm the default list for each "
                    "burger, and the price of paid additions like bacon.",
            confirm_price=True),
        Archetype(
            id="combo_upgrade", name="Combo",
            prompt="Would you like to make that a combo?",
            typical_options=(("Make it a Combo", 0),),
            min_select=0, max_select=1,
            confirm="Ask TWO things: what the upcharge is, and whether the "
                    "combo lets the caller choose a side and drink. If it "
                    "does, that is a reveal group with two required children. "
                    "Also ask the POS side — Toast models a combo as a "
                    "separate item GUID, not as a modifier.",
            confirm_price=True),
    ),
    menu_signals=(
        ("combo", "combo_upgrade"),
        ("make it a meal", "combo_upgrade"),
        ("with fries and a drink", "combo_upgrade"),
        ("lettuce", "toppings_default"),
        ("add bacon", "toppings_default"),
    ),
)


# ---------------------------------------------------------------------------
# PIZZA
# ---------------------------------------------------------------------------

PIZZA = CuisineProfile(
    id="pizza", name="Pizza",
    protein_split_dishes=("pizza", "pie", "calzone", "stromboli"),
    dishes=(
        DishEntry("Margherita", ("margherita pizza",),
                  ("margarita", "margarita pizza", "marguerita"),
                  ("pizza_size", "crust_choice", "pizza_toppings")),
        DishEntry("Pepperoni Pizza", ("pepperoni",),
                  ("peperoni", "pepperoni", "pepper only"),
                  ("pizza_size", "crust_choice", "pizza_toppings")),
        DishEntry("Cheese Pizza", ("plain pizza", "just cheese"),
                  ("cheese pizza",),
                  ("pizza_size", "crust_choice", "pizza_toppings")),
        DishEntry("Supreme", ("the works", "deluxe"), ("supreme",),
                  ("pizza_size", "crust_choice")),
        DishEntry("Meat Lovers", ("meat lover's",), ("meat lovers",),
                  ("pizza_size", "crust_choice")),
        DishEntry("White Pizza", ("bianca",), ("white pizza",),
                  ("pizza_size", "crust_choice")),
        DishEntry("Calzone", (), ("cal zone", "calzone"), ()),
        DishEntry("Stromboli", (), ("strom boli",), ()),
        DishEntry("Garlic Knots", ("knots",), ("garlic knots",),
                  (), "appetizer"),
        DishEntry("Wings", ("chicken wings", "buffalo wings"), ("wings",),
                  (), "appetizer"),
        DishEntry("Ranch", ("ranch cup",), ("ranch",), (), "modifier"),
    ),
    archetypes=(
        Archetype(
            id="pizza_size", name="Size",
            prompt="What size — small, medium, or large?",
            typical_options=(('10" Small', 0), ('14" Medium', 0),
                             ('18" Large', 0)),
            min_select=1, max_select=1,
            confirm="Size is a PRICE AXIS, not a modifier — and it changes "
                    "what toppings cost too. Get the topping price at every "
                    "size, not just one.",
            confirm_price=True),
        Archetype(
            id="crust_choice", name="Crust",
            prompt="What crust would you like?",
            typical_options=(("Regular", 0), ("Thin", 0), ("Deep Dish", 0),
                             ("Gluten Free", 0)),
            min_select=1, max_select=1,
            confirm="Speciality crusts are often NOT made at every size — "
                    "gluten free frequently stops at medium. Ask which sizes "
                    "each crust is available in, and what each costs.",
            confirm_price=True),
        Archetype(
            id="pizza_toppings", name="Toppings",
            prompt="What would you like on it?",
            typical_options=(("Pepperoni", 0), ("Sausage", 0), ("Mushrooms", 0),
                             ("Onions", 0), ("Green Peppers", 0),
                             ("Black Olives", 0), ("Extra Cheese", 0)),
            min_select=0, max_select=14,
            confirm="Three separate questions: (1) price per topping AT EACH "
                    "SIZE; (2) can a topping go on half — and is a half "
                    "topping half price or full price; (3) can a topping be "
                    "doubled, and is double charged twice.",
            confirm_price=True),
    ),
    menu_signals=(
        ("half and half", "pizza_toppings"),
        ("additional toppings", "pizza_toppings"),
        ("each topping", "pizza_toppings"),
        ("gluten free", "crust_choice"),
        ("thin crust", "crust_choice"),
        ("small", "pizza_size"),
        ('12"', "pizza_size"),
        ("3 topping", "pizza_toppings"),
    ),
)


# ---------------------------------------------------------------------------
# ITALIAN
# ---------------------------------------------------------------------------

ITALIAN = CuisineProfile(
    id="italian", name="Italian / Pasta",
    protein_split_dishes=("pasta", "parmigiana", "parm", "alfredo", "marinara"),
    dishes=(
        DishEntry("Spaghetti", (), ("spagetti", "spa getty"),
                  ("pasta_shape", "pasta_sauce")),
        DishEntry("Penne", (), ("penny", "pen nay", "penne"),
                  ("pasta_shape", "pasta_sauce")),
        DishEntry("Fettuccine Alfredo", ("alfredo", "fettuccine"),
                  ("fettucini alfredo", "fetuccini", "fet a cheeny"),
                  ("pasta_shape",)),
        DishEntry("Rigatoni", (), ("riga toni", "rigatoni"),
                  ("pasta_shape", "pasta_sauce")),
        DishEntry("Gnocchi", (), ("nyoki", "nokki", "gnocci", "no key"),
                  ("pasta_sauce",)),
        DishEntry("Lasagna", ("lasagne",), ("lasagna", "la zanya"), ()),
        DishEntry("Chicken Parmigiana", ("chicken parm", "chicken parmesan"),
                  ("chicken parmajana", "chicken parm"), ()),
        DishEntry("Eggplant Parmigiana", ("eggplant parm",),
                  ("eggplant parmesan",), ()),
        DishEntry("Carbonara", (), ("carbo nara", "car bonara"),
                  ("pasta_shape",)),
        DishEntry("Bolognese", ("meat sauce",),
                  ("bolognaise", "bologna", "baloney's"), (), "modifier"),
        DishEntry("Marinara", ("red sauce", "tomato sauce"), ("marinara",),
                  (), "modifier"),
        DishEntry("Pesto", (), ("pesto", "presto"), (), "modifier"),
        DishEntry("Bruschetta", (), ("brusketta", "brushetta", "bru shetta"),
                  (), "appetizer"),
        DishEntry("Caprese", (), ("ca pray zay", "capreesy"), (), "salad"),
        DishEntry("Caesar Salad", ("caesar",), ("seizure salad", "cesar"),
                  (), "salad"),
        DishEntry("Garlic Bread", ("bread",), ("garlic bread",),
                  (), "appetizer"),
        DishEntry("Tiramisu", (), ("tirimisu", "tira mi su"), (), "dessert"),
        DishEntry("Cannoli", ("cannolis",), ("canoli", "ca noli"),
                  (), "dessert"),
        DishEntry("Prosciutto", (), ("proshooto", "prosciutto", "pro shoot oh"),
                  (), "modifier"),
    ),
    archetypes=(
        Archetype(
            id="pasta_shape", name="Pasta",
            prompt="Which pasta would you like?",
            typical_options=(("Spaghetti", 0), ("Penne", 0),
                             ("Fettuccine", 0), ("Rigatoni", 0),
                             ("Gluten Free", 0)),
            min_select=1, max_select=1,
            confirm="Usually required and free, except gluten free which "
                    "usually carries an upcharge.",
            confirm_price=True),
        Archetype(
            id="pasta_sauce", name="Sauce",
            prompt="And which sauce?",
            typical_options=(("Marinara", 0), ("Alfredo", 0), ("Bolognese", 0),
                             ("Pesto", 0), ("Vodka", 0), ("Aglio e Olio", 0)),
            min_select=1, max_select=1,
            confirm="Meat and speciality sauces usually cost more than the "
                    "plain ones. Get each price, not one price.",
            confirm_price=True),
        Archetype(
            id="italian_addons", name="Add Protein",
            prompt="Would you like to add chicken, shrimp, or meatballs?",
            typical_options=(("Grilled Chicken", 0), ("Shrimp", 0),
                             ("Meatballs", 0), ("Italian Sausage", 0)),
            min_select=0, max_select=4,
            confirm="Confirm each price and whether meatballs are sold by the "
                    "piece (stackable) or as one portion.",
            confirm_price=True),
        Archetype(
            id="portion_size", name="Portion",
            prompt="Lunch or dinner portion?",
            typical_options=(("Lunch", 0), ("Dinner", 0), ("Family", 0)),
            min_select=1, max_select=1,
            confirm="A price axis, like pizza size. Confirm which portions "
                    "exist and whether lunch is time-restricted — a "
                    "time-limited portion needs handling the engine does not "
                    "have yet.",
            confirm_price=True),
    ),
    menu_signals=(
        ("choice of pasta", "pasta_shape"),
        ("your choice of sauce", "pasta_sauce"),
        ("add chicken", "italian_addons"),
        ("lunch portion", "portion_size"),
        ("family size", "portion_size"),
        ("gluten free", "pasta_shape"),
    ),
)

# American diner / family restaurant — the most common independent genre in
# Metro Detroit and absent from the library until a Copper Kettle onboarding
# rehearsal needed it (2026-09-30). Breadth over depth: diners sell 100+
# one-off specials, so the profile's job is the recurring SHAPES (eggs, toast,
# sides, doneness) and the dishes whose names callers actually say.
AMERICAN = CuisineProfile(
    id="american", name="American Diner",
    dishes=(
        DishEntry("Pancakes", ("pancake", "hotcakes", "flapjacks"),
                  ("pan cakes", "pancackes"), (), "entree"),
        DishEntry("French Toast", ("french toast",),
                  ("french toast", "french tost"), (), "entree"),
        DishEntry("Waffle", ("belgian waffle", "waffles"),
                  ("waffle", "wafile"), (), "entree"),
        DishEntry("Omelet", ("omelette", "omelets"),
                  ("omlet", "omelette", "aumlet"), ("omelet_fill",)),
        DishEntry("Eggs Any Style", ("two eggs", "eggs"),
                  ("eggs",), (), "entree"),
        DishEntry("Benedict", ("eggs benedict", "benny"),
                  ("benedict", "ben edict", "benny"), ()),
        DishEntry("Breakfast Sandwich", ("breakfast sandwich",),
                  ("breakfast samwich",), (), "entree"),
        DishEntry("Breakfast Bowl", ("breakfast bowl", "scramble bowl"),
                  ("breakfast bowl",), ("omelet_fill",)),
        DishEntry("Corned Beef Hash", ("corned beef hash",),
                  ("corn beef hash",), ()),
        DishEntry("Bacon", ("side bacon", "bacon strips"), ("bacon",),
                  (), "side"),
        DishEntry("Sausage Links", ("sausage", "links"), ("sausage links",),
                  (), "side"),
        DishEntry("Hash Browns", ("hashbrowns",),
                  ("hash browns", "shredded has browns"), (), "side"),
        DishEntry("Home Fries", ("redskins", "breakfast potatoes"),
                  ("home fries", "homefries"), (), "side"),
        DishEntry("Toast", ("side toast",), ("toast",), ("toast_kind",),
                  "side"),
        DishEntry("BLT", (), ("bee el tee",), (), "entree"),
        DishEntry("Club Sandwich", ("club", "triple decker"),
                  ("club", "triple decker"), (), "entree"),
        DishEntry("Patty Melt", (), ("paddy melt",), ()),
        DishEntry("Reuben", (), ("ruby", "reubin"), ()),
        DishEntry("Tuna Melt", (), ("tuna melt",), ()),
        DishEntry("Grilled Cheese", ("grilled cheese sandwich",),
                  ("grilled cheese", "grill cheese"), ()),
        DishEntry("Soup of the Day", ("soup",), ("soup",), (), "appetizer"),
        DishEntry("Chili", ("chili bowl",), ("chili", "chilli"), (),
                  "appetizer"),
        DishEntry("House Salad", ("garden salad", "side salad"),
                  ("house salad",), ("dressing",), "salad"),
        DishEntry("Caesar Salad", ("caesar",), ("seizure salad", "caesar"),
                  ("dressing",), "salad"),
        DishEntry("Cheeseburger", ("cheese burger",),
                  ("cheese burger", "chesseburger"), ("burger_toppings",)),
        DishEntry("Hamburger", ("burger", "plain burger"),
                  ("hamburger", "ham burger"), ("burger_toppings",)),
        DishEntry("Onion Rings", ("onion rings",), ("onion rings",),
                  (), "side"),
        DishEntry("French Fries", ("fries",), ("french fries", "fries"),
                  (), "side"),
        DishEntry("Chicken Tenders", ("tenders", "chicken fingers"),
                  ("chicken tenders", "chicken FINGERS"), (), "entree"),
        DishEntry("Quesadilla", (), ("casadia", "quesadilla"), ()),
        DishEntry("Wrap", ("chicken wrap",), ("wrap",), (), "entree"),
        DishEntry("Meatloaf", (), ("meat loaf",), ()),
        DishEntry("Pot Roast", (), ("pot roast",), ()),
        DishEntry("Broasted Chicken", ("broasted",),
                  ("broasted chicken", "broil stewed chicken"), ()),
        DishEntry("Cheesecake", (), ("cheese cake",), (), "dessert"),
        DishEntry("Apple Pie", ("pie",), ("apple pie",), (), "dessert"),
        DishEntry("Rice Pudding", (), ("rice pudding",), (), "dessert"),
        DishEntry("Iced Tea", ("iced tea",), ("ice tea", "iced tea"),
                  (), "drink"),
        DishEntry("Lemonade", (), ("lemonade", "lemon aid"), (), "drink"),
        DishEntry("Coffee", ("coffee",), ("coffee", "cup of joe"), (),
                  "drink"),
        DishEntry("Milkshake", ("shake",), ("milkshake", "shake"), (),
                  "drink"),
    ),
    archetypes=(
        Archetype(
            id="egg_style", name="Eggs",
            prompt="How would you like your eggs?",
            typical_options=(("Scrambled", 0), ("Over Easy", 0),
                             ("Over Hard", 0), ("Sunny Side Up", 0),
                             ("Poached", 0)),
            confirm="Confirm the egg styles this kitchen actually cooks.",
        ),
        Archetype(
            id="toast_kind", name="Toast",
            prompt="What kind of toast?",
            typical_options=(("White", 0), ("Wheat", 0), ("Rye", 0),
                             ("Sourdough", 0), ("English Muffin", 0)),
            confirm="Confirm the breads this kitchen actually stocks.",
        ),
        Archetype(
            id="omelet_fill", name="Omelet fillings",
            prompt="What would you like in the omelet?",
            typical_options=(("Cheese", 0), ("Ham", 0), ("Bacon", 0),
                             ("Mushrooms", 0), ("Onions", 0),
                             ("Peppers", 0), ("Spinach", 0), ("Tomato", 0)),
            min_select=0, max_select=4,
            confirm="Fillings are priced per the menu; confirm the price "
                    "with the owner before shipping.",
            confirm_price=True,
        ),
        Archetype(
            id="burger_toppings", name="Burger toppings",
            prompt="Any changes to the toppings?",
            typical_options=(("Lettuce", 0), ("Tomato", 0), ("Onion", 0),
                             ("Pickles", 0), ("Bacon", 0),
                             ("Extra Cheese", 0)),
            min_select=0, max_select=5,
            confirm="Toppings and their prices must match this restaurant's "
                    "burger menu; diners differ on what is free.",
            confirm_price=True,
        ),
        Archetype(
            id="dressing", name="Salad dressing",
            prompt="What dressing would you like?",
            typical_options=(("Ranch", 0), ("Italian", 0), ("Vinaigrette", 0),
                             ("Bleu Cheese", 0), ("Thousand Island", 0)),
            confirm="Confirm the dressings on this restaurant's menu.",
        ),
        Archetype(
            id="portion_size", name="Portion",
            prompt="Half or full order?",
            typical_options=(("Half", 0), ("Full", 0)),
            confirm="Half/full prices differ per item; confirm each with "
                    "the owner.",
            confirm_price=True,
        ),
    ),
    menu_signals=(
        ("two eggs", "egg_style"),
        ("any style", "egg_style"),
        ("choice of toast", "toast_kind"),
        ("white, wheat", "toast_kind"),
        ("build your own omelet", "omelet_fill"),
        ("half / full", "portion_size"),
        ("add chicken", "burger_toppings"),
        ("choice of dressing", "dressing"),
    ),
)


# ---------------------------------------------------------------------------

CUISINES: Dict[str, CuisineProfile] = {
    c.id: c for c in (INDIAN, MEXICAN, MEDITERRANEAN, JAPANESE, KOREAN,
                      BURGER, PIZZA, ITALIAN, AMERICAN)
}


def all_mishears(cuisine_id: str) -> Dict[str, str]:
    """{misheard form: canonical dish} for one cuisine."""
    prof = CUISINES[cuisine_id]
    out: Dict[str, str] = {}
    for d in prof.dishes:
        for m in d.mishears:
            out.setdefault(m.lower(), d.canonical)
    return out


def suggested_aliases(cuisine_id: str, item_name: str) -> Tuple[str, ...]:
    """Aliases the library would attach to an item with this name.

    Matches on the dish the name contains, so '29. Butter Chk. (Creamy)'
    still finds Butter Chicken.
    """
    prof = CUISINES.get(cuisine_id)
    if prof is None:
        return ()
    lowered = item_name.lower()
    # Keep only the MOST SPECIFIC dish that matches. "Plain Naan" matches both
    # the Naan entry and (via the alias "naan") the Garlic Naan entry; without
    # this it inherited "garlic none" as an alias and would have stolen garlic
    # naan orders.
    best_len = 0
    best: List[DishEntry] = []
    for d in prof.dishes:
        for key in (d.canonical,) + d.aliases:
            k = key.lower()
            if not re.search(r"\b" + re.escape(k) + r"\b", lowered):
                continue
            if len(k) > best_len:
                best_len, best = len(k), [d]
            elif len(k) == best_len and d not in best:
                best.append(d)
            break
    found: List[str] = []
    for d in best:
        found.extend(d.aliases)
        found.extend(d.mishears)
    # de-dupe, drop anything already in the name itself
    seen, out = set(), []
    for a in found:
        al = a.lower()
        if al in seen or al == lowered:
            continue
        seen.add(al)
        out.append(a)
    return tuple(out)
