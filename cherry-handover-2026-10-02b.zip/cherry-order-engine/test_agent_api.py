#!/usr/bin/env python3
"""
Tests for the tool surface the voice layer calls.

These are the tests that protect the integration contract. If the Inworld team
builds against TOOL_SCHEMAS and a method signature drifts, the failure shows up
here rather than on a live call.
"""

from __future__ import annotations

import inspect
import json
from pathlib import Path

import menu_schema as ms
from agent_api import TOOL_SCHEMAS, CallSession

MENUS = Path(__file__).parent / "menus"

_passed, _failed = 0, 0


def check(name: str, cond: bool, detail: str = "") -> None:
    global _passed, _failed
    if cond:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


def load(stem: str):
    return ms.load_yaml(MENUS / f"{stem}.yaml")


ENVELOPE_KEYS = {"ok", "say", "action", "needs", "order", "error"}
ORDER_KEYS = {"lines", "subtotal_cents", "tax_cents", "total_cents",
              "payment_mode", "submittable"}


def _settle(s, limit: int = 8) -> None:
    """Answer whatever the engine is asking, taking the first valid option.

    Bounded on purpose: an unbounded version hangs when an answer cannot be
    applied, and a test that hangs tells you nothing.
    """
    for _ in range(limit):
        issue = s.pending()
        if issue is None or not issue.candidates:
            return
        opt = s.config.option(issue.candidates[0])
        before = issue.group_id
        s.answer(opt.name if opt else issue.candidates[0])
        nxt = s.pending()
        if nxt is not None and nxt.group_id == before:
            return   # that answer did not stick; stop rather than spin


def t_every_tool_returns_the_same_envelope() -> None:
    s = CallSession(load("bun-n-run-ferndale"))
    calls = [
        s.greeting(),
        s.search_menu(),
        s.add_item("a double cheeseburger"),
        s.confirm_mods(),
        s.add_modifier("bacon"),
        s.remove_modifier("onion"),
        s.set_quantity(2),
        s.split_line(),
        s.read_back(),
        s.ready_to_place(),
        s.remove_item(),
        # every failure path too — a failure is still an envelope
        s.add_item("sushi"),
        s.answer("medium"),
        s.remove_modifier("nothing"),
        s.set_quantity(3),
    ]
    for r in calls:
        check(f"envelope from {r.get('action')}",
              set(r) - {"retryable"} == ENVELOPE_KEYS, str(sorted(r)))
        check(f"a failure from {r.get('action')} says whether to retry, a success does not",
              ("retryable" in r) == (not r["ok"]), str(sorted(r)))
        check(f"order block from {r.get('action')}",
              set(r["order"]) == ORDER_KEYS, str(sorted(r["order"])))
        check(f"say is never empty ({r.get('action')})",
              isinstance(r["say"], str) and r["say"].strip() != "")
        check(f"envelope is JSON-serialisable ({r.get('action')})",
              json.dumps(r) is not None)


def t_a_failure_is_never_silent() -> None:
    s = CallSession(load("bun-n-run-ferndale"))
    r = s.add_item("beef wellington")
    check("unknown item is not ok", r["ok"] is False)
    check("unknown item names an error", r["error"] == "no_match")
    check("unknown item still gives Lily words", "what else" in r["say"].lower())
    check("unknown item added nothing", r["order"]["lines"] == [])


def t_bad_arguments_produce_a_speakable_non_mutating_envelope() -> None:
    s = CallSession(load("pink-garlic-shelby"))
    added = s.add_item("lamb saag")
    before = s.snapshot()
    pending = added["needs"]["question"]

    r = s.argument_error("read_back", misrouted=True)
    check("misrouted text is refused", r["ok"] is False)
    check("misrouting has a machine-readable error", r["error"] == "misrouted")
    check("the pending question is asked again", r["say"] == pending, r["say"])
    check("misrouting does not mutate the order", s.snapshot() == before)

    r = s.argument_error("add_item")
    check("missing arguments are refused", r["ok"] is False)
    check("missing arguments have a machine-readable error",
          r["error"] == "bad_arguments")
    check("missing arguments are still speakable", bool(r["say"].strip()))


def t_ambiguity_is_returned_as_a_question_not_a_guess() -> None:
    s = CallSession(load("vesuvio"))
    r = s.add_item("pizza")
    check("bare 'pizza' is refused", r["ok"] is False, r["say"])
    check("it is flagged ambiguous", r["error"] == "ambiguous")
    check("Lily is given a choice to offer", "did you want" in r["say"].lower())
    check("more than one candidate is named",
          len(r["needs"]["candidates"]) >= 2)
    check("nothing was added", r["order"]["lines"] == [])


def t_a_required_group_blocks_submission_and_names_itself() -> None:
    s = CallSession(load("pink-garlic-shelby"))
    r = s.add_item("chicken tikka masala")
    check("adding succeeded", r["ok"] is True, r["say"])
    check("spice level is asked in the same breath",
          "spicy" in r["say"].lower() or "mild" in r["say"].lower(), r["say"])
    check("needs names the line and group",
          r["needs"] and r["needs"]["line_id"] and r["needs"]["group_id"])
    check("not submittable while a required group is open",
          r["order"]["submittable"] is False)

    r = s.answer("medium")
    check("answering clears the requirement", r["ok"] is True, r["say"])
    check("now submittable", r["order"]["submittable"] is True, str(r["needs"]))


def t_answer_without_an_open_question_is_rejected() -> None:
    s = CallSession(load("bun-n-run-ferndale"))
    r = s.answer("medium")
    check("answer with nothing asked fails", r["ok"] is False)
    check("it says why", r["error"] == "no_open_question")


def t_confirm_mods_selects_an_explicit_no_mods_option() -> None:
    cfg = ms.build_config({
        "restaurant": {"id": "confirm-test", "name": "Confirm Test",
                       "cuisine": "burger"},
        "options": [{"id": "no_mods", "name": "NO MODS",
                     "aliases": ["no changes"]},
                    {"id": "no_onion", "name": "No Onion"}],
        "groups": [{"id": "mods", "name": "Mods",
                    "prompt": "Any changes?", "min": 1, "max": 2,
                    "options": ["no_mods", "no_onion"]}],
        "items": [{"id": "burger", "name": "Burger", "price": "8.00",
                   "groups": ["mods"]}],
    })
    s = CallSession(cfg)
    added = s.add_item("burger")
    check("mods question starts open", added["order"]["submittable"] is False)
    r = s.confirm_mods()
    check("confirm mods succeeds", r["ok"] is True, r["say"])
    check("NO MODS satisfies the required group",
          r["order"]["submittable"] is True, str(r["order"]))
    check("the explicit POS choice reaches the order",
          "NO MODS" in r["order"]["lines"][0]["description"],
          r["order"]["lines"][0]["description"])


def t_confirm_mods_never_answers_a_required_combo_drink() -> None:
    s = CallSession(load("bun-n-run-ferndale"))
    s.add_item("double cheeseburger combo")
    confirmed = s.confirm_mods()
    question = confirmed["needs"]["question"]
    r = s.confirm_mods()
    check("confirm mods refuses the drink question", r["ok"] is False, r["say"])
    check("the drink question is repeated", r["say"] == question, r["say"])
    check("the error is specific", r["error"] == "wrong_confirmation", str(r))
    check("the combo remains incomplete", r["order"]["submittable"] is False)


def t_prices_come_from_the_engine_not_the_caller() -> None:
    s = CallSession(load("bun-n-run-ferndale"))
    s.add_item("double cheeseburger")
    r = s.remove_modifier("onion")
    check("subtotal is the item's real price, not one the caller stated",
          r["order"]["subtotal_cents"] == 999,
          str(r["order"]["subtotal_cents"]))
    check("tax is computed at the restaurant's rate",
          r["order"]["tax_cents"] == 60, str(r["order"]["tax_cents"]))
    check("total is subtotal plus tax",
          r["order"]["total_cents"] ==
          r["order"]["subtotal_cents"] + r["order"]["tax_cents"])


def t_modifier_quantity_is_read_from_the_words() -> None:
    """The voice layer may pass only text, so 'two bacon' must cost twice.

    Bacon on this menu is $2.00 and stacks up to 3x. A quantity dropped here
    is money the restaurant never sees.
    """
    one = CallSession(load("burger_template"))
    one.add_item("single cheeseburger")
    _settle(one)
    a = one.add_modifier("bacon")["order"]["subtotal_cents"]

    two = CallSession(load("burger_template"))
    two.add_item("single cheeseburger")
    _settle(two)
    r = two.add_modifier("two bacon")
    b = r["order"]["subtotal_cents"]
    check("a spoken quantity is charged", r["ok"] is True, r["say"])
    check("two bacon costs $2.00 more than one", b - a == 200, f"{b} vs {a}")

    three = CallSession(load("burger_template"))
    three.add_item("single cheeseburger")
    _settle(three)
    c = three.add_modifier("bacon", quantity=3)["order"]["subtotal_cents"]
    check("an explicit quantity is honoured", c - a == 400, f"{c} vs {a}")


def t_a_quantity_over_the_limit_is_refused_not_quietly_capped() -> None:
    """Charging for one while the caller believes they asked for three is the
    kind of error that comes back as a chargeback, not a complaint."""
    s = CallSession(load("chengs-sterling-heights"))
    s.add_item("egg drop soup")
    s.answer("large")
    before = s.read_back()["order"]["subtotal_cents"]
    # "3 wontons" is now understood as the menu's own "3 Wontons" option; a
    # quantity the model states EXPLICITLY, on an option that allows one, is
    # what must never be quietly capped.
    r = s.add_modifier("2 wontons", quantity=3)
    check("over-limit quantity is refused", r["ok"] is False, r["say"])
    check("it is named as a quantity problem", r["error"] == "qty_exceeded")
    check("nothing was charged", r["order"]["subtotal_cents"] == before)
    check("Lily's sentence reads as English, not a template",
          "up to 1 2" not in r["say"] and "only add one" in r["say"].lower(),
          r["say"])


def t_an_option_whose_name_contains_the_number_is_that_option() -> None:
    """Cheng's offers "1 Wonton" .. "4 Wontons". "three wontons" was read as
    quantity 3 of some wonton option and refused, so the 3-wonton add-on could
    never be ordered; the scripted call's "+ 3 wontons" silently did nothing."""
    cfg = load("chengs-sterling-heights")
    for phrase, name in (("3 wontons", "3 Wontons"), ("three wontons", "3 Wontons"),
                         ("add four wontons", "4 Wontons"), ("add 3 wontons please", "3 Wontons"),
                         ("a wonton", "1 Wonton")):
        s = CallSession(cfg)
        s.add_item("egg drop soup")
        r = s.add_modifier(phrase)
        chosen = [(cfg.option(x.option_id).name, x.quantity)
                  for x in s.e.lines[-1].selections]
        check(f"{phrase!r} adds {name}", chosen == [(name, 1)], str(chosen))


def t_well_is_a_menu_word_not_a_filler_when_the_menu_uses_it() -> None:
    """"well" is filler in "well, I'll have the burger" but it is half of
    "Medium Well": it was dropped, so a medium-well burger became medium."""
    from pathlib import Path
    import menu_schema as ms
    cfg = ms.load_yaml(Path(__file__).resolve().parent / "demos" / "prospects" / "bigtime-eatz.yaml")
    for said, want in (("medium well", "Medium Well"), ("well done", "Well Done"),
                       ("medium", "Medium"), ("well, medium rare please", "Medium Rare")):
        s = CallSession(cfg)
        s.add_item("cheeseburger")
        s.answer(said)
        got = [cfg.option(x.option_id).name for x in s.e.lines[-1].selections
               if cfg.option(x.option_id).name in ("Rare", "Medium Rare", "Medium", "Medium Well", "Well Done")]
        check(f"{said!r} -> {want}", got == [want], str(got))


def t_extra_chicken_is_not_extra_hot() -> None:
    """add_modifier took the FIRST group with any match: "extra chicken" scored
    0.64 against the spice level Extra Hot (checked first) and 1.0 against the
    Extra Chicken add-on, and the guest got a hotter dish with no extra chicken."""
    cfg = load("pink-garlic-shelby")
    for said, want in (("extra chicken", "Extra Chicken"), ("extra lamb", "Extra Lamb"),
                       ("extra hot", "Extra Hot")):
        s = CallSession(cfg)
        s.add_item("chicken tikka")
        s.answer("medium")
        s.add_modifier(said)
        names = [cfg.option(x.option_id).name for x in s.e.lines[-1].selections]
        check(f"{said!r} adds {want}", want in names, str(names))
        if want != "Extra Hot":
            check(f"{said!r} keeps the spice level", "Medium" in names, str(names))


def t_a_sold_out_item_is_announced_immediately() -> None:
    cfg = load("bun-n-run-ferndale")
    from restaurants import apply_availability
    cfg = apply_availability(cfg, frozenset({"french_fries"}), frozenset())
    s = CallSession(cfg)
    r = s.add_item("french fries")
    check("sold out is not ok", r["ok"] is False, r["say"])
    check("Lily says she is out of it, on that turn",
          "out of" in r["say"].lower(), r["say"])
    check("it names the reason", r["error"] == "item_unavailable")
    check("the order cannot be placed", r["order"]["submittable"] is False)


def t_read_back_reports_only_what_changed() -> None:
    s = CallSession(load("bun-n-run-ferndale"))
    s.add_item("double cheeseburger combo")
    s.add_modifier("Coke")
    s.remove_modifier("onion")
    r = s.read_back()
    check("read-back mentions the addition", "Coke" in r["say"])
    check("read-back mentions the removal", "Onion" in r["say"])
    check("read-back does not recite untouched defaults",
          "Lettuce" not in r["say"] and "Tomato" not in r["say"], r["say"])
    check("read-back states the total", "$" in r["say"])


def t_ready_to_place_refuses_an_incomplete_order() -> None:
    s = CallSession(load("pink-garlic-shelby"))
    s.add_item("chicken tikka masala")
    r = s.ready_to_place()
    check("incomplete order is refused", r["ok"] is False)
    check("it says what is missing", r["error"] == "incomplete")
    check("the question is the thing to say next", r["say"].strip() != "")
    s.answer("medium")
    r = s.ready_to_place()
    check("a complete order is first asked about allergies, like a waiter would",
          r["ok"] is False and r["error"] == "allergy_check", str(r))
    check("…in a question the voice layer can see", r["needs"]["code"] == "allergy_check")
    s.note_allergy("no")
    r = s.ready_to_place()
    check("complete order is accepted", r["ok"] is True, r["say"])
    check("and confirms with a total", "$" in r["say"])


def t_ready_to_place_refuses_an_empty_order() -> None:
    s = CallSession(load("bun-n-run-ferndale"))
    r = s.ready_to_place()
    check("empty order is refused", r["ok"] is False and r["error"] == "empty")


def t_snapshot_matches_what_the_tools_reported() -> None:
    s = CallSession(load("bun-n-run-ferndale"))
    s.add_item("double cheeseburger")
    r = s.add_modifier("bacon")
    snap = s.snapshot()
    check("snapshot total equals the reported total",
          snap["total_cents"] == r["order"]["total_cents"])
    check("snapshot has the fields the store requires",
          all(k in snap for k in
              ("lines", "subtotal_cents", "tax_cents", "total_cents")))


def t_split_line_lets_units_differ() -> None:
    s = CallSession(load("bun-n-run-ferndale"))
    s.add_item("three hamburgers")
    before = len(s.e.lines)
    r = s.split_line()
    check("split succeeded", r["ok"] is True, r["say"])
    check("there are now two lines", len(s.e.lines) == before + 1)
    check("the quantities add back up",
          sum(l.quantity for l in s.e.lines) == 3,
          str([l.quantity for l in s.e.lines]))


def t_split_of_a_single_unit_is_refused_not_crashed() -> None:
    s = CallSession(load("bun-n-run-ferndale"))
    s.add_item("a hamburger")
    r = s.split_line()
    check("splitting one unit is refused", r["ok"] is False)
    check("it says so", r["error"] == "not_splittable")


def t_line_ids_are_stable_and_addressable() -> None:
    s = CallSession(load("bun-n-run-ferndale"))
    a = s.add_item("hamburger")["order"]["lines"][0]["line_id"]
    s.add_item("french fries")
    r = s.remove_modifier("onion", line_id=a)
    check("a modifier can target an earlier line", r["ok"] is True, r["say"])
    lines = {l["line_id"]: l for l in r["order"]["lines"]}
    check("the earlier line is the one that changed",
          "no Onion" in lines[a]["description"], lines[a]["description"])


def t_tool_schemas_match_the_methods() -> None:
    """The contract handed to the voice team must describe the real code."""
    for schema in TOOL_SCHEMAS:
        name = schema["name"]
        fn = getattr(CallSession, name, None)
        check(f"{name} exists on CallSession", fn is not None)
        if fn is None:
            continue
        params = set(inspect.signature(fn).parameters) - {"self"}
        declared = set(schema["parameters"]["properties"])
        check(f"{name} declares no parameter the method lacks",
              declared <= params, str(declared - params))
        required = set(schema["parameters"].get("required", []))
        check(f"{name}'s required parameters exist", required <= params,
              str(required - params))
        for p, spec in schema["parameters"]["properties"].items():
            check(f"{name}.{p} is documented", bool(spec.get("description")))
        check(f"{name} is documented", bool(schema.get("description")))


def t_tool_schemas_are_json() -> None:
    check("schemas serialise", json.dumps(TOOL_SCHEMAS) is not None)
    check("every schema has a name and parameters",
          all({"name", "description", "parameters"} <= set(t)
              for t in TOOL_SCHEMAS))


def t_every_cuisine_can_be_driven_through_the_tools() -> None:
    """A smoke test across every config: the tools never raise, whatever the
    menu shape. A raise on a live call is dead air."""
    from test_conformance import ALL_PACKS
    for name, cfg in ALL_PACKS.items():
        s = CallSession(cfg)
        try:
            s.greeting()
            s.search_menu()
            for item in cfg.items[:6]:
                s.add_item(item.name)
                _settle(s)
                s.read_back()
                s.ready_to_place()
            s.snapshot()
        except Exception as exc:                     # noqa: BLE001
            check(f"{name} drives without raising", False, repr(exc))
            continue
        check(f"{name} drives without raising", True)


def main() -> int:
    for fn in [v for k, v in sorted(globals().items()) if k.startswith("t_")]:
        try:
            fn()
        except Exception as exc:                     # noqa: BLE001
            global _failed
            _failed += 1
            print(f"\n--- FAIL {fn.__name__}")
            import traceback
            traceback.print_exc()
    print(f"\n{_passed} passed, {_failed} failed (voice-layer tool contract)")
    return 1 if _failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
