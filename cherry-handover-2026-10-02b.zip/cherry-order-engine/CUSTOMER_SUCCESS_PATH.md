# Customer onboarding, success and support — the complete path

Written 2026-09-30, after a full onboarding rehearsal of a real prospect
(The Copper Kettle, Clinton Township — 139-item menu, its actual public
website, gate-clean to a live deployed order). This page is the operating
answer to: *what happens when a restaurant says yes, who does what, and what
happens after they are live.*

## Who can do what

| Step | Agent (with access) | Sales (Piyush) | Owner | Developer |
|---|---|---|---|---|
| Capture menu text | ✅ from their site/fax/photo | ✅ | confirms | — |
| `cherry.py ingest` → draft | ✅ | ✅ | — | — |
| Answer draft questions (prices, groups) | proposes | asks | **decides** | — |
| Fix speech collisions to gate-clean | ✅ | — | confirms intent | — |
| `cherry.py deploy` to test db | ✅ | ✅ | — | — |
| Demo call rehearsal | ✅ | ✅ listens | listens | — |
| Telnyx DID + 10DLC, Square OAuth, Postgres, TLS | — | — | — | ✅ |
| `cherry.py go-live` sign-off | runs it | runs it | witnesses | fixes FAILs |
| Post-live support intake | ✅ (Slack bridge) | ✅ | — | escalates |

The two-day clock (`ONBOARDING.md`) starts only when the owner's inputs are
complete — items 1–11 on that list, including the caller-phrases question.

## The process, demonstrated end to end (Copper Kettle rehearsal)

1. **Menu capture.** Their public site (a SpotApps JS app) hid the menu; the
   static food-menu page carried all of it. Captured ~140 items with prices.
   *Lesson recorded: white-label ordering sites often cannot be scraped —
   that is the moment to ask the owner to text the menu PDF.*
2. **Normalize, then ingest.** Prices mid-line (`Item 8.00 - desc`) were
   moved to end-of-line; half/full prices became two items; descriptions went
   on indented lines; descriptions ending in a bare number got `(+4.00)`
   parens — the parser correctly reads a trailing number as money.
   Result: **139 items parsed, 139 priced, 0 lines not understood.**
3. **The gate earned its keep four times.** `cherry.py check` refused the
   draft with real speech collisions: "side bacon" resolved to *Avocado
   Benny*; "1/2 Classic Egg Benny" unreachable; bare "wrap" decisive between
   two different wraps; "toast" stolen by *Avo Toast*. Each was fixed in the
   draft's `aliases` (symmetric aliases so the engine *asks*), and the menu
   went **READY — 25/25 invariants**.
4. **Deploy and prove.** Deployed to a test database, took a real order over
   HTTP: "pecan chicken and waffle" + "side bacon" both matched correctly,
   read-back `$16.96` (= $16.00 + 6% Michigan tax, exact), order placed,
   ticket to the sink.
5. **What a real onboarding adds** (external, per `NEW_CHAT_HANDOFF.md`):
   owner price signoff, the Square authorization, the DID + 10DLC, the two
   real test calls, the signed acceptance record. `cherry.py go-live` prints
   exactly which of these still block.

## New capability added by this rehearsal

- **`cuisine_library.py` gained `american`** (diner/family-restaurant
  profile: breakfast dishes, egg styles, toast kinds, omelet fillings, burger
  toppings, dressings, half/full portions). The most common independent genre
  in Metro Detroit was missing; now `cherry.py ingest --cuisine american`
  proposes its recurring modifier shapes and flags the price questions.
- **`support_bridge.py`** (below) — the Slack support path.

## Customer support — the Slack path

The Week-1 design in `BUSINESS TOOLS/developer-handoff-complete-automation-
suite-2026-09-28.md` is now one webhook away:

```bash
export CHERRY_SUPPORT_SLACK_WEBHOOK=https://hooks.slack.com/services/...
python3 support_bridge.py send "Owner asks: can lunch specials be 86'd
        separately from dinner?" "The Copper Kettle"
```

- **Owner messages** (`notify_support`) — one formatted block per message,
  severity-tagged; the founder triages in Slack in seconds, exactly as the
  automation suite planned.
- **Ops alerts** (`notify_alerts`) — the alerts from `/v1/ops/snapshot`
  (already identity-free) posted to the same channel, so a failing location
  is visible before the owner notices. The scheduled wiring is a one-line
  cron job; the developer connects it when the first location goes live.
- Failure behaviour: a missing webhook is a clean `disabled` (nothing crashes
  in dev), and a failed POST returns its error — a support message that
  silently vanishes is worse than one that errors.

Success metrics to watch from day one (already in the data model): the
`resolution` table for accuracy trends, `cherry.py mine` for alias growth,
the ops snapshot for exactly-once delivery, and the Tracker sheet for the
human side (visits → yes → onboarded → active at 30/60/90 days).
