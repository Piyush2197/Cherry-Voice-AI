"""
Where a finished order goes.

ONE INTERFACE, SEVERAL DESTINATIONS
-----------------------------------
The manual fallback is not a special case bolted on until the POS bridges
exist. It is an OrderSink, exactly like ToastSink and SquareSink will be. The
caller does:

    deliver(store, order_id, sink_for(restaurant))

and never knows or cares which one ran. That is what makes "build the Square
bridge" a change in one file rather than a change to the call flow, and it is
why a restaurant can go live on SMS this week and move to a POS bridge later
without anything upstream noticing.

RETRY POLICY
------------
Two kinds of failure, and they are not the same:

  * A CONNECTION failure — the network dropped, the POS timed out. Retrying
    can work, so retry with a short backoff.
  * A BUSINESS rejection — the item is sold out, the price moved, the POS
    refused the payload. Retrying cannot fix any of those, and retrying makes
    it worse: it burns seconds of silence on a live call and can double-submit.

So DeliveryResult carries `retryable` and the orchestrator obeys it. The
earlier stress testing found retry backoff was the only real source of latency
in the whole system; a retry that cannot succeed is pure dead air.
"""

from __future__ import annotations

import time
import json
import os
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Protocol

from order_engine import money


# ---------------------------------------------------------------------------
# Results
# ---------------------------------------------------------------------------


@dataclass
class DeliveryResult:
    ok: bool
    external_ref: Optional[str] = None
    error_kind: Optional[str] = None      # connection | rejected | auth | config
    error_detail: Optional[str] = None
    retryable: bool = False

    @classmethod
    def sent(cls, ref: str) -> "DeliveryResult":
        return cls(True, external_ref=ref)

    @classmethod
    def connection_error(cls, detail: str) -> "DeliveryResult":
        # worth another go
        return cls(False, error_kind="connection", error_detail=detail,
                   retryable=True)

    @classmethod
    def rejected(cls, detail: str) -> "DeliveryResult":
        # the POS understood us and said no. Retrying cannot change its mind.
        return cls(False, error_kind="rejected", error_detail=detail,
                   retryable=False)


class OrderSink(Protocol):
    name: str

    def send(self, order_id: str, snapshot: dict,
             ctx: "SinkContext") -> DeliveryResult: ...


@dataclass
class SinkContext:
    """Everything a sink might need that is not in the order itself."""
    restaurant_id: str
    restaurant_name: str
    short_code: str
    staff_phone: Optional[str] = None
    customer_phone: Optional[str] = None
    ticket_url: Optional[str] = None


# ---------------------------------------------------------------------------
# SMS transport
# ---------------------------------------------------------------------------


class SmsSender(Protocol):
    def send(self, to: str, body: str) -> str:
        """Send and return the provider's message id. Raise on failure."""
        ...


class FakeSmsSender:
    """Test and dev double. Records everything, fails on demand."""

    def __init__(self, fail_times: int = 0) -> None:
        self.sent: List[Dict[str, str]] = []
        self.fail_times = fail_times

    def send(self, to: str, body: str) -> str:
        if self.fail_times > 0:
            self.fail_times -= 1
            raise ConnectionError("simulated SMS gateway timeout")
        ref = f"fake-sms-{len(self.sent) + 1}"
        self.sent.append({"to": to, "body": body, "ref": ref})
        return ref


# The real sender lives in telnyx_sms.py, next to the error-code table it
# needs. Imported here so `from sinks import TelnyxSmsSender` keeps working.
from telnyx_sms import SmsError, TelnyxSmsSender  # noqa: E402,F401


# ---------------------------------------------------------------------------
# Ticket formatting — what a human actually reads
# ---------------------------------------------------------------------------


# Prefix for the "this is just how it comes" line. Plain text, because this
# lands in an SMS where escape codes would print as garbage.
DIM_STD = "as usual: "


def format_ticket(snapshot: dict, short_code: str, *,
                  restaurant_name: str = "", customer_name: str = "",
                  customer_phone: str = "", width: int = 38) -> str:
    """A kitchen ticket as plain text.

    Written for a phone screen, because that is where it lands. Order code
    first and large, because that is what staff match against when the
    customer walks in. Removals get a full line of their own with NO in
    capitals — a missed 'no onion' is the complaint that comes back.
    """
    out: List[str] = []
    out.append(f"#{short_code}  {restaurant_name}".strip())
    who = " / ".join(x for x in (customer_name, customer_phone) if x)
    if who:
        out.append(who)
    out.append("-" * width)
    import host_voice
    flag = host_voice.staff_line(snapshot.get("allergy"))
    if flag:
        out.append(f"*** {flag} ***")
        out.append("-" * width)

    for line in snapshot.get("lines", []):
        size = f" [{line['size_name']}]" if line.get("size_name") else ""
        head = f"{line['quantity']}x {line['item_name']}{size}"
        price = money(line["line_total_cents"])
        pad = max(1, width - len(head) - len(price))
        out.append(f"{head}{' ' * pad}{price}")

        # Deviations first, one per line. Standard toppings collapse onto a
        # single trailing line — a cook scanning a rail needs to see what is
        # DIFFERENT about this one, not re-read the recipe.
        standard: List[str] = []
        for m in line.get("modifiers", []):
            if m.get("informational"):
                continue
            if m.get("is_default") and m.get("quantity", 1) == 1 \
                    and m.get("placement", "whole") == "whole":
                standard.append(str(m["option_name"]))
                continue
            q = f"{m['quantity']}x " if m.get("quantity", 1) > 1 else ""
            pl = f" ({m['placement']})" if m.get("placement", "whole") != "whole" else ""
            out.append(f"   + {q}{m['option_name']}{pl}")
        for r in line.get("removed_defaults", []):
            out.append(f"   *** NO {str(r).upper()} ***")
        if standard:
            out.append(f"   {DIM_STD}{', '.join(standard)}")
        if line.get("note"):
            out.append(f"   note: {line['note']}")

    out.append("-" * width)
    out.append(f"{'Subtotal':<{width - 8}}{money(snapshot['subtotal_cents']):>8}")
    out.append(f"{'Tax':<{width - 8}}{money(snapshot['tax_cents']):>8}")
    out.append(f"{'TOTAL':<{width - 8}}{money(snapshot['total_cents']):>8}")
    mode = snapshot.get("payment_mode", "pay_at_pickup")
    out.append("PAY AT PICKUP" if mode == "pay_at_pickup"
               else "PAYMENT: link sent to customer")
    return "\n".join(out)


# ---------------------------------------------------------------------------
# Sinks
# ---------------------------------------------------------------------------


class ManualSink:
    """The fallback: text the ticket to a staff phone.

    Works for every restaurant on day one, needs no hardware and no POS
    credentials. The ticket_url in the message is what turns 'we sent a text'
    into 'a human pressed accept' — see OrderStore.acknowledge_delivery.
    """

    name = "manual"

    def __init__(self, sms: SmsSender) -> None:
        self.sms = sms

    def send(self, order_id: str, snapshot: dict,
             ctx: SinkContext) -> DeliveryResult:
        if not ctx.staff_phone:
            # config problem, not a transient one — retrying will not conjure
            # a phone number
            return DeliveryResult(False, error_kind="config",
                                  error_detail="restaurant has no staff_phone",
                                  retryable=False)
        body = format_ticket(snapshot, ctx.short_code,
                             restaurant_name=ctx.restaurant_name,
                             customer_phone=ctx.customer_phone or "")
        if ctx.ticket_url:
            body += f"\nAccept: {ctx.ticket_url}"
        try:
            ref = self.sms.send(ctx.staff_phone, body)
        except SmsError as exc:
            # The provider told us whether another attempt could ever work.
            # Retrying an unregistered 10DLC number or an opted-out recipient
            # three times just delays the escalation by three backoffs.
            return DeliveryResult(
                False,
                error_kind="connection" if exc.retryable else "rejected",
                error_detail=f"{exc.detail} (code {exc.code})",
                retryable=exc.retryable)
        except Exception as exc:                      # noqa: BLE001
            return DeliveryResult.connection_error(str(exc))
        return DeliveryResult.sent(ref)


class PosSink:
    """Base for real POS bridges. Not usable on its own."""

    name = "pos"

    def send(self, order_id: str, snapshot: dict,
             ctx: SinkContext) -> DeliveryResult:
        raise NotImplementedError


class ToastSink(PosSink):
    """Submit a normalized Cherry pickup order through Toast Orders v2.

    Toast requires a dining-option GUID and an item-group GUID in addition to
    the item GUIDs held by the menu.  The sink validates the order through the
    prices endpoint first and rejects any total mismatch before the kitchen
    sees it.  External ids are derived from Cherry's immutable order id so a
    retry cannot create a second order.
    """

    name = "toast"

    def __init__(self, client=None, *, dining_option_guid: str = "",
                 item_group_guid: str = "", modifier_group_guid: str = ""):
        self.client = client
        self.dining_option_guid = dining_option_guid
        self.item_group_guid = item_group_guid
        self.modifier_group_guid = modifier_group_guid

    def send(self, order_id: str, snapshot: dict,
             ctx: SinkContext) -> DeliveryResult:
        if self.client is None:
            return DeliveryResult(False, error_kind="config",
                                  error_detail="Toast client is not configured")
        try:
            order = build_toast_order(
                snapshot, order_id, ctx,
                dining_option_guid=self.dining_option_guid,
                item_group_guid=self.item_group_guid,
                modifier_group_guid=self.modifier_group_guid)
            priced = self.client.price_order(order)
            quoted = _toast_total_cents(priced)
            expected = int(snapshot.get("total_cents") or 0)
            if quoted != expected:
                return DeliveryResult.rejected(
                    f"Toast total {quoted}c does not match Cherry {expected}c")
            created = self.client.create_order(order)
            ref = created.get("guid") or created.get("externalId")
            if not ref:
                return DeliveryResult.rejected("Toast returned no order GUID")
            return DeliveryResult.sent(str(ref))
        except ToastError as exc:
            return DeliveryResult(
                False, error_kind=exc.kind, error_detail=exc.detail,
                retryable=exc.retryable)
        except (KeyError, ValueError) as exc:
            return DeliveryResult(False, error_kind="config",
                                  error_detail=str(exc), retryable=False)


class ToastError(RuntimeError):
    def __init__(self, detail: str, *, kind: str = "rejected",
                 retryable: bool = False):
        self.detail, self.kind, self.retryable = detail, kind, retryable
        super().__init__(detail)


class ToastClient:
    """Small dependency-free client for the two calls order submission needs."""

    def __init__(self, access_token: str, restaurant_guid: str, *,
                 base_url: str = "https://ws-api.toasttab.com",
                 opener=None, timeout: int = 10):
        if not access_token or not restaurant_guid:
            raise ValueError("Toast access token and restaurant GUID are required")
        self.access_token = access_token
        self.restaurant_guid = restaurant_guid
        self.base_url = base_url.rstrip("/")
        self.opener = opener or urllib.request.urlopen
        self.timeout = timeout

    def _post(self, path: str, payload: dict) -> dict:
        req = urllib.request.Request(
            self.base_url + path,
            data=json.dumps(payload).encode("utf-8"), method="POST",
            headers={"Authorization": f"Bearer {self.access_token}",
                     "Toast-Restaurant-External-ID": self.restaurant_guid,
                     "Content-Type": "application/json"})
        try:
            with self.opener(req, timeout=self.timeout) as response:
                return json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", "replace")[:1000]
            kind = "auth" if exc.code in (401, 403) else "rejected"
            raise ToastError(f"Toast HTTP {exc.code}: {detail}", kind=kind,
                             retryable=exc.code >= 500) from exc
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            raise ToastError(f"Toast connection failed: {exc}",
                             kind="connection", retryable=True) from exc

    def price_order(self, order: dict) -> dict:
        return self._post("/orders/v2/prices", order)

    def create_order(self, order: dict) -> dict:
        return self._post("/orders/v2/orders", order)


def build_toast_order(snapshot: dict, order_id: str, ctx: SinkContext, *,
                      dining_option_guid: str, item_group_guid: str,
                      modifier_group_guid: str = "") -> dict:
    """Translate the POS-neutral snapshot to a Toast pickup order."""
    if not dining_option_guid or not item_group_guid:
        raise ValueError("Toast dining-option and item-group GUIDs are required")
    selections = []
    for n, line in enumerate(snapshot.get("lines", [])):
        refs = line.get("pos_refs") or {}
        combo = any(m.get("option_id") == "bnr_combo"
                    for m in line.get("modifiers", []))
        item_guid = refs.get("toast_combo_guid") if combo else refs.get("toast_guid")
        if not item_guid:
            raise ValueError(f"{line.get('item_name')}: missing Toast item GUID")
        selection = {
            "entityType": "MenuItemSelection",
            "externalId": f"cherry-{order_id}-line-{n}",
            "item": {"guid": item_guid},
            "itemGroup": {"guid": refs.get("toast_item_group_guid") or item_group_guid},
            "quantity": int(line.get("quantity") or 1),
        }
        modifiers = []
        for m, mod in enumerate(line.get("modifiers", [])):
            if mod.get("informational") or mod.get("option_id") == "bnr_combo":
                continue
            mrefs = mod.get("pos_refs") or {}
            guid = mrefs.get("toast_guid")
            if not guid:
                raise ValueError(f"{mod.get('option_name')}: missing Toast modifier GUID")
            group = mrefs.get("toast_group_guid") or modifier_group_guid
            if not group:
                raise ValueError("Toast modifier-group GUID is required")
            modifiers.append({
                "entityType": "MenuItemSelection",
                "externalId": f"cherry-{order_id}-line-{n}-mod-{m}",
                "item": {"guid": guid}, "itemGroup": {"guid": group},
                "quantity": int(mod.get("quantity") or 1),
            })
        if line.get("removed_defaults"):
            note = "NO " + ", NO ".join(str(x).upper()
                                          for x in line["removed_defaults"])
            selection["specialRequest"] = note[:255]
        if line.get("note"):
            existing = selection.get("specialRequest", "")
            selection["specialRequest"] = (existing + "; " + str(line["note"])).strip("; ")[:255]
        if modifiers:
            selection["modifiers"] = modifiers
        selections.append(selection)
    if not selections:
        raise ValueError("Toast order has no selections")
    return {
        "entityType": "Order", "externalId": f"cherry-{order_id}",
        "source": "API", "diningOption": {"guid": dining_option_guid},
        "checks": [{
            "entityType": "Check", "externalId": f"cherry-{order_id}-check",
            "customer": {"entityType": "Customer", "firstName": "Phone",
                         **({"phone": ctx.customer_phone}
                            if ctx.customer_phone else {})},
            "selections": selections,
        }],
    }


def _toast_total_cents(priced: dict) -> int:
    checks = priced.get("checks") or []
    if not checks:
        raise ToastError("Toast price response has no check")
    # Toast money fields are decimal dollars in Orders v2 responses. Convert
    # through text, never binary-float arithmetic.
    from decimal import Decimal
    total = checks[0].get("totalAmount")
    if total is None:
        raise ToastError("Toast price response has no totalAmount")
    return int(Decimal(str(total)) * 100)


SINKS: Dict[str, type] = {
    "manual": ManualSink,
    "toast": ToastSink,
}


def _square_sink_class():
    """Imported lazily: square_bridge imports this module for DeliveryResult."""
    from square_bridge import SquareSink
    return SquareSink


# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------


def deliver(store, order_id: str, sink: OrderSink, *,
            max_attempts: int = 3, backoff_seconds: float = 0.3,
            sleep: Callable[[float], None] = time.sleep) -> DeliveryResult:
    """Send an order and record every attempt.

    Retries only what is worth retrying. A rejection is recorded once and
    returned immediately — the order then needs a human, which is what
    escalation is for.
    """
    row = store.order(order_id)
    if row is None:
        raise LookupError(f"no such order {order_id}")
    snapshot = store.order_snapshot(order_id)
    rest = store.restaurant(row["restaurant_id"])
    if snapshot.get("payment_mode") == "pay_now":
        payment = store.conn.execute(
            "SELECT status FROM payment WHERE order_id=?", (order_id,)).fetchone()
        if not payment or payment["status"] != "paid":
            return DeliveryResult.rejected(
                "itemized checkout is not paid; kitchen handoff is blocked")

    ctx = SinkContext(
        restaurant_id=row["restaurant_id"],
        restaurant_name=rest["name"] if rest else row["restaurant_id"],
        short_code=row["short_code"],
        staff_phone=rest["staff_phone"] if rest else None,
        customer_phone=row["customer_phone"],
        ticket_url=f"/t/{row['short_code']}",
    )

    last = DeliveryResult(False, error_kind="config",
                          error_detail="no attempt made")
    for attempt in range(1, max_attempts + 1):
        last = sink.send(order_id, snapshot, ctx)
        if last.ok:
            store.record_delivery(order_id, sink.name, "sent",
                                  external_ref=last.external_ref)
            if sink.name == "manual" and ctx.staff_phone:
                store.log_sms(ctx.staff_phone,
                              format_ticket(snapshot, ctx.short_code,
                                            restaurant_name=ctx.restaurant_name),
                              "ticket", restaurant_id=row["restaurant_id"],
                              order_id=order_id, provider_ref=last.external_ref,
                              status="sent")
            return last
        if not last.retryable:
            store.record_delivery(order_id, sink.name, "failed",
                                  error_kind=last.error_kind,
                                  error_detail=last.error_detail)
            return last
        if attempt < max_attempts:
            sleep(backoff_seconds * attempt)

    store.record_delivery(order_id, sink.name, "failed",
                          error_kind=last.error_kind,
                          error_detail=f"gave up after {max_attempts} attempts: "
                                       f"{last.error_detail}")
    return last


def sink_for(restaurant_row, sms: Optional[SmsSender] = None,
             **square_kwargs) -> OrderSink:
    """Pick the sink a restaurant is configured for."""
    name = restaurant_row["sink"] if restaurant_row else "manual"
    if name == "square":
        from square_bridge import square_sink_for
        return square_sink_for(restaurant_row, **square_kwargs)
    if name == "toast":
        rid = restaurant_row["id"].upper().replace("-", "_")
        env = lambda key: (os.environ.get(f"{key}_{rid}") or
                           os.environ.get(key, ""))
        token, restaurant = env("TOAST_ACCESS_TOKEN"), env("TOAST_RESTAURANT_GUID")
        client = (ToastClient(token, restaurant,
                              base_url=env("TOAST_API_BASE_URL") or
                              "https://ws-api.toasttab.com")
                  if token and restaurant else None)
        return ToastSink(client,
                         dining_option_guid=env("TOAST_DINING_OPTION_GUID"),
                         item_group_guid=env("TOAST_ITEM_GROUP_GUID"),
                         modifier_group_guid=env("TOAST_MODIFIER_GROUP_GUID"))
    cls = SINKS.get(name)
    if cls is None:
        raise ValueError(f"unknown sink {name!r}; have "
                         f"{sorted(list(SINKS) + ['square'])}")
    if cls is ManualSink:
        if sms is None:
            raise ValueError("ManualSink needs an SmsSender")
        return cls(sms)
    return cls()
