# Cherry developer handover audit — 2026-09-24

## Decision

The repository is ready for a developer to resume integration. It is **not ready for customer traffic**. Start with `DEVELOPER_HANDOFF.md`, `VOICE_FORWARDING.md`, and `TASKS.md`. Launch one location at a time after signed, live acceptance.

## Verified locally

- Full repository suite: 35 test files, 1,372 checks, zero failures. This includes six `test_voice_gateway.py` tests. The onboarding factory was rerun after its acceptance checks changed: 29 passed, zero failed.
- `git diff --check` passes.
- The current launch flow and flags are documented: `CHERRY_CHECKOUT_HANDOFF_ONLY=1` in server and job environments, plus `server.py --checkout-handoff-only`.
- The former production runbook, new-chat handoff, status, task list, onboarding text, operating plan, deployment notes, and quickstart were aligned with checkout-link handoff. The obsolete restore-drill command was corrected.
- Generated onboarding acceptance now asks for checkout SMS delivery, Square paid-order visibility, and no duplicate Cherry ticket. Regenerate any **unlaunched** acceptance packet made before this change.

## Critical work for the returning developer

1. **Voice path:** Confirm the actual Telnyx-to-Inworld media arrangement and implement/configure the Inworld event adapter to the gateway. Prove the same live call carries the real Telnyx `call_control_id`, caller ID, and destination DID. A generic `tools.json` is not an import-ready Inworld Function Calling template. If SIP does not expose Call Control, implement a supported transfer path.
2. **Merchant checkout:** Complete Square merchant authorization, correct location mapping, secure token storage and refresh. Prove the exact itemized checkout, delivered SMS, controlled payment, staff-visible Square order, and no duplicate Cherry ticket. Toast-only merchants need a compatible Square path or additional checkout development.
3. **Phone and fallback:** Acquire one DID per location and a separate direct staff line. The published restaurant number will forward to Cherry, so using it as fallback would loop. Prove requested and failure-triggered transfers before enabling public forwarding.
4. **Production:** Provision managed PostgreSQL, TLS, scoped principals, secret manager, backups/PITR, a separate restore drill, jobs, monitoring, and alerts. Keep checkout-handoff-only set in every server and job process.
5. **Per-location evidence:** Obtain menu/price/tax/hours signoff, run direct-DID and public-forwarded-number calls, then record owner-signed launch acceptance. No location has been certified live from repository evidence.

## Commercial/software gaps that should be scheduled

- The three pricing tiers are decided, but `cost_control.py` still applies the 3,000-minute threshold to every location. Per-location tier storage, tier-based reporting, subscription invoices, and annual prepaid billing are not implemented. This does not block a manually billed pilot, but the developer should estimate it before the first automated billing run.
- The incorrect-order remake/refund policy and liability cap need owner approval before paid contracts.
- The old engineering cost model still needs real provider invoice calibration; do not use it as current plan margin proof.

## Guardrail

The launch mode ends Cherry's call after sending the Square link. The Square paid order must become visible to staff through Square. A webhook may record status, but it must not create a second POS order or kitchen ticket. Passing local tests or a configuration-only `checkout-ready` check does not replace a real merchant payment test.
