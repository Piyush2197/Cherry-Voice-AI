# Cherry — source of truth for a new developer session

Updated 2026-09-24. Start with `DEVELOPER_HANDOFF.md`, then `VOICE_FORWARDING.md`, `TASKS.md`, and `DEPLOYMENT_STATUS.md`. Keep provider secrets out of chat and source control.

## Current launch design

The restaurant keeps its published number and forwards it to a dedicated Telnyx DID. Inworld handles the caller through Cherry's HTTP gateway. Cherry builds an immutable pickup order, texts an itemized Square checkout link, and ends its call flow. Square handles payment and makes its paid order available to the merchant. Cherry creates no second POS order or kitchen ticket. Set `CHERRY_CHECKOUT_HANDOFF_ONLY=1` in the server and scheduled jobs and start the server with `--checkout-handoff-only`.

The HTTP order engine, gateway event contract, Square checkout path, Telnyx transfer adapter, seven pilot menus, and local tests exist. A native Inworld media/event adapter and the exact Telnyx Call Control handoff remain provider-dependent work. The generic `tools.json` is not an import-ready Inworld function template. No restaurant is certified live by repository tests.

## Nonnegotiable live gates

- Verify the forwarded public number preserves caller ID and reaches the correct Telnyx DID and menu.
- Use a direct staff fallback line that does not forward to the public number or any active DID; prove requested and failure-triggered transfers.
- Obtain each merchant's Square authorization and verify a real delivered checkout SMS, exact itemized total, controlled payment, and paid order visibility to staff without a duplicate Cherry ticket.
- Approve current menu, modifiers, taxes, hours, and prices with each owner. Pink Garlic Oak Park and Allen Park still need price signoff.
- Deploy managed PostgreSQL, TLS, scoped credentials, backup/PITR, a separate restore drill, alerts, and operational jobs.
- Sign a per-location acceptance record after a real direct-DID call and a real published-number call. No pilot location is live until this is complete.

Square is the implemented itemized checkout provider. Toast Orders v2 is an order sink, not a checkout. A Toast-only merchant needs a compatible Square authorization or new checkout integration. A generic restaurant ordering URL cannot pay a Cherry cart.

## Commercial decisions

The three committed plans are in `PRICING_PLANS_2026-09-23.md`: Small 3,000 minutes ($299 monthly / $2,988 annual prepaid), Medium 5,000 ($399 / $4,188), and Grande 10,000 ($799 / $8,988). Usage code still assumes a 3,000-minute tier; per-location plans, annual billing, and subscription invoicing need implementation before automated billing or tier enforcement. No surprise overage is promised. Business software decisions are in `business/BUSINESS_DECISIONS_2026-09-23.md` in the project workspace.

## Features outside the pilot promise

Reservations are request-only unless the owner opts in; delivery dispatch, guest memory, catering, and live multilingual acceptance are not complete. No provider audio is retained. The operator UI and alerts still need live proof. The two-business-day onboarding clock starts with complete owner inputs and provider authorization, not with a first sales conversation.
