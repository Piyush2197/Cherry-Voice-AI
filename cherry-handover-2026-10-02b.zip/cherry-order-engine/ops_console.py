"""Small operator console served by Cherry; the API remains the source of truth."""

HTML = r'''<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width">
<title>Cherry Operations</title><style>
body{font:15px system-ui;margin:0;background:#111827;color:#f9fafb}header{padding:20px;background:#7f1d1d}
main{padding:20px;max-width:1100px;margin:auto}.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px}
.card,table{background:#1f2937;border-radius:10px;padding:14px}b{font-size:24px}table{width:100%;border-collapse:collapse;margin-top:18px}td,th{padding:10px;text-align:left;border-bottom:1px solid #374151}
.critical{color:#fca5a5}.high{color:#fde68a}button,input{padding:9px;margin:4px;border-radius:6px;border:0}small{color:#9ca3af}
</style></head><body><header><h1>Cherry Operations</h1><small>No customer identity is shown here.</small></header>
<main><div><input id="key" type="password" placeholder="Operator key"><button onclick="load()">Load</button><span id="status"></span></div><div id="app"></div></main>
<script>
const money=c=>'$'+(Number(c||0)/100).toFixed(2);
// Every value interpolated into innerHTML goes through esc(): POS item names and
// provider error strings reach this page and are not trusted.
const esc=v=>String(v==null?'':v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function load(){let key=document.querySelector('#key').value;try{sessionStorage.cherryKey=key}catch(e){}
let r=await fetch('/v1/ops/snapshot?hours=24',{headers:{'X-Cherry-Key':key}});if(!r.ok){status.textContent=' Access denied';return}let d=await r.json(),s=d.summary;
app.innerHTML=`<div class=cards>${[['Calls',s.calls],['Orders',s.orders],['Conversion',s.conversion_percent==null?'—':s.conversion_percent+'%'],['Revenue',money(s.revenue_cents)],['Open alerts',s.open_alerts]].map(x=>`<div class=card>${esc(x[0])}<br><b>${esc(x[1])}</b></div>`).join('')}</div>
<h2>Locations</h2><table><tr><th>Location</th><th>Calls</th><th>Orders</th><th>Revenue</th><th>Escalations</th></tr>${d.by_restaurant.map(x=>`<tr><td>${esc(x.name)}</td><td>${esc(x.calls)}</td><td>${esc(x.orders)}</td><td>${esc(money(x.revenue_cents))}</td><td>${esc(x.escalations)}</td></tr>`).join('')}</table>
<h2>Alerts</h2>${d.alerts.length?d.alerts.map(a=>`<div class="card ${esc(a.severity)}"><strong>${esc(a.title)}</strong><br>${esc(a.detail)}<br><small>${esc(a.action)}</small></div>`).join(''):'<div class=card>No open alerts</div>'}
<h2>Catalog review</h2>${(d.catalog_reviews||[]).length?d.catalog_reviews.map(r=>`<div class=card><strong>${esc(r.restaurant_id)}</strong><pre>${esc(JSON.stringify(r.detail,null,2))}</pre></div>`).join(''):'<div class=card>No catalog changes awaiting review</div>'}`;status.textContent=' Updated '+new Date().toLocaleTimeString()}
try{key.value=sessionStorage.cherryKey||''}catch(e){}
</script></body></html>'''
