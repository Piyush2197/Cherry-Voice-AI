#!/usr/bin/env python3
"""What a caller actually experiences, through the real server and gateway.

A regular is recognised from a REAL earlier order (not an unpaid one, not
someone else's); a restart in the middle of a call keeps the name and the
allergy; the name reaches the POS and the checkout text goes where the caller
said; the host answers hours and wait times only from what the restaurant
configured; a retried tool call does not add the dish twice; menu names are
made speakable; a transfer texts staff who is calling and what is in the cart.
"""

from __future__ import annotations

import json
import os
import time
import traceback
from datetime import datetime
from zoneinfo import ZoneInfo

import host_voice
import payments
import rehearsal
import restaurant_controls
import server

_passed = _failed = 0
RID = "pink-garlic-shelby"
DIALLED = "+12485550111"


def check(name, cond, detail=""):
    global _passed, _failed
    if cond:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


def order_a_usual(st, cid, frm):
    """Korma (medium) and two garlic naan; name Sam; a peanut allergy; checkout texted."""
    st.call(cid, frm=frm)
    st.tool(cid, "add_item", text="chicken korma")
    st.tool(cid, "answer", text="medium")
    st.tool(cid, "add_item", text="two garlic naan")
    st.tool(cid, "ready_to_place")
    st.tool(cid, "set_name", text="Sam")
    st.tool(cid, "note_allergy", text="peanut allergy")


def t_a_regular_is_recognised_from_a_real_order_and_the_call_survives_a_restart() -> None:
    st = rehearsal.Stack()
    try:
        _code, g = st.call("first", frm="+13135550123")
        tz = ZoneInfo(st.store.restaurant(RID)["timezone"] or "UTC")
        part = host_voice.day_part(datetime.now(tz).hour)
        check("a new caller is greeted by time of day, by name, as Lily",
              ("Welcome back" not in g["say"]) and "this is Lily" in g["say"].replace("This is", "this is")
              and (g["say"].startswith(part) if part else g["say"].startswith("Thank you for calling")), g["say"])
        check("…and the greeting is speakable: 'Shelby Twp' is said 'Shelby Township'",
              "Township" in g["say"] and "(" not in g["say"], g["say"])
        st.call("first-b", frm="+13135550123")           # (a second ring from the same number, same minute)
        order_a_usual(st, "reg-1", "+13135550123")
        st.restart_server()                              # a deploy mid-call
        code, done = st.finish("reg-1")
        say = done.get("say") or ""
        check("after a restart the call is resumed and the order placed", code == 200 and "texted" in say, say[:200])
        check("the checkout text says which number it went to", "ending in zero one two three" in say, say)
        check("…and the sign-off uses the name", "calling, Sam, and enjoy your meal" in say, say)
        posts = [b for (m, u, b) in st.fake.square if u.endswith("/payment-links") and m == "POST"]
        order = posts[-1]["order"]
        check("the POS order carries the caller's name", order["fulfillments"][0]["pickup_details"]["recipient"]["display_name"] == "Sam",
              str(order["fulfillments"][0]["pickup_details"]["recipient"]))
        check("…and the allergy", "peanut" in order["fulfillments"][0]["pickup_details"]["note"])

        # Not a regular yet: the order is unpaid.
        _c, g2 = st.call("reg-2", frm="+13135550123")
        check("an UNPAID earlier order does not make anyone a regular", "Welcome back" not in g2["say"], g2["say"])
        st.tool("reg-2", "abandon") if False else None
        oid = st.store.conn.execute('SELECT id FROM "order" ORDER BY placed_at DESC LIMIT 1').fetchone()["id"]
        check("(the checkout was paid)", payments.mark_paid(st.store, oid, "sq-1"))

        _c, g3 = st.call("reg-3", frm="+13135550123")
        check("once PAID, the next call is 'Welcome back, Sam!'", g3["say"].startswith("Welcome back, Sam!"), g3["say"])
        check("…offering the same again, in words", "Chicken Korma" in g3["say"] and "Garlic Naan" in g3["say"] and "same as last time" in g3["say"], g3["say"])
        _c, u = st.tool("reg-3", "reorder_last")
        check("'the usual' puts the whole order back", "I've added your usual" in u["say"], u["say"])
        st.tool("reg-3", "answer", text="medium")
        _c, q = st.tool("reg-3", "ready_to_place")
        check("the allergy is asked about again — never assumed — as a yes/no", "peanut allergy" in q["say"] and "Does that still apply" in q["say"], q["say"])
        st.tool("reg-3", "answer", text="yes")
        snap = st.app.live["reg-3"].call.snapshot()
        check("'yes' keeps the allergy on file; the name is taken from the same reply",
              snap["allergy"]["note"] == "peanut allergy" and st.app.live["reg-3"].call.customer_name == "Sam", str(snap.get("allergy")))
        check("the usual is exactly what was ordered",
              sorted((l["item_name"], l["quantity"]) for l in snap["lines"]) == [("Chicken Korma (Creamy)", 1), ("Garlic Naan", 2)])

        _c, g4 = st.call("reg-4", frm="+13135550999")
        check("someone else's number is a stranger", "Welcome back" not in g4["say"], g4["say"])
        os.environ["CHERRY_REMEMBER_CALLERS"] = "0"
        try:
            _c, g5 = st.call("reg-5", frm="+13135550123")
            check("remembering callers can be switched off", "Welcome back" not in g5["say"], g5["say"])
        finally:
            del os.environ["CHERRY_REMEMBER_CALLERS"]
    finally:
        st.close()


def t_the_owner_can_switch_off_remembering_callers_for_one_restaurant() -> None:
    import urllib.error
    import urllib.request
    st = rehearsal.Stack()
    try:
        def post(body):
            req = urllib.request.Request(
                f"http://127.0.0.1:{st.sport}/v1/restaurants/{RID}/controls",
                data=json.dumps(body).encode(), method="POST",
                headers={"X-Cherry-Key": "apikey", "Content-Type": "application/json"})
            try:
                with rehearsal.REAL_URLOPEN(req, timeout=20) as r:
                    return r.status, json.loads(r.read())
            except urllib.error.HTTPError as e:
                return e.code, json.loads(e.read() or b"{}")

        order_a_usual(st, "sw-1", "+13135550123")
        st.finish("sw-1")
        oid = st.store.conn.execute('SELECT id FROM "order" ORDER BY placed_at DESC LIMIT 1').fetchone()["id"]
        payments.mark_paid(st.store, oid, "sq-sw")
        check("the default is ON: a paid regular is welcomed back", restaurant_controls.get_controls(st.store, RID)["remember_callers"] is True)
        _c, g = st.call("sw-2", frm="+13135550123")
        check("…by name", g["say"].startswith("Welcome back, Sam!"), g["say"])

        code, now = post({"remember_callers": False})
        check("the owner can switch it off", code == 200 and now["remember_callers"] is False, str((code, now)))
        _c, g = st.call("sw-3", frm="+13135550123")
        check("the same caller is now greeted like anyone else — no name, no order read out",
              "Welcome back" not in g["say"] and "Sam" not in g["say"] and "Korma" not in g["say"]
              and "last time" not in g["say"], g["say"])

        code, now = post({"prep_minutes": 30})
        check("saving something else keeps it off", now["remember_callers"] is False and now["prep_minutes"] == 30, str(now))
        restaurant_controls.set_controls(st.store, RID, prep_minutes=30,
                                         weekly_hours={d: ["00:00", "24:00"] for d in ("mon", "tue", "wed", "thu", "fri", "sat", "sun")})
        check("…even through a caller of set_controls that has never heard of the setting",
              restaurant_controls.get_controls(st.store, RID)["remember_callers"] is False)
        _c, g = st.call("sw-4", frm="+13135550123")
        check("…and still no name", "Welcome back" not in g["say"], g["say"])

        # one restaurant's choice is its own
        other = "pink-garlic-oak-park" if st.store.restaurant("pink-garlic-oak-park") else None
        if other:
            check("another restaurant keeps the default", restaurant_controls.get_controls(st.store, other)["remember_callers"] is True)

        code, now = post({"remember_callers": True})
        _c, g = st.call("sw-5", frm="+13135550123")
        check("switching it back on restores the welcome", now["remember_callers"] is True and g["say"].startswith("Welcome back, Sam!"), g["say"])
    finally:
        st.close()


def t_a_database_from_before_the_switch_gains_it_with_the_default_on() -> None:
    import sqlite3
    import tempfile
    from order_store import OrderStore
    path = tempfile.mkdtemp() + "/old.db"
    old = sqlite3.connect(path)
    old.executescript("""CREATE TABLE restaurant_control (
        restaurant_id TEXT PRIMARY KEY, weekly_hours TEXT NOT NULL DEFAULT '{}',
        holiday_closures TEXT NOT NULL DEFAULT '[]', prep_minutes INTEGER NOT NULL DEFAULT 20,
        wait_minutes INTEGER NOT NULL DEFAULT 0, ai_enabled INTEGER NOT NULL DEFAULT 1,
        languages TEXT NOT NULL DEFAULT '["en"]', updated_by TEXT, updated_at TEXT NOT NULL);
        INSERT INTO restaurant_control (restaurant_id, prep_minutes, updated_at) VALUES ('legacy', 40, 'x');""")
    old.commit()
    old.close()
    store = OrderStore.sqlite(path)
    row = store.conn.execute("SELECT * FROM restaurant_control WHERE restaurant_id='legacy'").fetchone()
    check("an existing pilot database opens and keeps its row", row is not None and row["prep_minutes"] == 40)
    check("…and gains the column, switched on (what it did before)", row["remember_callers"] == 1)
    check("the migration is recorded", store.conn.execute("SELECT 1 FROM schema_migration WHERE version=7").fetchone() is not None)
    store2 = OrderStore.sqlite(path)                      # opening twice is harmless
    check("reopening is a no-op", store2.conn.execute("SELECT count(*) c FROM restaurant_control").fetchone()["c"] == 1)
    sql = open("db/schema.sql").read()
    check("the Postgres schema has it too, with an ALTER for an existing database",
          "remember_callers    BOOLEAN NOT NULL DEFAULT TRUE" in sql
          and "ADD COLUMN IF NOT EXISTS remember_callers" in sql)


def t_the_checkout_text_goes_where_the_caller_says() -> None:
    st = rehearsal.Stack()
    try:
        st.call("tn-1", frm="+13135550123")
        st.tool("tn-1", "add_item", text="garlic naan")
        _c, r = st.tool("tn-1", "set_text_number", text="I'm on a landline, text it to 586 980 5199")
        check("the number is accepted and read back", "ending in five one nine nine" in r["say"], r["say"])
        st.tool("tn-1", "ready_to_place"); st.tool("tn-1", "set_name", text="Maria"); st.tool("tn-1", "note_allergy", text="no")
        _c, done = st.finish("tn-1")
        check("the order is placed", "texted" in (done.get("say") or ""), str(done)[:200])
        sms = [m for m in st.fake.sms if "square.link" in m.get("text", "")]
        check("the link went to the number the caller gave, not the caller ID", sms and sms[-1]["to"] == "+15869805199", str(sms))
        check("…and the call says so", "ending in five one nine nine" in (done.get("say") or ""))
        check("the read-back gives an honest time, counted from checkout (the kitchen starts when they have paid)",
              "about 20 minutes after you complete checkout" in (done.get("say") or ""), (done.get("say") or "")[:300])
        st.call("tn-2", frm="+13135550124")
        st.tool("tn-2", "add_item", text="garlic naan")
        _c, bad = st.tool("tn-2", "set_text_number", text="586 980")
        check("half a number is refused with a question", "ten digits" in bad["say"] or "isn't" in bad["say"].lower() or "digits" in bad["say"], bad["say"])
    finally:
        st.close()


def t_the_host_answers_hours_and_wait_only_from_what_is_configured() -> None:
    st = rehearsal.Stack()
    try:
        _c, r = st.call("hr-1"); _c, a = st.tool("hr-1", "store_info", text="what time do you close tonight")
        check("with no hours configured, Lily does not guess", "don't have the hours" in a["say"] and "PM" not in a["say"], a["say"])
        _c, w = st.tool("hr-1", "store_info", text="how long will it take")
        check("the wait is the configured prep time (20) plus the current wait (0)", "20 minutes" in w["say"], w["say"])
        _c, d = st.tool("hr-1", "store_info", text="do you deliver?")
        check("delivery: she says what she does", "pickup" in d["say"].lower(), d["say"])

        days = {d: ["00:00", "23:59"] for d in ("mon", "tue", "wed", "thu", "fri", "sat", "sun")}
        restaurant_controls.set_controls(st.store, RID, weekly_hours=days, prep_minutes=20, wait_minutes=10)
        st.call("hr-2")
        _c, a2 = st.tool("hr-2", "store_info", text="what time do you close")
        check("with hours configured she says when they close", "11:59 PM" in a2["say"], a2["say"])
        _c, w2 = st.tool("hr-2", "store_info", text="how long is the wait")
        check("…and the wait includes the current busy time (20 + 10)", "30 minutes" in w2["say"], w2["say"])
        summary = restaurant_controls.hours_summary(st.store, RID, now=datetime(2026, 10, 7, 12, 0, tzinfo=ZoneInfo("America/Detroit")))
        check("hours_summary: open now with a closing time", summary["configured"] and summary["open_now"] and summary["closes"] == "11:59 PM", str(summary))
        restaurant_controls.set_controls(st.store, RID, weekly_hours={"sat": ["11:00", "21:00"]}, prep_minutes=20)
        wed = restaurant_controls.hours_summary(st.store, RID, now=datetime(2026, 10, 7, 12, 0, tzinfo=ZoneInfo("America/Detroit")))
        check("closed on a Wednesday: next opening is Saturday at 11 AM", not wed["open_now"] and wed["next_open"] == "Saturday at 11 AM", str(wed))
        sat_morning = restaurant_controls.hours_summary(st.store, RID, now=datetime(2026, 10, 10, 9, 30, tzinfo=ZoneInfo("America/Detroit")))
        check("before opening on Saturday: 'today at 11 AM'", sat_morning["next_open"] == "today at 11 AM", str(sat_morning))
    finally:
        st.close()


def t_a_retried_tool_call_does_not_add_the_dish_twice() -> None:
    st = rehearsal.Stack()
    old = server.DUPLICATE_WINDOW_SECONDS
    try:
        st.call("dup-1")
        a = st.app.run_tool("dup-1", "add_item", {"text": "garlic naan"})
        b = st.app.run_tool("dup-1", "add_item", {"text": "garlic naan"})
        check("an identical retry is answered from the first result", b.get("duplicate") is True and b["say"] == a["say"], str(b)[:160])
        check("…and the dish is on the order once", len(st.app.live["dup-1"].call.snapshot()["lines"]) == 1)
        c = st.app.run_tool("dup-1", "add_item", {"text": "plain naan"})
        check("a DIFFERENT request is not mistaken for a retry", not c.get("duplicate") and len(c["order"]["lines"]) == 2)
        server.DUPLICATE_WINDOW_SECONDS = 0.1
        time.sleep(0.2)
        d = st.app.run_tool("dup-1", "add_item", {"text": "plain naan"})
        check("after the window, the same words are a new request (two naan, said twice, minutes apart)",
              not d.get("duplicate") and len(d["order"]["lines"]) == 3, str(d)[:160])
        journal = [t for t, _a in st.store.load_journal(st.app.live["dup-1"].session_id)]
        check("a suppressed retry is not journaled (a replay must not add it either)", journal.count("add_item") == 3, str(journal))
    finally:
        server.DUPLICATE_WINDOW_SECONDS = old
        st.close()


def t_menu_names_are_made_speakable_at_the_door() -> None:
    st = rehearsal.Stack()
    try:
        st.call("sp-1")
        r = st.app.run_tool("sp-1", "add_item", {"text": "chicken korma"})
        check("'(Creamy)' becomes a spoken pause", "Chicken Korma, Creamy" in r["say"] and "(" not in r["say"], r["say"])
        r = st.app.run_tool("sp-1", "add_item", {"text": "vegetable samosa"})
        check("'(2Pcs)' becomes 'two pieces'", "two pieces" in r["say"] and "2Pcs" not in r["say"], r["say"])
    finally:
        st.close()


def t_a_sold_out_dish_is_offered_an_alternative_on_a_real_call() -> None:
    st = rehearsal.Stack()
    try:
        cfg, _mv = st.store.load_live_config(RID)
        korma = next(i for i in cfg.items if i.name.startswith("Lamb/Goat Korma"))
        st.store.set_availability(RID, korma.id, False, reason="out of lamb")
        st.call("so-1")
        _c, r = st.tool("so-1", "add_item", text="lamb korma")
        check("a dish the kitchen has 86'd: warm apology and the closest thing", "so sorry" in r["say"] and "very close" in r["say"], r["say"])
        _c, y = st.tool("so-1", "answer", text="yes please")
        check("'yes' takes the alternative", "Got it" in y["say"] or "Perfect" in y["say"] or "Lovely" in y["say"], y["say"])
        check("…and the 86'd dish never reached the order", all("Korma" not in l["item_name"] or "Lamb/Goat Korma" not in l["item_name"]
                                                             for l in st.app.live["so-1"].call.snapshot()["lines"]))
    finally:
        st.close()


def t_the_voice_worker_is_told_the_call_policy() -> None:
    st = rehearsal.Stack()
    try:
        code, body = st.gw("GET", "/v1/voice/tools")
        pol = body.get("call_policy") or {}
        check("the gateway publishes the call policy", code == 200 and pol, str(body.keys()))
        check("tools must be BLOCKING (Gemini 3.8 Live defaults to non-blocking)", pol.get("tool_behavior") == "BLOCKING")
        check("a runaway call is capped", 60 <= pol.get("max_call_seconds", 0) <= 1800)
        check("an idle line is prompted warmly, then released", "still there" in pol.get("idle_prompt", "") and pol.get("hang_up_after_idle_prompts", 0) >= 1)
        check("the prompt names the new tools", all(t in body["system_prompt"] for t in ("reorder_last", "set_name", "set_text_number", "store_info")))
        check("…and says to call each tool once", "ONCE" in body["system_prompt"])
    finally:
        st.close()


def t_a_transfer_texts_staff_who_is_calling_and_what_is_in_the_cart() -> None:
    st = rehearsal.Stack()
    try:
        st.call("ho-1", frm="+13135550177")
        st.tool("ho-1", "add_item", text="garlic naan")
        st.tool("ho-1", "set_name", text="Dana")
        st.tool("ho-1", "note_allergy", text="shellfish")
        code, b = st.gw("POST", "/v1/voice/calls/ho-1/handoff", {})
        time.sleep(0.6)                                   # the briefing is fire-and-forget
        check("the caller is transferred", code == 200 and st.fake.transfers, str(b))
        briefs = [m for m in st.fake.sms if "Cherry transfer" in m.get("text", "")]
        check("staff are texted a briefing", len(briefs) == 1, str(st.fake.sms)[:300])
        text = briefs[0]["text"] if briefs else ""
        check("…who is calling, why, and the cart", "Dana" in text and "+13135550177" in text and "Garlic Naan" in text and "asked for a person" in text, text)
        check("…and the allergy", "shellfish" in text, text)
        check("…in two SMS segments or fewer", len(text) <= 320, str(len(text)))
        check("the session is marked escalated", st.store.conn.execute("SELECT COUNT(*) c FROM session WHERE escalated_at IS NOT NULL").fetchone()["c"] >= 1)
        st.gw("POST", "/v1/voice/calls/ho-1/handoff", {})
        time.sleep(0.4)
        check("a second request does not text staff again",
              len([m for m in st.fake.sms if "Cherry transfer" in m.get("text", "")]) == 1)

        st.call("ho-2", frm="+13135550178"); st.tool("ho-2", "add_item", text="garlic naan")
        st.fake.sms_down = True
        code, b = st.gw("POST", "/v1/voice/calls/ho-2/handoff", {})
        time.sleep(0.4)
        check("a failing briefing never breaks the transfer", code == 200 and len(st.fake.transfers) >= 2, str(b))
    finally:
        st.close()


def t_staff_briefing_text_is_built_from_the_cart() -> None:
    snap = {"lines": [{"item_name": "Chicken Korma (Creamy)", "quantity": 2, "size_name": None},
                      {"item_name": "Egg Roll", "quantity": 1, "size_name": "Large"}],
            "total_cents": 4210, "allergy": {"checked": True, "note": "peanut allergy"}}
    t = host_voice.staff_briefing(caller="+13135550123", name="Sam", reason="the line dropped", snapshot=snap)
    check("names the caller, the reason, the items with quantities and sizes, the total and the allergy",
          all(x in t for x in ("Sam", "+13135550123", "the line dropped", "2x Chicken Korma", "Egg Roll Large", "$42.10", "peanut allergy")), t)
    e = host_voice.staff_briefing(caller="", name="", reason="", snapshot={"lines": []})
    check("an empty cart and an unknown caller still read sensibly", "no items yet" in e and "unknown number" in e, e)
    long_snap = {"lines": [{"item_name": "X" * 80, "quantity": 1}] * 5, "total_cents": 100}
    check("it is capped at two SMS segments", len(host_voice.staff_briefing(caller="+1", name="A", reason="r", snapshot=long_snap)) <= 320)


def main() -> int:
    global _failed
    for name, fn in sorted((k, v) for k, v in globals().items() if k.startswith("t_")):
        try:
            fn()
        except Exception:                                    # noqa: BLE001
            _failed += 1
            print(f"\n--- FAIL {name} raised")
            traceback.print_exc()
    print(f"{_passed} passed, {_failed} failed (the caller's experience, end to end)")
    return 1 if _failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
