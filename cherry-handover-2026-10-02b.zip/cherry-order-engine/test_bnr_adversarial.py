#!/usr/bin/env python3
"""Adversarial pass for Bun N Run — both locations, over a real socket.

Not a functional suite: a hostile one. Every battery tries to make the
engine put wrong food on a ticket, charge the wrong total, crash mid-call,
leak something, or double-release to the kitchen. A real caller mumbles,
the speech model mishears, and a bored teenager mashes the checkout link —
the system has to survive all three on Bun N Run's published number.

Invariants under attack:
  * a tool call never returns a 500 — the caller always gets spoken words;
  * totals are never negative, never absurd, and always 6% tax on cents;
  * a placed order cannot be mutated, double-paid, or double-released;
  * whatever a caller types never executes in the kitchen ticket page;
  * BNR's alias traps ("double no cheese" IS a hamburger) read correctly.
"""

from __future__ import annotations

import json
import threading
import urllib.parse
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

import menu_schema as ms
import payments
import server as srv
from order_store import OrderStore
from sinks import FakeSmsSender

MENUS = Path(__file__).parent / "menus"
KEY = "adversarial-secret"

_passed, _failed = 0, 0
_FAILS: list[str] = []


def check(name: str, cond: bool, detail: str = "") -> None:
    global _passed, _failed
    if cond:
        _passed += 1
    else:
        _failed += 1
        _FAILS.append(name)
        print(f"  FAIL {name}" + (f" — {detail[:300]}" if detail else ""))


class Harness:
    """A live server on a real port with both Bun N Run locations."""

    def __init__(self, **app_options):
        self.store = OrderStore.sqlite()
        for stem, inbound in (("bun-n-run-ferndale", "+13135551000"),
                              ("bun-n-run-clinton", "+15865551000")):
            cfg = ms.load_yaml(MENUS / f"{stem}.yaml")
            self.store.upsert_restaurant(
                cfg.id, cfg.name, cfg.cuisine, tax_rate_bps=cfg.tax_rate_bps,
                sink="manual", staff_phone="+13135550900", inbound_phone=inbound,
                active=True)
            self.store.publish_menu(cfg.id, (MENUS / f"{stem}.yaml").read_text(),
                                    item_count=len(cfg.items))
        self.sms = FakeSmsSender()
        self.app = srv.Cherry(self.store, sms=self.sms, api_key=KEY,
                              pay_provider=payments.FakePayLinkProvider(),
                              dev_checkout=True, **app_options)
        self.httpd = srv.build_server(self.app, 0)
        self.port = self.httpd.server_address[1]
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()

    def stop(self):
        self.httpd.shutdown()

    def req(self, method: str, path: str, body: Optional[Dict] = None,
            key: Optional[str] = KEY, headers: Optional[Dict[str, str]] = None,
            raw: Optional[bytes] = None) -> Tuple[int, Any]:
        data = raw if raw is not None else (
            json.dumps(body).encode() if body is not None else None)
        safe_path = urllib.parse.quote(path, safe="/?=&%+.~")
        r = urllib.request.Request(f"http://127.0.0.1:{self.port}{safe_path}",
                                   data=data, method=method)
        if data:
            r.add_header("Content-Type", "application/json")
        if key is not None:
            r.add_header("X-Cherry-Key", key)
        for name, value in (headers or {}).items():
            r.add_header(name, value)
        try:
            with urllib.request.urlopen(r, timeout=15) as resp:
                payload = resp.read()
                ctype = resp.headers.get("Content-Type", "")
                return resp.status, (json.loads(payload) if "json" in ctype
                                     else payload.decode("utf-8", "replace"))
        except urllib.error.HTTPError as exc:
            payload = exc.read()
            try:
                return exc.code, json.loads(payload)
            except ValueError:
                return exc.code, payload.decode("utf-8", "replace")

    def post(self, path, body=None, key=KEY, raw=None):
        return self.req("POST", path, body or {}, key, raw=raw)

    def get(self, path, key=KEY):
        return self.req("GET", path, None, key)

    def tool(self, call_id, name, **args):
        return self.post(f"/v1/calls/{call_id}/tools/{name}", args)

    def finish(self, call_id):
        return self.post(f"/v1/calls/{call_id}/finish", {})

    def call(self, call_id, to="+13135551000", frm="+13135550123"):
        return self.post("/v1/calls", {"call_id": call_id, "to": to, "from": frm})

    def health(self):
        return self.get("/health", key=None)

    def pay_and_release(self, order_id: str):
        return self.post(f"/v1/dev/pay/{order_id}", {})


# ---------------------------------------------------------------- batteries

GARBAGE = [
    "😂😂😂",
    "🎉 🍔 🧅",
    "مرحبا انا اريد برجر",
    "quiero dos hamburguesas por favor",
    "'; DROP TABLE \"order\"; --",
    "1' OR '1'='1",
    "<script>alert(1)</script>",
    "{{7*7}}",
    "%s%s%s%s%s%n",
    "A" * 5000,
    "\n\n\n\r\n\t",
    "burger\x00burger",
    "​zero width​​",
    "a" * 300 + " cheeseburger",
    "٢٣ برجر",
    "٣x fries",
]


def t_hostile_text_never_breaks_the_call() -> None:
    h = Harness()
    try:
        for i, text in enumerate(GARBAGE):
            cid = f"hostile-{i}"
            s, g = h.call(cid)
            check(f"call opens under garbage corpus {i}", s == 200, f"{s} {g}")
            for name in ("add_item", "add_modifier", "remove_modifier",
                         "remove_item", "answer", "item_info"):
                s, r = h.tool(cid, name, text=text)
                check(f"{name} survives garbage {i} (no 500)",
                      s != 500 and s != 501, f"{s} {str(r)[:120]}")
                if s == 200:
                    body = r if isinstance(r, dict) else {}
                    check(f"{name} says something under garbage {i}",
                          isinstance(body.get("say"), str) and body.get("say"),
                          str(body)[:120])
            s, r = h.tool(cid, "set_name", text=text)
            check(f"set_name survives garbage {i}", s != 500, f"{s}")
            s, r = h.tool(cid, "note_allergy", text=text)
            check(f"note_allergy survives garbage {i}", s != 500, f"{s}")
        s, r = h.health()
        check("server healthy after garbage corpus", s == 200 and r.get("ok"),
              f"{s} {r}")
    finally:
        h.stop()


def t_quantity_abuse() -> None:
    h = Harness()
    try:
        for i, text in enumerate(["999 cheeseburgers", "1000 fries",
                                  "a million cokes", "99 shakes",
                                  "0 burgers", "minus two burgers",
                                  "-1 hamburger", "two and a half burgers",
                                  "2.5 cheeseburger combos", "2 2 fries",
                                  "٥ burgers", "twenty two shakes"]):
            cid = f"qty-{i}"
            h.call(cid)
            s, r = h.tool(cid, "add_item", text=text)
            check(f"quantity phrase {i!r} no 500", s != 500, f"{s} {r}")
            if s == 200 and isinstance(r, dict) and r.get("order"):
                order = r["order"]
                check(f"quantity phrase {i!r} non-negative total",
                      order["total_cents"] >= 0, str(order))
                check(f"quantity phrase {i!r} sane total",
                      order["total_cents"] < 70000,
                      f"${order['total_cents']/100:.2f} — {order['lines']}")
                for line in order["lines"]:
                    check(f"quantity phrase {i!r} line qty 1..99",
                          1 <= line["quantity"] <= 99, str(line))
        # set_quantity through the tool argument — no text to parse, no excuse.
        # Three layers: the server's arg check (>1000 unusable), the tool
        # schema (maximum 99), and the engine's own spoken refusal.
        cid = "qty-tool"
        h.call(cid)
        h.tool(cid, "add_item", text="double cheeseburger combo")
        h.tool(cid, "add_modifier", text="Coke")
        h.tool(cid, "confirm_mods")
        for bad in (1000000, 999999):
            s, r = h.tool(cid, "set_quantity", quantity=bad)
            body = r if isinstance(r, dict) else {}
            total = (body.get("order") or {}).get("total_cents", 0)
            check(f"set_quantity {bad} bounded, caller told to repeat",
                  s != 500 and body.get("ok") is False and total < 70000,
                  f"{s} ok={body.get('ok')} ${total/100:.2f}")
        s, r = h.tool(cid, "set_quantity", quantity=100)
        body = r if isinstance(r, dict) else {}
        total = (body.get("order") or {}).get("total_cents", 0)
        check("set_quantity 100 refused with a spoken reason",
              s != 500 and body.get("error") == "quantity_cap"
              and total < 70000, f"{s} {str(body)[:160]}")
        check("server healthy after quantity battery", h.health()[1].get("ok"))
    finally:
        h.stop()


def t_alias_traps_read_right() -> None:
    """BNR's menu is full of spoken traps. Each case: what the caller said
    must become what the kitchen cooks."""
    h = Harness()
    try:
        cases = [
            # (phrase, expected item id or "AMBIG" for an offered choice)
            ("double no cheese", "double_hamburger"),
            ("double cheeseburger", "double_cheeseburger"),
            ("double burger", "double_hamburger"),
            ("burger", "hamburger"),
            ("plain burger", "hamburger"),
            ("veggie", "veggie_burger"),
            ("milkshake", "fresh_shake"),
            ("milk shake", "fresh_shake"),
            ("ice tea", "iced_tea"),
            ("doctor pepper", "dr_pepper"),
            ("spright", "sprite"),
            ("regular fries", "french_fries"),
            ("wild fries", "wild_fries"),
            ("double with cheese", "double_cheeseburger"),
        ]
        for i, (phrase, want) in enumerate(cases):
            cid = f"alias-{i}"
            h.call(cid)
            s, r = h.tool(cid, "add_item", text=phrase)
            body = r if isinstance(r, dict) else {}
            lines = (body.get("order") or {}).get("lines") or []
            got = lines[0]["item_id"] if lines else \
                (body.get("needs") or {}).get("code")
            check(f"{phrase!r} -> {want}", s == 200 and got == want,
                  f"got {got} ({str(body)[:160]})")
        # prefix trap: 'cheeseburger' must not eat 'double cheeseburger'
        cid = "alias-prefix"
        h.call(cid)
        s, r = h.tool(cid, "add_item", text="cheeseburger")
        body = r if isinstance(r, dict) else {}
        lines = (body.get("order") or {}).get("lines") or []
        got = lines[0]["item_id"] if lines else (body.get("needs") or {}).get("code")
        check("'cheeseburger' alone offers singles, never a double",
              got in ("single_cheeseburger", "AMBIG", "ambiguous",
                      "ambiguous_match", None)
              or (got or "").startswith("single"), f"got {got}")
        # bare 'fries' is two items — must ask, never guess
        cid = "alias-fries"
        h.call(cid)
        s, r = h.tool(cid, "add_item", text="fries")
        body = r if isinstance(r, dict) else {}
        lines = (body.get("order") or {}).get("lines") or []
        code = (body.get("needs") or {}).get("code") or ""
        ok = (not lines) or code in ("ambiguous", "clarify", "choice")
        check("bare 'fries' asks which one", ok, str(body)[:200])
        # THE trap: a contradiction ('cheeseburger' + 'no cheese') must be
        # ASKED about, never silently cooked as a hamburger
        cid = "alias-nocheese"
        h.call(cid)
        s, r = h.tool(cid, "add_item", text="double cheeseburger with no cheese")
        body = r if isinstance(r, dict) else {}
        lines = (body.get("order") or {}).get("lines") or []
        say = body.get("say", "")
        asked = body.get("ok") is False and not lines and "or the" in say
        resolved_cheese = any(l["item_id"] == "double_cheeseburger"
                              for l in lines) and not any(
            l["item_id"] == "double_hamburger" for l in lines)
        check("contradiction 'cheeseburger no cheese' asks, never silently "
              "cooks a hamburger", asked or resolved_cheese, say)
        # quantity words survive an ambiguity question: 'couple of fries'
        # may ask which fry, but must not become one fry of either
        s, r = h.tool(cid, "add_item", text="couple of fries")
        body = r if isinstance(r, dict) else {}
        lines = (body.get("order") or {}).get("lines") or []
        if lines:
            check("'couple of fries' is at least two fries",
                  lines[0]["quantity"] >= 2, str(lines))
        else:
            check("'couple of fries' asks which fry",
                  body.get("ok") is False, say)
    finally:
        h.stop()


def t_combo_drink_math() -> None:
    h = Harness()
    try:
        # every drink choice prices the same: the combo includes it
        for drink in ("Coke", "Water", "Dr. Pepper", "Lemonade"):
            cid = f"combo-{drink.split('.')[0].lower()}"
            h.call(cid)
            h.tool(cid, "add_item", text="double cheeseburger combo")
            h.tool(cid, "add_modifier", text=drink)
            h.tool(cid, "confirm_mods")
            h.tool(cid, "set_name", text="Math Check")
            h.tool(cid, "note_allergy", text="none")
            s, r = h.tool(cid, "ready_to_place")
            body = r if isinstance(r, dict) else {}
            total = (body.get("order") or {}).get("total_cents")
            check(f"combo with {drink} totals $14.83", total == 1483,
                  f"got {total}")
            s, r = h.finish(cid)
            body = r if isinstance(r, dict) else {}
            check(f"combo with {drink} finishes at $14.83",
                  body.get("total_cents") == 1483, str(body)[:160])
        # a combo cannot finish without its drink
        cid = "combo-no-drink"
        h.call(cid)
        h.tool(cid, "add_item", text="hamburger combo")
        h.tool(cid, "confirm_mods")
        h.tool(cid, "set_name", text="No Drink")
        h.tool(cid, "note_allergy", text="none")
        s, r = h.tool(cid, "ready_to_place")
        body = r if isinstance(r, dict) else {}
        check("combo without drink refuses to place",
              body.get("error") in ("missing_required_group", "incomplete"),
              str(body)[:200])
        s, r = h.finish(cid)
        body = r if isinstance(r, dict) else {}
        check("finish on drinkless combo does not place",
              not body.get("placed"), str(body)[:200])
    finally:
        h.stop()


def t_flow_abuse() -> None:
    h = Harness()
    try:
        # finish on an empty order
        h.call("flow-empty")
        s, r = h.finish("flow-empty")
        body = r if isinstance(r, dict) else {}
        check("finish on empty order does not place", not body.get("placed"),
              str(body)[:160])
        # read_back / confirm_mods with nothing pending
        s, r = h.tool("flow-empty", "read_back")
        check("read_back on empty is graceful", s != 500, f"{s}")
        s, r = h.tool("flow-empty", "confirm_mods")
        check("confirm_mods with nothing pending is graceful", s != 500, f"{s}")
        # full order, then attack it
        h.call("flow-double")
        h.tool("flow-double", "add_item", text="double cheeseburger combo")
        h.tool("flow-double", "add_modifier", text="Coke")
        h.tool("flow-double", "confirm_mods")
        h.tool("flow-double", "set_name", text="Dbl Trouble")
        h.tool("flow-double", "note_allergy", text="none")
        h.tool("flow-double", "ready_to_place")
        s1, r1 = h.finish("flow-double")
        s2, r2 = h.finish("flow-double")
        b1 = r1 if isinstance(r1, dict) else {}
        b2 = r2 if isinstance(r2, dict) else {}
        check("double finish keeps one order_id",
              b1.get("order_id") == b2.get("order_id"),
              f"{b1.get('order_id')} vs {b2.get('order_id')}")
        oid = b1.get("order_id")
        # mutation after placement must not touch the snapshot
        h.tool("flow-double", "add_item", text="20 french fries")
        h.tool("flow-double", "remove_item", text="take the whole combo off")
        s, r = h.tool("flow-double", "set_quantity", quantity=50)
        row = h.store.conn.execute(
            'SELECT total_cents FROM "order" WHERE id=?', (oid,)).fetchone()
        check("placed order total unmoved by post-finish tools",
              row is not None and row["total_cents"] == 1483,
              f"db says {row and row['total_cents']}")
        # remove_item with a dish from another restaurant entirely
        h.call("flow-wrong-menu")
        h.tool("flow-wrong-menu", "add_item", text="double cheeseburger")
        s, r = h.tool("flow-wrong-menu", "remove_item", text="remove the samosas")
        check("remove_item for foreign dish is graceful", s != 500, f"{s} {r}")
        # a fresh session on a finished call_id must not resurrect the order
        h.call("flow-reuse")
        h.tool("flow-reuse", "add_item", text="water")
        h.tool("flow-reuse", "set_name", text="R")
        h.tool("flow-reuse", "note_allergy", text="none")
        h.tool("flow-reuse", "ready_to_place")
        s, r1 = h.finish("flow-reuse")
        oid1 = (r1 if isinstance(r1, dict) else {}).get("order_id")
        s, g = h.call("flow-reuse")
        s, r2 = h.tool("flow-reuse", "read_back")
        lines = ((r2 if isinstance(r2, dict) else {}).get("order") or {}).get("lines")
        check("recreated call_id starts a clean order", not lines, str(lines))
        check("server healthy after flow battery", h.health()[1].get("ok"))
    finally:
        h.stop()


def t_gate_abuse() -> None:
    h = Harness()
    try:
        # hostile names never break placement and never inject the ticket
        for i, name in enumerate(["<script>alert(1)</script>", "123", "0",
                                  "N" * 5000, "🧨💥", "'; DROP TABLE \"order\";--",
                                  "no", "nothing", "   "]):
            cid = f"gate-{i}"
            h.call(cid)
            h.tool(cid, "add_item", text="single cheeseburger")
            h.tool(cid, "confirm_mods")
            s, r = h.tool(cid, "set_name", text=name)
            check(f"set_name survives {i!r:.40}", s != 500, f"{s}")
            h.tool(cid, "note_allergy", text="none")
            h.tool(cid, "ready_to_place")  # the gate is asked exactly once
            s, r = h.finish(cid)
            body = r if isinstance(r, dict) else {}
            check(f"order places under name {i!r:.40}", body.get("placed"),
                  str(body)[:200])
            oid, code = body.get("order_id"), body.get("short_code")
            if oid:
                s2, _ = h.pay_and_release(oid)
                check(f"dev pay ok for name {i!r:.40}", s2 == 200, f"{s2}")
                s3, html = h.get(f"/t/{code}", key=None)
                if isinstance(html, str):
                    check(f"ticket page escapes name {i!r:.40}",
                          "<script>alert" not in html, html[:120])
        # an over-long allergy note: the server refuses >2000 chars outright;
        # a long-but-deliverable note is bounded by the engine (300) and lands
        # on the ticket intact enough to keep the kitchen safe
        cid = "gate-allergy"
        h.call(cid)
        h.tool(cid, "add_item", text="veggie burger")
        h.tool(cid, "confirm_mods")
        h.tool(cid, "set_name", text="Allergy Tester")
        s, r = h.tool(cid, "note_allergy", text="peanuts " * 700)
        body = r if isinstance(r, dict) else {}
        check("4900-char allergy is refused, not stored raw",
              s != 500 and body.get("ok") is False, f"{s} {str(body)[:160]}")
        s, r = h.tool(cid, "note_allergy", text="severe peanut allergy, "
                                                "epipen in bag " * 10)
        body = r if isinstance(r, dict) else {}
        check("460-char allergy accepted", s == 200 and body.get("ok") is True,
              f"{s} {str(body)[:160]}")
        h.tool(cid, "ready_to_place")
        s, r = h.finish(cid)
        body = r if isinstance(r, dict) else {}
        check("order places under long allergy", body.get("placed"),
              str(body)[:200])
        if body.get("order_id"):
            h.pay_and_release(body["order_id"])
            s3, html = h.get(f"/t/{body['short_code']}", key=None)
            check("ticket renders the allergy note, bounded",
                  isinstance(html, str) and "peanut" in html
                  and html.count("peanut") < 40, str(html)[:120])
        # the gate must not let a caller skip the name forever, but must
        # never block placement either
        cid = "gate-mumble"
        h.call(cid)
        h.tool(cid, "add_item", text="double cheeseburger combo")
        h.tool(cid, "add_modifier", text="Coke")
        h.tool(cid, "confirm_mods")
        s, r = h.tool(cid, "ready_to_place")
        body = r if isinstance(r, dict) else {}
        check("gate asks on ready_to_place",
              (body.get("needs") or {}).get("code") in ("allergy_check",
                                                        "name_check"),
              str(body)[:200])
        h.tool("gate-mumble", "answer", text="😂😂😂")
        s, r = h.finish(cid)
        body = r if isinstance(r, dict) else {}
        check("emoji-only gate answer still places the order",
              body.get("placed"), str(body)[:200])
    finally:
        h.stop()


def t_payment_and_kds_abuse() -> None:
    h = Harness()
    try:
        h.call("pay-twice")
        h.tool("pay-twice", "add_item", text="double cheeseburger combo")
        h.tool("pay-twice", "add_modifier", text="Coke")
        h.tool("pay-twice", "confirm_mods")
        h.tool("pay-twice", "set_name", text="Pay Twice")
        h.tool("pay-twice", "note_allergy", text="none")
        s, r = h.finish("pay-twice")
        body = r if isinstance(r, dict) else {}
        oid, code = body.get("order_id"), body.get("short_code")
        s1, r1 = h.pay_and_release(oid)
        check("first dev pay succeeds", s1 == 200, f"{s1} {r1}")
        s2, r2 = h.pay_and_release(oid)
        check("second dev pay does not double-charge",
              s2 in (200, 409) and (not isinstance(r2, dict)
                                    or r2.get("paid") in (True, None)
                                    or r2.get("ok") is not True
                                    or r2.get("already")),
              f"{s2} {r2}")
        releases = h.store.conn.execute(
            "SELECT COUNT(*) c FROM order_delivery WHERE order_id=?",
            (oid,)).fetchone()["c"]
        check("exactly one kitchen release after double pay", releases == 1,
              str(releases))
        # KDS accept twice
        s3, r3 = h.post(f"/t/{code}/accept", {}, key=None)
        check("first staff accept ok", s3 == 200, f"{s3} {r3}")
        s4, r4 = h.post(f"/t/{code}/accept", {}, key=None)
        check("second accept is already-accepted", s4 == 200
              and (r4 if isinstance(r4, dict) else {}).get("already") is True,
              f"{s4} {r4}")
        # paying a fabricated id
        s5, r5 = h.pay_and_release("00000000-0000-0000-0000-000000000000")
        check("dev pay on unknown id is 404", s5 == 404, f"{s5} {r5}")
        # KDS feed refuses wrong key
        s6, r6 = h.get("/kds/orders?r=bun-n-run-ferndale&k=wrong", key=None)
        check("kds feed refuses wrong key", s6 in (403, 404), f"{s6}")
    finally:
        h.stop()


def t_concurrent_finishers() -> None:
    """Two callers' tools racing on the same call must yield one order."""
    h = Harness()
    try:
        h.call("race-1")
        h.tool("race-1", "add_item", text="double cheeseburger combo")
        h.tool("race-1", "add_modifier", text="Coke")
        h.tool("race-1", "confirm_mods")
        h.tool("race-1", "set_name", text="Racer")
        h.tool("race-1", "note_allergy", text="none")
        h.tool("race-1", "ready_to_place")
        results = []

        def finisher():
            s, r = h.finish("race-1")
            results.append((s, r))

        threads = [threading.Thread(target=finisher) for _ in range(6)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        oids = {(r if isinstance(r, dict) else {}).get("order_id")
                for s, r in results if (r if isinstance(r, dict) else {}).get("placed")}
        check("six concurrent finishes place exactly one order", len(oids) == 1,
              str(oids))
    finally:
        h.stop()


def t_burst_of_real_callers() -> None:
    """Ten simultaneous Bun N Run callers, full happy path each."""
    h = Harness()
    try:
        errs = []

        def caller(i):
            try:
                cid = f"burst-{i}"
                s, _ = h.call(cid, frm=f"+1313555{1000+i:04d}")
                h.tool(cid, "add_item", text="single cheeseburger combo")
                h.tool(cid, "add_modifier", text="Coke")
                h.tool(cid, "confirm_mods")
                h.tool(cid, "set_name", text=f"Burst {i}")
                h.tool(cid, "note_allergy", text="none")
                h.tool(cid, "ready_to_place")
                s, r = h.finish(cid)
                body = r if isinstance(r, dict) else {}
                if not body.get("placed"):
                    errs.append(f"{cid}: {str(body)[:120]}")
                elif body.get("total_cents") != 1324:  # 12.49 combo (drink included) + 6% MI tax, half-up
                    errs.append(f"{cid}: total {body.get('total_cents')}")
            except Exception as exc:  # noqa: BLE001
                errs.append(f"{cid}: {exc!r}")

        threads = [threading.Thread(target=caller, args=(i,)) for i in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        check("ten simultaneous callers all place", not errs, "; ".join(errs[:3]))
        rows = h.store.conn.execute(
            "SELECT COUNT(DISTINCT short_code) c FROM \"order\" WHERE "
            "short_code IS NOT NULL").fetchone()
        check("every placed order got a unique short code",
              rows["c"] >= 10, str(rows["c"]))
        check("server healthy after burst", h.health()[1].get("ok"))
    finally:
        h.stop()


def t_raw_http_abuse() -> None:
    h = Harness()
    try:
        s, r = h.post("/v1/calls", raw=b"this is not json at all")
        check("non-JSON body is not a 500", s != 500, f"{s}")
        s, r = h.post("/v1/calls", raw=b'{"call_id": "' + b"z" * 100000 + b'"}')
        check("100KB body is not a 500", s != 500, f"{s}")
        s, r = h.tool("../../etc/passwd", "add_item", text="fries")
        check("path traversal in call id is safe", s != 500, f"{s}")
        s, r = h.get("/t/..%2F..%2Fetc%2Fpasswd", key=None)
        check("path traversal on ticket page is safe", s != 200, f"{s}")
        s, r = h.get("/kds/orders?r=bun-n-run-ferndale&k=<script>", key=None)
        check("script in kds key refused", s in (403, 404), f"{s}")
        s, r = h.post("/v1/calls", {"call_id": "nokey", "to": "+13135551000",
                                    "from": "+13135550123"}, key="wrong-key")
        check("wrong API key rejected on calls", s in (401, 403), f"{s}")
        s, r = h.tool("unicode-🔫", "add_item", text="fries")
        check("emoji call id is handled", s != 500, f"{s}")
        check("server healthy after raw HTTP battery", h.health()[1].get("ok"))
    finally:
        h.stop()


def t_cross_location_isolation() -> None:
    """Ferndale and Clinton share a menu and a brand. They must not share
    tickets: an order on one number can never surface on the other's tablet."""
    h = Harness()
    try:
        import server as _srv
        ferndale_key = _srv.kds_key(KEY, "bun-n-run-ferndale")
        clinton_key = _srv.kds_key(KEY, "bun-n-run-clinton")
        check("display keys differ per location", ferndale_key != clinton_key)

        # one order on each location's published number
        h.call("iso-ferndale", to="+13135551000")
        h.tool("iso-ferndale", "add_item", text="double cheeseburger combo")
        h.tool("iso-ferndale", "add_modifier", text="Coke")
        h.tool("iso-ferndale", "confirm_mods")
        h.tool("iso-ferndale", "set_name", text="Ferndale Caller")
        h.tool("iso-ferndale", "note_allergy", text="none")
        h.tool("iso-ferndale", "ready_to_place")
        s, rf = h.finish("iso-ferndale")
        check("ferndale call places", (rf if isinstance(rf, dict) else {}).get("placed"),
              str(rf)[:160])

        h.call("iso-clinton", to="+15865551000")
        h.tool("iso-clinton", "add_item", text="veggie burger combo")
        h.tool("iso-clinton", "add_modifier", text="Lemonade")
        h.tool("iso-clinton", "confirm_mods")
        h.tool("iso-clinton", "set_name", text="Clinton Caller")
        h.tool("iso-clinton", "note_allergy", text="none")
        h.tool("iso-clinton", "ready_to_place")
        s, rc = h.finish("iso-clinton")
        bc = rc if isinstance(rc, dict) else {}
        check("clinton call places", bc.get("placed"), str(rc)[:160])

        if bc.get("order_id"):
            row = h.store.conn.execute(
                'SELECT restaurant_id FROM "order" WHERE id=?',
                (bc["order_id"],)).fetchone()
            check("clinton order belongs to clinton",
                  row["restaurant_id"] == "bun-n-run-clinton", str(row))

        # Ferndale's tablet must not show Clinton's ticket and vice versa
        s, pf = h.pay_and_release(bc["order_id"])
        s, feed_c = h.get(f"/kds/orders?r=bun-n-run-clinton&k={clinton_key}",
                          key=None)
        codes_c = json.dumps(feed_c) if not isinstance(feed_c, str) else feed_c
        check("clinton feed shows the clinton order",
              bc.get("short_code") in codes_c, codes_c[:200])
        s, feed_f = h.get(f"/kds/orders?r=bun-n-run-ferndale&k={ferndale_key}",
                          key=None)
        codes_f = json.dumps(feed_f) if not isinstance(feed_f, str) else feed_f
        check("ferndale feed never shows the clinton order",
              bc.get("short_code") not in codes_f, codes_f[:200])
        # one location's key cannot open the other's feed
        s, _ = h.get(f"/kds/orders?r=bun-n-run-clinton&k={ferndale_key}",
                     key=None)
        check("ferndale key refused on clinton feed", s in (403, 404), f"{s}")
        # a call to a number no restaurant owns is handled, not a 500
        s, r = h.post("/v1/calls", {"call_id": "iso-unknown",
                                    "to": "+19995550000",
                                    "from": "+13135550123"})
        check("unknown number routes nowhere, gracefully", s != 500, f"{s}")
    finally:
        h.stop()


def main() -> None:
    batteries = [
        t_hostile_text_never_breaks_the_call,
        t_quantity_abuse,
        t_alias_traps_read_right,
        t_combo_drink_math,
        t_flow_abuse,
        t_gate_abuse,
        t_payment_and_kds_abuse,
        t_concurrent_finishers,
        t_burst_of_real_callers,
        t_raw_http_abuse,
        t_cross_location_isolation,
    ]
    for fn in batteries:
        print(f"== {fn.__name__}")
        fn()
    print(f"\n{_passed} passed, {_failed} failed")
    if _FAILS:
        print("failed checks:")
        for name in _FAILS:
            print(f"  - {name}")


if __name__ == "__main__":
    main()
