"""Owner support, on one path: ops alerts and owner messages into Slack.

The BUSINESS TOOLS automation suite (Week 1) specifies a Slack support bot;
``ops_monitor`` deliberately leaves alert delivery to the caller. This module
is the missing bridge — one function, one webhook URL, no SDK:

- ``notify_support`` posts an owner-facing message (question, complaint,
  request) to the support channel.
- ``notify_alerts`` posts the ops snapshot's actionable alerts (the reviewed,
  identity-free source — ``START_HERE.md``) so the founder sees a failing
  location before the owner calls.

Failure behaviour is the same honesty the rest of the system uses: a missing
webhook URL is a clean no-op reporting ``disabled`` (local development must
not crash on missing infra), and a failed POST is returned, never swallowed —
a support message that silently vanished is worse than one that errored.
"""

from __future__ import annotations

import json
import os
import urllib.request
from typing import Any, Dict, List, Optional

WEBHOOK_ENV = "CHERRY_SUPPORT_SLACK_WEBHOOK"
_TIMEOUT = 10.0


def _post(url: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    """Slack incoming-webhook POST. Returns {ok, status, error?}."""
    body = json.dumps(payload).encode()
    req = urllib.request.Request(url, data=body,
                                 headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
            return {"ok": resp.status == 200, "status": resp.status}
    except Exception as exc:                    # urllib raises broadly
        return {"ok": False, "status": None, "error": str(exc)}


def _esc(text: Any) -> str:
    """Slack's own escaping: owner-written text must not become a mention
    (<!channel>) or a link."""
    return str(text).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _alert_line(alert: Any) -> str:
    """One alert as a phone-sized line. The snapshot's alerts are dicts with
    severity/title/detail/action; anything else is shown as-is, never dropped."""
    if isinstance(alert, dict) and alert.get("title"):
        head = f"*{_esc(alert.get('severity') or 'alert')}* {_esc(alert['title'])}"
        detail = str(alert.get("detail") or "")[:300]
        action = str(alert.get("action") or "")[:200]
        return (head + (f" — {_esc(detail)}" if detail else "")
                + (f" → {_esc(action)}" if action else ""))
    return _esc(alert)


def _blocks(text: str, fields: Optional[Dict[str, str]] = None) -> List[Dict]:
    block: Dict[str, Any] = {"type": "section",
                             "text": {"type": "mrkdwn", "text": text}}
    if fields:
        block["fields"] = [{"type": "mrkdwn", "text": f"*{k}*\n{v}"}
                           for k, v in fields.items()]
    return [block]


def notify_support(text: str, *, restaurant: str = "",
                   severity: str = "normal",
                   webhook_url: Optional[str] = None) -> Dict[str, Any]:
    """One owner message into the support channel."""
    url = webhook_url or os.environ.get(WEBHOOK_ENV, "")
    if not url:
        return {"ok": False, "status": "disabled"}
    icon = {"normal": ":speech_balloon:", "urgent": ":rotating_light:",
            "billing": ":dollar:"}.get(severity, ":speech_balloon:")
    header = f"{icon} *{_esc(restaurant)}* — support" if restaurant \
        else f"{icon} Cherry support"
    text = _esc(text)
    return _post(url, {"text": f"{header}\n{text}",
                       "blocks": _blocks(f"{header}\n{text}")})


def notify_alerts(alerts: List[Dict[str, Any]], *,
                  webhook_url: Optional[str] = None) -> Dict[str, Any]:
    """The ops snapshot's alerts, formatted for a founder scanning a phone.

    Alerts come from ``/v1/ops/snapshot`` — already identity-free. An empty
    list is reported, not posted: silence should mean quiet, not a lost
    connection.
    """
    url = webhook_url or os.environ.get(WEBHOOK_ENV, "")
    if not url:
        return {"ok": False, "status": "disabled"}
    if not alerts:
        return {"ok": True, "status": 200, "posted": False}
    lines = "\n".join(f"• {_alert_line(a)}" for a in alerts[:20])
    return _post(url, {"text": f":warning: *Cherry ops alerts*\n{lines}"})


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2 or sys.argv[1] not in ("test", "send"):
        print("usage: support_bridge.py test | send 'message' [restaurant]")
        raise SystemExit(2)
    if sys.argv[1] == "test":
        print("webhook:", "set" if os.environ.get(WEBHOOK_ENV)
              else "NOT SET (disabled — set CHERRY_SUPPORT_SLACK_WEBHOOK)")
        raise SystemExit(0)
    msg = sys.argv[2]
    rest = sys.argv[3] if len(sys.argv) > 3 else ""
    result = notify_support(msg, restaurant=rest)
    print(result)
    raise SystemExit(0 if result.get("ok") else 1)
