# Provisioning a location's phone number (Telnyx)

`provision.py` does the portal steps for a new restaurant from the command line: buy a number, route it
to the voice connection, attach the messaging profile, assign it to the 10DLC campaign, and record it in
the server's env file. It says plainly what is done, what is waiting on a carrier, and what is left.

**Status: written against Telnyx's documentation (checked 2026-10-02) and tested with a fake Telnyx
(74 checks in `test_provision.py`). It has never been run against a live account.** The first real run
should be `status` and `plan` only. Those read and change nothing.

## What it will and won't do

- `status` and `plan` are **read-only**.
- `apply` **buys a number (real money)**. It needs the exact `--number` from `plan`, a price under the caps,
  and `--yes`. It never picks a number for you.
- Caps default to **$5.00 monthly and $5.00 upfront**. Raise them per run with `--max-monthly-usd` and
  `--max-upfront-usd`. A number above the cap is refused before anything is ordered.
- It never buys twice. After a timeout or a Telnyx 5xx on the order, it looks for the order (by a
  `customer_reference` it set) and for the number, and does not send the order again. A pending order is
  waited for, not repeated. A rate limit (429) is the only case it retries a purchase.
- It never takes over a number that is already on your account but not tagged for this location.
- A location never ends up with two numbers.
- The API key is read by name (`TELNYX_API_KEY`, or the vault) and is never printed or logged.

## Configuration

Set these in your own shell or in the server's `cherry.env`. Do not paste keys into a chat.

| Variable | What it is |
|---|---|
| `TELNYX_API_KEY` | Telnyx API key (read by name; also accepted from the vault) |
| `TELNYX_CONNECTION_ID` | The voice connection every Cherry number routes through (the one pointed at Inworld) |
| `TELNYX_MESSAGING_PROFILE` | Messaging profile that carries the checkout texts |
| `TELNYX_10DLC_CAMPAIGN_ID` | The approved 10DLC campaign numbers are assigned to |
| `TELNYX_BILLING_GROUP_ID` | Optional |

The connection, messaging profile and campaign must already exist in Telnyx. The 10DLC campaign must be
**approved and active** before numbers can be assigned to it. That registration is done by hand in Telnyx
and takes days, so start it first.

## Usage

```bash
export TELNYX_API_KEY=...        # in your shell, not in chat
export TELNYX_CONNECTION_ID=... TELNYX_MESSAGING_PROFILE=... TELNYX_10DLC_CAMPAIGN_ID=...

python3 provision.py status --all                       # every location: done / todo / waiting / failed / blocked
python3 provision.py status --location pink-garlic-shelby
python3 provision.py plan --location pink-garlic-shelby --area-code 586 --limit 5   # numbers for sale and their cost

# the one command that spends money:
python3 provision.py apply --location pink-garlic-shelby --number +15865550123 --yes \
    --env-file /etc/cherry/cherry.env
# options: --replace-env (overwrite a different number already in the env file),
#          --skip-campaign (skip 10DLC for now), --max-monthly-usd N, --max-upfront-usd N
```

`apply` steps, each checked before it acts: **number** (buy it, or find that you already own it) →
**voice-connection** (route and tag it) → **messaging-profile** → **10dlc** (assign to the campaign) →
**env** (write the number to the env file, atomically, keeping the file's permissions; it refuses to overwrite a
different value without `--replace-env`). For a Square location, `status` also shows a **square** step: has the
owner approved Cherry in Square (`square_oauth.py authorize-url`).

## Reading the status

| State | Meaning |
|---|---|
| done | Nothing to do |
| todo | `apply` will do it |
| waiting | A carrier is working (or an order is pending). **10DLC assignment takes hours, up to 72 h to propagate; this is normal.** Re-run `apply`; it will not buy again |
| failed | Telnyx said no, or the env file and Telnyx disagree about the number; the detail is printed |
| blocked | A setting is not set (`TELNYX_CONNECTION_ID`, `TELNYX_MESSAGING_PROFILE` or `TELNYX_10DLC_CAMPAIGN_ID`), or you passed `--skip-campaign` |

Running `apply` again on a finished location changes nothing.

## Known uncertainties

- Telnyx's 10DLC pages name the assignment path two ways (`/10dlc/phone_number_campaigns` in the API
  reference, `/10dlc/phoneNumberCampaign` in the guide). Both are tried. If neither works on your account,
  assign the number in the portal and `status` will pick it up.
- Number lookup (landline vs mobile) can answer "fixed line or mobile". Measure how often with
  `lookup_probe.py` before building anything on it.

## Before the first real run

- [ ] The connection, messaging profile and approved 10DLC campaign exist in Telnyx.
- [ ] Env variables above are set in your shell.
- [ ] `status --all` and `plan --location ...` run cleanly (read-only).
- [ ] You have looked at the price `plan` printed and agree.
- [ ] Then, and only then, `apply ... --yes` for one location. Check the Telnyx portal shows the number
      routed, then place a test call.
