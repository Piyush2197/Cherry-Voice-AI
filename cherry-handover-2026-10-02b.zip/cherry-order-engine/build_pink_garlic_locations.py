#!/usr/bin/env python3
"""Build the Oak Park and Allen Park Pink Garlic voice menus.

The source is each location's published Grubhub menu, captured 2026-09-20.
Those pages explicitly warn that platform prices can differ from in-store and
between pickup and delivery, so these files are safe for order-engine testing
but remain deployment-blocked until the developer verifies them against the
location's Square catalog and supplies location-specific POS references.

Shelby's menu supplies the already-tested cuisine modifier model.  Only item
shape is reused: location item availability and prices come from the two
published location menus, and all Shelby POS references are stripped.
"""

from __future__ import annotations

import _ensure_deps  # noqa: F401  (re-runs under .venv, or says how to install, if PyYAML is missing)
from copy import deepcopy
from pathlib import Path
from typing import Dict, Iterable

import yaml


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "menus" / "pink-garlic-shelby.yaml"

SOURCES = {
    "pink-garlic-oak-park": (
        "https://www.grubhub.com/restaurant/"
        "pink-garlic-indian-cuisine-26661-coolidge-hwy-oak-park/3004028"),
    "pink-garlic-allen-park": (
        "https://www.grubhub.com/restaurant/"
        "pink-garlic-indian-cuisine-18625-ecorse-road-allen-park/7927584"),
}


def prices(default: str, ids: Iterable[str], **overrides: str) -> Dict[str, str]:
    out = {item_id: default for item_id in ids}
    out.update(overrides)
    return out


APPETIZERS = (
    "pg_2_papadam_and_chutney pg_onion_baji_2pcs pg_veg_samosa_2pcs "
    "pg_meat_samosa_2pcs pg_veg_pakora pg_chk_pakora pg_chk_wings_4pcs "
    "pg_prawn_puri pg_pg_chk pg_mix_starter pg_chk_tikka_wrap pg_veg_wrap "
    "pg_momo_s pg_chk_chat_puri"
).split()
TANDOORI = (
    "pg_chk_tikka pg_half_chk_tandoori pg_full_tandoori_chk pg_sheek_kabab "
    "pg_tandoori_king_prawn pg_tandoori_mix_grill pg_paneer_tikka_shaslik "
    "pg_chk_shaslik"
).split()
CHICKEN = (
    "pg_butter_chk_creamy pg_chk_tikka_masala_creamy pg_chk_korma_creamy "
    "pg_chk_curry pg_chk_bhuna pg_chk_dansak pg_chk_vindaloo "
    "pg_chk_tikka_balti pg_chk_karahi pg_chk_65 pg_naga_chk "
    "pg_pink_garlic_chk pg_chk_saag pg_shatkora_chk pg_chk_achari "
    "pg_chk_jalferzi pg_chk_chetinado pg_chk_tikka_patia pg_chk_rogan "
    "pg_chk_madras"
).split()
LAMB = (
    "pg_lamb_goat_curry pg_lamb_goat_vindaloo pg_lamb_goat_korma_creamy "
    "pg_lamb_goat_balti pg_lamb_goat_bhuna pg_lamb_goat_karahi "
    "pg_lamb_goat_achari pg_lamb_goat_dansak "
    "pg_lamb_goat_tikka_masala_creamy pg_lamb_goat_saag "
    "pg_lamb_goat_rogan pg_lamb_goat_chetinad pg_lamb_goat_naga"
).split()
BIRYANI = (
    "pg_chk_tikka_biryani pg_lamb_goat_biryani pg_veg_biryani "
    "pg_shrimp_biryani pg_fish_biryani pg_boneless_chk_biryani pg_pg_biryani"
).split()
SEAFOOD = (
    "pg_tandoori_king_prawn_masala_creamy pg_naga_king_prawn "
    "pg_mix_seafood_curry pg_fish_jalfrezi pg_king_prawn_sagwa "
    "pg_shrimp_dansak"
).split()
VEGETABLES = (
    "pg_veg_curry_vegan pg_veg_korma pg_tarka_daal_vegan pg_saag_paneer "
    "pg_bombay_aloo_vegan pg_bindi_baji_vegan pg_aloo_gobi_vegan "
    "pg_saag_aloo_vegan pg_chana_masala_vegan pg_karahi_paneer "
    "pg_matar_paneer pg_paneer_tikka_masala"
).split()
KIDS = "pg_french_fries pg_chk_nugget_and_chips pg_chk_tender_and_fries".split()
RICE = (
    "pg_chk_fried_rice pg_egg_fried_rice pg_veg_fried_rice "
    "pg_shrimp_fried_rice pg_coco_rice pg_bowl_of_rice"
).split()
BREAD = (
    "pg_plain_naan pg_garlic_naan pg_peshwari_naan pg_garlic_cheese_naan "
    "pg_garlic_chili_naan pg_pg_sp_naan pg_kulcha_naan pg_cheese_naan "
    "pg_aloo_paratha pg_paratha"
).split()


OAK_PRICES = {}
OAK_PRICES.update(prices("14.99", CHICKEN, pg_chk_saag="13.99"))
OAK_PRICES.update(prices("15.99", LAMB))
OAK_PRICES.update(prices("14.99", BIRYANI,
                         pg_lamb_goat_biryani="15.99",
                         pg_veg_biryani="13.99",
                         pg_shrimp_biryani="15.99",
                         pg_pg_biryani="15.49"))
OAK_PRICES.update(prices("14.99", SEAFOOD))
OAK_PRICES.update(prices("12.99", VEGETABLES,
                         pg_veg_curry_vegan="11.99",
                         pg_chana_masala_vegan="11.99",
                         pg_paneer_tikka_masala="13.99"))
OAK_PRICES.update(prices("13.99", ["pg_mango_chk", "pg_orange_chk", "pg_chk_manchurian"]))
OAK_PRICES.update(dict(zip(APPETIZERS, (
    "2.99 5.49 5.49 5.49 5.49 8.99 7.49 8.99 8.49 8.99 8.99 7.99 6.99 8.49"
).split())))
OAK_PRICES.update(dict(zip(TANDOORI, (
    "13.99 12.99 18.99 14.99 17.99 23.99 14.99 14.99"
).split())))
OAK_PRICES.update({
    "pg_pink_garlic_soup": "7.99", "pg_lentil_soup": "6.99",
    "pg_tomato_soup": "6.99", "pg_green_salad": "6.99",
    "pg_chef_sp_salad": "7.99", "pg_shrimp_curry": "14.99",
    "pg_shrimp_korma": "14.99", "pg_fish_curry": "14.99",
    "pg_fish_korma": "14.99", "pg_paneer_korma": "13.99",
    "pg_saag_baji_vegan": "13.99", "pg_veg_masala": "13.99",
    "pg_saag_daal_vegan": "13.99", "pg_half_tray_any_chk_dish": "60.00",
    "pg_full_tray_any_chk_dish": "120.00",
    "pg_half_tray_any_lamb_goat_dish": "70.00",
    "pg_full_tray_any_lamb_goat_dish": "130.00",
    "pg_half_tray_any_veg_dish": "45.00",
    "pg_full_tray_any_veg_dish": "90.00", "pg_half_tray_rice": "50.00",
    "pg_full_tray_rice": "100.00", "pg_chutnis": "0.99",
    "pg_rice_pudding": "4.49", "pg_mango_lassi": "4.99",
    "pg_can_of_coke_d_coke_pepsi_dr_paper_7up_sprit_m": "2.25",
    "pg_tando_roti": "3.49",
})
OAK_PRICES.update(dict(zip(KIDS, "3.49 8.99 8.99".split())))
OAK_PRICES.update(dict(zip(RICE, "12.99 12.99 11.99 12.99 12.49 2.49".split())))
OAK_PRICES.update(dict(zip(BREAD, "2.49 3.49 4.49 3.99 3.99 4.49 3.49 4.49 3.49 2.49".split())))


ALLEN_PRICES = {}
ALLEN_PRICES.update(prices("14.99", CHICKEN))
ALLEN_PRICES.update(prices("14.99", LAMB))
ALLEN_PRICES.update(prices("14.99", BIRYANI,
                           pg_lamb_goat_biryani="15.99",
                           pg_veg_biryani="13.99",
                           pg_shrimp_biryani="15.99",
                           pg_pg_biryani="15.99"))
ALLEN_PRICES.update(prices("15.99", SEAFOOD))
ALLEN_PRICES.update(prices("12.99", VEGETABLES,
                           pg_paneer_tikka_masala="13.99"))
ALLEN_PRICES.update(prices("14.99", ["pg_mango_chk", "pg_orange_chk",
                                      "pg_chk_manchurian", "pg_gobi_manchurian"]))
ALLEN_PRICES.update(dict(zip(APPETIZERS, (
    "2.99 5.49 5.49 5.99 5.49 8.99 7.99 8.99 8.49 8.99 8.99 7.99 6.99 7.99"
).split())))
ALLEN_PRICES.update(dict(zip(TANDOORI, (
    "13.49 12.99 18.99 14.99 17.99 23.99 14.99 14.99"
).split())))
ALLEN_PRICES.update({
    "pg_lentil_soup": "5.49", "pg_chicken_manchurian_soup": "13.99",
    "pg_green_salad": "5.49", "pg_chk_tikka_balti_rogan": "14.99",
    "pg_pg_mix_seafood_curry": "15.99", "pg_shrimp_dansak": "15.99",
    "pg_bhindi_masala": "12.99", "pg_chutnis": "0.99",
    "pg_gulab_jam": "4.49", "pg_rice_pudding": "4.49",
    "pg_mango_lassi": "4.49",
    "pg_can_of_coke_d_coke_pepsi_dr_paper_7up_sprit_m": "2.25",
})
ALLEN_PRICES.update(dict(zip(KIDS, "4.49 8.99 8.99".split())))
ALLEN_PRICES.update(dict(zip(RICE, "12.99 12.99 11.99 13.99 12.49 2.49".split())))
ALLEN_PRICES.update(dict(zip(BREAD, "2.99 3.49 3.99 3.99 3.99 4.49 3.99 4.49 4.49 2.49".split())))


NEW_ITEMS = {
    "pg_sheek_kabab": ("pg_chk_tikka", "Sheek Kabab", "tandoori"),
    "pg_pink_garlic_soup": ("pg_lentil_soup", "Pink Garlic Soup", "soup_salad"),
    "pg_tomato_soup": ("pg_lentil_soup", "Tomato Soup", "soup_salad"),
    "pg_chicken_manchurian_soup": ("pg_lentil_soup", "Chicken Manchurian Soup", "soup_salad"),
    "pg_fish_curry": ("pg_shrimp_curry", "Fish Curry", "seafood"),
    "pg_fish_korma": ("pg_shrimp_korma", "Fish Korma", "seafood"),
    "pg_chutnis": ("pg_red_onion", "Chutneys", "condiment"),
    "pg_chk_tikka_balti_rogan": ("pg_chk_rogan", "Chicken Tikka Balti Rogan Josh", "chicken"),
    "pg_pg_mix_seafood_curry": ("pg_mix_seafood_curry", "Pink Garlic Special Mix Seafood Curry", "seafood"),
    "pg_bhindi_masala": ("pg_bindi_baji_vegan", "Bhindi Masala", "vegetable"),
}


def build(location_id: str, name: str, price_map: Dict[str, str]) -> Path:
    doc = yaml.safe_load(BASE.read_text())
    doc["restaurant"]["id"] = location_id
    doc["restaurant"]["name"] = name
    doc["restaurant"]["notes"] = (
        "Built from the location's published menu on 2026-09-20; verify "
        "prices and POS references against Square before activation.")

    base_items = {item["id"]: item for item in doc["items"]}
    for item_id, (template_id, spoken_name, category) in NEW_ITEMS.items():
        if item_id not in price_map:
            continue
        item = deepcopy(base_items[template_id])
        item.update(id=item_id, name=spoken_name, category=category,
                    aliases=[spoken_name.lower()])
        base_items[item_id] = item

    missing = sorted(set(price_map) - set(base_items))
    if missing:
        raise ValueError(f"{location_id}: no item template for {missing}")

    selected = []
    for item_id, amount in price_map.items():
        item = deepcopy(base_items[item_id])
        item["price"] = amount
        item.pop("price_cents", None)
        item.pop("pos_refs", None)
        selected.append(item)
    doc["items"] = selected
    for option in doc.get("options", []):
        option.pop("pos_refs", None)

    source = SOURCES[location_id]
    header = (
        f"# Generated by build_pink_garlic_locations.py\n"
        f"# Published location menu: {source}\n"
        "# Price channel: Grubhub public menu captured 2026-09-20.\n"
        "# Activation requires Square price/POS-reference verification.\n")
    out = ROOT / "menus" / f"{location_id}.yaml"
    out.write_text(header + yaml.safe_dump(doc, sort_keys=False, width=1000))
    return out


def main() -> int:
    paths = [
        build("pink-garlic-oak-park", "Pink Garlic Indian Cuisine (Oak Park)", OAK_PRICES),
        build("pink-garlic-allen-park", "Pink Garlic Indian Cuisine (Allen Park)", ALLEN_PRICES),
    ]
    for path in paths:
        print(path.relative_to(ROOT))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# NOTE (2026-10-02): menus/*.yaml are now the SOURCE OF TRUTH.
# Re-running this builder REGENERATES the YAML from the captured TSV and
# will OVERWRITE hand-edits made since (spoken aliases added by the
# language pass — "papadams", "spright" — and any owner answers). Do not
# re-run without diffing against the current YAML first.
