#!/usr/bin/env python3
"""Tests for exact, fail-closed location menu generation."""

from __future__ import annotations

import _ensure_deps  # noqa: F401  (re-runs under .venv, or says how to install, if PyYAML is missing)
import traceback
from pathlib import Path

import yaml

from location_catalog import LocationCatalogError, build_location_doc


ROOT = Path(__file__).parent
_passed = _failed = 0


def check(name, condition, detail=""):
    global _passed, _failed
    if condition:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


def _base():
    return yaml.safe_load((ROOT / "menus" / "bun-n-run-ferndale.yaml").read_text())


def _export(doc):
    return [{"catalog_object_id": f"var-{row['id']}",
             "item_id": f"item-{row['id']}", "name": row["name"],
             "variation_name": "Regular",
             "price_cents": int(float(row["price"]) * 100),
             "currency": "USD", "available": True}
            for row in doc["items"]]


def t_builds_a_separate_location_with_current_prices_and_refs():
    base = _base()
    exported = _export(base)
    burger = next(x for x in exported if x["name"] == "Single Cheeseburger")
    burger["price_cents"] = 999
    doc, counts = build_location_doc(
        base, exported, restaurant_id="bun-n-run-third",
        restaurant_name="Bun N Run (Third)")
    item = next(x for x in doc["items"] if x["id"] == "single_cheeseburger")
    check("the location has its own id", doc["restaurant"]["id"] == "bun-n-run-third")
    check("the exported price replaces the base price", item["price"] == "9.99")
    check("the stable Square variation id is saved",
          item["pos_refs"]["square_catalog_object_id"] ==
          "var-single_cheeseburger")
    check("the change count is inspectable", counts["prices"] == 1, str(counts))


def t_missing_base_item_blocks_the_whole_output():
    base = _base()
    exported = [x for x in _export(base) if x["name"] != "Water"]
    try:
        build_location_doc(base, exported, restaurant_id="x", restaurant_name="X")
    except LocationCatalogError as exc:
        check("the missing item is named", "Water" in str(exc), str(exc))
    else:
        check("a partial location catalog is rejected", False)


def t_unknown_square_item_blocks_the_whole_output():
    base = _base()
    exported = _export(base)
    exported.append({"catalog_object_id": "new-var", "item_id": "new-item",
                     "name": "Secret Burger", "variation_name": "Regular",
                     "price_cents": 1299, "available": True})
    try:
        build_location_doc(base, exported, restaurant_id="x", restaurant_name="X")
    except LocationCatalogError as exc:
        check("the unknown Square item is named", "Secret Burger" in str(exc), str(exc))
    else:
        check("an unmodelled item is rejected", False)


def t_duplicate_square_match_is_not_guessed():
    base = _base()
    exported = _export(base)
    exported.append(dict(exported[0], catalog_object_id="duplicate-var"))
    try:
        build_location_doc(base, exported, restaurant_id="x", restaurant_name="X")
    except LocationCatalogError as exc:
        check("the duplicate explains the claimed item", "already claimed" in str(exc),
              str(exc))
    else:
        check("a duplicate mapping is rejected", False)


def main() -> int:
    for name, fn in sorted(globals().items()):
        if not name.startswith("t_"):
            continue
        try:
            fn()
        except Exception:
            global _failed
            _failed += 1
            print(f"\n--- FAIL {name}\n{traceback.format_exc()}")
    print(f"\n{_passed} passed, {_failed} failed (location catalog builder)")
    return 1 if _failed else 0


if __name__ == "__main__":
    raise SystemExit(main())

