#!/usr/bin/env python3
"""
cherry — the onboarding pipeline, as one command.

    ./cherry.py new burger naked-burger --name "Naked Burger"
        Scaffold a YAML from the closest cuisine template.

    ./cherry.py ingest menu.txt --cuisine burger -o menus/naked-burger.yaml
        Read raw menu text, propose a draft, print every question the owner
        has to answer. Never invents a price.

    ./cherry.py check menus/naked-burger.yaml
        THE GATE. Schema check, config lint, cuisine-library lint, and every
        conformance invariant the eight cuisine packs pass. Exit code 0 means
        it is safe to put in front of a caller.

    ./cherry.py play menus/naked-burger.yaml
        Order by hand, as a caller. This is the Wizard-of-Oz harness.

    ./cherry.py play menus/naked-burger.yaml --script calls/nb1.txt
        Same thing, scripted — how every restaurant gets hand-tested in CI.

    ./cherry.py keyterms menus/naked-burger.yaml
        The speech-recogniser boost list, ranked and budget-capped.

    ./cherry.py ls
        Every restaurant in menus/, with its state.

    ./cherry.py onboard new|status|packet ...
        The two-business-day onboarding case and launch-packet workflow.
"""

from __future__ import annotations

import _ensure_deps  # noqa: F401  (re-runs under .venv, or says how to install, if PyYAML is missing)
import argparse
import sys
import traceback
from pathlib import Path
from typing import List, Optional

import menu_schema as ms
from config_validator import lint_config
from agent_api import CallSession
from order_engine import IssueCode, OrderEngine, Placement, money

MENUS = Path(__file__).parent / "menus"

BOLD, DIM, RED, GRN, YEL, CYA, OFF = (
    "\033[1m", "\033[2m", "\033[31m", "\033[32m", "\033[33m", "\033[36m", "\033[0m")


def _resolve(target: str) -> Path:
    p = Path(target)
    if p.exists():
        return p
    for cand in (MENUS / target, MENUS / f"{target}.yaml"):
        if cand.exists():
            return cand
    sys.exit(f"no such menu: {target}")


# ---------------------------------------------------------------------------
# check — the gate
# ---------------------------------------------------------------------------


def cmd_owner_questions(args) -> int:
    """Accumulate this menu's owner questions into the ledger. Always exits
    0: questions are work for a conversation with the owner, never a gate."""
    import owner_questions as oq
    import yaml
    path = _resolve(args.menu)
    doc = yaml.safe_load(path.read_text())
    problems = ms.validate_doc(doc)
    if problems:
        print(f"{RED}schema problems — fix before collecting:{OFF}")
        for p in problems[:8]:
            print(f"  - {p}")
        return 0
    cfg = ms.build_config(doc)
    base = Path(args.dir)
    if args.answer:
        q = oq.answer(base, cfg.id, args.answer[0], args.answer[1])
        if q is None:
            print(f"{YEL}no question matching {args.answer[0]!r} "
                  f"for {cfg.id}{OFF}")
        else:
            print(f"{GRN}answered{OFF} ({q.source}): {q.text}\n  -> {q.answer}")
        return 0
    ledger, added = oq.accumulate(cfg, base)
    print(oq.render(ledger, show_all=args.all))
    if added:
        print(f"\n{YEL}{added} new question(s) recorded{OFF}")
    else:
        print(f"\n{DIM}no new questions — ledger already current{OFF}")
    return 0


def cmd_check(args) -> int:
    path = _resolve(args.menu)
    print(f"{BOLD}checking {path.name}{OFF}")
    failures = 0

    # 1. schema
    import yaml
    doc = yaml.safe_load(path.read_text())
    problems = ms.validate_doc(doc)
    if problems:
        print(f"  {RED}schema: {len(problems)} problem(s){OFF}")
        for p in problems[:20]:
            print(f"    - {p}")
        return 1
    print(f"  {GRN}schema ok{OFF}")

    cfg = ms.build_config(doc)
    print(f"  {len(cfg.items)} items, {len(cfg.groups)} groups, "
          f"{len(cfg.options)} options")

    # 2. structural lint
    findings = lint_config(cfg)
    errs = [f for f in findings if f.level == "ERROR"]
    warns = [f for f in findings if f.level == "WARN"]
    if errs:
        failures += 1
        print(f"  {RED}lint: {len(errs)} error(s){OFF}")
        for f in errs[:20]:
            print(f"    - {f}")
    else:
        print(f"  {GRN}lint ok{OFF} ({len(warns)} warning(s))")
    if args.verbose:
        for f in warns:
            print(f"    {YEL}warn{OFF} {f}")

    # 3. cuisine-library lint — advisory
    try:
        import menu_ingest as mi
        lib = mi.library_lint(cfg, cfg.cuisine)
        if lib:
            print(f"  {YEL}library: {len(lib)} question(s) for the owner{OFF}")
            for f in lib[: (99 if args.verbose else 4)]:
                print(f"    ? {f[:150]}")
    except Exception as exc:                       # advisory only
        print(f"  {DIM}library lint skipped: {exc}{OFF}")

    # 4. the conformance invariants — the real gate
    try:
        from test_conformance import INVARIANTS
    except Exception as exc:
        print(f"  {RED}could not load invariants: {exc}{OFF}")
        return 1
    passed, failed = 0, []
    for inv in INVARIANTS:
        try:
            inv(cfg.id, cfg)
            passed += 1
        except Exception as exc:
            failed.append((inv.__name__, exc))
    if failed:
        failures += 1
        print(f"  {RED}invariants: {len(failed)} failed, {passed} passed{OFF}")
        for n, e in failed:
            print(f"    - {n}: {str(e)[:200]}")
    else:
        print(f"  {GRN}invariants ok{OFF} ({passed} passed)")

    # 5. items with no price are a blocking, human-readable list
    unpriced = [i.name for i in cfg.items
                if not i.has_sizes and i.base_price_cents <= 0]
    if unpriced:
        failures += 1
        print(f"  {RED}{len(unpriced)} item(s) have no price{OFF}: "
              f"{', '.join(unpriced[:6])}")

    print(f"\n{GRN + 'READY' + OFF if not failures else RED + 'NOT READY' + OFF}"
          f" — {path.name}")
    return 1 if failures else 0


# ---------------------------------------------------------------------------
# ingest
# ---------------------------------------------------------------------------


def cmd_ingest(args) -> int:
    import menu_ingest as mi
    text = Path(args.textfile).read_text()

    cuisine = args.cuisine
    if not cuisine:
        guesses = mi.detect_cuisine(text)
        if not guesses:
            sys.exit("could not detect a cuisine; pass --cuisine")
        cuisine = guesses[0].cuisine_id
        print(f"{BOLD}cuisine{OFF}: {cuisine} "
              f"(score {guesses[0].score:.1f}; runners-up: "
              f"{', '.join(g.cuisine_id for g in guesses[1:])})")

    prop = mi.propose(text, cuisine)
    print(f"{BOLD}{prop.summary()}{OFF}\n")

    if prop.unparsed_lines:
        print(f"{YEL}lines not understood ({len(prop.unparsed_lines)}){OFF}")
        for l in prop.unparsed_lines[:10]:
            print(f"  ? {l[:100]}")
        print()

    print(f"{BOLD}questions for the owner{OFF}")
    for c in prop.confirmations:
        colour = RED if c.blocking else YEL
        print(f"  {colour}{c}{OFF}")

    if args.out:
        doc = {
            "schema_version": ms.SCHEMA_VERSION,
            "restaurant": {
                "id": args.id or "TODO-restaurant-id",
                "name": args.name or "TODO Restaurant Name",
                "cuisine": cuisine,
                "tax_rate_bps": 0,
                "pay_now_threshold_cents": 3000,
                "pay_now_basis": "subtotal",
                "pos_type": "manual_fallback",
                "notes": "DRAFT from cherry ingest. Every price and every "
                         "modifier group must be confirmed with the owner "
                         "before this goes live.",
            },
            "options": [
                {"id": f"{a.id}_{_slug(n)}", "name": n,
                 **({"price": "0.00"} if a.confirm_price else {})}
                for a in prop.archetypes for n, _ in a.typical_options],
            "groups": [
                {"id": a.id, "name": a.name, "prompt": a.prompt,
                 "options": [f"{a.id}_{_slug(n)}" for n, _ in a.typical_options],
                 "min": a.min_select, "max": a.max_select}
                for a in prop.archetypes],
            "items": [
                {"id": i.id, "name": i.name,
                 "price": ms.from_cents(i.price_cents) if i.price_cents else "0.00",
                 **({"aliases": list(i.aliases)} if i.aliases else {}),
                 **({"category": _slug(i.section)} if i.section else {}),
                 **({"groups": list(i.suggested_groups)} if i.suggested_groups else {})}
                for i in prop.items],
        }
        import yaml
        Path(args.out).write_text(
            yaml.safe_dump(doc, sort_keys=False, allow_unicode=True, width=100))
        print(f"\n{GRN}wrote {args.out}{OFF} — a DRAFT. Run "
              f"`cherry.py check {args.out}` once the questions above are "
              f"answered.")
    return 0


def _slug(s: str) -> str:
    import re
    return re.sub(r"[^a-z0-9]+", "_", (s or "").lower()).strip("_") or "x"


# ---------------------------------------------------------------------------
# play — the by-hand harness
# ---------------------------------------------------------------------------

HELP = """
  <text>          order an item, or answer the question Lily just asked
  + <text>        add a modifier to the last item (e.g. "+ extra bacon")
  - <text>        remove something (e.g. "- no onion")
  x2 / x3         set the quantity of the last item
  half <text>     add a topping to the left half (pizza)
  split           peel one unit off the last line so it can differ
  confirm         confirm there are no more item changes
  read            read the order back
  ticket          show the kitchen ticket the POS bridge would receive
  undo            remove the last line
  menu [text]     search the menu
  help            this
  quit            end the call
"""


class Session:
    """One hand-driven call.

    A thin terminal skin over agent_api.CallSession — the SAME object the
    Inworld layer drives in production. The typed shorthand below ("+ bacon",
    "x3") stands in for intents the voice model will classify; everything
    after that point is production code. That is the point: a scripted run in
    calls/ proves the live path, not a parallel implementation of it.
    """

    def __init__(self, cfg, echo=True):
        self.api = CallSession(cfg)
        self.e = self.api.e
        self.echo = echo
        self.transcript: List[str] = []
        self.last_agent_line = ""

    def say(self, who: str, text: str) -> None:
        colour = CYA if who == "Lily" else YEL
        self.transcript.append(f"{who:7s} {text}")
        if who == "Lily":
            self.last_agent_line = text
        if self.echo:
            print(f"  {colour}{who:7s}{OFF} {text}")

    def _speak(self, reply: dict) -> bool:
        self.say("Lily", reply["say"])
        return True

    def pending(self):
        return self.api.pending()

    def handle(self, raw: str) -> bool:
        """Returns False to end the call."""
        text = raw.strip()
        if not text:
            return True
        self.say("Caller", text)
        low = text.lower()

        if low in ("quit", "exit", "done", "bye"):
            return False
        if low == "help":
            print(HELP)
            return True
        if low == "read":
            return self._speak(self.api.read_back())
        if low == "ticket":
            self._ticket()
            return True
        if low == "undo":
            return self._speak(self.api.remove_item())
        if low.startswith("menu"):
            return self._speak(self.api.search_menu(text[4:].strip()))
        if low == "split":
            return self._speak(self.api.split_line())
        if low in ("confirm", "no changes", "that's all", "as is"):
            return self._speak(self.api.confirm_mods())
        if low.startswith("x") and low[1:].isdigit():
            return self._speak(self.api.set_quantity(int(low[1:])))
        if text.startswith("-"):
            return self._speak(self.api.remove_modifier(text[1:].strip()))
        if text.startswith("+"):
            return self._speak(self.api.add_modifier(text[1:].strip()))
        if low.startswith("half "):
            return self._speak(
                self.api.add_modifier(text[5:].strip(), placement="left"))

        if self.api.pending() is not None:
            return self._speak(self.api.answer(text))
        return self._speak(self.api.add_item(text))

    def _ticket(self) -> None:
        n = self.e.to_normalized_order()
        print(f"\n  {DIM}KITCHEN TICKET -> {n['pos_type']}{OFF}")
        for l in n["lines"]:
            size = f" [{l['size_name']}]" if l["size_name"] else ""
            print(f"    {l['quantity']}x {l['item_name']}{size}"
                  f"  {money(l['line_total_cents'])}")
            for m in l["modifiers"]:
                tag = " (included)" if m["informational"] else ""
                q = f"{m['quantity']}x " if m["quantity"] > 1 else ""
                pl = f" [{m['placement']}]" if m["placement"] != "whole" else ""
                print(f"        + {q}{m['option_name']}{pl}{tag}")
            for r in l["removed_defaults"]:
                print(f"        - NO {r}")
        print(f"    subtotal {money(n['subtotal_cents'])}  "
              f"tax {money(n['tax_cents'])}  "
              f"TOTAL {money(n['total_cents'])}  ({n['payment_mode']})\n")


def cmd_play(args) -> int:
    cfg = ms.load_yaml(_resolve(args.menu))
    s = Session(cfg)
    print(f"{BOLD}{cfg.name}{OFF}  {DIM}({len(cfg.items)} items) "
          f"— type 'help' for commands, 'quit' to hang up{OFF}")
    s.say("Lily", f"Thanks for calling {cfg.name}, what can I get you?")

    if args.script:
        for raw in Path(args.script).read_text().splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if not s.handle(line):
                break
    else:
        while True:
            try:
                raw = input("  > ")
            except (EOFError, KeyboardInterrupt):
                break
            if not s.handle(raw):
                break

    print()
    if s.e.lines:
        s.say("Lily", s.e.read_back())
        if s.e.is_submittable():
            s._ticket()
        else:
            q = s.e.next_question()
            print(f"  {RED}order incomplete{OFF} — still needs: {q}")
            return 1
    return 0


# ---------------------------------------------------------------------------
# misc
# ---------------------------------------------------------------------------


def cmd_keyterms(args) -> int:
    import menu_ingest as mi
    cfg = ms.load_yaml(_resolve(args.menu))
    kt = mi.asr_keyterms(cfg, cfg.cuisine, args.max_terms, args.max_tokens)
    print(f"{BOLD}{len(kt)} keyterms{OFF} from {len(cfg.items)} items "
          f"(budget {args.max_terms} terms / {args.max_tokens} tokens)")
    for k in kt:
        print(f"  {k.score:4.1f}  {k.term:34s} {DIM}{k.reason}{OFF}")
    return 0


def cmd_ls(args) -> int:
    rows = []
    for p in sorted(MENUS.glob("*.yaml")):
        try:
            cfg = ms.load_yaml(p)
            errs = len([f for f in lint_config(cfg) if f.level == "ERROR"])
            rows.append((cfg.id, cfg.cuisine, len(cfg.items), cfg.pos_type,
                         "ok" if not errs else f"{errs} lint errors"))
        except Exception as exc:
            rows.append((p.stem, "?", 0, "?", f"BROKEN: {str(exc)[:40]}"))
    print(f"{BOLD}{'id':30s} {'cuisine':14s} {'items':>5s}  {'pos':18s} state{OFF}")
    for r in rows:
        print(f"{r[0]:30s} {r[1]:14s} {r[2]:5d}  {r[3]:18s} {r[4]}")
    return 0


def cmd_new(args) -> int:
    from cuisine_library import CUISINES
    prof = CUISINES.get(args.cuisine)
    if prof is None:
        sys.exit(f"unknown cuisine {args.cuisine!r}; "
                 f"have {', '.join(sorted(CUISINES))}")
    doc = {
        "schema_version": ms.SCHEMA_VERSION,
        "restaurant": {"id": args.id, "name": args.name or args.id,
                       "cuisine": args.cuisine, "tax_rate_bps": 0,
                       "pay_now_threshold_cents": 3000,
                       "pay_now_basis": "subtotal",
                       "pos_type": "manual_fallback",
                       "notes": "SCAFFOLD. Delete any group this restaurant "
                                "does not actually have."},
        "options": [{"id": f"{a.id}_{_slug(n)}", "name": n, "price": "0.00"}
                    for a in prof.archetypes for n, _ in a.typical_options],
        "groups": [{"id": a.id, "name": a.name, "prompt": a.prompt,
                    "options": [f"{a.id}_{_slug(n)}"
                                for n, _ in a.typical_options],
                    "min": a.min_select, "max": a.max_select}
                   for a in prof.archetypes],
        "items": [{"id": "example_item", "name": "Example Item",
                   "price": "0.00", "groups": []}],
    }
    import yaml
    out = args.out or (MENUS / f"{args.id}.yaml")
    Path(out).write_text(yaml.safe_dump(doc, sort_keys=False,
                                        allow_unicode=True, width=100))
    print(f"{GRN}wrote {out}{OFF}")
    print("Questions the library says to ask this cuisine's owner:")
    for a in prof.archetypes:
        print(f"  - {a.name}: {a.confirm[:160]}")
    return 0


def cmd_onboard(args) -> int:
    import onboarding_factory
    return onboarding_factory.main(args.onboard_args)


def cmd_go_live(args) -> int:
    """The night-before question: what still blocks a real call?"""
    import go_live
    argv: List[str] = []
    if args.db:
        argv += ["--db", args.db]
    if args.url:
        argv += ["--url", args.url]
    if args.json:
        argv.append("--json")
    if args.no_color:
        argv.append("--no-color")
    for one in args.only:
        argv += ["--only", one]
    return go_live.main(argv)


def cmd_prospect(args) -> int:
    """Pre-onboard the whole sales route from the field plan onto the demo line."""
    import prospect
    argv: List[str] = ["--plan", args.plan, "--sheet", args.sheet]
    if args.day:
        argv += ["--day", str(args.day)]
    if args.out:
        argv += ["--out", args.out]
    if args.json:
        argv.append("--json")
    if args.dry_run:
        argv.append("--dry-run")
    if args.no_personalise:
        argv.append("--no-personalise")
    return prospect.main(argv)


def cmd_demo_line(args) -> int:
    """One number, every restaurant on the route."""
    import demo_line
    return demo_line.main(list(args.demo_args))


def cmd_mine(args) -> int:
    """Caller re-phrasings -> owner-confirmed menu aliases."""
    import alias_mining as am
    argv: List[str] = []
    if args.db:
        argv += ["--db", args.db]
    if args.restaurant:
        argv += ["--restaurant", args.restaurant]
    if args.json:
        argv.append("--json")
    if args.patch_out:
        argv += ["--patch-out", str(args.patch_out)]
    if args.apply:
        argv += ["--apply", str(args.apply)]
    if args.menu:
        argv += ["--menu", str(args.menu)]
    return am.main(argv)


def cmd_kds(args) -> int:
    """The kitchen-display URL for one restaurant's tablet."""
    import os
    import server as srv
    key_src = (os.environ.get("CHERRY_API_KEY", "")
               or os.environ.get("CHERRY_VOICE_KEY", ""))
    if not key_src:
        print("set CHERRY_API_KEY (the same value the server runs with) "
              "to derive the display key")
        return 1
    base = args.base_url.rstrip("/")
    url = (f"{base}/kds?r={args.restaurant_id}"
           f"&k={srv.kds_key(key_src, args.restaurant_id)}")
    print(f"Open on the restaurant's iPad (Safari, keep the page open):\n{url}")
    print("New orders chime automatically; staff tap Accept to confirm.")
    return 0


def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(prog="cherry", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("check", help="the gate: schema + lint + invariants")
    p.add_argument("menu"); p.add_argument("-v", "--verbose", action="store_true")
    p.set_defaults(fn=cmd_check)

    p = sub.add_parser("ingest", help="raw menu text -> draft YAML + questions")
    p.add_argument("textfile"); p.add_argument("--cuisine")
    p.add_argument("-o", "--out"); p.add_argument("--id"); p.add_argument("--name")
    p.set_defaults(fn=cmd_ingest)

    p = sub.add_parser("play", help="order by hand as a caller")
    p.add_argument("menu"); p.add_argument("--script")
    p.set_defaults(fn=cmd_play)

    p = sub.add_parser("keyterms", help="ASR boost list")
    p.add_argument("menu"); p.add_argument("--max-terms", type=int, default=100)
    p.add_argument("--max-tokens", type=int, default=500)
    p.set_defaults(fn=cmd_keyterms)

    p = sub.add_parser("new", help="scaffold a YAML from a cuisine template")
    p.add_argument("cuisine"); p.add_argument("id")
    p.add_argument("--name"); p.add_argument("-o", "--out")
    p.set_defaults(fn=cmd_new)

    p = sub.add_parser("ls", help="list restaurants in menus/")
    p.set_defaults(fn=cmd_ls)

    p = sub.add_parser("onboard", help="two-day onboarding case workflow")
    p.add_argument("onboard_args", nargs=argparse.REMAINDER)
    p.set_defaults(fn=cmd_onboard)

    p = sub.add_parser("go-live", help="can this deployment take a call? "
                                       "blockers, not vibes")
    # Declared explicitly rather than via REMAINDER: argparse's REMAINDER does
    # not forward a leading option, so `go-live --no-color` died at the top
    # level with "unrecognized arguments".
    p.add_argument("--db", default="", help="defaults to CHERRY_DATABASE_URL")
    p.add_argument("--url", default="", help="running server to probe")
    p.add_argument("--only", action="append", default=[],
                   help="limit to a location id or group; repeatable")
    p.add_argument("--json", action="store_true")
    p.add_argument("--no-color", action="store_true")
    p.set_defaults(fn=cmd_go_live)

    p = sub.add_parser("prospect", help="pre-onboard the sales route from the "
                                        "field plan onto the demo line")
    p.add_argument("--plan", required=True, help="field-plan .xlsx")
    p.add_argument("--sheet", default="Clinton first")
    p.add_argument("--day", type=int, default=0)
    p.add_argument("--out", default="")
    p.add_argument("--json", action="store_true")
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--no-personalise", action="store_true")
    p.set_defaults(fn=cmd_prospect)

    p = sub.add_parser("demo-line",
                       help="one number, every restaurant on the route")
    p.add_argument("demo_args", nargs=argparse.REMAINDER)
    p.set_defaults(fn=cmd_demo_line)

    p = sub.add_parser("mine",
                       help="caller re-phrasings -> owner-confirmed aliases")
    p.add_argument("--db", help="cherry database with call history")
    p.add_argument("--restaurant", help="limit to one restaurant id")
    p.add_argument("--menus", default="menus", help="menus directory")
    p.add_argument("--menu", help="one menu file (for --apply, or focus)")
    p.add_argument("--json", action="store_true", help="machine-readable")
    p.add_argument("--patch-out", metavar="FILE",
                   help="write a prunable YAML patch")
    p.add_argument("--apply", metavar="FILE",
                   help="apply a pruned patch (needs --menu)")
    p.set_defaults(fn=cmd_mine)

    p = sub.add_parser("kds",
                       help="print the kitchen-display URL for a tablet")
    p.add_argument("restaurant_id", help="the restaurant id, e.g. copper-kettle-clinton")
    p.add_argument("--base-url", default="http://localhost:8080",
                   help="the running Cherry server's public base URL")
    p.set_defaults(fn=cmd_kds)

    p = sub.add_parser("owner-questions",
                       help="accumulate the questions this menu owes its "
                            "owner into owner_questions/ — never blocks, "
                            "never duplicates, answers are recorded not "
                            "applied")
    p.add_argument("menu", help="path to the restaurant's menu YAML")
    p.add_argument("--answer", nargs=2, metavar=("QUESTION_ID", "ANSWER"),
                   help="record the owner's answer to a question id")
    p.add_argument("--all", action="store_true",
                   help="show answered questions too")
    p.add_argument("--dir", default="owner_questions",
                   help="ledger directory (default owner_questions/)")
    p.set_defaults(fn=cmd_owner_questions)

    import cherry_ops
    cherry_ops.add_parsers(sub)

    args = ap.parse_args(argv)
    return args.fn(args)


if __name__ == "__main__":
    raise SystemExit(main())
