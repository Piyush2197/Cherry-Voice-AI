#!/usr/bin/env python3
"""Tests for the credential-free Inworld/Telnyx bridge."""

from __future__ import annotations

import asyncio
import traceback

from agent_api import TOOL_SCHEMAS
from guest_services import RESERVATION_TOOL_SCHEMAS
from voice.inworld_bridge import CherryBridge, DEAD

_passed = _failed = 0


def check(name, condition, detail=""):
    global _passed, _failed
    if condition:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


class FakeTransport:
    def __init__(self):
        self.requests = []
        self.ready = False
        self.fail = False

    async def request(self, method, url, headers, body, timeout):
        self.requests.append((method, url, headers, body, timeout))
        if self.fail:
            raise ConnectionError("offline")
        path = url.split("test.invalid", 1)[-1]
        if path == "/v1/tools":
            return 200, {"tools": TOOL_SCHEMAS + RESERVATION_TOOL_SCHEMAS}
        if path == "/v1/calls":
            restaurant = ("Ferndale" if body["to"] == "+12485550001"
                          else "Clinton Township")
            return 200, {"say": f"Thanks for calling Bun N Run {restaurant}."}
        if path.endswith("/tools/ready_to_place"):
            if self.ready:
                return 200, {"ok": True, "say": "Your total is $14.83."}
            return 200, {"ok": False,
                         "say": "What drink would you like with the combo?"}
        if "/tools/" in path:
            name = path.rsplit("/", 1)[-1]
            return 200, {"ok": True,
                         "say": f"VERBATIM {name} {body.get('text', '')}".strip()}
        if path.endswith("/finish"):
            return 200, {"say": "Your order is in. Thanks!"}
        if path.endswith("/abandon"):
            return 200, {"ok": True}
        return 404, {"error": "not found"}


def t_start_routes_by_dialled_number_and_authenticates():
    async def run():
        tx = FakeTransport()
        b = CherryBridge("https://test.invalid/", "secret", transport=tx)
        a = await b.start("a", dialled="+12485550001", caller="+15550001")
        c = await b.start("c", dialled="+15865550002", caller="+15550002")
        check("Ferndale greeting is returned", "Ferndale" in a, a)
        check("Clinton greeting is returned", "Clinton Township" in c, c)
        first = tx.requests[0]
        check("API key is sent", first[2]["X-Cherry-Key"] == "secret")
        check("dialled number is not rewritten", first[3]["to"] == "+12485550001")
        check("caller number is not rewritten", first[3]["from"] == "+15550001")
    asyncio.run(run())


def t_tools_are_fetched_and_speech_is_verbatim():
    async def run():
        tx = FakeTransport()
        b = CherryBridge("https://test.invalid", "secret", transport=tx)
        tools = await b.tool_schemas()
        from server import ALL_TOOL_SCHEMAS      # not a number: it goes stale
        check("every published tool is fetched",
              {x["name"] for x in tools} == {x["name"] for x in ALL_TOOL_SCHEMAS},
              str(sorted(x["name"] for x in tools)))
        check("the allergen/dietary tool is among them",
              "item_info" in {x["name"] for x in tools})
        check("confirm_mods is registered",
              "confirm_mods" in {x["name"] for x in tools})
        say = await b.handle_tool_call("a", "add_item",
                                       {"text": "uh a burger please"})
        check("Cherry speech is returned byte-for-byte",
              say == "VERBATIM add_item uh a burger please", say)
        check("tool name is not rewritten",
              tx.requests[-1][1].endswith("/tools/add_item"))
        check("caller words are not rewritten",
              tx.requests[-1][3]["text"] == "uh a burger please")
        check("verbatim audit accepts exact speech", not b.verbatim_audit([say]))
        drift = b.verbatim_audit(["A burger."])
        check("verbatim audit catches paraphrasing", len(drift) == 1, str(drift))
    asyncio.run(run())


def t_finish_will_not_place_an_incomplete_order():
    async def run():
        tx = FakeTransport()
        b = CherryBridge("https://test.invalid", "secret", transport=tx)
        await b.start("a", dialled="+12485550001")
        say = await b.finish("a", "Sam")
        check("finish returns the missing question",
              say == "What drink would you like with the combo?", say)
        check("incomplete order was not placed",
              not any(x[1].endswith("/finish") for x in tx.requests))
        tx.ready = True
        say = await b.finish("a", "Sam")
        check("complete order is placed", say == "Your order is in. Thanks!", say)
        finish = [x for x in tx.requests if x[1].endswith("/finish")][-1]
        check("customer name reaches Cherry", finish[3] == {"customer_name": "Sam"})
    asyncio.run(run())


def t_backend_failure_requests_one_human_handoff():
    async def run():
        tx = FakeTransport()
        handoffs = []

        async def handoff(call_id, dialled, reason):
            handoffs.append((call_id, dialled, reason))

        b = CherryBridge("https://test.invalid", "secret", transport=tx,
                         handoff=handoff)
        tx.fail = True
        first = await b.start("a", dialled="+12485550001")
        second = await b.handle_tool_call("a", "add_item", {"text": "burger"})
        check("failure sentence is safe", first == DEAD and second == DEAD)
        check("handoff is requested once", len(handoffs) == 1, str(handoffs))
        check("handoff keeps the dialled location",
              handoffs[0][:2] == ("a", "+12485550001"), str(handoffs))
        check("handoff records the cause", "offline" in handoffs[0][2])
    asyncio.run(run())


def t_caller_human_request_transfers_once():
    async def run():
        sent = []

        async def handoff(call_id, dialled, reason):
            sent.append((call_id, dialled, reason))

        bridge = CherryBridge("https://test.invalid", "secret",
                              transport=FakeTransport(), handoff=handoff)
        await bridge.start("call-a", dialled="+12485550001")
        first = await bridge.request_handoff("call-a")
        second = await bridge.request_handoff("call-a")
        check("human request gets clear speech", first == second and
              "connect you" in first.lower(), first)
        check("human request transfers once", sent == [
            ("call-a", "+12485550001", "caller requested a person")], str(sent))
    asyncio.run(run())


def t_abandon_is_always_reported():
    async def run():
        tx = FakeTransport()
        b = CherryBridge("https://test.invalid", "secret", transport=tx)
        await b.start("a", dialled="+12485550001")
        await b.abandon("a", "caller_hung_up")
        req = tx.requests[-1]
        check("abandon endpoint is called", req[1].endswith("/a/abandon"), req[1])
        check("abandon reason is preserved", req[3]["reason"] == "caller_hung_up")
    asyncio.run(run())


def main():
    for name, fn in sorted(globals().items()):
        if not name.startswith("t_"):
            continue
        try:
            fn()
        except Exception:
            global _failed
            _failed += 1
            print(f"\n--- FAIL {name}\n{traceback.format_exc()}")
    print(f"\n{_passed} passed, {_failed} failed (voice bridge)")
    return 1 if _failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
