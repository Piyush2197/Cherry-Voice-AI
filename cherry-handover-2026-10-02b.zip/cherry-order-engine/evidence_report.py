#!/usr/bin/env python3
"""Build a complaint-ready evidence packet for one completed order.

The packet joins the immutable final order to the transcript, menu version,
delivery acknowledgement, messages, payment status and audit events. It is a
local support artifact and is intentionally not exposed as a public endpoint.
"""

from __future__ import annotations

import hashlib
import json
import re
from typing import Any, Dict

from order_store import json_value


def _detail(value: Any) -> Any:
    if not value:
        return {}
    if isinstance(value, (dict, list)):
        return value
    try:
        return json.loads(value)
    except (TypeError, ValueError):
        return {"raw": str(value)}


def _masked(phone: str) -> str:
    if not phone:
        return ""
    return "*" * max(0, len(phone) - 4) + phone[-4:]


def _redact(value: Any, secrets: list[str]) -> Any:
    """Remove known customer contact values, including from free text."""
    if isinstance(value, dict):
        return {key: _redact(item, secrets) for key, item in value.items()}
    if isinstance(value, list):
        return [_redact(item, secrets) for item in value]
    if isinstance(value, str):
        for secret in secrets:
            if secret:
                value = re.sub(re.escape(secret), "[REDACTED]", value,
                               flags=re.IGNORECASE)
    return value


def build(store, code: str, *, include_contact: bool = False) -> Dict[str, Any]:
    row = store.conn.execute(
        'SELECT * FROM "order" WHERE short_code=? ORDER BY placed_at DESC LIMIT 1',
        (code,)).fetchone()
    if row is None:
        raise LookupError(f"no order #{code}")
    rest = store.restaurant(row["restaurant_id"])
    menu = store.menu_version(row["menu_version_id"])
    snapshot = json_value(row["snapshot"])
    canonical = json.dumps(snapshot, sort_keys=True, separators=(",", ":"))

    turns = []
    session = None
    if row["session_id"]:
        session_row = store.conn.execute(
            "SELECT * FROM session WHERE id=?", (row["session_id"],)).fetchone()
        if session_row:
            session = {
                "id": session_row["id"], "channel": session_row["channel"],
                "started_at": session_row["started_at"],
                "ended_at": session_row["ended_at"],
                "end_reason": session_row["end_reason"],
                "external_call_id": session_row["external_id"],
            }
        turns = [
            {"seq": t["seq"], "speaker": t["speaker"], "text": t["text"],
             "intent": t["intent"], "engine_issue_code": t["engine_issue_code"],
             "created_at": t["created_at"]}
            for t in store.conn.execute(
                "SELECT * FROM turn WHERE session_id=? ORDER BY seq",
                (row["session_id"],)).fetchall()
        ]

    deliveries = [dict(d) for d in store.conn.execute(
        "SELECT * FROM order_delivery WHERE order_id=? ORDER BY id",
        (row["id"],)).fetchall()]
    if any(d["status"] == "acknowledged" for d in deliveries):
        delivery_outcome = "acknowledged_by_restaurant"
    elif any(d["status"] == "sent" for d in deliveries):
        delivery_outcome = "sent_not_acknowledged"
    elif any(d["status"] == "failed" for d in deliveries):
        delivery_outcome = "failed"
    else:
        delivery_outcome = "no_delivery_record"

    payment_row = store.conn.execute(
        "SELECT * FROM payment WHERE order_id=?", (row["id"],)).fetchone()
    payment = dict(payment_row) if payment_row else None
    if payment:
        # A hosted checkout URL is operational data, not dispute evidence.
        payment.pop("pay_url", None)

    messages = []
    for msg in store.messages_for_order(row["id"]):
        messages.append({
            "id": msg["id"], "kind": msg["kind"], "direction": msg["direction"],
            "destination": (msg["to_phone"] if include_contact
                            else _masked(msg["to_phone"])),
            "body": msg["body"], "provider_ref": msg["provider_ref"],
            "status": msg["status"], "error_detail": msg["error_detail"],
            "created_at": msg["created_at"],
        })

    events = [{"kind": e["kind"], "detail": _detail(e["detail"]),
               "created_at": e["created_at"]}
              for e in store.events(order_id=row["id"])]
    customer_phone = row["customer_phone"] or ""
    packet = {
        "evidence_version": 1,
        "order": {
            "id": row["id"], "short_code": row["short_code"],
            "restaurant_id": row["restaurant_id"],
            "restaurant_name": rest["name"] if rest else row["restaurant_id"],
            "placed_at": row["placed_at"], "status": row["status"],
            "delivery_outcome": delivery_outcome,
            "customer_name": row["customer_name"] if include_contact else None,
            "customer_phone": (customer_phone if include_contact
                               else _masked(customer_phone)),
            "total_cents": row["total_cents"],
        },
        "final_order": snapshot,
        "session": session,
        "transcript": turns,
        "delivery_attempts": deliveries,
        "messages": messages,
        "payment": payment,
        "audit_events": events,
        "menu_version": {
            "id": row["menu_version_id"],
            "version": menu["version"] if menu else None,
            "published_at": menu["published_at"] if menu else None,
            "yaml_sha256": menu["yaml_sha256"] if menu else None,
        },
        "integrity": {
            "final_order_sha256": hashlib.sha256(canonical.encode()).hexdigest(),
            "database_enforcement": (
                "order contents, menu version and totals are immutable after placement"),
        },
        "audio_recording": {
            "available_in_cherry": False,
            "note": "Transcript is stored. Original audio requires provider-side "
                    "recording, consent and a retention policy.",
        },
    }
    if include_contact:
        return packet
    # Tickets and transcripts are free text and can repeat contact details.
    # Redact the known values throughout, not only in dedicated columns.
    return _redact(packet, [row["customer_name"] or "", customer_phone])
