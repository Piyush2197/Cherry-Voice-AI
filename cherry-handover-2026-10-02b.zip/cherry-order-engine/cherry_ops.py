"""
Operations — the commands that exist once a restaurant is live.

Everything in cherry.py up to now works on FILES. This works on the DATABASE,
and that is the whole difference between a demo and a deployment:

    deploy   put a checked menu live for a restaurant, versioned
    call     run a whole call end to end: session -> order -> ticket -> pay
    orders   what the kitchen has, and what nobody has confirmed
    ack      a human confirming an order landed (the manual bridge's 'accept')
    86       sold out / back on, without republishing the menu
    trace    everything that happened to one order, in order
    evidence export a complaint-ready JSON packet for one order

`call` is the sample to test and deploy. It uses the same Session harness the
Wizard-of-Oz `play` command uses, so a scripted call here exercises the exact
matcher, validator and pricer a real caller will hit — and then keeps going
through the parts `play` never touched: storing an immutable snapshot, running
the sink, relaying the pay link, logging every turn.

Swap FakeSmsSender for TelnyxSmsSender and ManualSink for SquareSink and this
command IS production. Nothing else changes.
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Optional

import menu_schema as ms
from order_engine import money
from order_store import OrderStore, json_value
from payments import FakePayLinkProvider, arrange_payment, payment_for
from sinks import FakeSmsSender, deliver, format_ticket, sink_for

BOLD, DIM, RED, GRN, YEL, CYA, OFF = (
    "\033[1m", "\033[2m", "\033[31m", "\033[32m", "\033[33m", "\033[36m", "\033[0m")

DEFAULT_DB = "cherry.db"


def _store(args) -> OrderStore:
    target = (getattr(args, "db", None) or
              os.getenv("CHERRY_DATABASE_URL") or DEFAULT_DB)
    return OrderStore.open(target)


# ---------------------------------------------------------------------------
# deploy
# ---------------------------------------------------------------------------


def cmd_deploy(args) -> int:
    """Put a menu live. Refuses anything that has not passed the gate."""
    from cherry import cmd_check, _resolve

    path = _resolve(args.menu)

    class _Q:
        menu = str(path)
        verbose = False
    if cmd_check(_Q()) != 0:
        print(f"{RED}not deployed{OFF} — fix the gate first")
        return 1

    cfg = ms.load_yaml(path)
    st = _store(args)
    st.upsert_restaurant(
        cfg.id, cfg.name, cfg.cuisine or "",
        tax_rate_bps=cfg.tax_rate_bps,
        pos_type=cfg.pos_type, sink=args.sink,
        staff_phone=args.staff_phone, inbound_phone=args.inbound,
        active=not args.inactive)

    mv = st.publish_menu(cfg.id, path.read_text(),
                         item_count=len(cfg.items), published_by="cherry deploy")

    print(f"{GRN}live{OFF}  {BOLD}{cfg.name}{OFF}  menu version {mv}  "
          f"{len(cfg.items)} items  sink={args.sink}")
    if args.inbound:
        print(f"      inbound {args.inbound} -> {cfg.id}")
    if args.sink == "manual" and not args.staff_phone:
        print(f"{YEL}      no --staff-phone: the manual bridge has nowhere to "
              f"send tickets{OFF}")
    return 0


# ---------------------------------------------------------------------------
# call — the end-to-end sample
# ---------------------------------------------------------------------------


def cmd_call(args) -> int:
    from cherry import Session

    st = _store(args)

    if args.inbound:
        rest = st.restaurant_for_number(args.inbound)
        if rest is None:
            print(f"{RED}no restaurant on {args.inbound}{OFF}")
            return 1
    else:
        rest = st.restaurant(args.restaurant)
        if rest is None:
            print(f"{RED}no restaurant {args.restaurant!r} — deploy it first{OFF}")
            return 1
    rid = rest["id"]

    cfg, mv = st.load_live_config(rid)
    off = st.availability_overrides(rid)
    sid = st.start_session(rid, mv, channel="voice",
                           external_id=args.call_id, caller_phone=args.from_number)

    print(f"{BOLD}{rest['name']}{OFF} {DIM}menu v{mv} · session {sid[:8]} · "
          f"{len(cfg.items)} items{OFF}")
    if off["item"] or off["option"]:
        print(f"{YEL}86 tonight: {len(off['item'])} items, "
              f"{len(off['option'])} options{OFF}")

    s = Session(cfg)
    greeting = f"Thanks for calling {cfg.name}, what can I get you?"
    s.say("Lily", greeting)
    st.record_turn(sid, "agent", greeting)

    lines = []
    if args.script:
        lines = [l.strip() for l in Path(args.script).read_text().splitlines()]
        lines = [l for l in lines if l and not l.startswith("#")]

    def _run(text: str) -> bool:
        st.record_turn(sid, "caller", text, intent="utterance")
        before = len(s.transcript) if hasattr(s, "transcript") else 0
        keep = s.handle(text)
        st.save_cart(sid, s.e.to_normalized_order() if s.e.lines else None)
        return keep

    if lines:
        for text in lines:
            if not _run(text):
                break
    else:
        while True:
            try:
                raw = input("  > ")
            except (EOFError, KeyboardInterrupt):
                break
            if not raw.strip() or not _run(raw.strip()):
                break

    print()
    if not s.e.lines:
        st.end_session(sid, "no_order")
        print(f"{DIM}call ended with nothing ordered{OFF}")
        return 0

    if not s.e.is_submittable():
        q = s.e.next_question()
        st.escalate(sid, f"incomplete: {q}")
        st.end_session(sid, "escalated")
        print(f"{RED}order incomplete{OFF} — escalated. Still needs: {q}")
        return 1

    # Only confirm if the caller has not just been read the order. Saying the
    # total twice in a row is the single most obvious tell that a voice agent
    # is a script rather than a person.
    back = s.e.read_back()
    if getattr(s, "last_agent_line", None) != back:
        s.say("Lily", back)
        st.record_turn(sid, "agent", back, intent="read_back")
    snapshot = s.e.to_normalized_order()
    oid, code = st.place_order(rid, mv, snapshot, session_id=sid,
                               customer_name=args.customer,
                               customer_phone=args.from_number)
    st.end_session(sid, "completed")
    print(f"\n{GRN}order #{code}{OFF}  {money(snapshot['total_cents'])}  "
          f"{DIM}{oid}{OFF}")

    # --- payment gate ------------------------------------------------
    sms = FakeSmsSender()
    status = arrange_payment(st, oid, sms=sms,
                             provider=None if args.no_pos_pay else FakePayLinkProvider(),
                             customer_phone=args.from_number)
    pay = payment_for(st, oid)
    if status == "not_required":
        print(f"{DIM}payment: at pickup, POS collects{OFF}")
    elif status == "link_sent":
        print(f"payment: {GRN}POS pay link texted{OFF} -> {pay['pay_url']}")
    else:
        print(f"payment: {YEL}{status}{OFF} — held; restaurant has no ticket")

    if status == "not_required":
        res = deliver(st, oid, sink_for(rest, sms), sleep=lambda _: None)
        if res.ok:
            print(f"{GRN}delivered{OFF} via {rest['sink']} ({res.external_ref})")
        else:
            print(f"{RED}delivery failed{OFF}: {res.error_kind} — {res.error_detail}")
            st.escalate(sid, f"delivery {res.error_kind}")
    else:
        print(f"{YEL}kitchen held until verified payment{OFF}")

    print(f"\n{DIM}--- what the staff phone got ---{OFF}")
    for m in sms.sent:
        print(f"{DIM}to {m['to']}{OFF}\n{m['body']}\n")
    return 0


# ---------------------------------------------------------------------------
# the ops view
# ---------------------------------------------------------------------------


def cmd_orders(args) -> int:
    st = _store(args)
    rid = args.restaurant
    rows = (st.orders_awaiting_kitchen(rid) if not args.all else
            st.conn.execute('SELECT * FROM "order" WHERE restaurant_id=? '
                            'ORDER BY placed_at DESC LIMIT 50', (rid,)).fetchall())
    if not rows:
        print(f"{DIM}nothing{OFF}")
        return 0
    unack = {r["id"] for r in st.unacknowledged_orders(rid)}
    for r in rows:
        flag = f"{YEL} UNCONFIRMED{OFF}" if r["id"] in unack else ""
        print(f"#{r['short_code']}  {money(r['total_cents']):>8}  "
              f"{r['status']:<13} {DIM}{r['placed_at']}{OFF}{flag}")
    if unack:
        print(f"\n{YEL}{len(unack)} order(s) sent but never confirmed — this is "
              f"the number to alarm on{OFF}")
    return 0


def cmd_ack(args) -> int:
    st = _store(args)
    row = st.conn.execute('SELECT * FROM "order" WHERE short_code=? '
                          'ORDER BY placed_at DESC LIMIT 1',
                          (args.code,)).fetchone()
    if row is None:
        print(f"{RED}no order #{args.code}{OFF}")
        return 1
    if st.acknowledge_delivery(row["id"], args.by):
        print(f"{GRN}#{args.code} confirmed by {args.by}{OFF}")
        return 0
    print(f"{DIM}#{args.code} was already confirmed{OFF}")
    return 0


def cmd_86(args) -> int:
    """Sold out, or back on. No republish, no redeploy, effective next call."""
    st = _store(args)
    on = args.on
    st.set_availability(args.restaurant, args.target, available=on,
                        kind=args.kind, reason=args.reason or "",
                        set_by="staff")
    print(f"{GRN if on else YEL}{args.target} is "
          f"{'back on' if on else '86ed'}{OFF} for {args.restaurant}")
    try:
        cfg, _ = st.load_live_config(args.restaurant)
        live = sum(1 for i in cfg.items if i.available)
        print(f"{DIM}{live} of {len(cfg.items)} items orderable{OFF}")
    except LookupError:
        pass
    return 0


def cmd_trace(args) -> int:
    """Everything that happened to one order. The support tool."""
    st = _store(args)
    row = st.conn.execute('SELECT * FROM "order" WHERE short_code=? '
                          'ORDER BY placed_at DESC LIMIT 1',
                          (args.code,)).fetchone()
    if row is None:
        print(f"{RED}no order #{args.code}{OFF}")
        return 1
    oid = row["id"]
    rest = st.restaurant(row["restaurant_id"])
    print(f"{BOLD}#{row['short_code']}{OFF}  {rest['name']}  "
          f"{money(row['total_cents'])}  {row['status']}")
    print(f"{DIM}order {oid}  menu v{row['menu_version_id']}  "
          f"placed {row['placed_at']}{OFF}\n")

    if row["session_id"]:
        turns = st.conn.execute(
            "SELECT * FROM turn WHERE session_id=? ORDER BY seq",
            (row["session_id"],)).fetchall()
        for t in turns:
            who = "Lily" if t["speaker"] == "agent" else "caller"
            print(f"  {DIM}{who:>6}{OFF} {t['text']}")
        print()

    print(format_ticket(json_value(row["snapshot"]), row["short_code"],
                        restaurant_name=rest["name"],
                        customer_phone=row["customer_phone"] or ""))
    print()
    for d in st.conn.execute("SELECT * FROM order_delivery WHERE order_id=? "
                             "ORDER BY id", (oid,)).fetchall():
        print(f"  delivery {d['sink']}: {d['status']} attempt {d['attempt']} "
              f"{d['error_detail'] or ''}")
    p = payment_for(st, oid)
    if p:
        print(f"  payment {p['method']}: {p['status']} "
              f"(collected by {p['collected_by']})")
    for m in st.messages_for_order(oid):
        print(f"  sms {m['kind']} -> {m['to_phone']}: {m['status']}")
    for e in st.events(order_id=oid):
        print(f"  {DIM}event {e['kind']} {e['created_at']}{OFF}")
    return 0


def cmd_evidence(args) -> int:
    """Export the immutable order, transcript and delivery proof."""
    from evidence_report import build

    st = _store(args)
    try:
        packet = build(st, args.code, include_contact=args.include_contact)
    except LookupError as exc:
        print(f"{RED}{exc}{OFF}")
        return 1
    text = json.dumps(packet, indent=2, sort_keys=True)
    if args.out:
        out = Path(args.out)
        out.write_text(text + "\n")
        out.chmod(0o600)
        print(f"{GRN}wrote complaint evidence for #{args.code} to {args.out}{OFF}")
    else:
        print(text)
    return 0


def add_parsers(sub) -> None:
    p = sub.add_parser("deploy", help="put a checked menu live in the database")
    p.add_argument("menu")
    p.add_argument("--db"); p.add_argument("--sink", default="manual",
                                           choices=["manual", "toast", "square"])
    p.add_argument("--staff-phone"); p.add_argument("--inbound")
    p.add_argument("--inactive", action="store_true")
    p.set_defaults(fn=cmd_deploy)

    p = sub.add_parser("call", help="end-to-end: call -> order -> ticket -> pay")
    p.add_argument("restaurant", nargs="?")
    p.add_argument("--db"); p.add_argument("--script")
    p.add_argument("--inbound", help="dial a number instead of naming an id")
    p.add_argument("--from-number", default="+13135550101")
    p.add_argument("--customer"); p.add_argument("--call-id")
    p.add_argument("--no-pos-pay", action="store_true",
                   help="simulate a POS with no pay-link API")
    p.set_defaults(fn=cmd_call)

    p = sub.add_parser("orders", help="what the kitchen has")
    p.add_argument("restaurant"); p.add_argument("--db")
    p.add_argument("--all", action="store_true")
    p.set_defaults(fn=cmd_orders)

    p = sub.add_parser("ack", help="confirm an order landed")
    p.add_argument("code"); p.add_argument("--db")
    p.add_argument("--by", default="staff")
    p.set_defaults(fn=cmd_ack)

    p = sub.add_parser("86", help="mark something sold out, or back on")
    p.add_argument("restaurant"); p.add_argument("target")
    p.add_argument("--db"); p.add_argument("--kind", default="item",
                                           choices=["item", "option"])
    p.add_argument("--on", action="store_true", help="put it back on")
    p.add_argument("--reason")
    p.set_defaults(fn=cmd_86)

    p = sub.add_parser("trace", help="everything that happened to one order")
    p.add_argument("code"); p.add_argument("--db")
    p.set_defaults(fn=cmd_trace)

    p = sub.add_parser("evidence",
                       help="export final order, transcript and delivery proof")
    p.add_argument("code"); p.add_argument("--db"); p.add_argument("--out")
    p.add_argument("--include-contact", action="store_true",
                   help="include customer name and full phone; default is redacted")
    p.set_defaults(fn=cmd_evidence)

    from readiness import cmd_readiness
    p = sub.add_parser("readiness",
                       help="what stands between each restaurant and a live call")
    p.add_argument("restaurant", nargs="?")
    p.add_argument("--db"); p.add_argument("--pilots", action="store_true",
                                           help="just the three pilots")
    p.set_defaults(fn=cmd_readiness)
