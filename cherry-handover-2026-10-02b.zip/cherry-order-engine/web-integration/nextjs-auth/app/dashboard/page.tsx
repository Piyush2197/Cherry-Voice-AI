'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
// Types only: erased at build time, so no server code reaches the browser bundle.
import type { Snapshot } from '@/lib/cherry-api'

interface SessionUser {
  username: string
  role: string
}

export default function DashboardPage() {
  const router = useRouter()
  const [user, setUser] = useState<SessionUser | null>(null)
  const [snapshot, setSnapshot] = useState<Snapshot | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    load()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // The browser only ever talks to this site's own /api routes, which check the
  // session and hold the Cherry key. It never imports lib/auth or lib/cherry-api
  // (both read server-only secrets).
  const load = async () => {
    try {
      const [me, snap] = await Promise.all([
        fetch('/api/auth/me'),
        fetch('/api/cherry/snapshot?hours=24'),
      ])

      if (me.status === 401 || snap.status === 401) {
        router.push('/login')
        return
      }

      if (me.ok) {
        setUser((await me.json()).user)
      }

      if (snap.ok) {
        setSnapshot(await snap.json())
      } else {
        const body = await snap.json().catch(() => ({}))
        setError(body.error || 'Failed to fetch data')
      }
    } catch (err) {
      setError('Failed to connect to CHERRY API')
    } finally {
      setLoading(false)
    }
  }

  const handleLogout = async () => {
    await fetch('/api/auth/logout', { method: 'POST' })
    router.push('/login')
  }

  const formatMoney = (cents: number) => {
    return `$${(cents / 100).toFixed(2)}`
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-gray-600">Loading...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold text-gray-900">Cherry Voice AI Dashboard</h1>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">{user?.username}</span>
              <button
                onClick={handleLogout}
                className="px-4 py-2 text-sm font-medium text-white bg-red-600 rounded-md hover:bg-red-700"
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Error State */}
      {error && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">
            {error}
          </div>
        </div>
      )}

      {/* Dashboard Content */}
      {snapshot && (
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div className="bg-white rounded-lg shadow p-6">
              <p className="text-sm font-medium text-gray-600">Calls</p>
              <p className="mt-2 text-3xl font-bold text-gray-900">{snapshot.summary.calls}</p>
            </div>
            <div className="bg-white rounded-lg shadow p-6">
              <p className="text-sm font-medium text-gray-600">Orders</p>
              <p className="mt-2 text-3xl font-bold text-gray-900">{snapshot.summary.orders}</p>
            </div>
            <div className="bg-white rounded-lg shadow p-6">
              <p className="text-sm font-medium text-gray-600">Conversion</p>
              <p className="mt-2 text-3xl font-bold text-gray-900">
                {snapshot.summary.conversion_percent !== null
                  ? `${snapshot.summary.conversion_percent}%`
                  : '—'}
              </p>
            </div>
            <div className="bg-white rounded-lg shadow p-6">
              <p className="text-sm font-medium text-gray-600">Revenue</p>
              <p className="mt-2 text-3xl font-bold text-gray-900">
                {formatMoney(snapshot.summary.revenue_cents)}
              </p>
            </div>
          </div>

          {/* Alerts */}
          <div className="mb-8">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Alerts</h2>
            {snapshot.alerts.length === 0 ? (
              <div className="bg-white rounded-lg shadow p-6 text-gray-500">
                No open alerts
              </div>
            ) : (
              <div className="space-y-4">
                {snapshot.alerts.map((alert, index) => (
                  <div
                    key={index}
                    className={`bg-white rounded-lg shadow p-6 border-l-4 ${
                      alert.severity === 'critical'
                        ? 'border-red-500'
                        : alert.severity === 'high'
                        ? 'border-yellow-500'
                        : 'border-blue-500'
                    }`}
                  >
                    <h3 className="font-semibold text-gray-900">{alert.title}</h3>
                    <p className="mt-1 text-sm text-gray-600">{alert.detail}</p>
                    <p className="mt-2 text-sm text-gray-500">{alert.action}</p>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Restaurant Breakdown */}
          <div>
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Restaurant Performance</h2>
            <div className="bg-white rounded-lg shadow overflow-hidden">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Restaurant
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Calls
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Orders
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Revenue
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Escalations
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {snapshot.by_restaurant.map((restaurant) => (
                    <tr key={restaurant.restaurant_id}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {restaurant.name}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {restaurant.calls}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {restaurant.orders}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {formatMoney(restaurant.revenue_cents)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {restaurant.escalations}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </main>
      )}
    </div>
  )
}
