# Cherry launch handoff: existing number forwarded to Telnyx

> **Deploying on a VPS?** `deploy/README.md` has ready-made env, Postgres (with point-in-time recovery), nginx, systemd and cron files. The ordered list of everything to finish before the POS API work is `DEVELOPER_BEFORE_POS_API_2026-09-28.md`.

This is the launch sequence for **one location at a time**. The restaurant keeps
its public number with its current carrier and forwards it to a dedicated
Telnyx DID. Cherry sends an itemized Square checkout link, then ends its call
flow. The buyer completes payment on Square. Cherry does not wait for payment
and does not send a second kitchen ticket in this mode.

## 0. Confirm the voice design before changing any public forwarding

The current code provides an HTTP gateway (`voice_gateway.py`) and a Telnyx
Call Control transfer adapter (`telnyx_voice.py`). It does **not** implement a
SIP media server or an Inworld-specific event adapter. Confirm in the actual
Inworld and Telnyx accounts that all of the following are possible:

1. Telnyx can deliver the DID's audio to the supplied Inworld SIP endpoint.
2. The Inworld agent/worker can call the gateway's HTTP endpoints on call
   start, tool selection, completion, hangup, and human handoff, and can speak
   the returned `say` text exactly.
3. The worker can supply the **actual Telnyx `call_control_id`** for the same
   active call. A SIP Call-ID or an Inworld-generated ID is not interchangeable.
4. The caller ID and destination DID survive the restaurant carrier's forward.
   Cherry needs the caller's number to text checkout and the DID to pick the
   right restaurant.

The Telnyx transfer code requires item 3. If a direct SIP connection does not
provide Call Control for that call, use a provider-supported SIP transfer or
change the Telnyx route to keep the call under Programmable Voice control.
That choice may need vendor-specific adapter code. **Do not promise that
human handoff is configuration-only until a real call proves it.** Telnyx's
[Call Control transfer API](https://www.postman.com/telnyx-api/telnyx-api/request/pae2a8j/transfer-call)
uses `call_control_id`.

## 1. Collect the inputs for the first location

| Input | Source / acceptance |
| --- | --- |
| Published restaurant number | Owner; remains at its current carrier |
| Dedicated Telnyx DID | One voice-capable DID per location |
| Direct human fallback | Owner; a separate line or mobile that does **not** forward to Cherry |
| Menu, modifiers, tax, hours | Owner approval of this location's current menu |
| Square merchant authorization | Restaurant owner; production access and correct Square location |
| Inworld SIP endpoint and callback/tool contract | Inworld account or integration owner |
| Hosting destination | Public HTTPS for provider callbacks; private Cherry API path |
| Managed PostgreSQL destination | Connection URL stored in the deployment secret manager |

Square is the only production itemized checkout provider wired here. A
Toast-only merchant or a generic restaurant website cannot carry Cherry's
exact cart through this checkout flow without another integration. Do not
activate that location until it has a supported order-specific checkout.

## 2. Install and run the code checks

From this directory, use a supported Python 3 environment:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements-postgres.txt
python3 test_voice_gateway.py
python3 test_voice.py
python3 test_voice_http.py
python3 test_telnyx_voice.py
python3 test_server.py
python3 test_payment_gate.py
python3 test_pilot_deploy.py
python3 test_postgres_support.py
python3 test_production_jobs.py
```

These are local code checks, including HTTP loopback tests and database
contract checks. They do not prove the live provider connections.

## 3. Create and verify PostgreSQL

Create a managed PostgreSQL database in the selected hosting account. Enable
the provider's encrypted storage, backups/point-in-time recovery, and
monitoring. Put its URL in the secret manager as `CHERRY_DATABASE_URL`;
inject it into the Cherry server and deployment commands. Never commit it.
Then run:

```bash
python3 production_db.py bootstrap
python3 production_db.py verify
python3 production_db.py backup --out backups/cherry-first.dump
```

Create a **separate disposable** database with `restore` or `drill` in its
name, inject `CHERRY_RESTORE_DATABASE_URL`, and run the guarded restore drill
from `DATABASE.md`. Store real backups outside the application host. Cherry
uses SQLite only for local development; a managed PostgreSQL instance is not
created by this repository.

## 4. Connect Square checkout for the location

Get the restaurant's authorization for the Square application and the correct
Square location ID. The [Square Order Checkout guide](https://developer.squareup.com/docs/checkout-api/square-order-checkout)
confirms that the payment link creates its associated order from the itemized
request. The application needs the permissions required by Square's
[Create Payment Link API](https://developer.squareup.com/reference/square/checkout/create-payment-link).
Inject these per-location secrets/settings (replace the suffix with the
location ID in uppercase, with hyphens changed to underscores):

```text
SQUARE_TOKEN_BUN_N_RUN_FERNDALE
SQUARE_LOCATION_BUN_N_RUN_FERNDALE
```

`square_oauth.py` now covers the whole merchant flow; only the provider
accounts and the production secret store are left to the deployment.

One-time server settings (secret manager, never git):

```text
SQUARE_OAUTH_CLIENT_ID / SQUARE_OAUTH_CLIENT_SECRET   from the Square developer dashboard
CHERRY_OAUTH_STATE_SECRET                              random, 32+ chars
CHERRY_SECRET_DIR                                      e.g. /var/lib/cherry/secrets (chmod 700)
```

Register `https://<your-host>/v1/oauth/square/callback` as the redirect URL
in the Square application (TLS required). For each restaurant:

```bash
python3 square_oauth.py authorize-url --restaurant bun-n-run-ferndale   # send this link to the owner
python3 square_oauth.py status --restaurant bun-n-run-ferndale          # expect state "ok"
python3 square_oauth.py set-location --restaurant ID --location LXXXX   # only if the account has several locations
```

The callback verifies the signed link, exchanges the code, finds the Square
location and writes `SQUARE_TOKEN_*`, `SQUARE_REFRESH_*`, `SQUARE_EXPIRES_*`,
`SQUARE_LOCATION_*` into the vault (`vault.py`). Every Square reader
(checkout sink, reconciliation, catalog check, `pilot_deploy.py`) reads the
vault first and the environment second, so a refreshed token takes effect
without a restart. Schedule this **daily**; it renews only tokens that expire
within 7 days and exits non-zero on any failure or missing authorization so
your scheduler alerts:

```bash
python3 square_oauth.py refresh --restaurant ID1 --restaurant ID2 ...
```

To use a managed secret manager instead of `CHERRY_SECRET_DIR`, provide an
object with `get(name)` / `put(name, value)` / `names()` (see `vault.py`).
Not yet proven: the Square scopes in `SQUARE_SCOPES` and the callback against
Square's *sandbox* with real credentials. Do that before the first live merchant.

Set `CHERRY_CHECKOUT_HANDOFF_ONLY=1`. In this mode the Square payment webhook
is optional for the *call flow*. It may be connected for status records, but
its callback must never issue a second kitchen ticket. The production
reconciliation job also honors this mode. Square shows fulfillment orders in
its Dashboard/POS **after payment**, even though Cherry ends the call when it
sends the link. [Square order visibility](https://developer.squareup.com/docs/orders-api/create-orders)

## 5. Configure Telnyx voice, SMS, and the direct fallback

Inject `TELNYX_API_KEY`, `TELNYX_FROM_NUMBER`, and `TELNYX_PUBLIC_KEY` into the
services that need them. The sending number must be messaging enabled and
assigned to an approved 10DLC campaign where applicable. Point the signed
Telnyx messaging webhook to Cherry's public
`POST /v1/webhooks/telnyx/sms`; verify an actual delivered checkout SMS and a
STOP reply. A successful send API response alone does not prove delivery.

For the first example location, inject:

```text
CHERRY_INBOUND_BUN_N_RUN_FERNDALE=+1<TELNYX_DID>
CHERRY_DIRECT_FALLBACK_BUN_N_RUN_FERNDALE=+1<DIRECT_STAFF_LINE>
CHERRY_REQUIRE_DIRECT_FALLBACK=1
```

Use real E.164 numbers, not the placeholders above. The direct fallback may
not equal the forwarded public number or **any** active Telnyx DID. The live
preflight rejects these loops. Assign the DID's voice path to the confirmed
Inworld arrangement from step 0. Do not enable Telnyx's always-forward setting
on the DID, because it would bypass the AI.

## 6. Apply the location to Cherry

With the same production environment injected, run:

```bash
python3 pilot_deploy.py plan --only bun-n-run-ferndale
python3 pilot_deploy.py apply --only bun-n-run-ferndale --sink square
python3 pilot_deploy.py verify --only bun-n-run-ferndale
python3 pilot_deploy.py checkout-ready --only bun-n-run-ferndale
python3 pilot_smoke.py --only bun-n-run-ferndale
python3 failover_drill.py --only bun-n-run-ferndale
```

`apply` publishes the menu and number route to the database. `verify` checks
the active route and direct fallback. `checkout-ready` checks that the Square
and SMS configuration is present; it does not create a live checkout. The
offline failover drill proves the code will request one transfer to the direct
line, not that the provider will execute it.

## 7. Start the two services

Inject `CHERRY_API_KEY`, `CHERRY_VOICE_KEY`, `CHERRY_BASE_URL`,
`CHERRY_DATABASE_URL`, the location settings above, and the provider secrets.
Run one Cherry process and one gateway process initially:

```bash
python3 server.py --real-sms --checkout-handoff-only --port 8080
python3 voice_gateway.py --port 8090
```

`server.py` now reads `CHERRY_API_KEY` from the environment. Set
`CHERRY_BASE_URL` for the gateway to the private Cherry address, for example
`http://127.0.0.1:8080` when both services are on one host, or private HTTPS.
The gateway requires `X-Voice-Key` on every request. Put HTTPS and access
controls in front of both services. Keep the Cherry API private where
possible; expose only the signed provider webhook paths publicly. Both
services hold active call state in memory, so use one instance of each for
the first launch. Scaling needs sticky routing or shared session state.

Confirm `GET /health` returns a healthy database and the expected active
restaurant count. `pilot_smoke.py --base-url <PRIVATE_CHERRY_URL>` also checks
the running server's health and tool contract.

## 8. Connect Inworld to the gateway

`GET /v1/voice/tools` returns the tool schemas and system prompt. Supply
those to the Inworld agent. Inworld's worker calls the gateway with
`X-Voice-Key: <CHERRY_VOICE_KEY>`:

| Event | Gateway request |
| --- | --- |
| Incoming call | `POST /v1/voice/calls` with `call_control_id`, `to` (Telnyx DID), `from` (caller) |
| Selected tool | `POST /v1/voice/calls/{id}/tools/{tool_name}` with the tool arguments |
| Caller done | `POST /v1/voice/calls/{id}/finish` |
| Caller hangs up | `POST /v1/voice/calls/{id}/abandon` |
| Caller requests staff | `POST /v1/voice/calls/{id}/handoff` |

URL-encode `{id}`. The worker must speak each `say` value verbatim and retain
one call ID for the call. `VOICE_FORWARDING.md` has the full JSON contract.
If the Inworld product cannot emit these events or carry Telnyx's Call Control
ID, an Inworld-specific adapter remains to be written; this repository does
not silently supply one.

### 8a. TTS language and the Lily voice (multilingual callers)

- **Pass the language on every TTS request** (`es`, `ar`, `en`, ...), taken
  from whatever language the caller is speaking. If it is left empty, TTS
  guesses — and an English voice guesses toward English. This is a five-minute
  test; prove it before any multilingual claim.
- **Replace the default voice with a custom Lily voice.** Clone her from a
  native bilingual Spanish/English speaker — 5–15 seconds of clean audio and
  their **written consent** (recording/clone rights in writing, keep it with
  the onboarding case). Because she is native in both, the same voice sounds
  native in both and stays the same person when the caller switches mid-call.
  This is the real fix; the alternative is below.
- **Fallback: Inworld voice localization** on the chosen voice, which adapts
  it to sound native per language. Quicker than finding a bilingual speaker,
  but a **native speaker must judge it** before it goes live.
- Cherry's side of the chain already exists: `localization.py`
  (`SafeLocalizer`) translates the spoken `say` text while protecting menu
  names and dollar amounts, so TTS never receives a half-translated price.
  Menu translations themselves remain a later-scope prerequisite (`TASKS.md`).

## 9. Prove one live call before enabling public forwarding

First call the Telnyx DID directly from a separate phone. Verify the correct
location greeting, item/modifier/price read-back, caller number, and successful
checkout SMS. Open the link and check the exact items, taxes, location, and
total on Square's page. Complete a controlled payment and confirm how the
merchant actually sees the order. Test a request for a person and an induced
Cherry failure; both must reach the **direct** staff line without looping.

Then ask the existing carrier to forward the published restaurant number to
the tested Telnyx DID. Call the **published** number from an outside phone and
repeat the caller-ID, routing, SMS, checkout, and human-transfer checks. Have
the restaurant owner confirm the menu and the resulting Square order. If a
live call fails, disable forwarding at the existing carrier so calls return to
the original restaurant line.

## 9b. Scheduled jobs, alerts, and deploys

Every job below is a plain command; put each on the platform scheduler (cron,
systemd timer, or the host's job runner) with the same environment as the
server. A non-zero exit means "page someone".

| Job | Command | How often |
| --- | --- | --- |
| Alerts to the owner's phone | `python3 production_jobs.py --db "$CHERRY_DATABASE_URL" alerts` | every 2 minutes |
| Square token refresh | `python3 square_oauth.py refresh --restaurant ID ...` | daily |
| Catalog check | `python3 catalog_nightly.py --db "$CHERRY_DATABASE_URL" --restaurant ID ...` | nightly |
| Square payment status | `python3 production_jobs.py --db ... reconcile-square --restaurant ID` | daily |
| Transcript review queue | `python3 production_jobs.py --db ... transcripts` | daily |
| Database backup | `python3 production_db.py backup --out /approved/cherry-$(date +%F).dump` | daily, copy off the host |
| Plan-limit and cost review | `production_jobs.py ... plan-review` / `cost-savings` | monthly |
| Nightly brief | `python3 nightly_brief.py --db "$CHERRY_DATABASE_URL"` | nightly |

**Alerts reach a phone with no third-party pager.** Set
`CHERRY_ALERT_PHONE=+13135550100,+13135550101` (comma-separated E.164) and/or
`CHERRY_ALERT_WEBHOOK=https://...`. Each alert is sent once, worded for a lock
screen, and contains no caller phone numbers. The rules page for: an order not
delivered or acknowledged, a stuck payment, a call left open, a **failed staff
transfer**, a failed text, a missing live menu, **callers unable to get a
checkout link** (critical at 3 in an hour), and a **Square token refresh that
is failing**. The Telnyx sending number must be SMS-enabled and on an approved
10DLC campaign, or these texts will not arrive: test with a real page before launch.

**Deploying without dropping callers.** `GET /health` reports `live_calls`. Prefer
to deploy when it is 0. If a restart happens mid-call anyway, the server rebuilds
each live call from its journal (same cart, same menu version, same line ids), so
callers carry on; a call that cannot be rebuilt *exactly* is handed to staff rather
than risking a wrong cart. Run one server and one gateway process (call state is
otherwise in memory).

**What happens when things break** (all proven by `test_rehearsal.py`):
Square down, Square token expired, SMS failing, or a Square total that differs from
Cherry's quote: the caller is transferred to the direct line and the failure is
logged and alerted. Telnyx transfer itself failing: the caller is told the
restaurant's direct number to dial, and a critical alert is raised. A location with
no way to issue a checkout link (for example a Toast-only restaurant): the caller
goes straight to staff before any questions.

## 10. Launch acceptance

Activate the location only after all of these are observed on real services:

- PostgreSQL verifies and a separate restore drill succeeds.
- Published number reaches the correct Inworld agent through the Telnyx DID.
- Inworld sends the correct Telnyx call identifier and Cherry tool requests.
- Caller ID survives forwarding and a checkout SMS reaches a real handset.
- The Square page contains the exact order and the merchant sees the paid
  order without Cherry creating a duplicate kitchen ticket.
- Both requested and failure-triggered human transfers reach the direct line.
- The owner signs off on menu, prices, hours, fallback line, and checkout.

These are provider acceptance checks, not merely configuration checks. Repeat
for each location; never reuse one store's DID, menu, Square location, or
fallback route for another.
