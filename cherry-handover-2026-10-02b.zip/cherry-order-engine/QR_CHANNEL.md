# The QR channel — decision

> **REVISION 2026-09-29: the counter QR agent is now a build decision.**
> The original decision below answered "what is the cheapest ordering
> channel?" — and "link to the POS page, build nothing" was right for that.
> The owner's actual use case is different and stronger: the **2-person
> restaurant** (one chef, one person doing everything else), where the
> person at the counter keeps getting pulled away. The QR agent is staff
> augmentation, not an ordering channel.
>
> **What changes:** a conversational web agent reached by counter QR. The
> POS page cannot hold the conversation the cashier holds — allergens,
> spice levels, substitutions, combos — and cannot serve the customer in
> their own language. That conversation is the product.
>
> **What we build:** a chat UI per restaurant (no app install) that opens a
> `channel='web'` session and drives the SAME session/tool/finish API the
> voice agent uses; on-screen read-back before payment; pay link rendered
> from the existing POS sink; Cherry never touches money — unchanged.
> No telephony, no 10DLC, no TTS: cheaper per order than voice.
>
> **Prerequisite:** menu enrichment — allergen/dietary tags and modifier
> descriptions in the menu YAML. The agent answers menu questions ONLY from
> menu data and says "ask at the counter" where data is missing. No guessing,
> same straitjacket as voice.
>
> **Prerequisite status 2026-09-30: BUILT.** `MENU_ENRICHMENT.md` —
> `description`/`allergens`/`dietary` in the schema, closed vocabularies,
> ambiguous values rejected, contradictions blocking, and the answer layer
> that never converts a missing tag into a "no". What remains is *data*, not
> code: an owner has to write the facts down, and every shipped menu is
> currently blank. `python menu_enrichment.py report --menus menus` is the
> worklist.
>
> **Sequencing:** after the Square bridge is live and the first pilots are
> running — it uses the identical pay-link flow. The old decisions that
> still stand: no SMS ordering thread (10DLC risk, latency), no
> Cherry-hosted static ordering page (the POS page already exists).

You said whatever I think is right. Here it is, with the reasoning, so you can
overrule it if you know something about these owners that I don't.

## Decision: link to the POS's own ordering page. Build nothing.

Not a conversational SMS thread. Not a Cherry-built ordering page either.

## Why not an SMS thread

- **A2P 10DLC.** Every message type you push through SMS raises the stakes on
  one carrier approval that already gates your kitchen tickets and pay links.
  A conversational ordering thread is a lot of traffic riding on that approval.
- **A long code is one message per ten seconds.** A back-and-forth order is
  a dozen messages. That is two minutes of latency in the best case.
- **Typing a 144-item Indian order over SMS is miserable.** Either you dump the
  menu into a text nobody reads, or you do twenty round trips.

Cost was your original reason and it is the weakest of the four. At your
volumes SMS is cheap. The other three are what kill it.

## Why not a Cherry-built ordering page either

This is the part that changed my mind, and it is worth checking before writing
any code.

I opened Pink Garlic's Square site. **They already have a working online
ordering page** — full menu, categories, a cart, "Order Online". Square gives
it to them for free, it is already connected to their POS, it already takes
payment, and orders from it already reach their kitchen the way Square
intends.

Bun N Run has the same thing through Toast.

So a Cherry-built ordering page would be: a worse version of a page they
already have, that we have to maintain, that needs its own payment integration,
that duplicates the menu we are already modelling, and that gives the owner a
second place for prices to drift out of sync. The QR code can simply point at
the page that already exists.

## What the QR code should actually do

```
QR on the table/counter  ->  the restaurant's existing POS ordering page
```

That is it. No code from us. It is a link.

For Juan Miguel's, whose Heartland ordering is currently switched off, the QR
points at their phone number instead — which is Cherry. That is a feature, not
a fallback: their online ordering being broken is exactly why they need a voice
agent.

## What we DO build, when there is a reason to

The one thing the POS page cannot do, and the only reason to build anything
here, is **continuity with the phone call**:

> A caller is on the phone with Lily, the order is complicated, and she texts
> them a link that already contains everything they have said so far, so they
> can finish it on a screen.

That is worth building because no POS gives it and it is the thing Cherry
uniquely knows. But it is worth building **after** you have heard 20 real calls
and can say whether callers actually hit that wall. Building it now is guessing.

The plumbing is already there when you want it: `channel='web'` exists in the
schema, the order snapshot is already the thing you would hand to a page, and
`SquareSink` already produces a Square-hosted pay link. It is front-end work
against an engine that is finished.

## What this means for the task list

- **Task 41 (decide the QR channel): closed.** Point the QR at the POS page.
- No new engineering task. Ask each owner for their existing ordering URL when
  you do the menu review with them — it is one line in the restaurant record.
- Revisit "continue your phone order on a screen" after the first 20 calls.

## Before you commit to this

Two things I could not check and you can:

1. **Does Juan Miguel's Heartland ordering come back on?** Their menu page says
   "Online ordering is currently disabled." If they turn it on, they get the
   same free page and the same answer applies.
2. **Do these owners actually want QR ordering at all**, or was this about
   capturing customers who currently call and hang up? If it is the latter,
   the answer is not a QR code — it is Cherry answering the phone, which is the
   thing you are already building.
