#!/usr/bin/env python3
"""lookup_probe.py: measures Telnyx carrier lookups without ever printing a number or the key."""

from __future__ import annotations

import contextlib
import io
import json
import tempfile
import traceback
import urllib.error

import lookup_probe as lp
from order_store import OrderStore

_passed = _failed = 0
KEY = "KEY-SECRET-123"


def check(name, cond, detail=""):
    global _passed, _failed
    if cond:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


class Resp:
    def __init__(self, doc):
        self.raw = json.dumps(doc).encode()

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def read(self):
        return self.raw


TYPES = {"+13135550001": "mobile", "+13135550002": "fixed line", "+13135550003": "fixed line or mobile", "+13135550004": "voip",
         "+13135550005": "toll free", "+13135550006": None, "+13135550007": "mobile"}


def opener(req, timeout=None):
    assert req.get_header("Authorization") == f"Bearer {KEY}"
    num = req.full_url.split("/number_lookup/")[1].split("?")[0].replace("%2B", "+")
    assert req.full_url.endswith("?type=carrier")
    if num == "+13135550099":
        raise urllib.error.HTTPError(req.full_url, 422, "bad", {}, io.BytesIO(b"{}"))
    if num == "+13135550098":
        raise TimeoutError("slow")
    return Resp({"data": {"carrier": {"type": TYPES.get(num)}}})


def t_classification_follows_telnyxs_documented_types() -> None:
    for t, want in (("mobile", "can-text"), ("voip", "can-text"), ("fixed line", "cannot-text"), ("toll free", "cannot-text"),
                    ("fixed line or mobile", "ambiguous"), ("unknown", "ambiguous"), ("", "ambiguous"), ("error 422", "error")):
        check(f"{t!r} is {want}", lp.classify(t) == want, lp.classify(t))
    check("a missing type is 'unknown', not a crash", lp.lookup("+13135550006", KEY, opener=opener) == "unknown")
    check("an HTTP error is reported as an error, not raised", lp.lookup("+13135550099", KEY, opener=opener) == "error 422")
    check("a timeout is reported as an error, not raised", lp.lookup("+13135550098", KEY, opener=opener) == "error network")


def t_the_probe_reports_shares_and_hides_numbers() -> None:
    r = lp.probe(sorted(TYPES), KEY, opener=opener)
    check("seven numbers looked up", r["looked_up"] == 7)
    check("counts by type", r["by_type"]["mobile"] == 2 and r["by_type"]["fixed line"] == 1 and r["by_type"]["unknown"] == 1, str(r["by_type"]))
    check("definite = mobile x2 + voip + fixed line + toll free = 5 of 7", abs(r["definite_share"] - 5 / 7) < 1e-9, str(r["definite_share"]))
    check("definite landlines = fixed line + toll free = 2 of 7", abs(r["landline_share"] - 2 / 7) < 1e-9)
    check("the numbers are kept masked to the last four digits", all(m[0].startswith("…") and len(m[0]) == 5 for m in r["masked"]))

    store_path = tempfile.mkdtemp() + "/p.db"
    s = OrderStore.sqlite(store_path)
    s.upsert_restaurant("r1", "R1", "x", sink="manual", tax_rate_bps=0, staff_phone="+13135550100", active=True)
    mv = s.publish_menu("r1", "y", item_count=1)
    for i, n in enumerate(sorted(TYPES) + ["not-a-number"]):
        s.start_session("r1", mv, channel="voice", external_id=f"e{i}", caller_phone=n)
    s.close()

    def cli(*argv, env=None):
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            rc = lp.main(list(argv), env={"TELNYX_API_KEY": KEY} if env is None else env, opener=opener)
        return rc, buf.getvalue()
    rc, out = cli("--db", store_path, "--limit", "50")
    check("the database run looks up each valid caller once and prints percentages", rc == 0 and "7 numbers looked up" in out and "definite landlines: 29%" in out, out)
    check("it never prints a phone number or the key", "+1313" not in out and "313555" not in out and KEY not in out, out)
    rc, out = cli("--db", store_path, "--show")
    check("--show prints only the last four digits", "…0002  fixed line" in out and "+1313" not in out and "31355500" not in out, out)
    rc, out = cli("--numbers", "+13135550001", "garbage")
    check("explicit numbers work and junk is dropped", rc == 0 and "1 numbers looked up" in out, out)
    rc, out = cli("--numbers", "garbage")
    check("nothing valid to look up is exit 1", rc == 1)
    rc, out = cli("--numbers", "+13135550001", env={})
    check("no key says to export it, by name", rc == 2 and "TELNYX_API_KEY is not set" in out, out)


def main() -> int:
    global _failed
    for name, fn in sorted((k, v) for k, v in globals().items() if k.startswith("t_")):
        try:
            fn()
        except Exception:                                    # noqa: BLE001
            _failed += 1
            print(f"\n--- FAIL {name} raised")
            traceback.print_exc()
    print(f"{_passed} passed, {_failed} failed (lookup probe)")
    return 1 if _failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
