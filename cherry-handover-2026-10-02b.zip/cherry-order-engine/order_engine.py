"""
Cherry Order Engine — cuisine-agnostic core.

This module contains ZERO restaurant-specific data. Every restaurant is a
RestaurantConfig built in its own file (see cuisine_packs.py).

Design goals, in priority order:

  1. Never silently guess. Ambiguity produces a question, not a choice.
  2. Never crash mid-call. Every failure mode returns a structured issue that
     the voice layer can read aloud.
  3. Integer cents everywhere. No floats touch money.
  4. Every hard menu shape that real cuisines demand is expressible in data,
     so onboarding restaurant #9 is a config file, never an engine change.

Menu shapes covered (each is a real thing on a real menu, not a hypothetical):

  required, no default .............. Indian spice level, Mexican protein
  optional, priced, multi-select .... add-on proteins, extra sauces
  bundled included choice ........... "all entrees include rice or fries"
  choose N of M ..................... sushi boat "pick any 3 rolls"
  defaults with negation ............ burger "no onion, extra pickle"
  size-dependent modifier pricing ... pizza toppings cost more on an 18"
  placement (half/half) ............. pepperoni on the left only
  per-option quantity ............... double pepperoni, triple cheese
  reveal / nested groups ............ "make it a combo" -> side + drink groups
  free allowance then priced ........ "first 3 toppings free, then $1.50"
  size-as-variant ................... small/large is a price axis, not a modifier
"""

from __future__ import annotations

import difflib
import itertools
import re
import uuid
from dataclasses import dataclass, field, replace
from decimal import Decimal, ROUND_HALF_UP
from enum import Enum
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import phrasebook


# ---------------------------------------------------------------------------
# Money
# ---------------------------------------------------------------------------
# All money is integer cents. The only place a non-integer appears is the
# intermediate multiplication for half-placement pricing, which is rounded
# exactly once, half-up, at the moment it becomes a line charge.

Cents = int


def money(cents: Cents) -> str:
    """Format cents for humans/logs. Never used for arithmetic."""
    sign = "-" if cents < 0 else ""
    c = abs(int(cents))
    return f"{sign}${c // 100}.{c % 100:02d}"


def _round_cents(value: Decimal) -> Cents:
    return int(value.quantize(Decimal("1"), rounding=ROUND_HALF_UP))


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class Placement(str, Enum):
    WHOLE = "whole"
    LEFT = "left"
    RIGHT = "right"


class FreeAllowancePolicy(str, Enum):
    """Which selections a group's free allowance is spent on.

    MOST_EXPENSIVE is the customer-favourable reading and the one that
    prevents "you charged me for the cheap one" complaints. Set
    LEAST_EXPENSIVE only if the restaurant explicitly says so.
    """

    MOST_EXPENSIVE = "most_expensive"
    LEAST_EXPENSIVE = "least_expensive"
    FIRST_SELECTED = "first_selected"


class IssueCode(str, Enum):
    ITEM_UNAVAILABLE = "item_unavailable"
    OPTION_UNAVAILABLE = "option_unavailable"
    SIZE_REQUIRED = "size_required"
    SIZE_UNAVAILABLE = "size_unavailable"
    MISSING_REQUIRED_GROUP = "missing_required_group"
    GROUP_CONFIRMATION_REQUIRED = "group_confirmation_required"
    TOO_FEW_SELECTED = "too_few_selected"
    TOO_MANY_SELECTED = "too_many_selected"
    QTY_EXCEEDED = "qty_exceeded"
    PLACEMENT_NOT_ALLOWED = "placement_not_allowed"
    OPTION_NOT_IN_GROUP = "option_not_in_group"
    GROUP_NOT_ON_ITEM = "group_not_on_item"
    AMBIGUOUS_MATCH = "ambiguous_match"
    NO_MATCH = "no_match"
    EMPTY_CART = "empty_cart"


class Severity(str, Enum):
    BLOCKING = "blocking"   # order cannot be submitted
    WARNING = "warning"     # worth mentioning, not fatal


# ---------------------------------------------------------------------------
# Menu data model
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class SizeVariant:
    """A price axis, not a modifier.

    Pizza sizes change both the base price AND what toppings cost, which is
    why size lives here and modifier options may carry price_by_size.
    """

    id: str
    name: str
    price_cents: Cents
    aliases: Tuple[str, ...] = ()
    available: bool = True


@dataclass(frozen=True)
class ModifierOption:
    id: str
    name: str
    aliases: Tuple[str, ...] = ()
    # The owner's own words for this choice ("adds a smoky char"). Quotable,
    # never paraphrased into a new claim. Empty means nobody wrote it down.
    description: str = ""
    # Flat price, used when the group is not size-scoped.
    price_cents: Cents = 0
    # Size-scoped price: {size_id: cents}. Takes precedence when the parent
    # item has a size and this dict contains that size.
    price_by_size: Dict[str, Cents] = field(default_factory=dict)
    available: bool = True
    is_default: bool = False
    # Selecting this option activates these groups (combo upgrades, "add a
    # side" flows). Referenced groups should be marked reveal_only.
    reveals_group_ids: Tuple[str, ...] = ()
    # Max times this single option can be stacked on one line (double cheese).
    max_quantity: int = 1
    tags: Tuple[str, ...] = ()
    # POS identifiers for this modifier (e.g. Toast modifier-option GUIDs).
    # The engine never reads these; the bridges do.
    pos_refs: Dict[str, str] = field(default_factory=dict)

    def price_for_size(self, size_id: Optional[str]) -> Cents:
        if size_id is not None and size_id in self.price_by_size:
            return self.price_by_size[size_id]
        return self.price_cents


@dataclass(frozen=True)
class ModifierGroup:
    id: str
    name: str
    # What Lily says when this group is unsatisfied. This is the single most
    # important field for voice: a required group with no prompt is a dead air
    # bug waiting to happen, and the config linter rejects it.
    prompt: str
    # What Lily says when the group is PARTIALLY satisfied. Without this she
    # repeats the opening prompt verbatim ("which three rolls would you like?"
    # three times in a row), which sounds broken on a live call. Falls back to
    # prompt when empty; the linter warns for any group where min_select > 1.
    prompt_more: str = ""
    option_ids: Tuple[str, ...] = ()
    min_select: int = 0
    max_select: int = 1
    # Number of selections that cost nothing before pricing kicks in.
    free_select: int = 0
    free_policy: FreeAllowancePolicy = FreeAllowancePolicy.MOST_EXPENSIVE
    default_option_ids: Tuple[str, ...] = ()
    # Burger-style: defaults are on the item and may be removed by name.
    allow_negate_defaults: bool = True
    # Pizza-style: options may be applied to half the item.
    placement_enabled: bool = False
    # What a half-placed option costs relative to whole. 0.5 is typical;
    # plenty of pizzerias charge full price for a half topping -> set 1.0.
    half_placement_multiplier: Decimal = Decimal("0.5")
    # Group is inert until revealed by a parent option.
    reveal_only: bool = False
    # Purely informational (Korean banchan): never priced, never required,
    # never asked about. Kept in the model so it reaches the POS ticket.
    informational: bool = False
    # Voice ordering sometimes must explicitly ask whether the caller wants
    # changes even when every normal topping is already represented as a
    # default. This makes that acknowledgement part of order completeness.
    confirmation_required: bool = False

    @property
    def required(self) -> bool:
        return self.min_select > 0


@dataclass(frozen=True)
class MenuItem:
    id: str
    name: str
    category: str = "general"
    aliases: Tuple[str, ...] = ()
    # What the dish actually is, in the owner's words. The agent may quote this
    # verbatim; it may never turn it into a new claim. Empty means nobody has
    # written it down yet — which is not the same as "nothing to say".
    description: str = ""
    # Used when the item has no sizes.
    base_price_cents: Cents = 0
    sizes: Tuple[SizeVariant, ...] = ()
    modifier_group_ids: Tuple[str, ...] = ()
    available: bool = True
    taxable: bool = True
    tags: Tuple[str, ...] = ()
    # Owner-declared allergen facts, canonical ids from menu_enrichment.
    # READ THIS AS A ONE-WAY CLAIM: an id present means "the owner says this
    # dish contains it"; an empty tuple means "nobody declared anything", NOT
    # "free of everything". Absence of a claim is not a claim of absence, and
    # that is the single most dangerous misreading this field could invite.
    allergens: Tuple[str, ...] = ()
    # Owner-declared dietary facts (vegan, halal, ...). Positive claims only,
    # for the same reason: a missing tag is an unanswered question, and the
    # agent answers it with "ask at the counter" rather than a guess.
    dietary: Tuple[str, ...] = ()
    # Left empty until POS integration. The engine never reads these; the
    # bridges do. Keeping them here means adding Toast/Square later is a
    # data change, not a schema change.
    pos_refs: Dict[str, str] = field(default_factory=dict)

    @property
    def has_sizes(self) -> bool:
        return len(self.sizes) > 0

    def size_by_id(self, size_id: str) -> Optional[SizeVariant]:
        for s in self.sizes:
            if s.id == size_id:
                return s
        return None


@dataclass(frozen=True)
class RestaurantConfig:
    id: str
    name: str
    cuisine: str
    items: Tuple[MenuItem, ...]
    groups: Tuple[ModifierGroup, ...]
    options: Tuple[ModifierOption, ...]
    tax_rate_bps: int = 0          # basis points, e.g. 600 = 6.00%
    pay_now_threshold_cents: Cents = 3000
    pay_now_basis: str = "subtotal"  # "subtotal" | "total"
    pos_type: str = "manual_fallback"
    currency: str = "USD"

    # --- indexes, built lazily and cached on first use -------------------
    def __post_init__(self) -> None:
        object.__setattr__(self, "_item_index", {i.id: i for i in self.items})
        object.__setattr__(self, "_group_index", {g.id: g for g in self.groups})
        object.__setattr__(self, "_option_index", {o.id: o for o in self.options})

    def item(self, item_id: str) -> Optional[MenuItem]:
        return getattr(self, "_item_index").get(item_id)

    def group(self, group_id: str) -> Optional[ModifierGroup]:
        return getattr(self, "_group_index").get(group_id)

    def option(self, option_id: str) -> Optional[ModifierOption]:
        return getattr(self, "_option_index").get(option_id)

    def options_for(self, group: ModifierGroup) -> List[ModifierOption]:
        out = []
        for oid in group.option_ids:
            o = self.option(oid)
            if o is not None:
                out.append(o)
        return out


# ---------------------------------------------------------------------------
# Cart model
# ---------------------------------------------------------------------------


@dataclass
class Selection:
    group_id: str
    option_id: str
    quantity: int = 1
    placement: Placement = Placement.WHOLE

    def key(self) -> Tuple[str, str, str]:
        return (self.group_id, self.option_id, self.placement.value)


@dataclass
class OrderLine:
    item_id: str
    quantity: int = 1
    size_id: Optional[str] = None
    selections: List[Selection] = field(default_factory=list)
    # Default options the customer removed by name ("no onion").
    removed_defaults: List[str] = field(default_factory=list)
    confirmed_group_ids: List[str] = field(default_factory=list)
    note: str = ""
    line_id: str = field(default_factory=lambda: uuid.uuid4().hex[:8])

    def copy(self) -> "OrderLine":
        return OrderLine(
            item_id=self.item_id,
            quantity=self.quantity,
            size_id=self.size_id,
            selections=[replace(s) for s in self.selections],
            removed_defaults=list(self.removed_defaults),
            confirmed_group_ids=list(self.confirmed_group_ids),
            note=self.note,
            line_id=self.line_id,
        )


@dataclass
class Issue:
    code: IssueCode
    severity: Severity
    message: str                       # for logs / the dashboard
    question: Optional[str] = None     # for Lily to say out loud
    line_id: Optional[str] = None
    group_id: Optional[str] = None
    candidates: List[str] = field(default_factory=list)

    @property
    def blocking(self) -> bool:
        return self.severity is Severity.BLOCKING


@dataclass
class LinePrice:
    line_id: str
    item_name: str
    size_name: Optional[str]
    quantity: int
    unit_base_cents: Cents
    unit_modifier_cents: Cents
    unit_total_cents: Cents
    line_total_cents: Cents
    charged_modifiers: List[Tuple[str, Cents]] = field(default_factory=list)
    free_modifiers: List[str] = field(default_factory=list)
    # What each effective selection actually costs for ONE unit of the line,
    # keyed by its position in effective_selections(). A bridge that must
    # send modifiers separately (Square) needs these exact amounts: the
    # option's list price ignores free allowances and half placement.
    selection_charge_cents: Dict[int, Cents] = field(default_factory=dict)


@dataclass
class OrderPrice:
    lines: List[LinePrice]
    subtotal_cents: Cents
    tax_cents: Cents
    total_cents: Cents
    pay_now: bool


# ---------------------------------------------------------------------------
# Speech normalisation and matching
# ---------------------------------------------------------------------------

_NUMBER_WORDS = {
    "a": 1, "an": 1, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
    "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10, "eleven": 11,
    "twelve": 12, "couple": 2, "pair": 2, "few": 3, "dozen": 12,
    "half": 0,  # handled separately; never a quantity
}

_FILLERS = {
    "um", "uh", "er", "ah", "like", "yeah", "yes", "ok", "okay", "so",
    "just", "please", "gimme", "lemme", "hi", "hello", "hey", "thanks",
    "thank", "you", "id", "ill", "well", "actually", "basically", "kinda",
    "sorry", "alright",
    # "an order of fries", "a side of rice": wrappers, not part of the dish. Like
    # every filler these are kept when the menu itself uses them ("Bag of Chips").
    "order", "of", "some",
    # Wrapper speech around the dish: "can I get a", "I'll do the", "let me
    # get", "how about the". Without these, "give me the saag" scored below
    # the accept threshold and the caller was told we don't have it — while
    # bare "saag" tied correctly into a clarifying question. Every word here
    # is still kept when a menu names something with it ("Make it a Combo",
    # "Mac and Cheese") — the vocab guard in _menu_tokens is the safety net.
    "a", "an", "the", "and", "or", "for", "to", "with", "from", "at", "on",
    "i", "me", "my", "we", "us", "it", "its", "let", "lets", "let's",
    "i'll", "you'll", "we'll", "he'll", "she'll", "they'll",
    "can", "could", "would", "will", "shall", "get", "give", "got", "go",
    "want", "wanna", "need", "have", "take", "make", "do", "does", "did",
    "how", "about", "what", "that", "this", "these", "those", "there",
    "today", "tonight", "also", "then", "too", "really", "maybe",
    "probably", "definitely", "hook", "up",
}

_NEGATION_CUES = [
    "no ", "without ", "hold the ", "hold ", "minus ", "skip the ", "skip ",
    "leave off the ", "leave off ", "leave out the ", "leave out ",
    "take off the ", "take off ", "not any ", "none of the ",
]

_ADDITION_CUES = ["extra ", "add ", "with ", "plus ", "double ", "triple ", "more "]

_QTY_MULTIPLIER_CUES = {"double": 2, "triple": 3, "extra": 2}

# Words that MODIFY a dish without naming a different one. When a menu name
# is found inside a longer utterance, these are the leftovers that do not
# break the match ("extra chicken" is still the chicken; "onion rings" is
# not the onions).
_CUE_WORDS = {
    "extra", "add", "with", "plus", "double", "triple", "more",
    "no", "without", "hold", "skip", "minus", "leave", "off", "out",
    "not", "none", "light", "easy", "well", "done",
}

# Quantity speech — "two bacon", "media docena de …" — modifies HOW MANY,
# never WHAT. These words are exempt from the 1-token-alias penalty below.
_QTY_WORDS = (set(_NUMBER_WORDS)
              | {"dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho",
                 "nueve", "diez", "once", "doce", "media", "docena", "par"})


def normalize(text: str) -> str:
    t = text.lower()
    t = t.replace("&", " and ")
    t = re.sub(r"[^a-z0-9\s'-]", " ", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t


def _tokens(text: str, keep_fillers: bool = False) -> List[str]:
    toks = normalize(text).split()
    if keep_fillers:
        return toks
    return [t for t in toks if t not in _FILLERS]


def _strip_leading_quantity(tokens: List[str]) -> List[str]:
    """Drop leading quantity words before matching.

    'one cheeseburger' must not score against 'double cheeseburger' on the
    strength of sharing a leading word-sized chunk. The quantity is already
    extracted separately by parse_quantity, so leaving it in the match string
    only adds noise — and on short menu names that noise is enough to make a
    decisive match look ambiguous.

    Only strips from the front, and never strips the last token, so items
    whose own names start with a number ('2-Liter Soda') still match.
    """
    def _is_quantity(tok: str) -> bool:
        # "half" is in _NUMBER_WORDS but is never a quantity — it is part of
        # item names ("Half Deboned Chicken", "Half & Half"). Stripping it
        # turned Sam's Kabob's $19.99 Half Deboned Chicken into the $13.99
        # lunch Deboned Chicken.
        return tok.isdigit() or _NUMBER_WORDS.get(tok, 0) > 0

    out = list(tokens)
    while len(out) > 1 and _is_quantity(out[0]):
        out = out[1:]
        # 'a couple OF fries' — the connector only counts as noise when it
        # trails a quantity we just removed. Left in place elsewhere, because
        # real items are named 'Cup of Hummus' and 'Side of Rice'.
        if len(out) > 1 and out[0] == "of":
            out = out[1:]
    return out


def parse_quantity(text: str, default: int = 1) -> int:
    """Pull a leading quantity out of loose speech.

    'a couple of fries' -> 2, 'three tacos' -> 3, '2 cokes' -> 2.
    Deliberately conservative: a number appearing later in the phrase
    ('number 3 combo') is not treated as a quantity.
    """
    text = phrasebook.numbers_to_english(text)       # "dos" -> 2, "media docena" -> 6
    # "number 3", "#3", "no. 3", "combo number two" NAME a menu item; they are
    # not a quantity. Blank them out so the 3 is not read as three of them.
    text = re.sub(r"(?i)(?:\bnumber|\bnum|\bno\.?|#)\s*(?:\d+|one|two|three|four|"
                  r"five|six|seven|eight|nine|ten)\b", " ITEMNUMBER ", text)
    t = normalize(text)
    # Measure words: "half a dozen", "a dozen", "two dozen", "a couple of",
    # "a pair of", "a few". A bare "a" is one — but not when it opens one of
    # these, which is what made "a couple of fries" come out as 1.
    m = re.match(r"^(?:a\s+)?half\s+(?:a\s+)?dozen\b", t)
    if m:
        return 6
    m = re.match(r"^(?:(a|an|\w+)\s+)?(couple|pair|few|dozen)\b", t)
    if m:
        unit = _NUMBER_WORDS[m.group(2)]
        lead = m.group(1)
        if m.group(2) == "dozen" and lead and lead not in ("a", "an"):
            n = int(lead) if lead.isdigit() else _NUMBER_WORDS.get(lead, 0)
            if 1 <= n <= 8:
                return n * unit
        elif lead in (None, "a", "an"):
            return unit
    toks = _tokens(text, keep_fillers=True)
    # "let me get two cokes", "can I have three samosas": the wrapper speech
    # in front of the count must not push the number past the three-token
    # window. Skip leading fillers, THEN look — still only at the head, so a
    # number deeper in the phrase stays a name, not a quantity.
    while toks and toks[0] in _FILLERS:
        toks.pop(0)
    for tok in toks[:3]:
        if tok.isdigit():
            n = int(tok)
            return n if 1 <= n <= 99 else default
        if tok in _NUMBER_WORDS and _NUMBER_WORDS[tok] > 0:
            return _NUMBER_WORDS[tok]
    return default


# Score given to every name that fully contains what the caller said. Equal
# for all such names on purpose: ties are what force a clarifying question.
_UNDERSPECIFIED_FLOOR = 0.75


@dataclass
class MatchCandidate:
    target_id: str
    target_name: str
    score: float
    kind: str  # "item" | "option" | "size"
    # True when this name contains EVERYTHING the caller said — i.e. they may
    # simply not have finished specifying. Two of these means the utterance
    # does not distinguish between them, whatever the similarity scores say.
    covers_utterance: bool = False


class Matcher:
    """Loose-speech -> menu resolution.

    Scores on three signals and takes the max:
      * exact / alias hit                  -> 1.0
      * token containment (all words of a  -> 0.80-0.95
        name present in the utterance)
      * fuzzy ratio (mis-transcriptions)   -> difflib ratio

    Returns ranked candidates. The caller decides whether the top score is
    decisive; AMBIGUITY_MARGIN governs when we ask instead of guess.
    """

    ACCEPT_THRESHOLD = 0.62
    AMBIGUITY_MARGIN = 0.08

    def __init__(self, config: RestaurantConfig) -> None:
        self.config = config
        self._item_names: List[Tuple[str, str]] = []   # (item_id, searchable name)
        self._option_names: List[Tuple[str, str]] = []
        for it in config.items:
            self._item_names.append((it.id, normalize(it.name)))
            for a in it.aliases:
                self._item_names.append((it.id, normalize(a)))
        for op in config.options:
            self._option_names.append((op.id, normalize(op.name)))
            for a in op.aliases:
                self._option_names.append((op.id, normalize(a)))

    # -- scoring ---------------------------------------------------------
    @staticmethod
    def _score(utterance_tokens: Sequence[str], name: str) -> float:
        name_tokens = name.split()
        if not name_tokens:
            return 0.0
        utter = " ".join(utterance_tokens)
        if utter == name:
            return 1.0
        if len(utterance_tokens) > len(name_tokens) \
                and list(utterance_tokens[-len(name_tokens):]) == name_tokens \
                and all(t in _FILLERS for t in utterance_tokens[:-len(name_tokens)]):
            # "…and a chocolate milkshake": everything before the name is
            # wrapper speech, so the caller said the name exactly. Without
            # this the filler prefix kept the score at containment level,
            # where a 1-token alias ("milkshake") sat inside the ambiguity
            # margin of the 2-token name and a clear flavor order became a
            # clarifying question.
            return 1.0
        if name in utter:
            # Longer names matching inside the utterance are stronger signals.
            base = min(0.98, 0.80 + 0.03 * len(name_tokens))
            # A ONE-TOKEN alias found inside a longer utterance is the
            # dangerous case: "onion" inside "onion rings", "pepper" inside
            # "dr pepper" used to score 0.83 and silently cook the wrong
            # food (Vesuvio: "Dr. Pepper" added Pepperoni). Leftovers that
            # are quantity, addition or negation speech do not count — they
            # modify the dish, they do not name a different one ("two
            # bacon", "extra chicken", "media docena de …" with a longer
            # name, which never needed this penalty at all).
            if len(name_tokens) == 1:
                def _explained(tok: str) -> bool:
                    return any(tok == n or (len(n) >= 3 and (
                        tok.startswith(n) or n.startswith(tok)))
                        for n in name_tokens)
                leftover = [t for t in utterance_tokens
                            if not _explained(t) and t not in _FILLERS
                            and t not in _CUE_WORDS and t not in _QTY_WORDS]
                if leftover:
                    return base * len(name_tokens) / (len(name_tokens)
                                                      + len(leftover))
            return base
        uset = set(utterance_tokens)
        hits = sum(1 for t in name_tokens if t in uset)
        containment = hits / len(name_tokens)
        fuzzy = difflib.SequenceMatcher(None, utter, name).ratio()
        # Partial containment is only credible when most words land.
        containment_score = containment * 0.9 if containment >= 0.5 else containment * 0.5

        # UNDER-SPECIFICATION FLOOR.
        #
        # When everything the caller said appears in this name, they have named
        # a real but possibly incomplete dish — "saag" against both "Chicken
        # Saag" and "Lamb or Goat Saag". Scored normally, the shorter name wins
        # on length alone and the engine picks a protein the caller never said.
        #
        # Flooring every such name to the same value makes them tie, and a tie
        # is what makes is_decisive() refuse and ask. Without this, a menu with
        # the same dish in two proteins silently sends the wrong one to the
        # kitchen — which on Pink Garlic's menu was 14 dishes out of 14.
        underspecified = _UNDERSPECIFIED_FLOOR if uset and uset <= set(name_tokens) else 0.0

        return max(containment_score, fuzzy, underspecified)

    def _menu_tokens(self, text: str,
                     pool: Sequence[Tuple[str, str]]) -> List[str]:
        """The utterance's tokens, dropping filler words unless the menu uses them.

        "well" is filler in "well, I'll have the burger" but it is half of
        "Medium Well" and "Well Done"; dropping it turned a medium-well burger
        into a medium one. So a filler survives when some menu name contains
        it, EXCEPT when it is plainly an interjection: punctuated ("well,
        medium rare") or leading an utterance whose remainder already names
        something exactly ("well medium rare").
        """
        every = normalize(text).split()
        plain = [t for t in every if t not in _FILLERS]
        vocab = {t for _, n in pool for t in n.split()}
        kept = [t for t in every if t not in _FILLERS or t in vocab]
        if kept == plain:
            return plain
        lowered = text.lower()
        interjections = {t for t in set(kept) - set(plain)
                         if re.search(r"\b%s\b\s*[,.;!?]" % re.escape(t), lowered)}
        if interjections:
            kept = [t for t in kept if t in plain or t not in interjections]
        if every and every[0] in _FILLERS and every[0] in vocab:
            rest = _strip_leading_quantity(plain)
            if rest and any(self._score(rest, n) >= 0.999 for _, n in pool):
                return plain
        return kept

    def _rank(
        self, text: str, pool: Sequence[Tuple[str, str]], kind: str
    ) -> List[MatchCandidate]:
        """The caller's own words first; if they are in another language, a
        translation is tried too and used only when it matches clearly better
        (a dish named exactly as said — queso fundido — is never rewritten)."""
        base = self._rank_words(text, pool, kind)
        alt_text, lang = phrasebook.to_english(text)
        if lang is not None:
            alt = self._rank_words(alt_text, pool, kind)
            if alt and (not base or alt[0].score > base[0].score + 0.02):
                return alt
        return base

    def _rank_words(
        self, text: str, pool: Sequence[Tuple[str, str]], kind: str
    ) -> List[MatchCandidate]:
        toks = _strip_leading_quantity(self._menu_tokens(text, pool))
        if not toks:
            return []
        best: Dict[str, float] = {}
        covers: Dict[str, bool] = {}
        uset = set(toks)
        for target_id, name in pool:
            s = self._score(toks, name)
            if s > best.get(target_id, 0.0):
                best[target_id] = s
            if uset and uset <= set(name.split()):
                covers[target_id] = True
        out: List[MatchCandidate] = []
        for target_id, s in best.items():
            if s < self.ACCEPT_THRESHOLD:
                continue
            if kind == "item":
                obj = self.config.item(target_id)
            else:
                obj = self.config.option(target_id)
            if obj is None:
                continue
            out.append(MatchCandidate(target_id, obj.name, s, kind,
                                      covers.get(target_id, False)))
        out.sort(key=lambda c: (-c.score, c.target_name))
        return out

    def match_items(self, text: str) -> List[MatchCandidate]:
        return self._rank(text, self._item_names, "item")

    def match_options(
        self, text: str, allowed_option_ids: Optional[Iterable[str]] = None
    ) -> List[MatchCandidate]:
        pool = self._option_names
        if allowed_option_ids is not None:
            allowed = set(allowed_option_ids)
            pool = [(i, n) for (i, n) in pool if i in allowed]
        return self._rank(text, pool, "option")

    def match_size(self, text: str, item: MenuItem) -> List[MatchCandidate]:
        """'large' — or 'grande', 'kabir': the caller's words first, then a
        translation only if they matched nothing."""
        out = self._match_size_words(text, item)
        if not out:
            alt, lang = phrasebook.to_english(text)
            if lang is not None:
                out = self._match_size_words(alt, item)
        return out

    def _match_size_words(self, text: str, item: MenuItem) -> List[MatchCandidate]:
        toks = _strip_leading_quantity(_tokens(text))
        out: List[MatchCandidate] = []
        for s in item.sizes:
            names = [normalize(s.name)] + [normalize(a) for a in s.aliases]
            score = max((self._score(toks, n) for n in names), default=0.0)
            if score >= self.ACCEPT_THRESHOLD:
                out.append(MatchCandidate(s.id, s.name, score, "size"))
        out.sort(key=lambda c: -c.score)
        return out

    def is_decisive(self, candidates: Sequence[MatchCandidate]) -> bool:
        if not candidates:
            return False
        if len(candidates) == 1:
            return True
        # An exact match on a full name or alias beats anything partial.
        # "Chicken Shawarma Fattoush Salad with Feta" contains the shorter
        # "Chicken Shawarma Fattoush Salad", which scored close enough to
        # read as ambiguous even though the caller said one of them exactly.
        if candidates[0].score >= 1.0 and candidates[1].score < 1.0:
            return True
        # If two menu names both contain everything the caller said, the
        # caller has not distinguished between them. Similarity scores will
        # still separate the two — on name length, or on a fuzzy ratio — and
        # picking the winner there is exactly the silent guess this engine
        # must not make. Sam's Kabob sells "Grape Leaves with Meat" at $11.99
        # and "Meat Grape Leaves (8 pieces)" at $19.99.
        if sum(1 for c in candidates if c.covers_utterance) >= 2:
            return False
        return (candidates[0].score - candidates[1].score) > self.AMBIGUITY_MARGIN


# ---------------------------------------------------------------------------
# The engine
# ---------------------------------------------------------------------------


class OrderEngine:
    """One instance per live call. Holds the cart for that call only."""

    def __init__(self, config: RestaurantConfig) -> None:
        self.config = config
        self.matcher = Matcher(config)
        self.lines: List[OrderLine] = []
        # Line ids are a per-call counter, not random, so replaying a call's
        # journal after a restart rebuilds the SAME ids the voice worker was
        # already told about.
        self._line_seq = 0

    def _new_line_id(self) -> str:
        self._line_seq += 1
        return f"L{self._line_seq}"

    # -- group resolution ------------------------------------------------

    def active_group_ids(self, line: OrderLine) -> List[str]:
        """Groups in force for this line, including any revealed by selections.

        Resolved to a fixed point so a revealed group whose option reveals a
        further group (combo -> side -> side-size) also becomes active.
        """
        item = self.config.item(line.item_id)
        if item is None:
            return []
        active = [
            gid for gid in item.modifier_group_ids
            if (g := self.config.group(gid)) is not None and not g.reveal_only
        ]
        changed = True
        guard = 0
        while changed and guard < 10:
            changed = False
            guard += 1
            for sel in line.selections:
                if sel.group_id not in active:
                    continue
                opt = self.config.option(sel.option_id)
                if opt is None:
                    continue
                for gid in opt.reveals_group_ids:
                    if gid not in active and self.config.group(gid) is not None:
                        active.append(gid)
                        changed = True
        return active

    def effective_selections(self, line: OrderLine) -> List[Selection]:
        """Explicit selections plus surviving defaults from active groups.

        A default is dropped if the customer removed it by name, or if the
        customer made their own selection in that group (choosing a cheese
        replaces the default cheese rather than stacking with it, unless the
        group is genuinely multi-select).
        """
        active = self.active_group_ids(line)
        explicit_by_group: Dict[str, List[Selection]] = {}
        for sel in line.selections:
            if sel.group_id in active:
                explicit_by_group.setdefault(sel.group_id, []).append(sel)

        out: List[Selection] = []
        for gid in active:
            group = self.config.group(gid)
            if group is None:
                continue
            explicit = explicit_by_group.get(gid, [])
            out.extend(explicit)
            if not group.default_option_ids:
                continue
            explicit_ids = {s.option_id for s in explicit}
            single_select = group.max_select <= 1
            if single_select and explicit:
                # Customer's choice supersedes the default entirely.
                continue
            for did in group.default_option_ids:
                if did in line.removed_defaults or did in explicit_ids:
                    continue
                out.append(Selection(group_id=gid, option_id=did))
        return out

    # -- cart mutation ---------------------------------------------------

    def add_line(
        self,
        item_id: str,
        quantity: int = 1,
        size_id: Optional[str] = None,
        selections: Optional[List[Selection]] = None,
        note: str = "",
    ) -> OrderLine:
        line = OrderLine(
            item_id=item_id,
            quantity=max(1, int(quantity)),
            size_id=size_id,
            selections=list(selections or []),
            note=note,
            line_id=self._new_line_id(),
        )
        self.lines.append(line)
        return line

    def get_line(self, line_id: str) -> Optional[OrderLine]:
        for l in self.lines:
            if l.line_id == line_id:
                return l
        return None

    def remove_line(self, line_id: str) -> bool:
        before = len(self.lines)
        self.lines = [l for l in self.lines if l.line_id != line_id]
        return len(self.lines) != before

    def last_line(self) -> Optional[OrderLine]:
        return self.lines[-1] if self.lines else None

    def set_size(self, line_id: str, size_id: str) -> List[Issue]:
        """Change size. Drops any selection whose option is not offered at the
        new size, and reports what it dropped — silently keeping a topping the
        new size does not sell is how a ticket goes out wrong."""
        line = self.get_line(line_id)
        issues: List[Issue] = []
        if line is None:
            return [Issue(IssueCode.NO_MATCH, Severity.BLOCKING,
                          f"no such line {line_id}")]
        item = self.config.item(line.item_id)
        if item is None or item.size_by_id(size_id) is None:
            return [Issue(IssueCode.SIZE_UNAVAILABLE, Severity.BLOCKING,
                          f"size {size_id} not offered",
                          question="What size would you like?", line_id=line_id)]
        line.size_id = size_id
        kept: List[Selection] = []
        for sel in line.selections:
            opt = self.config.option(sel.option_id)
            grp = self.config.group(sel.group_id)
            if opt is None or grp is None:
                continue
            if opt.price_by_size and size_id not in opt.price_by_size:
                issues.append(Issue(
                    IssueCode.OPTION_UNAVAILABLE, Severity.WARNING,
                    f"{opt.name} not offered on {item.size_by_id(size_id).name}",
                    question=f"The {item.size_by_id(size_id).name} doesn't come "
                             f"with {opt.name} — is that alright?",
                    line_id=line_id, group_id=grp.id))
                continue
            kept.append(sel)
        line.selections = kept
        return issues

    def apply_option(
        self,
        line_id: str,
        group_id: str,
        option_id: str,
        quantity: int = 1,
        placement: Placement = Placement.WHOLE,
    ) -> List[Issue]:
        line = self.get_line(line_id)
        if line is None:
            return [Issue(IssueCode.NO_MATCH, Severity.BLOCKING,
                          f"no such line {line_id}")]
        group = self.config.group(group_id)
        option = self.config.option(option_id)
        if group is None or option is None:
            return [Issue(IssueCode.OPTION_NOT_IN_GROUP, Severity.BLOCKING,
                          f"unknown group/option {group_id}/{option_id}",
                          line_id=line_id)]
        if option_id not in group.option_ids:
            return [Issue(IssueCode.OPTION_NOT_IN_GROUP, Severity.BLOCKING,
                          f"{option.name} is not part of {group.name}",
                          line_id=line_id, group_id=group_id)]
        if group_id not in self.active_group_ids(line):
            return [Issue(IssueCode.GROUP_NOT_ON_ITEM, Severity.BLOCKING,
                          f"{group.name} does not apply to this item",
                          line_id=line_id, group_id=group_id)]
        if group_id in line.confirmed_group_ids:
            line.confirmed_group_ids.remove(group_id)
        if not option.available:
            return [Issue(IssueCode.OPTION_UNAVAILABLE, Severity.BLOCKING,
                          f"{option.name} is sold out",
                          question=f"Sorry, we're out of {option.name} today. "
                                   f"Would you like something else?",
                          line_id=line_id, group_id=group_id)]
        if placement is not Placement.WHOLE and not group.placement_enabled:
            return [Issue(IssueCode.PLACEMENT_NOT_ALLOWED, Severity.BLOCKING,
                          f"{group.name} cannot be applied to half",
                          line_id=line_id, group_id=group_id)]
        qty = max(1, int(quantity))

        def _over_cap() -> Issue:
            # Spoken aloud, so it must read as a sentence. The option name
            # may itself contain a number ("2 Wontons"), which is why the
            # count is not simply glued in front of it.
            return Issue(IssueCode.QTY_EXCEEDED, Severity.BLOCKING,
                         f"{option.name} can be added at most "
                         f"{option.max_quantity}x",
                         question=(f"I can only add one {option.name} — "
                                   f"is that okay?"
                                   if option.max_quantity == 1 else
                                   f"I can add at most {option.max_quantity} "
                                   f"of the {option.name} — is that okay?"),
                         line_id=line_id, group_id=group_id)

        if qty > option.max_quantity:
            return [_over_cap()]

        # Single-select groups replace rather than accumulate.
        if group.max_select <= 1:
            line.selections = [s for s in line.selections if s.group_id != group_id]

        for sel in line.selections:
            if sel.key() == (group_id, option_id, placement.value):
                if group.max_select > 1:
                    # "Another patty", "one more bacon": a caller re-adding a
                    # paid extra means MORE of it, not a swap. Replacing
                    # instead of accumulating charged one patty after the
                    # caller asked three times (Naked Burger, found by the
                    # burger pass). The owner's cap still holds, and going
                    # past it asks rather than silently clamping.
                    total = sel.quantity + qty
                    if total > option.max_quantity:
                        return [_over_cap()]
                    sel.quantity = total
                    return []
                sel.quantity = min(option.max_quantity, qty)
                return []
        line.selections.append(
            Selection(group_id=group_id, option_id=option_id,
                      quantity=qty, placement=placement))
        return []

    def remove_option(self, line_id: str, option_id: str) -> bool:
        """Remove an explicit selection, or suppress a default ('no onion')."""
        line = self.get_line(line_id)
        if line is None:
            return False
        removed_group_ids = {s.group_id for s in line.selections
                             if s.option_id == option_id}
        before = len(line.selections)
        line.selections = [s for s in line.selections if s.option_id != option_id]
        if len(line.selections) != before:
            line.confirmed_group_ids = [
                gid for gid in line.confirmed_group_ids
                if gid not in removed_group_ids]
            return True
        for gid in self.active_group_ids(line):
            g = self.config.group(gid)
            if g is None:
                continue
            if option_id in g.default_option_ids and g.allow_negate_defaults:
                if option_id not in line.removed_defaults:
                    line.removed_defaults.append(option_id)
                if gid in line.confirmed_group_ids:
                    line.confirmed_group_ids.remove(gid)
                return True
        return False

    def confirm_group(self, line_id: str, group_id: str) -> bool:
        """Record that the caller explicitly accepted this group's state."""
        line = self.get_line(line_id)
        group = self.config.group(group_id)
        if (line is None or group is None or not group.confirmation_required
                or group_id not in self.active_group_ids(line)):
            return False
        if group_id not in line.confirmed_group_ids:
            line.confirmed_group_ids.append(group_id)
        return True

    # -- validation ------------------------------------------------------

    def validate_line(self, line: OrderLine) -> List[Issue]:
        issues: List[Issue] = []
        item = self.config.item(line.item_id)
        if item is None:
            return [Issue(IssueCode.NO_MATCH, Severity.BLOCKING,
                          f"unknown item {line.item_id}", line_id=line.line_id)]
        if not item.available:
            issues.append(Issue(
                IssueCode.ITEM_UNAVAILABLE, Severity.BLOCKING,
                f"{item.name} is 86'd",
                question=f"I'm sorry, we're out of the {item.name} tonight. "
                         f"Can I get you something else?",
                line_id=line.line_id))
            # No point validating modifiers on an item we cannot sell.
            return issues

        if item.has_sizes:
            if line.size_id is None:
                names = ", ".join(s.name for s in item.sizes if s.available)
                issues.append(Issue(
                    IssueCode.SIZE_REQUIRED, Severity.BLOCKING,
                    f"{item.name} requires a size",
                    question=f"What size {item.name}? We have {names}.",
                    line_id=line.line_id,
                    candidates=[s.id for s in item.sizes if s.available]))
            else:
                sv = item.size_by_id(line.size_id)
                if sv is None or not sv.available:
                    issues.append(Issue(
                        IssueCode.SIZE_UNAVAILABLE, Severity.BLOCKING,
                        f"size {line.size_id} unavailable for {item.name}",
                        question=f"What size {item.name}?",
                        line_id=line.line_id))

        effective = self.effective_selections(line)
        by_group: Dict[str, List[Selection]] = {}
        for s in effective:
            by_group.setdefault(s.group_id, []).append(s)

        for gid in self.active_group_ids(line):
            group = self.config.group(gid)
            if group is None or group.informational:
                continue
            sels = by_group.get(gid, [])
            if (group.confirmation_required
                    and gid not in line.confirmed_group_ids):
                issues.append(Issue(
                    IssueCode.GROUP_CONFIRMATION_REQUIRED, Severity.BLOCKING,
                    f"{group.name} has not been confirmed",
                    question=group.prompt,
                    line_id=line.line_id, group_id=gid))
            # Count distinct selections, not stacked quantity: "double
            # pepperoni" is one topping choice, not two toward a max of 3.
            count = len(sels)
            if count < group.min_select:
                code = (IssueCode.MISSING_REQUIRED_GROUP if count == 0
                        else IssueCode.TOO_FEW_SELECTED)
                if count == 0:
                    ask = group.prompt
                else:
                    remaining = group.min_select - count
                    ask = group.prompt_more or group.prompt
                    if "{remaining}" in ask:
                        plural = "" if remaining == 1 else "s"
                        ask = ask.format(remaining=remaining, s=plural)
                issues.append(Issue(
                    code, Severity.BLOCKING,
                    f"{group.name} needs {group.min_select}, has {count}",
                    question=ask,
                    line_id=line.line_id, group_id=gid,
                    candidates=[o.id for o in self.config.options_for(group)
                                if o.available]))
            elif count > group.max_select:
                issues.append(Issue(
                    IssueCode.TOO_MANY_SELECTED, Severity.BLOCKING,
                    f"{group.name} allows {group.max_select}, has {count}",
                    question=f"You can pick up to {group.max_select} for "
                             f"{group.name} — which would you like to keep?",
                    line_id=line.line_id, group_id=gid))

            for sel in sels:
                opt = self.config.option(sel.option_id)
                if opt is None:
                    continue
                if not opt.available:
                    issues.append(Issue(
                        IssueCode.OPTION_UNAVAILABLE, Severity.BLOCKING,
                        f"{opt.name} is sold out",
                        question=f"We're out of {opt.name} — pick another?",
                        line_id=line.line_id, group_id=gid))
                if (item.has_sizes and line.size_id is not None
                        and opt.price_by_size
                        and line.size_id not in opt.price_by_size):
                    issues.append(Issue(
                        IssueCode.OPTION_UNAVAILABLE, Severity.BLOCKING,
                        f"{opt.name} not offered at this size",
                        question=f"{opt.name} isn't available on that size.",
                        line_id=line.line_id, group_id=gid))
        return issues

    def validate(self) -> List[Issue]:
        if not self.lines:
            return [Issue(IssueCode.EMPTY_CART, Severity.BLOCKING,
                          "cart is empty",
                          question="What can I get started for you?")]
        issues: List[Issue] = []
        for line in self.lines:
            issues.extend(self.validate_line(line))
        return issues

    def next_question(self) -> Optional[str]:
        """The single thing Lily should ask next, or None if the cart is clean.

        Deliberately one question at a time: stacking two questions into one
        breath is where callers answer only the second one.
        """
        for issue in self.validate():
            if issue.blocking and issue.question:
                return issue.question
        return None

    def is_submittable(self) -> bool:
        return not any(i.blocking for i in self.validate())

    # -- pricing ---------------------------------------------------------

    def price_line(self, line: OrderLine) -> LinePrice:
        item = self.config.item(line.item_id)
        if item is None:
            raise KeyError(f"unknown item {line.item_id}")

        size_name = None
        if item.has_sizes:
            sv = item.size_by_id(line.size_id) if line.size_id else None
            if sv is None:
                # Priced as the cheapest size so a quote can still be given
                # mid-call; validate() is what stops this reaching the POS.
                sv = min(item.sizes, key=lambda s: s.price_cents)
            base = sv.price_cents
            size_name = sv.name
        else:
            base = item.base_price_cents

        effective = self.effective_selections(line)
        by_group: Dict[str, List[Tuple[int, Selection]]] = {}
        for ei, s in enumerate(effective):
            by_group.setdefault(s.group_id, []).append((ei, s))
        selection_charge: Dict[int, Cents] = {}

        modifier_total: Cents = 0
        charged: List[Tuple[str, Cents]] = []
        free_names: List[str] = []

        for gid, sels in by_group.items():
            group = self.config.group(gid)
            if group is None or group.informational:
                continue
            priced: List[Tuple[Selection, ModifierOption, Cents, int]] = []
            for ei, sel in sels:
                opt = self.config.option(sel.option_id)
                if opt is None:
                    continue
                unit = opt.price_for_size(line.size_id if item.has_sizes else None)
                if sel.placement is not Placement.WHOLE and group.placement_enabled:
                    unit = _round_cents(Decimal(unit) * group.half_placement_multiplier)
                unit = unit * sel.quantity
                priced.append((sel, opt, unit, ei))

            # Spend the free allowance.
            free_n = min(group.free_select, len(priced))
            if free_n > 0:
                if group.free_policy is FreeAllowancePolicy.MOST_EXPENSIVE:
                    order = sorted(range(len(priced)), key=lambda i: -priced[i][2])
                elif group.free_policy is FreeAllowancePolicy.LEAST_EXPENSIVE:
                    order = sorted(range(len(priced)), key=lambda i: priced[i][2])
                else:
                    order = list(range(len(priced)))
                free_idx = set(order[:free_n])
            else:
                free_idx = set()

            for idx, (sel, opt, unit, ei) in enumerate(priced):
                label = opt.name
                if sel.quantity > 1:
                    label = f"{sel.quantity}x {label}"
                if sel.placement is not Placement.WHOLE:
                    label = f"{label} ({sel.placement.value})"
                if idx in free_idx or unit == 0:
                    free_names.append(label)
                    continue
                modifier_total += unit
                charged.append((label, unit))
                selection_charge[ei] = unit

        unit_total = base + modifier_total
        return LinePrice(
            line_id=line.line_id,
            item_name=item.name,
            size_name=size_name,
            quantity=line.quantity,
            unit_base_cents=base,
            unit_modifier_cents=modifier_total,
            unit_total_cents=unit_total,
            line_total_cents=unit_total * line.quantity,
            charged_modifiers=charged,
            free_modifiers=free_names,
            selection_charge_cents=selection_charge,
        )

    def price(self) -> OrderPrice:
        line_prices = [self.price_line(l) for l in self.lines]
        subtotal = sum(lp.line_total_cents for lp in line_prices)

        taxable = 0
        for line, lp in zip(self.lines, line_prices):
            item = self.config.item(line.item_id)
            if item is not None and item.taxable:
                taxable += lp.line_total_cents
        tax = _round_cents(Decimal(taxable) * Decimal(self.config.tax_rate_bps)
                           / Decimal(10000))
        total = subtotal + tax
        basis = subtotal if self.config.pay_now_basis == "subtotal" else total
        return OrderPrice(
            lines=line_prices,
            subtotal_cents=subtotal,
            tax_cents=tax,
            total_cents=total,
            pay_now=basis >= self.config.pay_now_threshold_cents,
        )

    # -- read-back -------------------------------------------------------

    def describe_line(self, line: OrderLine, changes_only: bool = False) -> str:
        """changes_only omits untouched free defaults.

        Reading six unchanged toppings back to a caller who changed one is how
        a 20-second confirmation becomes 50 seconds of them waiting to say yes.
        The kitchen ticket still carries everything; this is speech only.
        """
        item = self.config.item(line.item_id)
        if item is None:
            return "unknown item"
        parts: List[str] = []
        if line.quantity > 1:
            parts.append(str(line.quantity))
        if line.size_id and item.has_sizes:
            sv = item.size_by_id(line.size_id)
            if sv:
                parts.append(sv.name)
        parts.append(item.name)
        head = " ".join(parts)

        explicit = {(s.group_id, s.option_id) for s in line.selections}
        detail: List[str] = []
        for sel in self.effective_selections(line):
            grp = self.config.group(sel.group_id)
            opt = self.config.option(sel.option_id)
            if opt is None or grp is None or grp.informational:
                continue
            if changes_only:
                untouched_default = (sel.group_id, sel.option_id) not in explicit
                free = opt.price_for_size(
                    line.size_id if item.has_sizes else None) == 0
                if untouched_default and free:
                    continue
            frag = opt.name
            if sel.quantity > 1:
                frag = f"{sel.quantity}x {frag}"
            if sel.placement is not Placement.WHOLE:
                frag = f"{frag} on the {sel.placement.value}"
            detail.append(frag)
        for rid in line.removed_defaults:
            o = self.config.option(rid)
            if o is not None:
                detail.append(f"no {o.name}")
        if line.note:
            detail.append(line.note)
        return head + (" with " + ", ".join(detail) if detail else "")

    def read_back(self) -> str:
        if not self.lines:
            return "I don't have anything on the order yet."
        p = self.price()
        parts = [self.describe_line(l, changes_only=True) for l in self.lines]
        # "X, and Y" / "X; Y; and Z": how a person reads an order back, not a
        # list joined by semicolons.
        if len(parts) == 1:
            body = parts[0]
        elif len(parts) == 2:
            body = f"{parts[0]}, and {parts[1]}"
        else:
            body = "; ".join(parts[:-1]) + f"; and {parts[-1]}"
        return f"So that's {body}. Your total comes to {money(p.total_cents)}."

    # -- multi-quantity lines --------------------------------------------

    def split_line(self, line_id: str, take: int = 1) -> Optional[OrderLine]:
        """Peel `take` units off a line into a new, independently modifiable one.

        Modifiers are per-unit, so '3 tacos, add guac' charges guac three
        times — correct for 'three tacos all with guac', wrong for 'three
        tacos, one with guac'. When a caller differentiates mid-order, the
        voice layer splits the line and modifies the new one. Without this the
        only options are overcharging or losing the modifier.
        """
        line = self.get_line(line_id)
        if line is None or take < 1 or take >= line.quantity:
            return None
        new = line.copy()
        new.line_id = self._new_line_id()
        new.quantity = take
        line.quantity -= take
        idx = self.lines.index(line)
        self.lines.insert(idx + 1, new)
        return new

    # -- POS-agnostic output ---------------------------------------------

    def to_normalized_order(self) -> Dict:
        """The single payload every bridge consumes.

        ToastBridge, a future SquareBridge, and the manual SMS fallback all
        read this same dict. Nothing POS-specific appears in the engine.
        """
        p = self.price()
        lines = []
        for line, lp in zip(self.lines, p.lines):
            item = self.config.item(line.item_id)
            mods = []
            for ei, sel in enumerate(self.effective_selections(line)):
                opt = self.config.option(sel.option_id)
                grp = self.config.group(sel.group_id)
                if opt is None or grp is None:
                    continue
                mods.append({
                    "group_id": grp.id,
                    "group_name": grp.name,
                    "option_id": opt.id,
                    "option_name": opt.name,
                    "quantity": sel.quantity,
                    "placement": sel.placement.value,
                    "price_cents": opt.price_for_size(
                        line.size_id if item and item.has_sizes else None),
                    "informational": grp.informational,
                    # What this selection adds to ONE unit of the line,
                    # after free allowances, half placement and quantity.
                    # The unit prices above sum to unit_price_cents only
                    # when these are used.
                    "charge_cents": lp.selection_charge_cents.get(ei, 0),
                    # True when this option is simply how the item normally
                    # comes. A kitchen ticket must separate what the caller
                    # ASKED for from what the item ships with, or the cook
                    # cannot see the deviations at a glance.
                    "is_default": sel.option_id in grp.default_option_ids,
                    "pos_refs": dict(getattr(opt, "pos_refs", {}) or {}),
                })
            lines.append({
                "line_id": line.line_id,
                "item_id": line.item_id,
                "item_name": item.name if item else line.item_id,
                "size_id": line.size_id,
                "size_name": lp.size_name,
                "quantity": line.quantity,
                "unit_price_cents": lp.unit_total_cents,
                "unit_base_cents": lp.unit_base_cents,
                "line_total_cents": lp.line_total_cents,
                "modifiers": mods,
                "removed_defaults": [
                    (self.config.option(r).name if self.config.option(r) else r)
                    for r in line.removed_defaults
                ],
                "note": line.note,
                "pos_refs": dict(item.pos_refs) if item else {},
            })
        return {
            "restaurant_id": self.config.id,
            "restaurant_name": self.config.name,
            "cuisine": self.config.cuisine,
            "pos_type": self.config.pos_type,
            "currency": self.config.currency,
            "lines": lines,
            "subtotal_cents": p.subtotal_cents,
            "tax_cents": p.tax_cents,
            "total_cents": p.total_cents,
            "payment_mode": "pay_now" if p.pay_now else "pay_at_pickup",
        }
