#!/usr/bin/env python3
"""Tests for scheduled Square OAuth renewal."""

import io
import json
import urllib.error

from square_oauth import (OAuthRefreshError, SquareMerchant, SquareOAuthClient,
                          refresh_merchants)


class Response:
    status = 200
    def __init__(self, body): self.body = body
    def __enter__(self): return self
    def __exit__(self, *_): return False
    def read(self): return json.dumps(self.body).encode()


class Vault:
    def __init__(self): self.values = {"r": "refresh-old"}; self.writes = []
    def get(self, name): return self.values[name]
    def put(self, name, value): self.values[name] = value; self.writes.append((name, value))


def merchant(): return SquareMerchant("rest-1", "r", "a", "e")


def test_refresh_request_and_rotated_secret():
    seen = {}
    def open_(request, timeout):
        seen.update(json.loads(request.data))
        return Response({"access_token": "access-new", "refresh_token": "refresh-new",
                         "expires_at": "2026-10-20T00:00:00Z"})
    vault = Vault()
    result = refresh_merchants(SquareOAuthClient("app", "secret", opener=open_),
                               vault, [merchant()])
    assert result == {"checked": 1, "refreshed": 1, "failed": 0}
    assert seen["grant_type"] == "refresh_token" and seen["refresh_token"] == "refresh-old"
    assert vault.values == {"r": "refresh-new", "a": "access-new",
                            "e": "2026-10-20T00:00:00Z"}


def test_code_flow_can_keep_refresh_secret():
    vault = Vault()
    client = SquareOAuthClient("app", "secret", opener=lambda *_a, **_k: Response(
        {"access_token": "new", "expires_at": "soon"}))
    assert refresh_merchants(client, vault, [merchant()])["refreshed"] == 1
    assert vault.values["r"] == "refresh-old"


def test_invalid_response_does_not_overwrite_secrets():
    vault = Vault()
    client = SquareOAuthClient("app", "secret", opener=lambda *_a, **_k: Response({}))
    result = refresh_merchants(client, vault, [merchant()])
    assert result["failed"] == 1 and vault.writes == []


def test_http_failure_is_sanitized_and_counted():
    def fail(*_a, **_k):
        raise urllib.error.HTTPError("u", 401, "bad", {}, io.BytesIO(b'{"errors":[]}'))
    client = SquareOAuthClient("app", "secret", opener=fail)
    assert refresh_merchants(client, Vault(), [merchant()])["failed"] == 1


def test_required_configuration():
    try:
        SquareOAuthClient("", "secret")
    except ValueError:
        pass
    else:
        raise AssertionError("missing client id accepted")


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    failed = 0
    for test in tests:
        try: test()
        except Exception as exc:
            failed += 1; print(f"FAIL {test.__name__}: {exc}")
    print(f"{len(tests)-failed} passed, {failed} failed (Square OAuth)")
    raise SystemExit(bool(failed))
