"""Authentication helpers for Telnyx webhooks.

Telnyx signs ``timestamp|raw_request_body`` with Ed25519.  Verification must
use the bytes received on the wire; parsing and re-serialising JSON can change
whitespace and invalidate a legitimate signature.
"""

from __future__ import annotations

import base64
import time
from typing import Mapping, Optional

try:
    from cryptography.exceptions import InvalidSignature
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
except ImportError:  # pragma: no cover - exercised only on a broken deployment
    InvalidSignature = None  # type: ignore[assignment]
    Ed25519PublicKey = None  # type: ignore[assignment]


class WebhookVerificationError(ValueError):
    """The request cannot be authenticated as a fresh Telnyx webhook."""


def verify(raw_body: bytes, headers: Mapping[str, str], public_key: str, *,
           tolerance_seconds: int = 300,
           now: Optional[float] = None) -> None:
    """Verify a Telnyx Ed25519 signature and reject stale requests.

    ``public_key`` and the signature header are base64 encoded.  Telnyx sends a
    bare signature today; accepting the Standard Webhooks ``v1,`` prefix too
    keeps this compatible with their documented header mapping.
    """
    if Ed25519PublicKey is None:
        raise RuntimeError(
            "Telnyx signature verification needs the cryptography package")

    timestamp = headers.get("telnyx-timestamp", "")
    signature_text = headers.get("telnyx-signature-ed25519", "")
    if not timestamp or not signature_text:
        raise WebhookVerificationError("missing Telnyx signature headers")

    try:
        sent_at = int(timestamp)
    except (TypeError, ValueError) as exc:
        raise WebhookVerificationError("invalid Telnyx timestamp") from exc

    clock = time.time() if now is None else now
    if abs(clock - sent_at) > tolerance_seconds:
        raise WebhookVerificationError("stale Telnyx webhook")

    if signature_text.startswith("v1,"):
        signature_text = signature_text[3:]
    try:
        key_bytes = base64.b64decode(public_key, validate=True)
        signature = base64.b64decode(signature_text, validate=True)
        key = Ed25519PublicKey.from_public_bytes(key_bytes)
        key.verify(signature, timestamp.encode("ascii") + b"|" + raw_body)
    except (ValueError, TypeError, InvalidSignature) as exc:
        raise WebhookVerificationError("invalid Telnyx signature") from exc
