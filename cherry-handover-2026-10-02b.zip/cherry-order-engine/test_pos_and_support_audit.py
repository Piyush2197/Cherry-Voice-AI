#!/usr/bin/env python3
"""Regression checks for the Clover / Toast / Slack-support modules.

Found by running them rather than reading them:

  * on Python 3.9 a read timeout is `socket.timeout` (an OSError, NOT a
    TimeoutError), so Clover's and Toast's `except (URLError, TimeoutError)`
    let it escape as a bare exception instead of the module's own error;
  * `support_bridge.notify_alerts` printed a real ops alert as a Python dict
    repr — its own test used fake `{"kind": ...}` alerts and so passed;
  * owner-written support text went into Slack unescaped, so a message
    containing <!channel> paged the whole channel;
  * the kitchen-display feed asked for "the last 8 hours" with SQLite's
    `datetime('now','-8 hours')`: a function Postgres does not have (the
    production database), and whose space-separated text is compared against
    ISO timestamps written with a 'T', so on SQLite an order placed 13 hours
    ago was still on the tablet.
"""

from __future__ import annotations

import json
import os
import socket
import sqlite3
import tempfile
import threading
import traceback
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone

import clover_oauth
import support_bridge
import toast_oauth

_passed = _failed = 0


def check(name, cond, detail=""):
    global _passed, _failed
    if cond:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


class _Slow:
    def __enter__(self): return self
    def __exit__(self, *a): return False
    def read(self): raise socket.timeout("timed out")


def _slow(req, timeout=None):
    return _Slow()


def t_provider_timeouts_become_the_modules_own_error() -> None:
    cases = [
        ("clover exchange_code", clover_oauth.CloverAuthError,
         lambda: clover_oauth.CloverOAuthClient("id", "s", opener=_slow).exchange_code("c")),
        ("clover refresh_token", clover_oauth.CloverAuthError,
         lambda: clover_oauth.CloverOAuthClient("id", "s", opener=_slow).refresh_token("r")),
        ("toast authenticate", toast_oauth.ToastAuthError,
         lambda: toast_oauth.ToastOAuthClient("id", "s", opener=_slow).authenticate()),
    ]
    for name, err, call in cases:
        try:
            call()
            check(f"{name}: a read timeout raises", False, "returned")
        except err as exc:
            check(f"{name}: a read timeout is the module's own error", "unavailable" in str(exc), str(exc))
        except Exception as exc:                                  # noqa: BLE001
            check(f"{name}: a read timeout is the module's own error", False, type(exc).__name__)


def t_the_copper_kettle_draft_has_no_orphan_groups_and_speakable_specials() -> None:
    """The draft menu declared an egg-style question that nothing used, and
    'Kettle #1'..'#5' that a caller can only say as 'kettle one'."""
    import menu_schema as ms
    from agent_api import CallSession
    cfg = ms.load_yaml("onboarding/copper-kettle-clinton/copper-kettle-clinton.yaml")
    used = {g for it in cfg.items for g in it.modifier_group_ids}
    check("every modifier group is attached to something", {g.id for g in cfg.groups} <= used,
          str(sorted({g.id for g in cfg.groups} - used)))
    eggs = sorted(it.id for it in cfg.items if "egg_style" in it.modifier_group_ids)
    check("the egg-style question is on the plain 'N eggs' plates", eggs == [
        "big_breakfast", "kettle_1", "kettle_2", "moms_pot_roast_n_eggs", "rise_shine", "side_one_egg"], str(eggs))
    for utt, want in (("kettle one", "Kettle #1"), ("kettle two", "Kettle #2"), ("kettle special three", "Kettle #3"),
                      ("the kettle four please", "Kettle #4"), ("kettle five", "Kettle #5"),
                      ("charcuterie one half", "Charcuterie #1 (Half)")):
        s = CallSession(cfg)
        s.add_item(utt)
        lines = [(l["item_name"], l["quantity"]) for l in s.snapshot()["lines"]]
        check(f"{utt!r} is {want}, once", lines == [(want, 1)], str(lines))
    s = CallSession(cfg)
    s.add_item("big breakfast")
    s.add_modifier("scrambled")
    s.add_modifier("over easy")                       # the group takes one: this replaces it
    eggs = [m["option_id"] for m in s.snapshot()["lines"][0]["modifiers"] if m["group_id"] == "egg_style"]
    check("a caller can say how they want their eggs, and changing their mind replaces it",
          eggs == ["egg_style_over_easy"], str(eggs))


def t_slack_alerts_are_readable_and_owner_text_is_escaped() -> None:
    sent = []
    real_post = support_bridge._post
    support_bridge._post = lambda url, payload: sent.append(payload) or {"ok": True, "status": 200}
    try:
        alert = {"severity": "critical", "title": "Payment link failed",
                 "detail": "Pink Garlic Shelby: Square returned 503", "action": "Call the guest back"}
        support_bridge.notify_alerts([alert], webhook_url="https://hooks.example/x")
        text = sent[-1]["text"]
        check("a real alert reads as a sentence, not a dict", "{'severity'" not in text, text)
        check("…with severity, title, detail and what to do",
              all(x in text for x in ("critical", "Payment link failed", "Square returned 503", "Call the guest back")), text)
        support_bridge.notify_alerts([{"kind": "alert-0"}, "plain string"], webhook_url="https://hooks.example/x")
        check("an alert of unknown shape is still shown, never dropped",
              "alert-0" in sent[-1]["text"] and "plain string" in sent[-1]["text"], sent[-1]["text"])
        support_bridge.notify_support("hey <!channel> look <https://evil.example|here> & more",
                                      restaurant="A&B <!here>", webhook_url="https://hooks.example/x")
        out = sent[-1]["text"]
        check("owner text cannot mention the channel or inject a link",
              "<!channel>" not in out and "<!here>" not in out and "<https://" not in out
              and "&lt;!channel&gt;" in out, out)
        check("…and the same holds in the structured blocks",
              "<!channel>" not in str(sent[-1]["blocks"]), str(sent[-1]["blocks"])[:200])
        support_bridge.notify_support("Need the lunch price changed", webhook_url="https://hooks.example/x")
        check("ordinary text is unchanged", "Need the lunch price changed" in sent[-1]["text"])
    finally:
        support_bridge._post = real_post


def t_kitchen_display_shows_the_last_eight_hours_and_checks_its_key() -> None:
    import server as srv
    from order_store import OrderStore
    from test_kds import make_order
    secret = "kds-test-secret"
    with tempfile.TemporaryDirectory() as tmp:
        db = os.path.join(tmp, "c.db")
        store = OrderStore.sqlite(db)
        rid, oid, code, _total = make_order(store)
        app = srv.Cherry(store, api_key=secret, dev_checkout=True)
        httpd = srv.build_server(app, 0)
        base = f"http://127.0.0.1:{httpd.server_address[1]}"
        threading.Thread(target=httpd.serve_forever, daemon=True).start()

        def feed(key):
            try:
                with urllib.request.urlopen(f"{base}/kds/orders?r={rid}&k={urllib.parse.quote(key)}") as r:
                    return r.status, [o["code"] for o in json.loads(r.read())["orders"]]
            except urllib.error.HTTPError as exc:
                return exc.code, []

        def placed(hours_ago):
            ts = (datetime.now(timezone.utc) - timedelta(hours=hours_ago)).isoformat(timespec="seconds")
            c = sqlite3.connect(db)
            c.execute('UPDATE "order" SET placed_at=? WHERE id=?', (ts, oid))
            c.commit(); c.close()

        try:
            key = srv.kds_key(secret, rid)
            check("a fresh paid order is on the tablet", feed(key) == (200, [code]), str(feed(key)))
            placed(7)
            check("…and still at 7 hours", code in feed(key)[1], str(feed(key)))
            placed(13)
            check("an order placed 13 hours ago is NOT on an 8-hour display", code not in feed(key)[1], str(feed(key)))
            placed(30)
            check("…nor one from yesterday", code not in feed(key)[1], str(feed(key)))
            check("the window is a bound parameter, not SQLite-only SQL (Postgres has no datetime())",
                  "datetime(" not in open(os.path.join(os.path.dirname(srv.__file__), "server.py"),
                                          encoding="utf-8").read().split("def _kds_orders")[1].split("def _ticket")[0])
            check("a wrong key is refused", feed("0" * 16)[0] == 403)
            check("a non-ASCII key is refused with 403, not a crash", feed("caf\u00e9\u00e9")[0] == 403, str(feed("caf\u00e9")))
            check("another restaurant's key does not open this one", feed(srv.kds_key(secret, "other"))[0] == 403)
        finally:
            httpd.shutdown(); httpd.server_close(); store.close()


def main() -> int:
    global _failed
    for name, fn in sorted((k, v) for k, v in globals().items() if k.startswith("t_")):
        try:
            fn()
        except Exception:                                    # noqa: BLE001
            _failed += 1
            print(f"\n--- FAIL {name} raised")
            traceback.print_exc()
    print(f"{_passed} passed, {_failed} failed (POS scaffolding, support bridge, kitchen display audit)")
    return 1 if _failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
