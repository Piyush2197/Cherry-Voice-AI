#!/usr/bin/env python3
import localization

class Provider:
    def translate(self,text,language):
        return "ES:"+text.replace("Your total is","Su total es")

def main():
    loc=localization.SafeLocalizer(Provider())
    out=loc.translate("Butter Chicken. Your total is $14.99.","es",["Butter Chicken"])
    assert out=="ES:Butter Chicken. Su total es $14.99."
    assert loc.translate("hello","en",[])=="hello"
    print("2 passed, 0 failed (safe localization)");return 0
if __name__=="__main__":raise SystemExit(main())
