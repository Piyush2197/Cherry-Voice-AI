"""Make Cherry's text sound like a person said it.

A text-to-speech engine reads what it is given, literally. Menus are written
for eyes: "Vegetable Samosa (2Pcs)", "Lamb/Goat Korma", "Kettle #2", "12oz
Coke", "Pink Garlic Indian Cuisine (Shelby Twp)". Read aloud those come out
stilted ("slash", "two P-C-S") or run together. This turns them into what a
host would actually say, and changes nothing else: prices, dish names and the
wording of Lily's sentences are left alone.

It runs on the text AFTER it has been translated (translation protects the
menu names it is given, and those still contain their parentheses), and it is
idempotent, so applying it twice is the same as once.
"""

from __future__ import annotations

import re

_ONES = ("zero one two three four five six seven eight nine ten eleven twelve "
         "thirteen fourteen fifteen sixteen seventeen eighteen nineteen").split()
_TENS = "_ _ twenty thirty forty fifty sixty seventy eighty ninety".split()


def _words(n: int) -> str:
    if n < 20:
        return _ONES[n]
    if n < 100:
        return _TENS[n // 10] + (f"-{_ONES[n % 10]}" if n % 10 else "")
    return str(n)


def _count(match: "re.Match[str]", unit: str, plural: bool = True) -> str:
    n = int(match.group(1))
    return f"{_words(n)} {unit}{'s' if plural and n != 1 else ''}"


# Order matters: measures first, then the small abbreviations, then punctuation.
_RULES = [
    # fractions first, so the 2 in "1/2 lb" is never taken for a count
    (re.compile(r"\b1/2\b"), lambda m: "half"),
    (re.compile(r"\b1/4\b"), lambda m: "a quarter"),
    (re.compile(r"(?<![\d/])(\d+)\s*-?\s*(?:pcs?|pieces?)\b\.?", re.I), lambda m: _count(m, "piece")),
    # "a twelve ounce Coke", "a one pound order": a measure, singular
    (re.compile(r"(?<![\d/])(\d+)\s*oz\b\.?", re.I), lambda m: _count(m, "ounce", plural=False)),
    (re.compile(r"(?<![\d/])(\d+)\s*lbs?\b\.?", re.I), lambda m: _count(m, "pound", plural=False)),
    (re.compile(r"\blbs?\b\.?", re.I), lambda m: "pound"),
    (re.compile(r"\boz\b\.?", re.I), lambda m: "ounce"),
    (re.compile(r"\((\d{1,2})\)"), lambda m: f"({_words(int(m.group(1)))})"),
    (re.compile(r"\bw/o\b", re.I), lambda m: "without"),
    (re.compile(r"\bw/(?=\s|$)", re.I), lambda m: "with"),
    (re.compile(r"\bTwp\b\.?"), lambda m: "Township"),
    (re.compile(r"\bSt\.(?=\s|$)"), lambda m: "Street"),
    (re.compile(r"\b(?:No\.|Num\.?)\s*(\d+)\b"), lambda m: f"number {_words(int(m.group(1)))}"),
    (re.compile(r"#\s*(\d+)\b"), lambda m: f"number {_words(int(m.group(1)))}"),
    # "Lamb/Goat" -> "Lamb or Goat"; but never between two numbers (24/7, 3/4)
    (re.compile(r"(?<=[A-Za-z])\s*/\s*(?=[A-Za-z0-9])|(?<=[A-Za-z0-9])\s*/\s*(?=[A-Za-z])"),
     lambda m: " or "),
    (re.compile(r"\s*&\s*"), lambda m: " and "),
]
_PAREN = re.compile(r"\s*\(([^()]*)\)")


def speakable(text: str) -> str:
    """The same words, written so a voice reads them naturally."""
    if not text:
        return text
    out = text
    for rx, repl in _RULES:
        out = rx.sub(repl, out)
    # "Chicken Korma (Creamy)." -> "Chicken Korma, Creamy." : a spoken pause
    # instead of a bracket the engine may read out or skip.
    out = _PAREN.sub(lambda m: f", {m.group(1).strip()}," if m.group(1).strip() else "", out)
    out = re.sub(r",\s*([.?!;:])", r"\1", out)         # ",." -> "."
    out = re.sub(r",\s*(?=,)", "", out)                # ",," -> ","
    out = re.sub(r",\s*—", " —", out)                  # ", —" -> " —"
    out = re.sub(r"\s{2,}", " ", out)
    return out.strip()
