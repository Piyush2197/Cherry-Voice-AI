"""
Pull the menu from the restaurant's POS instead of asking them to maintain ours.

WHY THIS IS THE HIGHEST-VALUE THING TO BUILD
---------------------------------------------
At 50 restaurants the cost model says support is 40% of total cost — bigger
than every vendor line combined, and it is YOUR hours, which you cannot buy
more of. Almost all of it is three phone calls:

    "we're out of naan tonight"        -> an 86
    "lamb went up to $15.99"           -> a price edit
    "we added a special"               -> a new item

The owner has ALREADY made every one of those changes in their POS, because
that is where they ring up walk-in customers. Asking them to make it a second
time in a Cherry admin page is asking them to do double data entry, which they
will forget, and then Cherry quotes a stale price on a live call.

So: read their catalog, diff it against the live menu, and either apply the
change or raise it for review. The owner edits in one place — the place they
already edit — and Cherry follows.

WHAT IS SAFE TO APPLY AUTOMATICALLY, AND WHAT IS NOT
-----------------------------------------------------
This is the whole design question, and the answer is not "sync everything".

    AUTO-APPLY   price changes, availability (86/back-on), new items in a
                 category we already model, item renames
                 -> these cannot make Lily wrong, only current

    REVIEW       a new category, a new modifier group, an item whose
                 modifier structure we cannot infer, a deletion
                 -> these change what Lily ASKS, and a wrong question on a
                    live call is worse than a stale price

A deletion is never auto-applied. Square hides items for many reasons —
seasonal, reorganising the catalog, a mis-click — and an item vanishing from
Cherry mid-service because someone tidied their POS is a bad failure.

WHAT SQUARE CANNOT TELL US
--------------------------
Square's catalog has no concept of a REMOVAL ("no onion"), and its modifier
min/max are catalog configuration it does not enforce at order time. So the
modifier MODEL stays ours; only items, prices and availability sync. That is
the 90% that changes weekly anyway — modifier structure changes almost never.
"""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

SQUARE_VERSION = "2026-08-19"
SQUARE_PROD = "https://connect.squareup.com"
SQUARE_SANDBOX = "https://connect.squareupsandbox.com"


# ---------------------------------------------------------------------------
# What a change is
# ---------------------------------------------------------------------------

AUTO = "auto"           # safe to apply without a human
REVIEW = "review"       # needs someone to look
BLOCKED = "blocked"     # never automatic


@dataclass
class Change:
    kind: str                       # price | availability | new_item | rename | removed | structure
    level: str                      # AUTO | REVIEW | BLOCKED
    item_id: str
    what: str
    old: Any = None
    new: Any = None

    def __str__(self) -> str:
        return f"[{self.level:6}] {self.kind:12} {self.item_id:28} {self.what}"


@dataclass
class Diff:
    changes: List[Change] = field(default_factory=list)

    @property
    def auto(self) -> List[Change]:
        return [c for c in self.changes if c.level == AUTO]

    @property
    def review(self) -> List[Change]:
        return [c for c in self.changes if c.level in (REVIEW, BLOCKED)]

    def summary(self) -> str:
        if not self.changes:
            return "no changes"
        by = {}
        for c in self.changes:
            by[c.kind] = by.get(c.kind, 0) + 1
        bits = ", ".join(f"{n} {k}" for k, n in sorted(by.items()))
        return f"{len(self.auto)} auto, {len(self.review)} to review ({bits})"


# ---------------------------------------------------------------------------
# Reading the Square catalog
# ---------------------------------------------------------------------------


class SquareCatalog:
    """Reads items, variations and prices. Needs ITEMS_READ scope."""

    def __init__(self, access_token: str, location_id: str, *,
                 sandbox: bool = False, opener=None, timeout: float = 20.0):
        self.token = access_token
        self.location_id = location_id
        self.base = SQUARE_SANDBOX if sandbox else SQUARE_PROD
        self._opener = opener or urllib.request.urlopen
        self.timeout = timeout

    def _get(self, path: str) -> Dict[str, Any]:
        req = urllib.request.Request(
            f"{self.base}{path}",
            headers={"Authorization": f"Bearer {self.token}",
                     "Square-Version": SQUARE_VERSION,
                     "Accept": "application/json"})
        try:
            with self._opener(req, timeout=self.timeout) as r:
                return json.loads(r.read() or b"{}")
        except urllib.error.HTTPError as exc:
            body = exc.read() if hasattr(exc, "read") else b""
            raise RuntimeError(f"square catalog {exc.code}: "
                               f"{body[:300].decode('utf-8', 'replace')}") from exc

    def items(self) -> List[Dict[str, Any]]:
        """Every ITEM with its variations, flattened to what we care about.

        Square models a size as a VARIATION, so "Small Egg Drop Soup" is a
        variation of the item, not its own item. Each variation carries its
        own price, which is why the price lives at the variation level here.
        """
        out: List[Dict[str, Any]] = []
        cursor = None
        for _ in range(50):             # bounded: a huge catalog still ends
            path = "/v2/catalog/list?types=ITEM"
            if cursor:
                path += f"&cursor={cursor}"
            doc = self._get(path)
            out.extend(flatten_square_objects(doc.get("objects", []),
                                              self.location_id))
            cursor = doc.get("cursor")
            if not cursor:
                break
        return out


def flatten_square_objects(objects: List[Dict[str, Any]],
                           location_id: str) -> List[Dict[str, Any]]:
    """Flatten a saved Square Catalog API page without needing credentials."""
    out: List[Dict[str, Any]] = []
    for obj in objects:
        if obj.get("type") != "ITEM":
            continue
        data = obj.get("item_data") or {}
        for var in data.get("variations", []):
            vd = var.get("item_variation_data") or {}
            # Square puts location presence on the catalog OBJECT, not inside
            # item_variation_data; fall back to the item, then to the old
            # (variation-data) position so saved pages keep working.
            def _loc(key, default):
                for holder in (var, obj, vd):
                    if key in holder and holder[key] is not None:
                        return holder[key]
                return default
            present = _loc("present_at_all_locations", True)
            locs = _loc("present_at_location_ids", []) or []
            absent = _loc("absent_at_location_ids", []) or []
            if location_id in absent or (not present and location_id not in locs):
                continue
            # This location's own price and sold-out flag win over the base.
            override = next((o for o in vd.get("location_overrides") or []
                             if o.get("location_id") == location_id), {})
            money = override.get("price_money") or vd.get("price_money") or {}
            sold_out = bool(override.get("sold_out"))
            out.append({
                "catalog_object_id": var.get("id"),
                "item_id": obj.get("id"),
                "name": data.get("name", "").strip(),
                "variation_name": (vd.get("name") or "").strip(),
                "price_cents": money.get("amount"),
                "currency": money.get("currency", "USD"),
                "category_id": data.get("category_id"),
                "available": not (obj.get("is_deleted", False)
                                  or var.get("is_deleted", False) or sold_out),
            })
    return out


# ---------------------------------------------------------------------------
# The diff
# ---------------------------------------------------------------------------


def _norm(name: str, *, keep_qualifier: bool = True) -> str:
    """Match POS names to ours loosely — punctuation and case drift.

    The parenthetical qualifier is KEPT by default: "Korma (Chicken)" and
    "Korma (Lamb)" are different dishes at different prices, and erasing it
    made them one key, so one dish's price was written onto the other.
    """
    import re
    s = name.lower()
    s = re.sub(r"^\d+[a-z]?\.\s*", "", s)        # strip "29. "
    if not keep_qualifier:
        s = re.sub(r"\([^)]*\)", "", s)           # strip "(Creamy)"
    s = re.sub(r"[^a-z0-9]+", " ", s)
    return " ".join(s.split())


def diff_catalog(config, pos_items: List[Dict[str, Any]]) -> Diff:
    """Compare the live Cherry menu against the POS catalog.

    Matching is by pos_refs['square_catalog_object_id'] when it exists (exact
    and reliable), falling back to a normalised name match. An item we cannot
    match either way is reported for review rather than guessed at.
    """
    d = Diff()

    by_ref: Dict[str, Any] = {}
    by_name: Dict[str, Any] = {}
    by_base: Dict[str, Any] = {}     # qualifier stripped; None = ambiguous
    for i in config.items:
        ref = (i.pos_refs or {}).get("square_catalog_object_id")
        if ref:
            by_ref[ref] = i
        by_name.setdefault(_norm(i.name), i)
        base = _norm(i.name, keep_qualifier=False)
        by_base[base] = i if base not in by_base else None

    seen_ours = set()
    avail_votes: Dict[str, List[bool]] = {}   # per item, one vote per variation
    matched_item: Dict[str, Any] = {}
    for p in pos_items:
        if p["price_cents"] is None:
            continue                     # variable-price item; nothing to sync
        full = p["name"]
        if p["variation_name"] and p["variation_name"].lower() not in ("regular", ""):
            full = f"{p['name']} ({p['variation_name']})"

        exact = by_ref.get(p["catalog_object_id"]) or by_name.get(_norm(full))
        ours = exact or by_name.get(_norm(p["name"])) \
            or by_base.get(_norm(full, keep_qualifier=False))
        # Matched only by the base name, or to a different variation than
        # the one we are looking at: its price is not ours to compare.
        loose = exact is None and ours is not None

        if ours is None:
            # A RENAME with no stored catalog id looks exactly like a delete
            # plus a create. Before reporting either, look for one of our
            # items at the same price that nothing else has claimed — that is
            # almost always the same dish under a new name.
            candidate = None
            for i in config.items:
                if i.id in seen_ours or i.has_sizes:
                    continue
                if i.base_price_cents == p["price_cents"] and (
                        _norm(i.name) in _norm(full)
                        or _norm(full) in _norm(i.name)):
                    candidate = i
                    break
            if candidate is not None:
                seen_ours.add(candidate.id)
                d.changes.append(Change(
                    "rename", REVIEW, candidate.id,
                    f"'{candidate.name}' -> '{full}' at the same price "
                    f"({p['price_cents']}c) — likely a rename. Check the "
                    f"aliases a caller says still match.",
                    candidate.name, full))
                continue
            d.changes.append(Change(
                "new_item", REVIEW, p["catalog_object_id"],
                f"POS has '{full}' at {p['price_cents']}c — not in our menu. "
                f"Needs a category and modifier groups before Lily can sell it.",
                None, p["price_cents"]))
            continue

        seen_ours.add(ours.id)

        # Price. The single most common change: a stale price is Cherry
        # quoting the wrong number on a live call. Only applied automatically
        # when this POS variation IS the item (matched by catalog id or full
        # name); a loose match goes to a person.
        if not ours.has_sizes and ours.base_price_cents != p["price_cents"]:
            d.changes.append(Change(
                "price", REVIEW if loose else AUTO, ours.id,
                f"{ours.name}: {ours.base_price_cents}c -> {p['price_cents']}c"
                + (" (matched by name only — confirm it is the same dish)"
                   if loose else ""),
                ours.base_price_cents, p["price_cents"]))

        # Availability is decided once per item, after every variation has
        # voted: one sold-out size must not 86 the whole dish, and two
        # variations must not contradict each other.
        avail_votes.setdefault(ours.id, []).append(bool(p["available"]))
        matched_item[ours.id] = ours

        # A rename is safe to follow, but it may break the ALIASES a caller
        # says, so it is worth a look rather than silent.
        if _norm(ours.name) != _norm(full):
            d.changes.append(Change(
                "rename", REVIEW, ours.id,
                f"'{ours.name}' -> '{full}' (check aliases still match)",
                ours.name, full))

    for item_id, votes in avail_votes.items():
        ours = matched_item[item_id]
        pos_available = any(votes)
        if ours.available and not pos_available:
            d.changes.append(Change(
                "availability", AUTO, ours.id,
                f"{ours.name}: POS says unavailable", True, False))
        elif not ours.available and pos_available:
            d.changes.append(Change(
                "availability", AUTO, ours.id,
                f"{ours.name}: POS says back on", False, True))

    # Anything of ours the POS no longer lists. NEVER automatic.
    for i in config.items:
        if i.id in seen_ours or not i.available:
            continue
        d.changes.append(Change(
            "removed", BLOCKED, i.id,
            f"{i.name} is not in the POS catalog. Could be seasonal, "
            f"re-categorised, or a POS tidy-up — confirm with the owner "
            f"before removing.", True, None))
    return d


def _staff_86(store, restaurant_id: str, item_id: str) -> bool:
    """True when a current "unavailable" override was set by a person."""
    row = store.conn.execute(
        """SELECT set_by FROM availability_override
           WHERE restaurant_id=? AND target_kind='item' AND target_id=?
             AND available=FALSE""", (restaurant_id, item_id)).fetchone()
    return row is not None and (row["set_by"] or "") != "catalog_sync"


def apply_auto(store, restaurant_id: str, diff: Diff) -> Dict[str, int]:
    """Apply only what is safe.

    Availability goes through the existing 86 table — no menu republish, takes
    effect on the next call. Prices need a new menu version, which is
    deliberately a heavier operation because it changes what Lily quotes.
    """
    applied = {"availability": 0, "price": 0, "kept_staff_86": 0}
    for c in diff.auto:
        if c.kind == "availability":
            if c.new and _staff_86(store, restaurant_id, c.item_id):
                # Someone at the restaurant took this off on purpose ("we're
                # out of naan tonight"). The POS not saying "sold out" does
                # not mean they changed their mind, and re-listing a dish
                # the kitchen cannot make is the worse failure.
                applied["kept_staff_86"] += 1
                continue
            store.set_availability(restaurant_id, c.item_id, bool(c.new),
                                   reason="synced from POS catalog",
                                   set_by="catalog_sync")
            applied["availability"] += 1
        elif c.kind == "price":
            applied["price"] += 1        # counted; the republish is the caller's job
    if applied["availability"]:
        store.log_event("catalog.synced", restaurant_id=restaurant_id,
                        detail={"availability": applied["availability"],
                                "price_changes_pending": applied["price"]})
    return applied
