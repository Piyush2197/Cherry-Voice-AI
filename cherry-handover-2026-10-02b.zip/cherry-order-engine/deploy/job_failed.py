#!/usr/bin/env python3
"""Page the owner when a scheduled job exits non-zero.

    job_failed.py <job-name> <exit-code>

Uses the same channels as the alert job (CHERRY_ALERT_PHONE / _WEBHOOK), so a
dead backup or a failing token refresh reaches a phone, not a log nobody reads.
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import production_jobs as jobs  # noqa: E402


def page(name: str, code: str, sender=None) -> None:
    sender = sender or jobs.alert_sender_from_env()
    sender.send({"alert": {
        "severity": "critical", "restaurant_id": "",
        "title": f"Scheduled job '{name}' failed (exit {code})",
        "action": "Check the server logs (journalctl -u cherry-*, /var/log/cherry)."}})


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit("usage: job_failed.py <job-name> <exit-code>")
    page(sys.argv[1], sys.argv[2])
