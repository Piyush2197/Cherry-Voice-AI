import { cookies } from 'next/headers'
import { createHash, timingSafeEqual } from 'crypto'
import {
  SESSION_COOKIE,
  SESSION_HOURS,
  signSession,
  verifySession,
  type User,
} from './session'

export type { User }

/**
 * Sign-in configuration comes from the environment and ONLY from the
 * environment. There is no fallback username, password or signing secret: a
 * default credential in source is a credential everyone who has read the repo
 * knows. When anything is missing or weak, sign-in is switched off and says so
 * in the server log.
 *
 *   ADMIN_USERNAME   the sign-in name
 *   ADMIN_PASSWORD   at least 12 characters
 *   JWT_SECRET       at least 32 characters (openssl rand -hex 32)
 */
export interface AuthConfig {
  username: string
  password: string
}

let warned = false

export function authConfig(): AuthConfig | null {
  const username = process.env.ADMIN_USERNAME || ''
  const password = process.env.ADMIN_PASSWORD || ''
  const secret = process.env.JWT_SECRET || ''
  const problems: string[] = []
  if (!username) problems.push('ADMIN_USERNAME is not set')
  if (password.length < 12) problems.push('ADMIN_PASSWORD must be at least 12 characters')
  if (secret.length < 32) problems.push('JWT_SECRET must be at least 32 characters')
  if (problems.length) {
    if (!warned) {
      warned = true
      console.error(`[cherry-dashboard] sign-in is disabled: ${problems.join('; ')}`)
    }
    return null
  }
  return { username, password }
}

/** Compare without leaking, through timing, how much of a guess was right. */
function safeEqual(a: string, b: string): boolean {
  const ha = createHash('sha256').update(a).digest()
  const hb = createHash('sha256').update(b).digest()
  return timingSafeEqual(ha, hb)
}

/**
 * Validate user credentials
 */
export async function validateCredentials(
  username: string,
  password: string
): Promise<User | null> {
  const config = authConfig()
  if (!config) return null
  // Evaluate both before deciding, so a wrong username takes as long as a wrong password.
  const userOk = safeEqual(username, config.username)
  const passOk = safeEqual(password, config.password)
  return userOk && passOk ? { username: config.username, role: 'admin' } : null
}

/**
 * Verify JWT token
 */
export async function verifyToken(token: string): Promise<User | null> {
  return verifySession(token)
}

/**
 * Get current user from cookies
 */
export async function getCurrentUser(): Promise<User | null> {
  const cookieStore = await cookies()
  const token = cookieStore.get(SESSION_COOKIE)
  if (!token) return null
  return verifySession(token.value)
}

/**
 * Set auth cookie
 */
export async function setAuthCookie(token: string): Promise<void> {
  const cookieStore = await cookies()
  cookieStore.set(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 60 * 60 * SESSION_HOURS,
    path: '/',
  })
}

/**
 * Clear auth cookie
 */
export async function clearAuthCookie(): Promise<void> {
  const cookieStore = await cookies()
  cookieStore.delete(SESSION_COOKIE)
}

export type LoginResult =
  | { success: true; user: User }
  | { success: false; error: string; configured: boolean }

/**
 * Login user
 */
export async function loginUser(username: string, password: string): Promise<LoginResult> {
  if (!authConfig()) {
    return { success: false, error: 'Sign-in is not available', configured: false }
  }
  const user = await validateCredentials(username, password)
  if (!user) {
    return { success: false, error: 'Invalid credentials', configured: true }
  }
  await setAuthCookie(await signSession(user))
  return { success: true, user }
}

/**
 * Logout user
 */
export async function logoutUser(): Promise<void> {
  await clearAuthCookie()
}
