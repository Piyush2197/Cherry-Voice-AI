#!/usr/bin/env python3
"""Fail if deploy/cherry.env.example names a variable the code never reads,
or has an inline comment (systemd's EnvironmentFile would keep it in the value)."""
import re, subprocess, sys
from pathlib import Path

root = Path(__file__).resolve().parent.parent
src = "\n".join(p.read_text() for p in root.glob("*.py") if not p.name.startswith("test_"))
bad = []
for n, line in enumerate((root / "deploy/cherry.env.example").read_text().splitlines(), 1):
    if not line.strip() or line.lstrip().startswith("#"):
        continue
    name, _, value = line.partition("=")
    if " #" in value or "\t#" in value:
        bad.append(f"line {n}: inline comment in {name}")
    pattern = re.sub(r"_[A-Z0-9_]+$", "_", name) if name.startswith(
        ("CHERRY_INBOUND_", "CHERRY_DIRECT_FALLBACK_")) else name
    if pattern not in src:
        bad.append(f"line {n}: {name} is not read anywhere in the code")
# Every per-location variable the manifest expects must be in the template
# under its EXACT name. The prefix check above cannot see a wrong suffix, and
# a mis-named fallback variable makes the gateway refuse to boot.
sys.path.insert(0, str(root))
try:
    import pilot_deploy
    template = {ln.partition("=")[0].strip() for ln in
                (root / "deploy/cherry.env.example").read_text().splitlines()
                if ln.strip() and not ln.lstrip().startswith("#")}
    expected = set()
    for loc in pilot_deploy.load_manifest():
        expected.add(loc.inbound_env)
        expected.add(loc.fallback_env_name)
    for name in sorted(expected - template):
        bad.append(f"manifest expects {name} but deploy/cherry.env.example does not list it")
    for name in sorted(n for n in template - expected
                       if n.startswith(("CHERRY_INBOUND_", "CHERRY_DIRECT_FALLBACK_"))):
        bad.append(f"{name} is in the template but no manifest location reads it")
except Exception as exc:                          # noqa: BLE001
    bad.append(f"could not compare against the manifest: {exc}")
print("\n".join(bad) or "env template OK")
sys.exit(1 if bad else 0)
