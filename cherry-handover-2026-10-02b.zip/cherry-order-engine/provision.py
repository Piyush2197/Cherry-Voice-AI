#!/usr/bin/env python3
"""Provision a location's Telnyx number: buy it, route it, register it, record it.

Adding a restaurant used to mean a person in the Telnyx portal: buy a DID, point
it at the voice connection, attach the messaging profile, assign it to the 10DLC
campaign, then copy the number into the server's environment. This does the same
steps from the command line, one idempotent step at a time, and says what is
done, what is waiting on a carrier, and what is left.

    python3 provision.py status --all                      # read-only checklist, every location
    python3 provision.py plan  --location pink-garlic-shelby   # read-only: numbers you could buy, and what they cost
    python3 provision.py apply --location pink-garlic-shelby --number +12485550123 --yes \\
        --env-file /etc/cherry/cherry.env

`status` and `plan` only read. `apply` BUYS A NUMBER (money) and changes routing,
so it needs the exact `--number`, a cost under the caps, and `--yes`; it never
picks a number for you. It is safe to re-run: each step first looks at what
already exists, a second run on a finished location changes nothing, and a number
the location already owns is never bought again.

Configuration (the API key is read by name and never printed or logged):
    TELNYX_API_KEY                 (or in the vault)
    TELNYX_CONNECTION_ID           the voice connection every Cherry DID routes through (to Inworld)
    TELNYX_MESSAGING_PROFILE    the messaging profile that carries the checkout texts
    TELNYX_10DLC_CAMPAIGN_ID       the approved 10DLC campaign numbers are assigned to
    TELNYX_BILLING_GROUP_ID        optional

Written against Telnyx's documentation (checked 2026-10-02); NOT yet run against a
live account:
  https://developers.telnyx.com/api-reference/phone-number-search/list-available-phone-numbers
  https://developers.telnyx.com/api-reference/phone-number-orders/create-a-number-order
  https://developers.telnyx.com/api-reference/phone-number-configurations/list-phone-numbers
  https://developers.telnyx.com/api-reference/phone-number-configurations/update-a-phone-number
  https://developers.telnyx.com/docs/messaging/messages/phone-number-configuration
  https://developers.telnyx.com/api-reference/phone-number-campaigns/list-phone-number-campaigns
  https://developers.telnyx.com/docs/messaging/10dlc/phone-number-assignment
Telnyx's 10DLC pages name the assignment path two ways (`/10dlc/phone_number_campaigns`
in the API reference, `/10dlc/phoneNumberCampaign` in the guide); both are tried.
A 10DLC assignment is asynchronous: carriers take hours to propagate it, so a
fresh number shows `waiting` for a while, which is normal.
"""

from __future__ import annotations

import _ensure_deps  # noqa: F401  (re-runs under .venv, or says how to install, if PyYAML is missing)
import argparse
import json
import os
import re
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any, Callable, List, Mapping, Optional

import pilot_deploy as pd
from vault import secret as vault_secret

TELNYX_API = "https://api.telnyx.com/v2"
_E164 = re.compile(r"^\+[1-9][0-9]{7,14}$")
DONE, TODO, WAITING, FAILED, BLOCKED = "done", "todo", "waiting", "failed", "blocked"
_CAMPAIGN_PATHS = ("/10dlc/phone_number_campaigns", "/10dlc/phoneNumberCampaign")


class TelnyxError(RuntimeError):
    """A Telnyx call that did not succeed. ``ambiguous`` means the outcome is
    UNKNOWN (a timeout or a 5xx on a call that changes things): look before you retry."""

    def __init__(self, status: Optional[int], detail: str, *, ambiguous: bool = False):
        super().__init__(f"Telnyx {status if status is not None else 'unreachable'}: {detail}")
        self.status, self.detail, self.ambiguous = status, detail, ambiguous


class TelnyxAPI:
    """A small, careful Telnyx client: retries what is safe to retry, and nothing else."""

    def __init__(self, api_key: str, *, base: str = TELNYX_API, opener: Optional[Callable] = None,
                 timeout: float = 20.0, retries: int = 3, sleep: Callable[[float], None] = time.sleep,
                 spacing: float = 0.25):
        if not api_key:
            raise ValueError("TELNYX_API_KEY is not set")
        self._key, self.base, self.timeout, self.retries = api_key, base.rstrip("/"), timeout, retries
        self.opener = opener or urllib.request.urlopen
        self.sleep, self.spacing = sleep, spacing

    def _scrub(self, text: str) -> str:
        return (text or "").replace(self._key, "[key]")[:400]

    @staticmethod
    def _detail(raw: bytes) -> str:
        try:
            doc = json.loads(raw or b"{}")
            errs = doc.get("errors") or []
            if errs:
                return "; ".join(str(e.get("detail") or e.get("title") or e.get("code")) for e in errs)[:300]
        except (ValueError, AttributeError, TypeError):
            pass
        return (raw or b"").decode("utf-8", "replace")[:200]

    def request(self, method: str, path: str, *, params: Optional[Mapping] = None,
                body: Optional[dict] = None, idempotent: Optional[bool] = None) -> dict:
        """``idempotent`` defaults to True for GET/PATCH and False for POST. A call that
        changes things is retried only after a 429 (Telnyx refused it before doing
        anything); never after a timeout or a 5xx, where it may have happened."""
        safe_to_repeat = (method in ("GET", "PATCH", "PUT", "DELETE")) if idempotent is None else idempotent
        url = self.base + path + (("?" + urllib.parse.urlencode(params, doseq=True)) if params else "")
        data = json.dumps(body).encode() if body is not None else None
        last: Optional[TelnyxError] = None
        for attempt in range(self.retries + 1):
            if self.spacing:
                self.sleep(self.spacing)
            req = urllib.request.Request(url, data=data, method=method, headers={
                "Authorization": f"Bearer {self._key}", "Accept": "application/json",
                **({"Content-Type": "application/json"} if data is not None else {})})
            retry_after = None
            try:
                with self.opener(req, timeout=self.timeout) as resp:
                    status, raw = resp.status, resp.read()
            except urllib.error.HTTPError as exc:
                status, raw = exc.code, (exc.read() if hasattr(exc, "read") else b"")
                try:
                    retry_after = float(exc.headers.get("Retry-After")) if exc.headers else None
                except (TypeError, ValueError):
                    retry_after = None
            except (urllib.error.URLError, OSError) as exc:      # incl. 3.9's socket.timeout
                last = TelnyxError(None, self._scrub(str(exc)), ambiguous=not safe_to_repeat)
                if safe_to_repeat and attempt < self.retries:
                    self.sleep(min(30.0, 2.0 ** attempt))
                    continue
                raise last from None
            if status == 429 and attempt < self.retries:
                self.sleep(min(30.0, retry_after if retry_after is not None else 2.0 ** attempt))
                continue
            if status >= 500 and safe_to_repeat and attempt < self.retries:
                self.sleep(min(30.0, 2.0 ** attempt))
                continue
            if 200 <= status < 300:
                try:
                    return json.loads(raw or b"{}")
                except ValueError:
                    raise TelnyxError(status, "reply was not JSON", ambiguous=True) from None
            raise TelnyxError(status, self._scrub(self._detail(raw)), ambiguous=status >= 500)
        raise last or TelnyxError(None, "gave up")


def _cents(value: Any) -> Optional[int]:
    try:
        return int((Decimal(str(value)) * 100).to_integral_value())
    except (InvalidOperation, TypeError, ValueError):
        return None


@dataclass
class Candidate:
    number: str
    monthly_cents: Optional[int]
    upfront_cents: Optional[int]
    region: str = ""
    best_effort: bool = False


@dataclass
class Step:
    name: str
    state: str
    detail: str = ""
    fix: str = ""


@dataclass
class Settings:
    connection_id: str = ""
    messaging_profile_id: str = ""
    campaign_id: str = ""
    billing_group_id: str = ""
    max_monthly_cents: int = 500
    max_upfront_cents: int = 500

    @classmethod
    def from_env(cls, env: Mapping[str, str]) -> "Settings":
        g = lambda k: str(env.get(k, "")).strip()            # noqa: E731
        return cls(g("TELNYX_CONNECTION_ID"), g("TELNYX_MESSAGING_PROFILE"),
                   g("TELNYX_10DLC_CAMPAIGN_ID"), g("TELNYX_BILLING_GROUP_ID"))


def area_code(e164: str) -> str:
    m = re.fullmatch(r"\+1([2-9]\d\d)\d{7}", e164 or "")
    return m.group(1) if m else ""


def set_env_line(path: str, name: str, value: str, *, replace: bool = False) -> str:
    """Put ``NAME=value`` in an env file, touching nothing else. Returns "added",
    "unchanged" or "replaced". Refuses to overwrite a different value unless asked."""
    if not re.fullmatch(r"[A-Z][A-Z0-9_]*", name) or not _E164.match(value):
        raise ValueError("refusing to write an unexpected name or value into an env file")
    p = Path(path)
    lines = p.read_text().splitlines() if p.exists() else []
    out, found = [], None
    for ln in lines:
        m = re.match(rf"^\s*(?:export\s+)?{re.escape(name)}\s*=\s*(.*)$", ln)
        if m:
            found = m.group(1).strip().strip("\"'")
            if found == value:
                return "unchanged"
            if not replace:
                raise ValueError(f"{name} is already set to a different number in {path}")
            out.append(f"{name}={value}")
        else:
            out.append(ln)
    if found is None:
        out.append(f"{name}={value}")
    mode = (p.stat().st_mode & 0o777) if p.exists() else 0o600
    p.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(p.parent), prefix=".tmp-env-")
    try:
        with os.fdopen(fd, "w") as fh:
            fh.write("\n".join(out) + "\n")
            fh.flush()
            os.fsync(fh.fileno())
        os.chmod(tmp, mode)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except FileNotFoundError:
            pass
        raise
    return "added" if found is None else "replaced"


class Provisioner:
    def __init__(self, api: TelnyxAPI, settings: Settings, *, log: Callable[[str], None] = lambda s: None,
                 sleep: Callable[[float], None] = time.sleep, poll_seconds: float = 3.0,
                 poll_timeout: float = 120.0):
        self.api, self.s, self.log, self.sleep = api, settings, log, sleep
        self.poll_seconds, self.poll_timeout = poll_seconds, poll_timeout

    # -- reading --------------------------------------------------------------
    def search(self, area: str, *, limit: int = 5) -> List[Candidate]:
        doc = self.api.request("GET", "/available_phone_numbers", params={
            "filter[country_code]": "US", "filter[national_destination_code]": area,
            "filter[phone_number_type]": "local", "filter[features][]": ["voice", "sms"],
            "filter[limit]": limit})
        out = []
        for row in doc.get("data") or []:
            cost = row.get("cost_information") or {}
            region = ", ".join(r.get("region_name", "") for r in (row.get("region_information") or []) if r.get("region_name"))
            out.append(Candidate(row.get("phone_number", ""), _cents(cost.get("monthly_cost")),
                                 _cents(cost.get("upfront_cost")), region, bool(row.get("best_effort"))))
        return [c for c in out if _E164.match(c.number)]

    def owned(self, restaurant_id: str) -> List[dict]:
        doc = self.api.request("GET", "/phone_numbers", params={
            "filter[customer_reference]": restaurant_id, "page[size]": 20})
        return [r for r in (doc.get("data") or []) if r.get("status") not in ("deleted",)]

    def orders(self, restaurant_id: str) -> List[dict]:
        """Number orders this location has placed (Telnyx: filter[customer_reference])."""
        doc = self.api.request("GET", "/number_orders", params={
            "filter[customer_reference]": restaurant_id, "page[size]": 20})
        return list(doc.get("data") or [])

    def _wait_for_order(self, oid: str, status: str) -> str:
        """Poll a pending order for at most ``poll_timeout`` seconds (and never forever,
        whatever the clock does)."""
        polls = max(1, int(self.poll_timeout / max(self.poll_seconds, 0.1)))
        for _ in range(polls):
            if status != "pending":
                break
            self.sleep(self.poll_seconds)
            status = (self.api.request("GET", f"/number_orders/{oid}").get("data") or {}).get("status")
        return status

    def number_record(self, e164: str) -> Optional[dict]:
        doc = self.api.request("GET", "/phone_numbers", params={"filter[phone_number]": e164, "page[size]": 5})
        for r in doc.get("data") or []:
            if r.get("phone_number") == e164 and r.get("status") != "deleted":
                return r
        return None

    def campaign_assignment(self, e164: str) -> Optional[dict]:
        """The number's 10DLC assignment, or None when it has none."""
        for base in _CAMPAIGN_PATHS:
            try:
                return self.api.request("GET", f"{base}/{urllib.parse.quote(e164, safe='')}")
            except TelnyxError as exc:
                if exc.status == 404:
                    continue                  # no such assignment (or the other spelling of the path)
                raise
        return None

    # -- the checklist --------------------------------------------------------
    def status(self, loc: pd.Location, env: Mapping[str, str]) -> List[Step]:
        steps: List[Step] = []
        key = loc.inbound_env
        in_env = str(env.get(key, "")).strip()
        rows = self.owned(loc.id)
        if len(rows) > 1:
            return [Step("number", FAILED, f"{len(rows)} numbers carry the reference {loc.id}: " +
                         ", ".join(r.get("phone_number", "?") for r in rows), "release the extras in the Telnyx portal")]
        if not rows:
            steps.append(Step("number", TODO, "no Telnyx number is tagged for this location",
                              f"python3 provision.py plan --location {loc.id}"))
            steps.append(Step("env", DONE if in_env else TODO,
                              f"{key} is set to {in_env}" if in_env else f"{key} is not set",
                              "" if in_env else "set after the number is bought"))
            return steps
        rec = rows[0]
        e164 = rec.get("phone_number", "")
        steps.append(Step("number", DONE if rec.get("status") == "active" else WAITING,
                          f"{e164} ({rec.get('status')})", "re-run in a few minutes" if rec.get("status") != "active" else ""))
        if not self.s.connection_id:
            steps.append(Step("voice-connection", BLOCKED, "TELNYX_CONNECTION_ID is not set", "set it to the connection that routes to Inworld"))
        elif rec.get("connection_id") == self.s.connection_id:
            steps.append(Step("voice-connection", DONE, "routed to the Cherry voice connection"))
        else:
            steps.append(Step("voice-connection", TODO, f"routed to {rec.get('connection_id') or 'nothing'}", "provision.py apply fixes it"))
        if not self.s.messaging_profile_id:
            steps.append(Step("messaging-profile", BLOCKED, "TELNYX_MESSAGING_PROFILE is not set"))
        elif rec.get("messaging_profile_id") == self.s.messaging_profile_id:
            steps.append(Step("messaging-profile", DONE, "checkout texts go out through the Cherry messaging profile"))
        else:
            steps.append(Step("messaging-profile", TODO, f"profile is {rec.get('messaging_profile_id') or 'none'}", "provision.py apply fixes it"))
        if not self.s.campaign_id:
            steps.append(Step("10dlc", BLOCKED, "TELNYX_10DLC_CAMPAIGN_ID is not set"))
        else:
            a = self.campaign_assignment(e164)
            state = (a or {}).get("assignmentStatus")
            if state == "ASSIGNED":
                steps.append(Step("10dlc", DONE, "assigned to the campaign"))
            elif state in ("PENDING_ASSIGNMENT", "PENDING_UNASSIGNMENT"):
                steps.append(Step("10dlc", WAITING, f"{state.lower().replace('_', ' ')}: carriers take hours to propagate"))
            elif state and state.startswith("FAILED"):
                steps.append(Step("10dlc", FAILED, str((a or {}).get("failureReasons") or state), "fix the campaign, then re-run apply"))
            else:
                steps.append(Step("10dlc", TODO, "not assigned to the campaign", "provision.py apply does it"))
        if in_env == e164:
            steps.append(Step("env", DONE, f"{key} = {e164}"))
        elif in_env:
            steps.append(Step("env", FAILED, f"{key} is {in_env} but the Telnyx number is {e164}", "correct one of them"))
        else:
            steps.append(Step("env", TODO, f"{key} is not set", f"add {key}={e164} to the server's cherry.env (apply --env-file does it)"))
        if loc.pos_type == "square":
            tok = vault_secret(f"SQUARE_TOKEN_{loc.id.upper().replace('-', '_')}") or str(env.get(f"SQUARE_TOKEN_{loc.id.upper().replace('-', '_')}", ""))
            steps.append(Step("square", DONE if tok else TODO, "authorized" if tok else "the owner has not approved Cherry in Square",
                              "" if tok else f"python3 square_oauth.py authorize-url --restaurant {loc.id}"))
        return steps

    # -- doing ----------------------------------------------------------------
    def apply(self, loc: pd.Location, number: str, env: Mapping[str, str], *, yes: bool,
              env_file: str = "", replace_env: bool = False, skip_campaign: bool = False) -> List[Step]:
        if not yes:
            raise PermissionError("apply buys a phone number: pass --yes after reading `plan`")
        if not _E164.match(number or ""):
            raise ValueError(f"{number!r} is not an E.164 number")
        missing = [n for n, v in (("TELNYX_CONNECTION_ID", self.s.connection_id),
                                  ("TELNYX_MESSAGING_PROFILE", self.s.messaging_profile_id)) if not v]
        if not skip_campaign and not self.s.campaign_id:
            missing.append("TELNYX_10DLC_CAMPAIGN_ID")
        if missing:
            raise ValueError("not configured: " + ", ".join(missing))
        done: List[Step] = []

        # 1. the number — never bought twice
        rows = self.owned(loc.id)
        if len(rows) > 1:
            raise ValueError(f"{len(rows)} numbers already carry the reference {loc.id}; resolve that first")
        if rows:
            if rows[0].get("phone_number") != number:
                raise ValueError(f"{loc.id} already owns {rows[0].get('phone_number')}; refusing to buy {number}")
            rec = rows[0]
            done.append(Step("number", DONE, f"{number} is already this location's number; nothing bought"))
        else:
            if self.number_record(number) is not None:
                raise ValueError(f"{number} already exists on this Telnyx account and is not tagged for {loc.id}; refusing to take it over")
            # An order already in flight for this location (a previous run that timed out
            # waiting, or whose reply was lost) is waited for — never repeated.
            in_flight = [o for o in self.orders(loc.id) if o.get("status") == "pending"]
            if in_flight:
                ordered = [x.get("phone_number") for x in (in_flight[0].get("phone_numbers") or [])]
                if ordered and number not in ordered:
                    raise ValueError(f"{loc.id} already has an order pending for {', '.join(ordered)}; "
                                     f"wait for it (re-run with that number) instead of ordering {number}")
                oid, status = in_flight[0].get("id"), "pending"
                self.log(f"order {oid} for {loc.id} is already pending; waiting for it, not placing another")
            else:
                cand = next((c for c in self.search(area_code(number) or area_code(loc.fallback_phone), limit=50)
                             if c.number == number), None)
                if cand is None:
                    raise ValueError(f"{number} is not available any more (run `plan` again)")
                if cand.monthly_cents is None or cand.upfront_cents is None:
                    raise ValueError("Telnyx did not state this number's price; refusing to buy it")
                if cand.monthly_cents > self.s.max_monthly_cents or cand.upfront_cents > self.s.max_upfront_cents:
                    raise ValueError(f"{number} costs ${cand.upfront_cents / 100:.2f} up front and ${cand.monthly_cents / 100:.2f}/month, "
                                     f"over the caps (${self.s.max_upfront_cents / 100:.2f} / ${self.s.max_monthly_cents / 100:.2f})")
                body = {"phone_numbers": [{"phone_number": number}], "connection_id": self.s.connection_id,
                        "messaging_profile_id": self.s.messaging_profile_id, "customer_reference": loc.id}
                if self.s.billing_group_id:
                    body["billing_group_id"] = self.s.billing_group_id
                self.log(f"ordering {number} for {loc.id} (${cand.upfront_cents / 100:.2f} + ${cand.monthly_cents / 100:.2f}/month)")
                try:
                    order = self.api.request("POST", "/number_orders", body=body)
                    oid, status = (order.get("data") or {}).get("id"), (order.get("data") or {}).get("status")
                except TelnyxError as exc:
                    if not exc.ambiguous:
                        raise
                    # It may have gone through. Look; never re-send.
                    self.sleep(self.poll_seconds)
                    placed = [o for o in self.orders(loc.id) if o.get("status") in ("pending", "success")]
                    if self.number_record(number) is None and not placed:
                        raise TelnyxError(exc.status, "the order may or may not have been placed: check the Telnyx portal "
                                                      "before running apply again") from None
                    oid, status = (placed[0].get("id") if placed else None), (placed[0].get("status") if placed else "success")
            status = self._wait_for_order(oid, status) if oid else status
            if status == "failure":
                raise TelnyxError(None, f"Telnyx rejected the order for {number}")
            if status != "success":
                done.append(Step("number", WAITING, f"order {oid} is still pending", "re-run apply in a few minutes (it will not buy again)"))
                return done
            rec = self.number_record(number)
            if rec is None:
                done.append(Step("number", WAITING, "the order succeeded but the number is not listed yet", "re-run apply"))
                return done
            done.append(Step("number", DONE, f"bought {number}"))

        # 2. voice connection + tags (only what differs)
        patch = {}
        if rec.get("connection_id") != self.s.connection_id:
            patch["connection_id"] = self.s.connection_id
        if rec.get("customer_reference") != loc.id:
            patch["customer_reference"] = loc.id
        tags = sorted(set(rec.get("tags") or []) | {"cherry", loc.id})
        if tags != sorted(rec.get("tags") or []):
            patch["tags"] = tags
        if self.s.billing_group_id and rec.get("billing_group_id") != self.s.billing_group_id:
            patch["billing_group_id"] = self.s.billing_group_id
        if patch:
            self.api.request("PATCH", f"/phone_numbers/{rec['id']}", body=patch)
            done.append(Step("voice-connection", DONE, "routed and tagged: " + ", ".join(sorted(patch))))
        else:
            done.append(Step("voice-connection", DONE, "already routed and tagged"))

        # 3. messaging profile
        if rec.get("messaging_profile_id") != self.s.messaging_profile_id:
            self.api.request("PATCH", f"/messaging_phone_numbers/{urllib.parse.quote(number, safe='')}",
                             body={"messaging_profile_id": self.s.messaging_profile_id})
            done.append(Step("messaging-profile", DONE, "attached the messaging profile"))
        else:
            done.append(Step("messaging-profile", DONE, "messaging profile already attached"))

        # 4. 10DLC (needs the messaging profile first, per Telnyx)
        if skip_campaign:
            done.append(Step("10dlc", BLOCKED, "skipped (--skip-campaign)"))
        else:
            a = self.campaign_assignment(number)
            state = (a or {}).get("assignmentStatus")
            if state in ("ASSIGNED", "PENDING_ASSIGNMENT"):
                done.append(Step("10dlc", DONE if state == "ASSIGNED" else WAITING, state.lower().replace("_", " ")))
            else:
                last_err = None
                for base in _CAMPAIGN_PATHS:
                    try:
                        self.api.request("POST", base, body={"phoneNumber": number, "campaignId": self.s.campaign_id})
                        last_err = None
                        break
                    except TelnyxError as exc:
                        last_err = exc
                        if exc.status != 404:
                            break
                if last_err is not None:
                    done.append(Step("10dlc", FAILED, last_err.detail, "the number is bought and routed; fix the campaign and re-run apply"))
                else:
                    done.append(Step("10dlc", WAITING, "assignment requested: carriers take hours to propagate"))

        # 5. record the number where the server reads it
        if env_file:
            result = set_env_line(env_file, loc.inbound_env, number, replace=replace_env)
            done.append(Step("env", DONE, f"{loc.inbound_env} {result} in {env_file}"))
        else:
            done.append(Step("env", TODO, f"add {loc.inbound_env}={number} to the server's cherry.env", "or pass --env-file"))
        return done


# ---------------------------------------------------------------------------
# command line
# ---------------------------------------------------------------------------

_MARK = {DONE: "done   ", TODO: "todo   ", WAITING: "waiting", FAILED: "FAILED ", BLOCKED: "blocked"}


def _print_steps(loc: pd.Location, steps: List[Step]) -> None:
    print(f"\n{loc.name}  [{loc.id}]")
    for s in steps:
        print(f"  {_MARK[s.state]} {s.name}" + (f" — {s.detail}" if s.detail else ""))
        if s.fix and s.state != DONE:
            print(f"          fix: {s.fix}")


def _build(args, env: Mapping[str, str], opener=None) -> Provisioner:
    key = vault_secret("TELNYX_API_KEY") or str(env.get("TELNYX_API_KEY", ""))
    settings = Settings.from_env({**env, **{k: vault_secret(k) for k in
                                           ("TELNYX_CONNECTION_ID", "TELNYX_MESSAGING_PROFILE", "TELNYX_10DLC_CAMPAIGN_ID",
                                            "TELNYX_BILLING_GROUP_ID") if vault_secret(k)}})
    if getattr(args, "max_monthly_usd", None) is not None:
        settings.max_monthly_cents = int(Decimal(str(args.max_monthly_usd)) * 100)
    if getattr(args, "max_upfront_usd", None) is not None:
        settings.max_upfront_cents = int(Decimal(str(args.max_upfront_usd)) * 100)
    return Provisioner(TelnyxAPI(key, opener=opener), settings, log=lambda s: print(f"  · {s}", flush=True))


def main(argv: Optional[List[str]] = None, *, env: Optional[Mapping[str, str]] = None, opener=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--manifest", default=str(pd.DEFAULT_MANIFEST))
    sub = ap.add_subparsers(dest="cmd", required=True)
    st = sub.add_parser("status", help="read-only checklist")
    st.add_argument("--location", action="append", default=[])
    st.add_argument("--all", action="store_true")
    pl = sub.add_parser("plan", help="read-only: numbers you could buy and their cost")
    pl.add_argument("--location", required=True)
    pl.add_argument("--area-code", default="")
    pl.add_argument("--limit", type=int, default=5)
    ap_ = sub.add_parser("apply", help="BUYS the number and wires it up (idempotent)")
    ap_.add_argument("--location", required=True)
    ap_.add_argument("--number", required=True, help="the exact E.164 number from `plan`")
    ap_.add_argument("--yes", action="store_true", help="I read the cost and want to buy it")
    ap_.add_argument("--env-file", default="")
    ap_.add_argument("--replace-env", action="store_true")
    ap_.add_argument("--skip-campaign", action="store_true")
    ap_.add_argument("--max-monthly-usd", type=float, default=None)
    ap_.add_argument("--max-upfront-usd", type=float, default=None)
    args = ap.parse_args(argv)
    env = dict(os.environ if env is None else env)

    try:
        locations = pd.load_manifest(Path(args.manifest))
        if args.cmd == "status":
            locations = locations if (args.all or not args.location) else pd.selected(locations, args.location)
        else:
            locations = pd.selected(locations, [args.location])
        prov = _build(args, env, opener)
        if args.cmd == "plan":
            loc = locations[0]
            area = args.area_code or area_code(loc.fallback_phone)
            if not area:
                print(f"no area code for {loc.id}: pass --area-code")
                return 2
            cands = prov.search(area, limit=args.limit)
            print(f"\nNumbers available in {area} for {loc.name}:")
            for c in cands:
                cost = (f"${c.upfront_cents / 100:.2f} up front + ${c.monthly_cents / 100:.2f}/month"
                        if c.monthly_cents is not None and c.upfront_cents is not None else "price not stated")
                print(f"  {c.number}  {cost}  {c.region}{'  (best-effort match)' if c.best_effort else ''}")
            if not cands:
                print("  none: try another area code")
            print(f"\nNothing was bought. To buy one:\n  python3 provision.py apply --location {loc.id} --number <one above> --yes --env-file <cherry.env>")
            return 0
        if args.cmd == "status":
            worst = 0
            for loc in locations:
                steps = prov.status(loc, env)
                _print_steps(loc, steps)
                if any(s.state != DONE for s in steps):
                    worst = 3
            return worst
        loc = locations[0]
        steps = prov.apply(loc, args.number, env, yes=args.yes, env_file=args.env_file,
                           replace_env=args.replace_env, skip_campaign=args.skip_campaign)
        _print_steps(loc, steps)
        print(f"\nNext: python3 pilot_deploy.py apply --only {loc.id} --db <db>   (reads {loc.inbound_env} from the environment)")
        return 0 if all(s.state == DONE for s in steps) else 3
    except (ValueError, PermissionError, TelnyxError) as exc:
        print(f"provision: {exc}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
