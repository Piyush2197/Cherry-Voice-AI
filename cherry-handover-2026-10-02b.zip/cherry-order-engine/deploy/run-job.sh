#!/usr/bin/env bash
# Run one Cherry job with the service environment; page the owner if it fails.
#   run-job.sh <job-name> <command...>
set -uo pipefail
[ $# -ge 2 ] || { echo "usage: run-job.sh <job-name> <command...>" >&2; exit 2; }
name="$1"; shift
# Parse the env file the way systemd's EnvironmentFile does (KEY=value taken
# literally). `source` would run it as shell, so a database password or secret
# containing $, &, ; or a space works for the server and silently breaks here.
while IFS= read -r line || [ -n "$line" ]; do
  case "$line" in ''|\#*) continue ;; esac
  key="${line%%=*}"; val="${line#*=}"
  [[ "$key" =~ ^[A-Za-z_][A-Za-z0-9_]*$ ]] || continue
  case "$val" in
    \"*\") val="${val#\"}"; val="${val%\"}" ;;
    \'*\') val="${val#\'}"; val="${val%\'}" ;;
  esac
  export "$key=$val"
done < /etc/cherry/cherry.env
cd /opt/cherry
"$@"; code=$?
if [ "$code" -ne 0 ]; then
  echo "$(date -Is) job $name failed with exit $code" >&2
  /opt/cherry/.venv/bin/python deploy/job_failed.py "$name" "$code" || true
fi
exit "$code"
