#!/usr/bin/env python3
"""AI incident assistant safety and escalation checks."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

import ai_ops_assistant as assistant
from order_store import OrderStore


def fixture():
    store = OrderStore.sqlite()
    store.upsert_restaurant("r", "Restaurant", "test", active=True)
    store.conn.execute("""INSERT INTO menu_version
      (restaurant_id,version,yaml,yaml_sha256,item_count,published_at,is_live)
      VALUES ('r',1,'x','x',1,CURRENT_TIMESTAMP,1)""")
    store.conn.commit()
    return store


def main():
    passed = 0
    now = datetime(2026, 9, 21, 20, 0, tzinfo=timezone.utc)
    store = fixture()
    sid = store.start_session("r", 1, external_id="stuck")
    store.conn.execute("UPDATE session SET started_at=? WHERE id=?",
                       ((now - timedelta(hours=3)).isoformat(), sid))
    store.conn.commit()
    report = assistant.triage(store, now=now, apply_safe_fixes=True)
    case = report["incidents"][0]
    assert case["auto_resolved"] and case["owner"] == "resolved_automatically"; passed += 1
    assert store.conn.execute("SELECT end_reason FROM session WHERE id=?", (sid,)).fetchone()["end_reason"] == "timed_out"; passed += 1

    persistent = fixture()
    persistent.log_sms("+13135550123", "failed", "confirmation",
                       restaurant_id="r", status="failed",
                       error_detail="carrier unavailable")
    first = assistant.triage(persistent, now=now)["incidents"][0]
    second = assistant.triage(persistent, now=now)["incidents"][0]
    third = assistant.triage(persistent, now=now)["incidents"][0]
    assert first["owner"] == "ai_monitor" and not first["persistent"]; passed += 1
    assert second["occurrence_in_7_days"] == 2; passed += 1
    assert third["owner"] == "main_developer" and third["persistent"]; passed += 1
    encoded = str(third)
    assert "+13135550123" not in encoded and "transcript" not in third["facts"]; passed += 1
    assert any("Do not place" in x for x in third["assistant_guardrails"]); passed += 1
    print(f"{passed} passed, 0 failed (AI operations assistant)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
