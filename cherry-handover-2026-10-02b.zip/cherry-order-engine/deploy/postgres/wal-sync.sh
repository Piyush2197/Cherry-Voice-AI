#!/usr/bin/env bash
# Every 5 minutes: copy newly archived WAL off the server, so losing the VPS
# costs at most a few minutes of orders.
set -euo pipefail
cd "$(dirname "$0")"
[ -f /etc/cherry/offsite.env ] && . /etc/cherry/offsite.env
: "${OFFSITE:?set OFFSITE to an rclone remote path}"
rclone copy ./wal-archive "$OFFSITE/wal-archive"
