#!/usr/bin/env python3
"""Read-only deployment smoke test for Cherry's multi-location pilot.

This proves database routing, manifest fallbacks, live menu identity, pricing,
and (optionally) the running server's health/tool contract. It never places an
order, sends a text, or calls a restaurant.
"""

from __future__ import annotations

import argparse
import json
import os
import urllib.error
import urllib.request
from pathlib import Path
from typing import Dict, List, Optional

from agent_api import CallSession
from order_store import OrderStore
import pilot_deploy as pd


def _sample_call(cfg) -> Dict:
    """Add one unambiguous item and price it without persisting an order."""
    for item in cfg.items:
        if not item.available or item.has_sizes or item.base_price_cents <= 0:
            continue
        required = []
        for gid in item.modifier_group_ids:
            group = cfg.group(gid)
            if group and not group.informational and group.min_select > 0:
                required.append(gid)
        if required:
            continue
        call = CallSession(cfg)
        result = call.add_item(item.name)
        if result["ok"] and result["order"]["lines"]:
            return {"item": item.name,
                    "total_cents": result["order"]["total_cents"],
                    "say": call.read_back()["say"]}
    raise RuntimeError(f"{cfg.id} has no simple priced smoke-test item")


def _http_json(url: str, key: str = "") -> Dict:
    request = urllib.request.Request(url)
    if key:
        request.add_header("X-Cherry-Key", key)
    try:
        with urllib.request.urlopen(request, timeout=8) as response:
            data = json.loads(response.read())
            if response.status >= 400:
                raise RuntimeError(f"HTTP {response.status}: {data}")
            return data
    except urllib.error.HTTPError as exc:
        raise RuntimeError(f"HTTP {exc.code}: {exc.read().decode()}") from exc


def run(locations: List[pd.Location], db: str, env: Dict[str, str], *,
        base_url: str = "", api_key: str = "") -> int:
    if pd.verify(locations, db, env) != 0:
        print("SMOKE BLOCKED: deployment verification failed")
        return 2

    store = OrderStore.open(db)
    for loc in locations:
        cfg, _ = store.load_live_config(loc.id)
        sample = _sample_call(cfg)
        print(f"PASS {loc.id}: priced {sample['item']} at "
              f"{sample['total_cents']} cents; read-back is speakable")

    if base_url:
        base = base_url.rstrip("/")
        health = _http_json(f"{base}/health")
        if not health.get("ok") or health.get("database") != "ok":
            print(f"FAIL server health: {health}")
            return 2
        # Compare against this checkout's own tool list, not a number: a
        # hard-coded count went stale the day a tool was added and would have
        # failed the go-live smoke test against a correct server.
        from server import TOOL_NAMES
        tools = _http_json(f"{base}/v1/tools", api_key).get("tools")
        got = ({t.get("name") for t in tools if isinstance(t, dict)}
               if isinstance(tools, list) else set())
        if got != TOOL_NAMES:
            print("FAIL server tool contract differs from this checkout: "
                  f"missing {sorted(TOOL_NAMES - got)}, "
                  f"unexpected {sorted(got - TOOL_NAMES)}")
            return 2
        print(f"PASS running server: database healthy and all "
              f"{len(TOOL_NAMES)} tools exposed")

    print("SMOKE PASS: no order, text, payment, or phone call was created")
    return 0


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, default=pd.DEFAULT_MANIFEST)
    parser.add_argument("--db", default=os.getenv("CHERRY_DATABASE_URL", "cherry.db"))
    parser.add_argument("--only", action="append", default=[])
    parser.add_argument("--base-url", default="",
                        help="optional running Cherry URL, e.g. http://localhost:8080")
    parser.add_argument("--api-key", default=os.getenv("CHERRY_API_KEY", ""))
    args = parser.parse_args(argv)
    try:
        locations = pd.selected(pd.load_manifest(args.manifest), args.only)
    except ValueError as exc:
        parser.error(str(exc))
    return run(locations, args.db, dict(os.environ), base_url=args.base_url,
               api_key=args.api_key)


if __name__ == "__main__":
    raise SystemExit(main())
