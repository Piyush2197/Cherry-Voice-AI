# Menu enrichment — allergen, dietary and description data (2026-09-30)

**Status: the prerequisite is built. It ships with no facts in it, on purpose.**

`QR_CHANNEL.md` (revision 2026-09-29) names menu enrichment as the hard
prerequisite for the counter QR agent, and `DEVELOPER_BEFORE_POS_API_2026-09-28.md`
lists it as the thing that blocks the QR build. This is that piece: the places
in the menu file where an owner writes down allergens, dietary facts and
descriptions, the validation that keeps those values honest, the search the
agent runs over them, and the coverage report that tells an owner what is still
blank.

## Why it was missing

The facts existed, but as a trick. `build_pink_garlic.py` appends
`vegan <dish>` to an item's **aliases** whenever Square's raw name carried
`(Vegan)`, with a comment explaining exactly why:

> The vegan/vegetarian fact is real and worth keeping, but it belongs in an
> alias so a caller can **ask for** vegan dishes — not in the sentence Lily
> reads back.

An alias is a search handle, not an attribute. It lets a caller say "vegan
chana masala"; it cannot answer "what do you have that's vegan?", and it exists
for one restaurant because a build script put it there. The agent needs the
fact as data.

## The one rule

> **A declared tag is a fact the owner wrote down. A missing tag is silence.
> Cherry never turns silence into an answer.**

Every answer this layer produces is one of two shapes:

| Situation | What the agent says |
| --- | --- |
| the owner declared it | *"Yes — the menu lists milk in Butter Chicken."* |
| nobody declared it | *"I can't confirm that Plain Rice is free of milk — it isn't in the notes I have. Please ask at the counter."* |

There is deliberately **no `is_gluten_free() -> bool`**. Such a function has to
return `False` for an item nobody has reviewed, and `False` reads as *safe*.
The answer layer returns sentences, so "unknown" cannot be mistaken for "no".
`test_menu_enrichment.py` asserts those booleans do not exist.

## What went into the menu file

```yaml
items:
  - id: pg_butter_chicken
    name: Butter Chicken (Creamy)
    price: '16.99'
    description: Tomato and cream sauce, mild.          # the owner's words
    allergens: [milk]                                   # canonical ids
    dietary: []                                         # positive suits only
options:
  - id: pg_extra_cheese
    name: Extra Cheese
    description: Melts over the top.
    price: '2.00'
```

`description` may be quoted to a guest verbatim. It is never paraphrased into a
claim the owner did not make.

## Vocabulary

Two closed lists, in `menu_enrichment.py`. Owners may write the aliases;
anything else is **rejected at load**, not stored. A stored typo is a fact the
agent would repeat.

- **Allergens (16):** the US Big 9 — `milk, eggs, fish, shellfish, tree_nuts,
  peanuts, wheat, soy, sesame` — plus `gluten, sulfites, corn, mustard, celery,
  lupin, molluscs`.
- **Dietary (13):** `vegetarian, vegan, pescatarian, halal, kosher,
  gluten_free, dairy_free, nut_free, peanut_free, egg_free, soy_free,
  shellfish_free, sesame_free`.

Run `python menu_enrichment.py vocabulary` for the labels and accepted
spellings.

**Ambiguity is rejected, never guessed.** `nuts` could mean tree nuts or
peanuts; telling a peanut-allergic guest the wrong one is the failure this
whole module exists to prevent, so `nuts` is an error with a message saying to
write the one the owner means. Same for `seafood` (fish or shellfish?).

## Contradictions block the config

An item tagged `vegan` that also declares `milk` is a data-entry error that
would make the agent lie to whichever guest asked second. `contradictions()`
catches ten such pairs (vegan/vegetarian/pescatarian against animal allergens,
and each `*_free` tag against its own allergen). In the menu file it is a
**schema error**, so the menu does not load; `menu_enrichment.py check` reports
it and exits non-zero.

## The owner's worklist

```bash
python menu_enrichment.py report --menus menus              # human table
python menu_enrichment.py report --menus menus --json       # for a tool
python menu_enrichment.py check  --menus menus              # contradictions
```

`report` prints, per restaurant, how many items carry a description, allergens
and dietary tags, then the specific items still missing them. **All 19 shipped
menus are currently at zero** — that number is the honest state of the data and
the size of the owner conversation, not a defect in the code.

## What this deliberately does not do

- **It does not fill anything in.** Not one allergen or dietary tag was added
  to any shipped menu. Auto-filling from dish names ("Paneer" → milk) is
  inference, and the product rule is that Cherry never invents menu knowledge.
  The owner supplies the facts; this gives them somewhere to put them and a
  list of what is missing.
- **It does not lift Pink Garlic's alias hack into real tags.** The source
  (Square's raw `(Vegan)` suffix) is real, but promoting a heuristic in a build
  script into assertions about food safety deserves its own review, on its own
  change, with the owner's confirmation. It is the obvious first migration and
  it is called out in `TASKS.md`.
- **It is not the QR agent.** This is the prerequisite. The QR agent is still
  sequenced behind the Square bridge and the first pilots.

## For the voice agent today

Nothing reads these fields on a call yet — wiring an `allergen`/`dietary` tool
into `agent_api.py` is a separate, small change and is listed in `TASKS.md`.
The runtime path is already correct: `pilot_deploy.py` publishes the menu YAML
into the `menu_version` row, and `order_store.load_live_config()` rebuilds it
through `menu_schema.build_config()`, so enrichment reaches a live call as soon
as it is written down. `test_menu_enrichment.py` proves that round-trip,
including that marking an item sold out does not drop its allergens.
