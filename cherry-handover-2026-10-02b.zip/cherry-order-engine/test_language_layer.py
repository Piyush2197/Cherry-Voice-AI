#!/usr/bin/env python3
"""The language layer — how callers actually talk.

The engine's moat is deterministic food logic, but the words AROUND the food
are loose speech: wrappers ("can I get a", "I'll do the", "let me get"),
negations ("no", "without", "hold the", "sin cebolla"), plural dishes named
for counts ("2 Papadam", "21 Shrimp"), and bare family words ("a shake" at a
place with five flavors). This suite pins that layer across the real menus:

  * a wrapper phrase must never change WHAT is ordered, HOW MANY, or turn a
    clear order into a clarifying question;
  * wrapper speech must never break the under-specification floor — "give me
    the saag" asks Chicken or Lamb/Goat exactly like bare "saag";
  * menu-vocab words survive their own menus ("mac and cheese", "make it
    veggie", "the naked", "make it a combo");
  * a number-named dish said verbatim orders ONE; "two <name>" orders two;
  * a bare family word asks which one; a flavor phrase is decisive;
  * negation reads the same in English and Spanish.
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional, Tuple

import agent_api
import menu_schema as ms
import order_engine

MENUS = Path(__file__).parent / "menus"

_passed, _failed = 0, 0


def check(name: str, cond: bool, detail: str = "") -> None:
    global _passed, _failed
    if cond:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail[:260]}" if detail else ""))


def sess(stem: str) -> agent_api.CallSession:
    return agent_api.CallSession(ms.load_yaml(MENUS / f"{stem}.yaml"))


def outcome(s: agent_api.CallSession, phrase: str) -> Tuple[Optional[str],
                                                            Optional[int], bool]:
    """(item_id, quantity, asked) after add_item."""
    r = s.add_item(text=phrase)
    ls = (r.get("order") or {}).get("lines") or []
    asked = r.get("ok") is False and not ls
    return (ls[0]["item_id"] if ls else None,
            ls[0]["quantity"] if ls else None, asked)


def t_wrapper_phrases_never_change_the_order() -> None:
    """'can I get a X', 'I'll do the X', 'let me get N X', 'how about the X'."""
    cases = [
        ("bun-n-run-ferndale", "can I get a double cheeseburger",
         "double_cheeseburger", 1),
        ("bun-n-run-ferndale", "I'll do the single cheeseburger combo",
         "single_cheeseburger_combo", 1),
        ("bun-n-run-ferndale", "let me get two cokes", "coke", 2),
        ("bun-n-run-ferndale", "can I get two waters", "water", 2),
        ("bun-n-run-ferndale", "I'll take three shakes", "fresh_shake", 3),
        ("bun-n-run-ferndale", "let me get a hamburger", "hamburger", 1),
        ("bun-n-run-ferndale", "how about the veggie burger",
         "veggie_burger", 1),
        ("bun-n-run-ferndale", "I want a hamburger", "hamburger", 1),
        ("bun-n-run-ferndale", "I'll take a water", "water", 1),
        ("bun-n-run-ferndale", "could I have the wild fries",
         "wild_fries", 1),
        ("bun-n-run-ferndale", "hook me up with a shake", "fresh_shake", 1),
        ("burger_template", "let me do a double cheeseburger",
         "double_cheeseburger", 1),
        ("naked-burger-detroit", "can I do the korean chicken",
         "korean_fried_chicken_bites", 1),
        ("naked-burger-detroit", "give me the mac and cheese",
         "mac_and_cheese", 1),
    ]
    for stem, phrase, item, qty in cases:
        got_i, got_q, asked = outcome(sess(stem), phrase)
        check(f"{stem}: {phrase!r} -> {item} x{qty}",
              got_i == item and got_q == qty and not asked,
              f"got {got_i} x{got_q} asked={asked}")


def t_wrappers_preserve_the_underSpecification_floor() -> None:
    """'give me the saag' must ask Chicken or Lamb/Goat like bare 'saag'."""
    for phrase in ("saag", "give me the saag", "one saag please",
                   "let me get the saag"):
        got_i, got_q, asked = outcome(sess("pink-garlic-oak-park"), phrase)
        check(f"PG: {phrase!r} asks which saag",
              asked and got_i is None, f"got {got_i} ({phrase})")
    # and a wrapped exact dish still lands
    got_i, _, asked = outcome(sess("pink-garlic-oak-park"),
                              "let me get the chicken korma")
    check("PG: 'let me get the chicken korma' is decisive",
          got_i == "pg_chk_korma_creamy" and not asked, f"{got_i}")


def t_number_named_dishes_still_order_one() -> None:
    """'2 Papadam and Chutney' spoken plainly is ONE; 'two papadams' is TWO."""
    cases = [
        ("pink-garlic-oak-park", "2 Papadam and Chutney", 1),
        ("pink-garlic-oak-park", "give me the 2 papadam and chutney", 1),
        ("pink-garlic-oak-park", "can I get two papadams", 2),
        ("pink-garlic-oak-park", "one papadum please", 1),
        ("pink-garlic-allen-park", "let me get two papadums", 2),
        ("pink-garlic-shelby", "can I have the papadam", 1),
        ("juan-miguels-clinton", "21 Shrimp", 1),
        ("juan-miguels-clinton", "can I get the 21 shrimp", 1),
        ("juan-miguels-clinton", "let me get two 21 shrimps", 2),
        ("juan-miguels-clinton", "three shrimps", 3),
    ]
    for stem, phrase, qty in cases:
        got_i, got_q, asked = outcome(sess(stem), phrase)
        check(f"{stem}: {phrase!r} -> qty {qty}",
              got_q == qty and not asked, f"got {got_i} x{got_q}")


def t_bare_family_word_asks_flavor_is_decisive() -> None:
    """Naked Burger has five milkshakes: 'shake' asks, 'chocolate milkshake'
    doesn't — even wrapped ('and a chocolate milkshake')."""
    cfg_stem = "naked-burger-detroit"
    for phrase in ("shake", "milkshake", "two shakes", "let me get two shakes"):
        got_i, got_q, asked = outcome(sess(cfg_stem), phrase)
        check(f"naked: {phrase!r} asks which shake", asked, f"got {got_i}")
    for phrase, want in (("a vanilla shake", "vanilla_milkshake"),
                         ("chocolate milkshake", "chocolate_milkshake"),
                         ("and a chocolate milkshake", "chocolate_milkshake"),
                         ("strawberry shake", "strawberry_milkshake"),
                         ("oreo shake", "cookies_n_creme_milkshake"),
                         ("pistachio shake", "pistachio_olive_oil_milkshake")):
        got_i, _, asked = outcome(sess(cfg_stem), phrase)
        check(f"naked: {phrase!r} -> {want}",
              got_i == want and not asked, f"got {got_i}")


def t_negation_reads_the_same_in_two_languages() -> None:
    """no / without / hold the / skip the / leave off / sin — all 'no onion'."""
    for phrase in ("no onion", "without onion", "hold the onion",
                   "skip the onion", "leave off the onion", "sin cebolla"):
        s = sess("bun-n-run-ferndale")
        s.add_item(text="double cheeseburger combo")
        s.add_modifier(text="Coke")
        r = s.remove_modifier(text=phrase)
        snap = s.snapshot()
        removed = [d for l in snap.get("lines", [])
                   for d in l.get("removed_defaults", [])]
        check(f"negation {phrase!r} removes onion",
              r.get("ok") and "Onion" in removed, f"removed={removed}")


def t_menu_vocab_survives_its_own_menu() -> None:
    """Words that are fillers elsewhere are dish words here, and stay so."""
    s = sess("naked-burger-detroit")
    r = s.add_item(text="mac and cheese")
    ls = (r.get("order") or {}).get("lines") or []
    check("naked: 'mac and cheese' still the dish",
          bool(ls) and ls[0]["item_id"] == "mac_and_cheese", str(r.get("say")))
    for phrase in ("make it veggie", "go veggie"):
        s = sess("naked-burger-detroit")
        s.add_item(text="naked burger")
        s.answer(text="Naked Fries")
        r = s.add_modifier(text=phrase)
        snap = s.snapshot()
        mods = [m.get("option_name") for l in snap.get("lines", [])
                for m in l.get("modifiers", [])]
        check(f"naked: {phrase!r} still swaps the patty",
              r.get("ok") and "Falafel Patty Swap" in mods, f"mods={mods}")
    s = sess("burger_template")
    s.add_item(text="single cheeseburger")
    r = s.add_modifier(text="make it a combo")
    check("template: 'make it a combo' still upgrades",
          r.get("ok") and "combo" in r.get("say", "").lower(), str(r.get("say")))


def t_wrapped_exact_names_score_exact() -> None:
    """The tail rule: '…and a chocolate milkshake' is an EXACT call, not a
    containment score that a 1-token alias can tie."""
    m = order_engine
    # rebuild the matcher through a session to use the real menu pool
    s = sess("naked-burger-detroit")
    matcher = s.e.matcher
    cands = matcher.match_items("and a chocolate milkshake")
    check("tail-exact: 'and a chocolate milkshake' scores 1.0",
          cands and cands[0].score >= 1.0
          and cands[0].target_id == "chocolate_milkshake",
          str([(c.target_id, round(c.score, 3)) for c in cands[:3]]))
    check("tail-exact: it is decisive, not a question",
          matcher.is_decisive(cands), str(len(cands)))


def t_quantity_after_wrapper_speech() -> None:
    """parse_quantity skips leading fillers — but stays head-only."""
    pq = order_engine.parse_quantity
    cases = [("let me get two cokes", 2), ("can I have three samosas", 3),
             ("give me a coke", 1), ("I'll take 4 waters", 4),
             ("two cokes", 2), ("a couple of fries", 2),
             ("number 3 combo", 1), ("combo number two", 1)]
    for phrase, want in cases:
        got = pq(phrase)
        check(f"parse_quantity {phrase!r} -> {want}", got == want, str(got))


def main() -> None:
    batteries = [
        t_wrapper_phrases_never_change_the_order,
        t_wrappers_preserve_the_underSpecification_floor,
        t_number_named_dishes_still_order_one,
        t_bare_family_word_asks_flavor_is_decisive,
        t_negation_reads_the_same_in_two_languages,
        t_menu_vocab_survives_its_own_menu,
        t_wrapped_exact_names_score_exact,
        t_quantity_after_wrapper_speech,
    ]
    for fn in batteries:
        print(f"== {fn.__name__}")
        fn()
    print(f"\n{_passed} passed, {_failed} failed")


if __name__ == "__main__":
    main()
