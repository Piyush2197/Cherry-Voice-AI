#!/usr/bin/env python3
"""Menu enrichment: vocabulary, validation, round-trip, and the answer rule."""
from __future__ import annotations

import _ensure_deps  # noqa: F401  (re-runs under .venv, or says how to install, if PyYAML is missing)
import json
import tempfile
from pathlib import Path

import yaml

import menu_enrichment as me
import menu_schema as ms


def doc(items, options=None):
    d = {"restaurant": {"id": "t", "name": "Test Kitchen", "cuisine": "test"},
         "items": items}
    if options:
        d["options"] = options
    return d


def item(iid, name, **kw):
    return {"id": iid, "name": name, "price": "9.00", **kw}


def problems_of(d):
    try:
        ms.build_config(d)
    except ms.SchemaError as exc:
        return "\n".join(exc.problems)
    return ""


def main():
    passed = 0
    fails = []

    def check(cond, why):
        nonlocal passed
        if cond:
            passed += 1
        else:
            fails.append(why)

    # --- vocabulary -----------------------------------------------------
    check(me.normalize_allergen("Dairy") == "milk", "case/alias -> milk")
    check(me.normalize_allergen("tree nuts") == "tree_nuts", "spaced alias")
    check(me.normalize_allergen("gluten-free") is None,
          "a dietary alias must not resolve as an allergen")
    check(me.normalize_dietary("plant-based") == "vegan", "dietary alias")
    check(me.normalize_dietary("GF") == "gluten_free", "initialism")
    check(me.normalize_allergen("peanut butter") is None,
          "a dish name is not an allergen")
    check(me.normalize_allergen("nuts") is None, "ambiguous is rejected")
    check(me.normalize_dietary("seafood") is None, "seafood is ambiguous")
    check(me.allergen_label("tree_nuts") == "tree nuts", "label lookup")

    # --- schema: accepts and normalises --------------------------------
    d = doc([item("i1", "Paneer Tikka",
                  description="Charred paneer with peppers",
                  allergens=["Dairy", "tree nuts"], dietary=["Vegetarian"]),
             item("i2", "Dal", dietary=["vegan", "plant-based"]),
             item("i3", "Plain Rice")],
            options=[{"id": "o1", "name": "Cheese", "price": "1.00",
                      "description": "Melty mozzarella"}])
    check(problems_of(d) == "", "a valid enriched menu has no problems")
    cfg = ms.build_config(d)
    check(cfg.item("i1").allergens == ("milk", "tree_nuts"),
          "allergens canonicalised in order")
    check(cfg.item("i1").dietary == ("vegetarian",), "dietary canonicalised")
    check(cfg.item("i1").description == "Charred paneer with peppers",
          "item description carried")
    check(cfg.item("i2").dietary == ("vegan",),
          "two spellings of one tag collapse to one")
    check(cfg.option("o1").description == "Melty mozzarella",
          "option description carried")
    check(cfg.item("i3").allergens == () and cfg.item("i3").dietary == (),
          "an unenriched item is empty, not populated with guesses")

    # --- schema: round-trip --------------------------------------------
    check(ms.configs_equal(cfg, ms.build_config(ms.to_doc(cfg))) == [],
          "enrichment survives YAML round-trip")
    check("allergens" in json.dumps(ms.to_doc(cfg)),
          "to_doc emits the enrichment keys")
    dashed = ms.to_doc(cfg)
    check("dietary" in dashed["items"][0], "dietary emitted")

    # --- schema: rejections --------------------------------------------
    check("unknown value" in problems_of(doc([item("i", "X",
          allergens=["peanut butter"])])), "unknown allergen rejected")
    check("ambiguous" in problems_of(doc([item("i", "X",
          allergens=["nuts"])])), "ambiguous allergen rejected with reason")
    check("expected a list" in problems_of(doc([item("i", "X",
          allergens="milk")])), "scalar instead of list is told how to fix it")
    check("expected text" in problems_of(doc([item("i", "X",
          description=5)])), "non-text description rejected")
    check("declared vegan" in problems_of(doc([item("i", "X",
          allergens=["milk"], dietary=["vegan"])])),
          "vegan + milk is a blocking error")
    check("declared vegetarian" in problems_of(doc([item("i", "X",
          allergens=["fish"], dietary=["vegetarian"])])),
          "vegetarian + fish is a blocking error")
    check(problems_of(doc([item("i", "X", allergens=["milk"],
                                dietary=["vegetarian"])])) == "",
          "milk + vegetarian is legal")
    check(problems_of(doc([item("i", "X", allergens=["gluten"],
                                dietary=["gluten_free"])])) != "",
          "gluten + gluten_free is a contradiction")

    # --- the answer rule: never a denial -------------------------------
    yes_allergen = me.allergen_answer(cfg, "i1", "milk")
    check("lists milk" in yes_allergen, "declared allergen is stated")
    unknown_allergen = me.allergen_answer(cfg, "i3", "milk")
    check(me.ASK_AT_COUNTER in unknown_allergen,
          "undeclared allergen refers to the counter")
    check("free of" in unknown_allergen and "can't confirm" in unknown_allergen,
          "undeclared allergen is never a denial")
    check(me.allergen_answer(cfg, "i3", "nuts").endswith(me.ASK_AT_COUNTER) and
          me.allergen_answer(cfg, "i3", "tree_nuts").endswith(me.ASK_AT_COUNTER),
          "an ambiguous ask and an unlisted one both refer to the counter")
    check(not me.allergen_answer(cfg, "i3", "nuts").startswith("Yes"),
          "an ambiguous ask is never answered as a confirmation")
    check(me.dietary_answer(cfg, "i2", "vegan").startswith("Yes"),
          "declared diet is a yes")
    unknown_diet = me.dietary_answer(cfg, "i3", "vegan")
    check("won't guess" in unknown_diet and me.ASK_AT_COUNTER in unknown_diet,
          "undeclared diet refuses to guess")

    # No boolean API can exist, because a boolean has to answer "False" for an
    # item nobody reviewed, and False reads as safe.
    check(not hasattr(me, "is_gluten_free") and
          not hasattr(me, "is_vegan") and
          not hasattr(me, "contains"),
          "there is deliberately no boolean allergen/diet predicate")

    # --- search is over declarations only ------------------------------
    check(me.items_with_dietary(cfg, "vegan") == ["i2"],
          "dietary search returns declared items only")
    check(me.items_with_dietary(cfg, "vegetarian") == ["i1"],
          "vegan does not imply vegetarian in the search")
    check(me.items_with_dietary(cfg, "nonsense") == [],
          "unknown tag searches nothing rather than everything")
    check(me.items_with_allergen(cfg, "tree_nuts") == ["i1"],
          "allergen search returns declared items")
    check(me.items_with_allergen(cfg, "wheat") == [],
          "an undeclared allergen matches no item, not all of them")

    # --- descriptions are quotable, never invented ---------------------
    check(me.describe_item(cfg, "i1") == "Charred paneer with peppers",
          "description returned verbatim")
    check(me.describe_item(cfg, "i3") == "",
          "missing description is empty, so the agent cannot make one up")

    # --- coverage ------------------------------------------------------
    cov = me.coverage(cfg)
    check(cov.counts["items"] == 3, "coverage counts items")
    check(cov.counts["with_dietary"] == 2, "coverage counts dietary")
    check(cov.counts["with_allergens"] == 1, "coverage counts allergens")
    check([g.item_id for g in cov.gaps] == ["i2", "i3"],
          "every partially enriched item is a gap")
    i3_gap = [g for g in cov.gaps if g.item_id == "i3"][0]
    check(i3_gap.missing == ("description", "allergens", "dietary"),
          "the gap names every missing field")
    check([g for g in cov.gaps if g.item_id == "i2"][0].missing ==
          ("description", "allergens"),
          "a gap lists only what is actually missing")
    check(cov.items[0].complete, "a fully enriched item is complete")
    check(cov.as_dict()["counts"]["complete"] == 1, "as_dict carries counts")
    check(cov.as_dict()["gaps"][0]["item_id"] == "i2",
          "as_dict lists the worklist")

    # A contradiction is surfaced per item, and blocks `check`.
    contra = {"restaurant": {"id": "t", "name": "T", "cuisine": "t"},
              "items": [{"id": "i", "name": "X", "price": "5.00",
                         "allergens": ["milk"], "dietary": ["vegan"]}]}
    check("declared vegan" in problems_of(contra),
          "contradiction blocks the config at load")

    # --- CLI -----------------------------------------------------------
    import contextlib
    import io

    def run_cli(argv):
        with contextlib.redirect_stdout(io.StringIO()):
            return me.main(argv)

    with tempfile.TemporaryDirectory() as td:
        menus = Path(td) / "menus"
        menus.mkdir()
        (menus / "ok.yaml").write_text(yaml.safe_dump(d))
        check(run_cli(["check", "--menus", str(menus)]) == 0,
              "check passes a consistent menu set")
        check(run_cli(["report", "--menus", str(menus)]) == 0,
              "report runs over a menu set")
        check(run_cli(["vocabulary"]) == 0, "vocabulary prints")
        check(run_cli(["report", "--menus", str(menus), "--json"]) == 0,
              "report --json runs")
        check(run_cli(["check", "--menus", str(menus),
                       "--restaurant", "t"]) == 0, "restaurant filter")
        (menus / "bad.yaml").write_text(yaml.safe_dump({"restaurant": {
            "id": "b", "name": "B", "cuisine": "b"}, "items": [
            {"id": "i", "name": "X", "price": "5.00",
             "allergens": ["milk"], "dietary": ["vegan"]}]}))
        check(run_cli(["check", "--menus", str(menus)]) == 1,
              "check fails a contradictory menu set")

    # --- the real menus still load -------------------------------------
    real = ms.load_all("menus")
    check(len(real) >= 19, "every shipped menu still loads")
    check(me.coverage(real["pink-garlic-oak-park"]).counts["items"] > 0,
          "coverage runs on a shipped menu")

    # --- integration: enrichment survives the store and a live load -----
    # The runtime never reads the YAML file; it reads the menu_version row that
    # pilot_deploy published, then applies tonight's 86s. If enrichment did not
    # survive that round-trip, the agent would answer "ask at the counter" for
    # data the owner had actually supplied.
    from order_store import OrderStore
    from restaurants import apply_availability

    store = OrderStore.sqlite()
    store.upsert_restaurant("t", "Test Kitchen", "test", active=True)
    store.publish_menu("t", yaml.safe_dump(d), item_count=len(d["items"]))
    live, _ = store.load_live_config("t")
    check(live.item("i1").allergens == ("milk", "tree_nuts"),
          "allergens survive publish -> live load")
    check(live.item("i2").dietary == ("vegan",), "dietary survives publish")
    check(live.item("i1").description == "Charred paneer with peppers",
          "description survives publish")
    check(me.items_with_dietary(live, "vegan") == ["i2"],
          "the agent can search the live menu")
    store.set_availability("t", "i1", False, reason="ran out")
    sold_out, _ = store.load_live_config("t")
    check(sold_out.item("i1").available is False, "86 still applies")
    check(sold_out.item("i1").allergens == ("milk", "tree_nuts"),
          "marking an item sold out does not drop its allergens")

    if fails:
        print(f"{passed} passed, {len(fails)} failed (menu enrichment)")
        for f in fails:
            print(f"  FAIL: {f}")
        return 1
    print(f"{passed} passed, 0 failed (menu enrichment)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
