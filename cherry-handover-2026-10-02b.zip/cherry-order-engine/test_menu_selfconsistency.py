#!/usr/bin/env python3
"""What a caller says VERBATIM must resolve to what they said, on every menu.

For every item name and alias, every optional modifier (said as a modifier) and
every required question (answered with each option's exact name), the engine
must land on that thing, or ask which one when the menu itself is ambiguous.

This found, on real pilot menus, three ways the engine would have put the wrong
food on a ticket:

  * add_modifier took the first group with ANY match, so "extra chicken" became
    the spice level Extra Hot and "extra beef" replaced a protein choice;
  * "well" was dropped as a filler word, so "medium well" became "medium";
  * options named "2 Wontons" / "3 Wontons" collided with quantity parsing, so
    the 3-wonton add-on could never be ordered.

Adding a menu whose names the matcher misreads now fails here, not on a call.
"""

from __future__ import annotations

import collections
import sys
import traceback
from pathlib import Path

import agent_api
import menu_schema as ms
from order_engine import normalize

HERE = Path(__file__).resolve().parent
_passed = _failed = 0


def check(name, cond, detail=""):
    global _passed, _failed
    if cond:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


def _menus():
    out = []
    for path in sorted((HERE / "menus").glob("*.yaml")) + \
            sorted((HERE / "demos" / "prospects").glob("*.yaml")):
        try:
            out.append((path, ms.load_yaml(path)))
        except Exception:                                    # noqa: BLE001
            continue
    return out


def t_items_and_aliases_resolve_to_themselves() -> None:
    n = 0
    for path, cfg in _menus():
        names = collections.defaultdict(set)
        for it in cfg.items:
            names[normalize(it.name)].add(it.id)
            for a in it.aliases:
                names[normalize(a)].add(it.id)
        for it in cfg.items:
            if not it.available:
                continue
            for text in [it.name] + list(it.aliases):
                if len(names[normalize(text)]) > 1:
                    continue                      # ambiguous on the menu itself
                s = agent_api.CallSession(cfg)
                r = s.add_item(text)
                got = [ln["item_id"] for ln in s.snapshot()["lines"]] if s.e.lines else []
                asked = (r.get("needs") or {}).get("candidates") or []
                n += 1
                if got != [it.id] and not (not got and it.id in asked):
                    check(f"{path.name}: {text!r} -> {it.id}", False, f"got {got} / asked {asked}")
    check("a large number of names were exercised", n > 2500, str(n))


def t_modifiers_resolve_to_themselves() -> None:
    n = 0
    for path, cfg in _menus():
        for it in cfg.items:
            if not it.available:
                continue
            for gid in it.modifier_group_ids:
                g = cfg.group(gid)
                if not g or g.informational:
                    continue
                for oid in g.option_ids:
                    o = cfg.option(oid)
                    if not o or not o.available:
                        continue
                    twins = [x for gg in it.modifier_group_ids
                             for x in (cfg.group(gg).option_ids if cfg.group(gg) else [])
                             if cfg.option(x) and normalize(cfg.option(x).name) == normalize(o.name)]
                    if len(twins) > 1:
                        continue
                    s = agent_api.CallSession(cfg)
                    s.add_item(it.name)
                    if not s.e.lines or s.e.lines[-1].item_id != it.id:
                        continue
                    s.add_modifier(o.name)
                    n += 1
                    chosen = [sel.option_id for sel in s.e.lines[-1].selections]
                    if oid not in chosen:
                        check(f"{path.name}: {it.id} + {o.name!r}", False, f"got {chosen}")
    check("a large number of modifiers were exercised", n > 4000, str(n))


def t_required_questions_take_each_options_exact_name() -> None:
    n = 0
    for path, cfg in _menus():
        for it in cfg.items:
            if not it.available:
                continue
            for gid in it.modifier_group_ids:
                g = cfg.group(gid)
                if not g or g.informational or not g.required:
                    continue
                for oid in g.option_ids:
                    o = cfg.option(oid)
                    if not o or not o.available:
                        continue
                    if len([x for x in g.option_ids if cfg.option(x) and
                            normalize(cfg.option(x).name) == normalize(o.name)]) > 1:
                        continue
                    s = agent_api.CallSession(cfg)
                    s.add_item(it.name)
                    if not s.e.lines or s.e.lines[-1].item_id != it.id:
                        continue
                    for _ in range(6):           # answer earlier questions to reach this one
                        pend = s.pending()
                        if pend is None or pend.group_id == gid or not pend.group_id:
                            break
                        s.answer(cfg.option(pend.candidates[0]).name if pend.candidates else "")
                    pend = s.pending()
                    if pend is None or pend.group_id != gid:
                        continue
                    s.answer(o.name)
                    n += 1
                    chosen = [sel.option_id for sel in s.e.lines[-1].selections]
                    if oid not in chosen:
                        check(f"{path.name}: {it.id} / {g.name}: {o.name!r}", False,
                              f"got {[cfg.option(c).name for c in chosen]}")
    check("a large number of answers were exercised", n > 2000, str(n))


def main() -> int:
    global _failed
    for name, fn in sorted((k, v) for k, v in globals().items() if k.startswith("t_")):
        try:
            fn()
        except Exception:                                    # noqa: BLE001
            _failed += 1
            print(f"\n--- FAIL {name} raised")
            traceback.print_exc()
    print(f"{_passed} passed, {_failed} failed (menu self-consistency)")
    return 1 if _failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
