#!/usr/bin/env python3
"""Save one Square location catalog for offline Cherry menu generation.

The access token is read only from ``SQUARE_ACCESS_TOKEN``. It is never placed
in an argument, output file, log line or source file.
"""

from __future__ import annotations

import argparse
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional

from catalog_sync import SquareCatalog


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--location-id", required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--sandbox", action="store_true")
    args = parser.parse_args(argv)
    token = os.getenv("SQUARE_ACCESS_TOKEN", "")
    if not token:
        parser.error("SQUARE_ACCESS_TOKEN is not set")

    items = SquareCatalog(token, args.location_id,
                          sandbox=args.sandbox).items()
    payload = {
        "square_location_id": args.location_id,
        "exported_at": datetime.now(timezone.utc).isoformat(),
        "items": items,
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    print(f"WROTE {args.out}: {len(items)} priced variations for "
          f"{args.location_id}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

