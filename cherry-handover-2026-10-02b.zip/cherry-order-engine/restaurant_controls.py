"""Per-location hours, closures, language, prep time and AI controls."""

from __future__ import annotations

from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from order_store import json_value


DEFAULT = {"ai_enabled": True, "weekly_hours": {}, "holiday_closures": [],
           "prep_minutes": 20, "wait_minutes": 0, "languages": ["en"],
           "remember_callers": True}


_DAYS = ("mon", "tue", "wed", "thu", "fri", "sat", "sun")


def _clock(value) -> int:
    """'HH:MM' (00:00-24:00) -> minutes; ValueError otherwise."""
    hh, mm = str(value).split(":")
    h, m = int(hh), int(mm)
    if not (0 <= h <= 24 and 0 <= m <= 59) or (h == 24 and m):
        raise ValueError(f"{value!r} is not a time of day")
    return h * 60 + m


def validate_controls(weekly_hours, holiday_closures) -> None:
    """Reject what would make EVERY call fail or silently open 24 hours.

    A typo here is read on every incoming call, so it is refused when it is
    saved, not discovered on the first caller.
    """
    if not isinstance(weekly_hours, dict):
        raise ValueError("weekly_hours must be an object keyed by mon..sun")
    for day, span in weekly_hours.items():
        if day not in _DAYS:
            raise ValueError(f"weekly_hours key {day!r} must be one of {_DAYS}")
        if span in (None, [], ()):
            continue                                  # closed that day
        if not isinstance(span, (list, tuple)) or len(span) != 2:
            raise ValueError(f"weekly_hours[{day}] must be [open, close]")
        try:
            _clock(span[0]); _clock(span[1])
        except (ValueError, TypeError) as exc:
            raise ValueError(f"weekly_hours[{day}]: {exc}") from None
    if not isinstance(holiday_closures, (list, tuple)):
        raise ValueError("holiday_closures must be a list of YYYY-MM-DD dates")
    for d in holiday_closures:
        try:
            datetime.strptime(str(d), "%Y-%m-%d")
        except ValueError:
            raise ValueError(f"holiday closure {d!r} is not YYYY-MM-DD") from None


def set_controls(store, restaurant_id: str, *, weekly_hours=None,
                 holiday_closures=None, prep_minutes=20, wait_minutes=0,
                 ai_enabled=True, languages=None, updated_by="operator",
                 remember_callers=None):
    """``remember_callers=None`` keeps whatever is stored (True for a restaurant
    with no row yet), so a caller that predates the setting cannot switch it
    back on by saving the hours."""
    if prep_minutes < 0 or wait_minutes < 0:
        raise ValueError("prep and wait minutes cannot be negative")
    if remember_callers is None:
        remember_callers = get_controls(store, restaurant_id)["remember_callers"]
    validate_controls(weekly_hours or {}, holiday_closures or [])
    languages = languages or ["en"]
    if not languages or any(not str(x).strip() for x in languages):
        raise ValueError("at least one valid language is required")
    with store.tx() as conn:
        conn.execute("""INSERT INTO restaurant_control
            (restaurant_id,weekly_hours,holiday_closures,prep_minutes,
             wait_minutes,ai_enabled,languages,remember_callers,updated_by,updated_at)
            VALUES (?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)
            ON CONFLICT(restaurant_id) DO UPDATE SET
              weekly_hours=excluded.weekly_hours,
              holiday_closures=excluded.holiday_closures,
              prep_minutes=excluded.prep_minutes,wait_minutes=excluded.wait_minutes,
              ai_enabled=excluded.ai_enabled,languages=excluded.languages,
              remember_callers=excluded.remember_callers,
              updated_by=excluded.updated_by,updated_at=CURRENT_TIMESTAMP""",
            (restaurant_id, store._json_param(weekly_hours or {}),
             store._json_param(holiday_closures or []), int(prep_minutes),
             int(wait_minutes), bool(ai_enabled), store._json_param(languages),
             bool(remember_callers), updated_by))
    store.log_event("restaurant.controls_updated", restaurant_id=restaurant_id,
                    detail={"updated_by": updated_by})


def get_controls(store, restaurant_id: str) -> dict:
    row = store.conn.execute("SELECT * FROM restaurant_control WHERE restaurant_id=?",
                             (restaurant_id,)).fetchone()
    if not row: return dict(DEFAULT)
    return {"ai_enabled": bool(row["ai_enabled"]),
            "weekly_hours": json_value(row["weekly_hours"]) or {},
            "holiday_closures": json_value(row["holiday_closures"]) or [],
            "prep_minutes": int(row["prep_minutes"]),
            "wait_minutes": int(row["wait_minutes"]),
            "languages": json_value(row["languages"]) or ["en"],
            "remember_callers": bool(row["remember_callers"])}


def _spoken_time(minutes: int) -> str:
    """660 -> '11 AM', 1290 -> '9:30 PM'."""
    h, m = divmod(int(minutes) % 1440, 60)
    suffix = "AM" if h < 12 else "PM"
    h12 = h % 12 or 12
    return f"{h12} {suffix}" if m == 0 else f"{h12}:{m:02d} {suffix}"


def hours_summary(store, restaurant_id: str, *, now=None) -> dict:
    """What a caller can be told about hours — from the configured hours only.

    ``{"configured": False}`` when none are set: Lily then says she does not
    have them, and never guesses a closing time.
    """
    rest = store.restaurant(restaurant_id)
    cfg = get_controls(store, restaurant_id)
    if not cfg["weekly_hours"]:
        return {"configured": False}
    tz = ZoneInfo((rest["timezone"] if rest else None) or "UTC")
    local = now.astimezone(tz) if now else datetime.now(tz)
    holidays = set(cfg["holiday_closures"])
    current = local.hour * 60 + local.minute
    today = cfg["weekly_hours"].get(local.strftime("%a").lower())
    out = {"configured": True, "open_now": False, "closes": "", "next_open": ""}
    if today and local.date().isoformat() not in holidays:
        start, end = _clock(today[0]), _clock(today[1])
        open_now = start <= current < end if end > start else (current >= start or current < end)
        if open_now:
            out.update(open_now=True, closes=_spoken_time(end))
            return out
    for offset in range(0, 8):
        day = local.date() + timedelta(days=offset)
        hrs = cfg["weekly_hours"].get(day.strftime("%a").lower())
        if not hrs or day.isoformat() in holidays:
            continue
        start = _clock(hrs[0])
        if offset == 0 and current >= start:
            continue                       # today's window has already passed
        when = ("today" if offset == 0 else "tomorrow" if offset == 1
                else day.strftime("%A"))
        out["next_open"] = f"{when} at {_spoken_time(start)}"
        break
    return out


def service_state(store, restaurant_id: str, *, now=None) -> dict:
    rest = store.restaurant(restaurant_id)
    cfg = get_controls(store, restaurant_id)
    tz = ZoneInfo((rest["timezone"] if rest else None) or "UTC")
    local = (now.astimezone(tz) if now else datetime.now(tz))
    if not cfg["ai_enabled"]:
        return {**cfg, "accepting_orders": False, "reason": "ai_disabled"}
    if local.date().isoformat() in set(cfg["holiday_closures"]):
        return {**cfg, "accepting_orders": False, "reason": "holiday_closed"}
    if cfg["weekly_hours"]:
        # Hours ARE configured, so a day with no entry is a day the restaurant
        # is closed, not "open all day". (Hours not configured at all keeps
        # the old behaviour; go_live warns about that.)
        hours = cfg["weekly_hours"].get(local.strftime("%a").lower())
        if not hours:
            return {**cfg, "accepting_orders": False, "reason": "closed"}
        current = local.hour * 60 + local.minute
        start, end = _clock(hours[0]), _clock(hours[1])
        open_now = start <= current < end if end > start else (current >= start or current < end)
        if not open_now:
            return {**cfg, "accepting_orders": False, "reason": "closed"}
    return {**cfg, "accepting_orders": True, "reason": "open"}
