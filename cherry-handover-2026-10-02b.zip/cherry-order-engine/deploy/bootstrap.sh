#!/usr/bin/env bash
# Set up a fresh Ubuntu VPS (a Hostinger VPS, say) to run Cherry: steps 0, 2 and 3 of
# deploy/README.md, in one idempotent script. Run it AS ROOT ON THE SERVER, from a copy
# of this repository:
#
#     sudo bash deploy/bootstrap.sh --domain api.example.com --email you@example.com --tls --firewall
#
# What it does, in order (each step says what it did and is safe to run again):
#   1. checks it is Ubuntu/Debian, root, and Python >= 3.9
#   2. installs the packages (nginx, certbot, python3-venv, rclone, docker, ufw ...)
#   3. creates the `cherry` user and the directories, with the right owners and modes
#   4. copies this repository to /opt/cherry and builds its virtualenv
#   5. creates /etc/cherry/cherry.env from the example, mode 600 — NEVER overwriting an existing one
#   6. installs the systemd units and ENABLES them (it does not start them: fill in the env file first)
#   7. installs the nginx site for --domain, tests it with `nginx -t`, and reloads
#   8. installs the cron jobs
#   9. optionally (--tls) gets the TLS certificate and (--firewall) opens only 22, 80, 443
#
# What it does NOT do, on purpose: put a real secret anywhere, start the services, touch the
# database, or change DNS. It prints what is left (the database, the secrets, DNS) at the end.
# The database is deploy/postgres/ (docker compose); see deploy/README.md section 1.
#
# --dry-run prints every command and changes nothing. Everything lives under $ROOT_DIR
# (default /) so the script can be exercised on a scratch directory: see test_bootstrap.py.
set -euo pipefail

SOURCE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ROOT_DIR="${ROOT_DIR:-}"            # empty = the real system; tests point it at a scratch directory
DOMAIN=""; EMAIL=""; TLS=0; FIREWALL=0; DRY=0; PACKAGES=1; NGINX=1; SSH_PORT=22
PYTHON_BIN="${PYTHON_BIN:-python3}"
APP_USER="cherry"

usage() { sed -n '2,24p' "$0" | sed 's/^# \{0,1\}//'; exit "${1:-0}"; }
while [ $# -gt 0 ]; do
  case "$1" in
    --domain) DOMAIN="${2:?--domain needs a value}"; shift 2 ;;
    --email) EMAIL="${2:?--email needs a value}"; shift 2 ;;
    --source) SOURCE="${2:?--source needs a value}"; shift 2 ;;
    --tls) TLS=1; shift ;;
    --firewall) FIREWALL=1; shift ;;
    --ssh-port) SSH_PORT="${2:?--ssh-port needs a value}"; shift 2 ;;
    --dry-run) DRY=1; shift ;;
    --skip-packages) PACKAGES=0; shift ;;
    --no-nginx) NGINX=0; shift ;;
    -h|--help) usage 0 ;;
    *) echo "unknown option: $1" >&2; usage 2 ;;
  esac
done

say()  { printf '\n==> %s\n' "$*"; }
note() { printf '    %s\n' "$*"; }
die()  { printf 'bootstrap: %s\n' "$*" >&2; exit 1; }
run()  { if [ "$DRY" = 1 ]; then printf '    [dry-run] %s\n' "$*"; else "$@"; fi; }
path() { printf '%s%s' "$ROOT_DIR" "$1"; }

# ---- 1. preflight -----------------------------------------------------------------
say "1/9 checking this machine"
if [ -z "$ROOT_DIR" ]; then
  [ "$(uname -s)" = "Linux" ] || die "this installs onto a Linux server; you are on $(uname -s). Run it on the VPS."
  [ "$(id -u)" = "0" ] || die "run as root (sudo bash deploy/bootstrap.sh ...)"
  command -v apt-get >/dev/null 2>&1 || die "apt-get not found: this script is for Ubuntu/Debian"
fi
[ -f "$SOURCE/server.py" ] && [ -f "$SOURCE/requirements.txt" ] || die "$SOURCE is not the Cherry repository (no server.py/requirements.txt)"
if [ "$NGINX" = 1 ] && [ -z "$DOMAIN" ]; then die "--domain is required (the public API host name, e.g. api.example.com), or pass --no-nginx"; fi
if [ -n "$DOMAIN" ] && ! [[ "$DOMAIN" =~ ^[A-Za-z0-9]([A-Za-z0-9.-]*[A-Za-z0-9])?\.[A-Za-z]{2,}$ ]]; then die "'$DOMAIN' is not a host name"; fi
[[ "$SSH_PORT" =~ ^[0-9]{1,5}$ ]] || die "--ssh-port must be a number"
if [ "$TLS" = 1 ] && [ -z "$EMAIL" ]; then die "--tls needs --email (Let's Encrypt sends expiry notices there)"; fi
"$PYTHON_BIN" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' || die "Python 3.9 or newer is required"
note "ok: $(uname -s), Python $("$PYTHON_BIN" -c 'import sys; print("%d.%d" % sys.version_info[:2])'), source $SOURCE"

# ---- 2. packages ------------------------------------------------------------------
say "2/9 installing packages"
if [ "$PACKAGES" = 1 ]; then
  run apt-get update -y
  run apt-get install -y nginx certbot python3-venv python3-pip rsync rclone ufw curl ca-certificates docker.io docker-compose-v2
  note "PostgreSQL 16 CLIENT tools (pg_dump/pg_restore) must match the server: if 'pg_dump --version' is older than 16,"
  note "add the PGDG apt repository and install postgresql-client-16 (deploy/README.md step 0.2)."
else
  note "skipped (--skip-packages)"
fi

# ---- 3. user and directories ------------------------------------------------------
say "3/9 the cherry user and directories"
if ! id "$APP_USER" >/dev/null 2>&1; then
  run useradd --system --create-home --shell /usr/sbin/nologin "$APP_USER"
  note "created user $APP_USER"
else
  note "user $APP_USER already exists"
fi
if getent group docker >/dev/null 2>&1; then run usermod -aG docker "$APP_USER"; fi
for d in /etc/cherry /var/lib/cherry/secrets /var/lib/cherry/briefs /var/lib/cherry/backups /var/log/cherry /opt/cherry; do
  run mkdir -p "$(path "$d")"
done
run chown -R "$APP_USER" "$(path /var/lib/cherry)" "$(path /var/log/cherry)"
run chmod 700 "$(path /var/lib/cherry/secrets)"
run chmod 755 "$(path /etc/cherry)"
note "secrets directory is private (700); /opt/cherry is not writable by $APP_USER"

# ---- 4. the application -----------------------------------------------------------
say "4/9 copying the application to /opt/cherry and building its virtualenv"
DEST="$(path /opt/cherry)"
if [ "$DRY" = 1 ]; then
  printf '    [dry-run] copy %s -> %s (without .venv, __pycache__, tests data)\n' "$SOURCE" "$DEST"
else
  if [ "$(cd "$SOURCE" && pwd)" != "$(cd "$DEST" && pwd)" ]; then
    tar -C "$SOURCE" --exclude=.venv --exclude=__pycache__ --exclude='*.pyc' --exclude=.git --exclude='*.db' --exclude='*.db-*' \
        --exclude='.fail_*' -cf - . | tar -C "$DEST" -xf -
  fi
fi
if [ ! -x "$DEST/.venv/bin/python" ] || [ "$DRY" = 1 ]; then run "$PYTHON_BIN" -m venv "$DEST/.venv"; fi
run "$DEST/.venv/bin/pip" install --quiet --upgrade pip
run "$DEST/.venv/bin/pip" install --quiet -r "$DEST/requirements-postgres.txt"
run chown -R root:root "$DEST"                      # the service user can read and run it, never change it
run chmod -R go-w "$DEST"
note "dependencies installed from requirements-postgres.txt (PyYAML, cryptography, tzdata, psycopg ...)"

# ---- 5. the environment file ------------------------------------------------------
say "5/9 /etc/cherry/cherry.env"
ENVF="$(path /etc/cherry/cherry.env)"
if [ -e "$ENVF" ]; then
  note "already exists: left exactly as it is"
else
  run cp "$SOURCE/deploy/cherry.env.example" "$ENVF"
  run chmod 600 "$ENVF"
  run chown "$APP_USER" "$ENVF"
  note "created from the example. EVERY value that says CHANGE_ME is yours to fill in; nothing was generated or guessed"
  if [ -n "$DOMAIN" ]; then
    note "(set SQUARE_WEBHOOK_URL and CLOVER_REDIRECT_URI to https://$DOMAIN/... — the exact paths are in deploy/nginx/cherry.conf)"
  fi
fi

# ---- 6. services ------------------------------------------------------------------
say "6/9 systemd units (enabled, NOT started)"
UNITS="$(path /etc/systemd/system)"
run mkdir -p "$UNITS"
for u in cherry-server.service cherry-gateway.service; do run cp "$SOURCE/deploy/systemd/$u" "$UNITS/$u"; done
run systemctl daemon-reload
run systemctl enable cherry-server cherry-gateway
note "start them only after the env file and the database are ready:  systemctl start cherry-server cherry-gateway"

# ---- 7. nginx ---------------------------------------------------------------------
say "7/9 nginx"
if [ "$NGINX" = 1 ]; then
  SITES="$(path /etc/nginx/sites-available)"; ENABLED="$(path /etc/nginx/sites-enabled)"
  run mkdir -p "$SITES" "$ENABLED"
  if [ "$DRY" = 1 ]; then
    printf '    [dry-run] write %s/cherry.conf with api.example.com -> %s\n' "$SITES" "$DOMAIN"
  else
    sed "s/api\\.example\\.com/$DOMAIN/g" "$SOURCE/deploy/nginx/cherry.conf" > "$SITES/cherry.conf"
  fi
  run ln -sfn "$SITES/cherry.conf" "$ENABLED/cherry.conf"
  if [ "$TLS" = 1 ]; then
    run mkdir -p "$(path /var/www/certbot)"
    note "the certificate is requested in step 9; until then nginx cannot load the HTTPS block, so the site is written but NOT reloaded"
  else
    run nginx -t
    run systemctl reload nginx
  fi
else
  note "skipped (--no-nginx)"
fi

# ---- 8. cron ----------------------------------------------------------------------
say "8/9 scheduled jobs"
run mkdir -p "$(path /etc/cron.d)"
run cp "$SOURCE/deploy/cron/cherry.cron" "$(path /etc/cron.d/cherry)"
run chmod 644 "$(path /etc/cron.d/cherry)"
note "the jobs run as $APP_USER through deploy/run-job.sh, and page the alert phone if one fails"

# ---- 9. TLS and firewall ----------------------------------------------------------
say "9/9 TLS and firewall"
if [ "$TLS" = 1 ]; then
  note "DNS for $DOMAIN must already point at this server, or the certificate request fails"
  run certbot certonly --webroot -w "$(path /var/www/certbot)" -d "$DOMAIN" --email "$EMAIL" --agree-tos --no-eff-email --non-interactive
  run nginx -t
  run systemctl reload nginx
else
  note "no certificate requested (use --tls with --email once DNS points here)"
fi
if [ "$FIREWALL" = 1 ]; then
  # SSH first, so enabling the firewall can never lock you out of the machine you are typing on.
  run ufw allow "$SSH_PORT/tcp"
  run ufw allow 80/tcp
  run ufw allow 443/tcp
  run ufw default deny incoming
  run ufw --force enable
  note "only $SSH_PORT (ssh), 80 and 443 are open. 8080, 8090 and 5432 stay private: Cherry's own servers bind all interfaces, the firewall is what keeps them off the internet"
else
  note "firewall untouched. IMPORTANT: ports 8080, 8090 and 5432 must not be reachable from outside (use --firewall, or your provider's firewall)"
fi

cat <<EOF

DONE. What is left, in order (see deploy/README.md):
  1. The database:        cd /opt/cherry/deploy/postgres && cp db.env.example db.env  (real password) && docker compose up -d
  2. The secrets:         edit /etc/cherry/cherry.env — every CHANGE_ME — then:  python3 /opt/cherry/deploy/check_env_names.py
  3. Create the schema:   cd /opt/cherry && set -a && . /etc/cherry/cherry.env && set +a && .venv/bin/python production_db.py bootstrap && .venv/bin/python production_db.py verify
  4. Start:               systemctl start cherry-server cherry-gateway
  5. Check:               curl https://${DOMAIN:-YOUR-HOST}/health   (200)   and   curl -o /dev/null -w '%{http_code}' https://${DOMAIN:-YOUR-HOST}/t/1234   (404)
  6. Preflight:           cd /opt/cherry && .venv/bin/python cherry.py go-live --db "\$CHERRY_DATABASE_URL" --url https://${DOMAIN:-YOUR-HOST}
Deploy a new version BETWEEN calls: a call resumed across a restart is handed to staff.
EOF
