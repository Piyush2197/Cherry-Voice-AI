"""
Readiness — what stands between a restaurant and its first live call.

`cherry.py check` answers "is this config valid?". This answers a different and
more useful question: "can this restaurant actually take a call tonight, and if
not, what exactly is stopping it, and whose job is it?"

The distinction matters because most of what is left on this project is not
code. It is menu data that has to come from an owner, a phone number that has
to be bought, a POS token that has to be granted. Those blockers are invisible
to a test suite and they are the ones that actually hold up a launch.

    ./cherry.py readiness                 every restaurant
    ./cherry.py readiness pink-garlic-shelby --db cherry.db

Each blocker carries an OWNER, because "the menu is incomplete" sitting in a
list with no name against it is how a launch slips for three weeks.
"""

from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path
from typing import Dict, List, Optional

import menu_schema as ms

MENUS = Path(__file__).parent / "menus"

# Categories a cuisine is expected to sell. Missing ones are usually an
# incomplete extraction rather than a restaurant that genuinely has no
# vegetarian food. Advisory — the linter never blocks on these.
EXPECTED_CATEGORIES: Dict[str, tuple] = {
    "indian": ("appetizer", "vegetable", "chicken", "lamb", "seafood",
               "biryani", "bread", "rice", "tandoori", "dessert", "drink"),
    "mexican": ("appetizer", "taco", "burrito", "entree", "side", "kids",
                "dessert", "drink"),
    "burger": ("entree", "side", "drink"),
    "mediterranean": ("appetizer", "entree", "side", "dessert", "drink"),
    "japanese": ("appetizer", "roll", "entree", "side", "drink"),
    "italian": ("appetizer", "pasta", "entree", "side", "dessert", "drink"),
    "pizza": ("pizza", "side", "drink"),
    "chinese": ("appetizer", "soup", "entree", "rice", "drink"),
}

BLOCKER = "BLOCKER"       # cannot take a call
GAP = "GAP"               # will take calls, but will fail some of them
NOTE = "NOTE"             # worth knowing


@dataclass
class Finding:
    level: str
    owner: str
    what: str

    def __str__(self) -> str:
        return f"[{self.level:7}] ({self.owner}) {self.what}"


def assess(cfg, row=None, store=None) -> List[Finding]:
    """What is stopping this restaurant. `row` is its database record, if any."""
    out: List[Finding] = []

    # --- things that stop a call happening at all ----------------------
    if row is None:
        out.append(Finding(BLOCKER, "us",
                           "not deployed to a database yet — "
                           f"`cherry.py deploy menus/{cfg.id}.yaml`"))
    else:
        if not row["inbound_phone"]:
            out.append(Finding(BLOCKER, "you",
                               "no inbound number: nothing routes a call to "
                               "this restaurant"))
        if not row["active"]:
            out.append(Finding(BLOCKER, "us",
                               "marked inactive — it will refuse calls"))
        if row["sink"] == "manual" and not row["staff_phone"]:
            out.append(Finding(BLOCKER, "owner",
                               "no staff phone: the kitchen ticket has "
                               "nowhere to go"))
        if row["sink"] == "toast":
            rid = cfg.id.upper().replace("-", "_")
            required = ("TOAST_ACCESS_TOKEN", "TOAST_RESTAURANT_GUID",
                        "TOAST_DINING_OPTION_GUID", "TOAST_ITEM_GROUP_GUID")
            missing = [key for key in required if not (
                os.environ.get(f"{key}_{rid}") or os.environ.get(key))]
            if missing:
                out.append(Finding(BLOCKER, "dev",
                                   "ToastSink is built; missing deployment "
                                   "settings: " + ", ".join(missing)))
            unmapped = [i.name for i in cfg.items
                        if not (i.pos_refs or {}).get("toast_guid")]
            if unmapped:
                out.append(Finding(BLOCKER, "dev",
                                   f"{len(unmapped)} Toast item GUID mappings "
                                   "are still required from the live catalog"))
        if row["sink"] == "square":
            out.append(Finding(NOTE, "dev",
                               "Square needs a per-merchant OAuth token and "
                               "location id in the environment"))

    # --- things that will lose orders ----------------------------------
    unpriced = [i.name for i in cfg.items
                if not i.has_sizes and i.base_price_cents <= 0]
    if unpriced:
        out.append(Finding(BLOCKER, "owner",
                           f"{len(unpriced)} item(s) have no price: "
                           f"{', '.join(unpriced[:4])}"))

    cats = {i.category for i in cfg.items if i.category}
    expected = EXPECTED_CATEGORIES.get(cfg.cuisine, ())
    missing = [c for c in expected if c not in cats]
    if missing:
        out.append(Finding(
            GAP, "owner",
            f"no items in {len(missing)} expected categor"
            f"{'y' if len(missing) == 1 else 'ies'}: {', '.join(missing)}. "
            f"Callers who ask for these hear 'we don't have that'"))

    # A required group with one option is a question with one answer — it
    # wastes a turn on every single call.
    for g in cfg.groups:
        if g.min_select >= 1 and len(g.option_ids) == 1:
            out.append(Finding(GAP, "us",
                               f"group '{g.name}' is required but offers one "
                               f"option — Lily asks a pointless question"))

    # --- POS mapping ----------------------------------------------------
    if row is not None and row["sink"] == "square":
        try:
            from square_bridge import pos_ref_gaps
            gaps = pos_ref_gaps(cfg)
            if gaps["items"]:
                out.append(Finding(
                    NOTE, "dev",
                    f"{len(gaps['items'])}/{len(cfg.items)} items have no "
                    f"Square catalog id. Orders still work (ad hoc), but the "
                    f"owner loses per-item sales reporting"))
        except Exception:                              # noqa: BLE001
            pass

    # --- availability ---------------------------------------------------
    if store is not None and row is not None:
        off = store.availability_overrides(cfg.id)
        if off["item"] or off["option"]:
            out.append(Finding(NOTE, "owner",
                               f"{len(off['item'])} item(s) currently 86'd"))

    return out


def _load_all() -> List:
    cfgs = []
    for p in sorted(MENUS.glob("*.yaml")):
        try:
            cfgs.append(ms.load_yaml(p))
        except Exception:                              # noqa: BLE001
            continue
    return cfgs


def cmd_readiness(args) -> int:
    from cherry import BOLD, DIM, GRN, OFF, RED, YEL

    store = None
    if getattr(args, "db", None):
        from order_store import OrderStore
        store = OrderStore.open(args.db)

    if getattr(args, "restaurant", None):
        cfgs = [c for c in _load_all() if c.id == args.restaurant]
        if not cfgs:
            print(f"no such restaurant: {args.restaurant}")
            return 1
    elif getattr(args, "pilots", False):
        want = {"bun-n-run-ferndale", "pink-garlic-shelby",
                "juan-miguels-clinton"}
        cfgs = [c for c in _load_all() if c.id in want]
    else:
        cfgs = _load_all()

    ready = 0
    for cfg in cfgs:
        row = store.restaurant(cfg.id) if store else None
        findings = assess(cfg, row, store)
        blockers = [f for f in findings if f.level == BLOCKER]
        gaps = [f for f in findings if f.level == GAP]

        if not blockers:
            ready += 1
            badge = f"{GRN}CAN TAKE CALLS{OFF}"
        else:
            badge = f"{RED}BLOCKED{OFF}"
        print(f"\n{BOLD}{cfg.name}{OFF} {DIM}({cfg.id}, {len(cfg.items)} "
              f"items, {cfg.cuisine}){OFF}  {badge}")
        if not findings:
            print(f"   {DIM}nothing outstanding{OFF}")
        for f in findings:
            colour = RED if f.level == BLOCKER else (YEL if f.level == GAP else DIM)
            print(f"   {colour}{f}{OFF}")

    print(f"\n{BOLD}{ready}/{len(cfgs)}{OFF} could take a call right now.")
    if store is None:
        print(f"{DIM}(no --db given, so deployment state was not checked){OFF}")
    return 0
