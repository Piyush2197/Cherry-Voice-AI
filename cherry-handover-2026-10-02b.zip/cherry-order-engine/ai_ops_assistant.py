#!/usr/bin/env python3
"""AI-ready incident triage with a deliberately narrow safety boundary.

This creates evidence packets an AI coding assistant or the main developer can
act on. It never changes menus, prices, payments, orders, restaurant routing or
credentials. The only automatic repair is closing an abandoned session older
than the alert threshold when no order exists for it.
"""
from __future__ import annotations

import argparse
import json
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

import ops_monitor
from order_store import OrderStore, json_value

PERSISTENT_AFTER = 3


def _previous_occurrences(store: OrderStore, signature: str,
                          now: datetime) -> int:
    since = (now - timedelta(days=7)).isoformat(timespec="seconds")
    rows = store.conn.execute("""SELECT detail FROM event
        WHERE kind='incident.triaged' AND created_at>=?""", (since,)).fetchall()
    return sum(1 for row in rows
               if (json_value(row["detail"]) or {}).get("signature") == signature)


def _safe_close_stuck_session(store: OrderStore, alert) -> bool:
    if not alert.key.startswith("session-stuck:"):
        return False
    session_id = alert.key.split(":", 1)[1]
    order = store.conn.execute(
        'SELECT 1 FROM "order" WHERE session_id=?', (session_id,)).fetchone()
    session = store.conn.execute(
        "SELECT ended_at FROM session WHERE id=?", (session_id,)).fetchone()
    if order is not None or session is None or session["ended_at"] is not None:
        return False
    store.end_session(session_id, "timed_out")
    store.log_event("incident.auto_resolved", session_id=session_id,
                    detail={"action": "closed_stale_session_without_order"})
    return True


def triage(store: OrderStore, *, now: Optional[datetime] = None,
           apply_safe_fixes: bool = False, persist: bool = True
           ) -> Dict[str, Any]:
    now = now or datetime.now(timezone.utc)
    cases: List[Dict[str, Any]] = []
    for alert in ops_monitor.scan_alerts(store, now=now):
        signature = f"{alert.restaurant_id}:{alert.category}:{alert.title}"
        occurrence = _previous_occurrences(store, signature, now) + 1
        persistent = occurrence >= PERSISTENT_AFTER
        auto_resolved = apply_safe_fixes and _safe_close_stuck_session(store, alert)
        owner = ("resolved_automatically" if auto_resolved else
                 "main_developer" if persistent or alert.category == "configuration" else
                 "founder_first_response" if alert.severity == "critical" else
                 "ai_monitor")
        case = {
            "incident_key": alert.key, "signature": signature,
            "restaurant_id": alert.restaurant_id,
            "severity": alert.severity, "category": alert.category,
            "facts": {"title": alert.title, "detail": alert.detail},
            "recommended_action": alert.action,
            "occurrence_in_7_days": occurrence,
            "persistent": persistent, "owner": owner,
            "auto_resolved": auto_resolved,
            "assistant_guardrails": [
                "Do not place, cancel, redeliver or alter an order.",
                "Do not change prices, menus, routing, payments or credentials.",
                "Use logs and tests to diagnose; prepare a patch for developer review.",
                "Keep caller identity and transcript text out of the incident packet.",
            ],
            "developer_handoff": (
                "Persistent incident: inspect provider trace and Cherry events, "
                "reproduce, add a regression test, deploy through the release guard."
                if persistent else None),
        }
        cases.append(case)
        if persist:
            store.log_event("incident.triaged",
                            restaurant_id=alert.restaurant_id,
                            detail={"signature": signature,
                                    "incident_key": alert.key,
                                    "occurrence": occurrence,
                                    "owner": owner,
                                    "auto_resolved": auto_resolved})
    return {"generated_at": now.isoformat(timespec="seconds"),
            "incident_count": len(cases), "incidents": cases}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--db", required=True)
    parser.add_argument("--apply-safe-fixes", action="store_true")
    args = parser.parse_args()
    report = triage(OrderStore.open(args.db),
                    apply_safe_fixes=args.apply_safe_fixes)
    print(json.dumps(report, indent=2, default=str))
    return 2 if any(x["owner"] == "main_developer"
                    for x in report["incidents"]) else 0


if __name__ == "__main__":
    raise SystemExit(main())
