#!/usr/bin/env python3
"""voice_pack.py: the files a voice console needs, and the check that they still match the live engine."""

from __future__ import annotations

import contextlib
import io
import json
import re
import tempfile
import traceback
from pathlib import Path

import host_voice
import rehearsal
import server
import voice_pack as vp
from voice.inworld_bridge import SYSTEM_PROMPT

_passed = _failed = 0
SECRET = "voicekey"


def check(name, cond, detail=""):
    global _passed, _failed
    if cond:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


def cli(*argv, env=None, opener=None):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = vp.main(list(argv), env=env or {}, opener=opener)
    return rc, buf.getvalue()


def t_the_pack_is_built_from_the_repository() -> None:
    d = Path(tempfile.mkdtemp())
    rc, out = cli("make", "--out", str(d / "pack"), "--base-url", "https://api.cherry.example/")
    pack = d / "pack"
    check("make writes the six files and the fingerprint", rc == 0 and sorted(p.name for p in pack.iterdir()) == sorted(vp.FILES + ("pack.json",)), out)
    check("the prompt is the engine's, verbatim", (pack / "system_prompt.txt").read_text().rstrip("\n") == SYSTEM_PROMPT.rstrip("\n"))
    tools = json.loads((pack / "tools.json").read_text())
    check("every engine tool is in the pack, with its schema", [t["name"] for t in tools] == [t["name"] for t in server.ALL_TOOL_SCHEMAS] and len(tools) == 19, str(len(tools)))
    check("each tool has a name, a description and JSON-schema parameters", all(set(t) == {"name", "description", "parameters"} and t["parameters"].get("type") == "object" for t in tools))
    gem = json.loads((pack / "tools.gemini.json").read_text())
    check("the Gemini file declares EVERY tool BLOCKING (3.8 Live defaults to non-blocking)", len(gem) == 19 and all(g["behavior"] == "BLOCKING" for g in gem))
    check("the call policy is the engine's", json.loads((pack / "call_policy.json").read_text()) == host_voice.CALL_POLICY)
    connect = (pack / "CONNECT.md").read_text()
    check("CONNECT.md uses the given host (no trailing slash) and states the auth header",
          "https://api.cherry.example/v1/voice/calls" in connect and "//v1" not in connect.replace("https://", "") and "X-Voice-Key" in connect)
    check("…and the policy numbers are the real ones, not None", "8 s of silence" in connect and "after 2 unanswered" in connect.replace("release the caller after 2 unanswered", "after 2 unanswered") and "600 s" in connect and "None" not in connect, connect[-900:])
    check("the pack contains no secret", SECRET not in "".join(p.read_text() for p in pack.iterdir()))
    check("running make twice gives identical files (it can be committed and diffed)", (lambda a: (vp.make(pack, "https://api.cherry.example/") and a == {p.name: p.read_text() for p in pack.iterdir()})) ({p.name: p.read_text() for p in pack.iterdir()}))


def t_verify_matches_a_live_engine_and_catches_drift() -> None:
    st = rehearsal.Stack()
    try:
        url = f"http://127.0.0.1:{st.gport}"
        pack = Path(tempfile.mkdtemp()) / "pack"
        vp.make(pack, url)
        env = {"CHERRY_VOICE_KEY": SECRET}
        rc, out = cli("verify", "--pack", str(pack), "--url", url, env=env, opener=rehearsal.REAL_URLOPEN)
        check("a fresh pack matches the live gateway", rc == 0 and "matches the live engine" in out, out)

        # 1. an older prompt in the console
        (pack / "system_prompt.txt").write_text("You are an old prompt.\n")
        rc, out = cli("verify", "--pack", str(pack), "--url", url, env=env, opener=rehearsal.REAL_URLOPEN)
        check("an old prompt is reported", rc == 3 and "older (or edited) prompt" in out, out)
        vp.make(pack, url)

        # 2. a tool the engine has and the pack lacks (a deploy added one)
        tools = json.loads((pack / "tools.json").read_text())
        (pack / "tools.json").write_text(json.dumps([t for t in tools if t["name"] != "reorder_last"]))
        rc, out = cli("verify", "--pack", str(pack), "--url", url, env=env, opener=rehearsal.REAL_URLOPEN)
        check("a missing tool is named, with why it matters", rc == 3 and "reorder_last" in out and "cannot call it" in out, out)
        vp.make(pack, url)

        # 3. a tool the pack has that the engine does not (a deploy removed one)
        (pack / "tools.json").write_text(json.dumps(tools + [{"name": "ghost_tool", "description": "x", "parameters": {"type": "object", "properties": {}}}]))
        rc, out = cli("verify", "--pack", str(pack), "--url", url, env=env, opener=rehearsal.REAL_URLOPEN)
        check("a tool the engine dropped is named", rc == 3 and "ghost_tool" in out and "missing endpoint" in out, out)
        vp.make(pack, url)

        # 4. a changed parameter schema
        changed = json.loads((pack / "tools.json").read_text())
        changed[0]["parameters"]["properties"]["extra"] = {"type": "string"}
        (pack / "tools.json").write_text(json.dumps(changed))
        rc, out = cli("verify", "--pack", str(pack), "--url", url, env=env, opener=rehearsal.REAL_URLOPEN)
        check("a changed schema is reported against the tool", rc == 3 and f"tool {changed[0]['name']}: the parameters differ" in out, out)
        vp.make(pack, url)

        # 5. a tool left non-blocking, a policy edit, a hand edit after make
        gem = json.loads((pack / "tools.gemini.json").read_text())
        gem[3]["behavior"] = "NON_BLOCKING"
        (pack / "tools.gemini.json").write_text(json.dumps(gem))
        rc, out = cli("verify", "--pack", str(pack), "--url", url, env=env, opener=rehearsal.REAL_URLOPEN)
        check("a non-blocking tool declaration is reported", rc == 3 and "BLOCKING" in out, out)
        vp.make(pack, url)
        pol = json.loads((pack / "call_policy.json").read_text())
        pol["max_call_seconds"] = 3600
        (pack / "call_policy.json").write_text(json.dumps(pol))
        rc, out = cli("verify", "--pack", str(pack), "--url", url, env=env, opener=rehearsal.REAL_URLOPEN)
        check("an edited call policy is reported", rc == 3 and "call policy" in out and "edited after `make`" in out, out)
        vp.make(pack, url)

        # access problems are exit 2 with a plain message, never a traceback or the key
        rc, out = cli("verify", "--pack", str(pack), "--url", url, env={"CHERRY_VOICE_KEY": "wrong"}, opener=rehearsal.REAL_URLOPEN)
        check("a wrong voice key is a plain message", rc == 2 and "HTTP 401" in out and "wrong" not in out, out)
        rc, out = cli("verify", "--pack", str(pack), "--url", url, env={}, opener=rehearsal.REAL_URLOPEN)
        check("a missing key says to export it, by name", rc == 2 and "CHERRY_VOICE_KEY is not set" in out, out)
        rc, out = cli("verify", "--pack", str(pack), "--url", "http://127.0.0.1:9", env=env, opener=rehearsal.REAL_URLOPEN)
        check("an unreachable engine is a plain message", rc == 2 and "could not read" in out and "Traceback" not in out, out)
        rc, out = cli("verify", "--pack", str(Path(tempfile.mkdtemp())), "--url", url, env=env, opener=rehearsal.REAL_URLOPEN)
        check("an empty folder says to run make", rc == 3 and "run `voice_pack.py make`" in out, out)
        check("the voice key never appears in any output", SECRET not in out)
    finally:
        st.close()


def main() -> int:
    global _failed
    for name, fn in sorted((k, v) for k, v in globals().items() if k.startswith("t_")):
        try:
            fn()
        except Exception:                                    # noqa: BLE001
            _failed += 1
            print(f"\n--- FAIL {name} raised")
            traceback.print_exc()
    print(f"{_passed} passed, {_failed} failed (voice pack)")
    return 1 if _failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
