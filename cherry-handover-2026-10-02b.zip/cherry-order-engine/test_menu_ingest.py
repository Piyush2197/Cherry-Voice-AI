#!/usr/bin/env python3
"""
Menu text ingestion — prices without a "$", descriptions, and menu furniture.

Every restaurant that needed a hand-written Python builder needed one because
the generic path could not read the owner's menu as written. The most common
reason was that `parse_price` only understood a price carrying a "$": pasted,
printed and PDF'd menus write "Harbor Classic  9.50", so the ingester read a
whole real menu as unpriced and the owner's onboarding became a coding task.

These tests pin the parsing rules in both directions — the prices that must be
read, and the numbers that must NOT be read as money. The second direction is
the one that bills a customer.
"""

from __future__ import annotations

import menu_ingest as mi

_passed, _failed = 0, 0


def check(name: str, cond: bool, detail: str = "") -> None:
    global _passed, _failed
    if cond:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


# A realistic pasted menu: flush-left dishes, indented descriptions, bare
# prices, ALL-CAPS sections, and the restaurant's own header/address/tax.
PASTED = """HARBOR BURGER CO.
1247 Lakeshore Ave
Phone: (313) 555-1234

BURGERS
Harbor Classic  9.50
  Angus patty, pickles, harbor sauce
Lakeshore Double  13.25
  Two patties, american cheese, onion
Bluewater Bacon Burger  14.00
  Applewood bacon, smoked gouda

SIDES
Hand-Cut Fries  4.25
Onion Rings  5.75

DRINKS
Milkshake  6.25
  Vanilla, chocolate, or strawberry

Subtotal 45.00
TAX 6%
www.harbor.test
"""


def test_bare_prices_are_read() -> None:
    check("bare decimal price", mi.parse_price("Harbor Classic  9.50") == 950)
    check("single-space price", mi.parse_price("Fountain Soda 2.75") == 275)
    check("whole-dollar price", mi.parse_price("Onion Rings  6") == 600)
    check("dot leaders", mi.parse_price("Fries .... 4.25") == 425)
    check("price on its own line", mi.parse_price("4.25") == 425)


def test_dollar_prices_still_work() -> None:
    check("dollar price", mi.parse_price("Butter Chicken $16.99") == 1699)
    check("dollar with space", mi.parse_price("Butter Chicken $ 16.99") == 1699)
    check("dollar beats a trailing number",
          mi.parse_price("Combo 2 $13.99") == 1399)


def test_numbers_that_are_not_prices() -> None:
    """The dangerous direction: a wrong price bills a customer."""
    cases = [
        ("29. Butter Chk. (Creamy)", "leading menu number"),
        ("104. Garlic Naan", "leading menu number"),
        ("1247 Lakeshore Ave", "street number"),
        ("Est. 2019", "a year"),
        ("TAX 6%", "a tax rate"),
        ("Harbor Classic", "no number at all"),
        ("BURGERS", "a section heading"),
    ]
    for text, why in cases:
        check(f"{why}: {text!r}", mi.parse_price(text) is None,
              f"read as {mi.parse_price(text)}")


def test_strip_price_agrees_with_parse_price() -> None:
    for text, name in (("Harbor Classic  9.50", "Harbor Classic"),
                       ("Butter Chicken $16.99", "Butter Chicken"),
                       ("Onion Rings  6", "Onion Rings"),
                       ("Fries .... 4.25", "Fries")):
        check(f"strip {text!r}", mi.strip_price(text) == name,
              f"got {mi.strip_price(text)!r}")


def test_descriptions_attach_to_the_dish_above() -> None:
    items = {p.name: p for p in mi.parse_menu_text(PASTED)}
    got = items["Harbor Classic"].description
    check("indented line becomes the dish description",
          got == "Angus patty, pickles, harbor sauce", repr(got))
    check("and is not an item of its own",
          "Angus patty, pickles, harbor sauce" not in items)
    check("a second dish gets its own description",
          "Two patties" in items["Lakeshore Double"].description)
    check("a dish with no description has none",
          items["Hand-Cut Fries"].description == "")


def test_menu_furniture_never_becomes_an_item() -> None:
    names = [p.name for p in mi.parse_menu_text(PASTED)]
    joined = " | ".join(names)
    for junk in ("HARBOR BURGER CO", "1247 Lakeshore", "Phone", "Subtotal",
                 "TAX", "www."):
        check(f"{junk!r} is not an item", junk.lower() not in joined.lower(),
              joined)
    check("no description leaked into the item list",
          not any("Angus patty" in n for n in names), joined)


def test_numbered_dishes_survive() -> None:
    """A whole menu was once deleted by an over-broad 'skip' rule.

    Menu numbers ("29. Butter Chk.") and furniture both begin with a digit.
    Matching "starts with a digit" as furniture removed the food and still
    reported success, which is the worst possible failure: silent and green.
    """
    text = ("CHICKEN\n29. Butter Chk. (Creamy)\n$13.99\n"
            "41. Chk Saag\n$13.99\n")
    names = [p.name for p in mi.parse_menu_text(text)]
    check("numbered dish 1 kept", "Butter Chk. (Creamy)" in names, str(names))
    check("numbered dish 2 kept", "Chk Saag" in names, str(names))
    check("prices still read",
          all(p.price_cents == 1399
              for p in mi.parse_menu_text(text)), str(names))


def test_a_real_menu_parses_completely() -> None:
    items = mi.parse_menu_text(PASTED)
    check("every dish found", len(items) == 6, f"{len(items)}: "
          f"{[p.name for p in items]}")
    check("every dish priced",
          all(p.price_cents is not None for p in items),
          str([(p.name, p.price_cents) for p in items]))
    check("sections are recorded",
          {p.section for p in items} == {"BURGERS", "SIDES", "DRINKS"},
          str({p.section for p in items}))
    check("nothing was left unparsed", not mi.propose(PASTED, "burger").unparsed_lines)


def test_proposal_marks_the_draft_as_needing_confirmation() -> None:
    p = mi.propose(PASTED, "burger")
    check("a draft, not a config", p.items and len(p.items) == 6)
    check("the owner is asked about modifier prices",
          any(c.topic.startswith("prices in") for c in p.confirmations),
          str([c.topic for c in p.confirmations]))


def main() -> int:
    for fn in (test_bare_prices_are_read, test_dollar_prices_still_work,
               test_numbers_that_are_not_prices,
               test_strip_price_agrees_with_parse_price,
               test_descriptions_attach_to_the_dish_above,
               test_menu_furniture_never_becomes_an_item,
               test_numbered_dishes_survive,
               test_a_real_menu_parses_completely,
               test_proposal_marks_the_draft_as_needing_confirmation):
        try:
            fn()
        except Exception as exc:                       # noqa: BLE001
            check(f"{fn.__name__} raised", False, repr(exc))
    if _failed:
        print(f"{_passed} passed, {_failed} failed (menu ingestion)")
        return 1
    print(f"{_passed} passed, 0 failed (menu ingestion)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
