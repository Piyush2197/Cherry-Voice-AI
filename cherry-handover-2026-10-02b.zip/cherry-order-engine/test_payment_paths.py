#!/usr/bin/env python3
"""How a location that is NOT on Square takes payment.

Cherry has an itemized checkout only for Square. For a Toast, Clover or EPIPay
restaurant the supported answer today is Path A of POS_INTEGRATION_PLAN.md: the
menu's `pay_now_threshold_cents` is high, every order is pay-at-pickup, the
ticket reaches the kitchen (staff text + tablet) and the customer pays at the
counter. These tests prove that path really works end to end through the real
server and gateway, that the caller is TOLD how they will pay, that the deploy
checks describe it honestly instead of staying silent, and that adding a real
checkout provider later is one registry entry.
"""

from __future__ import annotations

import contextlib
import io
import json
import re
import tempfile
import traceback
from pathlib import Path

import go_live
import menu_schema as ms
import pilot_deploy as pd
import rehearsal
import server
from order_store import OrderStore

HERE = Path(__file__).resolve().parent
_passed = _failed = 0
BNR = ("bun-n-run-ferndale", "manual", "+12485550222", "+15869805188")


def check(name, cond, detail=""):
    global _passed, _failed
    if cond:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


def menu_with_threshold(cents: int) -> Path:
    text = (HERE / "menus" / "bun-n-run-ferndale.yaml").read_text()
    text, n = re.subn(r"pay_now_threshold_cents: \d+", f"pay_now_threshold_cents: {cents}", text)
    assert n == 1
    path = Path(tempfile.mkdtemp()) / "menu.yaml"
    path.write_text(text)
    return path


def location(menu: Path, pos_type="manual_fallback") -> pd.Location:
    return pd.Location(id="bun-n-run-ferndale", group="bun-n-run", name="Bun N Run Burger (Ferndale)", menu=menu,
                       catalog_status="ready", inbound_env="CHERRY_INBOUND_BUN_N_RUN_FERNDALE",
                       fallback_phone="+15869805188", pos_type=pos_type)


def t_the_payment_mode_comes_from_the_menu() -> None:
    for cents, want in ((0, "pay_now"), (3000, "mixed"), (49999, "mixed"), (50000, "pay_at_pickup"), (1_000_000, "pay_at_pickup")):
        got = pd.payment_mode(location(menu_with_threshold(cents)))
        check(f"a ${cents / 100:,.2f} threshold is {want}", got == want, got)
    check("a location with no menu file is treated as pay-now (the cautious reading)",
          pd.payment_mode(pd.Location(id="x", group="g", name="x", menu=None, catalog_status="ready", inbound_env="E",
                                      fallback_phone="+1", pos_type="manual_fallback")) == "pay_now")
    real = {l.id: pd.payment_mode(l) for l in pd.load_manifest()}
    check("the shipped menus are all pay-now today (an owner decision, not changed here)", set(real.values()) == {"pay_now"}, str(real))


def t_go_live_describes_the_non_square_payment_path() -> None:
    def run(cents, pos="manual_fallback"):
        rep = go_live.Report()
        go_live.check_payment_paths(rep, [location(menu_with_threshold(cents), pos)])
        return rep.checks
    c = run(1_000_000)[0]
    check("pay-at-pickup passes and says how the customer pays", c.status == go_live.PASS and "pays at the counter" in c.detail, str(c))
    c = run(0)[0]
    check("pay-now with no provider is WAITING, saying every call would go to staff, and names the three ways out",
          c.status == go_live.WAITING and "every call would be transferred" in c.detail and "(A)" in c.fix and "(B)" in c.fix and "(C)" in c.fix, str(c))
    c = run(3000, "toast")[0]
    check("a mixed threshold says only the big orders go to staff", c.status == go_live.WAITING and "over the pay-now threshold" in c.detail and "toast" in c.detail, str(c))
    rep = go_live.Report()
    go_live.check_payment_paths(rep, [location(menu_with_threshold(0), "square")])
    check("a Square location is not this check's business", rep.checks == [])
    rep = go_live.Report()
    go_live.check_payment_paths(rep, [pd.Location(id="x", group="g", name="x", menu=Path("/nonexistent.yaml"), catalog_status="ready",
                                                  inbound_env="E", fallback_phone="+1", pos_type="toast")])
    check("an unreadable menu is a plain WAITING (pay-now), not a crash", rep.checks[0].status == go_live.WAITING)


def t_checkout_ready_for_a_pay_at_pickup_location_needs_only_the_staff_text() -> None:
    db = tempfile.mkdtemp() + "/c.db"
    s = OrderStore.sqlite(db)
    s.upsert_restaurant("bun-n-run-ferndale", "Bun N Run Burger (Ferndale)", "burgers", sink="manual", tax_rate_bps=600,
                        staff_phone="+13135550100", active=True)
    s.close()

    def ready(cents, env):
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            rc = pd.checkout_ready([location(menu_with_threshold(cents))], db, env)
        return rc, buf.getvalue()
    rc, out = ready(1_000_000, {"TELNYX_API_KEY": "k", "TELNYX_FROM_NUMBER": "+12485550100"})
    check("pay-at-pickup with the Telnyx settings is CONFIGURED, with no Square variables asked for",
          rc == 0 and "CONFIGURED" in out and "pay at pickup" in out and "SQUARE" not in out, out)
    rc, out = ready(1_000_000, {})
    check("…but without Telnyx the staff text cannot go out: BLOCKED naming only Telnyx",
          rc == 2 and "TELNYX_API_KEY" in out and "SQUARE" not in out and "itemized" not in out, out)
    rc, out = ready(0, {"TELNYX_API_KEY": "k", "TELNYX_FROM_NUMBER": "+12485550100"})
    check("a pay-now non-Square location stays BLOCKED, as before", rc == 2 and "itemized_square_checkout_not_connected" in out, out)
    rc, out = ready(3000, {"TELNYX_API_KEY": "k", "TELNYX_FROM_NUMBER": "+12485550100"})
    check("a mixed threshold is BLOCKED too (a big order would have no checkout)", rc == 2 and "itemized_square_checkout_not_connected" in out, out)


def t_a_non_square_location_takes_an_order_as_pay_at_pickup_end_to_end() -> None:
    st = rehearsal.Stack(extra_locations=(BNR,))
    try:
        y = (HERE / "menus" / "bun-n-run-ferndale.yaml").read_text()
        cfg = ms.load_yaml(HERE / "menus" / "bun-n-run-ferndale.yaml")
        st.store.publish_menu("bun-n-run-ferndale", re.sub(r"pay_now_threshold_cents: \d+", "pay_now_threshold_cents: 1000000", y),
                              item_count=len(cfg.items))
        code, g = st.call("pap-1", to=BNR[2], frm="+13135550123")
        check("the call is answered by Lily, not handed to staff", code == 200 and not g.get("handoff_required") and "Bun N Run" in g["say"], str(g)[:200])
        for tool, args in (("add_item", {"text": "double cheeseburger"}), ("confirm_mods", {}), ("ready_to_place", {}),
                           ("set_name", {"text": "Sam"}), ("note_allergy", {"text": "no allergies"})):
            st.tool("pap-1", tool, **args)
        _c, rb = st.tool("pap-1", "ready_to_place")
        check("the read-back says what it costs, when it is ready, AND that they pay when they pick it up",
              "$10.59" in rb["say"] and "ready in about" in rb["say"] and "pay when you pick it up" in rb["say"], rb["say"])
        code, done = st.finish("pap-1")
        say = done["say"]
        check("the closing line says so exactly once, and thanks Sam", say.count("pay when you pick it up") == 1 and "calling, Sam" in say, say)
        check("no checkout link is promised or sent", "checkout" not in say.lower() and "texted" not in say.lower(), say)
        row = st.store.conn.execute('SELECT o.short_code, o.status, d.status AS delivery, p.status AS pay FROM "order" o '
                                    "LEFT JOIN order_delivery d ON d.order_id=o.id LEFT JOIN payment p ON p.order_id=o.id").fetchone()
        check("the order is placed and delivered to the kitchen, and no payment is required",
              row is not None and row["delivery"] == "sent" and row["pay"] == "not_required", str(dict(row) if row else None))
        ticket = [m for m in st.fake.sms if m["to"] == BNR[3]]
        check("the staff text carries the itemized ticket marked PAY AT PICKUP",
              len(ticket) == 1 and "PAY AT PICKUP" in ticket[0]["text"] and "1x Double Cheeseburger" in ticket[0]["text"]
              and "TOTAL                           $10.59" in ticket[0]["text"], str(ticket)[:300])
        check("the customer was sent nothing to pay", not [m for m in st.fake.sms if m["to"] == "+13135550123"], str(st.fake.sms)[:200])
        import urllib.request
        key = server.kds_key("apikey", "bun-n-run-ferndale")
        with rehearsal.REAL_URLOPEN(f"http://127.0.0.1:{st.sport}/kds/orders?r=bun-n-run-ferndale&k={key}", timeout=20) as r:
            feed = json.loads(r.read())
        check("the kitchen tablet shows the order immediately", [o["code"] for o in feed["orders"]] == [row["short_code"]] and feed["orders"][0]["lines"][0]["name"] == "Double Cheeseburger", str(feed)[:300])
    finally:
        st.close()


def t_a_pay_now_non_square_location_still_goes_to_staff_up_front() -> None:
    st = rehearsal.Stack(extra_locations=(BNR,))
    try:
        code, g = st.call("pn-1", to=BNR[2], frm="+13135550123")
        check("with the shipped (pay-now) menu the caller is connected to the restaurant before any ordering",
              "isn't available at this location yet" in g["say"] and "connect you with the restaurant" in g["say"], str(g)[:200])
        check("…and the refusal is logged with the sink, so ops can see which locations this affects",
              any(e["kind"] == "call.refused_no_checkout" and json.loads(e["detail"]).get("sink") == "manual" for e in st.store.events()))
    finally:
        st.close()


def t_a_checkout_provider_is_one_registry_entry() -> None:
    class Row(dict):
        pass
    calls = []

    class ToastLike:
        name = "toast"

    def factory(row):
        calls.append(row["id"])
        return ToastLike()

    app = server.Cherry(OrderStore.sqlite(), api_key="k")
    row = Row(id="r1", sink="toast")
    check("an unregistered sink has no checkout provider", app.checkout_provider_for(row) is None)
    server.CHECKOUT_PROVIDERS["toast"] = factory
    try:
        got = app.checkout_provider_for(row)
        check("registering a factory makes the server use it for that sink", isinstance(got, ToastLike) and calls == ["r1"])
        server.CHECKOUT_PROVIDERS["toast"] = lambda r: (_ for _ in ()).throw(ValueError("not authorized"))
        check("a factory that raises (not configured) yields no provider, never a crash", app.checkout_provider_for(row) is None)
        check("Square is registered out of the box", "square" in server.CHECKOUT_PROVIDERS)
        check("the single-provider override still wins", (setattr(app, "pay_provider", "X") or app.checkout_provider_for(row)) == "X")
    finally:
        server.CHECKOUT_PROVIDERS.pop("toast", None)


def main() -> int:
    global _failed
    for name, fn in sorted((k, v) for k, v in globals().items() if k.startswith("t_")):
        try:
            fn()
        except Exception:                                    # noqa: BLE001
            _failed += 1
            print(f"\n--- FAIL {name} raised")
            traceback.print_exc()
    print(f"{_passed} passed, {_failed} failed (payment paths for non-Square locations)")
    return 1 if _failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
