#!/usr/bin/env python3
"""
Pre-onboard the sales route — turn the field plan into a working demo line.

WHY THIS EXISTS
---------------
The pitch is a live demo at the counter, and the field plan is the route. What
was missing is the step between them: standing in front of a restaurateur with
their cuisine already answering the phone, before they have signed anything.

This reads the field-plan workbook, takes every prospect on it, works out what
they cook, attaches the closest demo menu we have, gives each one a short code
for the demo line, and reports honestly where we have no menu to show at all.
Run it the night before a route and the whole day is already on the phone.

    python3 cherry.py prospect --plan ../sales/cherry-clinton-first-field-plan-v2.xlsx
    python3 cherry.py prospect --plan … --day 2      # just Tuesday's stops
    python3 cherry.py prospect --plan … --json       # for a print sheet

THE HONEST PART
---------------
A cuisine guess from a restaurant's name is a guess, and a demo shown to an
owner is a claim. So every assignment is labelled:

  * `their_menu`   — built from a menu the owner actually gave us. Only this one
                     may be called "your menu" at the counter.
  * `cuisine_demo` — the closest cuisine we have. Says so, on screen, in the
                     registry, and in `demo_line.py`.

And where we have **no** menu in that cuisine, this refuses to invent one. It
reports the gap. Walking into five Asian restaurants with no Asian demo is a
thing to know the night before, not at the counter.
"""

from __future__ import annotations

import _ensure_deps  # noqa: F401  (re-runs under .venv, or says how to install, if PyYAML is missing)
import argparse
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import yaml

from demo_line import DemoEntry, DemoLineError, load_line, save_line

ROOT = Path(__file__).resolve().parent

# ---------------------------------------------------------------------------
# Cuisine from a name and an angle
# ---------------------------------------------------------------------------

#: Ordered: the first cuisine whose keyword appears wins, so put the specific
#: ones first. "Pizza" before "italian" so a pizzeria gets the pizza menu.
CUISINE_KEYWORDS: List[Tuple[str, Tuple[str, ...]]] = [
    ("thai", ("thai",)),
    ("chinese", ("chinese", "china", "wok", "hong kong", "szechuan",
                 "sichuan", "panda", "asian", "mandarin")),
    ("japanese", ("sushi", "japanese", "teriyaki", "hibachi", "ramen",
                  "izakaya")),
    ("korean", ("korean", "seoul", "kimchi")),
    ("indian", ("indian", "curry", "tandoor", "kaveri", "biryani", "masala")),
    ("mexican", ("mexican", "taco", "cantina", "burrito", "miguel", "taqueria",
                 "el ", "dos ", "los ")),
    ("pizza", ("pizza", "pizzeria", "pizzeria", "slice")),
    ("italian", ("italian", "pasta", "trattoria", "osteria", "ristorante",
                 "luciano", "aurelio", "nonna")),
    ("mediterranean", ("mediterranean", "greek", "gyro", "shawarma", "kabob",
                       "kebab", "falafel", "hummus", "pita")),
    ("seafood", ("seafood", "fish", "crab", "lobster", "oyster")),
    ("burger", ("burger", "cheeseburger", "coney")),
    ("american", ("diner", "deli", "bbq", "barbecue", "cheesesteak", "grill",
                  "pancake", "family restaurant", "kitchen", "cantina",
                  "restaurant")),
]

#: Cuisine -> a demo menu in `menus/`. Every cuisine recognised above must have
#: one, or `prospect` reports the stop as a gap rather than substituting a menu
#: that would be wrong in front of an owner.
CUISINE_DEMO_MENU: Dict[str, str] = {
    "burger": "menus/burger_template.yaml",
    "mexican": "menus/casa_verde.yaml",
    "japanese": "menus/kaiso_sushi.yaml",
    "korean": "menus/seoul_stone.yaml",
    "indian": "menus/saffron_house.yaml",
    "italian": "menus/trattoria_nonna.yaml",
    "mediterranean": "menus/olive_ember.yaml",
    "pizza": "menus/vesuvio.yaml",
    # Added 2026-09-30 after the first run of this tool reported that 14 of 27
    # stops on the Clinton route had nothing to demo: four Chinese, two Thai and
    # eight unrecognised American independents. Three menus closed the gap.
    "chinese": "menus/demo-chinese.yaml",
    "thai": "menus/demo-thai.yaml",
    "american": "menus/demo-american.yaml",
}

#: Used when the name and angle give us nothing. An American diner/deli menu is
#: the safest generic for a US independent, and the entry is still labelled a
#: cuisine demo — but the report separates this from a real cuisine match so the
#: rep knows the menu is a guess.
FALLBACK_CUISINE = "american"


def guess_cuisine(name: str, angle: str = "") -> str:
    """Best-effort cuisine from what the field plan recorded.

    Deliberately a keyword table and not a model: it is auditable, it says
    nothing when it does not know, and a wrong answer here is a wrong menu in
    front of an owner.
    """
    hay = f" {name} {angle} ".lower()
    for cuisine, words in CUISINE_KEYWORDS:
        for w in words:
            if w in hay:
                return cuisine
    return ""


# ---------------------------------------------------------------------------
# Reading the field plan
# ---------------------------------------------------------------------------

#: The sheet and the column names it uses. Confirmed against
#: cherry-clinton-first-field-plan-v2.xlsx on 2026-09-30.
SHEET = "Clinton first"
COLUMNS = {"day": "Day", "stop": "Stop", "name": "Restaurant",
           "address": "Address", "phone": "Phone", "status": "Status",
           "tier": "Tier", "platform": "Platform group",
           "angle": "Angle for the conversation"}


@dataclass
class Prospect:
    name: str
    day: int = 0
    stop: int = 0
    address: str = ""
    phone: str = ""
    status: str = ""
    tier: str = ""
    platform: str = ""
    angle: str = ""
    cuisine: str = ""
    #: True when the cuisine came from a keyword in the name/angle; False when
    #: it fell back to the generic menu. Reported separately so a rep knows
    #: which demos are a real match and which are a best guess.
    cuisine_matched: bool = False
    menu: str = ""
    code: str = ""

    @property
    def is_pitchable(self) -> bool:
        return self.status.strip().lower() in ("prospect", "brand route")


def read_plan(path: Path, sheet: str = SHEET) -> List[Prospect]:
    try:
        from openpyxl import load_workbook
    except ImportError as exc:                          # noqa: BLE001
        raise DemoLineError(
            "reading the field plan needs openpyxl: "
            "pip install -r requirements.txt") from exc
    wb = load_workbook(path, data_only=True, read_only=True)
    if sheet not in wb.sheetnames:
        raise DemoLineError(f"{path.name} has no {sheet!r} sheet; found "
                            f"{', '.join(wb.sheetnames[:8])}…")
    ws = wb[sheet]
    rows = ws.iter_rows(values_only=True)
    header = None
    idx: Dict[str, int] = {}
    for row in rows:
        cells = ["" if c is None else str(c).strip() for c in row]
        if header is None:
            # The sheet opens with title and note rows; the header is the row
            # that actually carries the column names.
            if COLUMNS["name"] in cells and COLUMNS["status"] in cells:
                header = cells
                idx = {k: cells.index(v) for k, v in COLUMNS.items()
                       if v in cells}
            continue
        if not any(cells):
            continue
        def get(key: str) -> str:
            i = idx.get(key)
            return cells[i] if i is not None and i < len(cells) else ""
        name = get("name")
        if not name:
            continue
        yield_ = Prospect(
            name=name, address=get("address"), phone=get("phone"),
            status=get("status"), tier=get("tier"), platform=get("platform"),
            angle=get("angle"))
        for key, attr in (("day", "day"), ("stop", "stop")):
            raw = get(key)
            m = re.match(r"^\s*(\d+)", raw or "")
            if m:
                setattr(yield_, attr, int(m.group(1)))
        yield yield_


# ---------------------------------------------------------------------------
# Building the line
# ---------------------------------------------------------------------------


def code_for(index: int) -> str:
    """A short, typeable code. Two digits once past the tenth stop.

    Three digits from 101 rather than 001: a leading zero is the one thing
    people get wrong typing into a phone, and it costs nothing to avoid.
    """
    return str(100 + index) if index < 100 else str(index)


def slugify(name: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    return s[:48] or "prospect"


def personalise(prospect: Prospect, cuisine_menu: str,
                outdir: Path) -> str:
    """A copy of the cuisine menu that greets with THIS restaurant's name.

    This is the whole difference between a nice demo and one that lands. The
    owner dials, and hears their own restaurant answer — not "Saffron House
    Indian Kitchen" when they run Kaveri.

    What it is NOT: a claim about their menu. The items and prices stay the
    generic cuisine demo, the notes field says so in the file, `menu_kind` stays
    `cuisine_demo` in the registry, and `demo_line.py` prints the warning before
    the first word is spoken. The name is borrowed for 90 seconds; nothing else
    is.
    """
    doc = yaml.safe_load((ROOT / cuisine_menu).read_text())
    slug = slugify(prospect.name)
    doc["restaurant"]["id"] = f"demo-{slug}"[:48]
    doc["restaurant"]["name"] = prospect.name
    doc["restaurant"]["notes"] = (
        f"PERSONALISED DEMO for {prospect.name} ({prospect.address}). "
        f"Items and prices are the generic {prospect.cuisine} demo menu and are "
        f"NOT this restaurant's menu or prices. Built {prospect.day and 'for route day ' + str(prospect.day) or 'from the field plan'}. "
        f"Never present as their menu; never take a real order on it.")
    outdir.mkdir(parents=True, exist_ok=True)
    path = outdir / f"{slug}.yaml"
    path.write_text(yaml.safe_dump(doc, sort_keys=False, allow_unicode=True,
                                   width=100))
    # Relative when it lives in the repo (so the registry stays portable),
    # absolute otherwise. `DemoEntry.menu_path` joins with ROOT, and pathlib
    # treats an absolute right-hand side as already absolute, so both work.
    try:
        return str(path.resolve().relative_to(ROOT))
    except ValueError:
        return str(path.resolve())


def build_line(prospects: Sequence[Prospect], *,
               personalise_dir: Optional[Path] = None
               ) -> Tuple[List[DemoEntry], List[Prospect]]:
    """(entries, gaps) — gaps are pitchable stops with no menu we can show."""
    entries: List[DemoEntry] = []
    gaps: List[Prospect] = []
    n = 0
    for p in prospects:
        if not p.is_pitchable:
            continue
        p.cuisine = guess_cuisine(p.name, p.angle)
        matched = bool(p.cuisine)
        if not matched:
            p.cuisine = FALLBACK_CUISINE
        p.cuisine_matched = matched
        menu = CUISINE_DEMO_MENU.get(p.cuisine, "")
        if not menu:
            gaps.append(p)
            continue
        n += 1
        p.menu = menu
        p.code = code_for(n)
        if personalise_dir is not None:
            # Point the entry at a copy that greets with their name. Still
            # labelled `cuisine_demo`: the name is borrowed, the menu is not
            # theirs until someone ingests it.
            p.menu = personalise(p, menu, personalise_dir)
        entries.append(DemoEntry(
            code=p.code, name=p.name, menu=p.menu, menu_kind="cuisine_demo",
            day=p.day, tier=p.tier, phone=p.phone, address=p.address,
            platform=p.platform,
            angle=(p.angle if len(p.angle) < 160 else p.angle[:157] + "...")))
    return entries, gaps


def route_sheet(entries: Sequence[DemoEntry]) -> str:
    out = []
    for day in sorted({e.day for e in entries}):
        rows = [e for e in entries if e.day == day]
        out.append(f"\nDAY {day} — {len(rows)} demo(s) armed")
        for e in rows:
            out.append(f"  code {e.code}   {e.name}")
            out.append(f"            {e.address}")
            out.append(f"            {e.phone or '(no phone on the plan)'}"
                       f"   {e.platform or ''}")
    return "\n".join(out)


def main(argv: Optional[Sequence[str]] = None) -> int:
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--plan", required=True, help="field-plan .xlsx")
    ap.add_argument("--sheet", default=SHEET)
    ap.add_argument("--day", type=int, default=0, help="limit to a route day")
    ap.add_argument("--out", default=str(ROOT / "demos" / "demo-line.yaml"))
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--dry-run", action="store_true",
                    help="report the gaps without touching the registry")
    ap.add_argument("--no-personalise", action="store_true",
                    help="use the shared cuisine menu instead of a copy that "
                         "greets with each restaurant's own name")
    args = ap.parse_args(argv)

    try:
        prospects = list(read_plan(Path(args.plan), args.sheet))
    except DemoLineError as exc:
        print(f"cannot read the plan: {exc}")
        return 2
    if args.day:
        prospects = [p for p in prospects if p.day == args.day]

    pdir = (None if args.no_personalise
            else ROOT / "demos" / "prospects")
    entries, gaps = build_line(prospects, personalise_dir=pdir)
    pitchable = [p for p in prospects if p.is_pitchable]

    if args.json:
        print(json.dumps({
            "prospects": len(pitchable),
            "armed": len(entries),
            "gaps": [{"name": g.name, "cuisine": g.cuisine or "unknown",
                      "day": g.day} for g in gaps],
            "entries": [e.__dict__ for e in entries],
        }, indent=2))
    else:
        print(f"Field plan: {len(prospects)} stop(s) read, "
              f"{len(pitchable)} pitchable")
        print(f"Armed on the demo line: {len(entries)}")
        print(route_sheet(entries))
        if gaps:
            print(f"\n\033[31mNO DEMO MENU for {len(gaps)} stop(s)\033[0m — "
                  f"these are pitchable and we have nothing to show them:")
            for g in gaps:
                print(f"  {g.name:34} cuisine: {g.cuisine or 'unrecognised'}"
                      f"   day {g.day}")
            missing = sorted({g.cuisine or "unrecognised" for g in gaps})
            print(f"\n  Missing cuisines: {', '.join(missing)}")
            print(f"  Build one menu each and every stop on the route is "
                  f"demoable. Until then, demo the closest cuisine and say so.")
        else:
            print(f"\n\033[32mEvery pitchable stop has a demo menu.\033[0m")

        guessed = [e for e in entries
                   if not next((p.cuisine_matched for p in prospects
                                if p.name == e.name), True)]
        if guessed:
            print(f"\n\033[33m{len(guessed)} stop(s) fell back to the generic "
                  f"American menu\033[0m — the name gave no cuisine. The demo "
                  f"still works; say 'closest menu we have', not 'yours':")
            for e in guessed:
                print(f"  {e.code}  {e.name}")

    if args.dry_run:
        return 0
    try:
        save_line(entries, Path(args.out))
    except DemoLineError as exc:
        print(f"could not write the line: {exc}")
        return 2
    print(f"\nwrote {args.out}  ({len(entries)} entries)")
    print("Check it:  python3 demo_line.py list")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
