#!/usr/bin/env python3
"""
The nightly developer brief.

    python3 nightly_brief.py --db cherry.db -o briefs/

Written every night so the developers wake up knowing what happened and what
to do. Everything in it is READ FROM THE REPO AND THE DATABASE, never from
anyone's memory — that is the whole point. A hand-written standup note drifts
from reality within a week; this cannot, because if the code changes the brief
changes with it.

WHAT GOES IN, AND WHY EACH SECTION EARNS ITS PLACE
--------------------------------------------------
1. LAST NIGHT'S SERVICE   calls, orders, failures, escalations. If something
                          broke at 7pm, this is where a developer sees it
                          before the owner phones.
2. WHAT NEEDS A HUMAN     unacknowledged orders, escalated calls, failed SMS,
                          POS changes waiting for review. This is the work
                          queue, ordered by whether a customer is affected.
3. HEALTH                 test count, restaurants live, menus that would fail
                          the gate today.
4. THE TASK LIST          open work with owners, read from TASKS.md.
5. WHAT CHANGED           new/modified files since the last brief, so a
                          developer picking up after a day off can see it.

WHAT IS DELIBERATELY NOT IN IT
------------------------------
No invented priorities, no "team velocity", no guesses about how long
anything will take. A brief that editorialises gets ignored; one that only
states facts gets read.
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

HERE = Path(__file__).parent


# ---------------------------------------------------------------------------
# Sources of truth
# ---------------------------------------------------------------------------


def _iso(dt: datetime) -> str:
    return dt.isoformat(timespec="seconds")


def service_report(store, since_hours: int = 24) -> Dict[str, Any]:
    """What actually happened on the phone last night."""
    since = _iso(datetime.now(timezone.utc) - timedelta(hours=since_hours))
    q = store.conn.execute

    calls = q("SELECT COUNT(*) c FROM session WHERE started_at > ?",
              (since,)).fetchone()["c"]
    orders = q('SELECT COUNT(*) c, COALESCE(SUM(total_cents),0) t '
               'FROM "order" WHERE placed_at > ?', (since,)).fetchone()
    escalated = q("SELECT restaurant_id, escalation_reason, started_at "
                  "FROM session WHERE escalated_at > ? "
                  "ORDER BY started_at DESC LIMIT 20", (since,)).fetchall()
    abandoned = q("SELECT COUNT(*) c FROM session WHERE ended_at > ? "
                  "AND end_reason IN ('abandoned','no_order','timed_out')",
                  (since,)).fetchone()["c"]

    # What the engine objected to, ranked. This is the accuracy signal.
    issues = q("""SELECT engine_issue_code code, COUNT(*) n FROM turn
                  WHERE created_at > ? AND engine_issue_code IS NOT NULL
                  GROUP BY engine_issue_code ORDER BY n DESC LIMIT 10""",
               (since,)).fetchall()

    slow = q("""SELECT MAX(latency_ms) m, AVG(latency_ms) a FROM turn
                WHERE created_at > ? AND latency_ms IS NOT NULL""",
             (since,)).fetchone()

    failed_sms = q("SELECT to_phone, kind, error_detail FROM sms_message "
                   "WHERE created_at > ? AND status='failed' LIMIT 20",
                   (since,)).fetchall()

    per_rest = q("""SELECT restaurant_id, COUNT(*) n FROM session
                    WHERE started_at > ? GROUP BY restaurant_id
                    ORDER BY n DESC""", (since,)).fetchall()

    return {
        "calls": calls,
        "orders": orders["c"],
        "revenue_cents": orders["t"],
        "abandoned": abandoned,
        "conversion": (orders["c"] / calls * 100) if calls else 0.0,
        "escalated": [dict(r) for r in escalated],
        "issues": [dict(r) for r in issues],
        "max_latency_ms": slow["m"],
        "avg_latency_ms": slow["a"],
        "failed_sms": [dict(r) for r in failed_sms],
        "per_restaurant": [dict(r) for r in per_rest],
    }


def needs_a_human(store) -> List[Dict[str, str]]:
    """The work queue, ordered by whether a customer is affected."""
    from ops_monitor import scan_alerts
    out = [{"urgency": "NOW" if a.severity == "critical" else "SOON",
            "what": a.title, "why": a.detail, "how": a.action}
           for a in scan_alerts(store)]

    sender_bad = store.conn.execute(
        "SELECT COUNT(*) c FROM event WHERE kind='sms.sender_not_ready'"
    ).fetchone()["c"]
    if sender_bad:
        out.append({
            "urgency": "NOW",
            "what": "Telnyx reported the sending number is not provisioned",
            "why": "EVERY outbound SMS will fail until this is fixed — "
                   "10DLC campaign assignment",
            "how": "GET /v2/10dlc/phone_number_campaigns/{number}"})

    suppressed = store.conn.execute(
        "SELECT COUNT(*) c FROM sms_suppression").fetchone()["c"]
    if suppressed:
        out.append({
            "urgency": "FYI",
            "what": f"{suppressed} number(s) have opted out of SMS",
            "why": "they will never receive a pay link; orders need another route",
            "how": "expected and legally required — no action unless it grows"})
    return out


def menu_health() -> List[Dict[str, str]]:
    """Which menus would fail the gate today."""
    out = []
    try:
        import menu_schema as ms
        from readiness import assess, BLOCKER, GAP
        for path in sorted((HERE / "menus").glob("*.yaml")):
            try:
                cfg = ms.load_yaml(path)
            except Exception as exc:                  # noqa: BLE001
                out.append({"menu": path.stem, "level": "BROKEN",
                            "what": f"will not load: {exc}"})
                continue
            for f in assess(cfg, None):
                if f.level in (BLOCKER, GAP) and "not deployed" not in f.what:
                    out.append({"menu": cfg.id, "level": f.level,
                                "what": f.what, "owner": f.owner})
    except Exception as exc:                          # noqa: BLE001
        out.append({"menu": "-", "level": "ERROR",
                    "what": f"readiness check failed: {exc}"})
    return out


def test_health() -> Dict[str, Any]:
    """Run the suites. A brief that says 'tests pass' without running them
    is worse than no brief."""
    # Discover every suite so a new safety check cannot be silently omitted
    # from the nightly health total.
    suites = [path.name for path in sorted(HERE.glob("test_*.py"))]
    total = failed = 0
    broken: List[str] = []
    for s in suites:
        if not (HERE / s).exists():
            continue
        try:
            r = subprocess.run([sys.executable, s], cwd=HERE, capture_output=True,
                               text=True, timeout=400)
            line = [l for l in r.stdout.splitlines() if "passed," in l]
            if not line:
                broken.append(f"{s}: produced no result line")
                continue
            parts = line[-1].split()
            total += int(parts[0])
            f = int(parts[2])
            failed += f
            if f:
                broken.append(f"{s}: {f} FAILING")
        except subprocess.TimeoutExpired:
            broken.append(f"{s}: timed out")
        except Exception as exc:                      # noqa: BLE001
            broken.append(f"{s}: {exc}")
    return {"passing": total, "failing": failed, "broken": broken}


def open_tasks() -> List[str]:
    """Unchecked items from TASKS.md.

    Only a real checklist counts. Scraping prose tables out of a status doc
    produces a task list that is quietly months out of date, which is worse
    than none — so if TASKS.md does not exist, this section is simply absent.
    """
    p = HERE / "TASKS.md"
    if not p.exists():
        return []
    return [l.rstrip() for l in p.read_text().splitlines()
            if l.strip().startswith("- [ ]")][:25]


def recent_changes(hours: int = 24) -> List[str]:
    cutoff = datetime.now().timestamp() - hours * 3600
    out = []
    for p in sorted(HERE.glob("*.py")) + sorted(HERE.glob("*.md")):
        try:
            if p.stat().st_mtime > cutoff:
                out.append(f"{p.name}  ({datetime.fromtimestamp(p.stat().st_mtime):%H:%M})")
        except OSError:
            pass
    return out


# ---------------------------------------------------------------------------
# Rendering
# ---------------------------------------------------------------------------


def render(store, *, hours: int = 24, run_tests: bool = True) -> str:
    now = datetime.now(timezone.utc)
    L: List[str] = []
    w = L.append

    w(f"# Cherry — developer brief, {now:%Y-%m-%d}")
    w("")
    w(f"Generated {now:%H:%M} UTC from the live database and the repo. "
      f"Nothing here is hand-written.")
    w("")

    # --- 1. the work queue, first, because it is what someone acts on ---
    queue = needs_a_human(store) if store else []
    w("## Needs a human")
    w("")
    if not queue:
        w("Nothing outstanding.")
    else:
        for q in sorted(queue, key=lambda x: 0 if x["urgency"] == "NOW" else 1):
            w(f"**[{q['urgency']}] {q['what']}**  ")
            w(f"{q['why']}  ")
            w(f"`{q['how']}`")
            w("")
    w("")

    # --- 2. last night ---------------------------------------------------
    if store:
        s = service_report(store, hours)
        w(f"## Last {hours} hours on the phone")
        w("")
        if not s["calls"]:
            w("No calls. If that is unexpected, check the Telnyx number is "
              "pointed at the server and the server is up (`GET /health`).")
        else:
            w(f"| | |")
            w(f"|---|---|")
            w(f"| Calls | {s['calls']} |")
            w(f"| Orders | {s['orders']} ({s['conversion']:.0f}% conversion) |")
            w(f"| Order value | ${s['revenue_cents']/100:,.2f} |")
            w(f"| Abandoned | {s['abandoned']} |")
            if s["max_latency_ms"]:
                w(f"| Engine latency | {s['avg_latency_ms']:.1f}ms avg, "
                  f"{s['max_latency_ms']}ms worst |")
            w("")
            if s["per_restaurant"]:
                w("By restaurant: " + ", ".join(
                    f"{r['restaurant_id']} {r['n']}" for r in s["per_restaurant"]))
                w("")
            if s["issues"]:
                w("**What the engine objected to** — this is the accuracy signal. "
                  "A code climbing week on week is a real problem.")
                w("")
                w("| code | times |")
                w("|---|---|")
                for i in s["issues"]:
                    w(f"| {i['code']} | {i['n']} |")
                w("")
            if s["escalated"]:
                w(f"**{len(s['escalated'])} escalated call(s)** — a human had to "
                  f"take over:")
                w("")
                for e in s["escalated"][:10]:
                    w(f"- {e['restaurant_id']}: {e['escalation_reason']}")
                w("")
            if s["failed_sms"]:
                w(f"**{len(s['failed_sms'])} SMS failed:**")
                w("")
                for f in s["failed_sms"][:10]:
                    w(f"- {f['kind']} to {f['to_phone']}: {f['error_detail']}")
                w("")
    w("")

    # --- 3. health -------------------------------------------------------
    w("## Health")
    w("")
    if run_tests:
        t = test_health()
        if t["failing"]:
            w(f"**{t['failing']} TESTS FAILING** out of {t['passing'] + t['failing']}. "
              f"Fix before anything else ships.")
            for b in t["broken"]:
                w(f"- {b}")
        else:
            w(f"{t['passing']} tests passing, 0 failing.")
        for b in t["broken"]:
            if "FAILING" not in b:
                w(f"- {b}")
    else:
        w("(tests not run — pass --tests to include them)")
    w("")

    mh = menu_health()
    if mh:
        blockers = [m for m in mh if m["level"] == "BLOCKER"]
        if blockers:
            w(f"**{len(blockers)} menu blocker(s):**")
            for m in blockers[:10]:
                w(f"- {m['menu']}: {m['what']}")
            w("")
        gaps = [m for m in mh if m["level"] == "GAP"]
        if gaps:
            w(f"{len(gaps)} menu gap(s) — will take calls but fail some:")
            for m in gaps[:10]:
                w(f"- {m['menu']}: {m['what']}")
            w("")
    w("")

    # --- 4. open work ----------------------------------------------------
    tasks = open_tasks()
    if tasks:
        w("## Open tasks")
        w("")
        for t in tasks:
            w(t)
        w("")

    # --- 5. what moved ---------------------------------------------------
    ch = recent_changes(hours)
    if ch:
        w(f"## Changed in the last {hours}h")
        w("")
        for c in ch:
            w(f"- {c}")
        w("")

    w("---")
    w("")
    w("Regenerate: `python3 nightly_brief.py --db cherry.db`")
    return "\n".join(L)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--db", help="the live database; omitted = repo health only")
    ap.add_argument("-o", "--out", default="briefs",
                    help="directory to write the brief into")
    ap.add_argument("--hours", type=int, default=24)
    ap.add_argument("--tests", action="store_true",
                    help="run the suites (slow, but it is the point)")
    ap.add_argument("--stdout", action="store_true")
    args = ap.parse_args()

    store = None
    if args.db and (args.db.startswith(("postgres://", "postgresql://")) or
                    os.path.exists(args.db)):
        from order_store import OrderStore
        store = OrderStore.open(args.db)

    text = render(store, hours=args.hours, run_tests=args.tests)

    if args.stdout:
        print(text)
        return 0
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    path = out / f"{datetime.now(timezone.utc):%Y-%m-%d}-brief.md"
    path.write_text(text)
    print(f"wrote {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
