"""
Menu ingestion — turn raw menu text into a config DRAFT plus a confirm-list.

Everything here runs once, at onboarding, on a developer's machine. Nothing
here is imported by order_engine.py and nothing here runs during a call.

The output of propose() is deliberately not a RestaurantConfig. It is a
Proposal: a draft plus an explicit list of things a human must confirm. That
asymmetry is the whole point. A tool that emitted a ready-to-run config would
be guessing prices, and a guessed price is worse than a missing one — a
missing price fails loudly on the first test order, a guessed one bills a
customer.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

from cuisine_library import (
    CUISINES,
    HOMOPHONE_TRAPS,
    Archetype,
    CuisineProfile,
    suggested_aliases,
)
from order_engine import Matcher, RestaurantConfig, normalize


# ---------------------------------------------------------------------------
# Parsing
# ---------------------------------------------------------------------------

_PRICE = re.compile(r"\$\s*(\d{1,4})(?:[.,](\d{2}))?")

# A price with NO dollar sign, at the end of a line: "Harbor Classic  9.50".
# Most pasted, printed and PDF'd menus write prices this way, and requiring a
# "$" made the ingester reject entire real menus — which is precisely how
# "onboarding a restaurant is a coding task" begins. Every one of the bespoke
# per-restaurant builder scripts exists because the generic path could not read
# the owner's menu as it was written.
#
# The pattern is deliberately narrow, because a number misread as a price bills
# a customer:
#   * it must be the LAST thing on the line, so a leading menu number
#     ("29. Butter Chicken") and a street number ("1247 Lakeshore Ave") are safe;
#   * one to three integer digits, so a year ("Est. 2019") is not money;
#   * a qualifier (`.50`) or a bare integer, both of which real menus use.
# Anything it still gets wrong is presented to a human in `propose()`'s
# questions rather than being written into a live config.
_BARE_PRICE_TAIL = re.compile(r"\s(\d{1,3})(?:[.,](\d{2}))?\s*$")

# A price alone on its own line, with or without a "$".
_PRICE_ONLY = re.compile(r"^\s*\$?\s*(\d{1,3})(?:[.,](\d{2}))?\s*$")

# Menu furniture that is not a dish. Without this, "TAX 6%", the restaurant's
# own address and its phone number become unorderable items in the draft.
#
# Two rules were learned the hard way here:
#   * Do NOT match "any line starting with a digit". An earlier version did, and
#     it silently deleted every numbered dish on an Indian menu
#     ("29. Butter Chk. (Creamy)") while the run still reported success. Menu
#     numbers are handled properly by _LEADING_NUM.
#   * Keyword alternatives are anchored to a trailing number or end of line, so
#     a dish legitimately called "Total Eclipse Burger" is not furniture.
#
# These are dropped whether or not they carry a price: a "Subtotal 45.00" line
# is not a dish either.
_METADATA = re.compile(
    r"^\s*(tax|sales tax|tax rate|service charge|gratuity|subtotal|total)"
    r"\b\s*[:$]?\s*\$?\d*\.?\d*\s*%?\s*$"
    r"|^\s*(phone|tel|fax)\b"
    r"|^\s*(www\.|https?:|@)"
    r"|^\s*\(?\d{3}\)?[-.\s]\d{3}[-.\s]\d{4}\s*$"
    r"|^\s*\d{1,6}\s+[A-Za-z0-9.'\- ]+\s+"
    r"(ave|avenue|st|street|rd|road|blvd|boulevard|dr|drive|ln|lane|way|"
    r"hwy|highway|pkwy|parkway|ct|court|pl|place|suite|ste)\b\.?\s*$",
    re.I)
# "29. Butter Chk. (Creamy)" -> leading menu number
_LEADING_NUM = re.compile(r"^\s*(\d{1,3}[a-z]?)\s*[.)-]\s*")


@dataclass
class ParsedItem:
    name: str
    price_cents: Optional[int]
    description: str = ""
    menu_number: str = ""
    section: str = ""
    raw: str = ""


def parse_price(text: str) -> Optional[int]:
    """Cents from a menu line, with a "$" or without one.

    A "$" price anywhere in the line wins, because it is unambiguous. Failing
    that, a bare number is read only at the very end of the line.
    """
    m = _PRICE.search(text)
    if m:
        return int(m.group(1)) * 100 + (int(m.group(2)) if m.group(2) else 0)
    m = _BARE_PRICE_TAIL.search(text) or _PRICE_ONLY.match(text)
    if not m:
        return None
    return int(m.group(1)) * 100 + (int(m.group(2)) if m.group(2) else 0)


def strip_price(text: str) -> str:
    """The line with its price removed — the dish name that remains.

    Uses the same rules as `parse_price`, so a line can never yield a price
    whose text stays behind in the name ("Fries 4.25" -> "Fries", not
    "Fries 4.25").
    """
    stripped = _PRICE.sub("", text)
    if stripped != text:
        return stripped.strip(" -–—\t")
    m = _BARE_PRICE_TAIL.search(text) or _PRICE_ONLY.match(text)
    if not m:
        return text.strip(" -–—\t")
    return text[:m.start()].strip(" -–—\t·.")


def _looks_like_section(line: str) -> bool:
    s = line.strip()
    if not s or len(s) > 40:
        return False
    letters = [c for c in s if c.isalpha()]
    if not letters:
        return False
    # ALL CAPS with no price is how nearly every menu marks a section. A
    # trailing full stop is still a heading — "HARBOR BURGER CO." is a name,
    # not a dish, and treating it as an item put an unorderable row in the
    # draft.
    return (all(c.isupper() for c in letters)
            and parse_price(s) is None
            and not _METADATA.match(s))


def parse_menu_text(text: str) -> List[ParsedItem]:
    """Parse a pasted menu into items.

    Handles the common shape: a name line, an optional description line, and a
    price on its own line or at the end of the name. Deliberately conservative
    — anything it cannot read is returned by propose() as an unparsed line
    rather than silently dropped.
    """
    # Indentation is kept, not stripped: on nearly every real menu the dish is
    # flush left and its description is indented under it. Stripping it lost
    # that distinction and turned every description into an unorderable item.
    raw_lines = text.splitlines()
    items: List[ParsedItem] = []
    section = ""
    pending: Optional[ParsedItem] = None
    desc_parts: List[str] = []

    def flush() -> None:
        nonlocal pending, desc_parts
        if pending is not None:
            pending.description = " ".join(desc_parts).strip()
            items.append(pending)
        pending, desc_parts = None, []

    for line in raw_lines:
        raw = line.strip()
        if not raw:
            continue
        indent = len(line) - len(line.lstrip())
        if _looks_like_section(raw):
            flush()
            section = raw
            continue
        # Phone numbers, tax lines, subtotals and addresses are not dishes.
        # Checked before the price logic so "TAX 6%" is not read as a $6 item,
        # and dropped even when they do carry a price.
        if _METADATA.match(raw):
            flush()
            continue

        price = parse_price(raw)
        stripped_of_price = strip_price(raw)

        if price is not None and not stripped_of_price:
            # a bare price line closes the pending item
            if pending is not None and pending.price_cents is None:
                pending.price_cents = price
                flush()
            continue

        if price is not None and stripped_of_price:
            # name and price on one line
            flush()
            num = ""
            m = _LEADING_NUM.match(stripped_of_price)
            if m:
                num = m.group(1)
                stripped_of_price = _LEADING_NUM.sub("", stripped_of_price)
            items.append(ParsedItem(
                name=stripped_of_price.strip(" .").strip(),
                price_cents=price, menu_number=num, section=section, raw=raw))
            continue

        # No price on this line: a new name, or a description of the dish above.
        if pending is not None:
            desc_parts.append(raw)
            continue
        if indent > 0 and items and not items[-1].description:
            # Indented under a dish that already has its price — this is that
            # dish's description, not a new item. "Angus patty, pickles, harbor
            # sauce" is not a thing a caller can order.
            items[-1].description = raw
            continue
        num = ""
        name = raw
        m = _LEADING_NUM.match(name)
        if m:
            num = m.group(1)
            name = _LEADING_NUM.sub("", name)
        pending = ParsedItem(name=name.strip(" .").strip(),
                             price_cents=None, menu_number=num,
                             section=section, raw=raw)

    flush()
    # items that never got a price are still returned, flagged by price_cents=None
    return items


# ---------------------------------------------------------------------------
# Cuisine detection
# ---------------------------------------------------------------------------


@dataclass
class CuisineGuess:
    cuisine_id: str
    score: float
    evidence: List[str] = field(default_factory=list)


def detect_cuisine(text: str, top: int = 3) -> List[CuisineGuess]:
    """Rank cuisines by how many of their known dishes appear in the text.

    Advisory only. A fusion menu will score two cuisines closely, and that is
    information, not a failure — it means the config will need archetypes from
    both.
    """
    lowered = normalize(text)
    guesses: List[CuisineGuess] = []
    for cid, prof in CUISINES.items():
        hits: List[str] = []
        for d in prof.dishes:
            for key in (d.canonical,) + d.aliases:
                k = normalize(key)
                if len(k) >= 4 and k in lowered:
                    hits.append(d.canonical)
                    break
        signal_hits = [s for s, _ in prof.menu_signals if s in lowered]
        score = len(hits) + 0.5 * len(signal_hits)
        if score:
            ev = [f"dish: {h}" for h in hits[:8]]
            ev += [f"phrase: '{s}'" for s in signal_hits[:4]]
            guesses.append(CuisineGuess(cid, score, ev))
    guesses.sort(key=lambda g: -g.score)
    return guesses[:top]


# ---------------------------------------------------------------------------
# Proposal
# ---------------------------------------------------------------------------


@dataclass
class ProposedItem:
    id: str
    name: str
    price_cents: Optional[int]
    aliases: Tuple[str, ...]
    section: str
    menu_number: str
    suggested_groups: Tuple[str, ...]


@dataclass
class Confirmation:
    """Something a human must answer before this config can ship."""

    topic: str
    question: str
    why: str
    blocking: bool = True

    def __str__(self) -> str:
        mark = "MUST" if self.blocking else "check"
        return f"[{mark}] {self.topic}: {self.question}\n        why: {self.why}"


@dataclass
class Proposal:
    cuisine_id: str
    items: List[ProposedItem]
    archetypes: List[Archetype]
    confirmations: List[Confirmation]
    unparsed_lines: List[str]
    protein_split_warnings: List[str]

    def summary(self) -> str:
        priced = sum(1 for i in self.items if i.price_cents)
        return (f"{len(self.items)} items parsed ({priced} with a price), "
                f"{len(self.archetypes)} modifier groups proposed, "
                f"{len(self.confirmations)} things to confirm, "
                f"{len(self.unparsed_lines)} lines not understood")


def _slug(name: str, used: set) -> str:
    base = re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")[:40] or "item"
    cand, n = base, 2
    while cand in used:
        cand, n = f"{base}_{n}", n + 1
    used.add(cand)
    return cand


def propose(text: str, cuisine_id: Optional[str] = None) -> Proposal:
    """Draft a config from raw menu text. Proposes; never decides."""
    if cuisine_id is None:
        guesses = detect_cuisine(text)
        cuisine_id = guesses[0].cuisine_id if guesses else "burger"
    prof = CUISINES.get(cuisine_id)
    if prof is None:
        raise KeyError(f"unknown cuisine '{cuisine_id}'")

    parsed = parse_menu_text(text)
    lowered = normalize(text)

    # which archetypes does the text actually signal?
    triggered: Dict[str, List[str]] = {}
    for phrase, aid in prof.menu_signals:
        if phrase in lowered:
            triggered.setdefault(aid, []).append(f"menu says '{phrase}'")
    for p in parsed:
        d_ctx = normalize(p.name + " " + p.description)
        for d in prof.dishes:
            if not d.implies:
                continue
            if normalize(d.canonical) in d_ctx or any(
                    normalize(a) in d_ctx for a in d.aliases if len(a) >= 4):
                for aid in d.implies:
                    triggered.setdefault(aid, []).append(
                        f"'{p.name}' is a {d.canonical}")

    archetypes = [a for a in prof.archetypes if a.id in triggered]

    used: set = set()
    items: List[ProposedItem] = []
    for p in parsed:
        if not p.name:
            continue
        ctx = normalize(p.name + " " + p.description)
        def _names_this_dish(d) -> bool:
            for key in (d.canonical,) + d.aliases:
                k = normalize(key)
                if len(k) < 4:
                    continue
                if re.search(r"\b" + re.escape(k) + r"\b", ctx):
                    return True
            return False

        groups = tuple(
            a.id for a in archetypes
            if any(_names_this_dish(d) for d in prof.dishes if a.id in d.implies)
        )
        aliases = suggested_aliases(cuisine_id, p.name)
        if p.menu_number:
            aliases = aliases + (f"number {p.menu_number}",)
        items.append(ProposedItem(
            id=_slug(p.name, used), name=p.name, price_cents=p.price_cents,
            aliases=aliases, section=p.section, menu_number=p.menu_number,
            suggested_groups=groups))

    # ---- confirmations --------------------------------------------------
    conf: List[Confirmation] = []

    missing_price = [i.name for i in items if not i.price_cents]
    if missing_price:
        conf.append(Confirmation(
            "prices",
            f"{len(missing_price)} items have no price: "
            f"{', '.join(missing_price[:5])}"
            f"{' …' if len(missing_price) > 5 else ''}",
            "An item with no price cannot be ordered. The engine refuses to "
            "start with one, which is correct — do not fill these in by "
            "guessing from similar items."))

    for a in archetypes:
        why = a.confirm or "Proposed from the menu text; confirm it is real."
        conf.append(Confirmation(
            f"group '{a.name}'",
            f"Does this restaurant have it, with these options? "
            f"({', '.join(n for n, _ in a.typical_options[:6]) or 'options unknown'})"
            + (f" Required, pick {a.min_select}." if a.min_select else " Optional."),
            why + " Evidence: " + "; ".join(sorted(set(triggered[a.id]))[:3])))
        if a.confirm_price:
            conf.append(Confirmation(
                f"prices in '{a.name}'",
                "What does each option cost?",
                "Modifier prices are almost never on a printed menu, and the "
                "library will not invent them. They stay at $0.00 until "
                "answered, which shows up on the first test order."))

    # ---- dishes that exist in several proteins --------------------------
    split_warnings: List[str] = []
    for word in prof.protein_split_dishes:
        matching = [i.name for i in items if word in normalize(i.name)]
        if len(matching) > 1:
            split_warnings.append(
                f"'{word}' appears in {len(matching)} items "
                f"({', '.join(matching[:3])}{' …' if len(matching) > 3 else ''})")
    if split_warnings:
        conf.append(Confirmation(
            "shared dish names",
            "Confirm a caller saying only the dish name should be asked which "
            "one they mean.",
            "A caller who says 'a korma' has named a dish but not a protein. "
            "Give every variant the same bare alias so they tie and the "
            "engine asks. " + "; ".join(split_warnings[:4]),
            blocking=False))

    # ---- homophone traps present on this menu ---------------------------
    for word, heard_as, note in HOMOPHONE_TRAPS:
        if word in lowered:
            conf.append(Confirmation(
                f"homophone '{word}'",
                f"'{word}' is commonly transcribed as '{heard_as}'. Add it as "
                f"an alias and have Lily confirm it back.",
                note, blocking=False))

    unparsed = [p.raw for p in parsed if not p.name]
    return Proposal(cuisine_id, items, archetypes, conf, unparsed,
                    split_warnings)


# ---------------------------------------------------------------------------
# ASR keyterm budget
# ---------------------------------------------------------------------------


@dataclass
class KeyTerm:
    term: str
    score: float
    reason: str


def asr_keyterms(
    config: RestaurantConfig,
    cuisine_id: Optional[str] = None,
    max_terms: int = 100,
    max_tokens: int = 500,
) -> List[KeyTerm]:
    """Pick which menu terms to boost in the speech recogniser.

    Speech recognisers cap boosted vocabulary — Deepgram's keyterm prompting
    takes at most 100 terms and 500 tokens per request. Pink Garlic has 200+
    items. So the whole menu cannot be boosted and something has to choose.

    Choosing by menu order wastes the budget on items nobody mishears. This
    ranks by how likely a term is to be misheard AND how much it costs to get
    wrong:

      * the cuisine library already knows this word gets misheard   (+3)
      * it collides with another item on THIS menu                  (+2.5)
      * it is short, so the recogniser has little to work with      (+1.5)
      * it is a required modifier option — getting it wrong stops   (+1)
        the order rather than just mispricing it

    Token count is estimated, not exact; leave headroom.
    """
    from cuisine_library import all_mishears

    mishears = all_mishears(cuisine_id) if cuisine_id in CUISINES else {}
    mishear_words = {normalize(k) for k in mishears}
    m = Matcher(config)

    candidates: Dict[str, KeyTerm] = {}

    def add(term: str, score: float, reason: str) -> None:
        t = term.strip()
        if not t or len(t) < 2:
            return
        cur = candidates.get(t.lower())
        if cur is None or score > cur.score:
            candidates[t.lower()] = KeyTerm(t, score, reason)

    names = [(i.id, i.name) for i in config.items]
    for iid, name in names:
        score, reasons = 0.0, []
        n = normalize(name)
        if any(w in n for w in mishear_words) or n in mishear_words:
            score += 3.0
            reasons.append("commonly misheard")
        # collides with another item on this menu
        others = [x for j, x in names if j != iid]
        best = max((m._score(n.split(), normalize(o)) for o in others),
                   default=0.0)
        if best >= 0.75:
            score += 2.5
            reasons.append(f"collides with another item ({best:.2f})")
        if len(n.split()) == 1 and len(n) <= 7:
            score += 1.5
            reasons.append("short name, poor recall")
        if score:
            add(name, score, "; ".join(reasons))

    for g in config.groups:
        if not g.required:
            continue
        for o in config.options_for(g):
            n = normalize(o.name)
            score, reasons = 1.0, ["required choice — a miss blocks the order"]
            if n in mishear_words:
                score += 3.0
                reasons.append("commonly misheard")
            if len(n) <= 6:
                score += 1.0
                reasons.append("short")
            add(o.name, score, "; ".join(reasons))

    ranked = sorted(candidates.values(), key=lambda k: (-k.score, k.term))

    out: List[KeyTerm] = []
    tokens = 0
    for kt in ranked:
        est = math.ceil(len(kt.term.split()) * 1.4) + 1
        if len(out) >= max_terms or tokens + est > max_tokens:
            break
        out.append(kt)
        tokens += est
    return out


# ---------------------------------------------------------------------------
# Library lint — the "menu literacy" safety net, at onboarding time only
# ---------------------------------------------------------------------------


def library_lint(config: RestaurantConfig, cuisine_id: str) -> List[str]:
    """Compare a finished config against what the cuisine usually has.

    Every finding is a QUESTION, never a correction. A restaurant is allowed
    to not have spice levels; what it is not allowed to be is accidentally
    missing them because whoever did the data entry never asked.
    """
    prof = CUISINES.get(cuisine_id)
    if prof is None:
        return [f"no library entry for cuisine '{cuisine_id}'"]

    out: List[str] = []
    _STOP = {"of", "the", "a", "your", "choice"}

    def _tokens(s_: str) -> set:
        flat = normalize(s_).replace("-", " ")
        return {t for t in flat.split() if t not in _STOP}

    group_tokens = [_tokens(g.name) for g in config.groups]
    for a in prof.archetypes:
        at = _tokens(a.name)
        # "Level of Spice" and "Spice Level" are the same group with the words
        # in a different order, which a substring test misses.
        if any(at and (at <= gt or gt <= at) for gt in group_tokens):
            continue
        # Some POS catalogs sell combos as separate menu items rather than a
        # modifier group. That is a complete representation, not a missing
        # archetype, when the item names themselves say Combo.
        if (normalize(a.name) == "combo"
                and any("combo" in _tokens(it.name) for it in config.items)):
            continue
        out.append(
            f"No group resembling '{a.name}' — most {prof.name} menus have "
            f"one. Confirm this restaurant genuinely does not. ({a.confirm})")

    # A group the library says is normally PRICED, sitting entirely at $0.00,
    # is the signature of a price nobody got round to asking for.
    for a in prof.archetypes:
        if not a.confirm_price:
            continue
        at = _tokens(a.name)
        for g in config.groups:
            if not (at and (at <= _tokens(g.name) or _tokens(g.name) <= at)):
                continue
            opts = config.options_for(g)
            if opts and all(o.price_cents == 0 and not o.price_by_size
                            for o in opts):
                # Ordinary included defaults (lettuce, tomato, sauce) are not
                # unpriced add-ons. Only warn when the group also contains a
                # non-default choice whose missing price could lose revenue.
                if set(g.option_ids) <= set(g.default_option_ids):
                    continue
                out.append(
                    f"Group '{g.name}' is entirely $0.00, but {prof.name} "
                    f"menus normally charge for at least some of these. "
                    f"Confirm these are genuinely free rather than unpriced. "
                    f"({a.confirm})")

    # required options priced at zero are the classic unanswered question
    for g in config.groups:
        if not g.required:
            continue
        opts = config.options_for(g)
        if opts and all(o.price_cents == 0 and not o.price_by_size
                        for o in opts):
            attached = [it for it in config.items
                        if g.id in it.modifier_group_ids]
            if (attached and all("combo" in _tokens(it.name)
                                 for it in attached)):
                continue
            out.append(
                f"Every option in required group '{g.name}' is $0.00. That is "
                f"normal for an included choice and a bug for a paid one — "
                f"confirm which this is.")

    for word, heard_as, note in HOMOPHONE_TRAPS:
        for it in config.items:
            # word boundary, or "Baba Ghanouj" trips the 'no' -> 'know' trap
            if re.search(r"\b" + re.escape(word) + r"\b", normalize(it.name)):
                aliases = {normalize(a) for a in it.aliases}
                if heard_as not in aliases and heard_as != word:
                    out.append(
                        f"'{it.name}' contains '{word}', which is commonly "
                        f"transcribed as '{heard_as}', but '{heard_as}' is not "
                        f"an alias. {note}")
                break
    # same finding from two sibling groups (plain/cheese toppings) reads as
    # noise; one line per distinct message is enough
    return list(dict.fromkeys(out))


# ---------------------------------------------------------------------------
# Draft rendering
# ---------------------------------------------------------------------------


def render_draft(proposal: Proposal, restaurant_id: str, name: str) -> str:
    """Emit a config draft as Python source, with every gap marked TODO."""
    lines: List[str] = []
    w = lines.append
    w('"""')
    w(f"DRAFT config for {name} — generated by menu_ingest.propose().")
    w("")
    w("NOT READY TO SHIP. Every TODO below is a question for the owner.")
    w("Prices left at 0 are unknown, not free.")
    w("")
    for c in proposal.confirmations:
        w(f"  {c}")
    w('"""')
    w("")
    w("from cuisine_packs import grp, opt")
    w("from order_engine import MenuItem, RestaurantConfig")
    w("")
    w("_OPTIONS = (")
    for a in proposal.archetypes:
        w(f"    # --- {a.name} ---")
        for oname, cents in a.typical_options:
            oid = re.sub(r"[^a-z0-9]+", "_", oname.lower()).strip("_")
            todo = "  # TODO price" if a.confirm_price else ""
            w(f'    opt("{a.id}_{oid}", "{oname}", {cents}),{todo}')
    w(")")
    w("")
    w("_GROUPS = (")
    for a in proposal.archetypes:
        ids = ", ".join(
            f'"{a.id}_{re.sub(chr(94) + "a-z0-9", "", re.sub(r"[^a-z0-9]+", "_", n.lower()).strip("_"))}"'
            for n, _ in a.typical_options)
        w(f'    grp("{a.id}", "{a.name}",')
        w(f'        "{a.prompt}",')
        w(f"        ({ids},),")
        w(f"        mn={a.min_select}, mx={a.max_select}),")
    w(")")
    w("")
    w("_ITEMS = (")
    for i in proposal.items:
        price = i.price_cents if i.price_cents else 0
        todo = "" if i.price_cents else "  # TODO price unknown"
        groups = ", ".join(f'"{g}"' for g in i.suggested_groups)
        al = ", ".join(f'"{a}"' for a in i.aliases[:6])
        w(f'    MenuItem(id="{i.id}", name="{i.name}",{todo}')
        w(f"             base_price_cents={price},")
        if al:
            w(f"             aliases=({al},),")
        if groups:
            w(f"             modifier_group_ids=({groups},)),")
        else:
            w("             ),")
    w(")")
    w("")
    w(f'{restaurant_id.upper().replace("-", "_")} = RestaurantConfig(')
    w(f'    id="{restaurant_id}", name="{name}",')
    w(f'    cuisine="{proposal.cuisine_id}",')
    w("    tax_rate_bps=0,   # TODO local rate")
    w("    options=_OPTIONS, groups=_GROUPS, items=_ITEMS,")
    w(")")
    return "\n".join(lines)
