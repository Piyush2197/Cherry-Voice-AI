/**
 * A small sign-in throttle: five failures per fifteen minutes, counted per
 * address and, separately, per username (so spreading guesses across addresses
 * does not help). In memory, per server process: a restart clears it and
 * several instances each keep their own count — put a shared limiter in front
 * (or at the proxy) before running more than one.
 */
const WINDOW_MS = 15 * 60 * 1000
const MAX_FAILURES = 5
const MAX_KEYS = 10_000

const failures = new Map<string, number[]>()

function recent(key: string, now: number): number[] {
  const list = (failures.get(key) || []).filter((t) => now - t < WINDOW_MS)
  if (list.length) failures.set(key, list)
  else failures.delete(key)
  return list
}

/** Seconds to wait if this address or username is locked out, else 0. */
export function lockedFor(ip: string, username: string, now: number = Date.now()): number {
  let wait = 0
  for (const key of [`ip:${ip}`, `user:${username.toLowerCase()}`]) {
    const list = recent(key, now)
    if (list.length >= MAX_FAILURES) {
      wait = Math.max(wait, Math.ceil((list[0] + WINDOW_MS - now) / 1000))
    }
  }
  return wait
}

export function recordFailure(ip: string, username: string, now: number = Date.now()): void {
  if (failures.size > MAX_KEYS) failures.clear() // bounded memory beats a perfect count
  for (const key of [`ip:${ip}`, `user:${username.toLowerCase()}`]) {
    failures.set(key, [...recent(key, now), now])
  }
}

export function recordSuccess(username: string): void {
  failures.delete(`user:${username.toLowerCase()}`)
}

export function resetRateLimit(): void {
  failures.clear()
}
