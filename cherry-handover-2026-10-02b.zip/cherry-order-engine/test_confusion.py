#!/usr/bin/env python3
"""The confusion sweep — the fleet-wide Dragon-Roll invariant.

The bug this pins: inside Miyazaki's Totoro tray (twelve similar "-Roll"
options), a caller's first pick "Dragon Roll" scored 0.727 against Salmon
Roll and was SILENTLY ADDED — the wrong food on the ticket, caught by the
deep pass, fixed with weak-match guards on every option path. This suite
generalizes that lesson across every menu:

  * a dish name from OUTSIDE an option pool, spoken into that pool's
    question, must never be silently added — the cart may not change;
  * a weak "did you mean" offer must never add anything on its own;
  * every item on every menu, spoken verbatim, resolves to itself;
  * Miyazaki's tray flows and Tamago's honest refusals, pinned.
"""

from __future__ import annotations

import difflib
from pathlib import Path

import agent_api
import menu_schema as ms
import order_engine

MENUS = Path(__file__).parent / "menus"

_passed, _failed = 0, 0


def check(name: str, cond: bool, detail: str = "") -> None:
    global _passed, _failed
    if cond:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail[:260]}" if detail else ""))


def load(stem):
    return ms.load_yaml(MENUS / f"{stem}.yaml")


def menus() -> list:
    out = []
    for f in sorted(MENUS.glob("*.yaml")):
        try:
            cfg = ms.load_yaml(f)
            out.append((f.stem, cfg))
        except Exception:  # noqa: BLE001
            pass
    return out


def cart_ids(s: agent_api.CallSession):
    return [(l["item_id"], l["quantity"],
             tuple(sorted((m["group_id"], m["option_id"])
                          for m in l.get("modifiers", []))))
            for l in s.snapshot().get("lines", [])]


def same_dish(spoken: str, option, cfg) -> bool:
    """True when the option the engine picked is plausibly the dish the
    caller named: 'Fries' spoken into a side question IS the French Fries;
    'Onion Rings' IS the Onion Rings. Name or alias tokens containing each
    other (after normalization) count as the same dish."""
    norm = order_engine.normalize
    utt = set(norm(spoken).split())
    names = [option.name] + list(getattr(option, "aliases", []) or [])
    for name in names:
        toks = set(norm(name).split())
        if toks and (utt <= toks or toks <= utt):
            return True
    return False


def t_foreign_names_never_enter_an_option_pool() -> None:
    """For every group of >=4 options: utter dish names from outside the
    pool that score in the weak zone. Nothing may be silently added."""
    fleet_names = []
    for _, cfg in menus():
        fleet_names += [i.name for i in cfg.items]
    probed = 0
    for stem, cfg in menus():
        for group in cfg.groups:
            if group.informational or len(group.option_ids) < 4:
                continue
            pool_names = {o.name.lower() for o in
                          (cfg.option(oid) for oid in group.option_ids)
                          if o is not None}
            # foreign names that are NOT pool options but textually close
            foreign = []
            for name in fleet_names:
                low = name.lower()
                if low in pool_names:
                    continue
                best = max(
                    (difflib.SequenceMatcher(None, low, p).ratio()
                     for p in pool_names), default=0.0)
                shared = any(w in p for p in pool_names
                             for w in low.split() if len(w) > 3)
                if best >= 0.55 or shared:
                    foreign.append(name)
            if not foreign:
                continue
            host = next((i for i in cfg.items
                         if group.id in i.modifier_group_ids
                         and i.available), None)
            if host is None:
                continue
            for name in foreign[:6]:
                s = agent_api.CallSession(cfg)
                s.add_item(text=host.name)
                before = cart_ids(s)
                r = s.add_modifier(text=name)
                after = cart_ids(s)
                probed += 1
                if before == after:
                    ok = True
                else:
                    # something was added — it must be the same dish the
                    # caller named, not a fuzzy neighbour
                    new_opts = {(g, o) for _, _, mods in after
                                for g, o in mods} - \
                        {(g, o) for _, _, mods in before for g, o in mods}
                    ok = bool(new_opts) and all(
                        same_dish(name, cfg.option(o), cfg)
                        for _, o in new_opts)
                check(f"{stem}: foreign {name!r} never silently enters "
                      f"{group.id}",
                      ok,
                      f"{r.get('say')!r} cart {before} -> {after}")
    check("the sweep actually probed pools", probed >= 40, str(probed))


def t_weak_offer_never_adds_on_its_own() -> None:
    """'Did you mean the X?' leaves the cart untouched until a yes."""
    cfg = load("tamago-sushi-bowl")
    s = agent_api.CallSession(cfg)
    r = s.add_item(text="shoyu ramen")          # only Spicy/Mild exist
    before = cart_ids(s)
    check("tamago: 'shoyu ramen' offers, adds nothing",
          r.get("ok") is False and before == [] and
          "Did you mean" in r.get("say", ""), str(r.get("say")))
    r2 = s.answer(text="no")
    check("tamago: declining the offer adds nothing",
          cart_ids(s) == [], str(r2.get("say")))


def t_miyazaki_tray_regressions() -> None:
    cfg = load("miyazaki-hall-rd")
    # the original bug: first pick "Dragon Roll" must ask, never add Salmon
    s = agent_api.CallSession(cfg)
    s.add_item(text="Totoro tray")
    r = s.add_modifier(text="Dragon Roll")
    sel = [m["option_name"] for m in s.snapshot()["lines"][0]["modifiers"]]
    check("miyazaki: 'Dragon Roll' into the tray ASKS, adds nothing",
          r.get("ok") is False and sel == [], f"{r.get('say')!r} {sel}")
    # eight natural picks: the 8th is added but the tray refuses to finalize
    # over-full (validation blocks it) — whether the 8th should be refused
    # outright or upcharged is on the owner ledger
    s2 = agent_api.CallSession(cfg)
    s2.add_item(text="Totoro tray")
    for p in ("California Roll", "Spicy Tuna Roll", "shrimp tempura",
              "salmon roll", "eel and avocado", "philadelphia",
              "yellowtail scallion", "AAC"):
        s2.add_modifier(text=p)
    sel2 = [m["option_name"] for m in s2.snapshot()["lines"][0]["modifiers"]]
    check("miyazaki: eight picks land but the tray cannot finalize over-full",
          len(sel2) == 8 and not s2.e.is_submittable(), str(len(sel2)))
    # tray removals: partial names remove the right roll; foreign ones refuse
    s3 = agent_api.CallSession(cfg)
    s3.add_item(text="Totoro tray")
    s3.add_modifier(text="Salmon Roll")
    r3 = s3.remove_modifier(text="no salmon")
    sel3 = [m["option_name"] for m in s3.snapshot()["lines"][0]["modifiers"]]
    check("miyazaki: 'no salmon' removes the Salmon Roll",
          r3.get("ok") and sel3 == [], f"{r3.get('say')!r} {sel3}")
    s3.add_modifier(text="Salmon Roll")
    r4 = s3.remove_modifier(text="no dragon")
    sel4 = [m["option_name"] for m in s3.snapshot()["lines"][0]["modifiers"]]
    check("miyazaki: 'no dragon' removes nothing",
          r4.get("ok") is False and "Salmon Roll" in sel4,
          f"{r4.get('say')!r} {sel4}")
    # the tray prompt no longer promises rolls it cannot take
    prompt = next(g for g in cfg.groups if g.id == "my_tray7").prompt
    check("miyazaki: Totoro prompt says BASIC rolls",
          "basic" in prompt.lower(), prompt)


def t_tamago_honest_refusals() -> None:
    cfg = load("tamago-sushi-bowl")
    for phrase, want_ask in (("shoyu ramen", True),
                             ("tonkotsu ramen", False),
                             ("poke bowl", False)):
        s = agent_api.CallSession(cfg)
        r = s.add_item(text=phrase)
        ls = (r.get("order") or {}).get("lines") or []
        if want_ask:
            check(f"tamago: {phrase!r} asks (dish family exists)",
                  r.get("ok") is False and not ls
                  and "mean" in r.get("say", ""), str(r.get("say")))
        else:
            check(f"tamago: {phrase!r} refuses cleanly",
                  r.get("ok") is False and not ls, str(r.get("say")))
    # the real menu is untouched by any of this
    for phrase, item in (("salmon avocado bowl", "tg_bowl_salmon_avocado"),
                         ("spicy tuna roll", "tg_spicy_tuna_roll"),
                         ("chicken teriyaki bowl", "tg_rb_chicken_teriyaki")):
        s = agent_api.CallSession(cfg)
        r = s.add_item(text=phrase)
        ls = (r.get("order") or {}).get("lines") or []
        check(f"tamago: {phrase!r} -> {item}",
              bool(ls) and ls[0]["item_id"] == item, str(r.get("say")))


def t_every_item_verbatim_resolves_to_itself() -> None:
    """The self-consistency rule, run across the whole fleet here so a new
    menu cannot ship with a name that lands on a neighbour."""
    for stem, cfg in menus():
        for item in cfg.items:
            if not item.available or item.has_sizes:
                continue
            s = agent_api.CallSession(cfg)
            r = s.add_item(text=item.name)
            ls = (r.get("order") or {}).get("lines") or []
            asked = r.get("ok") is False and not ls
            ok = (ls and ls[0]["item_id"] == item.id) or asked
            check(f"{stem}: {item.name!r} verbatim -> itself (or asks)",
                  ok, f"got {(ls or [{}])[0].get('item_id')} "
                      f"{r.get('say', '')[:80]!r}")


def main() -> None:
    batteries = [
        t_foreign_names_never_enter_an_option_pool,
        t_weak_offer_never_adds_on_its_own,
        t_miyazaki_tray_regressions,
        t_tamago_honest_refusals,
        t_every_item_verbatim_resolves_to_itself,
    ]
    for fn in batteries:
        print(f"== {fn.__name__}")
        fn()
    print(f"\n{_passed} passed, {_failed} failed")


if __name__ == "__main__":
    main()
