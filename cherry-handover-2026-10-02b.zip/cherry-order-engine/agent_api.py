"""
The seam between the voice layer and the order engine.

WHO DOES WHAT
-------------
Inworld hears the caller and decides INTENT. This module decides everything
about the ORDER. The split is deliberate and it is the whole reason the system
can be trusted:

    Inworld's job    "the caller wants to add something, and the words were
                      'gimme a double with cheese'"
    Cherry's job      which item that is, whether it is ambiguous, what it
                      costs, what still has to be asked, and the exact
                      sentence Lily says next

The voice model never invents a price, never guesses between two items, and
never decides an order is complete. Every tool below returns a `say` field
containing the literal sentence to speak. If the voice layer paraphrases it,
that is a bug in the voice layer — the words carry prices and clarifying
questions that have to be exact.

THE ENVELOPE
------------
Every tool returns the same shape, so the voice layer has one thing to handle:

    {
      "ok": true,
      "say": "Got it — Double Cheeseburger. How would you like that cooked?",
      "action": "add_item",
      "needs": {"question": "...", "line_id": "...", "group_id": "...",
                "candidates": ["..."]} | null,
      "order": {"lines": [...], "subtotal_cents": 1299, "tax_cents": 78,
                "total_cents": 1377, "submittable": false},
      "error": null
    }

`needs` non-null means the engine is waiting for an answer and the call CANNOT
be completed yet. `order.submittable` false means `place_order` will refuse.
Neither is advisory.

TOOL SCHEMAS
------------
`TOOL_SCHEMAS` at the bottom is JSON-schema function definitions, ready to
paste into Inworld's tool configuration. Keep them in sync with the methods —
`test_agent_api.py` asserts that they match.
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

import host_voice
import phrasebook
from order_engine import (IssueCode, MatchCandidate, OrderEngine, Placement,
                          _CUE_WORDS, _FILLERS, _NEGATION_CUES, _NUMBER_WORDS,
                          _QTY_WORDS, _tokens, money, normalize,
                          parse_quantity)

# The engine refuses to guess between two plausible items. When that happens
# Lily asks. This is the sentence she asks it with.
_DISAMBIGUATE = "Did you want the {options}?"
_NOT_ON_MENU = "Sorry, we don't have that — what else can I get you?"
_NOTHING_YET = "There's nothing on the order yet — what can I get you?"
#: Two replies this close together are one utterance ("a korma and two naan"):
#: a question already asked in the first is not asked again in the second.
_SAME_BREATH_SECONDS = 3.0
#: Below this, a match that does not cover what the caller said is a guess.
_WEAK_MATCH = 0.80

# item_info: words that frame an allergen/diet question without naming a dish.
_INFO_SCAFFOLD = frozenset(
    "does do did is are was were the a an any it its this that these those "
    "they them have has had with in on of for to and or contain contains "
    "containing include includes there here what whats which who how can "
    "could would you i im me my we please about tell anything something "
    "everything safe okay ok if options option dishes items menu free "
    "allergy allergic allergies allergen allergens intolerant intolerance "
    "celiac coeliac anaphylaxis epipen".split())
_INFO_PRONOUNS = frozenset("it its this that these those they them".split())
_INFO_ALLERGY_WORDS = frozenset(
    "allergy allergic allergies allergen allergens intolerant intolerance "
    "celiac coeliac anaphylaxis epipen".split())
#: Said after any allergen fact. A declared list is never the whole truth — it
#: is only what an owner wrote down — so it is never spoken without this.
_INFO_CONFIRM = ("That's only what the restaurant has written down, so please "
                 "confirm any allergy with the restaurant before ordering.")
_INFO_ASK = "Please check with the restaurant before ordering if this matters."


def _envelope(ok: bool, say: str, action: str, engine: OrderEngine,
              needs: Optional[Dict] = None,
              error: Optional[str] = None) -> Dict[str, Any]:
    p = engine.price()
    return {
        "ok": ok,
        "say": say,
        "action": action,
        "needs": needs,
        "order": {
            "lines": [
                {
                    "line_id": l.line_id,
                    "item_id": l.item_id,
                    "name": engine.config.item(l.item_id).name
                            if engine.config.item(l.item_id) else l.item_id,
                    "quantity": l.quantity,
                    "description": engine.describe_line(l, changes_only=True),
                    "line_total_cents": lp.line_total_cents,
                }
                for l, lp in zip(engine.lines, p.lines)
            ],
            "subtotal_cents": p.subtotal_cents,
            "tax_cents": p.tax_cents,
            "total_cents": p.total_cents,
            "payment_mode": "pay_now" if p.pay_now else "pay_at_pickup",
            "submittable": engine.is_submittable(),
        },
        "error": error,
        # A failed reply is something to SAY to the caller, not a call to repeat.
        # Models that retry silently (Gemini 3.8 Live is documented to sweep a
        # tool 2-5 times when it gets no result) must be told, in the reply.
        **({"retryable": error in ("bad_arguments", "misrouted")} if not ok else {}),
    }


@dataclass
class CallContext:
    """What the SERVER knows about this call and the engine does not.

    Filled in once, before the greeting, and again identically when a call is
    resumed after a restart — so everything Lily says from it is a function of
    this plus the journaled tool calls, and a replay says the same words.
    """
    local_hour: Optional[int] = None          # the restaurant's clock, 0-23
    prep_minutes: Optional[int] = None        # prep + current wait
    returning: Optional[Dict[str, Any]] = None  # {"name","lines","allergy_note"}
    hours: Optional[Dict[str, Any]] = None    # {"configured","open_now","closes","next_open"}
    is_suppressed: Optional[Callable[[str], bool]] = None  # a number that said STOP


class CallSession:
    """One call. Hold one of these per active call and route tools to it.

    Stateless between calls, stateful within one — which is why the voice
    layer must keep the same instance for the life of the call rather than
    rebuilding it per turn.
    """

    _UNAVAILABLE = (IssueCode.ITEM_UNAVAILABLE, IssueCode.OPTION_UNAVAILABLE,
                    IssueCode.SIZE_UNAVAILABLE)

    def __init__(self, config) -> None:
        self.e = OrderEngine(config)
        self.config = config
        # What the matcher heard and chose, drained by the server after each
        # tool call into the ``resolution`` table (accuracy log; never shown
        # to the caller and never used to make a decision).
        self.resolutions: List[Dict[str, Any]] = []
        # The item choice Lily last asked about ("the chicken or the lamb
        # korma?"). It is not an order line yet, so nothing in the engine
        # records it; without this the caller's reply to such a question
        # has nowhere to land when the voice model routes it to `answer`.
        self._ambiguous: Optional[Dict[str, Any]] = None
        # The waiter's question. `ready_to_place` asks it once; the answer (or
        # an allergy the caller volunteered earlier) is written onto the order
        # for the kitchen. Asked-but-never-answered is recorded too, so the
        # ticket says so rather than staying silent.
        self._allergy_asked = False
        self._allergy_checked = False
        self._allergy_unconfirmed = False
        self._allergy_note = ""
        self._acks = 0     # rotates Lily's openers; counted, so a replay agrees
        self.ctx = CallContext()
        self._name = ""            # the name for the order
        self._text_to = ""         # where the checkout link goes, if not the caller ID
        self._reordered = False
        self._asked: set = set()       # (line, group, question) already put to the caller
        self._asked_at: Dict[Any, float] = {}   # when it was last put to them
        self.now: Callable[[], float] = time.monotonic   # injectable: simulations pass time

    def set_context(self, **fields: Any) -> None:
        """Called by the server before the greeting (and again on a resume)."""
        for k, v in fields.items():
            if not hasattr(self.ctx, k):
                raise TypeError(f"unknown call context field {k!r}")
            setattr(self.ctx, k, v)
        # Greeted as "Welcome back, Sam!" — so do not then ask Sam for a name.
        # (Set here, not in greeting(): a resumed call never replays the greeting.)
        known = ((fields.get("returning") or {}).get("name") or "").strip()
        if known and not self._name:
            self._name = known

    @property
    def customer_name(self) -> str:
        return self._name

    @property
    def text_to(self) -> str:
        return self._text_to

    def _ack(self) -> str:
        """'Got it' first, then a rotation: warm without sounding scripted."""
        word = host_voice.rotate(host_voice.ACKS, self._acks)
        self._acks += 1
        return word

    def _note(self, tool: str, kind: str, heard: str, cands, outcome: str) -> None:
        top = cands[0] if cands else None
        second = cands[1] if cands and len(cands) > 1 else None
        self.resolutions.append({
            "tool": tool, "kind": kind, "heard": heard, "outcome": outcome,
            "resolved_id": top.target_id if top else None,   # best candidate; chosen only if matched
            "resolved_name": top.target_name if top else None,
            "score": float(top.score) if top else None,
            "runner_up_id": second.target_id if second else None,
            "runner_up_name": second.target_name if second else None,
            "runner_up_score": float(second.score) if second else None,
        })

    def take_resolutions(self) -> List[Dict[str, Any]]:
        out, self.resolutions = self.resolutions, []
        return out

    # -- what Lily is waiting for ---------------------------------------

    def pending(self):
        """The question the caller's next words would be ANSWERING.

        Not every blocking issue is one: an empty cart asks "what can I get
        you?", which is an invitation, not a question with candidates.
        Treating it as answerable routes every utterance into the answer path
        and nothing can be ordered at all. An answerable question names a line.
        """
        return next((i for i in self.e.validate()
                     if i.blocking and i.question and i.line_id
                     and (i.group_id or i.code is IssueCode.SIZE_REQUIRED)), None)

    def _blocker(self):
        """A blocking issue the caller cannot answer — chiefly being sold out.

        It has to be said the moment it happens. Confirming "Got it — Garlic
        Naan" and only objecting at the end of the call is worse than not
        taking the order at all.
        """
        return next((i for i in self.e.validate()
                     if i.blocking and i.code in self._UNAVAILABLE), None)

    def _needs(self) -> Optional[Dict]:
        i = self.pending()
        if i is None:
            return None
        return {"question": i.question, "line_id": i.line_id,
                "group_id": i.group_id, "code": i.code.value,
                "candidates": list(i.candidates)}

    def _reply(self, say: str, action: str, ok: bool = True,
               error: Optional[str] = None) -> Dict[str, Any]:
        return _envelope(ok, say, action, self.e, self._needs(), error)

    def argument_error(self, action: str, *, misrouted: bool = False
                       ) -> Dict[str, Any]:
        """Return a speakable failure when the voice layer sends bad args.

        This deliberately does not mutate the order.  If Cherry is already
        waiting for an answer, repeat that exact question; otherwise ask the
        caller to try again.  In particular, caller text accidentally sent to
        a no-text tool must never be discarded while the tool still runs.
        """
        issue = self.pending()
        say = (issue.question if issue and issue.question else
               "Sorry, I didn't catch that — could you say it again?")
        return self._reply(say, action, ok=False,
                           error="misrouted" if misrouted else "bad_arguments")

    def _confirm(self, confirmation: str, action: str) -> Dict[str, Any]:
        """Confirm, then immediately ask whatever is still outstanding.

        One sentence, not two turns: 'Got it — a saag. How spicy?' Making the
        caller wait a turn for the follow-up is what makes an agent feel slow.
        """
        stop = self._blocker()
        if stop is not None:
            return self._reply(stop.question or stop.message, action, ok=False,
                               error=stop.code.value)
        issue = self.pending()
        ask = self._pending_question(issue) if issue else ""
        say = f"{confirmation} {ask}" if ask else confirmation
        return self._reply(say, action)

    def _pending_question(self, issue) -> str:
        """The question to put to the caller NOW. The first time it is the
        engine's own; asked again about the same line it becomes "Anything else
        you'd like to change on the burger?" — repeating the whole list is how
        a host sounds like a machine, and re-listing the onion the caller just
        removed is how it sounds like one that is not listening."""
        q = issue.question or ""
        key = (issue.line_id, issue.group_id, q)
        now = self.now()
        if now - self._asked_at.get(key, -1e9) < _SAME_BREATH_SECONDS:
            # "A korma and two naan" is two tool calls in one breath, and the
            # korma's question rode on both replies. Said once is a question;
            # said twice, with the whole option list, is a machine.
            return ""
        self._asked_at[key] = now
        line = self.e.get_line(issue.line_id) if issue.line_id else None
        item = self.config.item(line.item_id) if line else None
        if q.startswith("Any changes") and key in self._asked:
            return (f"Anything else you'd like to change on the {item.name}?"
                    if item else "Anything else you'd like to change?")
        self._asked.add(key)
        last = self.e.last_line()
        if item is not None and last is not None and line.line_id != last.line_id:
            # The question is about an EARLIER item ("a korma and two naan" ->
            # "how spicy?"). Without this, "that" sounds like the naan.
            return f"For the {item.name}, {q[:1].lower() + q[1:]}"
        return q

    def _line_or_last(self, line_id: Optional[str]):
        return self.e.get_line(line_id) if line_id else self.e.last_line()

    def _target_line(self, line_id: Optional[str], text: str, action: str):
        """Which line the caller means: an id, else their words, else the last.

        The voice model never sees line ids (it is only handed what to say), so
        "take the samosa off" has to be resolvable from the caller's words.
        Returns (line, None) or (None, a ready-made refusal envelope).
        """
        if line_id:
            line = self.e.get_line(line_id)
            return (line, None) if line else (None, self._reply(
                _NOTHING_YET, action, ok=False, error="no_line"))
        words = (text or "").strip()
        if not words:
            line = self.e.last_line()
            return (line, None) if line else (None, self._reply(
                _NOTHING_YET, action, ok=False, error="no_line"))
        by_item: Dict[str, List] = {}
        for ln in self.e.lines:
            by_item.setdefault(ln.item_id, []).append(ln)
        pool = [(i, n) for (i, n) in self.e.matcher._item_names if i in by_item]
        cands = self.e.matcher._rank(words, pool, "item")
        if not cands:
            return None, self._reply("I don't see that on your order.", action,
                                     ok=False, error="no_match")
        if not self.e.matcher.is_decisive(cands):
            names = " or the ".join(c.target_name for c in cands[:3])
            return None, self._reply(f"Which one — the {names}?", action,
                                     ok=False, error="ambiguous")
        return by_item[cands[0].target_id][-1], None   # the most recent of them

    # -- tools ------------------------------------------------------------

    def greeting(self) -> Dict[str, Any]:
        c, name = self.ctx, self.config.name
        prev = (c.returning or {}).get("lines") or []
        if prev:
            # A regular: say so, and offer the same again — never read out
            # anything private (allergies are asked again at the end, not here).
            summary = host_voice.describe_lines(prev)
            offer = (host_voice.OFFER_USUAL.format(summary=summary) if summary
                     else host_voice.OFFER_USUAL_LONG)
            who = (c.returning or {}).get("name") or ""
            say = (host_voice.GREETING_BACK_NAMED.format(who=who, name=name, offer=offer)
                   if who else host_voice.GREETING_BACK.format(name=name, offer=offer))
        else:
            part = host_voice.day_part(c.local_hour)
            say = (host_voice.GREETING_DAYPART.format(part=part, name=name) if part
                   else host_voice.GREETING.format(name=name))
        return self._reply(say, "greeting")

    def add_item(self, text: str, quantity: Optional[int] = None,
                 note: str = "") -> Dict[str, Any]:
        """Put something on the order. `text` is the caller's own words."""
        cands = self.e.matcher.match_items(text)
        if not cands:
            self._note("add_item", "item", text, cands, "no_match")
            if host_voice.order_intent(text):
                # "I'd like to place an order": a welcome, not "we don't have that".
                welcome = host_voice.rotate(host_voice.WELCOME_ORDER, self._acks)
                self._acks += 1
                return self._reply(welcome, "add_item")
            return self._reply(_NOT_ON_MENU, "add_item", ok=False,
                               error="no_match")
        if not self.e.matcher.is_decisive(cands):
            avail = [c for c in cands if (self.config.item(c.target_id) is not None
                                          and self.config.item(c.target_id).available)]
            if len(avail) < len(cands):
                # One of the choices is sold out. Never offer it: with at most one
                # real choice left, say what is gone and offer what is close; with
                # several, ask only about what can actually be sold.
                if len(avail) <= 1:
                    gone = next(c for c in cands if c not in avail)
                    qty_g = quantity if quantity is not None else parse_quantity(text)
                    return self._sold_out(self.config.item(gone.target_id), qty_g,
                                          note, "add_item", text)
                cands = avail
            self._note("add_item", "item", text, cands, "ambiguous")
            names = " or the ".join(c.target_name for c in cands[:3])
            self._ambiguous = {
                "ids": [c.target_id for c in cands[:3]],
                "quantity": quantity if quantity is not None
                else parse_quantity(text),
                "note": note, "utterance": text}
            return _envelope(
                False, _DISAMBIGUATE.format(options=names), "add_item", self.e,
                needs={"question": _DISAMBIGUATE.format(options=names),
                       "line_id": None, "group_id": None,
                       "code": IssueCode.AMBIGUOUS_MATCH.value,
                       "candidates": [c.target_id for c in cands[:3]]},
                error="ambiguous")
        top = cands[0]
        top_item = self.config.item(top.target_id)
        if top_item is not None and not top_item.available:
            # Sold out beats "did you mean": never offer a dish the kitchen is out of.
            qty_s = quantity if quantity is not None else parse_quantity(text)
            self._note("add_item", "item", text, cands, "sold_out")
            return self._sold_out(top_item, qty_s, note, "add_item", text)
        if top.score < _WEAK_MATCH and not top.covers_utterance:
            # Close enough to GUESS, not close enough to put on the order: "pad
            # thai" scores 0.67 against "Paratha". Ask, never silently swap a dish.
            self._note("add_item", "item", text, cands, "weak")
            qty_w = quantity if quantity is not None else parse_quantity(text)
            say = f"Did you mean the {top.target_name}?"
            self._ambiguous = {"ids": [top.target_id], "quantity": qty_w,
                               "note": note, "offer": True, "utterance": text}
            return _envelope(
                False, say, "add_item", self.e,
                needs={"question": say, "line_id": None, "group_id": None,
                       "code": IssueCode.AMBIGUOUS_MATCH.value,
                       "candidates": [top.target_id]},
                error="low_confidence")
        self._note("add_item", "item", text, cands, "matched")
        self._ambiguous = None
        qty = quantity if quantity is not None \
            else self._spoken_quantity(text, cands[0],
                                       fallback=parse_quantity(text),
                                       count_none_as=1)
        item = self.config.item(cands[0].target_id)
        if item is not None and not item.available:
            return self._sold_out(item, qty, note, "add_item", text)
        line = self.e.add_line(cands[0].target_id, quantity=qty, note=note)
        word = f"{qty} " if qty > 1 else ""
        return self._confirm(f"{self._ack()} — {word}{cands[0].target_name}.",
                             "add_item")

    def _spoken_quantity(self, text: str, cand: MatchCandidate,
                         fallback: int = 1, count_none_as: int = 0) -> int:
        """How many the CALLER said — never a number inside the dish's name.

        Pink Garlic sells "2 Papadam and Chutney" and Juan Miguel's "21
        Shrimp": dishes NAMED for how many they serve. parse_quantity reads
        that leading number as a quantity, so merely naming the dish put 21
        shrimp on the ticket. Two shapes are fixed: the dish's full name (or
        an alias) spoken inside the utterance, whose span is removed before
        parsing; and an utterance that OPENS with the same number the dish's
        name opens with ("2 papadam" for "2 Papadam and Chutney"). If the
        words outside the name hold no count, that silence is reliable: the
        caller ordered the dish as named, so `count_none_as` wins (one on a
        complete utterance; zero to let a caller of a clarifying question
        keep the quantity they said earlier). Shapes this cannot pin down
        return `fallback` — genuinely ambiguous speech keeps the caller's
        words, and the read-back gives them the chance to correct."""
        norm = normalize(text or "")
        item = self.config.item(cand.target_id)
        names = [cand.target_name] + (
            list(item.aliases) if item is not None else [])
        for name in names:
            n = normalize(name)
            if n and n in norm:
                outside = norm.replace(n, " ", 1)
                qty = parse_quantity(outside, default=0)
                return qty if qty > 0 else count_none_as
        lead = re.match(r"^(\d+)\b", normalize(cand.target_name))
        if lead:
            rest = re.sub(rf"^{lead.group(1)}\b", " ", norm, count=1)
            if rest != norm:
                qty = parse_quantity(rest, default=0)
                return qty if qty > 0 else count_none_as
        return fallback

    def _alternatives(self, item) -> List[Any]:
        """Available dishes closest to a sold-out one: same name family first."""
        pool = [(i.id, normalize(i.name)) for i in self.config.items
                if i.available and i.id != item.id]
        near = self.e.matcher._rank(item.name, pool, "item")
        out = [self.config.item(c.target_id) for c in near[:2]]
        if not out and item.category and item.category != "general":
            out = [i for i in self.config.items
                   if i.available and i.id != item.id
                   and i.category == item.category][:2]
        return [i for i in out if i is not None]

    def _sold_out(self, item, qty: int, note: str, action: str,
                  text: str = "") -> Dict[str, Any]:
        """The dish is 86'd. It is NOT put on the order (an 86'd line blocks
        every later reply and the end of the call); say so warmly and offer
        what is closest, and remember the offer so a plain 'yes' takes it."""
        alts = self._alternatives(item)
        if not alts:
            self._ambiguous = None
            return self._reply(host_voice.SOLD_OUT_NONE.format(name=item.name),
                               action, ok=False, error="item_unavailable")
        say = (host_voice.SOLD_OUT_ONE.format(name=item.name, alt=alts[0].name)
               if len(alts) == 1 else
               host_voice.SOLD_OUT_TWO.format(name=item.name, alt=alts[0].name,
                                              alt2=alts[1].name))
        self._ambiguous = {"ids": [a.id for a in alts], "quantity": qty,
                           "note": note, "offer": True, "utterance": text}
        return _envelope(
            False, say, action, self.e,
            needs={"question": say, "line_id": None, "group_id": None,
                   "code": IssueCode.ITEM_UNAVAILABLE.value,
                   "candidates": [a.id for a in alts]},
            error="item_unavailable")

    def answer(self, text: str) -> Dict[str, Any]:
        """Answer whatever Lily last asked. Fails if she asked nothing."""
        issue = self.pending()
        if issue is None and self._ambiguous is not None:
            return self._answer_item_choice(text)
        if (issue is None and self._allergy_asked
                and (not self._allergy_checked or not self._name)):
            return self._answer_gate(text)        # the model used `answer`
        if issue is None:
            return self._reply(
                "Sorry, I'm not sure what that's for.", "answer", ok=False,
                error="no_open_question")
        self._ambiguous = None
        line_id = issue.line_id

        if issue.code is IssueCode.SIZE_REQUIRED:
            line = self.e.get_line(line_id)
            item = self.config.item(line.item_id) if line else None
            sc = self.e.matcher.match_size(text, item) if item else []
            self._note("answer", "size", text, sc, "matched" if sc else "no_match")
            if not sc:
                return self._reply("Sorry, which size was that?", "answer",
                                   ok=False, error="no_match")
            self.e.set_size(line_id, sc[0].target_id)
            return self._confirm(f"{sc[0].target_name} it is.", "answer")

        oc = self.e.matcher.match_options(text, issue.candidates)
        if oc and ((oc[0].score < _WEAK_MATCH and not oc[0].covers_utterance)
                   or self._cross_name(text, oc[0])):
            # Same weak-match guard as add_modifier: "dragon roll" answered
            # into the tray question scored 0.73 against Salmon Roll — ask
            # again rather than cook the wrong roll.
            self._note("answer", "option", text, oc, "weak")
            oc = []
        self._note("answer", "option", text, oc, "matched" if oc else "no_match")
        if not oc:
            return self._reply(
                "Sorry, I didn't catch that — could you say it again?",
                "answer", ok=False, error="no_match")
        probs = self.e.apply_option(line_id, issue.group_id, oc[0].target_id)
        if probs:
            return self._reply(probs[0].question or probs[0].message, "answer",
                               ok=False, error=probs[0].code.value)
        return self._confirm(f"{oc[0].target_name}, got it.", "answer")

    def _answer_item_choice(self, text: str) -> Dict[str, Any]:
        """The caller's reply to "did you want the X or the Y?"."""
        amb = self._ambiguous or {}
        allowed = set(amb.get("ids", ()))
        if amb.get("offer") and host_voice.is_no(text):
            self._ambiguous = None
            return self._reply(host_voice.OFFER_DECLINED, "answer")
        if amb.get("offer") and host_voice.is_yes(text) and amb.get("ids"):
            first = self.config.item(amb["ids"][0])
            cands = [MatchCandidate(first.id, first.name, 1.0, "item")]
        else:
            cands = [c for c in self.e.matcher.match_items(text)
                     if c.target_id in allowed]
        if not cands or not self.e.matcher.is_decisive(cands):
            names = " or the ".join(
                self.config.item(i).name for i in amb.get("ids", ())
                if self.config.item(i) is not None)
            self._note("answer", "item", text, cands,
                       "ambiguous" if cands else "no_match")
            return self._reply(_DISAMBIGUATE.format(options=names), "answer",
                               ok=False, error="ambiguous" if cands
                               else "no_match")
        self._note("answer", "item", text, cands, "matched")
        self._ambiguous = None
        if amb.get("info") is not None:      # an allergen/diet question, not an order
            return self._info_reply(self._info_about(
                cands[0].target_id, cands[0].target_name, **amb["info"]))
        stored = int(amb.get("quantity") or 1)
        if amb.get("offer"):
            # A plain 'yes' takes the offered dish at the quantity first asked
            # for — the reply names nothing, so there is nothing to re-parse.
            qty = stored
        else:
            # The reply may name the dish ("the 2 papadam and chutney") — its
            # own leading number is not a quantity. Prefer a count spoken
            # OUTSIDE the name in the reply, then in the original utterance,
            # then what was stored when the question was asked.
            qty = self._spoken_quantity(text, cands[0], fallback=0)
            if qty <= 0:
                qty = self._spoken_quantity(str(amb.get("utterance") or ""),
                                            cands[0], fallback=0,
                                            count_none_as=1)
            if qty <= 0:
                qty = stored
        self.e.add_line(cands[0].target_id, quantity=qty,
                        note=str(amb.get("note") or ""))
        word = f"{qty} " if qty > 1 else ""
        return self._confirm(f"{self._ack()} — {word}{cands[0].target_name}.",
                             "answer")

    def confirm_mods(self) -> Dict[str, Any]:
        """Accept an item as-is without discarding a real required choice.

        Some POS menus model an explicit ``NO MODS`` row as the only way to
        satisfy a required modifications group.  This tool selects that row
        when it is the pending choice.  It deliberately refuses to answer an
        unrelated required question such as a combo drink: "no changes" must
        never silently choose Coke, a size, or any other business decision.
        Menus that use ordinary default toppings need no mutation here; the
        acknowledgement is still useful to the voice layer.
        """
        issue = self.pending()
        if issue is None:
            return self._reply("Okay — no changes.", "confirm_mods")
        if not issue.group_id:
            return self._reply(issue.question or "I still need that choice.",
                               "confirm_mods", ok=False,
                               error="wrong_confirmation")

        if issue.code is IssueCode.GROUP_CONFIRMATION_REQUIRED:
            if not self.e.confirm_group(issue.line_id, issue.group_id):
                return self._reply(issue.question or "I still need that choice.",
                                   "confirm_mods", ok=False,
                                   error="wrong_confirmation")
            return self._confirm("Okay — no more changes.", "confirm_mods")

        accepted = {"no mods", "no modifications", "no changes",
                    "as is", "everything on it"}
        option_id = next(
            (oid for oid in issue.candidates
             if self.config.option(oid) is not None
             and (normalize(self.config.option(oid).name) in accepted
                  or accepted.intersection(
                      normalize(a) for a in self.config.option(oid).aliases))),
            None)
        if option_id is None:
            return self._reply(issue.question or "I still need that choice.",
                               "confirm_mods", ok=False,
                               error="wrong_confirmation")

        problems = self.e.apply_option(issue.line_id, issue.group_id, option_id)
        if problems:
            problem = problems[0]
            return self._reply(problem.question or problem.message,
                               "confirm_mods", ok=False,
                               error=problem.code.value)
        return self._confirm("Okay — no changes.", "confirm_mods")

    def _quantity_in_name(self, text: str, option_ids) -> Optional[str]:
        """An option whose OWN NAME starts with the number the caller said.

        Cheng's soups offer "1 Wonton", "2 Wontons", "3 Wontons", "4 Wontons".
        "three wontons" was read as quantity 3 of whichever wonton option the
        matcher liked, and refused ("I can only add one 2 Wontons"), so a
        caller could never order the 3-wonton add-on. When the whole utterance,
        number included, IS an option's name, the number is part of the name.
        """
        toks = _tokens(text)
        # The number may follow a lead-in: "add four wontons", "can I get 3".
        for i, tok in enumerate(toks[:4]):
            if tok.isdigit():
                digit = tok
            elif _NUMBER_WORDS.get(tok, 0) > 0 and tok not in ("a", "an"):
                digit = str(_NUMBER_WORDS[tok])
            else:
                continue
            break
        else:
            return None
        rest = [t for t in toks[i + 1:] if t not in ("please", "thanks")]
        if not rest:
            return None
        want = " ".join([digit] + rest)
        for oid in option_ids:
            opt = self.config.option(oid)
            if opt is not None and opt.available and normalize(opt.name) == want:
                return oid
        return None

    def _cross_name(self, text: str, cand: MatchCandidate) -> bool:
        """The utterance and the matched name each hold a real word the
        other doesn't — "cobb salad" against "Crab Salad" (0.87 fuzzy, two
        different dishes that rhyme). Close enough to guess is not close
        enough to cook: a cross-name must be asked, never applied."""
        opt = self.config.option(cand.target_id)
        name_tokens = set(normalize(cand.target_name).split())
        for alias in (getattr(opt, "aliases", []) or []):
            name_tokens |= set(normalize(alias).split())

        def same(a: str, b: str) -> bool:
            if a == b:
                return True
            return len(a) >= 3 and len(b) >= 3 and (
                a.startswith(b) or b.startswith(a))

        # Judge the caller's RAW words — "Carne Asada" on a Mexican menu is
        # the dish's own name, and translating it first corrupted the check.
        # The phrasebook translation is only a bridge when the raw words
        # share nothing with the name at all ("sin cebolla" -> "no onion").
        utt_tokens = [t for t in normalize(text or "").split()
                      if t not in _FILLERS]
        if not any(same(t, n) for t in utt_tokens for n in name_tokens):
            translated, _lang = phrasebook.to_english(text or "")
            utt_tokens = [t for t in normalize(translated).split()
                          if t not in _FILLERS]

        def translatable(tok: str) -> bool:
            # "pollo", "zyada", "asada": words the phrasebook maps to
            # English are the caller speaking another language, not the
            # name of a different dish. Only an UNTRANSLATABLE leftover
            # ("cobb" against "Crab Salad") can make a cross-name.
            alt, lang = phrasebook.to_english(tok)
            return lang is not None and alt != tok

        utt_left = [t for t in utt_tokens
                    if not any(same(t, n) for n in name_tokens)
                    and t not in _CUE_WORDS and t not in _QTY_WORDS
                    and not translatable(t)]
        if not utt_left:
            return False          # everything said is explained by the name
        # and the name holds a real word the caller never said — 'the',
        # 'and' and head nouns like 'roll' legally shorten a name, so only
        # words absent from the utterance (plurals count as present) count
        return any(len(t) > 3 and not any(same(t, u) for u in utt_tokens)
                   for t in name_tokens)

    def add_modifier(self, text: str, line_id: Optional[str] = None,
                     quantity: Optional[int] = None,
                     placement: str = "whole") -> Dict[str, Any]:
        """Add a topping, side, upgrade or extra to one line.

        When `quantity` is omitted it is read out of the caller's words, so
        "three wontons" and "double pepperoni" are charged correctly even when
        the voice layer passes only the text.
        """
        explicit_quantity = quantity is not None
        if quantity is None:
            quantity = parse_quantity(text)
        line = self._line_or_last(line_id)
        if line is None:
            return self._reply("What would you like that on?", "add_modifier",
                               ok=False, error="no_line")
        try:
            place = Placement(placement)
        except ValueError:
            return self._reply("Sorry, where on it?", "add_modifier", ok=False,
                               error="bad_placement")
        # The BEST match across every group, not the first group with any
        # match. "extra chicken" scores 1.0 against Extra Chicken (ADD) and
        # 0.64 against Extra Hot (spice, checked first): taking the first hit
        # gave the guest a hotter dish and silently dropped their add-on.
        best = None
        for gid in self.e.active_group_ids(line):
            group = self.config.group(gid)
            # Informational groups (Korean banchan, "comes with rice") are
            # told to the caller, never selected by them, and never priced.
            if group is None or group.informational:
                continue
            named = self._quantity_in_name(text, group.option_ids)
            if named is not None:
                oc = [MatchCandidate(named, self.config.option(named).name, 1.0,
                                     "option", True)]
                consumed = True
            else:
                oc = self.e.matcher.match_options(text, list(group.option_ids))
                consumed = False
            if not oc:
                continue
            if best is None or oc[0].score > best[1][0].score + 1e-9:
                best = (gid, oc, consumed)
        if best is not None:
            gid, oc, consumed = best
            top = oc[0]
            if not consumed and ((top.score < _WEAK_MATCH
                                  and not top.covers_utterance)
                                 or self._cross_name(text, top)):
                # Mirror of the item path's weak-match guard ("pad thai" vs
                # "Paratha"). Without it a fuzzy-only cross-name match added
                # the WRONG food: "Dragon Roll" inside the Totoro tray's
                # twelve basic rolls scored 0.73 against Salmon Roll — saved
                # only by the one-per-option cap. Close enough to guess is
                # not close enough to cook; ask instead.
                self._note("add_modifier", "option", text, oc, "weak")
                group = self.config.group(gid)
                ask = (group.prompt if group is not None and group.prompt
                       else "Sorry, which one did you mean?")
                return _envelope(
                    False, ask, "add_modifier", self.e,
                    needs={"question": ask, "line_id": line.line_id,
                           "group_id": gid, "code": "ambiguous_match",
                           "candidates": [c.target_id for c in oc[:3]]},
                    error="low_confidence")
            self._note("add_modifier", "option", text, oc, "matched")
            probs = self.e.apply_option(line.line_id, gid, oc[0].target_id,
                                        quantity=(1 if consumed and not explicit_quantity
                                                  else quantity),
                                        placement=place)
            if probs:
                return self._reply(probs[0].question or probs[0].message,
                                   "add_modifier", ok=False,
                                   error=probs[0].code.value)
            return self._confirm(f"Added {oc[0].target_name}.", "add_modifier")
        self._note("add_modifier", "option", text, [], "no_match")
        return self._reply("We don't have that, sorry.", "add_modifier",
                           ok=False, error="no_match")

    def remove_modifier(self, text: str,
                        line_id: Optional[str] = None) -> Dict[str, Any]:
        """Take something off — 'no onion'. This must reach the kitchen, not
        just the read-back."""
        line = self._line_or_last(line_id)
        if line is None:
            return self._reply(_NOTHING_YET, "remove_modifier", ok=False,
                               error="no_line")
        # Strip a leading negation cue before matching ("no salmon" must
        # reach "Salmon Roll" — the name is LONGER than the words around the
        # cue, so without this the under-specification floor never applies
        # and a real removal heard "I'm not sure that's on there"). The
        # weak-match guard below still backstops what stripping can't fix.
        probe_text = text or ""
        for cue in _NEGATION_CUES:
            if probe_text.startswith(cue):
                probe_text = probe_text[len(cue):]
                break
        oc = self.e.matcher.match_options(probe_text)
        if not oc:
            oc = self.e.matcher.match_options(text)
        if oc and ((oc[0].score < _WEAK_MATCH and not oc[0].covers_utterance)
                   or self._cross_name(text, oc[0])):
            # A weak cross-name match must never take the WRONG topping off:
            # "no dragon" scored 0.73 against a selected Salmon Roll. Removing
            # the wrong modifier is as bad as adding one.
            self._note("remove_modifier", "option", text, oc, "weak")
            oc = []
        self._note("remove_modifier", "option", text, oc, "matched" if oc else "no_match")
        if oc and self.e.remove_option(line.line_id, oc[0].target_id):
            return self._confirm(f"Okay, no {oc[0].target_name.lower()}.", "remove_modifier")
        return self._reply("I'm not sure that's on there.", "remove_modifier",
                           ok=False, error="no_match")

    def set_quantity(self, quantity: int,
                     line_id: Optional[str] = None,
                     text: str = "") -> Dict[str, Any]:
        line, refusal = self._target_line(line_id, text, "set_quantity")
        if refusal is not None:
            return refusal
        if quantity < 1:
            return self.remove_item(line.line_id)
        # Same ceiling parse_quantity speaks aloud (a caller cannot ask for
        # more than 99 of one line). An unbounded tool argument minted a
        # ten-million-dollar ticket on the adversarial BNR pass.
        if int(quantity) > 99:
            return self._reply(
                "I can put at most 99 of one item on an order.", "set_quantity",
                ok=False, error="quantity_cap")
        line.quantity = int(quantity)
        return self._confirm(f"Made it {line.quantity}.", "set_quantity")

    def split_line(self, line_id: Optional[str] = None,
                   take: int = 1, text: str = "") -> Dict[str, Any]:
        """Peel units off a line so they can differ — 'two tacos, one no onion'.

        Modifiers are per-unit. Without this, 'add guac' on a line of three
        charges guac three times, which is right until the caller wanted it on
        only one of them. The voice layer must call this; it cannot happen on
        its own.
        """
        line, refusal = self._target_line(line_id, text, "split_line")
        if refusal is not None:
            return refusal
        new = self.e.split_line(line.line_id, take)
        if new is None:
            return self._reply("That's only one already.", "split_line",
                               ok=False, error="not_splittable")
        return self._confirm("Sure — I'll do those separately.", "split_line")

    def remove_item(self, line_id: Optional[str] = None,
                    text: str = "") -> Dict[str, Any]:
        line, refusal = self._target_line(line_id, text, "remove_item")
        if refusal is not None:
            return refusal
        if not self.e.remove_line(line.line_id):
            return self._reply("Nothing to take off.", "remove_item", ok=False,
                               error="no_line")
        return self._confirm("Taken off.", "remove_item")

    def search_menu(self, text: str = "", limit: int = 8) -> Dict[str, Any]:
        """Answer 'what do you have?' — never used to decide, only to tell."""
        if text:
            hits = self.e.matcher.match_items(text)
            names = [h.target_name for h in hits[:limit]]
        else:
            names = [i.name for i in self.config.items if i.available][:limit]
        if not names:
            return self._reply(_NOT_ON_MENU, "search_menu", ok=False,
                               error="no_match")
        return self._reply("We have " + ", ".join(names) + ".", "search_menu")

    def item_info(self, text: str = "") -> Dict[str, Any]:
        """Answer 'does that have nuts?' / 'what's vegan?' from DECLARED
        facts only. A missing declaration is reported as such — silence is
        never turned into a safety claim (menu_enrichment's rule).

        The caller's words are a whole question, not a dish name, so this
        finds the dish inside it and resolves "that"/"it" to the item just
        ordered. A dish word that fits several items ("the korma") is asked
        about, never guessed, because a guess attaches one dish's allergens to
        another. An allergy question that names no dish is never answered with
        "what else can I get you": it is sent to the restaurant.
        """
        import menu_enrichment as me
        if not isinstance(text, str) or not text.strip():
            return self._reply("What would you like to know about?",
                               "item_info", ok=False, error="no_text")
        words = re.findall(r"[a-z0-9]+", text.lower().replace("'", ""))
        vocab = {t for table in (me.ALLERGENS, me.DIETARY)
                 for cid, (_label, aliases) in table.items()
                 for name in (cid, *aliases)
                 for t in re.findall(r"[a-z0-9]+", name.lower())}
        core = [w for w in words if w not in _INFO_SCAFFOLD and w not in vocab]
        pronoun = any(w in _INFO_PRONOUNS for w in words)

        cands: List[Any] = []
        if core:
            plain = [w for w in words if w not in _INFO_SCAFFOLD]
            matcher = self.e.matcher
            # Stricter than ordering: a loose fuzzy hit ("pad thai" -> Paratha)
            # is fine to read back, but must never carry an allergen answer.
            found = [c for c in ([x for x in matcher.match_items(a)
                                  if x.covers_utterance or x.score >= 0.9]
                                 for a in (text, " ".join(plain), " ".join(core))
                                 if a.strip()) if c]
            cands = next((c for c in found if matcher.is_decisive(c)),
                         found[0] if found else [])
        elif pronoun:
            last = self.e.last_line()
            item = self.config.item(last.item_id) if last else None
            if item is not None:
                cands = [MatchCandidate(item.id, item.name, 1.0, "item")]

        if not cands:
            diet, allergen, allergic = self._info_tags(me, words)
            if diet:                                   # "what's gluten-free?"
                ids = me.items_with_dietary(self.config, diet)
                label = me.dietary_label(diet)
                if not ids:
                    return self._info_reply(f"Nothing on this menu is marked "
                                            f"{label} yet. {_INFO_ASK}")
                names = [self.config.item(i).name for i in ids[:6]]
                more = " and others" if len(ids) > len(names) else ""
                tail = (" " + _INFO_CONFIRM) if diet.endswith("_free") else ""
                return self._info_reply(f"These are marked {label}: "
                                        + ", ".join(names) + more + "." + tail)
            if allergen or allergic:
                # The menu's declarations are not complete enough to answer
                # across dishes, and a list of dishes that DO declare an
                # allergen would read as "the rest are safe".
                return self._info_reply(
                    "I can't check that for you. If you have an allergy, "
                    "please tell the restaurant before ordering.")
            if core:
                return self._reply(
                    "I couldn't find that dish on the menu, so I can't speak "
                    "to what's in it. " + _INFO_ASK, "item_info", ok=False,
                    error="no_match")
            return self._reply("Which dish do you mean?", "item_info",
                               ok=False, error="no_subject")

        # Tags are read from what is left after the dish's own name, so a dish
        # called "Veg Samosa" or "Peanut Soup" is not mistaken for the question.
        own = {t for c in cands[:3]
               for t in re.findall(r"[a-z0-9]+", c.target_name.lower())}
        diet, allergen, allergic = self._info_tags(
            me, [w for w in words if w not in own])
        ask = {"diet": diet, "allergen": allergen, "allergic": allergic}

        if self.e.matcher.is_decisive(cands):
            return self._info_reply(self._info_about(
                cands[0].target_id, cands[0].target_name, **ask))
        said = [self._info_about(c.target_id, c.target_name, **ask)
                for c in cands]
        names = " or the ".join(c.target_name for c in cands[:3])
        if all("hasn't marked" in s for s in said):
            return self._info_reply(
                f"The restaurant hasn't marked allergen or diet facts for the "
                f"{names}" + (" or similar dishes" if len(cands) > 3 else "")
                + f". {_INFO_ASK}")
        say = f"Which one — the {names}?"
        needs = {"question": say, "line_id": None, "group_id": None,
                 "code": IssueCode.AMBIGUOUS_MATCH.value,
                 "candidates": [c.target_id for c in cands[:3]]}
        if self.pending() is None:       # else `answer` belongs to that question
            self._ambiguous = {"ids": [c.target_id for c in cands[:8]],
                               "info": ask}
        return _envelope(False, say, "item_info", self.e, needs=needs,
                         error="ambiguous")

    @staticmethod
    def _info_tags(me, words):
        """(dietary tag, allergen, allergy-flavoured?) named in the words."""
        grams = [" ".join(words[i:i + n]) for n in (2, 1)
                 for i in range(len(words) - n + 1)]
        diet = next((c for c in map(me.normalize_dietary, grams) if c), None)
        allergen = (None if diet else
                    next((c for c in map(me.normalize_allergen, grams) if c),
                         None))
        vague = (any(g in me.AMBIGUOUS for g in grams)
                 or any(w in _INFO_ALLERGY_WORDS for w in words))
        return diet, allergen, vague or allergen is not None

    def _with_pending(self, say: str, action: str) -> Dict[str, Any]:
        """An answer, followed by whatever the order is still waiting on."""
        issue = self.pending()
        ask = self._pending_question(issue) if issue and issue.question else ""
        return self._reply(f"{say} {ask}" if ask else say, action)

    def _info_reply(self, say: str) -> Dict[str, Any]:
        return self._with_pending(say, "item_info")

    def _info_about(self, item_id: str, name: str, diet=None, allergen=None,
                    allergic=False) -> str:
        import menu_enrichment as me
        allergens = me.item_allergens(self.config, item_id)
        dietary = me.item_dietary(self.config, item_id)
        if diet:
            if diet in dietary:
                return (f"Yes — the {name} is listed as "
                        f"{me.dietary_label(diet)}.")
            return (f"I don't have it written down that the {name} is "
                    f"{me.dietary_label(diet)}, and I won't guess. {_INFO_ASK}")
        if allergen:
            if allergen in allergens:
                return (f"Yes — the menu lists {me.allergen_label(allergen)} "
                        f"in the {name}. {_INFO_CONFIRM}")
            return (f"I can't confirm that the {name} is free of "
                    f"{me.allergen_label(allergen)} — it isn't in the notes I "
                    f"have. {_INFO_ASK}")
        parts = []
        if allergens:
            parts.append("declared allergens: " + ", ".join(
                me.allergen_label(a) for a in allergens))
        if dietary:
            parts.append("marked " + " and ".join(
                me.dietary_label(d) for d in dietary))
        if not parts:
            return (f"The restaurant hasn't marked allergen or diet facts for "
                    f"the {name}. {_INFO_ASK}")
        tail = f" {_INFO_CONFIRM}" if allergens or allergic else ""
        return f"The {name}: " + "; ".join(parts) + "." + tail

    def read_back(self) -> Dict[str, Any]:
        """The confirmation before placing. Says only what CHANGED plus the
        total — reciting every default topping is how a read-back turns into
        a minute of dead air."""
        if not self.e.lines:
            return self._reply(_NOTHING_YET, "read_back", ok=False,
                               error="empty")
        return self._reply(self.e.read_back(), "read_back")

    def ready_to_place(self) -> Dict[str, Any]:
        """Ask before hanging up. If this says no, the order is NOT complete
        and the answer in `needs` has to be asked first."""
        if not self.e.lines:
            return self._reply(_NOTHING_YET, "ready_to_place", ok=False,
                               error="empty")
        if not self.e.is_submittable():
            q = self.e.next_question() or "I still need one more thing."
            return self._reply(q, "ready_to_place", ok=False,
                               error="incomplete")
        if not self._allergy_checked or not self._name:
            if not self._allergy_asked:
                # The waiter's question: a name for the order, and allergies.
                # Asked ONCE, and here, so it cannot be forgotten the way a
                # prompt instruction can. Once asked it never blocks again: a
                # caller who hung up or a model that lost the answer must not
                # cost the restaurant the order.
                self._allergy_asked = True
                say = self._gate_question()
                code = "allergy_check" if not self._allergy_checked else "name_check"
                return _envelope(
                    False, say, "ready_to_place", self.e,
                    needs={"question": say, "line_id": None, "group_id": None,
                           "code": code, "candidates": []},
                    error=code)
            if not self._allergy_checked:
                self._allergy_unconfirmed = True  # asked; never answered
        say = self.e.read_back()
        n = self.ctx.prep_minutes
        if n:
            # An honest time, from the restaurant's own settings: the prep time
            # plus however busy it says it is right now.
            pay_now = self.e.price().pay_now
            say += (host_voice.READY_AFTER_PAYING if pay_now
                    else host_voice.READY_AT_PICKUP).format(n=n)
        return self._reply(say, "ready_to_place")

    def _gate_question(self) -> str:
        """One question that gets what the kitchen needs, in as few words as a
        good host would use. A regular's last allergy is asked about again —
        never assumed."""
        need_name, need_allergy = not self._name, not self._allergy_checked
        note = ((self.ctx.returning or {}).get("allergy_note") or "")[:80]
        if need_name and need_allergy:
            return (host_voice.GATE_BOTH_AGAIN.format(note=note) if note
                    else host_voice.GATE_BOTH)
        if need_allergy:
            return (host_voice.GATE_ALLERGY_AGAIN.format(note=note) if note
                    else host_voice.ALLERGY_ASK)
        return host_voice.GATE_NAME

    def _answer_gate(self, text: str) -> Dict[str, Any]:
        """The model sent the caller's reply to the gate through `answer`:
        'Sam, no allergies'. Take the name and the allergy part separately."""
        name, rest = (host_voice.split_name(text) if not self._name
                      else ("", (text or "").strip()))
        reply = None
        if name:
            reply = self.set_name(name)
        if rest and not self._allergy_checked:
            reply = self.note_allergy(rest)
        if reply is None:
            return self.note_allergy(text) if not self._allergy_checked \
                else self.set_name(text)
        return reply

    def set_name(self, text: str = "") -> Dict[str, Any]:
        """The name for the order ('it's Sam'). Shown on the ticket and the POS."""
        name = host_voice.extract_name(text if isinstance(text, str) else "")
        if not name:
            return self._reply(host_voice.NAME_RETRY, "set_name", ok=False,
                               error="no_name")
        self._name = name
        say = host_voice.rotate(host_voice.NAME_THANKS, self._acks).format(
            first=name.split()[0])
        self._acks += 1
        return self._with_pending(say, "set_name")

    def set_text_number(self, text: str = "") -> Dict[str, Any]:
        """Send the checkout link to a different number than the caller ID —
        a landline caller, or someone ordering for another phone."""
        number = host_voice.parse_us_number(text if isinstance(text, str) else "")
        if not number:
            return self._reply(host_voice.NUMBER_BAD, "set_text_number",
                               ok=False, error="bad_number")
        blocked = self.ctx.is_suppressed
        if blocked is not None and blocked(number):
            return self._reply(host_voice.NUMBER_BLOCKED, "set_text_number",
                               ok=False, error="number_blocked")
        self._text_to = number
        return self._with_pending(
            host_voice.NUMBER_OK.format(
                digits=host_voice.spoken_digits(number[-4:])), "set_text_number")

    def store_info(self, text: str = "") -> Dict[str, Any]:
        """Hours, wait time, pickup, address: the things a host is asked all
        day. Answered ONLY from what the restaurant configured — never guessed."""
        topic = host_voice.info_topic(text if isinstance(text, str) else "")
        c = self.ctx
        if topic == "delivery":
            say = host_voice.PICKUP_ONLY
        elif topic == "address":
            say = host_voice.ADDRESS_UNKNOWN
        elif topic == "wait":
            say = (host_voice.WAIT_TIME.format(n=c.prep_minutes)
                   if c.prep_minutes else host_voice.WAIT_UNKNOWN)
        elif topic == "hours":
            h = c.hours or {}
            if h.get("configured") and h.get("open_now") and h.get("closes"):
                say = host_voice.HOURS_OPEN.format(closes=h["closes"])
            elif h.get("configured") and not h.get("open_now") and h.get("next_open"):
                say = host_voice.HOURS_CLOSED.format(next_open=h["next_open"])
            else:
                say = host_voice.HOURS_UNKNOWN
        else:
            say = host_voice.INFO_GENERIC
        return self._with_pending(say, "store_info")

    def reorder_last(self) -> Dict[str, Any]:
        """'The usual': repeat the caller's last real order. Anything that is
        sold out or no longer valid is skipped AND SAID, never dropped silently."""
        prev = (self.ctx.returning or {}).get("lines") or []
        if not prev:
            return self._reply(host_voice.USUAL_NONE, "reorder_last", ok=False,
                               error="no_history")
        if self._reordered:
            return self._with_pending("I've already added your usual.", "reorder_last")
        self._reordered = True
        added, skipped = [], []
        for pl in prev:
            item = self.config.item(pl.get("item_id"))
            if item is None or not item.available:
                skipped.append(pl.get("item_name") or "one item")
                continue
            size = pl.get("size_id")
            if not (item.has_sizes and any(s.id == size and s.available for s in item.sizes)):
                size = None
            line = self.e.add_line(item.id, quantity=int(pl.get("quantity") or 1),
                                   size_id=size, note=pl.get("note") or "")
            lost = []
            for m in pl.get("modifiers", []):
                if m.get("informational") or m.get("is_default"):
                    continue          # how the dish normally comes
                opt = self.config.option(m.get("option_id"))
                if opt is None or not opt.available:
                    lost.append(m.get("option_name") or "an extra")
                    continue
                try:
                    self.e.apply_option(line.line_id, m["group_id"], m["option_id"],
                                        quantity=int(m.get("quantity") or 1),
                                        placement=Placement(m.get("placement") or "whole"))
                except Exception:                      # noqa: BLE001
                    lost.append(m.get("option_name") or "an extra")
            for removed in pl.get("removed_defaults", []):
                opt = next((o for o in self.config.options if o.name == removed), None)
                if opt is not None:
                    self.e.remove_option(line.line_id, opt.id)
            added.append((item, int(pl.get("quantity") or 1)))
            if lost:
                skipped.append(f"the {', '.join(lost)} on the {item.name}")
        if not added:
            return self._reply(
                "I'm sorry, those dishes aren't available today. What can I get started for you?",
                "reorder_last", ok=False, error="nothing_available")
        summary = host_voice.describe_lines(
            [{"item_name": it.name, "quantity": q} for it, q in added]) \
            or "your last order"
        say = host_voice.USUAL_ADDED.format(summary=summary)
        if skipped:
            say += host_voice.USUAL_SKIPPED.format(skipped=" and ".join(skipped))
        return self._confirm(say, "reorder_last")

    def note_allergy(self, text: str = "") -> Dict[str, Any]:
        """An allergy or dietary need, or "none". Written onto the order so the
        kitchen sees it. Cherry can pass this on; it cannot clear a dish, so
        nothing here ever says anything is safe."""
        text = text if isinstance(text, str) else ""
        kind = host_voice.classify_allergy(text)
        remembered = ((self.ctx.returning or {}).get("allergy_note") or "").strip()
        if remembered and self._allergy_asked and host_voice.confirms_remembered(text):
            # "Does that still apply?" -> "yes" / "same as before": keep what was
            # on file. Dropping a real allergy is the costly mistake, so a yes
            # re-records it rather than asking the caller to say it again.
            text, kind = remembered, "note"
        elif remembered and self._allergy_asked:
            more = re.match(r"(?i)^(?:yes|yeah|yep|yup|same|still)[,.\s]+(?:and\s+|plus\s+)?"
                            r"(?:also\s+)?(.+)$", text.strip())
            if more:                        # "yes, and also shellfish": both
                text, kind = f"{remembered}; {more.group(1)}", "note"
        if kind == "empty":
            return self._reply(host_voice.ALLERGY_ASK, "note_allergy",
                               ok=False, error="no_text")
        if kind == "yes":                     # "yes" — to what?
            return self._reply(host_voice.ALLERGY_FOLLOWUP, "note_allergy",
                               ok=False, error="needs_detail")
        self._allergy_checked = True
        self._allergy_unconfirmed = False
        if kind == "none":
            return self._with_pending(host_voice.ALLERGY_NONE, "note_allergy")
        note = host_voice.clean_note(text)
        self._allergy_note = host_voice.clean_note(
            f"{self._allergy_note}; {note}" if self._allergy_note else note)
        return self._with_pending(host_voice.ALLERGY_NOTED, "note_allergy")

    def snapshot(self) -> Dict[str, Any]:
        """The order as the store and every POS bridge consume it."""
        snap = self.e.to_normalized_order()
        if self._allergy_note:
            snap["allergy"] = {"checked": True, "note": self._allergy_note}
        elif self._allergy_unconfirmed:
            snap["allergy"] = {"checked": False, "note": ""}
        return snap


# ---------------------------------------------------------------------------
# Tool definitions for Inworld
# ---------------------------------------------------------------------------

def _tool(name: str, description: str, props: Dict[str, Any],
          required: Optional[List[str]] = None) -> Dict[str, Any]:
    return {
        "name": name,
        "description": description,
        "parameters": {"type": "object", "properties": props,
                       "required": required or []},
    }


_TEXT = {"type": "string", "description": "The caller's own words, verbatim. "
                                          "Do not clean up or normalise them — "
                                          "the matcher handles mishearings and "
                                          "aliases, and paraphrasing loses the "
                                          "information it needs."}
_LINE = {"type": "string", "description": "Which line to act on. Omit for the "
                                          "most recent one, which is almost "
                                          "always what the caller means."}
_WHICH = {"type": "string",
          "description": "The caller's words naming WHICH item on the order "
                         "they mean, e.g. 'the samosas'. Use this instead of "
                         "line_id; omit it for the most recent item."}

TOOL_SCHEMAS: List[Dict[str, Any]] = [
    _tool("add_item",
          "Put a menu item on the order. Call this whenever the caller names "
          "something they want. If the words are ambiguous the tool will come "
          "back with a question to ask — do not pick for them.",
          {"text": _TEXT,
           "quantity": {"type": "integer", "minimum": 1,
                        "description": "Only if the caller stated a number "
                                       "that is not in `text`."},
           "note": {"type": "string",
                    "description": "A free-text kitchen note such as 'well "
                                   "done'. Never put a modifier here — "
                                   "modifiers are priced, notes are not."}},
          ["text"]),
    _tool("answer",
          "Answer the question Lily just asked (spice level, size, choice of "
          "side). Use this, not add_modifier, whenever the previous turn ended "
          "in a question from the engine.",
          {"text": _TEXT}, ["text"]),
    _tool("item_info",
          "Answer ANY allergy, ingredient or diet question — 'does that have "
          "nuts?', 'is the soup vegan?', 'what's gluten-free?', 'I'm allergic "
          "to peanuts'. Pass the caller's own words; 'that' or 'it' means the "
          "item just ordered. Speaks only what the restaurant has declared; "
          "if nothing is declared it says so. Never answer these yourself, "
          "never guess from a dish name, and never tell a caller something "
          "is safe.",
          {"text": _TEXT}, ["text"]),
    _tool("note_allergy",
          "Record an allergy or dietary need the caller mentions, or that they "
          "have none. Call it the moment a caller volunteers one ('my son is "
          "allergic to peanuts'), and whenever `ready_to_place` asks about "
          "allergies: pass their words, even a plain 'no'. It writes a note "
          "onto the order for the kitchen. It never says anything is safe.",
          {"text": _TEXT}, ["text"]),
    _tool("set_name",
          "Record the name for the order. Call it when the caller gives a name "
          "('it's Sam', 'put it under Maria'), including when they give it "
          "together with an allergy answer: send each part to its own tool.",
          {"text": _TEXT}, ["text"]),
    _tool("set_text_number",
          "The caller wants the checkout link texted to a DIFFERENT number "
          "than the one they are calling from ('text it to my cell', 'I'm on a "
          "landline'). Pass the digits they say. Call it BEFORE ready_to_place.",
          {"text": _TEXT}, ["text"]),
    _tool("store_info",
          "Answer 'what time do you close', 'are you open', 'how long will it "
          "take', 'do you deliver', 'where are you'. Answers only from what the "
          "restaurant has set up; never guess a time or an address.",
          {"text": _TEXT}, ["text"]),
    _tool("reorder_last",
          "The caller wants what they had last time: 'the usual', 'same as "
          "before', 'my regular'. Only works for a returning caller; takes no "
          "arguments. Anything unavailable is skipped and said.",
          {}, []),
    _tool("confirm_mods",
          "The caller accepts the item as it normally comes — 'yes', 'that's "
          "fine', 'no changes', or 'everything on it'. This tool takes no "
          "caller text. Never use it for a required size, side, or drink.",
          {}, []),
    _tool("add_modifier",
          "Add a topping, extra, upgrade or included choice to a line the "
          "caller has already ordered.",
          {"text": _TEXT, "line_id": _LINE,
           "quantity": {"type": "integer", "minimum": 1,
                        "description": "For 'double pepperoni'."},
           "placement": {"type": "string",
                         "enum": ["whole", "left", "right"],
                         "description": "Pizza half-and-half only."}},
          ["text"]),
    _tool("remove_modifier",
          "Take something off an item — 'no onion', 'hold the mayo'.",
          {"text": _TEXT, "line_id": _LINE}, ["text"]),
    _tool("set_quantity",
          "Change how many of a line the caller wants.",
          {"quantity": {"type": "integer", "minimum": 0, "maximum": 99,
                        "description": "How many the caller wants, 1-99. 0 "
                                       "removes the line entirely."},
           "text": _WHICH, "line_id": _LINE},
          ["quantity"]),
    _tool("split_line",
          "Split a multi-unit line so the units can differ. Call this BEFORE "
          "adding a modifier the caller wants on only some of them — 'three "
          "tacos, one with guac'.",
          {"text": _WHICH, "line_id": _LINE,
           "take": {"type": "integer", "minimum": 1,
                    "description": "How many units to peel off."}},
          []),
    _tool("remove_item", "Take a whole item off the order. Pass `text` with the "
                         "caller's words when they name which item.",
          {"text": _WHICH, "line_id": _LINE}, []),
    _tool("search_menu",
          "Tell the caller what is available. Never use the result to decide "
          "what they meant — use add_item for that.",
          {"text": {"type": "string",
                    "description": "Optional. Omit to list the menu."}}, []),
    _tool("read_back",
          "Read the order back with the total. Call before ending the call, "
          "and any time the caller asks what they have.", {}, []),
    _tool("ready_to_place",
          "Check the order is complete and get the final confirmation "
          "sentence. If ok is false the order is NOT complete: ask what is in "
          "`needs` and do not end the call.", {}, []),
]
