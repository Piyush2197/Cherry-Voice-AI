#!/usr/bin/env python3
"""Whole calls through the real gateway and server, with providers failing on
demand. Every scenario here was a real gap found by running the system; each
assertion is the behaviour a caller or restaurant depends on."""

from __future__ import annotations

import json
import threading
import traceback
import urllib.error
import urllib.request

import rehearsal
from rehearsal import REAL_URLOPEN, Stack

CHECKOUT_OK = "texted your checkout link"


def order(s, cid, text="one vegetable samosa", frm="+13135550123"):
    assert s.call(cid, frm=frm)[0] == 200
    s.tool(cid, "add_item", text=text)
    s.tool(cid, "ready_to_place")


def kinds(s):
    return [e["kind"] for e in s.store.events()]


def get(s, path, key="apikey"):
    req = urllib.request.Request(f"http://127.0.0.1:{s.sport}{path}",
                                 headers={"X-Cherry-Key": key})
    with REAL_URLOPEN(req, timeout=20) as r:
        return r.status, json.loads(r.read())


def t_happy_path_itemized_checkout_texted_and_nothing_else():
    s = Stack()
    try:
        assert "Pink Garlic" in s.call("a1")[1]["say"]
        s.tool("a1", "add_item", text="one vegetable samosa")
        assert "$4.23" in s.tool("a1", "read_back")[1]["say"]
        s.tool("a1", "ready_to_place")
        code, done = s.finish("a1")
        assert code == 200 and CHECKOUT_OK in done["say"], done
        assert len(s.fake.sms) == 1, s.fake.sms           # the guest, no staff ticket
        sms = s.fake.sms[0]
        assert sms["to"] == "+13135550123" and "https://square.link/" in sms["text"]
        assert "$4.23" in sms["text"] and "+15869805199" in sms["text"]
        posts = [u for m, u, b in s.fake.square if m == "POST"]
        assert len(posts) == 1 and posts[0].endswith("/online-checkout/payment-links")
        line = s.fake.square[0][2]["order"]["line_items"][0]
        assert line["name"].startswith("Vegetable Samosa") and line["quantity"] == "1"
        assert not s.fake.transfers, "a successful order must not touch staff"
        assert kinds(s)[-2:] == ["order.placed", "payment.link_sent"], kinds(s)
        rows = s.store.conn.execute(
            "SELECT heard, outcome, resolved_id, tool FROM resolution").fetchall()
        assert len(rows) == 1 and rows[0]["heard"] == "one vegetable samosa" \
            and rows[0]["outcome"] == "matched" and rows[0]["tool"] == "add_item", \
            [dict(r) for r in rows]
    finally:
        s.close()


def t_a_failed_checkout_puts_a_person_on_the_line():
    """Square down, SMS down and a mismatched Square total each used to leave
    the caller told 'staff will help' with nobody ever called."""
    s = Stack()
    try:
        for name, arm in (("square_down", lambda: setattr(s.fake, "square_down", True)),
                          ("sms_down", lambda: setattr(s.fake, "sms_down", True)),
                          ("total_mismatch", lambda: setattr(s.fake, "total_override", 99999))):
            s.fake.square_down = s.fake.sms_down = False
            s.fake.total_override = None
            before = len(s.fake.transfers)
            arm()
            order(s, f"b-{name}")
            code, done = s.finish(f"b-{name}")
            assert code == 200 and "staff will need to help you" in done["say"], (name, done)
            assert len(s.fake.transfers) == before + 1, name
            url, body = s.fake.transfers[-1]
            assert body["to"] == "+15869805199" and f"b-{name}" in url, (name, body)
        assert "voice.handoff_succeeded" in kinds(s)
        assert any(m == "DELETE" for m, u, b in s.fake.square), \
            "a link whose total differs from the quote must be revoked"
    finally:
        s.close()


def t_transfer_failure_tells_the_caller_how_to_reach_staff_and_alerts():
    s = Stack()
    try:
        s.fake.transfer_down = True
        order(s, "e2")
        code, body = s.gw("POST", "/v1/voice/calls/e2/handoff", {})
        assert code == 200, (code, body)                 # was a bare 502
        assert "five eight six, nine eight zero, five one nine nine" in body["say"]
        assert "voice.handoff_failed" in kinds(s)
        alerts = get(s, "/v1/ops/snapshot")[1]["alerts"]
        assert any("handoff" in json.dumps(a).lower() for a in alerts), alerts
        # ...and the alert reaches the owner's phone by text, exactly once.
        import production_jobs as jobs
        sender = jobs.SmsAlert(s.app.sms, ["+13135550100"])
        first = jobs.dispatch_alerts(s.store, sender)
        again = jobs.dispatch_alerts(s.store, sender)
        assert first["sent"] >= 1 and again["sent"] == 0, (first, again)
        owner_texts = [m for m in s.fake.sms if m["to"] == "+13135550100"]
        assert owner_texts and "CRITICAL" in owner_texts[0]["text"], owner_texts
        assert "+13135550123" not in json.dumps(owner_texts), "caller number leaked"
    finally:
        s.close()


def t_requested_handoff_goes_to_the_direct_line_once():
    s = Stack()
    try:
        order(s, "e1")
        for _ in range(2):
            assert "connect you" in s.gw("POST", "/v1/voice/calls/e1/handoff", {})[1]["say"]
        assert len(s.fake.transfers) == 1
        assert s.fake.transfers[0][1]["to"] == "+15869805199"
    finally:
        s.close()


def t_replayed_finish_does_not_bounce_a_paid_caller_to_staff():
    s = Stack()
    try:
        order(s, "i1")
        first, second = s.finish("i1"), s.finish("i1")
        assert first == second and CHECKOUT_OK in first[1]["say"], (first, second)
        assert len([1 for m, u, b in s.fake.square if m == "POST"]) == 1
        assert len(s.fake.sms) == 1 and not s.fake.transfers
    finally:
        s.close()


def t_server_restart_mid_call_resumes_the_same_cart():
    """A deploy or crash while callers are on the line must not lose them."""
    s = Stack()
    try:
        s.call("f1")
        s.tool("f1", "add_item", text="butter chicken")
        s.tool("f1", "answer", text="medium")
        s.tool("f1", "add_item", text="one vegetable samosa")
        before = s.tool("f1", "read_back")[1]["say"]
        n_res = s.store.conn.execute("SELECT count(*) AS n FROM resolution").fetchone()["n"]
        assert int(n_res) >= 3, n_res
        s.restart_server()                              # the process is gone
        after = s.tool("f1", "read_back")[1]["say"]
        assert after == before, (before, after)
        assert int(s.store.conn.execute("SELECT count(*) AS n FROM resolution").fetchone()["n"]) \
            == int(n_res), "replaying the journal must not log new evidence"
        assert "call.resumed" in kinds(s)
        s.tool("f1", "ready_to_place")
        code, done = s.finish("f1")
        assert CHECKOUT_OK in done["say"], done          # and the order completes
        assert not s.fake.transfers, "a resumed call must not bounce to staff"
        # a replayed 'start call' after the restart keeps the cart too
        s.call("f2"); s.tool("f2", "add_item", text="one vegetable samosa")
        s.restart_server()
        again = s.call("f2")[1]
        assert "Vegetable Samosa" in again["say"], again
    finally:
        s.close()


def t_a_call_that_cannot_be_rebuilt_exactly_goes_to_staff_instead():
    s = Stack()
    try:
        s.call("g1")
        s.tool("g1", "add_item", text="one vegetable samosa")
        # damage the saved cart so the replay cannot match it
        s.store.save_cart(s.store.open_session_for_call("g1")["id"], {"corrupt": True})
        s.restart_server()
        say = s.tool("g1", "read_back")[1]["say"]
        assert "connect you with the restaurant" in say, say
        assert "call.resume_failed" in kinds(s)
        assert len(s.fake.transfers) == 1
    finally:
        s.close()


def t_a_menu_change_during_a_call_does_not_change_the_resumed_cart():
    s = Stack()
    try:
        s.call("h1")
        s.tool("h1", "add_item", text="one vegetable samosa")
        old_total = s.tool("h1", "read_back")[1]["say"]
        mv = s.store.live_menu("pink-garlic-shelby")
        repriced = mv["yaml"].replace("price: '3.99'", "price: '5.99'")
        assert repriced != mv["yaml"]
        s.store.publish_menu("pink-garlic-shelby", repriced, item_count=144)
        live_price = s.store.load_live_config("pink-garlic-shelby")[0]
        assert any(i.base_price_cents == 599 for i in live_price.items if i.id == "pg_veg_samosa_2pcs")
        s.restart_server()
        # the caller heard $4.23 and must be charged $4.23, not the new price
        assert s.tool("h1", "read_back")[1]["say"] == old_total
        assert "$4.23" in old_total
    finally:
        # leave the shared database's live menu as we found it
        s.store.publish_menu("pink-garlic-shelby", mv["yaml"], item_count=144)
        s.close()


def t_a_location_that_cannot_check_out_sends_the_caller_straight_to_staff():
    """Bun N Run runs Toast and has no Square link: Lily must not take a whole
    order and only then admit she cannot finish it."""
    s = Stack(extra_locations=(("bun-n-run-ferndale", "manual",
                                "+13135550222", "+12485547999"),))
    try:
        code, body = s.call("m1", to="+13135550222")
        assert code == 200 and "isn't available at this location" in body["say"], body
        assert [b["to"] for u, b in s.fake.transfers] == ["+12485547999"]
        assert "call.refused_no_checkout" in kinds(s)
        assert not s.fake.sms and not s.fake.square
        # ...while the Square location on the same server is unaffected
        assert "Pink Garlic" in s.call("m2")[1]["say"]
    finally:
        s.close()


def t_square_payment_webhook_records_payment_but_never_sends_a_second_ticket():
    import base64
    import hashlib
    import hmac
    s = Stack()
    try:
        order(s, "w1")
        assert CHECKOUT_OK in s.finish("w1")[1]["say"]
        pos_ref = s.store.conn.execute(
            "SELECT pos_payment_ref AS r FROM payment").fetchone()["r"]
        texts_before = len(s.fake.sms)

        def post(event_id, amount):
            raw = json.dumps({"event_id": event_id, "type": "payment.updated",
                              "data": {"object": {"payment": {
                                  "id": "PAY1", "order_id": pos_ref,
                                  "status": "COMPLETED",
                                  "amount_money": {"amount": amount, "currency": "USD"}}}}}).encode()
            url = "https://cherry.example/v1/webhooks/square/payment"
            sig = base64.b64encode(hmac.new(b"sigkey-0123456789", url.encode() + raw,
                                            hashlib.sha256).digest()).decode()
            req = urllib.request.Request(
                f"http://127.0.0.1:{s.sport}/v1/webhooks/square/payment", data=raw,
                method="POST", headers={"X-Square-HmacSha256-Signature": sig,
                                        "Content-Type": "application/json"})
            try:
                with REAL_URLOPEN(req, timeout=10) as r:
                    return r.status, json.loads(r.read())
            except urllib.error.HTTPError as exc:
                return exc.code, json.loads(exc.read())

        code, body = post("evt-wrong", 1)                    # wrong amount
        assert "payment.amount_mismatch" in kinds(s), (code, body)
        code, body = post("evt-1", 423)                      # the real payment
        assert code == 200, body
        assert s.store.conn.execute("SELECT status FROM payment").fetchone()["status"] == "paid"
        assert post("evt-1", 423)[1].get("action") == "duplicate"
        assert len(s.fake.sms) == texts_before, "handoff-only must not release a second ticket"
        assert not s.fake.transfers
        # a forged signature is rejected
        req = urllib.request.Request(
            f"http://127.0.0.1:{s.sport}/v1/webhooks/square/payment", data=b"{}",
            method="POST", headers={"X-Square-HmacSha256-Signature": "forged"})
        try:
            REAL_URLOPEN(req, timeout=10)
            raise AssertionError("accepted a forged webhook")
        except urllib.error.HTTPError as exc:
            assert exc.code == 401
    finally:
        s.close()


def t_bad_requests_are_refused():
    s = Stack()
    try:
        assert s.call("g1", to="+19995550000")[0] == 400
        assert s.gw("POST", "/v1/voice/calls",
                    {"call_control_id": "g2", "to": "+12485550111"}, key="bad")[0] == 401
        assert s.gw("GET", "/v1/voice/tools", key="")[0] == 401
        # the outcome endpoint is authenticated and validated
        req = urllib.request.Request(
            f"http://127.0.0.1:{s.sport}/v1/calls/x/handoff-outcome", method="POST",
            data=b'{"status":"weird"}',
            headers={"X-Cherry-Key": "apikey", "Content-Type": "application/json"})
        try:
            REAL_URLOPEN(req, timeout=10)
            raise AssertionError("accepted a bad status")
        except urllib.error.HTTPError as exc:
            assert exc.code == 400
    finally:
        s.close()


def t_a_burst_of_simultaneous_calls_all_complete():
    """25 simultaneous callers used to see a connection reset (listen backlog 5)."""
    s = Stack()
    try:
        results, errors = {}, []

        def one(n):
            cid = f"j{n}"
            try:
                order(s, cid, frm=f"+1313555{n:04d}")
                results[cid] = s.finish(cid)
            except Exception as exc:                          # noqa: BLE001
                errors.append(repr(exc))

        threads = [threading.Thread(target=one, args=(n,)) for n in range(40)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(120)
        assert not errors, errors[:3]
        assert sum(1 for c, b in results.values() if c == 200 and CHECKOUT_OK in b["say"]) == 40
        assert len({m["to"] for m in s.fake.sms}) == 40
        n = s.store.conn.execute('SELECT count(*) AS n FROM "order"').fetchone()["n"]
        assert int(n) == 40
        assert get(s, "/health")[1]["live_calls"] == 0, "finished calls must be released"
    finally:
        s.close()


def t_gateway_memory_is_bounded():
    from voice.inworld_bridge import CherryBridge
    b = CherryBridge("http://x", "k")
    for n in range(6000):
        b.spoken_log.append({"call_id": str(n), "tool": "t", "returned": "r"})
        b._remember(b._handed_off, str(n), True)
        b._remember(b._finished, str(n), "s")
    assert len(b.spoken_log) <= 2000
    assert len(b._handed_off) <= 5000 and len(b._finished) <= 5000


TESTS = [v for k, v in sorted(globals().items()) if k.startswith("t_")]


def main() -> int:
    passed, fails = 0, []
    for fn in TESTS:
        try:
            fn()
            passed += 1
        except Exception:                                    # noqa: BLE001
            fails.append((fn.__name__, traceback.format_exc()))
    print(f"{passed} passed, {len(fails)} failed (end-to-end rehearsal)")
    for name, tb in fails:
        print(f"\n--- FAIL {name}\n{tb}")
    return 1 if fails else 0


if __name__ == "__main__":
    raise SystemExit(main())
