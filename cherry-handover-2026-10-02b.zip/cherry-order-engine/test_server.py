#!/usr/bin/env python3
"""
Tests for the HTTP service — driven over a real socket.

These start an actual server on a real port and talk to it with real HTTP,
because the things that break in an integration are the things a direct
function call skips: routing, auth, JSON encoding, status codes, and what
happens when the voice layer sends something unexpected.
"""

from __future__ import annotations

import base64
import json
import threading
import time
import traceback
import urllib.error
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

import menu_schema as ms
import payments
import server as srv
from order_store import OrderStore
from sinks import FakeSmsSender

MENUS = Path(__file__).parent / "menus"
KEY = "test-secret"

_passed, _failed = 0, 0


def check(name: str, cond: bool, detail: str = "") -> None:
    global _passed, _failed
    if cond:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


class Harness:
    """A live server on a real port, torn down afterwards."""

    def __init__(self, sink="manual", telnyx_public_key="", **app_options):
        self.store = OrderStore.sqlite()
        for stem, inbound in (("bun-n-run-ferndale", "+13135551000"),
                              ("bun-n-run-clinton", "+15865551000"),
                              ("pink-garlic-shelby", "+12485551000")):
            cfg = ms.load_yaml(MENUS / f"{stem}.yaml")
            self.store.upsert_restaurant(
                cfg.id, cfg.name, cfg.cuisine, tax_rate_bps=cfg.tax_rate_bps,
                sink=sink, staff_phone="+13135550900", inbound_phone=inbound,
                active=True)
            self.store.publish_menu(cfg.id, (MENUS / f"{stem}.yaml").read_text(),
                                    item_count=len(cfg.items))
        self.store.upsert_restaurant("closed-one", "Closed", "burger",
                                     inbound_phone="+19995551000", active=False)
        self.sms = FakeSmsSender()
        self.app = srv.Cherry(self.store, sms=self.sms, api_key=KEY,
                              telnyx_public_key=telnyx_public_key,
                              **app_options)
        self.httpd = srv.build_server(self.app, 0)
        self.port = self.httpd.server_address[1]
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()

    def stop(self):
        self.httpd.shutdown()

    def req(self, method: str, path: str, body: Optional[Dict] = None,
            key: Optional[str] = KEY, headers: Optional[Dict[str, str]] = None,
            raw: Optional[bytes] = None) -> Tuple[int, Any]:
        data = raw if raw is not None else (
            json.dumps(body).encode() if body is not None else None)
        r = urllib.request.Request(f"http://127.0.0.1:{self.port}{path}",
                                   data=data, method=method)
        if data:
            r.add_header("Content-Type", "application/json")
        if key is not None:
            r.add_header("X-Cherry-Key", key)
        for name, value in (headers or {}).items():
            r.add_header(name, value)
        try:
            with urllib.request.urlopen(r, timeout=10) as resp:
                raw = resp.read()
                ctype = resp.headers.get("Content-Type", "")
                payload = (json.loads(raw) if "json" in ctype
                           else raw.decode("utf-8", "replace"))
                return resp.status, payload
        except urllib.error.HTTPError as exc:
            raw = exc.read()
            try:
                return exc.code, json.loads(raw)
            except ValueError:
                return exc.code, raw.decode("utf-8", "replace")

    def post(self, path, body=None, key=KEY):
        return self.req("POST", path, body or {}, key)

    def get(self, path, key=KEY):
        return self.req("GET", path, None, key)

    def tool(self, call_id, name, **args):
        return self.post(f"/v1/calls/{call_id}/tools/{name}", args)


def t_checkout_handoff_ends_at_customer_link() -> None:
    h = Harness(pay_provider=payments.FakePayLinkProvider(),
                checkout_handoff_only=True)
    try:
        h.post("/v1/calls", {"call_id": "handoff-one",
                             "to": "+13135551000", "from": "+13135550123"})
        h.tool("handoff-one", "add_item", text="double cheeseburger combo")
        h.tool("handoff-one", "confirm_mods")
        h.tool("handoff-one", "answer", text="Coke")
        h.tool("handoff-one", "set_name", text="Sam")
        h.tool("handoff-one", "note_allergy", text="no")
        status, result = h.post("/v1/calls/handoff-one/finish",
                                {"customer_name": "Sam"})
        check("handoff checkout returns successfully", status == 200)
        check("handoff is marked complete after link SMS",
              result.get("checkout_handed_off") is True, str(result))
        check("handoff does not wait for payment",
              result.get("awaiting_payment") is False, str(result))
        check("customer is directed to finish at checkout",
              "complete your transaction" in result.get("say", ""), str(result))
        check("checkout link is actually texted", len(h.sms.sent) == 1)
        check("no separate kitchen ticket is sent",
              h.store.conn.execute("SELECT 1 FROM order_delivery").fetchone() is None)
    finally:
        h.stop()


def t_health_needs_no_key() -> None:
    h = Harness()
    try:
        code, body = h.get("/health", key=None)
        check("health is open", code == 200, str(code))
        check("it reports live calls", "live_calls" in body, str(body))
        check("health proves the database is usable",
              body.get("database") == "ok", str(body))
        check("health reports deployed route and menu counts",
              all(k in body for k in ("active_restaurants", "routed_restaurants",
                                      "live_menus")), str(body))
        check("health reports shared-key webhook authentication",
              body.get("telnyx_webhook_auth") == "shared_key", str(body))
    finally:
        h.stop()


def t_every_other_endpoint_needs_the_key() -> None:
    h = Harness()
    try:
        for method, path in (("POST", "/v1/calls"),
                             ("POST", "/v1/calls/x/tools/add_item"),
                             ("POST", "/v1/calls/x/finish"),
                             ("GET", "/v1/tools"),
                             ("GET", "/v1/ops/snapshot")):
            code, _ = h.req(method, path, {} if method == "POST" else None,
                            key=None)
            check(f"{method} {path} rejects a missing key", code == 401, str(code))
            code, _ = h.req(method, path, {} if method == "POST" else None,
                            key="wrong")
            check(f"{method} {path} rejects a wrong key", code == 401, str(code))
    finally:
        h.stop()


def t_operations_snapshot_is_private_and_contains_no_customer_identity() -> None:
    h = Harness()
    try:
        h.post("/v1/calls", {"call_id": "private-call",
                             "to": "+13135551000",
                             "from": "+13135550999"})
        code, body = h.get("/v1/ops/snapshot?hours=48")
        check("operations snapshot is available to authenticated operators",
              code == 200, str(code))
        check("operations snapshot contains its reviewed window",
              body.get("window_hours") == 48, str(body))
        serialized = json.dumps(body)
        check("operations snapshot excludes caller phone",
              "+13135550999" not in serialized)
        check("operations snapshot excludes external call id",
              "private-call" not in serialized)
    finally:
        h.stop()


def t_operator_page_controls_and_voice_usage_are_served() -> None:
    h = Harness()
    try:
        code, page = h.get("/ops", key=None)
        check("operator shell is available without embedding private data",
              code == 200 and "Cherry Operations" in page, str(code))
        check("operator shell contains no API credential", KEY not in page)

        code, controls = h.post(
            "/v1/restaurants/bun-n-run-ferndale/controls",
            {"prep_minutes": 25, "wait_minutes": 7, "ai_enabled": True,
             "languages": ["en", "es"], "holiday_closures": ["2026-12-25"]})
        check("operator can update location controls", code == 200, str(controls))
        check("location controls round trip exactly",
              controls["prep_minutes"] == 25 and controls["wait_minutes"] == 7
              and controls["languages"] == ["en", "es"], str(controls))
        code, read_back = h.get("/v1/restaurants/bun-n-run-ferndale/controls")
        check("location controls can be read", code == 200 and read_back == controls,
              str(read_back))

        h.post("/v1/calls", {"call_id": "usage-call", "to": "+13135551000"})
        code, body = h.post("/v1/calls/usage-call/usage",
                            {"provider": "inworld",
                             "processedCharactersCount": 321,
                             "transcribedAudioMs": 4567})
        check("voice usage endpoint accepts provider totals",
              code == 200 and body.get("ok") is True, str(body))
        row = h.store.conn.execute(
            "SELECT v.* FROM voice_usage v JOIN session s ON s.id=v.session_id "
            "WHERE s.external_id=?", ("usage-call",)).fetchone()
        check("voice usage totals are persisted for reconciliation",
              row is not None and row["processed_characters"] == 321
              and row["transcribed_audio_ms"] == 4567, str(dict(row) if row else None))
    finally:
        h.stop()


def t_the_dialled_number_picks_the_restaurant() -> None:
    h = Harness()
    try:
        code, body = h.post("/v1/calls", {"call_id": "c1",
                                          "to": "+12485551000",
                                          "from": "+13135550123"})
        check("call starts", code == 200, str(body))
        check("it routed by the dialled number",
              body["restaurant_id"] == "pink-garlic-shelby", str(body))
        check("Lily greets with the restaurant's name",
              "Pink Garlic" in body["say"], body["say"])
        check("a session id comes back", bool(body["session_id"]))

        code, body = h.post("/v1/calls", {"call_id": "c-clinton",
                                          "to": "+15865551000",
                                          "from": "+13135550123"})
        check("Clinton call starts", code == 200, str(body))
        check("Clinton has its own phone route",
              body["restaurant_id"] == "bun-n-run-clinton", str(body))
        check("Clinton greeting names the right location",
              "Clinton Township" in body["say"], body["say"])

        code, body = h.post("/v1/calls", {"call_id": "c2", "to": "+15550000000"})
        check("an unknown number is a clean 404", code == 404, str(body))
        code, body = h.post("/v1/calls", {"call_id": "c3", "to": "+19995551000"})
        check("an inactive restaurant does not answer", code == 404, str(body))
    finally:
        h.stop()


def t_a_replayed_call_webhook_resumes_rather_than_restarting() -> None:
    h = Harness()
    try:
        _, a = h.post("/v1/calls", {"call_id": "dup", "to": "+13135551000"})
        h.tool("dup", "add_item", text="a double cheeseburger")
        _, b = h.post("/v1/calls", {"call_id": "dup", "to": "+13135551000"})
        check("the second start resumes", b.get("resumed") is True, str(b)[:200])
        check("it keeps the same session", b["session_id"] == a["session_id"])
        check("and the cart survives", b["order"]["lines"], str(b["order"]))
        sessions = h.store.conn.execute(
            "SELECT COUNT(*) c FROM session").fetchone()["c"]
        check("no second session was opened", sessions == 1, str(sessions))
    finally:
        h.stop()


def t_a_whole_call_over_http() -> None:
    provider = payments.FakePayLinkProvider()
    h = Harness(pay_provider=provider)
    try:
        _, g = h.post("/v1/calls", {"call_id": "call-1", "to": "+13135551000",
                                    "from": "+13135550123"})
        # "Good morning, … X. This is Lily." by day, "… X, this is Lily." in the small hours: the
        # greeting follows the restaurant's clock, so the check must not depend on when it runs.
        check("greeting is spoken, warmly, by name", "this is lily" in g["say"].lower()
              and "What can I get started" in g["say"], g["say"])

        _, r = h.tool("call-1", "add_item", text="gimme a double cheeseburger combo")
        check("item added", r["ok"] is True, r["say"])
        check("Lily confirms by name", "Double Cheeseburger Combo" in r["say"], r["say"])
        check("combo stays open until its drink is selected",
              r["order"]["submittable"] is False, str(r["order"]))

        _, r = h.tool("call-1", "add_modifier", text="Coke")
        check("included combo drink is accepted", r["ok"] is True, r["say"])

        _, r = h.tool("call-1", "remove_modifier", text="no onion")
        check("removal accepted", r["ok"] is True, r["say"])

        _, r = h.tool("call-1", "confirm_mods")
        check("modifications are explicitly closed", r["ok"] is True, r["say"])

        _, r = h.tool("call-1", "read_back")
        check("read-back has a total", "$" in r["say"], r["say"])
        check("and is submittable", r["order"]["submittable"] is True)
        check("current combo price and tax are exact",
              r["order"]["subtotal_cents"] == 1399 and
              r["order"]["tax_cents"] == 84 and
              r["order"]["total_cents"] == 1483, str(r["order"]))

        h.tool("call-1", "set_name", text="Sam")

        h.tool("call-1", "note_allergy", text="no")
        code, f = h.post("/v1/calls/call-1/finish", {"customer_name": "Sam"})
        check("finish succeeds", code == 200 and f["placed"] is True, str(f))
        check("it returns a spoken order code", bool(f["short_code"]))
        check("it is held until payment", f["delivered"] is False)
        check("itemized checkout link was texted", f["payment"] == "link_sent"
              and len(provider.requests) == 1 and len(h.sms.sent) == 1)
        check("the review checkout has the actual removed onion",
              "onion" in str(provider.requests[0]["snapshot"]["lines"]).lower())
        check("no kitchen ticket before payment",
              h.store.conn.execute("SELECT count(*) AS n FROM order_delivery "
                  "WHERE order_id=?", (f["order_id"],)).fetchone()["n"] == 0)
        payments.mark_paid(h.store, f["order_id"], provider.created[0].pos_ref)
        check("payment releases the immutable order",
              h.app.release_paid_order(f["order_id"])["released"] is True)
        check("the removal shouts on the post-payment kitchen ticket",
              any("NO ONION" in m["body"] for m in h.sms.sent))

        check("the call is no longer live", len(h.app.live) == 0)
        row = h.store.order(f["order_id"])
        check("the order is stored", row is not None)
        turns = h.store.conn.execute(
            "SELECT COUNT(*) c FROM turn WHERE session_id=?",
            (row["session_id"],)).fetchone()["c"]
        check("every turn was logged", turns >= 8, str(turns))
        lat = h.store.conn.execute(
            "SELECT COUNT(*) c FROM turn WHERE latency_ms IS NOT NULL"
        ).fetchone()["c"]
        check("agent turns carry latency for the dashboard", lat >= 4, str(lat))
    finally:
        h.stop()


def t_finish_refuses_an_incomplete_order() -> None:
    """The most important guard: never hang up on a half-specified order."""
    h = Harness()
    try:
        h.post("/v1/calls", {"call_id": "inc", "to": "+12485551000"})
        _, r = h.tool("inc", "add_item", text="chicken tikka masala")
        check("spice level is still open", r["order"]["submittable"] is False)

        code, f = h.post("/v1/calls/inc/finish")
        check("finish returns 200, not an error", code == 200, str(code))
        check("but it did not place", f["placed"] is False, str(f))
        check("it says what to ask", bool(f["say"]), str(f))
        check("and tells the voice layer what is missing",
              f.get("needs") is not None or f.get("error"), str(f)[:200])
        check("the call is still live so it can be finished",
              len(h.app.live) == 1)
        orders = h.store.conn.execute(
            'SELECT COUNT(*) c FROM "order"').fetchone()["c"]
        check("nothing reached the kitchen", orders == 0, str(orders))

        h.tool("inc", "answer", text="medium")
        code, f = h.post("/v1/calls/inc/finish")
        check("a complete order is asked about allergies before it is placed",
              f["placed"] is False and f["error"] == "allergy_check", str(f))
        h.tool("inc", "set_name", text="Sam")
        h.tool("inc", "note_allergy", text="no")
        code, f = h.post("/v1/calls/inc/finish")
        check("after answering, it places", f["placed"] is True, str(f))
    finally:
        h.stop()


def t_abandoning_a_part_built_order_escalates() -> None:
    h = Harness()
    try:
        h.post("/v1/calls", {"call_id": "ab", "to": "+13135551000"})
        h.tool("ab", "add_item", text="double cheeseburger")
        code, b = h.post("/v1/calls/ab/abandon", {"reason": "caller hung up"})
        check("abandon succeeds", code == 200 and b["ok"], str(b))
        check("it noticed there were items", b["had_items"] is True)
        esc = h.store.conn.execute(
            "SELECT COUNT(*) c FROM session WHERE escalated_at IS NOT NULL"
        ).fetchone()["c"]
        check("a half-built order is escalated, not silently dropped",
              esc == 1, str(esc))

        h.post("/v1/calls", {"call_id": "ab2", "to": "+13135551000"})
        _, b = h.post("/v1/calls/ab2/abandon")
        check("an empty call is not escalated", b["had_items"] is False)
    finally:
        h.stop()


def t_unknown_tools_and_bad_arguments_never_cause_dead_air() -> None:
    h = Harness()
    try:
        h.post("/v1/calls", {"call_id": "bad", "to": "+13135551000"})
        code, b = h.post("/v1/calls/bad/tools/drop_database", {})
        check("an unknown tool is a 400", code == 400, str(code))
        check("and it lists the real ones", "add_item" in str(b), str(b)[:200])

        code, b = h.post("/v1/calls/bad/tools/add_item", {"nonsense": 1})
        check("missing required args still return an envelope", code == 200,
              str(code))
        check("the envelope refuses the action", b["ok"] is False, str(b))
        check("the envelope is speakable", bool(b["say"].strip()), str(b))
        check("the error is machine-readable", b["error"] == "bad_arguments",
              str(b))

        code, b = h.post("/v1/calls/bad/tools/search_menu",
                         {"nonsense": 1})
        check("harmless extra args are dropped", code == 200 and b["ok"],
              str(b))

        code, b = h.post("/v1/calls/nope/tools/add_item", {"text": "x"})
        check("an unknown call id is a 404", code == 404, str(code))
    finally:
        h.stop()


def t_misrouted_caller_text_is_not_discarded_or_executed() -> None:
    h = Harness()
    try:
        h.post("/v1/calls", {"call_id": "mis", "to": "+12485551000"})
        _, added = h.tool("mis", "add_item", text="lamb saag")
        before = added["order"]
        question = added["needs"]["question"]

        # read_back takes no text.  This models the same dangerous integration
        # mistake as sending "no onions" to a no-text confirmation tool.
        code, body = h.post("/v1/calls/mis/tools/read_back",
                            {"text": "medium please"})
        check("misrouted text returns HTTP 200", code == 200, str(code))
        check("the action is refused", body["ok"] is False, str(body))
        check("the error says misrouted", body["error"] == "misrouted",
              str(body))
        check("the open question is asked again", body["say"] == question,
              body["say"])
        check("the cart is unchanged", body["order"] == before, str(body))

        _, answered = h.tool("mis", "answer", text="medium")
        check("the original question can still be answered", answered["ok"],
              str(answered))
    finally:
        h.stop()


def t_confirm_mods_with_stray_text_reasks_without_mutating() -> None:
    h = Harness()
    try:
        h.post("/v1/calls", {"call_id": "mods", "to": "+13135551000"})
        _, added = h.tool("mods", "add_item",
                          text="double cheeseburger combo")
        before = added["order"]
        question = added["needs"]["question"]

        code, body = h.post("/v1/calls/mods/tools/confirm_mods",
                            {"text": "no onions please"})
        check("stray confirm text returns HTTP 200", code == 200, str(code))
        check("stray confirm text is refused", body["ok"] is False, str(body))
        check("stray confirm is identified as misrouted",
              body["error"] == "misrouted", str(body))
        check("the real pending question is repeated",
              body["say"] == question, body["say"])
        check("misrouting cannot change the cart", body["order"] == before,
              str(body["order"]))
    finally:
        h.stop()


def t_the_cart_is_persisted_after_every_turn() -> None:
    """A crash mid-call must not lose the order."""
    h = Harness()
    try:
        _, g = h.post("/v1/calls", {"call_id": "p1", "to": "+13135551000"})
        h.tool("p1", "add_item", text="double cheeseburger")
        saved = h.store.load_cart(g["session_id"])
        check("the cart is in the database mid-call", saved is not None)
        check("with the right item",
              saved["lines"][0]["item_id"] == "double_cheeseburger", str(saved)[:200])
    finally:
        h.stop()


def t_the_ticket_page_opens_and_accepts() -> None:
    provider = payments.FakePayLinkProvider()
    h = Harness(pay_provider=provider)
    try:
        h.post("/v1/calls", {"call_id": "t1", "to": "+13135551000",
                             "from": "+13135550123"})
        h.tool("t1", "add_item", text="double cheeseburger")
        h.tool("t1", "confirm_mods")
        h.tool("t1", "set_name", text="Sam")
        h.tool("t1", "note_allergy", text="no")
        _, f = h.post("/v1/calls/t1/finish")
        code = f["short_code"]

        status, _ = h.get(f"/t/{code}", key=None)
        check("unpaid ticket cannot be opened", status == 404)
        status, _ = h.post(f"/t/{code}/accept", {}, key=None)
        check("unpaid ticket cannot be accepted", status == 409)
        payments.mark_paid(h.store, f["order_id"], provider.created[0].pos_ref)
        h.app.release_paid_order(f["order_id"])

        status, html = h.get(f"/t/{code}", key=None)
        check("the ticket page opens without a key", status == 200, str(status))
        check("it shows the order", f"#{code}" in html, html[:200])
        check("it shows it is unconfirmed", "Not yet confirmed" in html)
        check("and offers the button", "Got it" in html)

        status, body = h.post(f"/t/{code}/accept", {}, key=None)
        check("accepting works from the phone", status == 200, str(body))
        check("it was not already accepted", body["already"] is False)
        check("the order is acknowledged",
              h.store.order(f["order_id"])["status"] == "acknowledged")

        status, html = h.get(f"/t/{code}", key=None)
        check("the page now reads confirmed", "Confirmed" in html)
        check("and the button is gone", "Got it" not in html)

        status, _ = h.get("/t/0000", key=None)
        check("an unknown code is a clean 404", status == 404, str(status))
    finally:
        h.stop()


def t_unpaid_checkout_can_be_revoked_for_a_corrected_order() -> None:
    provider = payments.FakePayLinkProvider()
    h = Harness(pay_provider=provider)
    try:
        h.post("/v1/calls", {"call_id": "correction", "to": "+13135551000",
                             "from": "+13135550123"})
        h.tool("correction", "add_item", text="double cheeseburger")
        h.tool("correction", "confirm_mods")
        h.tool("correction", "set_name", text="Sam")
        h.tool("correction", "note_allergy", text="no")
        _, finished = h.post("/v1/calls/correction/finish")
        oid = finished["order_id"]
        status, result = h.post(f"/v1/orders/{oid}/cancel-checkout")
        check("staff can revoke unpaid checkout", status == 200 and
              result["replacement_required"], str(result))
        check("hosted checkout was revoked", len(provider.revoked) == 1)
        check("original order remains for evidence and is cancelled",
              h.store.order(oid)["status"] == "cancelled")
        status, result = h.post(f"/v1/orders/{oid}/cancel-checkout")
        check("correction cannot be applied twice", status == 200 and
              result["cancelled"] is False)
    finally:
        h.stop()


def t_the_sms_webhook_is_reachable_and_suppresses() -> None:
    h = Harness()
    try:
        code, b = h.post("/v1/webhooks/telnyx/sms", {"data": {
            "event_type": "message.received",
            "payload": {"direction": "inbound",
                        "from": {"phone_number": "+13135550123"},
                        "text": "STOP"}}})
        check("the webhook accepts", code == 200, str(b))
        check("it suppressed the number", b["action"] == "suppressed", str(b))
        check("and the store agrees", h.store.is_suppressed("+13135550123"))

        code, b = h.post("/v1/webhooks/telnyx/sms", {"garbage": True})
        check("a malformed webhook still returns 200", code == 200, str(b))
    finally:
        h.stop()


def t_telnyx_signature_authenticates_exact_body_and_blocks_replay() -> None:
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

    private = Ed25519PrivateKey.generate()
    public = base64.b64encode(private.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw)).decode()
    h = Harness(telnyx_public_key=public)
    try:
        body = {"data": {"id": "evt-stop-once",
                         "event_type": "message.received",
                         "payload": {"direction": "inbound",
                                     "from": {"phone_number": "+13135550124"},
                                     "text": "STOP"}}}
        # Deliberate compact encoding proves verification uses the wire bytes,
        # not a parsed/re-encoded version of the JSON.
        raw = json.dumps(body, separators=(",", ":")).encode()
        timestamp = str(int(time.time()))
        signature = base64.b64encode(private.sign(
            timestamp.encode() + b"|" + raw)).decode()
        headers = {"telnyx-timestamp": timestamp,
                   "telnyx-signature-ed25519": signature}

        code, result = h.req("POST", "/v1/webhooks/telnyx/sms", key=None,
                             headers=headers, raw=raw)
        check("a genuine Telnyx signature needs no Cherry key", code == 200,
              str(result))
        check("the genuine event runs", result["action"] == "suppressed",
              str(result))

        code, result = h.req("POST", "/v1/webhooks/telnyx/sms", key=None,
                             headers=headers, raw=raw)
        check("a retried event is acknowledged", code == 200, str(result))
        check("and is not applied twice", result["action"] == "duplicate",
              str(result))
        check("only one opt-out audit event exists",
              len(h.store.events(kind="sms.suppressed")) == 1)

        altered = raw.replace(b"STOP", b"START")
        code, result = h.req("POST", "/v1/webhooks/telnyx/sms", key=None,
                             headers=headers, raw=altered)
        check("a changed body fails the signature", code == 401, str(result))
        check("the failed forgery did not opt the number back in",
              h.store.is_suppressed("+13135550124"))
    finally:
        h.stop()


def t_telnyx_signature_rejects_stale_requests() -> None:
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

    private = Ed25519PrivateKey.generate()
    public = base64.b64encode(private.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw)).decode()
    h = Harness(telnyx_public_key=public)
    try:
        raw = b'{"data":{"id":"old-event"}}'
        timestamp = str(int(time.time()) - 301)
        signature = base64.b64encode(private.sign(
            timestamp.encode() + b"|" + raw)).decode()
        code, result = h.req(
            "POST", "/v1/webhooks/telnyx/sms", key=None, raw=raw,
            headers={"telnyx-timestamp": timestamp,
                     "telnyx-signature-ed25519": signature})
        check("a stale signed webhook is rejected", code == 401, str(result))
    finally:
        h.stop()


def t_tools_endpoint_serves_the_contract() -> None:
    h = Harness()
    try:
        code, b = h.get("/v1/tools")
        check("the tool schemas are servable", code == 200, str(code))
        names = {t["name"] for t in b["tools"]}
        check("every published tool is there", names == set(srv.TOOL_NAMES), str(sorted(names)))
        check("add_item is among them", "add_item" in names)
        check("reservation request and cancellation are included",
              {"request_reservation", "cancel_reservation"} <= names)
    finally:
        h.stop()


def t_phone_reservation_is_a_request_until_staff_confirms() -> None:
    h = Harness()
    try:
        code, policy = h.post(
            "/v1/restaurants/bun-n-run-ferndale/reservation-policy",
            {"enabled": True, "max_party_size": 8,
             "min_notice_minutes": 30, "max_advance_days": 30})
        check("reservation policy can be enabled", code == 200 and policy["enabled"])
        h.post("/v1/calls", {"call_id": "reserve-1", "to": "+13135551000",
                             "from": "+13135550123"})
        when = (datetime.now(timezone.utc) + timedelta(days=2)).isoformat()
        code, result = h.tool(
            "reserve-1", "request_reservation", guest_name="Sam",
            party_size=4, reserved_at=when, notes="quiet table")
        ref = result.get("reservation", {}).get("confirmation_code", "")
        check("voice tool records a request", code == 200 and result.get("ok") is True,
              str(result))
        check("voice tool never promises a confirmed table",
              result.get("reservation", {}).get("status") == "requested"
              and "not confirmed" in result.get("say", "").lower(), str(result))
        check("reservation has an eight-character reference", len(ref) == 8, ref)
        check("staff and guest both receive the request", len(h.sms.sent) == 2,
              str(h.sms.sent))
        _, replay = h.tool(
            "reserve-1", "request_reservation", guest_name="Sam",
            party_size=4, reserved_at=when, notes="quiet table")
        count = h.store.conn.execute(
            "SELECT count(*) AS n FROM reservation").fetchone()["n"]
        check("a retried voice tool cannot duplicate the reservation",
              replay.get("idempotent_replay") is True and count == 1
              and len(h.sms.sent) == 2, str(replay))
        code, updated = h.post(
            f"/v1/restaurants/bun-n-run-ferndale/reservations/{ref}",
            {"status": "confirmed"})
        check("restaurant can confirm the request", code == 200
              and updated.get("status") == "confirmed", str(updated))
        row = h.store.conn.execute(
            "SELECT status FROM reservation r JOIN reservation_reference x "
            "ON x.reservation_id=r.id WHERE x.confirmation_code=?", (ref,)).fetchone()
        check("confirmation is durable", row["status"] == "confirmed", str(dict(row)))
        check("guest receives the restaurant decision", len(h.sms.sent) == 3,
              str(h.sms.sent))
        _, replayed_update = h.post(
            f"/v1/restaurants/bun-n-run-ferndale/reservations/{ref}",
            {"status": "confirmed"})
        check("a retried confirmation does not text the guest twice",
              replayed_update.get("idempotent_replay") is True
              and len(h.sms.sent) == 3, str(replayed_update))
    finally:
        h.stop()


def t_two_calls_at_once_do_not_mix() -> None:
    """Two restaurants, two callers, one process."""
    h = Harness()
    try:
        h.post("/v1/calls", {"call_id": "A", "to": "+13135551000"})
        h.post("/v1/calls", {"call_id": "B", "to": "+12485551000"})
        h.tool("A", "add_item", text="double cheeseburger")
        h.tool("B", "add_item", text="chicken tikka masala")

        _, a = h.tool("A", "read_back")
        _, b = h.tool("B", "read_back")
        check("call A has only its own item",
              "Cheeseburger" in a["say"] and "Tikka" not in a["say"], a["say"])
        check("call B has only its own item",
              "Tikka" in b["say"] and "Cheeseburger" not in b["say"], b["say"])
        check("both are live", len(h.app.live) == 2)
    finally:
        h.stop()


def t_concurrent_turns_on_many_calls_stay_correct() -> None:
    """Ten simultaneous calls, each adding its own item. Twice the measured
    peak concurrency, and enough to shake out shared state."""
    h = Harness()
    try:
        results: Dict[str, Any] = {}
        errors = []

        def one(n: int):
            try:
                cid = f"load-{n}"
                h.post("/v1/calls", {"call_id": cid, "to": "+13135551000"})
                h.tool(cid, "add_item", text="double cheeseburger")
                _, r = h.tool(cid, "read_back")
                results[cid] = r["order"]["total_cents"]
            except Exception as exc:                  # noqa: BLE001
                errors.append(repr(exc))

        threads = [threading.Thread(target=one, args=(i,)) for i in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=30)

        check("no thread errored", not errors, str(errors[:2]))
        check("all ten calls completed", len(results) == 10, str(len(results)))
        totals = set(results.values())
        check("every call priced identically and independently",
              len(totals) == 1, str(totals))
    finally:
        h.stop()


def t_stale_calls_are_swept() -> None:
    h = Harness()
    try:
        _, g = h.post("/v1/calls", {"call_id": "old", "to": "+13135551000"})
        h.app.live["old"].started_at -= 7200
        h.post("/v1/calls", {"call_id": "new", "to": "+13135551000"})
        n = h.app.sweep()
        check("the stale call was swept", n == 1, str(n))
        check("the fresh one survived", "new" in h.app.live and "old" not in h.app.live)
        check("and the session was closed",
              h.store.conn.execute("SELECT ended_at FROM session WHERE id=?",
                                   (g["session_id"],)).fetchone()["ended_at"])
    finally:
        h.stop()


def main() -> int:
    for name, fn in sorted(globals().items()):
        if not name.startswith("t_"):
            continue
        try:
            fn()
        except Exception:                              # noqa: BLE001
            global _failed
            _failed += 1
            print(f"\n--- FAIL {name}")
            traceback.print_exc()
    print(f"\n{_passed} passed, {_failed} failed (HTTP service, over a socket)")
    return 1 if _failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
