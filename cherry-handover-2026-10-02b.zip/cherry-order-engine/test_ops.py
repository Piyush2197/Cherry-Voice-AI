#!/usr/bin/env python3
"""
Tests for the deployed path — the one a real call takes.

test_store.py tests the store, the sinks and the payment relay in isolation.
This tests them WIRED TOGETHER through the CLI, because that is where the
wiring bugs live: the harness routing an utterance to the wrong handler, a
config field renamed, an 86 that loads but never reaches the matcher. Every
one of those passed unit tests and broke the call.
"""

from __future__ import annotations

import argparse
import io
import os
import sys
import tempfile
from contextlib import redirect_stdout
from pathlib import Path

import cherry
import cherry_ops
import menu_schema as ms

HERE = Path(__file__).parent
MENUS = HERE / "menus"
CALLS = HERE / "calls"

_passed, _failed = 0, 0


def check(name: str, cond: bool, detail: str = "") -> None:
    global _passed, _failed
    if cond:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


def ns(**kw) -> argparse.Namespace:
    base = dict(db=None, verbose=False, script=None, inbound=None,
                restaurant=None, menu=None, sink="manual", staff_phone=None,
                inactive=False, from_number="+13135550101", customer=None,
                call_id=None, no_pos_pay=False, all=False, by="staff",
                kind="item", on=False, reason=None, target=None, code=None,
                pilots=False)
    base.update(kw)
    return argparse.Namespace(**base)


def run(fn, **kw):
    """Call an ops command, capture what the operator would have seen."""
    buf = io.StringIO()
    with redirect_stdout(buf):
        rc = fn(ns(**kw))
    return rc, buf.getvalue()


def script(tmp: Path, *lines: str) -> str:
    p = tmp / "call.txt"
    p.write_text("\n".join(lines) + "\n")
    return str(p)


def main() -> int:
    with tempfile.TemporaryDirectory() as td:
        tmp = Path(td)
        db = str(tmp / "t.db")
        # Exercise the separately supported pay-at-pickup branch here. Actual
        # seven-location paid-first menus are tested in test_payment_gate.py.
        legacy_menu = tmp / "bun-legacy.yaml"
        legacy_menu.write_text((MENUS / "bun-n-run-ferndale.yaml").read_text()
            .replace("pay_now_threshold_cents: 0",
                     "pay_now_threshold_cents: 3000"))

        # -- deploy -------------------------------------------------------
        rc, out = run(cherry_ops.cmd_deploy, menu=str(legacy_menu),
                      db=db, staff_phone="+13135550900", inbound="+13135551000")
        check("deploy exits 0", rc == 0, out[-300:])
        check("deploy reports live", "live" in out)

        st = cherry_ops._store(ns(db=db))
        check("restaurant stored", st.restaurant("bun-n-run-ferndale") is not None)
        check("number routes to restaurant",
              st.restaurant_for_number("+13135551000")["id"] == "bun-n-run-ferndale")

        # Republishing the same YAML must not create a second version.
        v1 = st.live_menu("bun-n-run-ferndale")["id"]
        run(cherry_ops.cmd_deploy, menu=str(legacy_menu),
            db=db, staff_phone="+13135550900", inbound="+13135551000")
        st2 = cherry_ops._store(ns(db=db))
        check("identical redeploy reuses the version",
              st2.live_menu("bun-n-run-ferndale")["id"] == v1)

        # -- a call, dialled by number -----------------------------------
        rc, out = run(cherry_ops.cmd_call, inbound="+13135551000", db=db,
                      script=str(CALLS / "bun-n-run.txt"), call_id="call-1")
        check("call exits 0", rc == 0, out[-400:])
        check("order placed", "order #" in out, out[-400:])
        check("delivered via manual", "delivered" in out)
        check("staff ticket names the item", "Double Cheeseburger" in out)
        check("removal shouts on the ticket", "*** NO ONION ***" in out)
        check("standard toppings are not listed as additions",
              "+ Ketchup" not in out and "as usual:" in out)
        check("under threshold pays at pickup", "PAY AT PICKUP" in out)

        st = cherry_ops._store(ns(db=db))
        row = st.conn.execute('SELECT * FROM "order" LIMIT 1').fetchone()
        check("order total is 1483 cents", row["total_cents"] == 1483,
              str(row["total_cents"]))
        check("order is tied to its menu version",
              row["menu_version_id"] == v1)
        turns = st.conn.execute("SELECT COUNT(*) c FROM turn WHERE session_id=?",
                                (row["session_id"],)).fetchone()["c"]
        check("every turn was logged", turns >= 5, str(turns))
        check("session was closed",
              st.conn.execute("SELECT ended_at FROM session WHERE id=?",
                              (row["session_id"],)).fetchone()["ended_at"] is not None)

        # A replayed telephony webhook must not start a second session.
        rc, out = run(cherry_ops.cmd_call, inbound="+13135551000", db=db,
                      script=str(CALLS / "bun-n-run.txt"), call_id="call-1")
        st = cherry_ops._store(ns(db=db))
        sessions = st.conn.execute("SELECT COUNT(*) c FROM session").fetchone()["c"]
        check("replayed call_id reuses the session", sessions == 1, str(sessions))

        # -- unconfirmed orders are visible, then acknowledgeable ---------
        rc, out = run(cherry_ops.cmd_orders, restaurant="bun-n-run-ferndale", db=db)
        check("unconfirmed orders are flagged", "UNCONFIRMED" in out, out)
        code = row["short_code"]
        rc, out = run(cherry_ops.cmd_ack, code=code, db=db, by="tablet")
        check("ack exits 0", rc == 0)
        check("ack confirms", "confirmed" in out)
        rc, out = run(cherry_ops.cmd_ack, code=code, db=db, by="tablet")
        check("second ack is a no-op, not an error", rc == 0 and "already" in out)
        rc, out = run(cherry_ops.cmd_orders, restaurant="bun-n-run-ferndale", db=db)
        check("acknowledged order clears the alarm", "UNCONFIRMED" not in out, out)

        # -- trace --------------------------------------------------------
        rc, out = run(cherry_ops.cmd_trace, code=code, db=db)
        check("trace exits 0", rc == 0)
        check("trace shows the transcript", "cheeseburger" in out.lower())
        check("trace shows the ticket", "TOTAL" in out)
        check("trace shows delivery", "delivery manual" in out)
        check("trace shows the audit events", "order.placed" in out)
        rc, out = run(cherry_ops.cmd_trace, code="0000", db=db)
        check("trace of an unknown code fails cleanly", rc == 1)

        # -- 86 ------------------------------------------------------------
        rc, out = run(cherry_ops.cmd_86, restaurant="bun-n-run-ferndale",
                      target="french_fries", db=db, reason="fryer down")
        check("86 exits 0", rc == 0, out)
        st = cherry_ops._store(ns(db=db))
        cfg, _ = st.load_live_config("bun-n-run-ferndale")
        fries = cfg.item("french_fries")
        check("86ed item is loaded unavailable", fries is not None and not fries.available)

        rc, out = run(cherry_ops.cmd_call, restaurant="bun-n-run-ferndale", db=db,
                      script=script(tmp, "an order of french fries", "read"))
        check("an 86ed item never becomes an order", "nothing ordered" in out, out[-300:])
        check("Lily says she is out of it, at the moment she is asked",
              "out of the" in out, out[-400:])
        check("…and offers the closest thing instead of a dead end",
              "very close" in out, out[-400:])
        check("a caller who only asked for something sold out is not escalated to staff",
              "escalated" not in out.lower())
        st = cherry_ops._store(ns(db=db))
        esc = st.conn.execute("SELECT COUNT(*) c FROM session "
                              "WHERE escalated_at IS NOT NULL").fetchone()["c"]
        check("no escalation is recorded", esc == 0, str(esc))

        # Back on, and orderable again.
        run(cherry_ops.cmd_86, restaurant="bun-n-run-ferndale",
            target="french_fries", db=db, on=True)
        rc, out = run(cherry_ops.cmd_call, restaurant="bun-n-run-ferndale", db=db,
                      script=script(tmp, "an order of french fries", "read"))
        check("un-86ing makes it orderable again", rc == 0, out[-300:])

        # -- over the threshold, the POS pay link is what gets texted -----
        rc, out = run(cherry_ops.cmd_deploy, menu=str(MENUS / "pink-garlic-shelby.yaml"),
                      db=db, staff_phone="+12485550900", inbound="+12485551000")
        check("second restaurant deploys", rc == 0, out[-300:])
        big = script(tmp, "lamb saag", "medium plus", "boneless lamb", "x3")
        rc, out = run(cherry_ops.cmd_call, inbound="+12485551000", db=db, script=big)
        check("big order placed", rc == 0, out[-400:])
        check("over threshold sends a pay link", "pay link texted" in out, out[-400:])
        check("the link is the POS's own https link",
              "https://" in out and "kitchen held until verified payment" in out)
        st = cherry_ops._store(ns(db=db))
        pay = st.conn.execute("SELECT * FROM payment WHERE status='link_sent'").fetchone()
        check("payment is recorded as collected by the POS",
              pay["collected_by"] == "restaurant_pos")
        check("no payment instrument is stored anywhere in the row",
              not any(str(k).lower() in ("card", "pan", "cvv") for k in pay.keys()))

        # No itemized checkout cannot silently downgrade a pay-now order.
        rc, out = run(cherry_ops.cmd_call, inbound="+12485551000", db=db,
                      script=big, no_pos_pay=True)
        check("no pay-link provider still completes the order", rc == 0, out[-300:])
        check("it holds the kitchen order without a checkout provider",
              "held; restaurant has no ticket" in out and
              "kitchen held until verified payment" in out, out[-300:])

        # -- two restaurants stay separate --------------------------------
        st = cherry_ops._store(ns(db=db))
        bnr = st.conn.execute('SELECT COUNT(*) c FROM "order" WHERE restaurant_id=?',
                              ("bun-n-run-ferndale",)).fetchone()["c"]
        pg = st.conn.execute('SELECT COUNT(*) c FROM "order" WHERE restaurant_id=?',
                             ("pink-garlic-shelby",)).fetchone()["c"]
        check("orders are scoped per restaurant", bnr >= 2 and pg == 2,
              f"bnr={bnr} pg={pg}")

        # -- the gate still gates ------------------------------------------
        bad = tmp / "bad.yaml"
        # A dangling group reference: structurally invalid, and exactly the
        # mistake a human makes editing YAML by hand.
        bad.write_text((MENUS / "bun-n-run-ferndale.yaml").read_text()
                       .replace("id: bun-n-run-ferndale", "id: broken-one")
                       .replace("groups: [bnr_cheeseburger_toppings]",
                                "groups: [bnr_toppings_MISSING]", 1))
        rc, out = run(cherry_ops.cmd_deploy, menu=str(bad), db=db)
        check("a menu that fails the gate is never deployed", rc == 1, out[-300:])
        st = cherry_ops._store(ns(db=db))
        check("nothing was written for the rejected menu",
              st.restaurant("broken-one") is None)


        # -- readiness ------------------------------------------------------
        import readiness as rd
        cfg_b = ms.load_yaml(MENUS / "bun-n-run-ferndale.yaml")
        st = cherry_ops._store(ns(db=db))

        f = rd.assess(cfg_b, None)
        check("an undeployed restaurant is blocked",
              any(x.level == rd.BLOCKER and "not deployed" in x.what for x in f),
              str([str(x) for x in f]))

        row = st.restaurant("bun-n-run-ferndale")
        f = rd.assess(cfg_b, row, st)
        check("a deployed, phoned, staffed restaurant has no blockers",
              not [x for x in f if x.level == rd.BLOCKER],
              str([str(x) for x in f]))

        # Strip the staff phone: the ticket now has nowhere to go.
        st.upsert_restaurant("bun-n-run-ferndale", cfg_b.name, cfg_b.cuisine,
                             sink="manual", inbound_phone="+13135551000",
                             staff_phone=None, active=True)
        st2 = cherry_ops._store(ns(db=db))
        f = rd.assess(cfg_b, st2.restaurant("bun-n-run-ferndale"), st2)
        check("no staff phone is a blocker, owned by the owner",
              any(x.level == rd.BLOCKER and x.owner == "owner"
                  and "staff phone" in x.what for x in f),
              str([str(x) for x in f]))

        # No inbound number: nothing can route a call here at all.
        st2.upsert_restaurant("bun-n-run-ferndale", cfg_b.name, cfg_b.cuisine,
                              sink="manual", inbound_phone=None,
                              staff_phone="+13135550900", active=True)
        st3 = cherry_ops._store(ns(db=db))
        f = rd.assess(cfg_b, st3.restaurant("bun-n-run-ferndale"), st3)
        check("no inbound number is a blocker",
              any(x.level == rd.BLOCKER and "inbound" in x.what for x in f),
              str([str(x) for x in f]))

        # The gap that actually matters on this project: a cuisine missing
        # categories it certainly sells. Synthesised rather than taken from a
        # real menu, so that completing a real menu never breaks this test.
        cfg_pg = ms.load_yaml(MENUS / "pink-garlic-shelby.yaml")
        import dataclasses
        stripped = dataclasses.replace(
            cfg_pg, items=tuple(i for i in cfg_pg.items
                                if i.category not in ("vegetable", "seafood")))
        gaps = [x for x in rd.assess(stripped, None) if x.level == rd.GAP]
        check("an Indian menu with no vegetarian section is flagged",
              any("vegetable" in x.what for x in gaps),
              str([str(x) for x in gaps]))
        check("the gap is owned by the owner, not us",
              all(x.owner == "owner" for x in gaps if "categor" in x.what))

        # And the real, now-complete menu no longer reports that gap.
        real_gaps = [x for x in rd.assess(cfg_pg, None) if x.level == rd.GAP]
        check("the completed Pink Garlic menu has its vegetarian section",
              not any("vegetable" in x.what for x in real_gaps),
              str([str(x) for x in real_gaps]))

        cfg_jm = ms.load_yaml(MENUS / "juan-miguels-clinton.yaml")
        f = rd.assess(cfg_jm, None)
        check("a Mexican menu with no tacos is flagged",
              any("taco" in x.what for x in f if x.level == rd.GAP),
              str([str(x) for x in f]))

        # A missing category is a GAP, never a BLOCKER: an incomplete menu
        # still takes the orders it can.
        check("an incomplete menu is not blocked from taking calls",
              not any(x.level == rd.BLOCKER and "categor" in x.what
                      for x in rd.assess(cfg_pg, None)))

        rc, out = run(rd.cmd_readiness, restaurant="bun-n-run-ferndale",
                      db=db)
        check("the readiness command runs", rc == 0, out[-200:])
        check("and names the restaurant", "Bun N Run" in out, out[-200:])

    print(f"\n{_passed} passed, {_failed} failed (deployed path, end to end)")
    return 1 if _failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
