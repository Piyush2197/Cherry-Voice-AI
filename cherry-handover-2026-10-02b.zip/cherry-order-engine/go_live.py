#!/usr/bin/env python3
"""
Go-live preflight — can this deployment take a customer's call tonight?

Everything else in this repository answers a narrower question. `cherry.py check`
asks "is this menu valid?". `pilot_deploy.py plan` asks "is the manifest
deployable?". `cherry.py readiness` asks "what does the owner still owe us?".
None of them answers the question actually asked the night before a launch, and
the answer is spread across a database, fifteen environment variables, a
manifest, two provider accounts and a running process.

This asks it in one place, in the order the failures actually bite, and every
failing check prints the exact command or variable that fixes it.

    python3 go_live.py                          # everything, from the environment
    python3 go_live.py --db cherry.db           # include the deployed database
    python3 go_live.py --url https://cherry.example  # include the running server
    python3 go_live.py --only pink-garlic-oak-park

Exit code is 0 only when nothing BLOCKS. WAITING items are things a human must
do (buy a number, get an owner's signoff) and do not fail the run; they are
listed because a launch slips when they are invisible.

WHY IT IS STRICT ABOUT SOME THINGS
----------------------------------
Two checks refuse to be waved through, because both have already happened in
this repository:

  * a direct staff line equal to the published number. That number forwards
    into Cherry, so a transfer to it loops. `pilot_deploy.py apply` will write
    the published number if its env var is missing, and the gateway then refuses
    to start — so the deploy "succeeds" into a service that cannot boot.
  * `--dev-checkout` left on. It marks orders paid without money moving. The
    server reports it in `/health`, and this refuses to call a deployment live
    while it is set.
"""

from __future__ import annotations

import _ensure_deps  # noqa: F401  (re-runs under .venv, or says how to install, if PyYAML is missing)
import argparse
import json
import os
import re
import sys
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

ROOT = Path(__file__).parent

import menu_schema as ms
import pilot_deploy as pd
from order_store import redact_dsn

E164 = re.compile(r"^\+[1-9][0-9]{7,14}$")

PASS, WAITING, WARN, FAIL = "PASS", "WAITING", "WARN", "FAIL"

#: Values that look configured but are not. A placeholder API key on a public
#: server is worse than an empty one, because nothing complains.
PLACEHOLDERS = {"", "changeme", "change-me", "dev-secret", "test-secret",
                "placeholder", "placeholder-not-a-real-key", "todo", "xxx"}


def is_placeholder(value: object) -> bool:
    """True for anything that merely looks configured.

    deploy/cherry.env.example ships CHANGE_ME_long_random and +1XXXXXXXXXX; a
    plain set-membership test passed both, so a server could go live behind a
    published secret.
    """
    v = str(value or "").strip().lower()
    if v in PLACEHOLDERS:
        return True
    return bool(re.search(r"change[_-]?me|placeholder|xxxx|example\.com|"
                          r"your[_-]|todo|tbd", v))



@dataclass
class Check:
    group: str
    name: str
    status: str
    detail: str = ""
    fix: str = ""

    @property
    def blocking(self) -> bool:
        return self.status in (FAIL, WARN)


@dataclass
class Report:
    checks: List[Check] = field(default_factory=list)

    def add(self, group: str, name: str, status: str, detail: str = "",
            fix: str = "") -> None:
        self.checks.append(Check(group, name, status, detail, fix))

    @property
    def blocked(self) -> List[Check]:
        return [c for c in self.checks if c.blocking]

    @property
    def ok(self) -> bool:
        return not self.blocked


# ---------------------------------------------------------------------------
# Checks
# ---------------------------------------------------------------------------


def check_database(rep: Report, db: Optional[str]) -> None:
    g = "Database"
    if not db:
        rep.add(g, "database configured", FAIL,
                "no --db and no CHERRY_DATABASE_URL",
                "set CHERRY_DATABASE_URL=postgresql://... or pass --db")
        return
    is_sqlite = not str(db).startswith(("postgres://", "postgresql://"))
    if is_sqlite:
        rep.add(g, "database reachable", PASS, db)
        # Fine for a demo; a pilot needs one database the whole team can reach
        # and that can be restored point-in-time.
        rep.add(g, "database is production-grade", WAITING,
                f"{db} is SQLite",
                "provision PostgreSQL (see DATABASE.md) before a pilot")
        return
    rep.add(g, "database is PostgreSQL", PASS)
    try:
        from order_store import OrderStore
        store = OrderStore.open(db)
        # Reported only now: the old "reachable" PASS was printed before any
        # connection was attempted, and echoed the password with it.
        rep.add(g, "database reachable", PASS, redact_dsn(db))
        tables = store.conn.execute(
            "SELECT count(*) AS n FROM information_schema.tables "
            "WHERE table_schema='public'").fetchone()["n"]
        rep.add(g, "schema present", PASS if tables else FAIL,
                f"{tables} tables",
                "" if tables else "run: python3 production_db.py bootstrap")
        rest = store.conn.execute(
            "SELECT count(*) AS n FROM restaurant WHERE active=TRUE"
        ).fetchone()["n"]
        rep.add(g, "restaurants deployed", PASS if rest else FAIL,
                f"{rest} active",
                "" if rest else "run: python3 pilot_deploy.py apply --db ...")
    except Exception as exc:                           # noqa: BLE001
        rep.add(g, "schema present", FAIL, str(exc)[:120],
                "run: python3 production_db.py bootstrap")


def check_secrets(rep: Report, env: Dict[str, str]) -> None:
    g = "Secrets"
    required = {
        "CHERRY_API_KEY": "authenticates the voice worker and operator calls",
        "CHERRY_VOICE_KEY": "authenticates the voice gateway",
    }
    for name, why in required.items():
        v = str(env.get(name, "")).strip()
        if not v:
            rep.add(g, name, FAIL, f"not set ({why})",
                    f"generate one: openssl rand -hex 24  ->  {name}=...")
        elif is_placeholder(v):
            rep.add(g, f"{name} is not a placeholder", FAIL, f"value is {v!r}",
                    "generate a real secret: openssl rand -hex 24")
        else:
            rep.add(g, f"{name} set", PASS)

    state = str(env.get("CHERRY_OAUTH_STATE_SECRET", "")).strip()
    if not state:
        rep.add(g, "CHERRY_OAUTH_STATE_SECRET", WAITING,
                "not set — required only once Square OAuth is used",
                "set it before sending owners authorize links")
    elif is_placeholder(state) or len(state) < 16:
        # Anyone who knows this can forge an authorize link and point a
        # restaurant's checkout money at their own Square account.
        rep.add(g, "CHERRY_OAUTH_STATE_SECRET is not a placeholder", FAIL,
                "placeholder or shorter than 16 characters",
                "generate a real secret: openssl rand -hex 24")
    else:
        rep.add(g, "CHERRY_OAUTH_STATE_SECRET set", PASS)

    secret_dir = str(env.get("CHERRY_SECRET_DIR", "")).strip()
    if not secret_dir:
        rep.add(g, "secret store", WAITING,
                "CHERRY_SECRET_DIR not set — falling back to the environment",
                "chmod 700 a directory and point CHERRY_SECRET_DIR at it, or "
                "use a secret manager")
        return
    p = Path(secret_dir)
    if not p.is_dir():
        rep.add(g, "CHERRY_SECRET_DIR exists", FAIL, f"{secret_dir} is not a directory",
                "mkdir -m 700 " + secret_dir)
        return
    mode = p.stat().st_mode & 0o777
    rep.add(g, "secret directory is private", PASS if mode == 0o700 else FAIL,
            f"mode {oct(mode)}", "" if mode == 0o700 else
            f"chmod 700 {secret_dir}")


def check_menus(rep: Report, locations: List[pd.Location]) -> None:
    g = "Menus"
    if not locations:
        rep.add(g, "at least one location in the manifest", FAIL,
                "deployments/pilot-locations.yaml has no locations", "")
        return
    bad = []
    for loc in locations:
        if loc.menu is None or not loc.menu.exists():
            bad.append(f"{loc.id}: menu missing")
            continue
        try:
            cfg = ms.load_yaml(loc.menu)
        except ms.SchemaError as exc:
            bad.append(f"{loc.id}: {exc.problems[0] if exc.problems else exc}")
            continue
        if cfg.id != loc.id:
            bad.append(f"{loc.id}: menu declares id {cfg.id!r}")
    if bad:
        rep.add(g, "every manifest menu loads", FAIL, "; ".join(bad[:3]),
                "python3 cherry.py check menus/<file>.yaml")
    else:
        rep.add(g, "every manifest menu loads", PASS,
                f"{len(locations)} location(s)")


def check_routing(rep: Report, locations: List[pd.Location],
                  env: Dict[str, str]) -> None:
    g = "Routing"
    seen: Dict[str, str] = {}
    for loc in locations:
        inbound = str(env.get(loc.inbound_env, "")).strip()
        if not inbound:
            rep.add(g, f"{loc.id} DID", WAITING,
                    f"{loc.inbound_env} not set",
                    f"buy a Telnyx DID and set {loc.inbound_env}=+1...")
            continue
        if not E164.fullmatch(inbound):
            rep.add(g, f"{loc.id} DID", FAIL, f"{inbound!r} is not E.164",
                    f"set {loc.inbound_env} to a +1... number")
            continue
        if inbound in seen:
            rep.add(g, f"{loc.id} DID is unique", FAIL,
                    f"shared with {seen[inbound]}",
                    "one DID per location; a shared number cannot route")
            continue
        seen[inbound] = loc.id

        # The check that matters: the staff line must not be the number that
        # forwards into Cherry. `direct_fallback_source` RAISES on a loop rather
        # than returning, because the deploy path must never write one — so a
        # preflight that failed to catch it would crash on precisely the
        # condition it exists to report.
        try:
            staff, source = pd.direct_fallback_source(loc, env)
        except ValueError as exc:
            rep.add(g, f"{loc.id} direct staff line", FAIL, str(exc),
                    f"set {loc.fallback_env_name} to the restaurant's own line, "
                    f"which must differ from the published number and from "
                    f"every Telnyx DID")
            continue
        if source != "env":
            rep.add(g, f"{loc.id} direct staff line", FAIL,
                    f"{loc.fallback_env_name} not set; would fall back to the "
                    f"PUBLISHED number {staff}, which forwards into Cherry",
                    f"set {loc.fallback_env_name}=+1... (the restaurant's own "
                    f"line, not the published one)")
        elif staff == inbound:
            rep.add(g, f"{loc.id} direct staff line", FAIL,
                    "equals the location's own DID",
                    f"set {loc.fallback_env_name} to a different number")
        else:
            rep.add(g, f"{loc.id} direct staff line", PASS, staff)


def check_providers(rep: Report, locations: List[pd.Location],
                    env: Dict[str, str]) -> None:
    g = "Providers"
    telnyx = [n for n in ("TELNYX_API_KEY", "TELNYX_FROM_NUMBER")
              if is_placeholder(env.get(n, ""))]
    if not telnyx and not E164.fullmatch(str(env.get("TELNYX_FROM_NUMBER", "")).strip()):
        telnyx.append("TELNYX_FROM_NUMBER (not E.164)")
    if telnyx:
        rep.add(g, "Telnyx configured", FAIL, "missing " + ", ".join(telnyx),
                "the voice gateway refuses to start without TELNYX_API_KEY")
    else:
        rep.add(g, "Telnyx configured", PASS)

    if not str(env.get("TELNYX_PUBLIC_KEY", "")).strip():
        # Not a nicety: without it the webhook can only be authenticated by
        # X-Cherry-Key, which Telnyx cannot send. Every STOP reply and
        # delivery receipt is rejected, so opt-outs are never recorded
        # (a 10DLC compliance failure) and failed texts are never seen.
        rep.add(g, "Telnyx webhook signature", FAIL,
                "TELNYX_PUBLIC_KEY not set — Telnyx's SMS webhooks (STOP, "
                "delivery receipts) will be rejected",
                "set TELNYX_PUBLIC_KEY from the Telnyx portal (base64 Ed25519)")
    else:
        rep.add(g, "Telnyx webhook signature", PASS)

    square_locs = [l for l in locations if l.pos_type == "square"]
    toast_locs = [l for l in locations if l.pos_type == "toast"]
    clover_locs = [l for l in locations if l.pos_type == "clover"]
    
    if not square_locs and not toast_locs and not clover_locs:
        rep.add(g, "checkout provider", PASS, "no POS locations configured")
    
    # Square checks
    if square_locs:
        missing = [n for n in ("SQUARE_OAUTH_CLIENT_ID",
                               "SQUARE_OAUTH_CLIENT_SECRET")
                   if not str(env.get(n, "")).strip()]
        if missing:
            rep.add(g, "Square app configured", FAIL, "missing " + ", ".join(missing),
                    "these locations need an itemized checkout before go-live")
        else:
            rep.add(g, "Square app configured", PASS)
        for loc in square_locs:
            key = loc.id.upper().replace("-", "_")
            # Tokens normally live in the vault (CHERRY_SECRET_DIR), not in
            # the environment, and the process-wide SQUARE_ACCESS_TOKEN
            # belongs to one merchant, so it never counts for a location.
            from vault import secret as vault_secret
            token = (vault_secret(f"SQUARE_TOKEN_{key}")
                     or str(env.get(f"SQUARE_TOKEN_{key}", "")).strip())
            square_loc = (vault_secret(f"SQUARE_LOCATION_{key}")
                          or str(env.get(f"SQUARE_LOCATION_{key}", "")).strip())
            if not token:
                rep.add(g, f"{loc.id} merchant authorization", WAITING,
                        "no Square token for this location",
                        f"send the owner: python3 square_oauth.py authorize-url "
                        f"--restaurant {loc.id}")
            elif not square_loc:
                rep.add(g, f"{loc.id} merchant authorization", FAIL,
                        "authorized, but no Square location was chosen — "
                        "checkout links cannot be created",
                        f"python3 square_oauth.py set-location --restaurant "
                        f"{loc.id} --location <id>")
            else:
                rep.add(g, f"{loc.id} merchant authorization", PASS)
    
    # Toast checks (partner model - single credentials for all restaurants)
    if toast_locs:
        missing = [n for n in ("TOAST_CLIENT_ID", "TOAST_CLIENT_SECRET")
                   if not str(env.get(n, "")).strip()]
        if missing:
            rep.add(g, "Toast partner configured", FAIL, "missing " + ", ".join(missing),
                    "register as a Toast partner to get credentials")
        else:
            from vault import secret as vault_secret
            # Toast uses shared tokens (not per-restaurant)
            token = vault_secret("TOAST_ACCESS_TOKEN")
            if not token:
                rep.add(g, "Toast authenticated", WAITING,
                        "no Toast access token",
                        "run: python3 toast_oauth.py authenticate")
            else:
                rep.add(g, "Toast authenticated", PASS)
    
    # Clover checks (per-merchant OAuth, similar to Square)
    if clover_locs:
        missing = [n for n in ("CLOVER_CLIENT_ID", "CLOVER_CLIENT_SECRET")
                   if not str(env.get(n, "")).strip()]
        if missing:
            rep.add(g, "Clover app configured", FAIL, "missing " + ", ".join(missing),
                    "create a Clover app to get credentials")
        else:
            rep.add(g, "Clover app configured", PASS)
        for loc in clover_locs:
            key = loc.id.upper().replace("-", "_")
            from vault import secret as vault_secret
            token = (vault_secret(f"CLOVER_TOKEN_{key}")
                     or str(env.get(f"CLOVER_TOKEN_{key}", "")).strip())
            merchant = (vault_secret(f"CLOVER_MERCHANT_{key}")
                        or str(env.get(f"CLOVER_MERCHANT_{key}", "")).strip())
            if not token:
                rep.add(g, f"{loc.id} merchant authorization", WAITING,
                        "no Clover token for this location",
                        f"send the owner: python3 clover_oauth.py authorize-url "
                        f"--restaurant {loc.id}")
            elif not merchant:
                rep.add(g, f"{loc.id} merchant authorization", FAIL,
                        "authorized, but no Clover merchant ID was set",
                        "check the authorization result")
            else:
                rep.add(g, f"{loc.id} merchant authorization", PASS)

    alert_phones = [p.strip() for p in
                    str(env.get("CHERRY_ALERT_PHONE", "")).split(",") if p.strip()]
    if not alert_phones:
        rep.add(g, "alerts reach a handset", WARN,
                "CHERRY_ALERT_PHONE not set — alerts are logged, nobody is paged",
                "set CHERRY_ALERT_PHONE=+1... and confirm a real test page")
    elif not all(E164.fullmatch(p) for p in alert_phones):
        rep.add(g, "alerts reach a handset", FAIL,
                "CHERRY_ALERT_PHONE has a value that is not an E.164 number",
                "use +1XXXXXXXXXX, comma-separated, real numbers")
    else:
        rep.add(g, "alerts reach a handset", PASS)
        if not str(env.get("CHERRY_ALERT_WEBHOOK", "")).strip():
            # Pages go out as SMS from the same Telnyx number callers' checkout
            # links use. If that number is blocked, the outage and the alert
            # about it fail together.
            rep.add(g, "alerts have a second channel", WARN,
                    "only SMS pages are configured; a dead Telnyx number "
                    "silences them too",
                    "set CHERRY_ALERT_WEBHOOK to a Slack/PagerDuty/email hook")


def check_payment_paths(rep: Report, locations: List[pd.Location]) -> None:
    """How each location that is NOT on Square will take payment.

    Cherry only has an itemized checkout for Square. A Toast, Clover or EPIPay
    location with a menu that wants a pay-now link for every order would transfer
    every caller to staff — that is not a failure of the code, but nobody should
    discover it on launch night. The supported answer today is pay-at-pickup
    (POS_INTEGRATION_PLAN.md, Path A), which is a menu setting the owner chooses.
    """
    g = "Payment path"
    for loc in locations:
        if loc.pos_type == "square":
            continue
        try:
            mode = pd.payment_mode(loc)
        except Exception as exc:                          # noqa: BLE001
            rep.add(g, f"{loc.id} payment path", FAIL, f"menu unreadable: {str(exc)[:100]}", "")
            continue
        if mode == "pay_at_pickup":
            rep.add(g, f"{loc.id} payment path", PASS,
                    f"pay at pickup ({loc.pos_type}): orders go straight to the kitchen; "
                    "the customer pays at the counter")
        else:
            who = "every call" if mode == "pay_now" else "every order over the pay-now threshold"
            rep.add(g, f"{loc.id} payment path", WAITING,
                    f"no itemized checkout exists for {loc.pos_type}: {who} would be transferred to staff",
                    "owner's choice (POS_INTEGRATION_PLAN.md): (A) set pay_now_threshold_cents in the menu "
                    "to 50000 or more so every order is pay-at-pickup, (B) put the location on Square, or "
                    "(C) wait for the POS's partner API")


def check_runtime(rep: Report, url: Optional[str], env: Dict[str, str]) -> None:
    g = "Runtime"
    if not url:
        rep.add(g, "running server", WAITING, "no --url given; skipped",
                "pass --url http://127.0.0.1:8080 to include the live server")
        return
    try:
        with urllib.request.urlopen(f"{url.rstrip('/')}/health", timeout=8) as r:
            health = json.loads(r.read())
    except Exception as exc:                           # noqa: BLE001
        rep.add(g, "running server", FAIL, str(exc)[:120],
                "start it: python3 server.py --db ... --key ...")
        return
    rep.add(g, "server responds", PASS if health.get("ok") else FAIL,
            json.dumps({k: health.get(k) for k in
                        ("ok", "database", "live_menus")}))
    if health.get("database") != "ok":
        rep.add(g, "server can reach the database", FAIL,
                str(health.get("database")), "check CHERRY_DATABASE_URL")

    checkout = health.get("checkout")
    if checkout == "dev":
        # Refuse to call this live: dev checkout marks orders paid with no money.
        rep.add(g, "checkout is real", FAIL,
                "server is running --dev-checkout",
                "restart without --dev-checkout and configure Square")
    else:
        rep.add(g, "checkout is real", PASS, str(checkout))

    if not str(env.get("CHERRY_CHECKOUT_HANDOFF_ONLY", "")).strip() == "1":
        rep.add(g, "CHERRY_CHECKOUT_HANDOFF_ONLY", WARN,
                "not set to 1 — a paid webhook may release a second ticket",
                "set CHERRY_CHECKOUT_HANDOFF_ONLY=1 in the server AND job env")
    else:
        rep.add(g, "CHERRY_CHECKOUT_HANDOFF_ONLY", PASS)


def check_inworld(rep: Report) -> None:
    g = "Voice"
    try:
        from inworld_adapter import Dialect, main as _adapter_main  # noqa: F401
    except Exception as exc:                           # noqa: BLE001
        rep.add(g, "inworld adapter importable", FAIL, str(exc)[:120], "")
        return
    rep.add(g, "inworld adapter importable", PASS)
    d = Dialect.from_env()
    rep.add(g, "event dialect", PASS,
            f"type={d.type_field} call_id={d.call_id_field} "
            f"({len(d.started_types)} start / {len(d.tool_types)} tool spellings)")
    rep.add(g, "provider event format confirmed", WAITING,
            "Inworld's real field names are unconfirmed",
            "capture one real event, then: python3 inworld_adapter.py check "
            "--file event.json")
    rep.add(g, "voice worker follows the engine's call policy", WAITING,
            "only a real call can show it: tools declared BLOCKING, the idle prompt, "
            "the call-length cap, and the engine's words spoken verbatim",
            "make one real call, then: python3 call_review.py --db <db> --latest "
            "[--spoken spoken.txt] (see CALL_SOUND_GUIDE.md)")


# ---------------------------------------------------------------------------
# Report
# ---------------------------------------------------------------------------

_COLOR = {PASS: "\033[32m", FAIL: "\033[31m", WARN: "\033[31m",
          WAITING: "\033[33m"}
_RESET = "\033[0m"


def render(rep: Report, color: bool = True) -> str:
    def c(s, st):
        return f"{_COLOR[st]}{s}{_RESET}" if color else s

    lines, group = [], None
    for chk in rep.checks:
        if chk.group != group:
            group = chk.group
            lines.append(f"\n{group}")
        lines.append(f"  {c(f'{chk.status:7}', chk.status)} {chk.name}"
                     + (f" — {chk.detail}" if chk.detail else ""))
        if chk.fix and chk.status != PASS:
            lines.append(f"          fix: {chk.fix}")
    return "\n".join(lines)


def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--db", default=os.getenv("CHERRY_DATABASE_URL", ""),
                    help="defaults to CHERRY_DATABASE_URL")
    ap.add_argument("--url", default="", help="running server to probe")
    ap.add_argument("--manifest", default=str(pd.DEFAULT_MANIFEST))
    ap.add_argument("--only", action="append", default=[],
                    help="limit to a location id or group; repeatable")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--no-color", action="store_true")
    args = ap.parse_args(argv)

    env = dict(os.environ)
    try:
        locations = pd.load_manifest(Path(args.manifest))
    except Exception as exc:                           # noqa: BLE001
        print(f"manifest unreadable: {exc}")
        return 2
    if args.only:
        locations = pd.selected(locations, args.only)

    rep = Report()
    check_database(rep, args.db or None)
    check_secrets(rep, env)
    check_menus(rep, locations)
    check_routing(rep, locations, env)
    check_providers(rep, locations, env)
    check_payment_paths(rep, locations)
    check_runtime(rep, args.url or None, env)
    check_inworld(rep)

    if args.json:
        print(json.dumps({
            "ok": rep.ok,
            "checks": [{"group": c.group, "name": c.name, "status": c.status,
                        "detail": c.detail, "fix": c.fix} for c in rep.checks],
        }, indent=2))
        return 0 if rep.ok else 1

    print("Cherry go-live preflight")
    print(render(rep, color=not args.no_color))

    fails = [c for c in rep.checks if c.status == FAIL]
    warns = [c for c in rep.checks if c.status == WARN]
    waits = [c for c in rep.checks if c.status == WAITING]
    print()
    if not fails and not warns:
        print(f"\033[32mREADY\033[0m — nothing blocks a call. "
              f"{len(waits)} item(s) still waiting on a human:" if waits
              else "\033[32mREADY\033[0m — nothing blocks a call.")
        for c in waits:
            print(f"  - {c.name}: {c.detail}")
        return 0
    print(f"\033[31mNOT READY\033[0m — {len(fails)} blocker(s), "
          f"{len(warns)} warning(s). Fix the blockers and run this again.")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
