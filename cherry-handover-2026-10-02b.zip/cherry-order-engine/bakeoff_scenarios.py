"""Scripted calls for `model_bakeoff.py`.

Each scenario is what a caller says, turn by turn, with the tool calls an IDEAL
voice model would make for each turn, and what the finished call should look
like. The expectations are written by hand from what the caller MEANT — never
generated from the engine's output — so a scenario fails when the engine or a
model gets it wrong, not when it merely changes.

Cuisines: Indian, American burgers, Chinese, Mexican, Middle Eastern, sushi.
Languages: English, Spanish, Arabic and Hindi/Urdu (as callers actually say them).
Behaviours: allergies, a name, "the usual", sold-out dishes, corrections,
quantities ("a couple", "half a dozen"), hours, wait time, a different text
number, an unknown dish, a hesitant "which one?".
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import menu_schema as ms

HERE = Path(__file__).resolve().parent
Turn = Tuple[str, List[Tuple[str, Dict[str, Any]]]]


def T(tool: str, **args: Any) -> Tuple[str, Dict[str, Any]]:
    return (tool, args)


def returning(menu: str, lines: Sequence[Tuple[str, int]], name: str = "",
              allergy_note: str = "") -> Dict[str, Any]:
    """A regular's last order, with real item ids from the menu."""
    cfg = ms.load_yaml(HERE / "menus" / f"{menu}.yaml")
    out = []
    for item_name, qty in lines:
        it = next(i for i in cfg.items if i.name == item_name)
        out.append({"item_id": it.id, "item_name": it.name, "quantity": qty, "size_id": None,
                    "note": "", "modifiers": [], "removed_defaults": []})
    return {"name": name, "lines": out, "allergy_note": allergy_note}


def scenario(id: str, menu: str, tags: List[str], turns: Sequence[Turn], expect: Dict[str, Any],
             *, context: Optional[Dict[str, Any]] = None,
             unavailable: Optional[List[str]] = None) -> Dict[str, Any]:
    return {"id": id, "menu": menu, "tags": tags, "caller": [t for t, _ in turns],
            "plan": [calls for _, calls in turns], "expect": expect,
            "context": context or {}, "unavailable": unavailable or []}


#: how a good call ends: the host asks for a name and allergies; the caller answers.
def finish(name: str = "Sam", allergy: str = "no allergies") -> List[Turn]:
    return [("that's all", [T("ready_to_place")]),
            (f"{name}, {allergy}", [T("set_name", text=name), T("note_allergy", text=allergy)]),
            ("yes, that's right", [T("ready_to_place")])]


PG, BNR, CHENG, NAKED = "pink-garlic-shelby", "bun-n-run-ferndale", "chengs-sterling-heights", "naked-burger-detroit"
JM, SAMS, MIYA, TAMAGO = "juan-miguels-clinton", "sams-kabob-clinton", "miyazaki-hall-rd", "tamago-sushi-bowl"

SCENARIOS: List[Dict[str, Any]] = [
    # ---- English, the ordinary call ---------------------------------------------------------
    scenario("pg-basic-order", PG, ["english", "indian", "name", "allergy"], [
        ("Hi, I'd like to place an order", [T("add_item", text="I'd like to place an order")]),
        ("a chicken korma, medium", [T("add_item", text="chicken korma"), T("answer", text="medium")]),
        ("and a garlic naan", [T("add_item", text="garlic naan")]),
    ] + finish(), {"cart": [("Chicken Korma (Creamy)", 1), ("Garlic Naan", 1)], "name": "Sam", "allergy": "none",
                   "submittable": True, "never_says": ["we don't have that"]}),
    scenario("pg-quantity-phrases", PG, ["english", "indian", "quantity"], [
        ("a couple of garlic naan", [T("add_item", text="a couple of garlic naan")]),
        ("and half a dozen vegetable samosas", [T("add_item", text="half a dozen vegetable samosas")]),
    ] + finish("Dana"), {"cart": [("Garlic Naan", 2), ("Vegetable Samosa (2Pcs)", 6)], "name": "Dana", "allergy": "none"}),
    scenario("pg-correction", PG, ["english", "indian", "correction"], [
        ("two garlic naan", [T("add_item", text="two garlic naan")]),
        ("actually make that three", [T("set_quantity", quantity=3)]),
    ] + finish(), {"cart": [("Garlic Naan", 3)], "name": "Sam"}),
    scenario("pg-take-an-item-off", PG, ["english", "indian", "correction"], [
        ("a garlic naan and a vegetable samosa", [T("add_item", text="garlic naan"), T("add_item", text="vegetable samosa")]),
        ("take the samosa off", [T("remove_item", text="the samosa")]),
    ] + finish(), {"cart": [("Garlic Naan", 1)]}),
    scenario("pg-extra-on-a-dish", PG, ["english", "indian", "modifier"], [
        ("chicken tikka masala, hot, with extra chicken",
         [T("add_item", text="chicken tikka masala"), T("answer", text="hot"), T("add_modifier", text="extra chicken")]),
    ] + finish(), {"cart": [("Chicken Tikka Masala (Creamy)", 1)], "submittable": True, "name": "Sam"}),
    scenario("pg-which-korma", PG, ["english", "indian", "ambiguity"], [
        ("a korma please", [T("add_item", text="korma")]),
        ("the chicken one, mild", [T("answer", text="chicken"), T("answer", text="mild")]),
    ] + finish(), {"cart": [("Chicken Korma (Creamy)", 1)], "says": ["Did you want"], "submittable": True}),
    scenario("pg-unknown-dish-is-not-swapped", PG, ["english", "indian", "safety"], [
        ("a pad thai please", [T("add_item", text="pad thai")]),
        ("no, never mind", [T("answer", text="no")]),
    ], {"cart": [], "says": ["Did you mean the"], "never_says": ["Got it — Paratha"]}),

    # ---- Allergies, names, the number the link goes to --------------------------------------
    scenario("pg-allergy-volunteered", PG, ["english", "indian", "allergy", "name"], [
        ("a chicken korma, medium. My daughter is allergic to peanuts.",
         [T("add_item", text="chicken korma"), T("answer", text="medium"),
          T("note_allergy", text="my daughter is allergic to peanuts")]),
        ("that's all", [T("ready_to_place")]),
        ("Priya", [T("set_name", text="Priya")]),
        ("yes", [T("ready_to_place")]),
    ], {"cart": [("Chicken Korma (Creamy)", 1)], "name": "Priya", "allergy": "contains:peanut",
        "says": ["flagged that for the kitchen"], "never_says": ["safe"], "submittable": True}),
    scenario("pg-allergy-question-never-answered-from-memory", PG, ["english", "indian", "allergy", "safety"], [
        ("does the chicken korma have nuts?", [T("item_info", text="does the chicken korma have nuts")]),
        ("I have a nut allergy, what can I eat?", [T("item_info", text="I have a nut allergy, what can I eat?")]),
    ], {"cart": [], "never_says": ["safe", "no nuts", "nut-free"], "says": ["hasn't marked", "tell the restaurant"]}),
    scenario("pg-landline-text-a-cell", PG, ["english", "indian", "text-number"], [
        ("a garlic naan", [T("add_item", text="garlic naan")]),
        ("I'm on a landline, text it to my cell: 586 980 5199", [T("set_text_number", text="586 980 5199")]),
    ] + finish(), {"cart": [("Garlic Naan", 1)], "text_to": "+15869805199", "says": ["ending in five one nine nine"]}),

    # ---- The host knows things --------------------------------------------------------------
    scenario("pg-regular-the-usual", PG, ["english", "indian", "regular"], [
        ("the usual please", [T("reorder_last")]),
        ("medium", [T("answer", text="medium")]),
    ] + finish("Sam", "same as before"),
        {"cart": [("Chicken Korma (Creamy)", 1), ("Garlic Naan", 2)], "name": "Sam", "allergy": "contains:peanut",
         "says": ["I've added your usual"], "submittable": True},
        context={"returning": returning(PG, [("Chicken Korma (Creamy)", 1), ("Garlic Naan", 2)], "Sam", "peanut allergy")}),
    scenario("pg-closing-time", PG, ["english", "indian", "info"], [
        ("what time do you close tonight?", [T("store_info", text="what time do you close tonight")]),
    ], {"cart": [], "says": ["9 PM"]},
        context={"hours": {"configured": True, "open_now": True, "closes": "9 PM", "next_open": ""}}),
    scenario("pg-closing-time-unknown-is-not-guessed", PG, ["english", "indian", "info", "safety"], [
        ("what time do you close?", [T("store_info", text="what time do you close")]),
    ], {"cart": [], "says": ["don't have the hours"], "never_says": ["PM", "AM"]}),
    scenario("pg-how-long", PG, ["english", "indian", "info"], [
        ("how long will it take?", [T("store_info", text="how long will it take")]),
    ], {"cart": [], "says": ["25 minutes"]}, context={"prep_minutes": 25}),
    scenario("pg-sold-out-offers-the-closest", PG, ["english", "indian", "sold-out"], [
        ("two lamb korma please", [T("add_item", text="two lamb korma")]),
        ("yes that's fine", [T("answer", text="yes")]),
    ], {"total_items": 2, "says": ["out of the Lamb/Goat Korma", "very close"]},
        unavailable=["Lamb/Goat Korma (Creamy)"]),

    # ---- Other cuisines ---------------------------------------------------------------------
    scenario("bnr-burger-no-onion", BNR, ["english", "burgers", "modifier"], [
        ("a double cheeseburger, no onion", [T("add_item", text="double cheeseburger"), T("remove_modifier", text="no onion")]),
        ("and fries", [T("add_item", text="french fries")]),
        ("no, that's it", [T("confirm_mods")]),
    ] + finish(), {"cart": [("Double Cheeseburger", 1), ("French Fries", 1)], "submittable": True,
                   "says": ["Anything else you'd like to change on the Double Cheeseburger"]}),
    scenario("naked-burger-with-a-side", NAKED, ["english", "burgers", "required-choice"], [
        ("a naked burger", [T("add_item", text="naked burger")]),
        ("with the fries", [T("answer", text="naked fries")]),
    ] + finish(), {"cart": [("Naked Burger", 1)], "submittable": True}),
    scenario("cheng-egg-roll-large", CHENG, ["english", "chinese", "required-choice"], [
        ("an egg roll", [T("add_item", text="egg roll")]),
        ("large", [T("answer", text="large")]),
        ("and two crab rangoons", [T("add_item", text="two crab rangoons")]),
    ] + finish("Wei"), {"cart": [("Egg Roll", 1), ("Crab Rangoons (6)", 2)], "name": "Wei", "submittable": True}),
    scenario("miyazaki-two-rolls", MIYA, ["english", "sushi"], [
        ("a california roll and a spicy tuna roll", [T("add_item", text="california roll"), T("add_item", text="spicy tuna roll")]),
    ] + finish("Ken"), {"cart": [("California Roll", 1), ("Spicy Tuna Roll", 1)], "name": "Ken"}),
    scenario("tamago-edamame-gyoza", TAMAGO, ["english", "sushi"], [
        ("edamame and gyoza", [T("add_item", text="edamame"), T("add_item", text="gyoza")]),
    ] + finish("Mia"), {"cart": [("Edamame", 1), ("Gyoza", 1)], "name": "Mia"}),

    # ---- Other languages --------------------------------------------------------------------
    scenario("es-two-burritos", JM, ["spanish", "mexican", "quantity", "name", "allergy"], [
        ("hola, quiero dos burritos de pollo", [T("add_item", text="quiero dos burritos"), T("answer", text="pollo")]),
        ("y una quesabirria por favor", [T("add_item", text="una quesabirria por favor")]),
        ("es todo", [T("ready_to_place")]),
        ("me llamo Carlos, sin alergias", [T("set_name", text="me llamo Carlos"), T("note_allergy", text="sin alergias")]),
        ("sí", [T("ready_to_place")]),
    ], {"cart": [("Burritos", 2), ("Quesabirria", 1)], "name": "Carlos", "allergy": "none", "submittable": True}),
    scenario("es-half-dozen-and-numbers", JM, ["spanish", "mexican", "quantity"], [
        ("media docena de bag of chips", [T("add_item", text="media docena de bag of chips")]),
        ("tres kids taco", [T("add_item", text="tres kids taco")]),
    ] + finish("Ana"), {"cart": [("Bag of Chips", 6), ("Kids Taco", 3)], "name": "Ana"}),
    scenario("es-without-onion", BNR, ["spanish", "burgers", "modifier"], [
        ("quiero una double cheeseburger sin cebolla", [T("add_item", text="double cheeseburger"), T("remove_modifier", text="sin cebolla")]),
        ("no, nada más", [T("confirm_mods")]),
    ] + finish("Luis"), {"cart": [("Double Cheeseburger", 1)], "name": "Luis", "submittable": True}),
    scenario("ar-hommus-and-falafel", SAMS, ["arabic", "middle-eastern", "quantity"], [
        ("wahid hommus", [T("add_item", text="wahid hommus")]),
        ("ithnain falafel plate", [T("add_item", text="ithnain falafel plate")]),
    ] + finish("Omar"), {"cart": [("Hommus", 1), ("Falafel Plate", 2)], "name": "Omar"}),
    scenario("hi-murgh-makhani", PG, ["hindi-urdu", "indian", "quantity"], [
        ("ek murgh makhani", [T("add_item", text="ek murgh makhani"), T("answer", text="mild")]),
        ("aur paanch vegetable samosa", [T("add_item", text="paanch vegetable samosa")]),
    ] + finish("Priya"), {"cart": [("Butter Chicken (Creamy)", 1), ("Vegetable Samosa (2Pcs)", 5)], "name": "Priya"}),
]
