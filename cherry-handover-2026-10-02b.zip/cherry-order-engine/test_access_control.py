#!/usr/bin/env python3
"""Tenant roles and location-scoped operations data."""

import json
import traceback

import access_control as ac

_passed = _failed = 0

def check(name, cond, detail=""):
    global _passed, _failed
    if cond: _passed += 1
    else:
        _failed += 1; print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))

def policy():
    return ac.AccessPolicy.from_json(json.dumps([
        {"name":"Oak owner","key":"oak-secret","role":"viewer",
         "restaurants":["oak"]},
        {"name":"Ops","key":"ops-secret","role":"operator",
         "restaurants":["*"]},
    ]))

def t_roles_are_enforced_and_plaintext_is_not_retained():
    p=policy(); oak=p.authenticate("oak-secret")
    check("viewer can read operations", p.permits(oak,"viewer","oak"))
    check("viewer cannot invoke service tools", not p.permits(oak,"service","oak"))
    check("viewer cannot cross tenant", not p.permits(oak,"viewer","allen"))
    check("wrong key is rejected", p.authenticate("wrong") is None)
    check("plaintext key is not stored", "oak-secret" not in repr(p.__dict__))

def t_scoped_snapshot_cannot_leak_another_restaurant():
    principal=policy().authenticate("oak-secret")
    snap={"by_restaurant":[
        {"restaurant_id":"oak","name":"Oak","calls":2,"orders":1,"revenue_cents":1000,"escalations":0},
        {"restaurant_id":"allen","name":"Allen","calls":9,"orders":8,"revenue_cents":9000,"escalations":1}],
        "alerts":[{"restaurant_id":"allen","title":"private"}],
        "engine_issues":[{"code":"private","count":9}],"summary":{}}
    out=ac.scope_snapshot(snap,principal); encoded=json.dumps(out)
    check("only authorized restaurant remains", len(out["by_restaurant"])==1)
    check("summary is recomputed from authorized rows", out["summary"]["calls"]==2 and out["summary"]["orders"]==1)
    check("other tenant never appears", "Allen" not in encoded and "private" not in encoded)

def main():
    for name,fn in sorted(globals().items()):
        if name.startswith("t_"):
            try: fn()
            except Exception:
                global _failed; _failed+=1; print(f"\n--- FAIL {name}\n{traceback.format_exc()}")
    print(f"\n{_passed} passed, {_failed} failed (access control)")
    return 1 if _failed else 0

if __name__ == "__main__": raise SystemExit(main())
