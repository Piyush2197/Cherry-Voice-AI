#!/usr/bin/env python3
"""
The demo line — one number, every restaurant on the route.

WHY THIS EXISTS
---------------
The field plan names its own missing piece:

> Coming upgrade: one real dial-in demo number for the whole route, once the
> developer's Phase 1 (VPS + one DID) is live.

This is the routing behind that number. A rep walks into a restaurant, dials the
demo line, enters the short code printed on the route sheet, and Cherry answers
**that restaurant's cuisine** and takes a real order over it. No app, no laptop,
no signal-dependent web page — the strongest thing in the pitch, working from
any phone.

It also closes the loop the other way. `cherry.py prospect` reads the field-plan
workbook and writes the registry below, so the whole sales route is
pre-onboarded before anyone has said yes: 19 prospects, each with a code, a
cuisine and a working menu, ready to demo on the doorstep.

THE SAFETY BOUNDARY
-------------------
A demo must be incapable of becoming a real order. This module therefore never
touches a database, never sends an SMS, never creates a POS ticket and never
takes payment — it drives `agent_api.CallSession`, the same object production
drives, over a config loaded straight from YAML. Nothing it does is persisted,
so a demo cannot leave a restaurant with a phantom ticket or a customer with a
charge they did not make.

That boundary is the whole reason a demo can be shown before a contract exists.

WHAT IS AND IS NOT CLAIMED
--------------------------
A prospect has no menu on file until someone ingests one. Until then its entry
is a **cuisine demo**: the closest menu we have, clearly labelled as not theirs.
`DEMO_ONBOARDING.md` is emphatic about this and so is the registry — every entry
carries `menu_kind`, and `describe()` says out loud which one it is. When the
owner hands over a real menu, the entry is re-registered as `their_menu` and the
demo becomes genuinely theirs.

USAGE
-----
    python3 cherry.py prospect --plan ../sales/cherry-clinton-first-field-plan-v2.xlsx
    python3 demo_line.py list --day 2
    python3 demo_line.py resolve --code 042
    python3 demo_line.py run --code 042
"""

from __future__ import annotations

import _ensure_deps  # noqa: F401  (re-runs under .venv, or says how to install, if PyYAML is missing)
import argparse
import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Sequence

import yaml

import menu_schema as ms

ROOT = Path(__file__).resolve().parent
DEFAULT_LINE = ROOT / "demos" / "demo-line.yaml"

#: `cuisine_demo` = the closest menu we have, NOT the restaurant's own.
#: `their_menu`   = built from a menu the owner actually gave us.
MENU_KINDS = {"cuisine_demo", "their_menu"}

CODE = re.compile(r"^\d{2,4}$")


@dataclass
class DemoEntry:
    code: str
    name: str
    menu: str                      # repo-relative path
    menu_kind: str = "cuisine_demo"
    day: int = 0
    tier: str = ""
    phone: str = ""
    address: str = ""
    platform: str = ""
    angle: str = ""
    active: bool = True

    @property
    def menu_path(self) -> Path:
        return ROOT / self.menu

    def describe(self) -> str:
        """What the rep may say out loud about this demo. Never overstates."""
        if self.menu_kind == "their_menu":
            return f"{self.name} — demoing their own menu"
        return (f"{self.name} — demoing the closest cuisine menu we have. "
                f"This is NOT their menu; say so.")


class DemoLineError(ValueError):
    pass


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------


def load_line(path: Path = DEFAULT_LINE) -> List[DemoEntry]:
    if not path.exists():
        raise DemoLineError(
            f"no demo line at {path}. Build one from the field plan:\n"
            f"  python3 cherry.py prospect --plan <field-plan.xlsx>")
    doc = yaml.safe_load(path.read_text())
    if not isinstance(doc, dict) or doc.get("schema_version") != 1:
        raise DemoLineError("demo line must have schema_version: 1")
    rows = doc.get("entries")
    if not isinstance(rows, list):
        raise DemoLineError("demo line needs an entries list")

    out, seen = [], set()
    for n, row in enumerate(rows):
        if not isinstance(row, dict):
            raise DemoLineError(f"entries[{n}] must be a mapping")
        code = str(row.get("code", "")).strip()
        if not CODE.fullmatch(code):
            raise DemoLineError(
                f"entries[{n}].code {code!r} must be 2-4 digits — it is typed "
                f"on a phone keypad, so keep it short and unambiguous")
        if code in seen:
            raise DemoLineError(f"duplicate demo code {code}")
        seen.add(code)
        name = str(row.get("name", "")).strip()
        if not name:
            raise DemoLineError(f"entries[{n}].name is required")
        menu = str(row.get("menu", "")).strip()
        kind = str(row.get("menu_kind", "cuisine_demo")).strip()
        if kind not in MENU_KINDS:
            raise DemoLineError(
                f"entries[{n}].menu_kind must be one of {sorted(MENU_KINDS)}")
        if menu and not (ROOT / menu).exists():
            raise DemoLineError(
                f"entries[{n}] ({name}) points at a menu that does not exist: "
                f"{menu}")
        out.append(DemoEntry(
            code=code, name=name, menu=menu, menu_kind=kind,
            day=int(row.get("day") or 0), tier=str(row.get("tier") or ""),
            phone=str(row.get("phone") or ""), address=str(row.get("address") or ""),
            platform=str(row.get("platform") or ""),
            angle=str(row.get("angle") or ""),
            active=bool(row.get("active", True))))
    return out


def save_line(entries: Sequence[DemoEntry], path: Path = DEFAULT_LINE) -> None:
    doc = {
        "schema_version": 1,
        "note": ("Generated from the field plan. A 'cuisine_demo' entry is the "
                 "closest menu we have and is NOT the restaurant's own — say so "
                 "at the counter. Regenerate with: cherry.py prospect --plan …"),
        "entries": [
            {k: v for k, v in (
                ("code", e.code), ("name", e.name), ("menu", e.menu),
                ("menu_kind", e.menu_kind), ("day", e.day), ("tier", e.tier),
                ("phone", e.phone), ("address", e.address),
                ("platform", e.platform), ("angle", e.angle),
                ("active", e.active)) if v not in ("", 0, None)
            } for e in entries],
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(doc, sort_keys=False, allow_unicode=True,
                                   width=100))


# ---------------------------------------------------------------------------
# Resolution — how an inbound call becomes one restaurant
# ---------------------------------------------------------------------------


def resolve(entries: Sequence[DemoEntry], *, code: str = "",
            caller: str = "", did: str = "",
            pins: Optional[Dict[str, str]] = None) -> DemoEntry:
    """Pick the demo for an inbound call. Raises with the reason if it cannot.

    Order of precedence, most specific first:

      1. the code the caller typed  — always wins, it is unambiguous
      2. a pin from the caller's number — for a rep whose phone is registered
         to today's stop, so they need not type anything
      3. nothing — and that is an error, never a guess.

    Guessing here would answer a restaurateur with the wrong restaurant's menu,
    which is worse than a plain "which restaurant?" prompt.
    """
    live = [e for e in entries if e.active]
    if not live:
        raise DemoLineError("the demo line has no active entries")

    code = str(code or "").strip()
    if code:
        for e in live:
            if e.code == code:
                return e
        known = ", ".join(sorted(e.code for e in live)[:12])
        raise DemoLineError(
            f"no demo for code {code!r}. Known codes: {known}"
            + (" …" if len(live) > 12 else ""))

    caller = str(caller or "").strip()
    if caller and pins:
        target = pins.get(caller)
        if target:
            for e in live:
                if e.code == str(target) or e.name == target:
                    return e
            raise DemoLineError(
                f"caller {caller} is pinned to {target!r}, which is not on the "
                f"demo line any more")

    raise DemoLineError(
        "which restaurant? Enter the code from the route sheet. "
        "(Nothing was guessed: answering with the wrong menu at the counter "
        "is worse than asking.)")


def pins_from_env(env: Optional[Dict[str, str]] = None) -> Dict[str, str]:
    """`CHERRY_DEMO_PIN_<digits>=<code>` pins a rep's phone to a stop.

    Useful on a route day: pin the rep's mobile to the next stop and the demo
    answers without anyone typing a code in front of the owner.
    """
    import os
    env = os.environ if env is None else env
    out = {}
    for key, value in env.items():
        if key.startswith("CHERRY_DEMO_PIN_"):
            number = key[len("CHERRY_DEMO_PIN_"):]
            if not number.startswith("+"):
                number = "+" + number
            out[number] = str(value).strip()
    return out


# ---------------------------------------------------------------------------
# Running a demo
# ---------------------------------------------------------------------------


def run_demo(entry: DemoEntry, script: Optional[Path] = None,
             echo: bool = True) -> int:
    """Take one practice order over the entry's menu. Persists nothing.

    Drives `cherry.Session`, which is a thin skin over `agent_api.CallSession` —
    the object production drives. So a demo exercises the real engine, and the
    absence of a database, SMS sender or payment provider is what keeps it a
    demo rather than a live order.
    """
    from cherry import Session

    if not entry.menu:
        raise DemoLineError(
            f"{entry.name} has no menu yet. Ingest the owner's menu, or point "
            f"the entry at a cuisine menu and keep menu_kind: cuisine_demo.")
    cfg = ms.load_yaml(entry.menu_path)
    s = Session(cfg)

    print(f"\033[1m{cfg.name}\033[0m  \033[2m({len(cfg.items)} items) — "
          f"demo code {entry.code}\033[0m")
    if entry.menu_kind != "their_menu":
        print(f"\033[33m  CUISINE DEMO — this is not {entry.name}'s menu. "
              f"Say so at the counter.\033[0m")
    s.say("Lily", f"Thanks for calling {cfg.name}, what can I get you?")

    if script is not None:
        for raw in Path(script).read_text().splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if not s.handle(line):
                break
    else:
        while True:
            try:
                raw = input("  > ")
            except (EOFError, KeyboardInterrupt):
                break
            if not s.handle(raw):
                break

    print()
    if s.e.lines:
        s.say("Lily", s.e.read_back())
        if s.e.is_submittable():
            s._ticket()
            print("\n\033[2mPractice order — nothing was sent, ordered, "
                  "charged or stored.\033[0m")
        else:
            print(f"  order incomplete — still needs: {s.e.next_question()}")
            return 1
    return 0


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def main(argv: Optional[Sequence[str]] = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("list", help="what is on the demo line")
    p.add_argument("--day", type=int, default=0, help="route day to show")
    p.add_argument("--json", action="store_true")

    p = sub.add_parser("resolve", help="which demo answers this call?")
    p.add_argument("--code", default="")
    p.add_argument("--caller", default="")
    p.add_argument("--did", default="")

    p = sub.add_parser("run", help="take a practice order over one entry")
    p.add_argument("--code", default="")
    p.add_argument("--script", default="")

    args = ap.parse_args(argv)
    line = load_line()

    if args.cmd == "list":
        rows = [e for e in line if not args.day or e.day == args.day]
        if args.json:
            print(json.dumps([e.__dict__ for e in rows], indent=2))
            return 0
        day = f" — day {args.day}" if args.day else ""
        print(f"Demo line: {len(rows)} stop(s){day}")
        for e in rows:
            flag = "" if e.menu_kind == "their_menu" else "  (cuisine demo)"
            print(f"  {e.code}  {e.name:34} {e.tier or '-':3} {e.platform or '-'}"
                  f"{flag}")
        return 0

    if args.cmd == "resolve":
        try:
            e = resolve(line, code=args.code, caller=args.caller, did=args.did,
                        pins=pins_from_env())
        except DemoLineError as exc:
            print(f"no demo: {exc}")
            return 1
        print(f"{e.code}  {e.name}")
        print(f"  menu: {e.menu}  ({e.menu_kind})")
        print(f"  {e.describe()}")
        if e.angle:
            print(f"  angle: {e.angle}")
        return 0

    # run
    try:
        entry = resolve(line, code=args.code, pins=pins_from_env())
    except DemoLineError as exc:
        print(f"no demo: {exc}")
        return 2
    return run_demo(entry, Path(args.script) if args.script else None)


if __name__ == "__main__":
    raise SystemExit(main())
