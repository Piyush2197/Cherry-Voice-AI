"""
The HTTP server both Cherry services run on — one class, not two.

WHY THIS EXISTS
---------------
`server.py` and `voice_gateway.py` each defined their own
`BoundedThreadingHTTPServer`. They started out similar and then diverged, which
is the failure mode duplication always eventually produces:

  * `voice_gateway.py` grew a `BoundedSemaphore` cap on concurrent requests.
  * `server.py` did not.

So the service that takes **every tool call on every live conversation** — the
busiest path in the product — was the one without a ceiling. A burst would spawn
a thread per connection until the process ran out of them, while the quieter
service queued politely. Nobody had to make a bad decision for that to happen;
the two copies simply drifted.

What `CHANGES_2026-09-29.md` recorded as "a semaphore cap on concurrent gateway
requests" was true of the gateway only.

THE NUMBERS, AND WHY THOSE NUMBERS
----------------------------------
* **backlog 128.** The stdlib default is 5. At 5, a burst of 25 simultaneous
  callers produced connection resets in 5 of 8 measured runs; at 128, 0 of 8.
  A dropped connection during a phone order is a lost order.
* **64 concurrent.** Callers queue for a slot rather than getting a thread each,
  so a burst cannot exhaust the process. 64 is comfortably above the 40-call
  burst the rehearsal exercises and cheap in memory, since these handlers are
  I/O-bound and mostly waiting on the database.
* **daemon threads**, so a stuck handler cannot delay shutdown.

Both are overridable per service, because the gateway and the API do not carry
identical load.
"""

from __future__ import annotations

import threading
from http.server import ThreadingHTTPServer

#: Requests queue at the socket instead of being reset.
DEFAULT_BACKLOG = 128
#: Requests in flight before new ones wait for a slot.
DEFAULT_MAX_CONCURRENT = 64
#: Seconds a connection may sit silent while its request is being read. The
#: concurrency cap above is only a defence if a stalled connection gives its
#: slot back: without this, 64 half-open connections hold every slot forever
#: and no real call is served. (Time spent *computing* a reply is not counted.)
DEFAULT_REQUEST_TIMEOUT = 30.0


class BoundedThreadingHTTPServer(ThreadingHTTPServer):
    """A threading HTTP server with a listen backlog and a concurrency cap."""

    daemon_threads = True
    request_queue_size = DEFAULT_BACKLOG

    def __init__(self, server_address, handler,
                 max_concurrent: int = DEFAULT_MAX_CONCURRENT,
                 request_timeout: float = DEFAULT_REQUEST_TIMEOUT) -> None:
        if max_concurrent < 1:
            raise ValueError("max_concurrent must be at least 1")
        self.max_concurrent = max_concurrent
        self.request_timeout = request_timeout
        self._slots = threading.BoundedSemaphore(max_concurrent)
        super().__init__(server_address, handler)

    def process_request_thread(self, request, client_address) -> None:
        with self._slots:
            if self.request_timeout:
                try:
                    request.settimeout(self.request_timeout)
                except OSError:
                    pass
            super().process_request_thread(request, client_address)
