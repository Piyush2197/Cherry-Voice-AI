#!/usr/bin/env python3
"""
Sizing — what the three pilots actually cost in latency, storage and messages.

Everything here is MEASURED, not estimated. The engine is driven through real
menus, the database is filled with real calls and then weighed, and the message
volume is counted rather than assumed. Where a number cannot be measured from
this repo (carrier pricing, Inworld's per-minute rate) it is left as a stated
input rather than invented, because a made-up unit price compounds into a
made-up budget.

    python3 sizing.py

The latency figure is the one that matters most. A voice agent's turn budget is
roughly 300 ms of silence before a caller thinks the line has gone dead, and
that budget is shared between speech recognition, the model, the tool call and
speech synthesis. If the order engine takes a meaningful slice of it, the
engine is the problem. If it takes single-digit milliseconds, every latency
conversation from then on is about the voice stack, and this file is what lets
you say that with a number instead of a shrug.
"""

from __future__ import annotations

import os
import random
import statistics
import tempfile
import time
from pathlib import Path
from typing import Dict, List

import menu_schema as ms
from agent_api import CallSession
from order_engine import OrderEngine
from order_store import OrderStore

MENUS = Path(__file__).parent / "menus"

# What the owners reported. Volumes, not guesses.
PILOTS = [
    # name,              menu stem,               calls/day, weekly sales
    ("Bun N Run",        "bun-n-run-ferndale",      50,  10_000),
    ("Pink Garlic",      "pink-garlic-shelby",      75,  17_500),
    ("Juan Miguel's",    "juan-miguels-clinton",   100,  50_000),
]

# A dinner rush is not uniform. Restaurant phone traffic concentrates hard:
# roughly 60% of a day's calls land in the ~3 busiest hours. Used only for the
# concurrency estimate, and stated so it can be argued with.
RUSH_SHARE = 0.60
RUSH_HOURS = 3.0
AVG_CALL_SECONDS = 90.0

# A Telnyx long code is rated at 0.1 messages/sec = 360/hour, per number.
LONG_CODE_PER_HOUR = 360


def _bar(n: int, width: int = 28, cap: float = 1.0, value: float = 0.0) -> str:
    filled = int(min(value / cap, 1.0) * width) if cap else 0
    return "█" * filled + "·" * (width - filled)


# ---------------------------------------------------------------------------
# 1. Latency — how long the engine takes per caller turn
# ---------------------------------------------------------------------------


def measure_latency(rounds: int = 200) -> Dict[str, Dict[str, float]]:
    """Time a realistic turn on every menu we have.

    A turn is what happens between the caller finishing a sentence and Lily
    starting hers: match the words, apply them, revalidate the whole cart,
    reprice it, and build the reply. That is what `add_item` does, so that is
    what gets timed — not a micro-benchmark of the matcher alone.
    """
    out: Dict[str, Dict[str, float]] = {}
    for path in sorted(MENUS.glob("*.yaml")):
        cfg = ms.load_yaml(path)
        names = [i.name for i in cfg.items if i.available]
        if not names:
            continue
        samples: List[float] = []
        rnd = random.Random(7)
        for _ in range(rounds):
            s = CallSession(cfg)
            # A cart with a few lines already on it — validation and pricing
            # walk every line, so timing an empty cart flatters the engine.
            for _ in range(3):
                s.add_item(rnd.choice(names))
            word = rnd.choice(names)
            t0 = time.perf_counter()
            s.add_item(word)
            samples.append((time.perf_counter() - t0) * 1000.0)
        samples.sort()
        out[path.stem] = {
            "items": len(cfg.items),
            "p50": samples[len(samples) // 2],
            "p95": samples[int(len(samples) * 0.95)],
            "max": samples[-1],
        }
    return out


# ---------------------------------------------------------------------------
# 2. Storage — what one call costs on disk
# ---------------------------------------------------------------------------


def measure_storage(calls: int = 200) -> Dict[str, float]:
    """Run real calls into a real database file and weigh it.

    Everything a call writes is included: the session, every turn, the order
    with its full snapshot, the delivery record, the payment row, the SMS log
    and the audit events. The snapshot is the big one — it is a complete copy
    of the order, which is the price of being able to reprint it years later.
    """
    cfg = ms.load_yaml(MENUS / "pink-garlic-shelby.yaml")
    yaml_text = (MENUS / "pink-garlic-shelby.yaml").read_text()
    names = [i.name for i in cfg.items if i.available]
    rnd = random.Random(11)

    with tempfile.TemporaryDirectory() as td:
        db = os.path.join(td, "sizing.db")
        store = OrderStore.sqlite(db)
        store.upsert_restaurant(cfg.id, cfg.name, cfg.cuisine,
                                tax_rate_bps=cfg.tax_rate_bps,
                                staff_phone="+13135550100", active=True)
        mv = store.publish_menu(cfg.id, yaml_text, item_count=len(cfg.items))
        empty = os.path.getsize(db)

        placed = 0
        for n in range(calls):
            sid = store.start_session(cfg.id, mv, external_id=f"call-{n}",
                                      caller_phone="+13135550123")
            s = CallSession(cfg)
            store.record_turn(sid, "agent", s.greeting()["say"])
            for _ in range(rnd.randint(1, 3)):
                text = rnd.choice(names)
                store.record_turn(sid, "caller", text)
                r = s.add_item(text)
                store.record_turn(sid, "agent", r["say"])
                for _ in range(4):
                    issue = s.pending()
                    if issue is None or not issue.candidates:
                        break
                    opt = cfg.option(issue.candidates[0])
                    ans = opt.name if opt else issue.candidates[0]
                    store.record_turn(sid, "caller", ans)
                    store.record_turn(sid, "agent", s.answer(ans)["say"])
            if not s.e.lines or not s.e.is_submittable():
                store.end_session(sid, "abandoned")
                continue
            snap = s.snapshot()
            oid, code = store.place_order(cfg.id, mv, snap, session_id=sid,
                                          customer_phone="+13135550123")
            store.record_delivery(oid, "manual", "sent", external_ref=f"sms-{n}")
            store.log_sms("+13135550100", "ticket body here", "ticket",
                          order_id=oid, restaurant_id=cfg.id, status="sent")
            store.end_session(sid, "completed")
            placed += 1

        store.conn.commit()
        size = os.path.getsize(db) - empty
        turns = store.conn.execute("SELECT COUNT(*) c FROM turn").fetchone()["c"]

    return {"calls": calls, "orders": placed, "bytes": size,
            "bytes_per_call": size / calls, "turns": turns,
            "turns_per_call": turns / calls}


# ---------------------------------------------------------------------------
# 3. Load — concurrency and message volume
# ---------------------------------------------------------------------------


def erlang_b(channels: int, load: float) -> float:
    """Probability a call arrives and finds every channel busy.

    Average concurrency is the wrong number to provision on: calls do not
    arrive politely spaced, and the average hides the evening where three
    people ring at once. Erlang B answers the question that actually matters —
    how many channels before a caller hears a busy signal — and it is the
    standard telephony model for exactly this.
    """
    inv = 1.0
    for n in range(1, channels + 1):
        inv = 1.0 + inv * n / load
    return 1.0 / inv


def channels_for(load: float, target_blocking: float = 0.01) -> int:
    """Fewest channels that keep blocking under the target."""
    for n in range(1, 60):
        if erlang_b(n, load) < target_blocking:
            return n
    return 60


def load_profile() -> List[Dict[str, float]]:
    rows = []
    for name, stem, calls_day, weekly in PILOTS:
        rush_calls = calls_day * RUSH_SHARE
        calls_per_hour = rush_calls / RUSH_HOURS
        # Little's law: concurrency = arrival rate x average call duration.
        concurrent = calls_per_hour * (AVG_CALL_SECONDS / 3600.0)
        # One ticket per order, plus a pay link on the orders over the
        # threshold. Assume roughly a third clear $30 — the Mexican restaurant
        # averages a much bigger ticket, so it is treated as higher.
        pay_link_share = 0.55 if weekly > 30_000 else 0.30
        msgs_hour = calls_per_hour * (1 + pay_link_share)
        rows.append({
            "name": name, "calls_day": calls_day,
            "calls_per_rush_hour": calls_per_hour,
            "concurrent": concurrent,
            "msgs_per_rush_hour": msgs_hour,
            "long_code_headroom": LONG_CODE_PER_HOUR / msgs_hour if msgs_hour else 0,
            "orders_year": calls_day * 365 * 0.8,   # ~80% of calls become orders
        })
    return rows


# ---------------------------------------------------------------------------


def main() -> int:
    print("=" * 66)
    print("CHERRY — SIZING FOR THE THREE PILOTS")
    print("=" * 66)

    print("\n1. ENGINE LATENCY PER CALLER TURN")
    print("   (match + apply + revalidate + reprice, on a 3-line cart)\n")
    lat = measure_latency()
    worst = max(lat.items(), key=lambda kv: kv[1]["p95"])
    biggest = max(lat.items(), key=lambda kv: kv[1]["items"])
    print(f"   {'menu':<28}{'items':>6}{'p50 ms':>9}{'p95 ms':>9}{'max ms':>9}")
    seen = set()
    for stem in (biggest[0], worst[0], "bun-n-run-ferndale",
                 "pink-garlic-shelby", "juan-miguels-clinton"):
        if stem not in lat or stem in seen:
            continue
        seen.add(stem)
        m = lat[stem]
        print(f"   {stem:<28}{m['items']:>6}{m['p50']:>9.2f}"
              f"{m['p95']:>9.2f}{m['max']:>9.2f}")
    all_p95 = [m["p95"] for m in lat.values()]
    print(f"\n   across all {len(lat)} menus: worst p95 = {max(all_p95):.2f} ms "
          f"({worst[0]}, {lat[worst[0]]['items']} items)")
    print(f"   median menu p95              = {statistics.median(all_p95):.2f} ms")
    budget = 300.0
    print(f"\n   A caller notices silence at roughly {budget:.0f} ms. The engine "
          f"uses {max(all_p95) / budget * 100:.1f}% of that")
    print(f"   at its worst. Latency work belongs in the voice stack, not here.")

    print("\n2. STORAGE PER CALL")
    print("   (session + every turn + order snapshot + delivery + SMS + events)\n")
    st = measure_storage()
    print(f"   {st['calls']} calls, {st['orders']} became orders, "
          f"{st['turns']} turns logged")
    print(f"   {st['turns_per_call']:.1f} turns per call")
    print(f"   {st['bytes_per_call'] / 1024:.1f} KB per call")

    total_calls_day = sum(p[2] for p in PILOTS)
    per_year_mb = st["bytes_per_call"] * total_calls_day * 365 / 1024 / 1024
    print(f"\n   All three pilots: {total_calls_day} calls/day")
    print(f"   -> {per_year_mb:.0f} MB/year of order and transcript data")
    print(f"   -> {per_year_mb * 10 / 1024:.1f} GB/year at 10x the volume "
          f"(30 restaurants)")
    print(f"\n   The smallest managed Postgres on any provider carries this for "
          f"years.")
    print(f"   Provision for backups and point-in-time recovery, not for size.")

    print("\n3. CONCURRENCY AND MESSAGE VOLUME AT THE RUSH")
    print(f"   ({RUSH_SHARE:.0%} of calls in {RUSH_HOURS:.0f} hours, "
          f"{AVG_CALL_SECONDS:.0f}s average call)\n")
    rows = load_profile()
    print(f"   {'restaurant':<16}{'calls/day':>10}{'/rush hr':>10}"
          f"{'concurrent':>12}{'SMS/hr':>9}{'headroom':>10}")
    for r in rows:
        print(f"   {r['name']:<16}{r['calls_day']:>10}"
              f"{r['calls_per_rush_hour']:>10.1f}{r['concurrent']:>12.2f}"
              f"{r['msgs_per_rush_hour']:>9.1f}"
              f"{r['long_code_headroom']:>9.0f}x")
    peak = sum(r["concurrent"] for r in rows)
    print(f"\n   Average simultaneous calls, all three: {peak:.2f}")
    print(f"   Busiest single restaurant:            "
          f"{max(r['concurrent'] for r in rows):.2f}")

    # The average is not what you provision on. Calls arrive at random, so
    # size for the night three people ring at once.
    print(f"\n   Channels needed so fewer than 1 caller in 100 hits a busy "
          f"signal:")
    for r in rows:
        n = channels_for(r["concurrent"])
        print(f"     {r['name']:<16}{n:>3} channel(s)   "
              f"(blocking {erlang_b(n, r['concurrent']) * 100:.3f}%)")
    shared = channels_for(peak)
    print(f"     {'shared pool':<16}{shared:>3} channels     "
          f"(blocking {erlang_b(shared, peak) * 100:.3f}%)")
    print(f"\n   So: {shared} concurrent channels covers all three pilots with "
          f"room to spare.")
    print(f"   Size the voice stack for a handful of channels, not a call "
          f"centre —")
    print(f"   and note the binding constraint is per-restaurant phone lines, "
          f"not us.")

    tightest = min(rows, key=lambda r: r["long_code_headroom"])
    print(f"\n   Long code ceiling is {LONG_CODE_PER_HOUR}/hour per number. The "
          f"tightest pilot")
    print(f"   ({tightest['name']}) uses "
          f"{tightest['msgs_per_rush_hour']:.0f}/hour — "
          f"{tightest['long_code_headroom']:.0f}x headroom.")
    print(f"   One number per restaurant is comfortable. Sharing one number")
    print(f"   across all three would still fit, but removes the headroom that")
    print(f"   absorbs a bad night.")

    print("\n4. WHAT THIS DOES NOT SIZE")
    print("""
   Carrier and vendor pricing changes and is not in this repo, so it is
   not invented here. To finish the budget, multiply the measured volumes
   above by the rates on your own contracts:

     SMS out    ~{msgs:,.0f} messages/year across the three pilots
     Voice      ~{mins:,.0f} call-minutes/year
     Orders     ~{orders:,.0f} orders/year

   Inworld and Telnyx per-minute rates and Telnyx's per-segment SMS price
   are the three numbers to fill in. Note a kitchen ticket is usually more
   than one 160-character segment and is billed per segment, not per
   message — a long Indian order can be three.
""".format(
        msgs=sum(r["msgs_per_rush_hour"] * RUSH_HOURS / RUSH_SHARE * 365
                 for r in rows),
        mins=total_calls_day * 365 * AVG_CALL_SECONDS / 60,
        orders=sum(r["orders_year"] for r in rows)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
