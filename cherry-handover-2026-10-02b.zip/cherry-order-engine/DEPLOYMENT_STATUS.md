# Cherry deployment status

Updated 2026-09-24. “Built” means implemented and covered by automated checks.
“Live” means activated with production credentials and proven by a real call.

| Capability | Built and ready | External activation or proof still required |
|---|---|---|
| Order engine | Matching, ambiguity, quantities, modifiers, exact pricing/tax, validation, immutable final snapshot | Review real-call transcripts and owner-verify location catalogs |
| Voice | Nineteen-tool ordering/reservation/allergen-diet/host HTTP contract, gateway event API, persisted carts, usage endpoint, Telnyx Call Control transfer adapter | Build/configure the provider-specific Inworld event/media path, prove the real Telnyx call-control ID and caller ID survive forwarding, then test live calls and fallback |
| POS delivery | Manual acknowledged ticket, Square bridge, Toast Orders v2 price-check and submission | Merchant OAuth; Toast credentials and item/group GUID mapping; live proof |
| Payments | All seven pilot menus require itemized Square checkout; checkout-handoff-only mode texts the link, ends the Cherry call flow, and suppresses second ticket release in server and reconciliation jobs | Per-merchant Square authorization, real delivered SMS, live payment and paid-order visibility; set the mode in both server and jobs. Manual-only configuration is not traffic-ready |
| Catalog | Export, diff, fail-closed nightly updater, immutable versions, operator review queue | Square OAuth, scheduler and first owner-approved production diff |
| Operations | Private `/ops` UI, fleet/location metrics, transcript review, exactly-once alerts, privacy-safe AI incident triage and third-repeat developer escalation | On-call webhook URL, scheduler and live incident drill |
| Cost control | Measured voice/SMS usage and a 3,000-minute upgrade report | Add per-location tier thresholds for the three chosen plans; schedule reports and implement billing separately |
| Database | SQLite local mode; Postgres pool/schema/bootstrap/backup/restore tooling | Managed host, PITR and executed restore drill |
| Tenant security | Hashed API principals, roles, restaurant scopes, audited controls, no stored provider secrets | Production principals/secret manager, TLS and security review |
| Reliability | Idempotency, concurrency checks, outage drill, SLO release gate and audited menu rollback | Staging/production load run, approved SLOs and rollback drill |
| Complaint support | Immutable evidence packet, transcript, menu hash, delivery/payment/audit trail | Owner decision only if original provider audio will be retained |
| Hours/wait/languages | Per-location schedules, closures, prep/wait controls, language allow-list and protected translation | Enter live schedules and connect the chosen translator if multilingual is enabled |
| Reservations | Request/confirm/decline/cancel flow, per-location policy, opening-hour limits, confirmation code, staff/guest notices and voice tools | Owner supplies policy; developer enables and proves real calls per location |
| Delivery | Address validation and quote-provider interface | Choose and connect a dispatch provider only if sold |
| Restaurant onboarding | Two-day intake SLA, explicit itemized-checkout authorization gate, blocker ownership, deployment/control packet, pipeline portfolio and signed menu-hashed acceptance | Sales must collect complete intake; developer supplies credentials and performs live acceptance |

## Readiness decision

The Square-based pickup-order core is implemented for developer integration.
It is not yet production-live: provider credentials, merchant authorization,
Inworld media/event integration, phone-number routing, managed infrastructure and real-call proof cannot be
completed from a source repository. `TASKS.md` is the authoritative external
activation and conditional product-engineering list. Toast-only itemized
checkout is not implemented, and optional guest memory, catering and delivery
dispatch are not launch-ready features.

Pink Garlic Oak Park and Allen Park have separate menu files and regressions and
are deployable into the database for testing. No manual-only location is
ready for customer traffic under the itemized-review-and-pay requirement.
Owner price signoff remains required before traffic; Square variation ids
are optional for ad-hoc Square checkout but merchant authorization is required.
