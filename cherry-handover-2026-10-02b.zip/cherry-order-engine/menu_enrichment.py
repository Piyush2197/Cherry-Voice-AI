"""
Menu enrichment — the owner's own words about allergens and diet, and the
rules that stop Cherry inventing any.

WHY THIS EXISTS
---------------
A guest asks two questions the menu could always have answered and never did:
"does this have nuts?" and "is this vegan?". Today the only place that fact
lives is a trick: `build_pink_garlic.py` appends `vegan <dish>` to an item's
ALIASES so a caller can *address* the dish that way. That is a search handle,
not an attribute. It cannot answer "what do you have that's vegan?", and it
exists for exactly one restaurant because it was a build script's workaround.

The counter QR agent (see `QR_CHANNEL.md`) names menu enrichment as its hard
prerequisite, and the voice agent needs it for the same reason. This module is
that prerequisite: a controlled vocabulary, schema validation, a coverage
report an owner can work through, and the answer layer.

THE ONE RULE
------------
**A declared tag is a fact the owner wrote down. A missing tag is silence.
Cherry never turns silence into an answer.**

So every answer this module produces is one of two shapes:

    declared  -> "the menu lists it"            (a positive claim, quotable)
    silent    -> "please ask at the counter"    (never a "no")

That is why there is no `is_gluten_free() -> bool` here. Such a function has to
return `False` for an item nobody has reviewed, and `False` reads as "safe".
The absence of a claim is not a claim of absence. `dietary_answer()` and
`allergen_answer()` return sentences, not booleans, so the caller cannot
accidentally treat "unknown" as "no".

Same discipline on contradictions: an item tagged `vegan` that also declares
`milk` is a data-entry error that would have the agent lie to a guest, so
`contradictions()` turns it into a blocking lint ERROR.

VOCABULARY
----------
Canonical ids are stable and snake_case; owners may write the aliases. Unknown
values are REJECTED with a hint rather than stored, because a typo like
`peanuts ` or `nuts` is exactly the case where an agent would otherwise guess.
`nuts` is deliberately ambiguous (tree nuts or peanuts?) and is rejected.
"""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple, Union

from order_engine import RestaurantConfig

# ---------------------------------------------------------------------------
# Vocabulary
# ---------------------------------------------------------------------------

#: The US "Big 9" plus the declarations US owners actually write down. Each
#: entry is canonical id -> (label, aliases). Aliases are singular/plural and
#: the spelling variants owners use; they are deliberately NOT brand or dish
#: names ("tahini" is a food that contains sesame, not a synonym for it).
ALLERGENS: Dict[str, Tuple[str, Tuple[str, ...]]] = {
    "milk":      ("milk", ("dairy", "lactose")),
    "eggs":      ("eggs", ("egg",)),
    "fish":      ("fish", ("fin fish", "finfish")),
    "shellfish": ("shellfish", ("crustacean", "crustaceans", "shrimp", "prawn",
                                "prawns", "crab", "lobster", "crawfish",
                                "crayfish")),
    "tree_nuts": ("tree nuts", ("tree nut", "treenut", "almond", "almonds",
                                "cashew", "cashews", "walnut", "walnuts",
                                "pecan", "pecans", "pistachio", "pistachios",
                                "hazelnut", "hazelnuts", "macadamia")),
    "peanuts":   ("peanuts", ("peanut", "groundnut", "groundnuts")),
    "wheat":     ("wheat", ()),
    "soy":       ("soy", ("soya", "soybean", "soybeans")),
    "sesame":    ("sesame", ("sesame seed", "sesame seeds")),
    "gluten":    ("gluten", ()),
    "sulfites":  ("sulfites", ("sulfite", "sulphite", "sulphites",
                               "sulfur dioxide")),
    "corn":      ("corn", ("maize",)),
    "mustard":   ("mustard", ()),
    "celery":    ("celery", ()),
    "lupin":     ("lupin", ("lupine",)),
    "molluscs":  ("molluscs", ("mollusk", "mollusks", "mollusc", "clam",
                               "clams", "mussel", "mussels", "oyster",
                               "oysters", "scallop", "scallops", "squid",
                               "calamari", "octopus", "snail", "snails")),
}

#: Dietary *suits* — what a guest can eat. Positive claims only.
DIETARY: Dict[str, Tuple[str, Tuple[str, ...]]] = {
    "vegetarian":     ("vegetarian", ("veggie", "veg")),
    "vegan":          ("vegan", ("plant based", "plant-based", "plantbased")),
    "pescatarian":    ("pescatarian", ("pescetarian",)),
    "halal":          ("halal", ()),
    "kosher":         ("kosher", ()),
    "gluten_free":    ("gluten free", ("gluten-free", "glutenfree", "gf",
                                       "no gluten")),
    "dairy_free":     ("dairy free", ("dairy-free", "dairyfree", "no dairy")),
    "nut_free":       ("nut free", ("nut-free", "nutfree", "no nuts")),
    "peanut_free":    ("peanut free", ("peanut-free", "peanutfree",
                                       "no peanuts")),
    "egg_free":       ("egg free", ("egg-free", "eggfree", "no eggs")),
    "soy_free":       ("soy free", ("soy-free", "soyfree", "no soy")),
    "shellfish_free": ("shellfish free", ("shellfish-free", "no shellfish")),
    "sesame_free":    ("sesame free", ("sesame-free", "no sesame")),
}

#: Values owners write that genuinely mean more than one thing. Rejecting them
#: with an explanation is the whole point: "nuts" must not silently become
#: tree_nuts, because a peanut-allergic guest would then be told the wrong fact.
AMBIGUOUS: Dict[str, str] = {
    "nut": "tree_nuts or peanuts — write the one the owner means",
    "nuts": "tree_nuts or peanuts — write the one the owner means",
    "nut free": "nut_free (tree nuts) or peanut_free — write the one meant",
    "seafood": "fish or shellfish — write the one the owner means",
}

#: dietary tag -> allergens that logically cannot co-exist with it. Used by
#: contradictions(); the ordering is canonical so the message is stable.
CONTRADICTIONS: Dict[str, Tuple[str, ...]] = {
    "vegan":          ("milk", "eggs", "fish", "shellfish", "molluscs"),
    "vegetarian":     ("fish", "shellfish", "molluscs"),
    "pescatarian":    ("milk", "eggs"),
    "dairy_free":     ("milk",),
    "gluten_free":    ("gluten", "wheat"),
    "nut_free":       ("tree_nuts", "peanuts"),
    "peanut_free":    ("peanuts",),
    "egg_free":       ("eggs",),
    "soy_free":       ("soy",),
    "shellfish_free": ("shellfish", "molluscs"),
    "sesame_free":    ("sesame",),
}

ASK_AT_COUNTER = "Please ask at the counter."

#: The rule, in one sentence, for anything that has to explain itself.
POSITIVE_ONLY_RULE = (
    "A declared tag is a fact; a missing tag is silence, and silence is "
    "answered with 'ask at the counter', never with 'no'.")


# ---------------------------------------------------------------------------
# Normalisation and validation
# ---------------------------------------------------------------------------


def _key(raw: object) -> str:
    return str(raw).strip().lower().replace("-", " ").replace("_", " ")


def _lookup(raw: object,
            vocab: Dict[str, Tuple[str, Tuple[str, ...]]]
            ) -> Tuple[Optional[str], Optional[str]]:
    """Return (canonical_id, problem). Exactly one of the two is None."""
    k = _key(raw)
    if not k:
        return None, "empty value"
    if k in vocab:
        return k, None
    for cid, (_label, aliases) in vocab.items():
        if k == _key(cid) or any(k == _key(a) for a in aliases):
            return cid, None
    if k in AMBIGUOUS:
        return None, (f"{raw!r} is ambiguous: {AMBIGUOUS[k]}")
    return None, (f"unknown value {raw!r} — use one of "
                  f"{', '.join(sorted(vocab))}")


def normalize_allergen(raw: object) -> Optional[str]:
    """Canonical allergen id, or None if the value is not in the vocabulary."""
    return _lookup(raw, ALLERGENS)[0]


def normalize_dietary(raw: object) -> Optional[str]:
    """Canonical dietary id, or None if the value is not in the vocabulary."""
    return _lookup(raw, DIETARY)[0]


def allergen_label(canonical: str) -> str:
    return ALLERGENS.get(canonical, (canonical, ()))[0]


def dietary_label(canonical: str) -> str:
    return DIETARY.get(canonical, (canonical, ()))[0]


def tag_list(values: object, vocab: Dict[str, Tuple[str, Tuple[str, ...]]],
             kind: str, where: str, problems: List[str]) -> Tuple[str, ...]:
    """Validate a YAML tag list into canonical ids, collecting every problem.

    Duplicates that normalise to the same id are collapsed — an owner writing
    both `soy` and `soya` meant one thing. Anything unrecognised is a problem,
    never a silent pass-through.
    """
    if values is None:
        return ()
    if isinstance(values, str):
        problems.append(f"{where}: expected a list, got a string — write it "
                        f"as [{values!r}]")
        return ()
    if not isinstance(values, (list, tuple)):
        problems.append(f"{where}: expected a list, got "
                        f"{type(values).__name__}")
        return ()
    out: List[str] = []
    for i, v in enumerate(values):
        if not isinstance(v, str):
            problems.append(f"{where}[{i}]: expected text, got {v!r}")
            continue
        cid, problem = _lookup(v, vocab)
        if problem:
            problems.append(f"{where}[{i}]: {kind} {problem}")
            continue
        if cid not in out:
            out.append(cid)
    return tuple(out)


def contradictions(allergens: Iterable[str],
                   dietary: Iterable[str]) -> List[str]:
    """Owner-declared pairs that cannot both be true, as readable sentences.

    This is the check that stops `vegan` + `milk` reaching a guest. It is an
    ERROR, not a warning: the data contradicts itself, so at least one of the
    two claims is wrong and the agent would repeat whichever one it was asked.
    """
    out: List[str] = []
    a = set(allergens)
    for tag in sorted(set(dietary)):
        for bad in CONTRADICTIONS.get(tag, ()):
            if bad in a:
                out.append(f"declared {dietary_label(tag)} but also declares "
                           f"the allergen {allergen_label(bad)} — one of the "
                           f"two is wrong")
    return out


# ---------------------------------------------------------------------------
# Reading enrichment off a config
# ---------------------------------------------------------------------------


def item_allergens(config: RestaurantConfig, item_id: str) -> Tuple[str, ...]:
    """Declared allergens for one item. Empty is silence, not safety."""
    item = config.item(item_id)
    return tuple(item.allergens) if item is not None else ()


def item_dietary(config: RestaurantConfig, item_id: str) -> Tuple[str, ...]:
    """Declared dietary suits for one item. Empty is silence, not safety."""
    item = config.item(item_id)
    return tuple(item.dietary) if item is not None else ()


def items_with_dietary(config: RestaurantConfig, tag: str) -> List[str]:
    """Item ids the owner has declared as `tag`, in menu order.

    A search over declarations. It deliberately does not consider an item
    "probably vegan" because its name or aliases say so.
    """
    cid = normalize_dietary(tag)
    if cid is None:
        return []
    return [i.id for i in config.items if cid in i.dietary]


def items_with_allergen(config: RestaurantConfig, tag: str) -> List[str]:
    """Item ids the owner has declared as containing `tag`, in menu order."""
    cid = normalize_allergen(tag)
    if cid is None:
        return []
    return [i.id for i in config.items if cid in i.allergens]


def declaration_count(config: RestaurantConfig) -> Dict[str, int]:
    """How much of this menu a human has actually written enrichment for."""
    items = list(config.items)
    return {
        "items": len(items),
        "with_description": sum(1 for i in items if i.description.strip()),
        "with_allergens": sum(1 for i in items if i.allergens),
        "with_dietary": sum(1 for i in items if i.dietary),
        "options": len(config.options),
        "options_with_description": sum(
            1 for o in config.options if o.description.strip()),
    }


# ---------------------------------------------------------------------------
# The answer layer — sentences, never booleans
# ---------------------------------------------------------------------------


def _item_or_raise(config: RestaurantConfig, item_id: str):
    item = config.item(item_id)
    if item is None:
        raise KeyError(f"{config.id} has no item {item_id!r}")
    return item


def allergen_answer(config: RestaurantConfig, item_id: str,
                    allergen: str) -> str:
    """What the agent may say when asked whether an item contains something.

    Returns the owner's declared fact when there is one, and the counter
    referral when there is not. It never returns a denial.
    """
    item = _item_or_raise(config, item_id)
    cid = normalize_allergen(allergen)
    if cid is None:
        return (f"I don't have that as a listed allergen for {item.name}. "
                f"{ASK_AT_COUNTER}")
    if cid in item.allergens:
        return (f"Yes — the menu lists {allergen_label(cid)} in {item.name}. "
                f"{ASK_AT_COUNTER}")
    return (f"I can't confirm that {item.name} is free of "
            f"{allergen_label(cid)} — it isn't in the notes I have. "
            f"{ASK_AT_COUNTER}")


def dietary_answer(config: RestaurantConfig, item_id: str, tag: str) -> str:
    """What the agent may say when asked whether an item is vegan/halal/etc."""
    item = _item_or_raise(config, item_id)
    cid = normalize_dietary(tag)
    if cid is None:
        return f"I don't have that for {item.name}. {ASK_AT_COUNTER}"
    if cid in item.dietary:
        return f"Yes — {item.name} is listed as {dietary_label(cid)}."
    return (f"I don't have it written down that {item.name} is "
            f"{dietary_label(cid)}. I won't guess on that. {ASK_AT_COUNTER}")


def describe_item(config: RestaurantConfig, item_id: str) -> str:
    """The owner's description, verbatim. Empty string when there is none."""
    return _item_or_raise(config, item_id).description.strip()


def describe_option(config: RestaurantConfig, option_id: str) -> str:
    """The owner's modifier description, verbatim. Empty when there is none."""
    option = config.option(option_id)
    return option.description.strip() if option is not None else ""


# ---------------------------------------------------------------------------
# Coverage — the owner's worklist
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ItemCoverage:
    item_id: str
    name: str
    has_description: bool
    allergens: Tuple[str, ...]
    dietary: Tuple[str, ...]
    problems: Tuple[str, ...] = ()

    @property
    def missing(self) -> Tuple[str, ...]:
        out = []
        if not self.has_description:
            out.append("description")
        if not self.allergens:
            out.append("allergens")
        if not self.dietary:
            out.append("dietary")
        return tuple(out)

    @property
    def complete(self) -> bool:
        return not self.missing and not self.problems


@dataclass(frozen=True)
class Coverage:
    restaurant_id: str
    restaurant_name: str
    items: Tuple[ItemCoverage, ...]

    @property
    def counts(self) -> Dict[str, int]:
        return {
            "items": len(self.items),
            "complete": sum(1 for i in self.items if i.complete),
            "with_description": sum(1 for i in self.items if i.has_description),
            "with_allergens": sum(1 for i in self.items if i.allergens),
            "with_dietary": sum(1 for i in self.items if i.dietary),
            "contradictions": sum(1 for i in self.items if i.problems),
        }

    @property
    def gaps(self) -> Tuple[ItemCoverage, ...]:
        return tuple(i for i in self.items if not i.complete)

    def as_dict(self) -> Dict[str, object]:
        return {
            "restaurant_id": self.restaurant_id,
            "restaurant_name": self.restaurant_name,
            "counts": self.counts,
            "gaps": [{"item_id": i.item_id, "name": i.name,
                      "missing": list(i.missing),
                      "problems": list(i.problems)} for i in self.gaps],
        }


def coverage(config: RestaurantConfig) -> Coverage:
    """Everything a human still has to write down for this menu."""
    rows = []
    for item in config.items:
        rows.append(ItemCoverage(
            item_id=item.id, name=item.name,
            has_description=bool(item.description.strip()),
            allergens=tuple(item.allergens), dietary=tuple(item.dietary),
            problems=tuple(contradictions(item.allergens, item.dietary))))
    return Coverage(restaurant_id=config.id, restaurant_name=config.name,
                    items=tuple(rows))


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def _load(directory: Union[str, Path]) -> Dict[str, RestaurantConfig]:
    # Imported here so this module stays importable from menu_schema without a
    # cycle (menu_schema imports us for tag validation).
    import menu_schema
    return menu_schema.load_all(directory)


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("report", "check", "vocabulary"))
    parser.add_argument("--menus", default="menus",
                        help="directory of menu YAML files")
    parser.add_argument("--restaurant", default="",
                        help="limit to one restaurant id (report only)")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)

    if args.command == "vocabulary":
        print(json.dumps({
            "allergens": {k: v[0] for k, v in sorted(ALLERGENS.items())},
            "dietary": {k: v[0] for k, v in sorted(DIETARY.items())},
            "ambiguous": AMBIGUOUS,
        }, indent=2))
        return 0

    # `check` fails on a schema problem, so it must load with problems visible.
    import menu_schema
    try:
        configs = _load(args.menus)
    except menu_schema.SchemaError as exc:
        print(f"menu enrichment check FAILED: {exc}")
        return 1

    if args.restaurant:
        want = args.restaurant
        configs = {k: v for k, v in configs.items()
                   if k == want or v.name == want}
        if not configs:
            parser.error(f"no menu matched {want!r} in {args.menus}")

    reports = [coverage(c) for c in configs.values()]

    if args.command == "check":
        bad = [(r.restaurant_id, i) for r in reports for i in r.items
               if i.problems]
        if bad:
            for rid, i in bad:
                for p in i.problems:
                    print(f"ERROR {rid}:{i.item_id}: {p}")
            return 1
        # `check` is about correctness; incompleteness is `report`'s job, and
        # an unenriched menu is the normal state before an owner fills it in.
        print(f"OK — {len(reports)} menu(s), no contradictions. "
              f"Enrichment is a one-way claim: "
              f"{sum(r.counts['with_allergens'] for r in reports)} item(s) "
              f"declare allergens, "
              f"{sum(r.counts['with_dietary'] for r in reports)} declare diet.")
        return 0

    if args.json:
        print(json.dumps([r.as_dict() for r in reports], indent=2))
        return 0

    total = {"items": 0, "complete": 0}
    for r in reports:
        c = r.counts
        total["items"] += c["items"]
        total["complete"] += c["complete"]
        print(f"{r.restaurant_id}  ({r.restaurant_name})")
        print(f"  items {c['items']}  fully enriched {c['complete']}  "
              f"description {c['with_description']}  "
              f"allergens {c['with_allergens']}  "
              f"dietary {c['with_dietary']}")
        for i in r.gaps[:12]:
            what = ", ".join(i.missing) if i.missing else "contradiction"
            flag = "  !! " + "; ".join(i.problems) if i.problems else ""
            print(f"    - {i.item_id}: missing {what}{flag}")
        if len(r.gaps) > 12:
            print(f"    ... and {len(r.gaps) - 12} more")
    print(f"\nTOTAL items {total['items']}, fully enriched "
          f"{total['complete']} ({total['items'] - total['complete']} to go)")
    print(POSITIVE_ONLY_RULE)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
