#!/usr/bin/env bash
# Weekly base backup + push of the WAL archive and backups OFF this server.
# A base backup plus the archived WAL is what makes point-in-time recovery possible.
# Requires OFFSITE (an rclone remote, e.g. "b2:cherry-backups" or "s3:cherry-backups").
set -euo pipefail
cd "$(dirname "$0")"
[ -f /etc/cherry/offsite.env ] && . /etc/cherry/offsite.env
: "${OFFSITE:?set OFFSITE to an rclone remote path}"
stamp=$(date +%F-%H%M)
docker exec cherry-postgres bash -c \
  "pg_basebackup -U \"\$POSTGRES_USER\" -D /backups/base-$stamp -Ft -z -Xs"
# keep 5 local base backups
ls -1dt backups/base-* | tail -n +6 | xargs -r rm -rf
rclone copy ./wal-archive "$OFFSITE/wal-archive"
rclone sync ./backups "$OFFSITE/backups"
echo "base backup $stamp pushed to $OFFSITE"
