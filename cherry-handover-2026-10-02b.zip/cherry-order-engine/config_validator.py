"""
Onboarding-time config linter.

This is the piece that makes onboarding foolproof rather than hopeful. Every
check here corresponds to a failure that would otherwise surface mid-call, on
a live customer, as either dead air or a wrong ticket.

Run this in CI and as the last step of onboarding. A config with any ERROR
must not go live.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from typing import Dict, List, Set

from order_engine import (
    FreeAllowancePolicy,
    Matcher,
    ModifierGroup,
    RestaurantConfig,
    normalize,
)


@dataclass
class LintFinding:
    level: str   # "ERROR" | "WARN"
    where: str
    message: str

    def __str__(self) -> str:
        return f"[{self.level}] {self.where}: {self.message}"


def lint_config(config: RestaurantConfig) -> List[LintFinding]:
    f: List[LintFinding] = []
    err = lambda w, m: f.append(LintFinding("ERROR", w, m))
    warn = lambda w, m: f.append(LintFinding("WARN", w, m))

    option_ids: Set[str] = {o.id for o in config.options}
    group_ids: Set[str] = {g.id for g in config.groups}

    # --- duplicate ids ---------------------------------------------------
    for label, seq in (("item", [i.id for i in config.items]),
                       ("group", [g.id for g in config.groups]),
                       ("option", [o.id for o in config.options])):
        seen, dupes = set(), set()
        for i in seq:
            (dupes if i in seen else seen).add(i)
        for d in sorted(dupes):
            err(f"{label}:{d}", "duplicate id")

    # --- groups ----------------------------------------------------------
    referenced_groups: Set[str] = set()
    revealed_groups: Set[str] = set()
    for it in config.items:
        referenced_groups.update(it.modifier_group_ids)
    for o in config.options:
        revealed_groups.update(o.reveals_group_ids)

    for g in config.groups:
        where = f"group:{g.id}"
        if not g.option_ids:
            err(where, "group has no options")
        for oid in g.option_ids:
            if oid not in option_ids:
                err(where, f"references unknown option '{oid}'")
        if g.min_select > g.max_select:
            err(where, f"min_select {g.min_select} > max_select {g.max_select}")
        if g.max_select < 1:
            err(where, "max_select must be at least 1")
        available = [o for o in config.options_for(g) if o.available]
        if g.min_select > len(available):
            err(where, f"requires {g.min_select} selections but only "
                       f"{len(available)} options are available")
        if g.min_select > 1 and not g.prompt_more.strip():
            warn(where, f"min_select is {g.min_select} but there is no "
                        f"prompt_more — Lily will repeat the opening prompt "
                        f"verbatim for each remaining pick, which sounds "
                        f"broken on a live call")
        if (g.required or g.confirmation_required) and not g.prompt.strip():
            err(where, "required/confirmed group has no prompt — Lily would have "
                       "nothing to say when it is unsatisfied")
        if g.required and g.default_option_ids and g.max_select <= 1:
            warn(where, "required single-select group has a default; confirm "
                        "the restaurant really wants a default rather than "
                        "always asking")
        for did in g.default_option_ids:
            if did not in g.option_ids:
                err(where, f"default '{did}' is not one of the group's options")
        if len(g.default_option_ids) > g.max_select:
            err(where, f"{len(g.default_option_ids)} defaults exceed "
                       f"max_select {g.max_select}")
        if g.free_select > g.max_select:
            warn(where, f"free_select {g.free_select} exceeds max_select "
                        f"{g.max_select}; the allowance can never be spent")
        if g.free_select > 0 and g.free_policy is FreeAllowancePolicy.LEAST_EXPENSIVE:
            warn(where, "free allowance is spent on the CHEAPEST options, which "
                        "maximises the customer's bill — confirm this is "
                        "intentional")
        if g.placement_enabled and g.max_select <= 1:
            warn(where, "placement enabled on a single-select group; half/half "
                        "normally only makes sense for multi-select toppings")
        if g.informational and g.required:
            err(where, "informational group cannot be required")
        if g.informational and g.confirmation_required:
            err(where, "informational group cannot require confirmation")
        if g.id not in referenced_groups and g.id not in revealed_groups:
            warn(where, "group is not attached to any item and never revealed "
                        "— dead config")
        if g.reveal_only and g.id not in revealed_groups:
            err(where, "reveal_only group is never revealed by any option — "
                       "it can never be satisfied, so any required selection "
                       "inside it is unreachable")

    # --- options ---------------------------------------------------------
    for o in config.options:
        where = f"option:{o.id}"
        if o.max_quantity < 1:
            err(where, "max_quantity must be at least 1")
        if o.price_cents < 0 and not o.price_by_size:
            warn(where, f"negative price {o.price_cents}c — intentional only "
                        f"if this is a discount/substitution credit")
        for gid in o.reveals_group_ids:
            if gid not in group_ids:
                err(where, f"reveals unknown group '{gid}'")
        if o.price_by_size and o.price_cents:
            warn(where, "has both price_cents and price_by_size; price_by_size "
                        "wins for sized items and price_cents is used only for "
                        "unsized ones")

    # --- items -----------------------------------------------------------
    for it in config.items:
        where = f"item:{it.id}"
        if it.has_sizes:
            if it.base_price_cents:
                warn(where, "base_price_cents is ignored when sizes exist")
            if not any(s.available for s in it.sizes):
                err(where, "no available sizes")
            size_ids = [s.id for s in it.sizes]
            if len(set(size_ids)) != len(size_ids):
                err(where, "duplicate size ids")
        else:
            if it.base_price_cents <= 0:
                err(where, "unsized item has no price")
        for gid in it.modifier_group_ids:
            if gid not in group_ids:
                err(where, f"references unknown group '{gid}'")
                continue
            g = config.group(gid)
            if g is not None and g.reveal_only:
                warn(where, f"attaches reveal_only group '{gid}' directly; it "
                            f"will be inert until an option reveals it")

        # Size-scoped option prices must cover every size the item sells.
        for gid in it.modifier_group_ids:
            g = config.group(gid)
            if g is None:
                continue
            for o in config.options_for(g):
                if not o.price_by_size or not it.has_sizes:
                    continue
                missing = [s.id for s in it.sizes if s.id not in o.price_by_size]
                if missing and len(missing) == len(it.sizes):
                    err(where, f"option '{o.id}' is size-priced but covers none "
                               f"of this item's sizes")
                elif missing:
                    warn(where, f"option '{o.id}' has no price for size(s) "
                                f"{missing}; it will be refused at those sizes")

    # --- ambiguity: the config-level cause of mid-call guessing ----------
    name_to_items: Dict[str, List[str]] = defaultdict(list)
    for it in config.items:
        for n in (it.name,) + tuple(it.aliases):
            name_to_items[normalize(n)].append(it.id)
    for n, ids in sorted(name_to_items.items()):
        if len(set(ids)) > 1:
            warn(f"alias:'{n}'", f"resolves to multiple items {sorted(set(ids))} "
                                 f"— the engine will ask which one every time. "
                                 f"That is correct when a dish genuinely exists "
                                 f"in several proteins ('saag'); it is a bug if "
                                 f"one of them was meant to win.")

    # Near-collisions are the real-world version of the above: two items whose
    # names differ by one word are exactly the Double Cheeseburger / Double
    # Hamburger trap.
    m = Matcher(config)
    items = list(config.items)
    for a, b in ((items[i], items[j])
                 for i in range(len(items)) for j in range(i + 1, len(items))):
        score = m._score(normalize(a.name).split(), normalize(b.name))
        if score >= 0.85:
            warn(f"item:{a.id}", f"name is very close to '{b.name}' "
                                 f"(score {score:.2f}) — give at least one of "
                                 f"them a distinguishing alias")

    return f


def assert_config_ok(config: RestaurantConfig) -> List[LintFinding]:
    """Raise on any ERROR. Use this as the onboarding gate."""
    findings = lint_config(config)
    errors = [x for x in findings if x.level == "ERROR"]
    if errors:
        raise ValueError(
            f"{config.name} config has {len(errors)} blocking error(s):\n"
            + "\n".join(str(e) for e in errors))
    return findings
