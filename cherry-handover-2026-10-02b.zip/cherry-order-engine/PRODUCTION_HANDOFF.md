# Cherry production handoff

The current launch runbook is `DEVELOPER_HANDOFF.md`. Use it for the forwarded public number, dedicated Telnyx DID, Inworld voice, itemized Square checkout, and checkout-handoff-only flow. `VOICE_FORWARDING.md` has the gateway event contract. This page remains so older links point to the current instructions.

The former paid-webhook kitchen-release sequence is not the chosen launch mode. Set `CHERRY_CHECKOUT_HANDOFF_ONLY=1` in every Cherry server and scheduled job environment, and start the server with `--checkout-handoff-only`. The Square webhook can record status, but must not submit a second POS order or kitchen ticket. A live paid Square order must be visible to restaurant staff.

## Additional production operations

- Store API principals, database URLs, merchant tokens, Telnyx credentials, Inworld credentials, webhook keys, and alert destinations in the selected secret manager. Keep the Cherry API private and expose provider callbacks through TLS.
- Enable Postgres point-in-time recovery and run a guarded restore drill into a separate disposable database. The command uses `--archive`, not `--source`:

```bash
python3 production_db.py bootstrap
python3 production_db.py verify
python3 production_db.py backup --out /approved/backup/cherry.dump
CHERRY_RESTORE_DATABASE_URL='<separate restore database URL>' \
  python3 production_db.py restore-drill \
  --archive /approved/backup/cherry.dump --confirm-target
python3 release_guard.py load-test --url https://staging.example --key "$CHERRY_API_KEY"
```

- Schedule nightly catalog sync, daily Square reconciliation, alerts, transcript review, backups, and merchant OAuth refresh as described in the relevant CLI help and `TASKS.md`.
- Generate each new restaurant's packet with `ONBOARDING.md` and certify only after the owner signs the live acceptance evidence. Regenerate unlaunched packets created before the checkout-handoff acceptance checks were updated.
- Keep the direct human fallback number distinct from the forwarded public number and all active Telnyx DIDs. Prove requested and failure-triggered transfers before public forwarding is enabled.

The repository and local tests do not prove provider activation. No location is certified live until the real call, delivered SMS, Square payment/order visibility, fallback, and restore drill have been observed.
