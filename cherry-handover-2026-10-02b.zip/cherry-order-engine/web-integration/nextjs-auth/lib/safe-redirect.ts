/**
 * Where to go after signing in. Only a path on THIS site is allowed: a
 * `?redirect=https://evil.example` (or `//evil.example`, or `/\evil.example`,
 * which browsers read as a host) must not turn the sign-in page into a
 * redirector. No server-only imports: the login page (a client component) uses it.
 */
export function safeRedirect(target: string | null | undefined, fallback = '/dashboard'): string {
  if (!target || typeof target !== 'string') return fallback
  if (!target.startsWith('/')) return fallback
  if (target.startsWith('//') || target.startsWith('/\\')) return fallback
  if (/[\u0000-\u001f\u007f]/.test(target)) return fallback
  return target
}
