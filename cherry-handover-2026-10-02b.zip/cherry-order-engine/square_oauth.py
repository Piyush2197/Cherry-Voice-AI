"""Square OAuth for Cherry: merchant authorization, storage and renewal.

Flow, once per restaurant:
  1. ``authorize-url`` prints a signed link. The restaurant owner opens it and
     approves Cherry in Square.
  2. Square redirects to ``/v1/oauth/square/callback``; the server calls
     ``complete_authorization``, which checks the signed ``state``, exchanges
     the code, finds the merchant's location and writes the tokens to the vault.
  3. ``refresh`` runs daily and renews any token that expires within a week.

Tokens never enter Cherry's database or logs.  They live in the vault
(``vault.py``: owner-only files by default, or a managed secret manager).

    python3 square_oauth.py authorize-url --restaurant bun-n-run-ferndale
    python3 square_oauth.py status  --restaurant bun-n-run-ferndale ...
    python3 square_oauth.py refresh --restaurant bun-n-run-ferndale ...
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import hmac
import json
import os
import secrets
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Dict, Iterable, List, Optional, Protocol

from square_bridge import SQUARE_VERSION
from vault import default_vault, restaurant_key

# Minimum permissions for itemized checkout links, order visibility, payment
# reconciliation and the nightly catalog check. Confirm against the Square
# sandbox before the first live merchant.
SQUARE_SCOPES = ("ORDERS_READ", "ORDERS_WRITE", "PAYMENTS_READ", "PAYMENTS_WRITE",
                 "ITEMS_READ", "MERCHANT_PROFILE_READ")
STATE_TTL_SECONDS = 60 * 60 * 24 * 2     # an owner may take a day or two to click
REFRESH_WITHIN = timedelta(days=7)       # Square access tokens last 30 days


class SecretVault(Protocol):
    def get(self, name: str) -> str: ...
    def put(self, name: str, value: str) -> None: ...


class OAuthRefreshError(RuntimeError):
    pass


@dataclass(frozen=True)
class SquareMerchant:
    restaurant_id: str
    refresh_token_secret: str
    access_token_secret: str
    expires_at_secret: str


class SquareOAuthClient:
    """Small client for Square's ObtainToken refresh-token grant."""

    def __init__(self, client_id: str, client_secret: str, *, sandbox: bool = False,
                 opener=None, timeout: float = 15.0):
        if not client_id or not client_secret:
            raise ValueError("Square OAuth client id and secret are required")
        self.client_id, self.client_secret = client_id, client_secret
        host = "connect.squareupsandbox.com" if sandbox else "connect.squareup.com"
        self.url = f"https://{host}/oauth2/token"
        self.opener, self.timeout = opener or urllib.request.urlopen, timeout

    def refresh(self, refresh_token: str) -> Dict[str, str]:
        if not refresh_token:
            raise OAuthRefreshError("merchant refresh token is empty")
        body = {"client_id": self.client_id,
                "client_secret": self.client_secret,
                "grant_type": "refresh_token",
                "refresh_token": refresh_token}
        request = urllib.request.Request(
            self.url, data=json.dumps(body).encode(), method="POST",
            headers={"Content-Type": "application/json",
                     "Square-Version": SQUARE_VERSION})
        try:
            with self.opener(request, timeout=self.timeout) as response:
                result = json.loads(response.read() or b"{}")
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode(errors="replace") if hasattr(exc, "read") else ""
            raise OAuthRefreshError(f"Square OAuth returned HTTP {exc.code}: {detail[:500]}") from exc
        except (urllib.error.URLError, TimeoutError) as exc:
            raise OAuthRefreshError(f"Square OAuth unavailable: {exc}") from exc
        if not result.get("access_token") or not result.get("expires_at"):
            raise OAuthRefreshError("Square OAuth response lacks access_token or expires_at")
        return result


def refresh_merchants(client: SquareOAuthClient, vault: SecretVault,
                      merchants: Iterable[SquareMerchant], *, store=None) -> dict:
    """Refresh merchants and atomically publish each complete token set.

    Access tokens are written only after a valid response.  PKCE deployments
    receive a rotated refresh token, while code-flow deployments safely keep
    the old one when Square returns the same token.
    """
    counts = {"checked": 0, "refreshed": 0, "failed": 0}
    for merchant in merchants:
        counts["checked"] += 1
        try:
            old_refresh = vault.get(merchant.refresh_token_secret)
            token = client.refresh(old_refresh)
            new_refresh = str(token.get("refresh_token") or old_refresh)
            vault.put(merchant.access_token_secret, str(token["access_token"]))
            vault.put(merchant.refresh_token_secret, new_refresh)
            vault.put(merchant.expires_at_secret, str(token["expires_at"]))
        except Exception as exc:
            counts["failed"] += 1
            if store is not None:
                store.log_event("square.oauth_refresh_failed",
                                restaurant_id=merchant.restaurant_id,
                                detail={"error": str(exc)})
            continue
        counts["refreshed"] += 1
        if store is not None:
            store.log_event("square.oauth_refreshed",
                            restaurant_id=merchant.restaurant_id,
                            detail={"expires_at": token["expires_at"],
                                    "refreshed_at": datetime.now(timezone.utc).isoformat(timespec="seconds")})
    return counts


# ---------------------------------------------------------------------------
# Initial merchant authorization
# ---------------------------------------------------------------------------

def _host(sandbox: bool) -> str:
    return "connect.squareupsandbox.com" if sandbox else "connect.squareup.com"


def secret_names(restaurant_id: str) -> Dict[str, str]:
    key = restaurant_key(restaurant_id)
    return {"access": f"SQUARE_TOKEN_{key}", "refresh": f"SQUARE_REFRESH_{key}",
            "expires": f"SQUARE_EXPIRES_{key}", "location": f"SQUARE_LOCATION_{key}",
            "merchant": f"SQUARE_MERCHANT_{key}"}


def merchant_for(restaurant_id: str) -> SquareMerchant:
    names = secret_names(restaurant_id)
    return SquareMerchant(restaurant_id, names["refresh"], names["access"],
                          names["expires"])


def _b64(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode().rstrip("=")


def sign_state(secret: str, restaurant_id: str, *, now: Optional[float] = None,
               rebind: bool = False) -> str:
    """Tamper-proof, expiring ``state`` that also names the restaurant, so the
    callback needs no server-side session and cannot be pointed at another
    restaurant."""
    if len(secret) < 16:
        raise ValueError("state secret must be at least 16 characters")
    payload = _b64(json.dumps({"r": restaurant_id,
                               "exp": int((now or time.time()) + STATE_TTL_SECONDS),
                               "n": secrets.token_hex(12),
                               "rb": bool(rebind)}).encode())
    sig = _b64(hmac.new(secret.encode(), payload.encode(), hashlib.sha256).digest())
    return f"{payload}.{sig}"


def verify_state(secret: str, state: str, *, now: Optional[float] = None) -> str:
    """Return the restaurant id, or raise OAuthRefreshError."""
    return str(_state_body(secret, state, now=now)["r"])


def _state_body(secret: str, state: str, *, now: Optional[float] = None) -> dict:
    try:
        payload, sig = state.split(".", 1)
        good = _b64(hmac.new(secret.encode(), payload.encode(), hashlib.sha256).digest())
        if not hmac.compare_digest(sig, good):
            raise ValueError("bad signature")
        body = json.loads(base64.urlsafe_b64decode(payload + "=" * (-len(payload) % 4)))
        if body["exp"] < (now or time.time()):
            raise ValueError("expired")
        body["r"]
        return body
    except Exception as exc:
        raise OAuthRefreshError(f"invalid or expired authorization link ({exc})") from exc


def authorize_url(client_id: str, secret: str, restaurant_id: str, *,
                  sandbox: bool = False, rebind: bool = False) -> str:
    query = urllib.parse.urlencode({
        "client_id": client_id, "scope": " ".join(SQUARE_SCOPES),
        "session": "false",
        "state": sign_state(secret, restaurant_id, rebind=rebind)},
        quote_via=urllib.parse.quote)
    return f"https://{_host(sandbox)}/oauth2/authorize?{query}"


def _get_json(url: str, token: str, opener, timeout: float = 15.0) -> dict:
    request = urllib.request.Request(url, headers={
        "Authorization": f"Bearer {token}", "Square-Version": SQUARE_VERSION})
    try:
        with (opener or urllib.request.urlopen)(request, timeout=timeout) as response:
            return json.loads(response.read() or b"{}")
    except urllib.error.HTTPError as exc:
        raise OAuthRefreshError(f"Square returned HTTP {exc.code}") from exc
    except (urllib.error.URLError, TimeoutError) as exc:
        raise OAuthRefreshError(f"Square unavailable: {exc}") from exc


def active_locations(access_token: str, *, sandbox: bool = False, opener=None) -> List[dict]:
    result = _get_json(f"https://{_host(sandbox)}/v2/locations", access_token, opener)
    return [loc for loc in result.get("locations", [])
            if loc.get("status", "ACTIVE") == "ACTIVE"]


def _exchange_code(self: SquareOAuthClient, code: str) -> Dict[str, str]:
    body = {"client_id": self.client_id, "client_secret": self.client_secret,
            "grant_type": "authorization_code", "code": code}
    request = urllib.request.Request(
        self.url, data=json.dumps(body).encode(), method="POST",
        headers={"Content-Type": "application/json", "Square-Version": SQUARE_VERSION})
    try:
        with self.opener(request, timeout=self.timeout) as response:
            result = json.loads(response.read() or b"{}")
    except urllib.error.HTTPError as exc:
        raise OAuthRefreshError(f"Square OAuth returned HTTP {exc.code}") from exc
    except (urllib.error.URLError, TimeoutError) as exc:
        raise OAuthRefreshError(f"Square OAuth unavailable: {exc}") from exc
    for field in ("access_token", "refresh_token", "expires_at", "merchant_id"):
        if not result.get(field):
            raise OAuthRefreshError(f"Square OAuth response lacks {field}")
    return result


SquareOAuthClient.exchange_code = _exchange_code


def complete_authorization(client: SquareOAuthClient, vault, state_secret: str, *,
                           state: str, code: str, sandbox: bool = False,
                           opener=None, store=None, known_restaurants=None) -> dict:
    """Finish the owner's approval. Returns a result dict; never the tokens."""
    body = _state_body(state_secret, state)
    restaurant_id = str(body["r"])
    if known_restaurants is not None and restaurant_id not in known_restaurants:
        raise OAuthRefreshError("authorization link names an unknown restaurant")
    # A link is a bearer credential: whoever completes it decides which Square
    # account receives this restaurant's checkout money. Honour it ONCE.
    claim = None
    if store is not None and body.get("n"):
        claim = str(body["n"])
        if not store.claim_webhook("oauth-state", claim, restaurant_id):
            raise OAuthRefreshError("this authorization link was already used; "
                                    "ask for a new one")
    try:
        return _finish_authorization(client, vault, restaurant_id, code,
                                     sandbox=sandbox, opener=opener, store=store,
                                     rebind=bool(body.get("rb")))
    except Exception:
        if claim is not None:           # nothing was changed; the link may be retried
            store.release_webhook("oauth-state", claim)
        raise


def _finish_authorization(client, vault, restaurant_id: str, code: str, *,
                          sandbox: bool, opener, store, rebind: bool) -> dict:
    token = client.exchange_code(code)
    names = secret_names(restaurant_id)
    try:
        bound = vault.get(names["merchant"])
    except KeyError:
        bound = ""
    if bound and bound != token["merchant_id"] and not rebind:
        # Re-authorizing the SAME merchant is routine. A different one would
        # move this restaurant's money to another account: only allowed when
        # the link was issued with --rebind by someone who meant it.
        raise OAuthRefreshError(
            "this restaurant is already connected to a different Square "
            "account; issue the link with `authorize-url --rebind` if the "
            "change is intended")
    locations = active_locations(token["access_token"], sandbox=sandbox, opener=opener)
    # Write the tokens first: the merchant already approved, and a lost
    # authorization forces them to repeat it.
    vault.put(names["refresh"], token["refresh_token"])
    vault.put(names["access"], token["access_token"])
    vault.put(names["expires"], token["expires_at"])
    vault.put(names["merchant"], token["merchant_id"])
    location_id = ""
    if len(locations) == 1:
        location_id = locations[0]["id"]
        vault.put(names["location"], location_id)
    result = {"restaurant_id": restaurant_id, "merchant_id": token["merchant_id"],
              "expires_at": token["expires_at"],
              "location_id": location_id or None,
              "needs_location": [{"id": loc["id"], "name": loc.get("name", "")}
                                 for loc in locations] if len(locations) != 1 else []}
    if store is not None:
        store.log_event("square.oauth_authorized", restaurant_id=restaurant_id,
                        detail={k: v for k, v in result.items()
                                if k != "restaurant_id"})
    return result


def set_location(vault, restaurant_id: str, location_id: str) -> None:
    if not location_id or not location_id.replace("-", "").isalnum():
        raise ValueError("invalid Square location id")
    vault.put(secret_names(restaurant_id)["location"], location_id)


# ---------------------------------------------------------------------------
# Scheduled renewal and status
# ---------------------------------------------------------------------------

def _parse_expiry(value: str) -> Optional[datetime]:
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        return None


def token_status(vault, restaurant_id: str, *, now: Optional[datetime] = None) -> dict:
    now = now or datetime.now(timezone.utc)
    names = secret_names(restaurant_id)
    have = {}
    for label, name in names.items():
        try:
            have[label] = vault.get(name)
        except KeyError:
            have[label] = ""
    expires = _parse_expiry(have["expires"]) if have["expires"] else None
    if not have["access"] or not have["refresh"]:
        state = "not_authorized"
    elif expires is None:
        state = "unknown_expiry"
    elif expires <= now:
        state = "expired"
    elif expires - now <= REFRESH_WITHIN:
        state = "due"
    else:
        state = "ok"
    return {"restaurant_id": restaurant_id, "state": state,
            "expires_at": have["expires"] or None,
            "days_left": round((expires - now).total_seconds() / 86400, 1) if expires else None,
            "has_location": bool(have["location"])}


def refresh_due(client: SquareOAuthClient, vault, restaurant_ids: Iterable[str], *,
                store=None, now: Optional[datetime] = None, force: bool = False) -> dict:
    """Refresh only tokens that are due, expired or of unknown age. A token that
    was never authorized is reported, not silently skipped."""
    due, statuses = [], []
    for rid in restaurant_ids:
        status = token_status(vault, rid, now=now)
        statuses.append(status)
        if force or status["state"] in ("due", "expired", "unknown_expiry"):
            due.append(merchant_for(rid))
    counts = refresh_merchants(client, vault, due, store=store)
    counts["not_authorized"] = [s["restaurant_id"] for s in statuses
                                if s["state"] == "not_authorized"]
    counts["skipped_ok"] = len(statuses) - len(due) - len(counts["not_authorized"])
    return counts


def _client_from_env(sandbox: bool) -> SquareOAuthClient:
    return SquareOAuthClient(os.environ.get("SQUARE_OAUTH_CLIENT_ID", ""),
                             os.environ.get("SQUARE_OAUTH_CLIENT_SECRET", ""),
                             sandbox=sandbox)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--sandbox", action="store_true",
                        default=os.environ.get("CHERRY_SQUARE_SANDBOX") == "1")
    sub = parser.add_subparsers(dest="command", required=True)
    link = sub.add_parser("authorize-url", help="print the signed link to send the owner")
    link.add_argument("--restaurant", required=True)
    link.add_argument("--rebind", action="store_true",
                      help="allow the link to replace the connected Square "
                           "account with a different one")
    for name in ("status", "refresh"):
        p = sub.add_parser(name)
        p.add_argument("--restaurant", action="append", required=True)
        if name == "refresh":
            p.add_argument("--force", action="store_true")
    loc = sub.add_parser("set-location", help="choose the Square location when an account has several")
    loc.add_argument("--restaurant", required=True)
    loc.add_argument("--location", required=True)
    args = parser.parse_args(argv)

    vault = default_vault()
    if vault is None:
        print(json.dumps({"ok": False, "error": "CHERRY_SECRET_DIR is not set"}))
        return 1
    try:
        if args.command == "authorize-url":
            client = _client_from_env(args.sandbox)
            secret = os.environ.get("CHERRY_OAUTH_STATE_SECRET", "")
            print(authorize_url(client.client_id, secret, args.restaurant,
                                sandbox=args.sandbox, rebind=args.rebind))
            return 0
        if args.command == "set-location":
            set_location(vault, args.restaurant, args.location)
            print(json.dumps({"ok": True}))
            return 0
        if args.command == "status":
            statuses = [token_status(vault, r) for r in args.restaurant]
            print(json.dumps(statuses, indent=2))
            return 0 if all(s["state"] == "ok" for s in statuses) else 3
        # Pass the store so the refresh is RECORDED: the operations monitor's
        # "token refresh is failing" page is driven by these events, and with
        # no store the cron job refreshed (or failed) invisibly.
        store = None
        dsn = os.environ.get("CHERRY_DATABASE_URL", "")
        if dsn:
            from order_store import OrderStore
            store = OrderStore.open(dsn)
        result = refresh_due(_client_from_env(args.sandbox), vault, args.restaurant,
                             store=store, force=args.force)
        print(json.dumps(result, indent=2))
        # Non-zero exit makes the scheduler alert: a failed or missing
        # authorization must never be a silent success.
        return 0 if not result["failed"] and not result["not_authorized"] else 3
    except Exception as exc:                       # noqa: BLE001
        print(json.dumps({"ok": False, "error": str(exc)}))
        return 1


if __name__ == "__main__":
    sys.exit(main())
