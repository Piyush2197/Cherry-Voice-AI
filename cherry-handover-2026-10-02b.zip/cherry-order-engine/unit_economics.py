#!/usr/bin/env python3
"""
Unit economics — what a call costs, and what each lever actually saves.

WHY THIS FILE REFUSES TO QUOTE PRICES
-------------------------------------
Vendor rates change and are negotiated. A number typed in here would look
authoritative and be wrong, and a wrong unit price compounds into a wrong
business model. So every rate is an INPUT at the top, defaulting to 0.0, and
the model tells you which ones it needs. Fill them from your own contracts or
the vendor pricing pages.

What IS measured here, from the real engine and the real menus:

  * how many characters Lily speaks per call
  * what fraction of those characters are the SAME on every call
    (that fraction is the ceiling on what pre-recording can save)
  * how many SMS segments an order actually sends
  * calls, minutes and orders per year at the pilot volumes

Those are the quantities. Multiply by your rates to get dollars.

THE LEAN POINT
--------------
The biggest cost lever is not a discount tier. It is that a voice agent is
billed per minute, so ANYTHING that shortens the call reduces every per-minute
line at once — telephony, STT, LLM and TTS. A 15-second saving on a 90-second
call is a 17% cut across the whole per-minute stack. Pre-recording helps
latency and the TTS line; shortening the conversation helps everything.
"""

from __future__ import annotations

import re
import statistics
from collections import Counter
from pathlib import Path
from typing import Dict, List, Tuple

import menu_schema as ms
from agent_api import CallSession

MENUS = Path(__file__).parent / "menus"

# --------------------------------------------------------------------------
# YOUR RATES — fill these in. Everything is 0.0 so nothing is invented.
# --------------------------------------------------------------------------

RATES = {
    # Telephony, per minute, inbound
    "telephony_per_min": 0.0,
    # Speech-to-text, per minute
    "stt_per_min": 0.0,
    # Text-to-speech, per 1,000 characters
    "tts_per_1k_chars": 0.0,
    # LLM, per 1,000 tokens (blended in+out), or per minute if bundled
    "llm_per_1k_tokens": 0.0,
    "llm_tokens_per_min": 0.0,
    # A bundled voice-agent rate, if your vendor sells one. If this is set,
    # it REPLACES stt + tts + llm + orchestration.
    "bundled_voice_per_min": 0.0,
    # SMS, per 160-character segment
    "sms_per_segment": 0.0,
    # Fixed monthly: phone numbers, 10DLC campaign, database, hosting
    "monthly_fixed": 0.0,
    # What you charge a restaurant per month
    "price_per_restaurant_month": 0.0,
}

# --------------------------------------------------------------------------
# Volumes — measured, not assumed
# --------------------------------------------------------------------------

PILOTS = [("Bun N Run", 50), ("Pink Garlic", 75), ("Juan Miguel's", 100)]
AVG_CALL_SECONDS = 90.0
ORDER_CONVERSION = 0.80
SMS_SEGMENT_CHARS = 160


def measure_speech(menu_stem: str, orders: int = 60) -> Dict[str, float]:
    """How many characters Lily speaks in a typical call, and how many of
    them repeat.

    The split is the whole argument for pre-recording:

      FIXED     — identical on every call at this restaurant (greeting,
                  "Got it —", group prompts, the closing). Record once.
      SEMIFIXED — one of a known finite set (item names, option names).
                  Record one clip per item at deploy time.
      VARIABLE  — money and order codes. Must be synthesised live.
    """
    import random
    cfg = ms.load_yaml(MENUS / f"{menu_stem}.yaml")
    names = [i.name for i in cfg.items if i.available]
    rnd = random.Random(5)

    fixed = semifixed = variable = 0
    per_call: List[int] = []

    item_names = {i.name for i in cfg.items}
    option_names = {o.name for o in cfg.options}

    for _ in range(orders):
        s = CallSession(cfg)
        said: List[str] = [s.greeting()["say"]]
        for _ in range(rnd.randint(1, 3)):
            r = s.add_item(rnd.choice(names))
            said.append(r["say"])
            for _ in range(5):
                issue = s.pending()
                if issue is None or not issue.candidates:
                    break
                opt = cfg.option(issue.candidates[0])
                said.append(s.answer(opt.name if opt else issue.candidates[0])["say"])
        if s.e.lines:
            said.append(s.read_back()["say"])

        call_chars = 0
        for sentence in said:
            call_chars += len(sentence)
            # Money and digits can never be cached.
            money_chars = sum(len(m) for m in re.findall(r"\$[\d,]+\.\d\d", sentence))
            variable += money_chars
            rest = re.sub(r"\$[\d,]+\.\d\d", "", sentence)
            # Item and option names are semifixed: a finite per-restaurant set.
            named = 0
            for n in item_names | option_names:
                if n and n in rest:
                    named += len(n)
                    rest = rest.replace(n, "", 1)
            semifixed += named
            fixed += len(rest)
        per_call.append(call_chars)

    total = fixed + semifixed + variable
    return {
        "chars_per_call": statistics.mean(per_call),
        "fixed_pct": fixed / total * 100 if total else 0,
        "semifixed_pct": semifixed / total * 100 if total else 0,
        "variable_pct": variable / total * 100 if total else 0,
        "cacheable_pct": (fixed + semifixed) / total * 100 if total else 0,
        "items": len(cfg.items),
        "clips_needed": len(item_names) + len(option_names) + 25,
    }


def measure_sms(menu_stem: str = "pink-garlic-shelby") -> Dict[str, float]:
    """SMS is billed per 160-character segment, not per message. A long
    ticket is three segments and costs three times what people assume."""
    import random
    from order_engine import OrderEngine
    from sinks import format_ticket

    cfg = ms.load_yaml(MENUS / f"{menu_stem}.yaml")
    names = [i.id for i in cfg.items if i.available]
    rnd = random.Random(9)
    segs: List[int] = []
    for _ in range(60):
        e = OrderEngine(cfg)
        for _ in range(rnd.randint(1, 3)):
            line = e.add_line(rnd.choice(names))
            for gid in e.active_group_ids(line):
                g = cfg.group(gid)
                if g and g.required and g.option_ids:
                    e.apply_option(line.line_id, gid, g.option_ids[0])
        if not e.lines:
            continue
        ticket = format_ticket(e.to_normalized_order(), "1234",
                               restaurant_name=cfg.name,
                               customer_phone="+13135550123")
        segs.append(-(-len(ticket) // SMS_SEGMENT_CHARS))
    return {"avg_segments": statistics.mean(segs),
            "max_segments": max(segs),
            "avg_chars": statistics.mean(segs) * SMS_SEGMENT_CHARS}


def annual_volumes() -> Dict[str, float]:
    calls_day = sum(c for _, c in PILOTS)
    calls_year = calls_day * 365
    return {
        "restaurants": len(PILOTS),
        "calls_day": calls_day,
        "calls_year": calls_year,
        "minutes_year": calls_year * AVG_CALL_SECONDS / 60,
        "orders_year": calls_year * ORDER_CONVERSION,
    }


def cost_model(rates: Dict[str, float], speech: Dict[str, float],
               sms: Dict[str, float], vol: Dict[str, float],
               cache_hit: float = 0.0) -> Dict[str, float]:
    """Annual cost. cache_hit is the fraction of TTS characters served from
    pre-recorded audio (0.0 = none, 1.0 = every cacheable character)."""
    minutes = vol["minutes_year"]
    calls = vol["calls_year"]
    orders = vol["orders_year"]

    tts_chars = speech["chars_per_call"] * calls
    cached_chars = tts_chars * (speech["cacheable_pct"] / 100) * cache_hit
    billable_tts = tts_chars - cached_chars

    if rates["bundled_voice_per_min"]:
        voice = minutes * rates["bundled_voice_per_min"]
        tts = 0.0     # included in the bundle
    else:
        voice = minutes * rates["stt_per_min"]
        tts = billable_tts / 1000 * rates["tts_per_1k_chars"]

    llm = (minutes * rates["llm_tokens_per_min"] / 1000
           * rates["llm_per_1k_tokens"])
    telephony = minutes * rates["telephony_per_min"]
    # One ticket per order, plus a pay link on roughly a third.
    sms_cost = orders * sms["avg_segments"] * 1.33 * rates["sms_per_segment"]
    fixed = rates["monthly_fixed"] * 12

    total = voice + tts + llm + telephony + sms_cost + fixed
    revenue = (rates["price_per_restaurant_month"] * 12 * vol["restaurants"])
    return {
        "telephony": telephony, "voice": voice, "tts": tts, "llm": llm,
        "sms": sms_cost, "fixed": fixed, "total": total,
        "per_call": total / calls if calls else 0,
        "per_order": total / orders if orders else 0,
        "revenue": revenue, "gross_profit": revenue - total,
        "margin_pct": (revenue - total) / revenue * 100 if revenue else 0,
    }


def main() -> int:
    vol = annual_volumes()
    print("=" * 68)
    print("CHERRY — UNIT ECONOMICS")
    print("=" * 68)

    print(f"\nMEASURED VOLUMES ({vol['restaurants']} pilots)")
    print(f"  {vol['calls_day']:,.0f} calls/day -> {vol['calls_year']:,.0f} calls/year")
    print(f"  {vol['minutes_year']:,.0f} call-minutes/year "
          f"(at {AVG_CALL_SECONDS:.0f}s average)")
    print(f"  {vol['orders_year']:,.0f} orders/year (at {ORDER_CONVERSION:.0%} conversion)")

    print("\nWHAT LILY SAYS, AND HOW MUCH OF IT REPEATS")
    print("  (this is the ceiling on what pre-recording can save)\n")
    print(f"  {'restaurant':<22}{'chars/call':>11}{'fixed':>8}{'named':>8}"
          f"{'money':>8}{'cacheable':>11}{'clips':>7}")
    rows = {}
    for stem, label in (("bun-n-run-ferndale", "Bun N Run"),
                        ("pink-garlic-shelby", "Pink Garlic"),
                        ("juan-miguels-clinton", "Juan Miguel's")):
        m = measure_speech(stem)
        rows[label] = m
        print(f"  {label:<22}{m['chars_per_call']:>11.0f}"
              f"{m['fixed_pct']:>7.0f}%{m['semifixed_pct']:>7.0f}%"
              f"{m['variable_pct']:>7.0f}%{m['cacheable_pct']:>10.0f}%"
              f"{m['clips_needed']:>7.0f}")

    avg_cache = statistics.mean(r["cacheable_pct"] for r in rows.values())
    avg_chars = statistics.mean(r["chars_per_call"] for r in rows.values())
    print(f"\n  Average {avg_chars:,.0f} characters spoken per call, "
          f"{avg_cache:.0f}% of it cacheable.")
    print(f"  Annual TTS characters: {avg_chars * vol['calls_year']:,.0f}")
    print(f"  Cacheable characters:  "
          f"{avg_chars * vol['calls_year'] * avg_cache / 100:,.0f}")
    print(f"\n  So pre-recording can remove AT MOST {avg_cache:.0f}% of the TTS")
    print(f"  line — and TTS is one line of five. See the sensitivity below.")

    sms = measure_sms()
    print(f"\nSMS — BILLED PER {SMS_SEGMENT_CHARS}-CHARACTER SEGMENT")
    print(f"  Average kitchen ticket: {sms['avg_chars']:.0f} chars "
          f"= {sms['avg_segments']:.1f} segments")
    print(f"  Longest seen: {sms['max_segments']} segments")
    print(f"  A ticket is NOT one message. Budget "
          f"{sms['avg_segments']:.1f}x what you think.")

    speech = {"chars_per_call": avg_chars, "cacheable_pct": avg_cache}

    print("\n" + "=" * 68)
    print("YOUR RATES")
    print("=" * 68)
    missing = [k for k, v in RATES.items() if v == 0.0]
    if missing:
        print("\n  Not filled in yet, so no dollar figures are shown:\n")
        for k in missing:
            print(f"    {k}")
        print(f"""
  Fill these in at the top of this file and re-run. Use your own
  contracts, or the vendor pricing pages — do not take a number from
  a model, including me: rates move and mine would be stale.

  Then this prints annual cost by line, cost per call, cost per order,
  gross margin, and a sensitivity table showing exactly what the
  pre-recording lever is worth at your real numbers.""")
        return 0

    print("\n" + "=" * 68)
    print("ANNUAL COST AND MARGIN")
    print("=" * 68)
    for hit, label in ((0.0, "no caching"), (0.5, "half cached"),
                       (0.95, "fully cached")):
        c = cost_model(RATES, speech, sms, vol, cache_hit=hit)
        print(f"\n  {label.upper()}")
        for line in ("telephony", "voice", "tts", "llm", "sms", "fixed"):
            if c[line]:
                print(f"    {line:<12}${c[line]:>12,.0f}")
        print(f"    {'TOTAL':<12}${c['total']:>12,.0f}"
              f"   (${c['per_call']:.3f}/call, ${c['per_order']:.3f}/order)")
        if c["revenue"]:
            print(f"    revenue     ${c['revenue']:>12,.0f}   "
                  f"margin {c['margin_pct']:.0f}%")

    base = cost_model(RATES, speech, sms, vol, 0.0)
    full = cost_model(RATES, speech, sms, vol, 0.95)
    saved = base["total"] - full["total"]
    print(f"\n  Pre-recording saves ${saved:,.0f}/year "
          f"({saved / base['total'] * 100:.1f}% of total cost)")

    print("\n  COMPARE: shortening the average call by 15 seconds")
    shorter = dict(vol)
    shorter["minutes_year"] = vol["calls_year"] * (AVG_CALL_SECONDS - 15) / 60
    s = cost_model(RATES, speech, sms, shorter, 0.0)
    print(f"  saves ${base['total'] - s['total']:,.0f}/year "
          f"({(base['total'] - s['total']) / base['total'] * 100:.1f}%)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
