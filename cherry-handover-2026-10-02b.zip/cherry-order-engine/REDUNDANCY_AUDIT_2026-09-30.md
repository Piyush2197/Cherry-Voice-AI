# Redundancy audit — 2026-09-30

Prompted by "check for redundancy as well". One finding was a live bug; the rest
are real but need a decision before they are touched.

Method: parsed every non-test module's AST and looked for the same top-level
symbol defined in more than one file, then checked each hit by hand. Duplicate
`main()` functions and per-module CLI entry points are expected and are not
listed.

---

## 1. FIXED — `BoundedThreadingHTTPServer`, duplicated and diverged

`server.py` and `voice_gateway.py` each defined their own copy of this class.
They started the same and then drifted:

| | `voice_gateway.py` | `server.py` |
| --- | --- | --- |
| listen backlog 128 | yes | yes |
| concurrency cap | **`BoundedSemaphore(64)`** | **none** |

`CHANGES_2026-09-29.md` recorded the semaphore as "a semaphore cap on concurrent
gateway requests", and that was exactly true — of the gateway only.

The service that lost the fix is the busier one. Cherry's API answers **every
tool call on every live conversation**; a lunch rush is hundreds of requests a
minute against it. Without a cap, `ThreadingHTTPServer` spawns a thread per
connection until the process runs out of them. The quieter service queued
politely while the hot path had no ceiling.

Nobody chose this. Two copies simply diverged, which is what copies do.

**Fix:** one class in `bounded_http.py`, imported by both. The API now has the
same 128 backlog / 64 cap as the gateway. `test_bounded_http.py` (17 checks)
pins the behaviour *and* fails if either file ever defines its own copy again —
the regression guard matters more than the tests, because re-copying the class
is precisely how this happened.

---

## 2. FIXED (same day) — the six `restaurant_*.py` files duplicated the YAML menus

**Status: deleted 2026-09-30.** Kept here because the measurement is the argument
for why it was safe, and because the same shape will reappear if a menu is ever
hand-built in Python again.

~1,900 lines of hand-written Python holding restaurant menus that also exist as
YAML. Measured against `menus/*.yaml`:

| Module | items | YAML | Same items? |
| --- | --- | --- | --- |
| `restaurant_chengs.py` | 98 | 98 | **identical, 0 differences** |
| `restaurant_sams_kabob.py` | 126 | 126 | **identical, 0 differences** |
| `restaurant_juan_miguels.py` | 20 | 20 | **identical, 0 differences** |
| `restaurant_miyazaki.py` | 48 | 48 | **identical, 0 differences** |
| `restaurant_tamago.py` | 120 | 120 | **identical, 0 differences** |
| `restaurant_pink_garlic.py` | 51 | 128 | **already drifted** |

412 items across five restaurants were duplicated exactly — same ids, same
names, same prices, to the cent. The sixth had **already diverged**: the Python
copy was a stale single-location Pink Garlic, superseded by the three location
YAMLs, and 77 items out of date.

Nothing on the live path read them. Production loads menus from YAML into
`menu_version` and rebuilds through `menu_schema.build_config()`.

### How it was deleted safely

The risk was not the deletion, it was the fixtures: `test_conformance.py` ran
its 25 invariants against these seven configs. So before removing anything, the
invariants were dry-run against all 19 YAML menus:

**0 failures across 19 menus.** The YAML is not merely equivalent as a fixture,
it is strictly better — conformance now covers 27 configs instead of 15, and it
covers the real 128-item and 144-item Pink Garlic menus that the stale Python
copy never did.

What changed:

- `restaurants.py` dropped its six imports. `REAL_RESTAURANTS` now loads
  `menus/*.yaml` lazily, so a conformance fixture and a deployed menu are *the
  same file* and cannot drift apart again.
- `BUN_N_RUN` stays hand-written: it is a deliberate 9-item fixture the
  invariants reference by name, not a copy of a deployed menu.
- `test_conformance.py` and `test_library.py` load their fixtures from
  `menus/`. `test_library.py` had been checking the library against 51 Oak Park
  items when the location sold 128.
- `build_pink_garlic.py` had a dead `import restaurant_pink_garlic as pg` that
  was never referenced; removed.

Result: conformance went from `25 x 15` to `25 x 27` checks (707, all passing),
and the six files are gone.

---

## 3. NOT FIXED — a `Finding` dataclass defined twice

`onboarding_factory.py` and `readiness.py` each define a `Finding` dataclass and
an `_iso()` helper. They are structurally similar but not identical, and both
are report-shaped. Low risk, low value: worth merging only if the two reports
are ever meant to agree. Noted, not touched.

---

## 4. NOT FIXED — small helpers, judged acceptable

`_slug` (`cherry.py`, `menu_ingest.py`), `_parse_errors` (`square_bridge.py`,
`telnyx_sms.py`), `_drop_ambiguous_aliases` (two restaurant modules, both slated
for deletion under §2), and a `Handler` class name in both HTTP services.

The `Handler` pair is a name collision, not shared logic — the two handlers
serve completely different routes and merging them would be worse than the
duplication. The rest are three-to-ten-line helpers where a shared module would
add more indirection than it removes. Recorded so the next audit does not
re-litigate them.

---

## What to take from this

Of everything found, **one item was a real defect** and it was in the hottest
code path — found not by reading but by comparing two copies that were supposed
to be the same. The largest item by volume (§2) is the same disease as the
onboarding problem: a bespoke file per restaurant, existing only because the
generic path could not yet do the job. Now that `cherry.py ingest` reads a real
menu, §2 is finally deletable, and doing so is the cheapest remaining reduction
in onboarding cost.
