"""Voice-channel adapters for Cherry."""

from .inworld_bridge import CherryBridge, SYSTEM_PROMPT

__all__ = ["CherryBridge", "SYSTEM_PROMPT"]
