#!/usr/bin/env python3
"""Cost prediction: the numbers must agree with company_model.py and with hand
arithmetic, every rate must say where it came from, and 'actual' must read the
real database. If these drift, the figure a decision rests on is wrong."""

from __future__ import annotations

import contextlib
import io
import os
import sqlite3
import tempfile
import traceback
from datetime import datetime, timedelta, timezone
from pathlib import Path

import call_cost as cc
import company_model as cm
import menu_schema as ms
from order_store import OrderStore

HERE = Path(__file__).resolve().parent
_passed = _failed = 0


def check(name, cond, detail=""):
    global _passed, _failed
    if cond:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


def close(a, b, tol=1e-9):
    return abs(a - b) <= tol


def t_the_cascade_agrees_with_company_model() -> None:
    sc = cm.Scenario(1, "creator")
    c = sc.costs()
    per = cc.call_cost("inworld_cascade", cc.Profile())
    n = sc.calls
    for ours, theirs in (("telephony", "telephony"), ("tts", "inworld tts"), ("stt", "inworld stt"), ("llm", "llm")):
        check(f"per-call {ours} == company_model.{theirs} / calls", close(per[ours], c[theirs] / n, 1e-9),
              f"{per[ours]} vs {c[theirs] / n}")


def t_gemini_by_hand() -> None:
    p = cc.Profile(call_seconds=90, lily_speaks_seconds=17, static_context_tokens=3000, tool_turns=8)
    lo = cc.call_cost("gemini_live_3_8", p)
    check("input audio is billed for the WHOLE call: 90 s x 25 tok/s x $3/M", close(lo["audio_in"], 90 * 25 / 1e6 * 3.00))
    check("output audio is only what Lily speaks: 17 s x 25 x $12/M", close(lo["audio_out"], 17 * 25 / 1e6 * 12.00))
    check("static context billed once at best: 3000 x $0.75/M", close(lo["context_text_in"], 3000 / 1e6 * 0.75))
    hi = cc.call_cost("gemini_live_3_8", p, high=True)
    check("…and on every tool turn at worst", close(hi["context_text_in"], 3000 * 8 / 1e6 * 0.75))
    check("high uses 32 audio tokens a second", close(hi["audio_in"], 90 * 32 / 1e6 * 3.00))
    check("telephony is the same either way (Telnyx still carries the call)", close(lo["telephony"], 1.5 * cm.TELEPHONY_PER_MIN))
    for arch in ("inworld_cascade", "gemini_live_3_8", "gemini_live_2_5"):
        a, b = cc.call_cost(arch, p), cc.call_cost(arch, p, high=True)
        check(f"{arch}: the pessimistic estimate is never below the optimistic one, line by line",
              all(b[k] >= a[k] - 1e-12 for k in a), str((a, b)))
    check("a longer call costs more on Gemini Live (silence is billed)",
          cc.total(cc.call_cost("gemini_live_3_8", cc.Profile(call_seconds=300))) > cc.total(cc.call_cost("gemini_live_3_8", cc.Profile(call_seconds=90))))


def t_every_rate_says_where_it_came_from() -> None:
    for name, r in cc.RATES.items():
        check(f"{name} has a label and a status", bool(r.get("label")) and bool(r.get("status")))
    check("the Gemini prices are marked verified, with the source and date",
          "VERIFIED 2026-10-01" in cc.RATES["gemini_live_3_8"]["status"] and "ai.google.dev" in cc.RATES["gemini_live_3_8"]["status"])
    check("the retiring model says so", "retired" in cc.RATES["gemini_live_2_5"]["label"])


def t_a_verified_new_price_is_a_one_line_edit() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        f = os.path.join(tmp, "over.yaml")
        Path(f).write_text("gemini_live_3_8:\n  audio_in_per_1m: 6.0\n", encoding="utf-8")
        rates = cc.load_rates(f)
        check("the override is applied", rates["gemini_live_3_8"]["audio_in_per_1m"] == 6.0)
        check("everything else is kept", rates["gemini_live_3_8"]["audio_out_per_1m"] == 12.0)
        a = cc.call_cost("gemini_live_3_8", cc.Profile(static_context_tokens=1000), rates=rates)["audio_in"]
        check("and it flows into the estimate", close(a, 90 * 25 / 1e6 * 6.0))
        check("the module defaults are not mutated", cc.RATES["gemini_live_3_8"]["audio_in_per_1m"] == 3.0)


def t_actual_reads_the_database() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        db = os.path.join(tmp, "c.db")
        store = OrderStore.sqlite(db)
        cfg = ms.load_yaml(HERE / "menus" / "bun-n-run-ferndale.yaml")
        store.upsert_restaurant(cfg.id, cfg.name, cfg.cuisine, sink="manual", tax_rate_bps=cfg.tax_rate_bps,
                                staff_phone="+13135550999", active=True)
        mv = store.publish_menu(cfg.id, "menus/bun-n-run-ferndale.yaml", item_count=len(cfg.items))
        now = datetime.now(timezone.utc)
        made = []
        for i, (secs, chars) in enumerate([(80, 200), (95, 260), (100, 300), (1500, 400)]):
            sid = store.start_session(cfg.id, mv, channel="voice", external_id=f"c{i}", caller_phone="+13135550123")
            store.record_turn(sid, "agent", "x" * chars, intent="t")
            store.record_turn(sid, "caller", "hello", intent="t")
            store.end_session(sid, "completed")
            made.append((sid, secs))
        raw = sqlite3.connect(db)
        for sid, secs in made:
            start = now - timedelta(hours=2)
            raw.execute("UPDATE session SET started_at=?, ended_at=? WHERE id=?",
                        (start.isoformat(timespec="seconds"), (start + timedelta(seconds=secs)).isoformat(timespec="seconds"), sid))
        raw.commit(); raw.close()
        calls = cc.observed_calls(store, days=7)
        check("every ended voice call is read", len(calls) == 4, str(len(calls)))
        check("durations come from the session's own start and end", sorted(round(c["seconds"]) for c in calls) == [80, 95, 100, 1500])
        check("characters are what Lily actually said", sorted(c["chars"] for c in calls) == [200, 260, 300, 400])
        prof = cc.observed_profile(calls)
        check("the profile is the MEDIAN call, so one runaway does not skew it", 90 < prof.call_seconds < 100, str(prof.call_seconds))
        runaways = cc.long_calls(calls, minutes=8)
        check("the 25-minute call is flagged as a runaway", len(runaways) == 1 and runaways[0]["seconds"] == 1500)
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            rc = cc.main(["actual", "--db", db, "--days", "7"])
        out = buf.getvalue()
        check("the actual report runs and names the runaway", rc == 0 and "25.0 min" in out and "Median call" in out, out[-300:])
        store.close()


def t_the_commands_run() -> None:
    for argv, needle in ((["compare"], "TOTAL / call"), (["forecast", "--restaurants", "10"], "voice cost/month"),
                         (["rates"], "gemini_live_3_8"), (["compare", "--calls-per-day", "20", "--call-seconds", "120"], "20 calls/day")):
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            rc = cc.main(argv)
        check(f"call_cost {' '.join(argv)} runs", rc == 0 and needle in buf.getvalue(), buf.getvalue()[-200:])
    check("the prompt and tool schemas are measured, not guessed", 2000 < cc.static_context_tokens() < 12000, str(cc.static_context_tokens()))


def main() -> int:
    global _failed
    for name, fn in sorted((k, v) for k, v in globals().items() if k.startswith("t_")):
        try:
            fn()
        except Exception:                                    # noqa: BLE001
            _failed += 1
            print(f"\n--- FAIL {name} raised")
            traceback.print_exc()
    print(f"{_passed} passed, {_failed} failed (call cost model)")
    return 1 if _failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
