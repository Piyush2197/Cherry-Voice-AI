#!/usr/bin/env python3
"""Build a location-specific Cherry menu from a saved Square catalog export.

This never calls Square and never needs a credential. The owner/developer saves
the Catalog API JSON locally, then this command matches every Square variation
to the reviewed base menu, replaces prices and availability, and embeds stable
Square ids. Any unmatched or duplicate item blocks the output instead of being
guessed.
"""

from __future__ import annotations

import _ensure_deps  # noqa: F401  (re-runs under .venv, or says how to install, if PyYAML is missing)
import argparse
import copy
import json
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import yaml

import menu_schema as ms
from catalog_sync import flatten_square_objects
from cherry import cmd_check


class LocationCatalogError(ValueError):
    pass


def _strict_name(value: str) -> str:
    value = re.sub(r"^\s*\d+[a-z]?\.\s*", "", value.lower())
    value = re.sub(r"[^a-z0-9]+", " ", value)
    return " ".join(value.split())


def _loose_name(value: str) -> str:
    value = re.sub(r"\([^)]*\)", "", value)
    return _strict_name(value)


def read_export(path: Path, location_id: str) -> List[Dict[str, Any]]:
    """Accept either raw Square ``objects`` JSON or an already-flat list."""
    doc = json.loads(path.read_text())
    if isinstance(doc, dict) and isinstance(doc.get("objects"), list):
        return flatten_square_objects(doc["objects"], location_id)
    if isinstance(doc, dict) and isinstance(doc.get("items"), list):
        doc = doc["items"]
    if not isinstance(doc, list):
        raise LocationCatalogError(
            "export must be a Square {objects:[...]} response or a flat item list")
    return doc


def build_location_doc(base_doc: Dict[str, Any], pos_items: List[Dict[str, Any]],
                       *, restaurant_id: str,
                       restaurant_name: str) -> Tuple[Dict[str, Any], Dict[str, int]]:
    """Return an exact location menu or fail with every unresolved match."""
    doc = copy.deepcopy(base_doc)
    problems = ms.validate_doc(doc)
    if problems:
        raise LocationCatalogError("base menu is invalid: " + "; ".join(problems))

    rows = doc.get("items") or []
    by_ref: Dict[str, dict] = {}
    strict: Dict[str, List[dict]] = {}
    loose: Dict[str, List[dict]] = {}
    for row in rows:
        refs = row.get("pos_refs") or {}
        if refs.get("square_catalog_object_id"):
            by_ref[str(refs["square_catalog_object_id"])] = row
        names = [str(row.get("name") or "")]
        names.extend(str(v) for k, v in refs.items() if k.endswith("name"))
        for name in names:
            strict.setdefault(_strict_name(name), []).append(row)
            loose.setdefault(_loose_name(name), []).append(row)

    claimed: Dict[str, str] = {}
    unresolved_pos: List[str] = []
    updated_prices = updated_availability = 0
    for item in pos_items:
        ref = str(item.get("catalog_object_id") or "")
        name = str(item.get("name") or "").strip()
        variation = str(item.get("variation_name") or "").strip()
        full = name if not variation or variation.lower() == "regular" \
            else f"{name} ({variation})"

        row = by_ref.get(ref)
        if row is None:
            candidates = strict.get(_strict_name(full), [])
            if len(candidates) != 1:
                candidates = strict.get(_strict_name(name), [])
            if len(candidates) != 1:
                candidates = loose.get(_loose_name(full), [])
            row = candidates[0] if len(candidates) == 1 else None

        if row is None:
            unresolved_pos.append(f"{full} [{ref or 'no variation id'}]")
            continue
        item_id = str(row.get("id"))
        if item_id in claimed:
            unresolved_pos.append(
                f"{full} [{ref}] also matched {item_id}, already claimed by "
                f"{claimed[item_id]}")
            continue
        claimed[item_id] = full

        price = item.get("price_cents")
        if price is None:
            unresolved_pos.append(f"{full} [{ref}] has no fixed price")
            continue
        if row.get("sizes"):
            unresolved_pos.append(
                f"{full} [{ref}] matched sized item {item_id}; variation mapping required")
            continue
        new_price = f"{int(price) // 100}.{int(price) % 100:02d}"
        if str(row.get("price")) != new_price:
            updated_prices += 1
        row["price"] = new_price
        available = bool(item.get("available", True))
        before = row.get("available", True)
        if before != available:
            updated_availability += 1
        if available:
            row.pop("available", None)
        else:
            row["available"] = False
        refs = dict(row.get("pos_refs") or {})
        refs.update({"square_catalog_object_id": ref,
                     "square_item_id": str(item.get("item_id") or ""),
                     "square_name": full})
        row["pos_refs"] = refs

    missing = [f"{row.get('name')} [{row.get('id')}]" for row in rows
               if str(row.get("id")) not in claimed]
    if unresolved_pos or missing:
        details = []
        if unresolved_pos:
            details.append("unmatched/ambiguous Square entries:\n  - " +
                           "\n  - ".join(unresolved_pos))
        if missing:
            details.append("base-menu items absent from this location:\n  - " +
                           "\n  - ".join(missing))
        raise LocationCatalogError("\n".join(details))

    doc["restaurant"]["id"] = restaurant_id
    doc["restaurant"]["name"] = restaurant_name
    final_problems = ms.validate_doc(doc)
    if final_problems:
        raise LocationCatalogError("generated menu is invalid: " +
                                   "; ".join(final_problems))
    return doc, {"items": len(rows), "prices": updated_prices,
                 "availability": updated_availability}


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--export", type=Path, required=True)
    parser.add_argument("--square-location-id", required=True)
    parser.add_argument("--restaurant-id", required=True)
    parser.add_argument("--restaurant-name", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args(argv)

    base = yaml.safe_load(args.base.read_text())
    try:
        doc, counts = build_location_doc(
            base, read_export(args.export, args.square_location_id),
            restaurant_id=args.restaurant_id,
            restaurant_name=args.restaurant_name)
    except LocationCatalogError as exc:
        print(f"BLOCKED — no menu written\n{exc}")
        return 2

    text = yaml.safe_dump(doc, sort_keys=False, allow_unicode=True, width=100)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(text)
    gate_args = type("CheckArgs", (), {"menu": str(args.out), "verbose": False})()
    if cmd_check(gate_args) != 0:
        args.out.unlink(missing_ok=True)
        print("BLOCKED — generated menu failed the gate and was removed")
        return 1
    print(f"WROTE {args.out}: {counts['items']} items, "
          f"{counts['prices']} price changes, "
          f"{counts['availability']} availability changes")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

