#!/usr/bin/env python3
"""Usage-plan and observed cost-saving checks."""
from __future__ import annotations

from datetime import datetime, timezone

import cost_control as cc
from order_store import OrderStore


def fixture():
    store = OrderStore.sqlite()
    store.upsert_restaurant("r", "Restaurant", "test", active=True)
    store.conn.execute("""INSERT INTO menu_version
      (restaurant_id,version,yaml,yaml_sha256,item_count,published_at,is_live)
      VALUES ('r',1,'x','x',1,CURRENT_TIMESTAMP,1)""")
    store.conn.commit()
    return store


def add_usage(store, month: str, minutes: float, number: int):
    sid = store.start_session("r", 1, external_id=f"call-{number}")
    store.conn.execute("UPDATE session SET started_at=? WHERE id=?",
                       (f"{month}-15T12:00:00+00:00", sid))
    store.conn.execute("""INSERT INTO voice_usage
        (session_id,provider,processed_characters,transcribed_audio_ms,updated_at)
        VALUES (?,'inworld',100,?,CURRENT_TIMESTAMP)""",
        (sid, int(minutes * 60000)))
    store.conn.commit()


def add_calls(store, day: str, count: int, restaurant_id: str = "r"):
    for i in range(count):
        sid = store.start_session(restaurant_id, 1, channel="voice",
                                  external_id=f"burst-{restaurant_id}-{day}-{i}")
        store.conn.execute("UPDATE session SET started_at=? WHERE id=?",
                           (f"{day}T11:{i // 60:02d}:{i % 60:02d}+00:00", sid))
    store.conn.commit()


def main():
    passed = 0
    store = fixture()
    now = datetime(2026, 9, 21, tzinfo=timezone.utc)
    for n, month in enumerate(("2026-06", "2026-07", "2026-08")):
        add_usage(store, month, 3100 + n, n)
    # A location with no stored plan is on Small, the launch default.
    review = cc.plan_reviews(store, now=now)[0]
    assert review["plan"] == "small" and review["included_minutes"] == 3000.0
    passed += 1
    assert review["action"] == "upgrade_plan"; passed += 1
    assert review["consecutive_completed_months_over"] == 3; passed += 1
    add_usage(store, "2026-09", 4000, 9)
    assert cc.plan_reviews(store, now=now)[0]["consecutive_completed_months_over"] == 3; passed += 1
    store.conn.execute("UPDATE voice_usage SET transcribed_audio_ms=? WHERE session_id="
                       "(SELECT id FROM session WHERE started_at LIKE '2026-07%')",
                       (2500 * 60000,))
    store.conn.commit()
    review = cc.plan_reviews(store, now=now)[0]
    assert review["action"] == "watch" and review["consecutive_completed_months_over"] == 1; passed += 1

    # The same usage on Medium (5,000 minutes) is comfortably inside the plan.
    cc.set_plan(store, "r", "medium")
    review = cc.plan_reviews(store, now=now)[0]
    assert review["plan"] == "medium" and review["included_minutes"] == 5000.0
    passed += 1
    assert review["action"] == "stay_on_plan" \
        and review["consecutive_completed_months_over"] == 0; passed += 1
    # Re-setting a plan updates the row instead of failing on the primary key.
    cc.set_plan(store, "r", "grande")
    assert cc.location_plans(store) == {"r": "grande"}; passed += 1
    review = cc.plan_reviews(store, now=now)[0]
    assert review["included_minutes"] == 10000.0; passed += 1
    try:
        cc.set_plan(store, "r", "deluxe")
        raise AssertionError("an unknown plan must be rejected")
    except ValueError:
        passed += 1

    # Daily call counts feed the ops-monitor threshold for the location's plan.
    add_calls(store, "2026-09-21", 3)
    counts = cc.daily_voice_calls(store, now=now)
    assert counts == {"r": 3}, counts; passed += 1
    assert cc.daily_voice_calls(store, day=datetime(2026, 9, 20,
                                tzinfo=timezone.utc).date(), now=now) == {}
    passed += 1

    assert cc.sms_segments("x" * 161) == 2; passed += 1
    store.log_sms("+13135550123", "x" * 161, "confirmation",
                  restaurant_id="r", status="sent")
    report = cc.savings_report(store, restaurant_id="r")
    assert report["measured"]["sms_segments"] == 2; passed += 1
    assert any(x["name"] == "keep_customer_review_and_payment_in_one_text"
               for x in report["opportunities"]); passed += 1
    print(f"{passed} passed, 0 failed (cost control)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
