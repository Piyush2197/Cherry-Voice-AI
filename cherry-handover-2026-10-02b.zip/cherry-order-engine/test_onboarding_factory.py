#!/usr/bin/env python3
"""Checks for the repeatable two-business-day onboarding factory."""

from __future__ import annotations

import _ensure_deps  # noqa: F401  (re-runs under .venv, or says how to install, if PyYAML is missing)
import tempfile
import traceback
import shutil
from datetime import datetime, timezone
from pathlib import Path

import yaml

import onboarding_factory as factory
import pilot_deploy
import menu_schema as ms
from order_store import OrderStore


ROOT = Path(__file__).parent
_passed = _failed = 0


def check(name, condition, detail=""):
    global _passed, _failed
    if condition:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


def ready_case(menu=None):
    return {"schema_version": 1, "case_id": "fast-burger",
            "business_name": "Fast Burger", "primary_contact": "Owner",
            "timezone": "America/Detroit",
            "intake_completed_at": "2026-09-21T14:00:00Z",
            "locations": [{
                "id": "bun-n-run-ferndale", "name": "Fast Burger Ferndale",
                "cuisine": "burger",
                "menu": str(menu or ROOT / "menus" / "bun-n-run-ferndale.yaml"),
                "fallback_phone": "+12485551234",
                "inbound_env": "CHERRY_INBOUND_FAST_BURGER_FERNDALE",
                "pos_type": "manual", "provider_access_ready": True,
                "checkout_provider": "square", "checkout_authorized": True,
                "pos_mapping_verified": True,
                "service": {"weekly_hours": {"mon": ["10:00", "22:00"]},
                            "holiday_closures": [], "prep_minutes": 20,
                            "wait_minutes": 0, "languages": ["en"]},
                "confirmations": {"prices": True, "modifiers": True,
                                  "tax": True, "hours": True,
                                  "fallback": True, "owner_approval": True}}]}


def t_new_case_is_safe_and_does_not_overwrite():
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp) / "case"
        path = factory.new_case(out, "x", "X", "x-main", "X Main", "burger", "square")
        text = path.read_text()
        check("new case creates the intake and raw-menu slots",
              path.is_file() and (out / "raw-menu.txt").is_file())
        check("new case contains no credential value",
              "access_token" not in text and "api_key" not in text)
        try:
            factory.new_case(out, "x", "X", "x-main", "X Main", "burger", "square")
        except FileExistsError:
            check("new case refuses to overwrite", True)
        else:
            check("new case refuses to overwrite", False)


def t_incomplete_intake_does_not_start_the_sla():
    with tempfile.TemporaryDirectory() as tmp:
        path = factory.new_case(Path(tmp) / "case", "x", "X", "x-main",
                                "X Main", "burger", "manual")
        audit = factory.audit_case(factory.load_case(path), path, env={})
        check("incomplete intake is clearly not complete", not audit.intake_complete)
        check("the two-day clock is not started while waiting on inputs",
              audit.clock_started_at is None and audit.deadline_at is None)
        check("owner and sales blockers are assigned",
              {x.owner for x in audit.findings} >= {"owner", "sales"})


def t_complete_case_generates_a_deployable_packet():
    with tempfile.TemporaryDirectory() as tmp:
        case_path = Path(tmp) / "intake.yaml"
        case_path.write_text(yaml.safe_dump(ready_case(), sort_keys=False))
        env = {"CHERRY_INBOUND_FAST_BURGER_FERNDALE": "+13135551234"}
        audit = factory.write_packet(case_path, Path(tmp) / "packet", env=env)
        check("complete case passes every pre-live gate", audit.launch_ready,
              str(audit.as_dict()))
        check("deadline is two business days after Sunday intake",
              audit.deadline_at.startswith("2026-09-23"), str(audit.deadline_at))
        manifest = pilot_deploy.load_manifest(Path(tmp) / "packet" / "deployment.yaml")
        check("generated manifest is accepted by the deployment tool",
              len(manifest) == 1 and manifest[0].id == "bun-n-run-ferndale")
        check("packet contains controls, audit and human launch report",
              all((Path(tmp) / "packet" / name).is_file()
                  for name in ("controls.yaml", "audit.json", "LAUNCH_REPORT.md")))
        check("packet generates a runnable per-location smoke call",
              (Path(tmp) / "packet" / "calls" /
               "bun-n-run-ferndale-smoke.txt").is_file())


def t_packet_controls_apply_fail_closed():
    with tempfile.TemporaryDirectory() as tmp:
        case_path = Path(tmp) / "intake.yaml"
        case_path.write_text(yaml.safe_dump(ready_case(), sort_keys=False))
        packet = Path(tmp) / "packet"
        factory.write_packet(case_path, packet,
                             env={"CHERRY_INBOUND_FAST_BURGER_FERNDALE": "+13135551234"})
        db = str(Path(tmp) / "pilot.db")
        store = OrderStore.sqlite(db)
        try:
            factory.apply_controls_file(packet / "controls.yaml", db)
        except ValueError as exc:
            check("controls refuse an undeployed restaurant", "undeployed" in str(exc))
        else:
            check("controls refuse an undeployed restaurant", False)
        cfg = ms.load_yaml(ROOT / "menus" / "bun-n-run-ferndale.yaml")
        store.upsert_restaurant(cfg.id, cfg.name, cfg.cuisine)
        check("controls apply after deployment",
              factory.apply_controls_file(packet / "controls.yaml", db) == 1)
        row = store.conn.execute(
            "SELECT prep_minutes FROM restaurant_control WHERE restaurant_id=?",
            (cfg.id,)).fetchone()
        check("packet controls persist exactly", row["prep_minutes"] == 20)


def t_checkout_authorization_is_required_before_the_sla_starts():
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "intake.yaml"
        doc = ready_case()
        doc["locations"][0]["provider_access_ready"] = False
        path.write_text(yaml.safe_dump(doc))
        intake = factory.audit_case(doc, path, env={}, deployment=False)
        deployment = factory.audit_case(doc, path, env={}, deployment=True)
        check("provider authorization must precede the two-day clock",
              not intake.intake_complete and intake.clock_started_at is None)
        codes = {x.code for x in deployment.findings}
        check("deployment separately blocks missing number and authorization",
              {"inbound_number", "provider_access"} <= codes, str(codes))


def t_manual_only_checkout_cannot_be_called_launch_ready():
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "intake.yaml"
        doc = ready_case()
        loc = doc["locations"][0]
        loc["checkout_provider"] = ""
        loc["checkout_authorized"] = False
        path.write_text(yaml.safe_dump(doc))
        env = {"CHERRY_INBOUND_FAST_BURGER_FERNDALE": "+13135551234"}
        audit = factory.audit_case(doc, path, env=env, deployment=True)
        codes = {finding.code for finding in audit.findings}
        check("manual-only case cannot pass paid-first launch gate",
              not audit.intake_complete and audit.clock_started_at is None
              and not audit.launch_ready and
              {"itemized_checkout_provider", "checkout_authorization"} <= codes,
              str(codes))


def t_credentials_are_rejected_in_case_files():
    doc = ready_case()
    doc["square_access_token"] = "do-not-store-this"
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "intake.yaml"
        path.write_text(yaml.safe_dump(doc))
        try:
            factory.load_case(path)
        except ValueError as exc:
            check("credential values are rejected", "forbidden" in str(exc), str(exc))
        else:
            check("credential values are rejected", False)


def t_bad_menu_or_duplicate_location_cannot_ship():
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "intake.yaml"
        doc = ready_case(Path(tmp) / "missing.yaml")
        doc["locations"].append(dict(doc["locations"][0]))
        path.write_text(yaml.safe_dump(doc))
        audit = factory.audit_case(doc, path, env={}, deployment=True)
        codes = {x.code for x in audit.findings}
        check("missing menu and duplicate ids block launch",
              {"menu_missing", "duplicate_location"} <= codes, str(codes))
        check("blocked case never reports launch ready", not audit.launch_ready)


def t_portfolio_tracks_waiting_ready_and_overdue_cases_without_contacts():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        waiting = root / "waiting"; waiting.mkdir()
        factory.new_case(waiting, "waiting", "Waiting Cafe", "waiting-main",
                         "Waiting Main", "burger", "manual")
        ready = root / "ready"; ready.mkdir()
        ready_doc = ready_case()
        (ready / "intake.yaml").write_text(yaml.safe_dump(ready_doc))
        result = factory.portfolio(
            root, env={"CHERRY_INBOUND_FAST_BURGER_FERNDALE": "+13135551234"},
            now=datetime(2026, 9, 22, tzinfo=timezone.utc))
        check("portfolio aggregates cases and locations",
              result["cases"] == 2 and result["locations"] == 2, str(result))
        check("portfolio separates intake from ready-for-acceptance",
              result["states"] == {"ready_for_acceptance": 1,
                                    "waiting_intake": 1}, str(result["states"]))
        check("portfolio never exposes the primary contact",
              "Owner" not in str(result), str(result))


def t_launch_certificate_requires_every_check_and_learns_from_bugs():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        case_path = root / "intake.yaml"
        case_path.write_text(yaml.safe_dump(ready_case()))
        packet = root / "packet"
        env = {"CHERRY_INBOUND_FAST_BURGER_FERNDALE": "+13135551234"}
        factory.write_packet(case_path, packet, env=env)
        acceptance_path = packet / "acceptance.yaml"
        try:
            factory.certify(case_path, acceptance_path, root / "certificate.json", env=env)
        except ValueError as exc:
            check("unchecked launch cannot be certified", "not passed" in str(exc), str(exc))
        else:
            check("unchecked launch cannot be certified", False)

        acceptance = yaml.safe_load(acceptance_path.read_text())
        acceptance["checks"] = {name: True for name in factory.ACCEPTANCE_CHECKS}
        acceptance["accepted_at"] = "2026-09-22T17:00:00Z"
        acceptance["owner_signoff"] = "Restaurant Owner"
        acceptance["issues"] = [{"description": "combo phrase misheard",
                                  "resolution": "added a spoken alias",
                                  "regression_test": "test_fast_burger_combo_phrase"}]
        acceptance_path.write_text(yaml.safe_dump(acceptance))
        certificate = factory.certify(
            case_path, acceptance_path, root / "certificate.json", env=env)
        check("fully accepted launch receives a menu-hashed certificate",
              len(certificate["menu_sha256"]["bun-n-run-ferndale"]) == 64)
        check("resolved bug and regression test become launch evidence",
              certificate["resolved_issues"][0]["regression_test"] ==
              "test_fast_burger_combo_phrase")

        acceptance["issues"][0]["regression_test"] = ""
        acceptance_path.write_text(yaml.safe_dump(acceptance))
        try:
            factory.certify(case_path, acceptance_path, root / "bad.json", env=env)
        except ValueError as exc:
            check("a discovered bug must have a regression test", "regression_test" in str(exc))
        else:
            check("a discovered bug must have a regression test", False)

        acceptance["issues"][0]["regression_test"] = "test_fast_burger_combo_phrase"
        acceptance["checks"]["no_unpaid_kitchen_ticket"] = False
        acceptance_path.write_text(yaml.safe_dump(acceptance))
        try:
            factory.certify(case_path, acceptance_path, root / "unpaid.json", env=env)
        except ValueError as exc:
            check("an unpaid kitchen ticket cannot be certified",
                  "no_unpaid_kitchen_ticket" in str(exc), str(exc))
        else:
            check("an unpaid kitchen ticket cannot be certified", False)


def t_menu_change_after_acceptance_packet_forces_retest():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        menu = root / "menu.yaml"
        shutil.copyfile(ROOT / "menus" / "bun-n-run-ferndale.yaml", menu)
        doc = ready_case(menu)
        case_path = root / "intake.yaml"
        case_path.write_text(yaml.safe_dump(doc))
        packet = root / "packet"
        env = {"CHERRY_INBOUND_FAST_BURGER_FERNDALE": "+13135551234"}
        factory.write_packet(case_path, packet, env=env)
        acceptance_path = packet / "acceptance.yaml"
        acceptance = yaml.safe_load(acceptance_path.read_text())
        acceptance["checks"] = {name: True for name in factory.ACCEPTANCE_CHECKS}
        acceptance["accepted_at"] = "2026-09-22T17:00:00Z"
        acceptance["owner_signoff"] = "Restaurant Owner"
        acceptance_path.write_text(yaml.safe_dump(acceptance))
        menu.write_text(menu.read_text() + "\n# changed after review\n")
        try:
            factory.certify(case_path, acceptance_path, root / "bad.json", env=env)
        except ValueError as exc:
            check("menu drift invalidates prior acceptance", "menu changed" in str(exc), str(exc))
        else:
            check("menu drift invalidates prior acceptance", False)


def main():
    for name, fn in sorted(globals().items()):
        if name.startswith("t_"):
            try:
                fn()
            except Exception:
                global _failed
                _failed += 1
                print(f"\n--- FAIL {name}\n{traceback.format_exc()}")
    print(f"\n{_passed} passed, {_failed} failed (onboarding factory)")
    return 1 if _failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
