#!/usr/bin/env python3
"""Provision, verify, back up and restore-drill Cherry's Postgres database.

Credentials are read from environment variables and are never accepted as
command-line values, so they do not leak into shell history or process lists.

    export CHERRY_DATABASE_URL='postgresql://...'
    python3 production_db.py bootstrap
    python3 production_db.py verify
    python3 production_db.py backup --out backups/cherry.dump

For a destructive restore drill, create a separate empty database whose name
contains "restore" or "drill", set CHERRY_RESTORE_DATABASE_URL, then run:

    python3 production_db.py restore-drill --archive backups/cherry.dump \
        --confirm-target
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path
from typing import Any, Callable, Dict, Iterable
from urllib.parse import parse_qsl, unquote, urlparse

from order_store import OrderStore


REQUIRED_TABLES = {
    "schema_migration", "restaurant", "menu_version", "availability_override",
    "restaurant_control", "reservation_policy", "reservation",
    "reservation_reference", "session", "call_journal", "resolution",
    "location_plan", "billing_contract", "invoice", "invoice_line", "billing_adjustment",
    "voice_usage", "turn",
    "order", "order_delivery", "order_release", "payment", "sms_message", "sms_suppression",
    "event", "webhook_receipt",
}


def dsn_from_env(name: str) -> str:
    dsn = os.getenv(name, "").strip()
    if not dsn:
        raise RuntimeError(f"{name} is not set")
    if not dsn.startswith(("postgres://", "postgresql://")):
        raise RuntimeError(f"{name} must be a Postgres URL")
    return dsn


def database_name(dsn: str) -> str:
    return urlparse(dsn).path.lstrip("/").split("?", 1)[0]


def pg_environment(dsn: str) -> Dict[str, str]:
    """Convert a URL to libpq environment variables, keeping it out of argv."""
    parsed = urlparse(dsn)
    env = dict(os.environ)
    if parsed.hostname:
        env["PGHOST"] = parsed.hostname
    if parsed.port:
        env["PGPORT"] = str(parsed.port)
    if parsed.username:
        env["PGUSER"] = unquote(parsed.username)
    if parsed.password:
        env["PGPASSWORD"] = unquote(parsed.password)
    if database_name(dsn):
        env["PGDATABASE"] = unquote(database_name(dsn))
    supported = {
        "sslmode": "PGSSLMODE", "sslrootcert": "PGSSLROOTCERT",
        "connect_timeout": "PGCONNECT_TIMEOUT", "application_name": "PGAPPNAME",
    }
    for key, value in parse_qsl(parsed.query):
        if key in supported:
            env[supported[key]] = value
    return env


def verify_store(store: OrderStore) -> Dict[str, Any]:
    tables = {row["tablename"] for row in store.conn.execute(
        "SELECT tablename FROM pg_catalog.pg_tables "
        "WHERE schemaname='public' ORDER BY tablename").fetchall()}
    missing = sorted(REQUIRED_TABLES - tables)
    trigger = store.conn.execute(
        "SELECT count(*) AS n FROM pg_catalog.pg_trigger "
        "WHERE tgname='order_immutable' AND NOT tgisinternal").fetchone()
    migration = store.conn.execute(
        "SELECT COALESCE(MAX(version), 0) AS version FROM schema_migration"
    ).fetchone()
    counts = store.conn.execute("""
        SELECT
          (SELECT count(*) FROM restaurant) AS restaurants,
          (SELECT count(*) FROM menu_version) AS menu_versions,
          (SELECT count(*) FROM "order") AS orders,
          (SELECT count(*) FROM session WHERE ended_at IS NULL) AS open_sessions
    """).fetchone()
    result = {
        "ok": (not missing and int(trigger["n"]) == 1 and
               int(migration["version"]) >= 1),
        "missing_tables": missing,
        "immutable_order_trigger": int(trigger["n"]) == 1,
        "schema_version": int(migration["version"]),
        "counts": {key: int(value) for key, value in counts.items()},
    }
    if not result["ok"]:
        raise RuntimeError(f"database verification failed: {result}")
    return result


def run_program(argv: Iterable[str], *, env: Dict[str, str],
                runner: Callable[..., Any] = subprocess.run):
    try:
        return runner(list(argv), check=True, text=True, capture_output=True, env=env)
    except subprocess.CalledProcessError as exc:
        # Surface the tool's own diagnostics (never the environment, which
        # carries the database password) instead of a bare exit status.
        detail = (exc.stderr or exc.stdout or "").strip()[-800:]
        raise RuntimeError(f"{Path(str(argv[0])).name} failed "
                           f"(exit {exc.returncode}): {detail}") from exc


def backup(dsn: str, out: Path, *, overwrite: bool = False,
           runner: Callable[..., Any] = subprocess.run) -> Dict[str, Any]:
    if out.exists() and not overwrite:
        raise FileExistsError(f"refusing to overwrite {out}; pass --overwrite")
    pg_dump = shutil.which("pg_dump")
    if not pg_dump:
        raise RuntimeError("pg_dump is not installed")
    out.parent.mkdir(parents=True, exist_ok=True)
    run_program([pg_dump, "--format=custom", "--no-owner", "--no-acl",
                 "--file", str(out)], env=pg_environment(dsn), runner=runner)
    out.chmod(0o600)
    digest = hashlib.sha256(out.read_bytes()).hexdigest()
    return {"archive": str(out), "bytes": out.stat().st_size,
            "sha256": digest}


def restore_drill(archive: Path, target_dsn: str, *, confirmed: bool,
                  runner: Callable[..., Any] = subprocess.run) -> Dict[str, Any]:
    if not confirmed:
        raise RuntimeError("restore drill requires --confirm-target")
    if not archive.is_file():
        raise FileNotFoundError(archive)
    target_name = database_name(target_dsn).lower()
    if "restore" not in target_name and "drill" not in target_name:
        raise RuntimeError(
            "refusing destructive restore: target database name must contain "
            "'restore' or 'drill'")
    pg_restore = shutil.which("pg_restore")
    if not pg_restore:
        raise RuntimeError("pg_restore is not installed")
    # pg_restore only restores into a database when --dbname is given;
    # without it PostgreSQL 16 refuses to run. Only the database *name* goes
    # on the command line; host and credentials stay in the environment.
    run_program([pg_restore, "--clean", "--if-exists", "--no-owner",
                 "--no-acl", "--exit-on-error",
                 "--dbname", database_name(target_dsn), str(archive)],
                env=pg_environment(target_dsn), runner=runner)
    store = OrderStore.postgres(target_dsn)
    try:
        verified = verify_store(store)
    finally:
        store.close()
    return {"restored_to": target_name, "verification": verified}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("bootstrap", help="idempotently create the production schema")
    sub.add_parser("verify", help="verify tables, immutable-order trigger and counts")
    backup_parser = sub.add_parser("backup", help="create a restricted custom archive")
    backup_parser.add_argument("--out", required=True, type=Path)
    backup_parser.add_argument("--overwrite", action="store_true")
    restore_parser = sub.add_parser(
        "restore-drill", help="restore into a separate disposable database")
    restore_parser.add_argument("--archive", required=True, type=Path)
    restore_parser.add_argument("--confirm-target", action="store_true")
    args = parser.parse_args()

    try:
        if args.command == "backup":
            result = backup(dsn_from_env("CHERRY_DATABASE_URL"), args.out,
                            overwrite=args.overwrite)
        elif args.command == "restore-drill":
            result = restore_drill(
                args.archive, dsn_from_env("CHERRY_RESTORE_DATABASE_URL"),
                confirmed=args.confirm_target)
        else:
            dsn = dsn_from_env("CHERRY_DATABASE_URL")
            store = OrderStore.postgres(dsn, bootstrap=args.command == "bootstrap")
            try:
                result = verify_store(store)
            finally:
                store.close()
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}))
        return 1
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
