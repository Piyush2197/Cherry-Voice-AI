"""
The menu schema — a restaurant as one YAML file.

WHY THIS EXISTS
---------------
Until now a restaurant was a Python file. That made onboarding a coding task:
whoever enters the menu has to know Python, and a typo is a syntax error in
the middle of a config. It also meant the menu could not be handed to the
restaurant owner, edited in a spreadsheet, or diffed meaningfully.

A restaurant is data. This module makes it data:

    menus/naked-burger.yaml  ->  load_yaml()  ->  RestaurantConfig

and back out again with dump_yaml(), so the seven configs already written in
Python can be exported and the round trip verified.

MONEY IN YAML
-------------
Prices are written the way a human writes them — `price: 15.00` — and parsed
through Decimal, never float. `15.10` becomes exactly 1510 cents. A price
that cannot be represented exactly in cents is an error, not a rounding.
`price_cents:` is also accepted where someone wants to be explicit.

VALIDATION
----------
validate_doc() checks the document's SHAPE and reports every problem with the
path to the offending key, before anything is constructed. It is deliberately
separate from config_validator.lint_config(), which checks the MEANING of a
config that already parsed. Two different failures:

    schema error  -> "items[3].price: expected a number, got 'ask'"
    lint error    -> "group:spice: required group has no prompt"

Both must pass before a restaurant goes live.
"""

from __future__ import annotations

import _ensure_deps  # noqa: F401  (re-runs under .venv, or says how to install, if PyYAML is missing)
import json
from dataclasses import asdict
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

import yaml

from order_engine import (
    FreeAllowancePolicy,
    MenuItem,
    ModifierGroup,
    ModifierOption,
    RestaurantConfig,
    SizeVariant,
)
from menu_enrichment import ALLERGENS, DIETARY, contradictions, tag_list

SCHEMA_VERSION = 1


class SchemaError(Exception):
    """Raised with every problem found, not just the first."""

    def __init__(self, problems: List[str]) -> None:
        self.problems = problems
        super().__init__(f"{len(problems)} schema problem(s):\n  " +
                         "\n  ".join(problems))


# ---------------------------------------------------------------------------
# Money
# ---------------------------------------------------------------------------


def to_cents(value: Any, where: str, problems: List[str]) -> Optional[int]:
    """Parse a YAML price into integer cents, exactly.

    Accepts 15, 15.0, 15.00, "15.00", "$15.00". Rejects anything that would
    need rounding — a menu price that is not a whole number of cents is a
    data-entry mistake, and silently rounding it is how a config ends up a
    penny off on every order.
    """
    if value is None:
        return None
    if isinstance(value, bool):
        problems.append(f"{where}: expected a price, got a boolean")
        return None
    text = str(value).strip().replace("$", "").replace(",", "")
    if not text:
        return None
    try:
        dec = Decimal(text)
    except InvalidOperation:
        problems.append(f"{where}: expected a number, got {value!r}")
        return None
    cents = dec * 100
    if cents != cents.to_integral_value():
        problems.append(
            f"{where}: {value!r} is not a whole number of cents")
        return None
    if cents < 0:
        problems.append(f"{where}: negative price {value!r}")
        return None
    return int(cents)


def from_cents(cents: int) -> str:
    """Render cents back as a YAML-friendly price string."""
    return f"{cents // 100}.{cents % 100:02d}"


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

_OPTION_KEYS = {"id", "name", "aliases", "description", "price", "price_cents",
                "price_by_size", "available", "default", "reveals",
                "max_quantity", "tags", "pos_refs"}
_GROUP_KEYS = {"id", "name", "prompt", "prompt_more", "options", "min", "max",
               "free", "free_policy", "defaults", "allow_negate_defaults",
               "placement", "half_placement_multiplier", "reveal_only",
               "informational", "confirm"}
_ITEM_KEYS = {"id", "name", "category", "aliases", "description", "price",
              "price_cents", "sizes", "groups", "available", "taxable", "tags",
              "allergens", "dietary", "pos_refs"}
_SIZE_KEYS = {"id", "name", "price", "price_cents", "aliases", "available"}
_RESTAURANT_KEYS = {"id", "name", "cuisine", "tax_rate_bps",
                    "pay_now_threshold_cents", "pay_now_basis", "pos_type",
                    "currency", "notes"}


def _check_keys(d: dict, allowed: set, where: str, problems: List[str]) -> None:
    for k in d:
        if k not in allowed:
            close = [a for a in allowed if a.startswith(str(k)[:3])]
            hint = f" (did you mean {close[0]}?)" if close else ""
            problems.append(f"{where}: unknown key {k!r}{hint}")


def _str_list(value: Any, where: str, problems: List[str]) -> Tuple[str, ...]:
    if value is None:
        return ()
    if isinstance(value, str):
        problems.append(f"{where}: expected a list, got a string — "
                        f"write it as [{value!r}]")
        return ()
    if not isinstance(value, list):
        problems.append(f"{where}: expected a list, got {type(value).__name__}")
        return ()
    out = []
    for i, v in enumerate(value):
        if not isinstance(v, str):
            problems.append(f"{where}[{i}]: expected text, got {v!r}")
            continue
        out.append(v)
    return tuple(out)


def validate_doc(doc: Any) -> List[str]:
    """Return every shape problem in the document. Empty list means valid."""
    problems: List[str] = []
    if not isinstance(doc, dict):
        return ["top level: expected a mapping with "
                "restaurant/options/groups/items"]

    for required in ("restaurant", "items"):
        if required not in doc:
            problems.append(f"top level: missing required section {required!r}")

    for k in doc:
        if k not in {"schema_version", "restaurant", "options", "groups",
                     "items"}:
            problems.append(f"top level: unknown section {k!r}")

    r = doc.get("restaurant")
    if isinstance(r, dict):
        _check_keys(r, _RESTAURANT_KEYS, "restaurant", problems)
        for req in ("id", "name", "cuisine"):
            if not r.get(req):
                problems.append(f"restaurant.{req}: required")
        basis = r.get("pay_now_basis", "subtotal")
        if basis not in ("subtotal", "total"):
            problems.append(f"restaurant.pay_now_basis: must be 'subtotal' or "
                            f"'total', got {basis!r}")
        tr = r.get("tax_rate_bps", 0)
        if not isinstance(tr, int) or isinstance(tr, bool) or tr < 0 or tr > 3000:
            problems.append(f"restaurant.tax_rate_bps: expected basis points "
                            f"0-3000 (600 = 6%), got {tr!r}")
    elif r is not None:
        problems.append("restaurant: expected a mapping")

    for section, keys in (("options", _OPTION_KEYS), ("groups", _GROUP_KEYS),
                          ("items", _ITEM_KEYS)):
        rows = doc.get(section) or []
        if not isinstance(rows, list):
            problems.append(f"{section}: expected a list")
            continue
        seen_ids = set()
        for i, row in enumerate(rows):
            where = f"{section}[{i}]"
            if not isinstance(row, dict):
                problems.append(f"{where}: expected a mapping")
                continue
            _check_keys(row, keys, where, problems)
            rid = row.get("id")
            name = row.get("name")
            if not rid:
                problems.append(f"{where}.id: required")
            elif rid in seen_ids:
                problems.append(f"{where}.id: duplicate id {rid!r}")
            else:
                seen_ids.add(rid)
            if not name:
                problems.append(f"{where}.name: required")
            if "price" in row:
                to_cents(row["price"], f"{where}.price", problems)
            if "price_cents" in row and not isinstance(row["price_cents"], int):
                problems.append(f"{where}.price_cents: expected whole cents")
            for lk in ("aliases", "tags"):
                if lk in row:
                    _str_list(row[lk], f"{where}.{lk}", problems)
            if "description" in row and not isinstance(row["description"], str):
                problems.append(f"{where}.description: expected text, got "
                                f"{type(row['description']).__name__}")

    # group-specific
    for i, g in enumerate(doc.get("groups") or []):
        if not isinstance(g, dict):
            continue
        where = f"groups[{i}]"
        mn, mx = g.get("min", 0), g.get("max", 1)
        for label, v in (("min", mn), ("max", mx)):
            if not isinstance(v, int) or isinstance(v, bool) or v < 0:
                problems.append(f"{where}.{label}: expected a whole number, "
                                f"got {v!r}")
        if isinstance(mn, int) and isinstance(mx, int) and mn > mx:
            problems.append(f"{where}: min {mn} is greater than max {mx}")
        fp = g.get("free_policy", "most_expensive")
        if fp not in {p.value for p in FreeAllowancePolicy}:
            problems.append(f"{where}.free_policy: must be one of "
                            f"{sorted(p.value for p in FreeAllowancePolicy)}")
        _str_list(g.get("options"), f"{where}.options", problems)
        _str_list(g.get("defaults"), f"{where}.defaults", problems)

    # item-specific
    for i, it in enumerate(doc.get("items") or []):
        if not isinstance(it, dict):
            continue
        where = f"items[{i}]"
        _str_list(it.get("groups"), f"{where}.groups", problems)
        sizes = it.get("sizes")
        if sizes is not None:
            if not isinstance(sizes, list):
                problems.append(f"{where}.sizes: expected a list")
            else:
                for j, s in enumerate(sizes):
                    sw = f"{where}.sizes[{j}]"
                    if not isinstance(s, dict):
                        problems.append(f"{sw}: expected a mapping")
                        continue
                    _check_keys(s, _SIZE_KEYS, sw, problems)
                    if not s.get("id"):
                        problems.append(f"{sw}.id: required")
                    if not s.get("name"):
                        problems.append(f"{sw}.name: required")
                    if "price" in s:
                        to_cents(s["price"], f"{sw}.price", problems)
        has_price = it.get("price") is not None or it.get("price_cents") is not None
        if not sizes and not has_price:
            problems.append(f"{where}: needs a price, or sizes with prices — "
                            f"an item with no price cannot be ordered")

        # Enrichment. Unknown or ambiguous values are rejected here rather than
        # stored, because a stored typo is a fact the agent would repeat.
        allergens = tag_list(it.get("allergens"), ALLERGENS, "allergen",
                             f"{where}.allergens", problems)
        dietary = tag_list(it.get("dietary"), DIETARY, "dietary tag",
                           f"{where}.dietary", problems)
        for c in contradictions(allergens, dietary):
            problems.append(f"{where}: {c}")

    return problems


# ---------------------------------------------------------------------------
# Load
# ---------------------------------------------------------------------------


def _price_of(row: dict, where: str, problems: List[str]) -> int:
    if row.get("price_cents") is not None:
        return int(row["price_cents"])
    c = to_cents(row.get("price"), where, problems)
    return c or 0


def build_config(doc: dict) -> RestaurantConfig:
    """Turn a validated document into a RestaurantConfig."""
    problems = validate_doc(doc)
    if problems:
        raise SchemaError(problems)

    r = doc["restaurant"]
    opts: List[ModifierOption] = []
    for i, o in enumerate(doc.get("options") or []):
        w = f"options[{i}]"
        by_size = {}
        for sid, v in (o.get("price_by_size") or {}).items():
            c = to_cents(v, f"{w}.price_by_size.{sid}", problems)
            if c is not None:
                by_size[sid] = c
        opts.append(ModifierOption(
            id=o["id"], name=o["name"],
            aliases=tuple(o.get("aliases") or ()),
            description=str(o.get("description", "") or ""),
            price_cents=_price_of(o, f"{w}.price", problems),
            price_by_size=by_size,
            available=bool(o.get("available", True)),
            is_default=bool(o.get("default", False)),
            reveals_group_ids=tuple(o.get("reveals") or ()),
            max_quantity=int(o.get("max_quantity", 1)),
            tags=tuple(o.get("tags") or ()),
            pos_refs=dict(o.get("pos_refs") or {}),
        ))

    groups: List[ModifierGroup] = []
    for g in doc.get("groups") or []:
        groups.append(ModifierGroup(
            id=g["id"], name=g["name"],
            prompt=g.get("prompt", "") or "",
            prompt_more=g.get("prompt_more", "") or "",
            option_ids=tuple(g.get("options") or ()),
            min_select=int(g.get("min", 0)),
            max_select=int(g.get("max", 1)),
            free_select=int(g.get("free", 0)),
            free_policy=FreeAllowancePolicy(
                g.get("free_policy", "most_expensive")),
            default_option_ids=tuple(g.get("defaults") or ()),
            allow_negate_defaults=bool(g.get("allow_negate_defaults", True)),
            placement_enabled=bool(g.get("placement", False)),
            half_placement_multiplier=Decimal(
                str(g.get("half_placement_multiplier", "0.5"))),
            reveal_only=bool(g.get("reveal_only", False)),
            informational=bool(g.get("informational", False)),
            confirmation_required=bool(g.get("confirm", False)),
        ))

    items: List[MenuItem] = []
    for i, it in enumerate(doc["items"]):
        w = f"items[{i}]"
        sizes = []
        for j, s in enumerate(it.get("sizes") or []):
            sizes.append(SizeVariant(
                id=s["id"], name=s["name"],
                price_cents=_price_of(s, f"{w}.sizes[{j}].price", problems),
                aliases=tuple(s.get("aliases") or ()),
                available=bool(s.get("available", True)),
            ))
        items.append(MenuItem(
            id=it["id"], name=it["name"],
            category=it.get("category", "general"),
            aliases=tuple(it.get("aliases") or ()),
            description=str(it.get("description", "") or ""),
            base_price_cents=0 if sizes else _price_of(it, f"{w}.price", problems),
            sizes=tuple(sizes),
            modifier_group_ids=tuple(it.get("groups") or ()),
            available=bool(it.get("available", True)),
            taxable=bool(it.get("taxable", True)),
            tags=tuple(it.get("tags") or ()),
            allergens=tag_list(it.get("allergens"), ALLERGENS, "allergen",
                               f"{w}.allergens", problems),
            dietary=tag_list(it.get("dietary"), DIETARY, "dietary tag",
                             f"{w}.dietary", problems),
            pos_refs=dict(it.get("pos_refs") or {}),
        ))

    if problems:
        raise SchemaError(problems)

    return RestaurantConfig(
        id=r["id"], name=r["name"], cuisine=r["cuisine"],
        items=tuple(items), groups=tuple(groups), options=tuple(opts),
        tax_rate_bps=int(r.get("tax_rate_bps", 0)),
        pay_now_threshold_cents=int(r.get("pay_now_threshold_cents", 3000)),
        pay_now_basis=r.get("pay_now_basis", "subtotal"),
        pos_type=r.get("pos_type", "manual_fallback"),
        currency=r.get("currency", "USD"),
    )


def load_yaml(path: Union[str, Path]) -> RestaurantConfig:
    doc = yaml.safe_load(Path(path).read_text())
    return build_config(doc)


def load_all(directory: Union[str, Path]) -> Dict[str, RestaurantConfig]:
    """Load every .yaml in a directory. This is how production should load
    restaurants: a folder of data files, no imports."""
    out: Dict[str, RestaurantConfig] = {}
    for p in sorted(Path(directory).glob("*.yaml")):
        cfg = load_yaml(p)
        out[cfg.id] = cfg
    return out


# ---------------------------------------------------------------------------
# Dump
# ---------------------------------------------------------------------------


def to_doc(config: RestaurantConfig) -> dict:
    """RestaurantConfig -> plain document, for round-tripping."""
    def opt_row(o: ModifierOption) -> dict:
        row: Dict[str, Any] = {"id": o.id, "name": o.name}
        if o.aliases:
            row["aliases"] = list(o.aliases)
        if o.description:
            row["description"] = o.description
        if o.price_cents:
            row["price"] = from_cents(o.price_cents)
        if o.price_by_size:
            row["price_by_size"] = {k: from_cents(v)
                                    for k, v in o.price_by_size.items()}
        if not o.available:
            row["available"] = False
        if o.is_default:
            row["default"] = True
        if o.reveals_group_ids:
            row["reveals"] = list(o.reveals_group_ids)
        if o.max_quantity != 1:
            row["max_quantity"] = o.max_quantity
        if o.tags:
            row["tags"] = list(o.tags)
        if o.pos_refs:
            row["pos_refs"] = dict(o.pos_refs)
        return row

    def grp_row(g: ModifierGroup) -> dict:
        row: Dict[str, Any] = {"id": g.id, "name": g.name}
        if g.prompt:
            row["prompt"] = g.prompt
        if g.prompt_more:
            row["prompt_more"] = g.prompt_more
        row["options"] = list(g.option_ids)
        if g.min_select:
            row["min"] = g.min_select
        if g.max_select != 1:
            row["max"] = g.max_select
        if g.free_select:
            row["free"] = g.free_select
        if g.free_policy is not FreeAllowancePolicy.MOST_EXPENSIVE:
            row["free_policy"] = g.free_policy.value
        if g.default_option_ids:
            row["defaults"] = list(g.default_option_ids)
        if not g.allow_negate_defaults:
            row["allow_negate_defaults"] = False
        if g.placement_enabled:
            row["placement"] = True
            row["half_placement_multiplier"] = str(g.half_placement_multiplier)
        if g.reveal_only:
            row["reveal_only"] = True
        if g.informational:
            row["informational"] = True
        if g.confirmation_required:
            row["confirm"] = True
        return row

    def item_row(i: MenuItem) -> dict:
        row: Dict[str, Any] = {"id": i.id, "name": i.name}
        if i.category != "general":
            row["category"] = i.category
        if i.aliases:
            row["aliases"] = list(i.aliases)
        if i.description:
            row["description"] = i.description
        if i.has_sizes:
            row["sizes"] = [
                {"id": s.id, "name": s.name, "price": from_cents(s.price_cents),
                 **({"aliases": list(s.aliases)} if s.aliases else {}),
                 **({} if s.available else {"available": False})}
                for s in i.sizes]
        else:
            row["price"] = from_cents(i.base_price_cents)
        if i.modifier_group_ids:
            row["groups"] = list(i.modifier_group_ids)
        if not i.available:
            row["available"] = False
        if not i.taxable:
            row["taxable"] = False
        if i.tags:
            row["tags"] = list(i.tags)
        if i.allergens:
            row["allergens"] = list(i.allergens)
        if i.dietary:
            row["dietary"] = list(i.dietary)
        if i.pos_refs:
            row["pos_refs"] = dict(i.pos_refs)
        return row

    return {
        "schema_version": SCHEMA_VERSION,
        "restaurant": {
            "id": config.id, "name": config.name, "cuisine": config.cuisine,
            "tax_rate_bps": config.tax_rate_bps,
            "pay_now_threshold_cents": config.pay_now_threshold_cents,
            "pay_now_basis": config.pay_now_basis,
            "pos_type": config.pos_type,
            "currency": config.currency,
        },
        "options": [opt_row(o) for o in config.options],
        "groups": [grp_row(g) for g in config.groups],
        "items": [item_row(i) for i in config.items],
    }


def dump_yaml(config: RestaurantConfig, path: Union[str, Path, None] = None) -> str:
    text = yaml.safe_dump(to_doc(config), sort_keys=False, allow_unicode=True,
                          width=100)
    if path is not None:
        Path(path).write_text(text)
    return text


def configs_equal(a: RestaurantConfig, b: RestaurantConfig) -> List[str]:
    """Structural comparison, used by the round-trip test. Returns differences."""
    diffs: List[str] = []
    ja, jb = json.dumps(to_doc(a), sort_keys=True), json.dumps(to_doc(b), sort_keys=True)
    if ja == jb:
        return diffs
    da, db = to_doc(a), to_doc(b)
    for section in ("restaurant", "options", "groups", "items"):
        if json.dumps(da[section], sort_keys=True) != json.dumps(db[section], sort_keys=True):
            if isinstance(da[section], list):
                for x, y in zip(da[section], db[section]):
                    if x != y:
                        diffs.append(f"{section}: {x.get('id')} differs: "
                                     f"{x} != {y}")
                if len(da[section]) != len(db[section]):
                    diffs.append(f"{section}: length "
                                 f"{len(da[section])} != {len(db[section])}")
            else:
                diffs.append(f"{section}: {da[section]} != {db[section]}")
    return diffs or ["documents differ"]
