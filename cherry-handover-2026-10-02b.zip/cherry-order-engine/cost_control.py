#!/usr/bin/env python3
"""Usage-plan enforcement and measurable cost savings.

Each location has a stored plan (schema v6, ``location_plan``; a missing row
means Small, the launch default). The plan's monthly minute allowance is the
controlling limit (PRICING_PLANS_2026-09-23.md): a location is reviewed for
an upgrade only after three *completed* billing months above its own
allowance. The current partial month is shown for warning purposes but never
counts toward the streak. The daily-call figure is a usage-review signal for
the operations monitor — it pages once a day, never interrupts a call.
"""
from __future__ import annotations

import argparse
import json
import math
from collections import defaultdict
from datetime import date, datetime, timezone
from typing import Any, Dict, List, Optional

from order_store import OrderStore

PLANS = {
    # Per the 28 Sep 2026 pricing (sales workbook), plans are sold by
    # calls/day: Small 50, Medium 65, Large 100 — a cap that never cuts a
    # call off; exceeding it starts a plan conversation. The monthly-minute
    # figures below are the usage-review measure kept from the original
    # 23 Sep tiers and drive the completed-month upgrade review.
    "small": {"monthly_minutes": 3000.0, "daily_calls": 50},
    "medium": {"monthly_minutes": 5000.0, "daily_calls": 65},
    "grande": {"monthly_minutes": 10000.0, "daily_calls": 100},
}
DEFAULT_PLAN = "small"
UPGRADE_AFTER_CONSECUTIVE_MONTHS = 3
SMS_COST_PER_SEGMENT = 0.008


def _month(value: str) -> str:
    return str(value)[:7]


def _previous_months(now: datetime, count: int) -> List[str]:
    year, month = now.year, now.month
    out = []
    for _ in range(count):
        month -= 1
        if month == 0:
            year, month = year - 1, 12
        out.append(f"{year:04d}-{month:02d}")
    return out


def set_plan(store: OrderStore, restaurant_id: str, plan: str) -> None:
    """Store a location's plan tier; validates against the approved plans."""
    if plan not in PLANS:
        raise ValueError(f"unknown plan {plan!r}; expected one of "
                         f"{', '.join(sorted(PLANS))}")
    with store.tx() as conn:
        conn.execute("""
            INSERT INTO location_plan (restaurant_id, plan, updated_at)
            VALUES (?,?,?)
            ON CONFLICT (restaurant_id) DO UPDATE
            SET plan=excluded.plan, updated_at=excluded.updated_at
        """, (restaurant_id, plan,
              datetime.now(timezone.utc).isoformat(timespec="seconds")))


def location_plans(store: OrderStore) -> Dict[str, str]:
    """Every stored plan; locations missing from the result are on Small."""
    rows = store.conn.execute(
        "SELECT restaurant_id, plan FROM location_plan").fetchall()
    return {row["restaurant_id"]: row["plan"] for row in rows}


def plan_of(store: OrderStore, restaurant_id: str,
            plans: Optional[Dict[str, str]] = None) -> str:
    if plans is None:
        plans = location_plans(store)
    return plans.get(restaurant_id, DEFAULT_PLAN)


def monthly_voice_minutes(store: OrderStore,
                          restaurant_id: str = "") -> Dict[str, Dict[str, float]]:
    where = " WHERE s.restaurant_id=?" if restaurant_id else ""
    params = (restaurant_id,) if restaurant_id else ()
    rows = store.conn.execute("""SELECT s.restaurant_id,s.started_at,
        v.transcribed_audio_ms FROM voice_usage v
        JOIN session s ON s.id=v.session_id""" + where, params).fetchall()
    totals: Dict[str, Dict[str, float]] = defaultdict(lambda: defaultdict(float))
    for row in rows:
        totals[row["restaurant_id"]][_month(row["started_at"])] += (
            int(row["transcribed_audio_ms"] or 0) / 60000.0)
    return {rid: dict(months) for rid, months in totals.items()}


def daily_voice_calls(store: OrderStore, *, day: Optional[date] = None,
                      now: Optional[datetime] = None) -> Dict[str, int]:
    """Voice calls started per location on one UTC day, for plan thresholds."""
    now = now or datetime.now(timezone.utc)
    day = day or now.date()
    start = datetime(day.year, day.month, day.day, tzinfo=timezone.utc)
    end_day = date.fromordinal(day.toordinal() + 1)
    end = datetime(end_day.year, end_day.month, end_day.day, tzinfo=timezone.utc)
    rows = store.conn.execute("""
        SELECT restaurant_id, COUNT(*) AS n FROM session
        WHERE channel='voice' AND started_at>=? AND started_at<?
        GROUP BY restaurant_id
    """, (start.isoformat(timespec="seconds"), end.isoformat(timespec="seconds"))
    ).fetchall()
    return {row["restaurant_id"]: int(row["n"]) for row in rows}


def plan_reviews(store: OrderStore, *, now: Optional[datetime] = None,
                 streak_required: int = UPGRADE_AFTER_CONSECUTIVE_MONTHS
                 ) -> List[Dict[str, Any]]:
    now = now or datetime.now(timezone.utc)
    usage = monthly_voice_minutes(store)
    plans = location_plans(store)
    completed = _previous_months(now, streak_required)
    current = f"{now.year:04d}-{now.month:02d}"
    restaurants = store.conn.execute(
        "SELECT id,name FROM restaurant WHERE active=TRUE ORDER BY name").fetchall()
    out = []
    for rest in restaurants:
        plan = plans.get(rest["id"], DEFAULT_PLAN)
        included_minutes = PLANS[plan]["monthly_minutes"]
        months = usage.get(rest["id"], {})
        values = [round(months.get(m, 0.0), 2) for m in completed]
        streak = 0
        for value in values:  # newest completed month first
            if value <= included_minutes:
                break
            streak += 1
        current_minutes = round(months.get(current, 0.0), 2)
        out.append({
            "restaurant_id": rest["id"], "restaurant_name": rest["name"],
            "plan": plan, "included_minutes": included_minutes,
            "current_month": current, "current_minutes": current_minutes,
            "current_percent": round(current_minutes / included_minutes * 100, 1),
            "completed_months": [
                {"month": month, "minutes": value,
                 "over": value > included_minutes}
                for month, value in zip(completed, values)],
            "consecutive_completed_months_over": streak,
            "action": "upgrade_plan" if streak >= streak_required else
                      "watch" if current_minutes > included_minutes or streak else
                      "stay_on_plan",
        })
    return out


def sms_segments(text: str) -> int:
    """Conservative GSM/Unicode segment estimate for cost reporting."""
    if not text:
        return 0
    gsm = all(ord(char) < 128 for char in text)
    single, joined = (160, 153) if gsm else (70, 67)
    return 1 if len(text) <= single else math.ceil(len(text) / joined)


def savings_report(store: OrderStore, *, restaurant_id: str = "") -> Dict[str, Any]:
    where = " WHERE restaurant_id=?" if restaurant_id else ""
    params = (restaurant_id,) if restaurant_id else ()
    messages = store.conn.execute(
        "SELECT kind,body FROM sms_message" + where, params).fetchall()
    by_kind: Dict[str, int] = defaultdict(int)
    for row in messages:
        by_kind[row["kind"]] += sms_segments(row["body"])
    total_segments = sum(by_kind.values())
    ticket_segments = by_kind.get("ticket", 0)
    usage = monthly_voice_minutes(store, restaurant_id)
    voice_minutes = round(sum(sum(months.values()) for months in usage.values()), 2)
    calls_where = " WHERE restaurant_id=? AND channel='voice'" if restaurant_id \
        else " WHERE channel='voice'"
    calls = int(store.conn.execute(
        "SELECT count(*) AS n FROM session" + calls_where, params).fetchone()["n"])
    shorten_minutes = calls * 15 / 60.0
    return {
        "scope": restaurant_id or "fleet",
        "measured": {"voice_minutes": voice_minutes, "voice_calls": calls,
                     "sms_segments": total_segments,
                     "sms_segments_by_kind": dict(sorted(by_kind.items()))},
        "opportunities": [
            {"name": "native_pos_kitchen_delivery",
             "monthly_savings_at_observed_volume": round(
                 ticket_segments * SMS_COST_PER_SEGMENT, 2),
             "note": "Removes kitchen ticket SMS only. Keep the customer review/payment text."},
            {"name": "shorten_average_call_by_15_seconds",
             "minutes_saved_at_observed_volume": round(shorten_minutes, 2),
             "note": "Use only after transcript review proves accuracy is unchanged."},
            {"name": "keep_customer_review_and_payment_in_one_text",
             "note": "Do not send separate review and payment messages when one POS-hosted link can do both."},
            {"name": "right_size_provider_tier",
             "note": "Review fleet usage monthly; tier fees and credits are shared across locations."},
        ],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("plans", "savings", "set-plan"))
    parser.add_argument("--db", required=True)
    parser.add_argument("--restaurant", default="")
    parser.add_argument("--plan", choices=sorted(PLANS), default="")
    args = parser.parse_args()
    store = OrderStore.open(args.db)
    if args.command == "set-plan":
        if not args.restaurant or not args.plan:
            parser.error("set-plan needs --restaurant and --plan")
        # The id as stored. (It was being rewritten to the SQUARE_TOKEN_* style,
        # MY_RESTAURANT, which is never a restaurant id, so the plan could not
        # be saved at all.)
        rid = args.restaurant
        if store.restaurant(rid) is None:
            parser.error(f"no restaurant {rid!r}")
        set_plan(store, rid, args.plan)
        result = {"restaurant_id": rid, "plan": args.plan}
    else:
        result = (plan_reviews(store) if args.command == "plans" else
                  savings_report(store, restaurant_id=args.restaurant))
    print(json.dumps(result, indent=2, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
