"""
Tests for the order store, the sinks, and the payment relay.

The two things these exist to prove:
  1. A placed order is immutable and reprints exactly as the kitchen saw it,
     no matter what the menu does afterwards.
  2. No payment data can be stored, by structure and by guard.
"""

from __future__ import annotations

import re
import traceback
from dataclasses import replace
from pathlib import Path

import menu_schema as ms
import payments as pay
from order_engine import OrderEngine
from order_store import OrderStore
from sinks import (FakeSmsSender, ManualSink, SinkContext, ToastSink,
                   deliver, format_ticket, sink_for)

HERE = Path(__file__).parent
MENUS = HERE / "menus"


def _fixture(menu="bun-n-run-ferndale", sink="manual"):
    store = OrderStore.sqlite()
    # These legacy sink tests intentionally exercise the pay-at-pickup branch.
    # Pilot catalogs use checkout for *every* amount; test_payment_gate.py
    # separately exercises those real catalog settings.
    yaml_text = (MENUS / f"{menu}.yaml").read_text().replace(
        "pay_now_threshold_cents: 0", "pay_now_threshold_cents: 3000")
    cfg = replace(ms.load_yaml(MENUS / f"{menu}.yaml"),
                  pay_now_threshold_cents=3000)
    store.upsert_restaurant(cfg.id, cfg.name, cfg.cuisine,
                            tax_rate_bps=cfg.tax_rate_bps, sink=sink,
                            staff_phone="+13135550100",
                            inbound_phone="+13135550199", active=True)
    mv = store.publish_menu(cfg.id, yaml_text, item_count=len(cfg.items))
    return store, cfg, mv


def _an_order(store, cfg, mv, item="double_cheeseburger", qty=1,
              phone="+13135550123"):
    e = OrderEngine(cfg)
    line = e.add_line(item, quantity=qty)
    for gid in e.active_group_ids(line):
        g = cfg.group(gid)
        if g and g.required:
            e.apply_option(line.line_id, gid, g.option_ids[0])
    snap = e.to_normalized_order()
    return store.place_order(cfg.id, mv, snap, channel="voice",
                             customer_phone=phone)


# --- store ----------------------------------------------------------------


def t_publish_menu_versions_and_dedupes():
    store, cfg, mv = _fixture()
    text = (MENUS / "bun-n-run-ferndale.yaml").read_text().replace(
        "pay_now_threshold_cents: 0", "pay_now_threshold_cents: 3000")
    again = store.publish_menu(cfg.id, text, item_count=len(cfg.items))
    assert again == mv, "republishing identical YAML must not make a new version"
    changed = store.publish_menu(cfg.id, text + "\n# edited\n",
                                 item_count=len(cfg.items))
    assert changed != mv
    live = store.live_menu(cfg.id)
    assert live["id"] == changed and live["version"] == 2


def t_only_one_live_menu():
    store, cfg, mv = _fixture()
    text = (MENUS / "bun-n-run-ferndale.yaml").read_text()
    store.publish_menu(cfg.id, text + "\n# v2\n", item_count=1)
    rows = store.conn.execute(
        "SELECT COUNT(*) c FROM menu_version WHERE restaurant_id=? AND is_live",
        (cfg.id,)).fetchone()
    assert rows["c"] == 1


def t_restaurant_is_found_by_dialled_number():
    store, cfg, mv = _fixture()
    row = store.restaurant_for_number("+13135550199")
    assert row and row["id"] == cfg.id
    assert store.restaurant_for_number("+15550000000") is None


def t_order_is_immutable():
    store, cfg, mv = _fixture()
    oid, code = _an_order(store, cfg, mv)
    try:
        with store.tx() as c:
            c.execute('UPDATE "order" SET total_cents=1 WHERE id=?', (oid,))
    except Exception as exc:
        assert "immutable" in str(exc).lower(), exc
    else:
        raise AssertionError("order totals were editable")
    # status may still move
    store.set_order_status(oid, "ready")
    assert store.order(oid)["status"] == "ready"


def t_order_reprints_identically_after_a_price_change():
    """The whole reason snapshots exist."""
    store, cfg, mv = _fixture()
    oid, code = _an_order(store, cfg, mv)
    before = store.order_snapshot(oid)
    ticket_before = format_ticket(before, code)

    # the restaurant puts prices up and republishes
    text = (MENUS / "bun-n-run-ferndale.yaml").read_text()
    store.publish_menu(cfg.id, text.replace("price: '9.95'", "price: '12.95'"),
                       item_count=len(cfg.items))

    after = store.order_snapshot(oid)
    assert after == before
    assert format_ticket(after, code) == ticket_before
    assert store.order(oid)["menu_version_id"] == mv


def t_simultaneous_callers_that_pick_the_same_code_both_get_orders():
    """Choosing a free short code and inserting it are separate steps; two
    callers finishing together used to collide and one order was lost."""
    import threading
    store, cfg, mv = _fixture()
    codes = iter(["1234"] * 4 + [str(2000 + i) for i in range(50)])
    lock = threading.Lock()

    def scripted(_restaurant_id):
        with lock:
            return next(codes)
    store._short_code = scripted
    out, errors = [], []

    def caller(n):
        try:
            out.append(_an_order(store, cfg, mv, phone=f"+1313555{n:04d}"))
        except Exception as exc:                              # noqa: BLE001
            errors.append(repr(exc))
    threads = [threading.Thread(target=caller, args=(n,)) for n in range(4)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    assert not errors, errors
    assert len({code for _oid, code in out}) == 4


def t_snapshot_must_be_complete():
    store, cfg, mv = _fixture()
    try:
        store.place_order(cfg.id, mv, {"lines": []})
    except ValueError as exc:
        assert "missing" in str(exc)
    else:
        raise AssertionError("stored an order that cannot be reprinted")


def t_short_codes_are_unique_per_restaurant():
    store, cfg, mv = _fixture()
    codes = {_an_order(store, cfg, mv)[1] for _ in range(40)}
    assert len(codes) == 40
    assert all(re.fullmatch(r"[0-9A-F]{4,6}", c) for c in codes)


def t_session_is_idempotent_on_external_id():
    """A replayed Telnyx webhook must not open a second call."""
    store, cfg, mv = _fixture()
    a = store.start_session(cfg.id, mv, external_id="telnyx-call-1")
    b = store.start_session(cfg.id, mv, external_id="telnyx-call-1")
    assert a == b
    assert len(store.open_sessions(cfg.id)) == 1


def t_turns_are_recorded_in_order():
    store, cfg, mv = _fixture()
    sid = store.start_session(cfg.id, mv, external_id="c1")
    store.record_turn(sid, "agent", "What can I get you?")
    store.record_turn(sid, "caller", "a double cheeseburger",
                      asr_confidence=0.91)
    store.record_turn(sid, "agent", "Any changes?",
                      engine_issue_code="missing_required_group")
    rows = store.conn.execute(
        "SELECT * FROM turn WHERE session_id=? ORDER BY seq", (sid,)).fetchall()
    assert [r["seq"] for r in rows] == [1, 2, 3]
    assert rows[1]["asr_confidence"] == 0.91
    assert rows[2]["engine_issue_code"] == "missing_required_group"


def t_cart_survives_between_turns_and_clears_at_end():
    store, cfg, mv = _fixture()
    sid = store.start_session(cfg.id, mv, external_id="c2")
    store.save_cart(sid, {"lines": [{"item_id": "cheeseburger"}]})
    assert store.load_cart(sid)["lines"][0]["item_id"] == "cheeseburger"
    store.end_session(sid, "completed")
    assert store.load_cart(sid) is None


def t_86_applies_to_the_live_config_without_touching_the_menu():
    store, cfg, mv = _fixture()
    loaded, _ = store.load_live_config(cfg.id)
    assert loaded.item("wild_fries").available

    store.set_availability(cfg.id, "wild_fries", False, reason="sold out")
    loaded, _ = store.load_live_config(cfg.id)
    assert loaded.item("wild_fries").available is False
    # and the stored menu is untouched, so it can come back tomorrow
    assert "wild_fries" in store.live_menu(cfg.id)["yaml"]

    store.set_availability(cfg.id, "wild_fries", True)
    loaded, _ = store.load_live_config(cfg.id)
    assert loaded.item("wild_fries").available


def t_expired_86_stops_applying():
    store, cfg, mv = _fixture()
    store.set_availability(cfg.id, "wild_fries", False,
                           expires_at="2000-01-01T00:00:00+00:00")
    loaded, _ = store.load_live_config(cfg.id)
    assert loaded.item("wild_fries").available, "an expired 86 must lapse"


# --- sinks ----------------------------------------------------------------


def t_manual_sink_texts_a_ticket():
    store, cfg, mv = _fixture()
    oid, code = _an_order(store, cfg, mv)
    sms = FakeSmsSender()
    res = deliver(store, oid, ManualSink(sms), sleep=lambda s: None)
    assert res.ok and res.external_ref
    assert len(sms.sent) == 1
    body = sms.sent[0]["body"]
    assert f"#{code}" in body and "TOTAL" in body
    assert sms.sent[0]["to"] == "+13135550100"
    assert store.order(oid)["status"] == "sent"


def t_ticket_shouts_about_removals():
    """A missed 'no onion' is the complaint that comes back."""
    store, cfg, mv = _fixture()
    e = OrderEngine(cfg)
    line = e.add_line("double_cheeseburger")
    e.remove_option(line.line_id, "bnr_onion")
    oid, code = store.place_order(cfg.id, mv, e.to_normalized_order())
    ticket = format_ticket(store.order_snapshot(oid), code)
    assert "*** NO ONION ***" in ticket


def t_connection_failures_retry_and_then_succeed():
    store, cfg, mv = _fixture()
    oid, _ = _an_order(store, cfg, mv)
    sms = FakeSmsSender(fail_times=2)
    res = deliver(store, oid, ManualSink(sms), sleep=lambda s: None)
    assert res.ok, res
    rows = store.conn.execute(
        "SELECT * FROM order_delivery WHERE order_id=?", (oid,)).fetchall()
    assert len(rows) == 1 and rows[0]["status"] == "sent"


def t_giving_up_is_recorded_as_failed():
    store, cfg, mv = _fixture()
    oid, _ = _an_order(store, cfg, mv)
    sms = FakeSmsSender(fail_times=99)
    res = deliver(store, oid, ManualSink(sms), max_attempts=3,
                  sleep=lambda s: None)
    assert not res.ok and res.error_kind == "connection"
    row = store.conn.execute(
        "SELECT * FROM order_delivery WHERE order_id=?", (oid,)).fetchone()
    assert row["status"] == "failed"


def t_config_errors_are_not_retried():
    """No staff phone is not a transient problem."""
    store, cfg, mv = _fixture()
    store.upsert_restaurant(cfg.id, cfg.name, cfg.cuisine, sink="manual",
                            staff_phone=None, inbound_phone="+13135550199")
    oid, _ = _an_order(store, cfg, mv)
    sms = FakeSmsSender()
    res = deliver(store, oid, ManualSink(sms), sleep=lambda s: None)
    assert not res.ok and res.error_kind == "config" and not res.retryable
    assert not sms.sent


def t_acknowledgement_is_what_proves_the_kitchen_saw_it():
    store, cfg, mv = _fixture()
    oid, _ = _an_order(store, cfg, mv)
    deliver(store, oid, ManualSink(FakeSmsSender()), sleep=lambda s: None)
    assert store.unacknowledged_orders(cfg.id), "should be waiting"
    assert store.acknowledge_delivery(oid, by="kitchen-tablet")
    assert not store.unacknowledged_orders(cfg.id)
    assert store.order(oid)["status"] == "acknowledged"


def t_voice_usage_is_idempotent_and_keeps_largest_provider_totals():
    store, cfg, mv = _fixture()
    store.start_session(cfg.id, mv, external_id="usage-call")
    store.record_voice_usage("usage-call", provider="inworld",
                             processed_characters=1200,
                             transcribed_audio_ms=45000)
    store.record_voice_usage("usage-call", provider="inworld",
                             processed_characters=1100,
                             transcribed_audio_ms=44000)
    row = store.conn.execute("SELECT * FROM voice_usage").fetchone()
    assert (row["processed_characters"], row["transcribed_audio_ms"]) == (1200, 45000)


def t_toast_sink_prices_then_submits_the_normalized_order():
    class FakeToast:
        def __init__(self):
            self.priced = self.created = None

        def price_order(self, payload):
            self.priced = payload
            return {"checks": [{"totalAmount": "10.59"}]}

        def create_order(self, payload):
            self.created = payload
            return {"guid": "toast-order-1"}

    snapshot = {"total_cents": 1059, "lines": [{
        "item_name": "Hamburger", "quantity": 1,
        "pos_refs": {"toast_guid": "a1b2-hamburger",
                     "toast_combo_guid": "a1b2-hamburger-combo"},
        "removed_defaults": [], "modifiers": [{
            "option_id": "bnr_combo", "option_name": "Make it a Combo",
            "quantity": 1, "pos_refs": {}}]}]}
    client = FakeToast()
    result = ToastSink(client, dining_option_guid="takeout-guid",
                       item_group_guid="burger-group",
                       modifier_group_guid="toppings-group").send(
                           "order-1", snapshot,
                           SinkContext("bun-n-run-ferndale", "Bun N Run", "1234",
                                       customer_phone="+13135550123"))
    assert result.ok and result.external_ref == "toast-order-1"
    selection = client.created["checks"][0]["selections"][0]
    assert selection["item"]["guid"] == "a1b2-hamburger-combo"
    assert all(m["item"]["guid"] != "bnr_combo"
               for m in selection.get("modifiers", []))


def t_toast_sink_refuses_a_pos_price_mismatch():
    class WrongPrice:
        def price_order(self, payload):
            return {"checks": [{"totalAmount": "99.99"}]}

        def create_order(self, payload):
            raise AssertionError("must not submit a mismatched order")

    snapshot = {"total_cents": 100, "lines": [{
        "item_name": "Burger", "quantity": 1,
        "pos_refs": {"toast_guid": "burger"}, "modifiers": []}]}
    result = ToastSink(WrongPrice(), dining_option_guid="takeout",
                       item_group_guid="burgers").send(
                           "order-2", snapshot,
                           SinkContext("r", "R", "1234"))
    assert not result.ok and result.error_kind == "rejected"


def t_sink_for_reads_the_restaurant_row():
    store, cfg, mv = _fixture(sink="manual")
    s = sink_for(store.restaurant(cfg.id), FakeSmsSender())
    assert s.name == "manual"
    store.upsert_restaurant(cfg.id, cfg.name, cfg.cuisine, sink="square")
    import os
    os.environ["SQUARE_ACCESS_TOKEN"] = "test-token"
    os.environ["SQUARE_LOCATION_ID"] = "L-TEST"
    # The process-wide token belongs to one merchant, so using it for a
    # restaurant is an explicit single-merchant opt-in, not a silent default.
    os.environ["CHERRY_ALLOW_GLOBAL_SQUARE_TOKEN"] = "1"
    try:
        assert sink_for(store.restaurant(cfg.id)).name == "square"
    finally:
        os.environ.pop("SQUARE_ACCESS_TOKEN", None)
        os.environ.pop("SQUARE_LOCATION_ID", None)
        os.environ.pop("CHERRY_ALLOW_GLOBAL_SQUARE_TOKEN", None)


# --- payments -------------------------------------------------------------


def t_under_threshold_needs_no_payment():
    store, cfg, mv = _fixture()
    oid, _ = _an_order(store, cfg, mv, item="hamburger")
    sms = FakeSmsSender()
    status = pay.arrange_payment(store, oid, sms=sms,
                                 provider=pay.FakePayLinkProvider())
    assert status == "not_required"
    row = pay.payment_for(store, oid)
    assert row["method"] == "at_pickup" and row["pay_url"] is None
    assert not sms.sent


def t_over_threshold_texts_a_pos_hosted_link():
    store, cfg, mv = _fixture()
    oid, code = _an_order(store, cfg, mv, qty=5)      # well over $30
    assert store.order_snapshot(oid)["payment_mode"] == "pay_now"
    sms = FakeSmsSender()
    provider = pay.FakePayLinkProvider()
    status = pay.arrange_payment(store, oid, sms=sms, provider=provider)
    assert status == "link_sent"
    row = pay.payment_for(store, oid)
    assert row["collected_by"] == "restaurant_pos"
    assert row["pay_url"].startswith("https://")
    assert row["status"] == "link_sent"
    assert sms.sent and code in sms.sent[0]["body"]
    assert "https://" in sms.sent[0]["body"]


def t_no_provider_holds_pay_now_order_out_of_kitchen():
    store, cfg, mv = _fixture()
    oid, _ = _an_order(store, cfg, mv, qty=5)
    status = pay.arrange_payment(store, oid, sms=FakeSmsSender(), provider=None)
    assert status == "link_pending"
    assert pay.payment_for(store, oid)["method"] == "pay_link"
    assert not store.conn.execute("SELECT 1 FROM order_delivery WHERE order_id=?",
                                  (oid,)).fetchone()
    assert [e["kind"] for e in store.events(kind="payment.no_provider")]


def t_pos_marks_it_paid():
    store, cfg, mv = _fixture()
    oid, _ = _an_order(store, cfg, mv, qty=5)
    provider = pay.FakePayLinkProvider()
    pay.arrange_payment(store, oid, sms=FakeSmsSender(), provider=provider)
    pay.mark_paid(store, oid, "pos-ref-991",
                  raw_pos_payload={"status": "COMPLETED", "amount": 6000})
    row = pay.payment_for(store, oid)
    assert row["status"] == "paid" and row["pos_payment_ref"] == provider.created[0].pos_ref


def t_pay_link_must_be_https():
    try:
        pay.PayLink(url="http://pay.example.test/abc")
    except ValueError as exc:
        assert "https" in str(exc)
    else:
        raise AssertionError("accepted a plaintext pay link")


# --- the payment-data guard ----------------------------------------------


def t_card_numbers_are_refused():
    for value in ("4111111111111111", "4111 1111 1111 1111",
                  "5500-0000-0000-0004"):
        try:
            pay.reject_payment_data(value, "test")
        except pay.PaymentDataRefused:
            pass
        else:
            raise AssertionError(f"accepted a card number: {value}")


def t_payment_keys_are_refused_anywhere_in_a_payload():
    for payload in ({"cvv": "123"}, {"card_number": "x"},
                    {"data": {"nested": [{"exp_month": 4}]}},
                    {"payment_token": "tok_123"}):
        try:
            pay.reject_payment_data(payload, "webhook")
        except pay.PaymentDataRefused:
            pass
        else:
            raise AssertionError(f"accepted payment data: {payload}")


def t_ordinary_data_passes_the_guard():
    pay.reject_payment_data({"short_code": "4471", "total_cents": 2385,
                             "phone": "+13135550123",
                             "items": ["Double Cheeseburger"]}, "order")


def t_a_pos_webhook_carrying_card_data_is_rejected_before_storage():
    store, cfg, mv = _fixture()
    oid, _ = _an_order(store, cfg, mv, qty=5)
    pay.arrange_payment(store, oid, sms=FakeSmsSender(),
                        provider=pay.FakePayLinkProvider())
    try:
        pay.mark_paid(store, oid, "ref", raw_pos_payload={"pan": "4111111111111111"})
    except pay.PaymentDataRefused:
        pass
    else:
        raise AssertionError("stored a webhook carrying a PAN")
    assert pay.payment_for(store, oid)["status"] == "link_sent"


def t_schema_has_no_column_that_could_hold_payment_data():
    """Structural, not aspirational. Reads the real DDL."""
    sql = (HERE / "db" / "schema.sql").read_text()
    # column definitions only: strip comments first
    body = "\n".join(l for l in sql.splitlines()
                     if not l.strip().startswith("--"))
    cols = re.findall(r"^\s{4}([a-z_]+)\s+[A-Z]", body, re.MULTILINE)
    assert cols, "found no column definitions — the parser is wrong"
    banned = {"card", "card_number", "pan", "cvv", "cvc", "expiry",
              "exp_month", "exp_year", "cardholder", "account_number",
              "routing_number", "iban", "payment_token", "card_token"}
    hits = sorted(set(cols) & banned)
    assert not hits, f"schema has payment-data columns: {hits}"


# --- end to end -----------------------------------------------------------


def t_a_whole_call_from_dialled_number_to_acknowledged_ticket():
    store, cfg, mv = _fixture()
    rest = store.restaurant_for_number("+13135550199")
    config, menu_version = store.load_live_config(rest["id"])
    sid = store.start_session(rest["id"], menu_version, channel="voice",
                              external_id="telnyx-abc", caller_phone="+13135550123")

    e = OrderEngine(config)
    store.record_turn(sid, "agent", "Thanks for calling, what can I get you?")
    store.record_turn(sid, "caller", "two double cheeseburgers")
    line = e.add_line("double_cheeseburger", quantity=2)
    store.save_cart(sid, {"lines": 1})
    e.remove_option(line.line_id, "bnr_onion")
    store.record_turn(sid, "caller", "no onions on those")
    assert e.confirm_group(line.line_id, "bnr_cheeseburger_toppings")
    assert e.is_submittable()

    oid, code = store.place_order(rest["id"], menu_version,
                                  e.to_normalized_order(), session_id=sid,
                                  channel="voice",
                                  customer_phone="+13135550123")
    sms = FakeSmsSender()
    res = deliver(store, oid, sink_for(rest, sms), sleep=lambda s: None)
    assert res.ok
    status = pay.arrange_payment(store, oid, sms=sms, provider=None)
    store.end_session(sid, "completed")
    store.acknowledge_delivery(oid, by="staff-phone")

    order = store.order(oid)
    assert order["status"] == "acknowledged"
    assert order["session_id"] == sid
    assert status == "not_required"
    assert "NO ONION" in sms.sent[0]["body"]
    kinds = {e["kind"] for e in store.events()}
    assert {"order.placed", "delivery.acknowledged"} <= kinds


def t_resolution_log_records_and_reports():
    store, cfg, mv = _fixture()
    sid = store.start_session(cfg.id, mv, external_id="res-1")
    base = {"tool": "add_item", "kind": "item", "resolved_id": "a", "resolved_name": "A",
            "score": 0.7, "runner_up_id": "b", "runner_up_name": "B", "runner_up_score": 0.68}
    store.record_resolution(sid, dict(base, heard="saag", outcome="ambiguous"))
    store.record_resolution(sid, dict(base, heard="saag", outcome="ambiguous"))
    store.record_resolution(sid, dict(base, heard="chow mein", outcome="no_match",
                                      resolved_id=None, resolved_name=None, score=None,
                                      runner_up_id=None, runner_up_name=None,
                                      runner_up_score=None))
    store.record_resolution(sid, dict(base, heard="naan", outcome="matched"))
    assert store.unresolved(cfg.id) == [{"heard": "chow mein", "n": 1}], store.unresolved(cfg.id)
    conf = store.confusions(cfg.id)
    assert len(conf) == 1 and (conf[0]["a"], conf[0]["b"], int(conf[0]["n"])) == ("a", "b", 2), conf
    assert store.unresolved("someone-else") == []
    store.record_resolution("00000000-0000-0000-0000-000000000000", dict(base, heard="x", outcome="matched"))  # no raise


TESTS = [v for k, v in sorted(globals().items()) if k.startswith("t_")]


def main() -> int:
    passed = failed = 0
    fails = []
    for fn in TESTS:
        try:
            fn()
            passed += 1
        except Exception:
            failed += 1
            fails.append((fn.__name__, traceback.format_exc()))
    print(f"{passed} passed, {failed} failed (store + sinks + payments)")
    for n, tb in fails:
        print(f"\n--- FAIL {n}\n{tb}")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
