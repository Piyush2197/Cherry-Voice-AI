#!/usr/bin/env python3
"""Repeatable two-business-day restaurant onboarding factory.

The SLA clock starts only when ``intake_complete`` is true.  A case file never
contains credentials; it contains secret-manager reference names and boolean
proof that the merchant authorization was completed.  Generated deployment
manifests are accepted directly by ``pilot_deploy.py --manifest``.
"""

from __future__ import annotations

import _ensure_deps  # noqa: F401  (re-runs under .venv, or says how to install, if PyYAML is missing)
import argparse
import hashlib
import json
import os
import re
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, Iterable, List, Optional
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

import yaml

import menu_schema as ms
from config_validator import lint_config


SCHEMA_VERSION = 1
SECRET_KEYS = re.compile(
    r"(^|_)(secret|token|password|api_key|private_key|access_key)(_|$)", re.I)
PHONE = re.compile(r"^\+[1-9]\d{7,14}$")
SUPPORTED_POS = {"manual", "manual_fallback", "square", "toast"}
ACCEPTANCE_CHECKS = (
    "routing_and_greeting", "simple_order", "required_choices",
    "modifiers_and_removals", "combo_or_bundle", "sold_out_item",
    "square_paid_order_visible_no_duplicate", "checkout_sms_delivery",
    "itemized_checkout_exact_total", "no_unpaid_kitchen_ticket",
    "checkout_link_handoff", "unpaid_correction_revokes_link",
    "human_fallback", "hours_and_disable_controls", "ops_visibility",
    "concurrent_calls", "rollback_drill")


@dataclass
class Finding:
    code: str
    owner: str
    message: str
    location_id: str = ""


@dataclass
class Audit:
    case_id: str
    intake_complete: bool
    launch_ready: bool
    clock_started_at: Optional[str]
    deadline_at: Optional[str]
    findings: List[Finding] = field(default_factory=list)

    def by_owner(self) -> Dict[str, List[dict]]:
        out: Dict[str, List[dict]] = {}
        for finding in self.findings:
            out.setdefault(finding.owner, []).append(asdict(finding))
        return out

    def as_dict(self) -> dict:
        return {"case_id": self.case_id,
                "intake_complete": self.intake_complete,
                "launch_ready": self.launch_ready,
                "clock_started_at": self.clock_started_at,
                "deadline_at": self.deadline_at,
                "findings": [asdict(x) for x in self.findings],
                "findings_by_owner": self.by_owner()}


def _iso(value) -> Optional[str]:
    if not value:
        return None
    if isinstance(value, datetime):
        dt = value
    else:
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc).isoformat(timespec="seconds")


def business_deadline(start: str, business_days: int = 2) -> str:
    """Return the end of the Nth following business day in UTC.

    Provider/owner delays pause before this clock begins; holidays are handled
    operationally because they differ by market.
    """
    current = datetime.fromisoformat(_iso(start))
    added = 0
    while added < business_days:
        current += timedelta(days=1)
        if current.weekday() < 5:
            added += 1
    return current.isoformat(timespec="seconds")


def load_case(path: Path) -> dict:
    doc = yaml.safe_load(path.read_text())
    if not isinstance(doc, dict) or doc.get("schema_version") != SCHEMA_VERSION:
        raise ValueError("onboarding case must have schema_version: 1")
    _reject_secrets(doc)
    return doc


def _reject_secrets(value, trail="case") -> None:
    if isinstance(value, dict):
        for key, child in value.items():
            if SECRET_KEYS.search(str(key)) and child not in (None, "", False):
                raise ValueError(
                    f"{trail}.{key}: credentials are forbidden in onboarding files; "
                    "store only an environment/secret-manager reference")
            _reject_secrets(child, f"{trail}.{key}")
    elif isinstance(value, list):
        for n, child in enumerate(value):
            _reject_secrets(child, f"{trail}[{n}]")


def _menu_findings(location: dict, root: Path) -> List[Finding]:
    location_id = str(location.get("id") or "")
    menu_value = str(location.get("menu") or "")
    if not menu_value:
        return [Finding("menu_missing", "cherry", "No Cherry menu file is assigned.", location_id)]
    menu_path = (root / menu_value).resolve() if not Path(menu_value).is_absolute() else Path(menu_value)
    if not menu_path.is_file():
        return [Finding("menu_missing", "cherry", f"Menu file does not exist: {menu_value}", location_id)]
    try:
        raw = yaml.safe_load(menu_path.read_text())
        schema = ms.validate_doc(raw)
        if schema:
            return [Finding("menu_schema", "cherry", "; ".join(schema[:5]), location_id)]
        cfg = ms.build_config(raw)
    except Exception as exc:
        return [Finding("menu_invalid", "cherry", str(exc), location_id)]
    findings = []
    if cfg.id != location_id:
        findings.append(Finding("menu_id_mismatch", "cherry",
                                f"Menu id is {cfg.id}, expected {location_id}.", location_id))
    errors = [str(x) for x in lint_config(cfg) if x.level == "ERROR"]
    if errors:
        findings.append(Finding("menu_lint", "cherry", "; ".join(errors[:5]), location_id))
    unpriced = [x.name for x in cfg.items if not x.has_sizes and x.base_price_cents <= 0]
    if unpriced:
        findings.append(Finding("menu_unpriced", "owner",
                                f"Confirm prices for {', '.join(unpriced[:5])}.", location_id))
    try:
        from test_conformance import INVARIANTS
        failed = []
        for invariant in INVARIANTS:
            try:
                invariant(cfg.id, cfg)
            except Exception as exc:
                failed.append(f"{invariant.__name__}: {exc}")
        if failed:
            findings.append(Finding("menu_conformance", "cherry",
                                    "; ".join(failed[:5]), location_id))
    except Exception as exc:
        findings.append(Finding("menu_conformance_unavailable", "cherry",
                                str(exc), location_id))
    return findings


def audit_case(doc: dict, case_path: Path, *, env: Optional[Dict[str, str]] = None,
               deployment: bool = False) -> Audit:
    environment = dict(os.environ if env is None else env)
    findings: List[Finding] = []
    case_id = str(doc.get("case_id") or "")
    if not case_id:
        findings.append(Finding("case_id", "sales", "Case id is required."))
    for field_name in ("business_name", "primary_contact", "timezone"):
        if not doc.get(field_name):
            findings.append(Finding(f"missing_{field_name}", "sales",
                                    f"{field_name.replace('_', ' ').title()} is required."))
    if doc.get("timezone"):
        try:
            ZoneInfo(str(doc["timezone"]))
        except ZoneInfoNotFoundError:
            findings.append(Finding("timezone_invalid", "sales",
                                    "Timezone must be an IANA name such as America/Detroit."))
    locations = doc.get("locations")
    if not isinstance(locations, list) or not locations:
        findings.append(Finding("locations", "sales", "At least one location is required."))
        locations = []
    seen_ids, seen_envs = set(), set()
    root = case_path.resolve().parent
    for number, loc in enumerate(locations, 1):
        if not isinstance(loc, dict):
            findings.append(Finding("location_invalid", "sales",
                                    f"Location {number} must be a mapping."))
            continue
        lid = str(loc.get("id") or "")
        if not lid:
            findings.append(Finding("location_id", "sales", "Location id is required."))
            lid = f"location-{number}"
        elif lid in seen_ids:
            findings.append(Finding("duplicate_location", "sales", "Location id is duplicated.", lid))
        seen_ids.add(lid)
        for field_name in ("name", "cuisine", "fallback_phone", "inbound_env", "pos_type"):
            if not loc.get(field_name):
                findings.append(Finding(f"missing_{field_name}", "sales",
                                        f"{field_name.replace('_', ' ').title()} is required.", lid))
        phone = str(loc.get("fallback_phone") or "")
        if phone and not PHONE.match(phone):
            findings.append(Finding("fallback_phone", "owner",
                                    "Fallback phone must be E.164, for example +12485551234.", lid))
        inbound_env = str(loc.get("inbound_env") or "")
        if inbound_env in seen_envs and inbound_env:
            findings.append(Finding("duplicate_inbound_env", "sales",
                                    "Each location needs a unique inbound-number variable.", lid))
        seen_envs.add(inbound_env)
        pos_type = str(loc.get("pos_type") or "")
        if pos_type and pos_type not in SUPPORTED_POS:
            findings.append(Finding("unsupported_pos", "sales",
                                    f"Unsupported POS type: {pos_type}.", lid))
        confirmations = loc.get("confirmations") or {}
        for proof in ("prices", "modifiers", "tax", "hours", "fallback", "owner_approval"):
            if confirmations.get(proof) is not True:
                findings.append(Finding(f"confirm_{proof}", "owner",
                                        f"Owner must confirm {proof.replace('_', ' ')}.", lid))
        service = loc.get("service") or {}
        if not isinstance(service.get("weekly_hours"), dict) or not service.get("weekly_hours"):
            findings.append(Finding("service_hours", "owner",
                                    "Enter weekly opening and closing hours.", lid))
        for minute_field in ("prep_minutes", "wait_minutes"):
            try:
                if int(service.get(minute_field, -1)) < 0:
                    raise ValueError
            except (TypeError, ValueError):
                findings.append(Finding(f"service_{minute_field}", "owner",
                                        f"{minute_field.replace('_', ' ')} must be zero or greater.", lid))
        languages = service.get("languages")
        if not isinstance(languages, list) or not languages:
            findings.append(Finding("service_languages", "owner",
                                    "List at least one approved service language.", lid))
        findings.extend(_menu_findings(loc, root))
        if loc.get("checkout_provider") != "square":
            findings.append(Finding("itemized_checkout_provider", "sales",
                                    "The current paid-first flow requires an order-specific Square checkout; a generic ordering URL or manual-only sink cannot launch.", lid))
        if loc.get("checkout_authorized") is not True:
            findings.append(Finding("checkout_authorization", "owner",
                                    "The merchant must authorize itemized checkout before the two-day clock starts.", lid))
        if loc.get("provider_access_ready") is not True:
            findings.append(Finding("provider_access", "developer",
                                    "Merchant/provider access has not been verified.", lid))
        if deployment:
            if not inbound_env or not environment.get(inbound_env):
                findings.append(Finding("inbound_number", "developer",
                                        f"Set {inbound_env or 'the inbound-number variable'}.", lid))
            if pos_type == "square" and not loc.get("pos_location_id"):
                findings.append(Finding("square_location", "developer",
                                        "Square location id is required.", lid))
            if pos_type == "toast" and not loc.get("pos_mapping_verified"):
                findings.append(Finding("toast_mapping", "developer",
                                        "Toast item and group GUID mapping must be verified.", lid))

    # The commercial SLA starts after every sales/owner/menu-data input exists,
    # not while Cherry is waiting for access or decisions.
    intake_findings = [x for x in findings
                       if x.owner in {"sales", "owner", "cherry"}
                       or x.code == "provider_access"]
    complete = not intake_findings
    started = _iso(doc.get("intake_completed_at")) if complete else None
    if complete and not started:
        findings.append(Finding("clock_not_started", "sales",
                                "Set intake_completed_at to start the two-business-day SLA."))
    deadline = business_deadline(started) if started else None
    launch_ready = deployment and not findings and complete and bool(started)
    return Audit(case_id, complete, launch_ready, started, deadline, findings)


def deployment_manifest(doc: dict, case_path: Path, audit: Audit) -> dict:
    root = case_path.resolve().parent
    locations = []
    blocking_locations = {x.location_id for x in audit.findings
                          if x.owner in {"sales", "owner", "cherry"} and x.location_id}
    for loc in doc.get("locations", []):
        menu = Path(str(loc.get("menu") or ""))
        absolute = (root / menu).resolve() if not menu.is_absolute() else menu
        try:
            relative = absolute.relative_to(Path(__file__).resolve().parent)
            menu_value = str(relative)
        except ValueError:
            menu_value = str(absolute)
        locations.append({
            "id": loc["id"], "group": doc.get("case_id", loc["id"]),
            "name": loc["name"], "menu": menu_value,
            "catalog_status": ("ready" if loc["id"] not in blocking_locations
                               else "onboarding_verification_required"),
            "inbound_env": loc["inbound_env"],
            "fallback_phone": loc["fallback_phone"],
            "pos_type": loc["pos_type"],
            "pos_location_id": str(loc.get("pos_location_id") or ""),
            "note": "Generated by onboarding_factory.py; do not add credentials."
        })
    return {"schema_version": 1, "locations": locations}


def render_report(doc: dict, audit: Audit) -> str:
    state = "READY FOR LIVE ACCEPTANCE" if audit.launch_ready else (
        "INTAKE COMPLETE — DEPLOYMENT WORK REMAINS" if audit.intake_complete
        else "WAITING FOR COMPLETE INTAKE")
    lines = [f"# Launch report — {doc.get('business_name', audit.case_id)}", "",
             f"**State:** {state}",
             f"**Case:** `{audit.case_id}`",
             f"**SLA started:** {audit.clock_started_at or 'not started'}",
             f"**Two-business-day deadline:** {audit.deadline_at or 'not calculated'}", ""]
    if not audit.findings:
        lines += ["All automated onboarding gates pass. Live acceptance is the final gate.", ""]
    else:
        lines += ["## Blocking checklist", ""]
        for owner in ("sales", "owner", "cherry", "developer"):
            owned = [x for x in audit.findings if x.owner == owner]
            if owned:
                lines += [f"### {owner.title()}", ""]
                for item in owned:
                    where = f" ({item.location_id})" if item.location_id else ""
                    lines.append(f"- [ ] `{item.code}`{where}: {item.message}")
                lines.append("")
    lines += ["## Required live acceptance", "",
              "- [ ] Dialled number reaches the correct restaurant and greeting.",
              "- [ ] Simple item, required choice, modifier/removal and combo match the POS price.",
              "- [ ] Itemized checkout matches the immutable order and exact total.",
              "- [ ] The paid Square order appears to staff; Cherry creates no duplicate kitchen ticket.",
              "- [ ] Wrong unpaid order revokes its link before a corrected new order is sent.",
              "- [ ] Checkout SMS is delivered and Cherry ends its call flow after link handoff.",
              "- [ ] Forced outage transfers once to the verified fallback number.",
              "- [ ] Hours, holiday closure, 86 item and AI-disable controls behave correctly.",
              "- [ ] `/ops` shows the call without exposing customer identity.",
              "- [ ] Owner signs the launch acceptance record.", ""]
    return "\n".join(lines)


def write_packet(case_path: Path, output: Path, *, env=None) -> Audit:
    doc = load_case(case_path)
    audit = audit_case(doc, case_path, env=env, deployment=True)
    output.mkdir(parents=True, exist_ok=True)
    (output / "deployment.yaml").write_text(yaml.safe_dump(
        deployment_manifest(doc, case_path, audit), sort_keys=False, width=100))
    (output / "LAUNCH_REPORT.md").write_text(render_report(doc, audit))
    (output / "audit.json").write_text(json.dumps(audit.as_dict(), indent=2) + "\n")
    controls = {"schema_version": 1, "locations": [
        {"restaurant_id": loc["id"], **(loc.get("service") or {})}
        for loc in doc.get("locations", [])]}
    (output / "controls.yaml").write_text(yaml.safe_dump(
        controls, sort_keys=False, width=100))
    calls = output / "calls"
    calls.mkdir(exist_ok=True)
    root = case_path.resolve().parent
    menu_hashes = {}
    for loc in doc.get("locations", []):
        menu = Path(str(loc.get("menu") or ""))
        menu = (root / menu).resolve() if not menu.is_absolute() else menu
        try:
            cfg = ms.load_yaml(menu)
            menu_hashes[loc["id"]] = hashlib.sha256(menu.read_bytes()).hexdigest()
            # The generated script proves routing/pricing without guessing a
            # required option. Rich modifier/combo cases remain on the signed
            # acceptance checklist because they require owner-confirmed intent.
            item = next((x for x in cfg.items if not any(
                cfg.group(gid).min_select > 0
                for gid in x.modifier_group_ids)), cfg.items[0])
            (calls / f"{loc['id']}-smoke.txt").write_text(
                f"{item.name}\nconfirm\nread\n")
        except Exception:
            # Menu failures are already explicit in audit.json; packet creation
            # must still return the full blocker list instead of crashing here.
            pass
    acceptance = {"schema_version": 1, "case_id": audit.case_id,
                  "accepted_at": None, "owner_signoff": "",
                  "menu_sha256": menu_hashes,
                  "checks": {name: False for name in ACCEPTANCE_CHECKS},
                  "issues": []}
    (output / "acceptance.yaml").write_text(yaml.safe_dump(
        acceptance, sort_keys=False, width=100))
    return audit


def apply_controls_file(path: Path, db: str, *, updated_by="onboarding_factory") -> int:
    """Apply a packet's controls only after every restaurant is deployed."""
    from order_store import OrderStore
    import restaurant_controls
    doc = yaml.safe_load(path.read_text())
    if not isinstance(doc, dict) or doc.get("schema_version") != 1:
        raise ValueError("controls file must have schema_version: 1")
    rows = doc.get("locations")
    if not isinstance(rows, list) or not rows:
        raise ValueError("controls file has no locations")
    store = OrderStore.open(db)
    missing = [str(row.get("restaurant_id") or "") for row in rows
               if not row.get("restaurant_id") or not store.restaurant(row["restaurant_id"])]
    if missing:
        raise ValueError("controls target undeployed restaurant(s): " + ", ".join(missing))
    for row in rows:
        restaurant_controls.set_controls(
            store, row["restaurant_id"],
            weekly_hours=row.get("weekly_hours"),
            holiday_closures=row.get("holiday_closures"),
            prep_minutes=int(row.get("prep_minutes", 20)),
            wait_minutes=int(row.get("wait_minutes", 0)),
            languages=row.get("languages"), updated_by=updated_by)
    return len(rows)


def portfolio(root: Path, *, env=None, now=None) -> dict:
    """Aggregate every onboarding case without exposing contact information."""
    now = now or datetime.now(timezone.utc)
    rows = []
    for path in sorted(root.rglob("intake.yaml")):
        try:
            doc = load_case(path)
            audit = audit_case(doc, path, env=env, deployment=True)
            deadline = (datetime.fromisoformat(audit.deadline_at)
                        if audit.deadline_at else None)
            if not audit.intake_complete:
                state = "waiting_intake"
            elif audit.launch_ready:
                state = "ready_for_acceptance"
            elif deadline and now.astimezone(timezone.utc) > deadline:
                state = "overdue"
            else:
                state = "activation"
            hours_remaining = (round((deadline - now.astimezone(timezone.utc)).total_seconds() / 3600, 1)
                               if deadline else None)
            rows.append({"case_id": audit.case_id,
                         "business_name": str(doc.get("business_name") or ""),
                         "locations": len(doc.get("locations") or []),
                         "state": state, "deadline_at": audit.deadline_at,
                         "hours_remaining": hours_remaining,
                         "blockers": len(audit.findings),
                         "owners": sorted(audit.by_owner())})
        except Exception as exc:
            rows.append({"case_id": path.parent.name, "business_name": "",
                         "locations": 0, "state": "invalid",
                         "deadline_at": None, "hours_remaining": None,
                         "blockers": 1, "owners": ["cherry"],
                         "error": str(exc)})
    states: Dict[str, int] = {}
    for row in rows:
        states[row["state"]] = states.get(row["state"], 0) + 1
    return {"cases": len(rows), "locations": sum(x["locations"] for x in rows),
            "states": states, "pipeline": rows}


def certify(case_path: Path, acceptance_path: Path, output: Path, *, env=None) -> dict:
    """Create a launch certificate only after configuration and live proof pass."""
    doc = load_case(case_path)
    audit = audit_case(doc, case_path, env=env, deployment=True)
    if not audit.launch_ready:
        raise ValueError("case is not ready for acceptance: " +
                         ", ".join(x.code for x in audit.findings))
    acceptance = yaml.safe_load(acceptance_path.read_text())
    if not isinstance(acceptance, dict) or acceptance.get("schema_version") != 1:
        raise ValueError("acceptance file must have schema_version: 1")
    if acceptance.get("case_id") != audit.case_id:
        raise ValueError("acceptance case_id does not match intake")
    missing = [name for name in ACCEPTANCE_CHECKS
               if (acceptance.get("checks") or {}).get(name) is not True]
    if missing:
        raise ValueError("acceptance checks not passed: " + ", ".join(missing))
    if not str(acceptance.get("owner_signoff") or "").strip():
        raise ValueError("owner_signoff is required")
    accepted_at = _iso(acceptance.get("accepted_at"))
    if not accepted_at:
        raise ValueError("accepted_at is required")
    for number, issue in enumerate(acceptance.get("issues") or [], 1):
        if not isinstance(issue, dict) or not all(str(issue.get(key) or "").strip()
                                                  for key in ("description", "resolution",
                                                              "regression_test")):
            raise ValueError(f"issue {number} needs description, resolution and regression_test")
    root = case_path.resolve().parent
    menu_hashes = {}
    for loc in doc.get("locations", []):
        menu = Path(str(loc["menu"]))
        menu = (root / menu).resolve() if not menu.is_absolute() else menu
        menu_hashes[loc["id"]] = hashlib.sha256(menu.read_bytes()).hexdigest()
    if acceptance.get("menu_sha256") != menu_hashes:
        raise ValueError("menu changed after the launch packet was generated; regenerate and repeat acceptance")
    certificate = {"schema_version": 1, "case_id": audit.case_id,
                   "business_name": doc["business_name"],
                   "accepted_at": accepted_at,
                   "owner_signoff": str(acceptance["owner_signoff"]),
                   "locations": sorted(menu_hashes),
                   "menu_sha256": menu_hashes,
                   "checks": {name: True for name in ACCEPTANCE_CHECKS},
                   "resolved_issues": acceptance.get("issues") or []}
    output.write_text(json.dumps(certificate, indent=2) + "\n")
    return certificate


def new_case(output: Path, case_id: str, business_name: str, location_id: str,
             location_name: str, cuisine: str, pos_type: str) -> Path:
    if output.exists() and any(output.iterdir()):
        raise FileExistsError(f"refusing to overwrite non-empty directory {output}")
    output.mkdir(parents=True, exist_ok=True)
    inbound = "CHERRY_INBOUND_" + re.sub(r"[^A-Z0-9]+", "_", location_id.upper()).strip("_")
    doc = {"schema_version": 1, "case_id": case_id,
           "business_name": business_name, "primary_contact": "",
           "timezone": "America/Detroit", "intake_completed_at": None,
           "locations": [{"id": location_id, "name": location_name,
                          "cuisine": cuisine, "menu": "menu.yaml",
                          "fallback_phone": "", "inbound_env": inbound,
                          "pos_type": pos_type, "pos_location_id": "",
                          "provider_access_ready": False,
                          "checkout_provider": "", "checkout_authorized": False,
                          "pos_mapping_verified": False,
                          "service": {"weekly_hours": {},
                                      "holiday_closures": [],
                                      "prep_minutes": 20,
                                      "wait_minutes": 0,
                                      "languages": ["en"]},
                          "confirmations": {"prices": False, "modifiers": False,
                                            "tax": False, "hours": False,
                                            "fallback": False,
                                            "owner_approval": False}}]}
    path = output / "intake.yaml"
    path.write_text(yaml.safe_dump(doc, sort_keys=False, width=100))
    (output / "raw-menu.txt").write_text(
        "Paste the complete owner/POS menu here, including prices and modifier descriptions.\n")
    (output / "README.md").write_text(
        "# Onboarding case\n\n"
        "1. Complete `intake.yaml` without adding secrets.\n"
        "2. Build `menu.yaml` with `cherry.py ingest` or the POS catalog tools.\n"
        "3. Run `python3 onboarding_factory.py status intake.yaml`.\n"
        "4. After intake passes, set `intake_completed_at` and generate the packet.\n")
    return path


def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest="command", required=True)
    create = sub.add_parser("new")
    create.add_argument("--out", type=Path, required=True)
    create.add_argument("--case-id", required=True)
    create.add_argument("--business-name", required=True)
    create.add_argument("--location-id", required=True)
    create.add_argument("--location-name", required=True)
    create.add_argument("--cuisine", required=True)
    create.add_argument("--pos", required=True, choices=sorted(SUPPORTED_POS))
    status = sub.add_parser("status")
    status.add_argument("case", type=Path)
    status.add_argument("--deployment", action="store_true")
    status.add_argument("--json", action="store_true")
    packet = sub.add_parser("packet")
    packet.add_argument("case", type=Path)
    packet.add_argument("--out", type=Path, required=True)
    controls = sub.add_parser("apply-controls")
    controls.add_argument("controls", type=Path)
    controls.add_argument("--db", required=True)
    portfolio_parser = sub.add_parser("portfolio")
    portfolio_parser.add_argument("root", type=Path)
    portfolio_parser.add_argument("--json", action="store_true")
    certify_parser = sub.add_parser("certify")
    certify_parser.add_argument("case", type=Path)
    certify_parser.add_argument("acceptance", type=Path)
    certify_parser.add_argument("--out", type=Path, required=True)
    args = ap.parse_args(argv)
    try:
        if args.command == "new":
            path = new_case(args.out, args.case_id, args.business_name,
                            args.location_id, args.location_name,
                            args.cuisine, args.pos)
            print(path)
            return 0
        if args.command == "apply-controls":
            count = apply_controls_file(args.controls, args.db)
            print(f"applied controls for {count} location(s)")
            return 0
        if args.command == "portfolio":
            result = portfolio(args.root)
            if args.json:
                print(json.dumps(result, indent=2))
            else:
                print(f"{result['cases']} cases / {result['locations']} locations")
                for row in result["pipeline"]:
                    deadline = row["deadline_at"] or "clock not started"
                    print(f"{row['state']:20} {row['case_id']:24} "
                          f"{row['locations']} location(s), {row['blockers']} blocker(s), {deadline}")
            return 2 if result["states"].get("invalid") else 0
        if args.command == "certify":
            certificate = certify(args.case, args.acceptance, args.out)
            print(args.out)
            return 0
        doc = load_case(args.case)
        if args.command == "packet":
            audit = write_packet(args.case, args.out)
            print(args.out / "LAUNCH_REPORT.md")
        else:
            audit = audit_case(doc, args.case, deployment=args.deployment)
            if args.json:
                print(json.dumps(audit.as_dict(), indent=2))
            else:
                print(render_report(doc, audit))
        if args.command == "status" and not args.deployment:
            return 0 if audit.intake_complete else 2
        return 0 if audit.launch_ready else 2
    except (ValueError, FileExistsError) as exc:
        ap.error(str(exc))
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
