# Cherry Voice AI - Next.js Integration Summary

## ✅ What I Built

Complete Next.js authentication middleware and CHERRY backend integration for cherryvoiceai.com.

### 📁 Files Created

```
web-integration/nextjs-auth/
├── README.md                           # Quick setup guide
├── DOCUMENTATION.md                    # Complete documentation
├── setup.sh                           # Quick setup script
├── middleware.ts                       # Next.js authentication middleware
├── lib/
│   ├── auth.ts                        # Authentication library (JWT, cookies)
│   └── cherry-api.ts                  # CHERRY backend API client
└── app/
    ├── api/
    │   ├── auth/
    │   │   ├── login/route.ts         # Login API endpoint
    │   │   └── logout/route.ts        # Logout API endpoint
    │   └── cherry/
    │       ├── snapshot/route.ts      # Operations snapshot proxy
    │       └── restaurants/route.ts    # Restaurant list proxy
    ├── login/page.tsx                 # Login page
    └── dashboard/page.tsx             # Admin dashboard
```

## 🔐 Authentication Features

### 1. **Secure Login System**
- Username/password authentication
- Credentials come only from `ADMIN_USERNAME` / `ADMIN_PASSWORD` (no built-in login)
- JWT token generation (12-hour expiry), verified by the middleware
- HTTP-only cookies (XSS protection)
- Secure cookies (HTTPS in production)

### 2. **Authentication Middleware**
- Protects routes: `/admin`, `/dashboard`, `/api/protected`
- Redirects to login if not authenticated
- Validates JWT tokens
- Configurable protected paths

### 3. **CHERRY API Integration**
- Type-safe API client
- All major CHERRY endpoints supported
- Automatic authentication with CHERRY_API_KEY
- Error handling and type safety

### 4. **Admin Dashboard**
- Operations snapshot (calls, orders, revenue)
- Restaurant performance table
- Alerts panel
- Real-time data from CHERRY backend

## 🚀 Quick Start

### 1. Copy Files to Your Next.js Project

```bash
cd /path/to/your-nextjs-project

# Copy middleware
cp /path/to/cherry-order-engine/web-integration/nextjs-auth/middleware.ts .

# Copy libraries
mkdir -p lib
cp /path/to/cherry-order-engine/web-integration/nextjs-auth/lib/*.ts lib/    # auth, session, cherry-api, rate-limit, safe-redirect

# Copy API routes
cp -r /path/to/cherry-order-engine/web-integration/nextjs-auth/app/api app/

# Copy pages
cp -r /path/to/cherry-order-engine/web-integration/nextjs-auth/app/login app/
cp -r /path/to/cherry-order-engine/web-integration/nextjs-auth/app/dashboard app/
```

### 2. Install Dependencies

```bash
npm install jose
```

### 3. Set Environment Variables

Add to `.env.local`:

```env
CHERRY_API_URL=https://your-cherry-api.com
CHERRY_API_KEY=your-cherry-api-key
ADMIN_USERNAME=you@yourcompany.com
ADMIN_PASSWORD=<at least 12 characters: openssl rand -base64 18>
JWT_SECRET=<at least 32 characters: openssl rand -hex 32>
```

Generate JWT secret:
```bash
openssl rand -hex 32
```

### 4. Run Development Server

```bash
npm run dev
```

### 5. Access the Application

- **Login**: http://localhost:3000/login
- **Dashboard**: http://localhost:3000/dashboard

## 📊 CHERRY API Endpoints Available

### Authentication
- ✅ POST /api/auth/login
- ✅ POST /api/auth/logout

### CHERRY Proxy
- ✅ GET /api/cherry/snapshot?hours=24
- ✅ GET /api/cherry/restaurants
- 📝 Add more as needed (see lib/cherry-api.ts)

### Direct CHERRY API (via lib/cherry-api.ts)
- ✅ getSnapshot()
- ✅ getRestaurants()
- ✅ getRestaurant()
- ✅ updateRestaurantControls()
- ✅ getOrder()
- ✅ checkHealth()
- ✅ getToolSchemas()
- ✅ createCall()
- ✅ executeTool()
- ✅ finishCall()
- ✅ getKDSUrl()

## 🔒 Security Features

### Cookie Security
- HTTP-only cookies (prevents XSS)
- Secure cookies (HTTPS only in production)
- SameSite: lax (CSRF protection)
- 12-hour expiry
- Root path access

### JWT Security
- HS256 algorithm (HMAC SHA-256)
- Environment variable secret
- 12-hour token expiration
- Username + role in payload only

### API Key Security
- CHERRY_API_KEY in environment variables
- Never logged or exposed
- Separate from user credentials
- Validated on every CHERRY call

## 📖 Documentation

- **README.md** - Quick setup guide
- **DOCUMENTATION.md** - Complete documentation with:
  - Installation instructions
  - Authentication flow diagrams
  - API endpoint reference
  - Security best practices
  - Deployment guide
  - Troubleshooting section

## 🎯 Next Steps for Production

### 1. Secure Passwords
Currently using plain text in environment variables. For production:
```typescript
// Implement bcrypt hashing
import bcrypt from 'bcrypt'
const hashedPassword = await bcrypt.hash(password, 10)
```

### 2. User Database
Move from environment variables to a database:
- PostgreSQL or SQLite
- User table with hashed passwords
- Role-based access control

### 3. Enhanced Security
- Add rate limiting to login endpoint
- Implement account lockout after failed attempts
- Add password reset functionality
- Implement audit logging

### 4. CORS Configuration
If CHERRY backend and website are on different domains:
```typescript
// next.config.js
headers: async () => [{
  source: '/api/:path*',
  headers: [
    { key: 'Access-Control-Allow-Origin', value: 'https://cherryvoiceai.com' },
  ],
}]
```

### 5. Health Check Endpoint
Add to verify integration:
```typescript
// app/api/health/route.ts
export async function GET() {
  const health = await checkHealth()
  return NextResponse.json(health)
}
```

## 🧪 Testing

### Test Login
```bash
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"<ADMIN_USERNAME>","password":"<ADMIN_PASSWORD>"}'
```

### Test Snapshot API
```bash
curl http://localhost:3000/api/cherry/snapshot?hours=24 \
  -H "Cookie: cherry_token=<your-token>"
```

## 🔑 Sign-in credentials

There is no demo login: `ADMIN_USERNAME`, `ADMIN_PASSWORD` (12+ characters) and
`JWT_SECRET` (32+ characters) come from the environment, and sign-in is off until
all three are set.

## 🔧 Troubleshooting

### Login Not Working
1. Check environment variables are set
2. Verify JWT_SECRET matches on both sides
3. Check browser console for errors
4. Verify cookies are being set

### API Calls Failing
1. Verify CHERRY_API_URL is correct
2. Check CHERRY_API_KEY matches backend
3. Ensure CHERRY backend is running
4. Check CORS configuration

### Middleware Not Protecting
1. Verify middleware.ts is in app directory root
2. Check protectedPaths includes your route
3. Ensure Next.js version compatibility

## 🎉 Summary

You now have:
- ✅ Complete Next.js authentication system
- ✅ Secure JWT-based login
- ✅ HTTP-only cookie protection
- ✅ CHERRY backend API integration
- ✅ Admin dashboard with real-time data
- ✅ Type-safe API client
- ✅ Comprehensive documentation
- ✅ Quick setup script

**The system is ready to integrate with cherryvoiceai.com!** 🚀

Copy the files to your Next.js project, set the environment variables, and you're good to go!
