# Forwarded-number voice deployment

For the full developer launch sequence and acceptance checks, start with
`DEVELOPER_HANDOFF.md`.

## Call path

The restaurant keeps its published number with its current carrier. That carrier
forwards every inbound call to a location-specific Telnyx DID. Telnyx delivers
audio to the Inworld SIP endpoint. The Inworld voice worker calls
`voice_gateway.py` for lifecycle and tool events; the gateway relays these to
`server.py`. The voice worker must speak each returned `say` value exactly.

The gateway is an HTTP tool/call adapter. It is **not** a SIP or RTP server.
The Inworld SIP endpoint, its event format, and its tool-callback configuration
must be supplied and connected in the Inworld account. The worker must preserve
Telnyx's actual `call_control_id`; a generated Inworld ID cannot control a
Telnyx transfer. If Telnyx routes the DID through a plain SIP connection and
does not expose a Call Control ID for the inbound leg, the Call Control
transfer adapter cannot move that call. In that setup, human handoff needs
Inworld's supported SIP transfer mechanism or the Telnyx routing must be
changed to keep the call under a programmable voice application. Validate this
with a live provider call before enabling forwarding.

## Required live configuration

For every active location set `CHERRY_INBOUND_<LOCATION>` to its Telnyx DID and
`CHERRY_DIRECT_FALLBACK_<LOCATION>` to a separately reachable staff line. The
direct fallback must differ from both the Telnyx DID and the published number
in `deployments/pilot-locations.yaml`. That published number is being forwarded
to the AI, so transferring to it would create a loop.

Set `CHERRY_REQUIRE_DIRECT_FALLBACK=1` during deployment and verification.
Run `pilot_deploy.py apply` and `verify` with the same environment so the direct
line is stored as the restaurant contact number. Also set:

| Variable | Purpose |
| --- | --- |
| `CHERRY_BASE_URL` | Private HTTPS address of `server.py` |
| `CHERRY_API_KEY` | Shared key used by the gateway for Cherry API calls; pass the same key as `server.py --key` |
| `CHERRY_VOICE_KEY` | Separate shared key required on every gateway request |
| `TELNYX_API_KEY` | Authorizes the Call Control transfer action |
| `CHERRY_CHECKOUT_HANDOFF_ONLY=1` | Ends Cherry's order flow after sending the customer an itemized checkout link; no paid kitchen release |

Start the gateway with `python3 voice_gateway.py --port 8090` behind TLS and
restrict its network access to the Inworld voice worker. Start Cherry with
`python3 server.py --key "$CHERRY_API_KEY" --real-sms --checkout-handoff-only`
and a configured production database. The gateway and Cherry server each hold
active call state in memory, so deploy one instance of each or provide sticky
routing before scaling horizontally.

## Voice worker contract

Every request to the gateway requires `X-Voice-Key: <CHERRY_VOICE_KEY>` and JSON
for POST requests. The gateway returns JSON. The worker speaks `say` verbatim.

| Event | Request | Body |
| --- | --- | --- |
| Load tools | `GET /v1/voice/tools` | none |
| Incoming call | `POST /v1/voice/calls` | `{"call_control_id":"...","to":"+1...","from":"+1..."}` |
| Tool selected by Inworld | `POST /v1/voice/calls/{call_control_id}/tools/{tool_name}` | Tool arguments from the selected schema |
| Caller finished ordering | `POST /v1/voice/calls/{call_control_id}/finish` | `{"customer_name":"..."}` |
| Caller hangs up | `POST /v1/voice/calls/{call_control_id}/abandon` | `{"reason":"caller_hung_up"}` |
| Caller asks for a person | `POST /v1/voice/calls/{call_control_id}/handoff` | `{}` |

URL-encode `call_control_id` in paths. Use `GET /v1/voice/tools` as the tool
catalog and the `SYSTEM_PROMPT` in `voice/inworld_bridge.py` for tool behavior.
The voice worker must call `finish` only after `ready_to_place` reports ready;
the bridge checks this again and returns the missing question when incomplete.
On Cherry errors the gateway asks Telnyx to transfer once to the direct line.

## Checkout behavior

With handoff-only enabled, Cherry saves the order, creates an itemized checkout
link through the restaurant's configured Square connection, texts that link,
and tells the caller to finish on the restaurant's page. Cherry does not wait
for payment before ending the call and does not issue a separate kitchen ticket.
The restaurant's checkout/POS owns what happens after the link is opened.
The Square webhook may still record payment status if configured, but is not
needed for the handoff-only call path.

There is no generic-cart transfer into an arbitrary restaurant website. A
location must have an order-specific checkout provider connected before this
path can send a useful link. A real test call must prove the forwarded DID,
audio, tool calls, SMS delivery, checkout contents, human transfer, and direct
fallback before public forwarding is switched on.
