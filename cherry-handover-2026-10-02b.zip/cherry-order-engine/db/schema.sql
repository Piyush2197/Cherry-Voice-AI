-- Cherry — order store. PostgreSQL.
--
-- THE ONE RULE THAT SHAPES EVERYTHING
-- -----------------------------------
-- Cherry never touches money. No card number, no CVV, no expiry, no token, no
-- bank detail is ever stored, logged, or passed through. Payment happens on
-- the restaurant's own POS. Cherry relays a POS-hosted link and records a
-- status word. Anything more is a PCI problem we have no reason to own.
--
-- This is enforced three ways: there is no column here that could hold card
-- data; payments.pay_url is constrained to https; and a test asserts that no
-- column name in this file matches a payment-data pattern.
--
-- THE SECOND RULE
-- ---------------
-- A placed order is immutable and self-contained. Menus change weekly — a
-- price edit on Tuesday must not silently restate what a customer was quoted
-- on Monday. So every order stores the full priced snapshot as JSON, plus the
-- menu_version it was priced against. Reprinting a three-week-old ticket must
-- produce exactly what the kitchen originally saw.

CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS schema_migration (
    version             INTEGER PRIMARY KEY,
    name                TEXT NOT NULL,
    applied_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);
INSERT INTO schema_migration (version, name)
VALUES (1, 'initial production schema')
ON CONFLICT (version) DO NOTHING;

-- ---------------------------------------------------------------------------
-- Restaurants and menus
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS restaurant (
    id                  TEXT PRIMARY KEY,          -- 'bun-n-run-ferndale'
    name                TEXT NOT NULL,
    cuisine             TEXT NOT NULL,
    timezone            TEXT NOT NULL DEFAULT 'America/Detroit',
    tax_rate_bps        INTEGER NOT NULL DEFAULT 0
                            CHECK (tax_rate_bps BETWEEN 0 AND 3000),
    pos_type            TEXT NOT NULL DEFAULT 'manual_fallback',
    -- where a finished order goes. 'manual' is a sink like any other, not a
    -- special case; see bridges.py
    sink                TEXT NOT NULL DEFAULT 'manual',
    -- staff phone for the manual sink, E.164
    staff_phone         TEXT,
    inbound_phone       TEXT UNIQUE,               -- number callers dial
    active              BOOLEAN NOT NULL DEFAULT FALSE,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Every menu edit is a new version. Nothing is updated in place, so an order
-- can always be re-priced exactly as it was.
CREATE TABLE IF NOT EXISTS menu_version (
    id                  BIGSERIAL PRIMARY KEY,
    restaurant_id       TEXT NOT NULL REFERENCES restaurant(id),
    version             INTEGER NOT NULL,
    yaml                TEXT NOT NULL,             -- the config file, verbatim
    yaml_sha256         TEXT NOT NULL,
    item_count          INTEGER NOT NULL,
    published_by        TEXT,
    published_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    is_live             BOOLEAN NOT NULL DEFAULT FALSE,
    UNIQUE (restaurant_id, version)
);

-- Exactly one live menu per restaurant.
CREATE UNIQUE INDEX IF NOT EXISTS one_live_menu_per_restaurant
    ON menu_version (restaurant_id) WHERE is_live;

-- 86'd items. Deliberately NOT in the menu: "we ran out tonight" is not a
-- menu fact, and baking it into the config means it can never come back.
CREATE TABLE IF NOT EXISTS availability_override (
    restaurant_id       TEXT NOT NULL REFERENCES restaurant(id),
    target_kind         TEXT NOT NULL CHECK (target_kind IN ('item', 'option')),
    target_id           TEXT NOT NULL,
    available           BOOLEAN NOT NULL,
    reason              TEXT,
    set_by              TEXT,
    set_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    -- NULL means until someone clears it; most 86s should expire at close
    expires_at          TIMESTAMPTZ,
    PRIMARY KEY (restaurant_id, target_kind, target_id)
);

CREATE TABLE IF NOT EXISTS restaurant_control (
    restaurant_id       TEXT PRIMARY KEY REFERENCES restaurant(id),
    weekly_hours        JSONB NOT NULL DEFAULT '{}'::jsonb,
    holiday_closures    JSONB NOT NULL DEFAULT '[]'::jsonb,
    prep_minutes        INTEGER NOT NULL DEFAULT 20 CHECK (prep_minutes >= 0),
    wait_minutes        INTEGER NOT NULL DEFAULT 0 CHECK (wait_minutes >= 0),
    ai_enabled          BOOLEAN NOT NULL DEFAULT TRUE,
    languages           JSONB NOT NULL DEFAULT '["en"]'::jsonb,
    -- greet a returning caller by name and offer their last order; the owner's switch
    remember_callers    BOOLEAN NOT NULL DEFAULT TRUE,
    updated_by          TEXT,
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);
-- a database created before this column existed (a repeat bootstrap cannot add it by itself)
ALTER TABLE restaurant_control ADD COLUMN IF NOT EXISTS remember_callers BOOLEAN NOT NULL DEFAULT TRUE;
INSERT INTO schema_migration (version, name)
VALUES (7, 'per-restaurant caller memory switch')
ON CONFLICT (version) DO NOTHING;

CREATE TABLE IF NOT EXISTS reservation (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    restaurant_id TEXT NOT NULL REFERENCES restaurant(id),
    guest_name TEXT NOT NULL, guest_phone TEXT NOT NULL,
    party_size INTEGER NOT NULL CHECK (party_size BETWEEN 1 AND 100),
    reserved_at TIMESTAMPTZ NOT NULL, notes TEXT,
    status TEXT NOT NULL CHECK (status IN ('requested','confirmed','declined','cancelled','seated','completed')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(), updated_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS reservation_reference (
    reservation_id UUID PRIMARY KEY REFERENCES reservation(id) ON DELETE CASCADE,
    confirmation_code TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS reservation_policy (
    restaurant_id TEXT PRIMARY KEY REFERENCES restaurant(id),
    enabled BOOLEAN NOT NULL DEFAULT FALSE,
    mode TEXT NOT NULL DEFAULT 'request_only'
        CHECK (mode IN ('request_only')),
    max_party_size INTEGER NOT NULL DEFAULT 12 CHECK (max_party_size BETWEEN 1 AND 100),
    min_notice_minutes INTEGER NOT NULL DEFAULT 60 CHECK (min_notice_minutes >= 0),
    max_advance_days INTEGER NOT NULL DEFAULT 90 CHECK (max_advance_days BETWEEN 1 AND 365),
    updated_by TEXT,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
INSERT INTO schema_migration (version, name)
VALUES (2, 'reservation request workflow')
ON CONFLICT (version) DO NOTHING;

-- ---------------------------------------------------------------------------
-- Sessions — one per inbound call or text thread
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS session (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    restaurant_id       TEXT NOT NULL REFERENCES restaurant(id),
    menu_version_id     BIGINT NOT NULL REFERENCES menu_version(id),
    channel             TEXT NOT NULL
                            CHECK (channel IN ('voice', 'sms', 'web', 'manual')),
    -- Telnyx call_control_id, or the SMS thread key. Unique so a webhook
    -- replay cannot create a second session for the same call.
    external_id         TEXT UNIQUE,
    caller_phone        TEXT,
    started_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    ended_at            TIMESTAMPTZ,
    end_reason          TEXT,   -- completed | caller_hangup | timeout | escalated | error
    -- live cart between turns; cleared when the order is placed
    cart                JSONB,
    escalated_at        TIMESTAMPTZ,
    escalation_reason   TEXT
);

-- Every cart-changing tool call, in order. If the server restarts mid-call the
-- cart is rebuilt by replaying these against the same menu version.
CREATE TABLE IF NOT EXISTS call_journal (
    id          BIGSERIAL PRIMARY KEY,
    session_id  UUID NOT NULL REFERENCES session(id) ON DELETE CASCADE,
    seq         INTEGER NOT NULL,
    tool        TEXT NOT NULL,
    args        JSONB NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (session_id, seq)
);
INSERT INTO schema_migration (version, name)
VALUES (4, 'call journal for mid-call resume')
ON CONFLICT (version) DO NOTHING;

-- The resolution log: what the matcher heard, what it chose, how sure it was,
-- and the runner-up. Written by live calls, never read by the call path. It
-- is what shows which phrases callers use that the menu does not know, and
-- which dishes callers cannot tell apart. Cannot be backfilled.
CREATE TABLE IF NOT EXISTS resolution (
    id                BIGSERIAL PRIMARY KEY,
    session_id        UUID NOT NULL REFERENCES session(id) ON DELETE CASCADE,
    restaurant_id     TEXT NOT NULL,
    tool              TEXT NOT NULL,
    kind              TEXT NOT NULL CHECK (kind IN ('item', 'option', 'size')),
    heard             TEXT NOT NULL,
    outcome           TEXT NOT NULL CHECK (outcome IN ('matched', 'ambiguous', 'no_match')),
    resolved_id       TEXT,
    resolved_name     TEXT,
    score             REAL,
    runner_up_id      TEXT,
    runner_up_name    TEXT,
    runner_up_score   REAL,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS resolution_restaurant_outcome
    ON resolution (restaurant_id, outcome, created_at DESC);
INSERT INTO schema_migration (version, name)
VALUES (5, 'resolution log')
ON CONFLICT (version) DO NOTHING;

-- The per-location subscription plan (PRICING_PLANS_2026-09-23.md). One row
-- per location; a missing row means Small, the launch default. The monthly
-- minute allowance is the controlling limit; the daily-call figure is a
-- usage-review signal, never a cutoff — see cost_control.PLANS.
CREATE TABLE IF NOT EXISTS location_plan (
    restaurant_id TEXT PRIMARY KEY REFERENCES restaurant(id) ON DELETE CASCADE,
    plan          TEXT NOT NULL CHECK (plan IN ('small', 'medium', 'grande')),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
INSERT INTO schema_migration (version, name)
VALUES (6, 'per-location plan storage')
ON CONFLICT (version) DO NOTHING;

-- Subscription billing (billing.py). Cherry never touches a restaurant's
-- money; this records what each location OWES Cherry, so invoices can be
-- created in QuickBooks (card or ACH) from one reviewed export. Amounts are
-- whole cents, dates are ISO text. An invoice is never edited: it is voided.
CREATE TABLE IF NOT EXISTS billing_contract (
    restaurant_id TEXT PRIMARY KEY REFERENCES restaurant(id) ON DELETE CASCADE,
    customer TEXT NOT NULL,
    billing_email TEXT,
    plan TEXT NOT NULL CHECK (plan IN ('small','medium','large')),
    term TEXT NOT NULL CHECK (term IN ('monthly','annual')),
    starts_on TEXT NOT NULL,
    bill_from TEXT,
    ends_on TEXT,
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','paused','cancelled')),
    multi_location BOOLEAN NOT NULL DEFAULT FALSE,
    onboarding_fee_cents INTEGER CHECK (onboarding_fee_cents IS NULL OR onboarding_fee_cents >= 0),
    price_override_cents INTEGER CHECK (price_override_cents IS NULL OR price_override_cents >= 0),
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS invoice (
    id BIGSERIAL PRIMARY KEY,
    number TEXT NOT NULL UNIQUE,
    restaurant_id TEXT NOT NULL REFERENCES restaurant(id),
    customer TEXT NOT NULL,
    plan TEXT NOT NULL,
    term TEXT NOT NULL,
    period_start TEXT NOT NULL,
    period_end TEXT NOT NULL,
    issued_on TEXT NOT NULL,
    due_on TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'issued' CHECK (status IN ('issued','exported','void')),
    total_cents INTEGER NOT NULL CHECK (total_cents >= 0),
    memo TEXT,
    exported_at TIMESTAMPTZ,
    void_reason TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (restaurant_id, period_start)
);
CREATE TABLE IF NOT EXISTS invoice_line (
    id BIGSERIAL PRIMARY KEY,
    invoice_id BIGINT NOT NULL REFERENCES invoice(id) ON DELETE CASCADE,
    seq INTEGER NOT NULL,
    kind TEXT NOT NULL CHECK (kind IN ('subscription','onboarding','adjustment')),
    item TEXT NOT NULL,
    description TEXT NOT NULL,
    quantity INTEGER NOT NULL DEFAULT 1,
    unit_cents INTEGER NOT NULL,
    amount_cents INTEGER NOT NULL,
    UNIQUE (invoice_id, seq)
);
CREATE TABLE IF NOT EXISTS billing_adjustment (
    id BIGSERIAL PRIMARY KEY,
    restaurant_id TEXT NOT NULL REFERENCES restaurant(id),
    amount_cents INTEGER NOT NULL CHECK (amount_cents <> 0),
    memo TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    applied_invoice_id BIGINT REFERENCES invoice(id)
);
CREATE INDEX IF NOT EXISTS invoice_period ON invoice (period_start, status);
INSERT INTO schema_migration (version, name)
VALUES (8, 'subscription billing')
ON CONFLICT (version) DO NOTHING;

CREATE TABLE IF NOT EXISTS voice_usage (
    session_id UUID PRIMARY KEY REFERENCES session(id),
    provider TEXT NOT NULL,
    processed_characters INTEGER NOT NULL DEFAULT 0 CHECK (processed_characters >= 0),
    transcribed_audio_ms INTEGER NOT NULL DEFAULT 0 CHECK (transcribed_audio_ms >= 0),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS session_restaurant_started ON session (restaurant_id, started_at DESC);
CREATE INDEX IF NOT EXISTS session_open ON session (restaurant_id) WHERE ended_at IS NULL;

-- Every turn, for the accuracy work in weeks 9-10. Cheap to write now,
-- impossible to backfill later.
CREATE TABLE IF NOT EXISTS turn (
    id                  BIGSERIAL PRIMARY KEY,
    session_id          UUID NOT NULL REFERENCES session(id) ON DELETE CASCADE,
    seq                 INTEGER NOT NULL,
    speaker             TEXT NOT NULL CHECK (speaker IN ('caller', 'agent', 'system')),
    text                TEXT,
    asr_confidence      REAL,
    intent              TEXT,
    engine_issue_code   TEXT,       -- what the order engine objected to, if anything
    latency_ms          INTEGER,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (session_id, seq)
);

-- ---------------------------------------------------------------------------
-- Orders — immutable once placed
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS "order" (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    restaurant_id       TEXT NOT NULL REFERENCES restaurant(id),
    session_id          UUID REFERENCES session(id),
    menu_version_id     BIGINT NOT NULL REFERENCES menu_version(id),
    -- human-facing, short, spoken aloud: "order 4471"
    short_code          TEXT NOT NULL,
    channel             TEXT NOT NULL
                            CHECK (channel IN ('voice', 'sms', 'web', 'manual')),
    customer_name       TEXT,
    customer_phone      TEXT,
    fulfilment          TEXT NOT NULL DEFAULT 'pickup'
                            CHECK (fulfilment IN ('pickup', 'delivery', 'dinein')),
    -- the whole to_normalized_order() payload, exactly as priced
    snapshot            JSONB NOT NULL,
    subtotal_cents      INTEGER NOT NULL CHECK (subtotal_cents >= 0),
    tax_cents           INTEGER NOT NULL CHECK (tax_cents >= 0),
    total_cents         INTEGER NOT NULL CHECK (total_cents >= 0),
    status              TEXT NOT NULL DEFAULT 'placed'
                            CHECK (status IN ('placed', 'sent', 'acknowledged',
                                              'ready', 'completed', 'cancelled',
                                              'failed')),
    placed_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (restaurant_id, short_code)
);

-- One call, one order. Telnyx retries webhooks; without this a retry places
-- a second identical order and the kitchen cooks it twice.
CREATE UNIQUE INDEX IF NOT EXISTS one_order_per_session ON "order" (session_id)
    WHERE session_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS order_restaurant_placed ON "order" (restaurant_id, placed_at DESC);
CREATE INDEX IF NOT EXISTS order_open ON "order" (restaurant_id, status)
    WHERE status IN ('placed', 'sent', 'acknowledged');

-- The snapshot is the record. Refuse UPDATEs to the money and the contents.
CREATE OR REPLACE FUNCTION order_is_immutable() RETURNS trigger AS $$
BEGIN
    IF NEW.snapshot IS DISTINCT FROM OLD.snapshot
       OR NEW.subtotal_cents IS DISTINCT FROM OLD.subtotal_cents
       OR NEW.tax_cents      IS DISTINCT FROM OLD.tax_cents
       OR NEW.total_cents    IS DISTINCT FROM OLD.total_cents
       OR NEW.menu_version_id IS DISTINCT FROM OLD.menu_version_id THEN
        RAISE EXCEPTION
          'order % is immutable: cancel it and place a new one', OLD.id;
    END IF;
    RETURN NEW;
END $$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS order_immutable ON "order";
CREATE TRIGGER order_immutable BEFORE UPDATE ON "order"
    FOR EACH ROW EXECUTE FUNCTION order_is_immutable();

-- ---------------------------------------------------------------------------
-- Delivery to the POS or to the fallback — same table either way
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS order_delivery (
    id                  BIGSERIAL PRIMARY KEY,
    order_id            UUID NOT NULL REFERENCES "order"(id),
    sink                TEXT NOT NULL,   -- manual | toast | square | heartland
    attempt             INTEGER NOT NULL DEFAULT 1,
    status              TEXT NOT NULL
                            CHECK (status IN ('pending', 'sent', 'acknowledged',
                                              'failed', 'abandoned')),
    -- what the sink gave back: a POS order GUID, or the SMS message id
    external_ref        TEXT,
    error_kind          TEXT,   -- connection | rejected | unavailable | auth
    error_detail        TEXT,
    acknowledged_by     TEXT,
    sent_at             TIMESTAMPTZ,
    acknowledged_at     TIMESTAMPTZ,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (order_id, sink, attempt)
);

CREATE INDEX IF NOT EXISTS delivery_unacked ON order_delivery (created_at)
    WHERE status IN ('pending', 'sent');

-- ---------------------------------------------------------------------------
-- Payment — STATUS ONLY. Cherry never handles money.
-- ---------------------------------------------------------------------------
--
-- There is deliberately no column here that can hold a card number, a CVV, an
-- expiry, a cardholder name, a bank account, or a payment token. The POS
-- issues its own hosted link; Cherry texts it and records what the POS says
-- happened. If a future requirement seems to need card data here, it is the
-- requirement that is wrong.

CREATE TABLE IF NOT EXISTS payment (
    id                  BIGSERIAL PRIMARY KEY,
    order_id            UUID NOT NULL UNIQUE REFERENCES "order"(id),
    -- who is collecting: always the restaurant, never Cherry
    collected_by        TEXT NOT NULL DEFAULT 'restaurant_pos'
                            CHECK (collected_by = 'restaurant_pos'),
    method              TEXT NOT NULL
                            CHECK (method IN ('pay_link', 'at_pickup', 'unknown')),
    status              TEXT NOT NULL DEFAULT 'not_required'
                            CHECK (status IN ('not_required', 'link_pending',
                                              'link_sent', 'paid', 'expired',
                                              'failed', 'refunded')),
    amount_cents        INTEGER NOT NULL CHECK (amount_cents >= 0),
    -- POS-hosted checkout URL. https only, and never logged in full.
    pay_url             TEXT CHECK (pay_url IS NULL OR pay_url LIKE 'https://%'),
    pay_url_expires_at  TIMESTAMPTZ,
    -- the POS's own reference, for reconciliation
    pos_payment_ref     TEXT,
    -- checkout object id, used to revoke an unpaid/expired hosted link
    provider_link_ref   TEXT,
    link_sent_at        TIMESTAMPTZ,
    settled_at          TIMESTAMPTZ,
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS order_release (
    order_id UUID PRIMARY KEY REFERENCES "order"(id),
    status TEXT NOT NULL CHECK (status IN ('claimed','sent')),
    claimed_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE payment ADD COLUMN IF NOT EXISTS provider_link_ref TEXT;
INSERT INTO schema_migration (version, name)
VALUES (3, 'payment-gated POS release')
ON CONFLICT (version) DO NOTHING;

-- ---------------------------------------------------------------------------
-- SMS — outbound relay and the QR/web channel's confirmations
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS sms_message (
    id                  BIGSERIAL PRIMARY KEY,
    restaurant_id       TEXT REFERENCES restaurant(id),
    order_id            UUID REFERENCES "order"(id),
    session_id          UUID REFERENCES session(id),
    direction           TEXT NOT NULL CHECK (direction IN ('out', 'in')),
    to_phone            TEXT NOT NULL,
    from_phone          TEXT,
    kind                TEXT NOT NULL
                            CHECK (kind IN ('ticket', 'pay_link', 'confirmation',
                                            'ready', 'escalation', 'reply')),
    body                TEXT NOT NULL,
    provider_ref        TEXT,       -- Telnyx message id
    status              TEXT NOT NULL DEFAULT 'queued'
                            CHECK (status IN ('queued', 'sent', 'delivered',
                                              'failed')),
    error_detail        TEXT,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS sms_order ON sms_message (order_id);
CREATE INDEX IF NOT EXISTS sms_provider_ref ON sms_message (provider_ref);

-- Numbers that must never be texted again.
--
-- A caller who replies STOP has opted out, and texting them afterwards is a
-- carrier violation, not a preference we get to weigh. Telnyx reports the
-- block ASYNCHRONOUSLY (error 40300 arrives on the message webhook, not in
-- the send response), so by then the message has already gone out. That is
-- why this table exists: the only way to honour an opt-out is to remember it
-- and check before sending.
CREATE TABLE IF NOT EXISTS sms_suppression (
    phone               TEXT PRIMARY KEY,
    reason              TEXT NOT NULL,
    source              TEXT NOT NULL
                            CHECK (source IN ('inbound_stop', 'provider_error',
                                              'manual')),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------------
-- Audit log — append only, one row per thing that happened
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS event (
    id                  BIGSERIAL PRIMARY KEY,
    restaurant_id       TEXT REFERENCES restaurant(id),
    session_id          UUID REFERENCES session(id),
    order_id            UUID REFERENCES "order"(id),
    kind                TEXT NOT NULL,
    detail              JSONB,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS event_restaurant_time ON event (restaurant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS event_kind_time ON event (kind, created_at DESC);

-- A provider retries the same event id until it receives HTTP 200. This table
-- makes applying those webhooks exactly-once from Cherry's point of view.
CREATE TABLE IF NOT EXISTS webhook_receipt (
    provider            TEXT NOT NULL,
    event_id             TEXT NOT NULL,
    event_type           TEXT,
    received_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (provider, event_id)
);
