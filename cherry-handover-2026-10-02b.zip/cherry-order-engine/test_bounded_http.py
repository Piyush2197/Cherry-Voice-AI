#!/usr/bin/env python3
"""
The shared HTTP server class — and a guard against it being copied again.

`server.py` and `voice_gateway.py` each had their own
`BoundedThreadingHTTPServer`. They drifted: the gateway grew a concurrency cap
and the API — the busier service, since it answers every tool call on every
live conversation — did not. Nobody chose that; two copies simply diverged.

So these tests check two things: that the shared class behaves, and that neither
service has quietly reintroduced a private copy of it.
"""

from __future__ import annotations

import ast
import pathlib
import threading
import time
import urllib.request

import bounded_http
from bounded_http import BoundedThreadingHTTPServer

_passed = _failed = 0


def check(name, condition, detail=""):
    global _passed, _failed
    if condition:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


def t_defaults_cover_a_burst():
    check("backlog is 128, not the stdlib 5", bounded_http.DEFAULT_BACKLOG == 128)
    check("concurrency is capped", bounded_http.DEFAULT_MAX_CONCURRENT == 64)
    srv = BoundedThreadingHTTPServer(("127.0.0.1", 0), None)
    try:
        check("the instance carries the backlog",
              srv.request_queue_size == 128, str(srv.request_queue_size))
        check("the instance carries the cap", srv.max_concurrent == 64)
        check("threads are daemons", srv.daemon_threads is True)
    finally:
        srv.server_close()


def t_the_cap_is_configurable_and_sane():
    srv = BoundedThreadingHTTPServer(("127.0.0.1", 0), None, max_concurrent=4)
    try:
        check("cap can be lowered", srv.max_concurrent == 4)
    finally:
        srv.server_close()
    try:
        BoundedThreadingHTTPServer(("127.0.0.1", 0), None, max_concurrent=0)
        check("a zero cap is refused", False, "accepted max_concurrent=0")
    except ValueError:
        check("a zero cap is refused", True)


def t_concurrency_is_actually_bounded():
    """The cap must bind, not merely exist as an attribute."""
    from http.server import BaseHTTPRequestHandler

    live = 0
    peak = 0
    lock = threading.Lock()

    class H(BaseHTTPRequestHandler):
        def do_GET(self):
            nonlocal live, peak
            with lock:
                live += 1
                peak = max(peak, live)
            time.sleep(0.15)
            with lock:
                live -= 1
            body = b"ok"
            self.send_response(200)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *a):
            pass

    srv = BoundedThreadingHTTPServer(("127.0.0.1", 0), H, max_concurrent=3)
    port = srv.server_address[1]
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        def hit():
            try:
                with urllib.request.urlopen(
                        f"http://127.0.0.1:{port}/", timeout=10) as r:
                    r.read()
            except OSError:
                pass

        threads = [threading.Thread(target=hit) for _ in range(12)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(15)
        time.sleep(0.5)
        check("no more than 3 handlers ran at once", peak <= 3, f"peak was {peak}")
        check("work still got done", peak >= 1, f"peak was {peak}")
    finally:
        srv.shutdown()
        srv.server_close()


def t_neither_service_defines_its_own_copy():
    """The regression guard: re-adding a local class is how this drifted."""
    for f in ("server.py", "voice_gateway.py"):
        tree = ast.parse(pathlib.Path(f).read_text())
        classes = [n.name for n in tree.body if isinstance(n, ast.ClassDef)]
        check(f"{f} does not define its own server class",
              "BoundedThreadingHTTPServer" not in classes, str(classes))
        check(f"{f} imports the shared one",
              "from bounded_http import BoundedThreadingHTTPServer"
              in pathlib.Path(f).read_text())


def t_the_api_service_gets_the_cap_too():
    """The actual bug: Cherry's API had no ceiling while the gateway did."""
    import server
    from order_store import OrderStore
    store = OrderStore.sqlite()
    store.upsert_restaurant("r", "R", "burger", active=True,
                            staff_phone="+13135550100",
                            inbound_phone="+13135550111")
    app = server.Cherry(store, sms=server.FakeSmsSender(), api_key="k")
    srv = server.build_server(app, 0)
    try:
        check("the API server is bounded", srv.max_concurrent == 64,
              str(getattr(srv, "max_concurrent", "no cap")))
        check("the API server queues rather than resetting",
              srv.request_queue_size == 128)
    finally:
        srv.server_close()


def t_the_gateway_builds_on_the_shared_class():
    import voice_gateway
    src = pathlib.Path("voice_gateway.py").read_text()
    check("gateway constructs the shared class",
          "BoundedThreadingHTTPServer((" in src)
    check("no second definition survives",
          "class BoundedThreadingHTTPServer" not in src)


def main():
    for fn in (t_defaults_cover_a_burst, t_the_cap_is_configurable_and_sane,
               t_concurrency_is_actually_bounded,
               t_neither_service_defines_its_own_copy,
               t_the_api_service_gets_the_cap_too,
               t_the_gateway_builds_on_the_shared_class):
        try:
            fn()
        except Exception as exc:                       # noqa: BLE001
            import traceback
            check(f"{fn.__name__} raised", False, repr(exc))
            traceback.print_exc()
    if _failed:
        print(f"{_passed} passed, {_failed} failed (bounded http)")
        return 1
    print(f"{_passed} passed, 0 failed (bounded http)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
