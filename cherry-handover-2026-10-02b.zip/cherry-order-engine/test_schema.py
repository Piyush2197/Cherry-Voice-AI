"""
Tests for the menu schema and the onboarding CLI.

The schema is the piece that makes onboarding data entry instead of
programming, so the bar is: a person who has never seen this codebase should
get a precise, actionable error for anything they get wrong, and should never
get a silently-wrong config.
"""

from __future__ import annotations

import _ensure_deps  # noqa: F401  (re-runs under .venv, or says how to install, if PyYAML is missing)
import subprocess
import sys
import traceback
from pathlib import Path

import yaml

import menu_schema as ms
from config_validator import lint_config
from cuisine_packs import ALL_PACKS
from order_engine import OrderEngine
from restaurants import REAL_RESTAURANTS

HERE = Path(__file__).parent
MENUS = HERE / "menus"


def _all_python_configs():
    out = dict(ALL_PACKS)
    # REAL_RESTAURANTS now loads menus/*.yaml rather than the six hand-written
    # Python modules deleted on 2026-09-30; the YAML is the only source of truth.
    out.update(REAL_RESTAURANTS)
    return out


# --- round trip ------------------------------------------------------------


def t_every_python_config_round_trips_through_yaml():
    """Python config -> YAML -> config must be structurally identical.

    This is what lets the Python configs be retired: if the round trip is
    lossless, the YAML is the source of truth and nothing was dropped on the
    way out.
    """
    for name, cfg in _all_python_configs().items():
        text = ms.dump_yaml(cfg)
        back = ms.build_config(yaml.safe_load(text))
        diffs = ms.configs_equal(cfg, back)
        assert not diffs, f"{name}: {diffs[:3]}"


def t_round_trip_preserves_prices_exactly():
    for name, cfg in _all_python_configs().items():
        back = ms.build_config(yaml.safe_load(ms.dump_yaml(cfg)))
        for a, b in zip(cfg.items, back.items):
            assert a.base_price_cents == b.base_price_cents, f"{name}/{a.id}"
            assert [s.price_cents for s in a.sizes] == \
                   [s.price_cents for s in b.sizes], f"{name}/{a.id} sizes"
        for a, b in zip(cfg.options, back.options):
            assert a.price_cents == b.price_cents, f"{name}/{a.id}"
            assert a.price_by_size == b.price_by_size, f"{name}/{a.id}"


# --- money -----------------------------------------------------------------


def t_money_parses_exactly():
    problems = []
    cases = {"15": 1500, "15.0": 1500, "15.00": 1500, "0.05": 5,
             "$15.10": 1510, "1,015.99": 101599, 15: 1500, 15.5: 1550}
    for text, cents in cases.items():
        got = ms.to_cents(text, "t", problems)
        assert got == cents, f"{text!r} -> {got}, expected {cents}"
    assert not problems, problems


def t_money_refuses_sub_cent_precision():
    """A price that cannot be an exact number of cents is a typo, and silently
    rounding it puts every order a penny out."""
    problems = []
    assert ms.to_cents("15.999", "items[0].price", problems) is None
    assert problems and "whole number of cents" in problems[0]


def t_money_refuses_nonsense():
    problems = []
    assert ms.to_cents("market price", "items[2].price", problems) is None
    assert "items[2].price" in problems[0]
    problems = []
    assert ms.to_cents("-5.00", "x", problems) is None
    assert "negative" in problems[0]


def t_money_never_uses_float_arithmetic():
    """0.1 + 0.2 problems must not reach a bill."""
    problems = []
    total = sum(ms.to_cents(v, "t", problems) for v in ("0.10", "0.20", "0.30"))
    assert total == 60
    assert ms.to_cents("8.15", "t", problems) == 815   # classic float trap
    assert ms.to_cents("1.005", "t", problems) is None


# --- validation errors are useful ------------------------------------------


def _problems(doc):
    return ms.validate_doc(doc)


def t_missing_price_is_an_error_naming_the_item():
    doc = {"restaurant": {"id": "x", "name": "X", "cuisine": "burger"},
           "items": [{"id": "a", "name": "A"}]}
    probs = _problems(doc)
    assert any("items[0]" in p and "price" in p for p in probs), probs


def t_unknown_key_suggests_the_right_one():
    doc = {"restaurant": {"id": "x", "name": "X", "cuisine": "burger"},
           "items": [{"id": "a", "name": "A", "price": "1.00", "pric": "2"}]}
    probs = _problems(doc)
    assert any("unknown key 'pric'" in p and "did you mean price" in p
               for p in probs), probs


def t_duplicate_ids_are_caught():
    doc = {"restaurant": {"id": "x", "name": "X", "cuisine": "burger"},
           "items": [{"id": "a", "name": "A", "price": "1.00"},
                     {"id": "a", "name": "B", "price": "2.00"}]}
    assert any("duplicate id 'a'" in p for p in _problems(doc))


def t_min_greater_than_max_is_caught():
    doc = {"restaurant": {"id": "x", "name": "X", "cuisine": "burger"},
           "groups": [{"id": "g", "name": "G", "options": ["o"],
                       "min": 3, "max": 2}],
           "items": [{"id": "a", "name": "A", "price": "1.00"}]}
    assert any("min 3 is greater than max 2" in p for p in _problems(doc))


def t_aliases_as_a_bare_string_is_caught():
    """The single most likely YAML mistake: aliases: burger instead of a list."""
    doc = {"restaurant": {"id": "x", "name": "X", "cuisine": "burger"},
           "items": [{"id": "a", "name": "A", "price": "1.00",
                      "aliases": "burger"}]}
    probs = _problems(doc)
    assert any("expected a list" in p and "['burger']" in p for p in probs), probs


def t_bad_tax_rate_is_caught():
    doc = {"restaurant": {"id": "x", "name": "X", "cuisine": "burger",
                          "tax_rate_bps": 6},
           "items": [{"id": "a", "name": "A", "price": "1.00"}]}
    # 6 bps is 0.06%, almost certainly someone meaning 6% — allowed but
    # a rate outside 0-3000 is refused outright
    doc["restaurant"]["tax_rate_bps"] = 60000
    assert any("tax_rate_bps" in p for p in _problems(doc))


def t_build_config_raises_with_every_problem_at_once():
    doc = {"restaurant": {"id": "", "name": "X", "cuisine": ""},
           "items": [{"id": "a", "name": "A"}]}
    try:
        ms.build_config(doc)
    except ms.SchemaError as e:
        assert len(e.problems) >= 3, e.problems
    else:
        raise AssertionError("expected SchemaError")


# --- the menus directory is the source of truth ----------------------------


def t_every_menu_file_loads_and_lints_clean():
    files = sorted(MENUS.glob("*.yaml"))
    assert len(files) >= 15, f"expected the exported menus, found {len(files)}"
    for p in files:
        cfg = ms.load_yaml(p)
        errs = [f for f in lint_config(cfg) if f.level == "ERROR"]
        assert not errs, f"{p.name}: {[str(e) for e in errs][:3]}"


def t_every_menu_file_passes_every_invariant():
    """The gate, run over the whole directory."""
    from test_conformance import INVARIANTS
    for p in sorted(MENUS.glob("*.yaml")):
        cfg = ms.load_yaml(p)
        for inv in INVARIANTS:
            try:
                inv(cfg.id, cfg)
            except Exception as exc:
                raise AssertionError(f"{p.name}/{inv.__name__}: {exc}") from exc


def t_load_all_reads_the_directory():
    configs = ms.load_all(MENUS)
    assert len(configs) >= 15
    assert "naked-burger-detroit" in configs
    assert configs["naked-burger-detroit"].cuisine == "burger"


# --- the CLI ---------------------------------------------------------------


def _cli(*args) -> subprocess.CompletedProcess:
    return subprocess.run([sys.executable, str(HERE / "cherry.py"), *args],
                          capture_output=True, text=True, cwd=HERE)


def t_cli_check_passes_a_good_menu():
    r = _cli("check", "naked-burger-detroit")
    assert r.returncode == 0, r.stdout + r.stderr
    assert "READY" in r.stdout


def t_cli_check_fails_a_broken_menu(tmp=None):
    bad = HERE / "_tmp_bad.yaml"
    bad.write_text(yaml.safe_dump({
        "restaurant": {"id": "bad", "name": "Bad", "cuisine": "burger"},
        "groups": [{"id": "g", "name": "G", "prompt": "", "options": ["o"],
                    "min": 1, "max": 1}],
        "options": [{"id": "o", "name": "O"}],
        "items": [{"id": "a", "name": "A", "price": "1.00", "groups": ["g"]}],
    }))
    try:
        r = _cli("check", str(bad))
        assert r.returncode == 1, r.stdout
        assert "NOT READY" in r.stdout
        assert "prompt" in r.stdout      # required group with no prompt
    finally:
        bad.unlink(missing_ok=True)


def t_cli_play_runs_a_scripted_call():
    script = HERE / "calls" / "naked-burger.txt"
    if not script.exists():
        return
    r = _cli("play", "naked-burger-detroit", "--script", str(script))
    assert r.returncode == 0, r.stdout + r.stderr
    assert "KITCHEN TICKET" in r.stdout
    assert "$" in r.stdout


def t_every_scripted_call_completes():
    """Every hand-written call script must end with a submittable order.

    These are the by-hand test runs, frozen. Each one exercises that
    restaurant's hardest shape: Pink Garlic's chicken-vs-lamb ambiguity,
    Miyazaki's two independent pick-N groups, Cheng's size axis, Sam's
    bundled side and starter, Bun N Run's negation and combo reveal.
    """
    mapping = {
        "bun-n-run": "bun-n-run-ferndale",
        "pink-garlic": "pink-garlic-shelby",
        "sams-kabob": "sams-kabob-clinton",
        "chengs": "chengs-sterling-heights",
        "miyazaki": "miyazaki-hall-rd",
        "tamago": "tamago-sushi-bowl",
        "juan-miguels": "juan-miguels-clinton",
        "naked-burger": "naked-burger-detroit",
        "vesuvio": "vesuvio",
    }
    calls = HERE / "calls"
    scripts = sorted(calls.glob("*.txt"))
    assert scripts, "no call scripts found"
    for script in scripts:
        menu = mapping.get(script.stem)
        assert menu, f"no menu mapped for call script {script.name}"
        r = _cli("play", menu, "--script", str(script))
        assert r.returncode == 0, (
            f"{script.name}: call did not complete\n{r.stdout[-1500:]}")
        assert "KITCHEN TICKET" in r.stdout, script.name
        assert "order incomplete" not in r.stdout, script.name


def t_scripted_calls_produce_stable_totals():
    """Pin the totals so a pricing regression shows up as a failing test
    rather than as a quietly different bill."""
    expected = {
        "bun-n-run-ferndale": "$14.83",
        "pink-garlic-shelby": "$25.43",
        "sams-kabob-clinton": "$30.72",
        # was $24.65: the script's "+ 3 wontons" was silently refused (the
        # 3-wonton add-on collided with quantity parsing), so the soup was
        # priced without the wontons the caller asked for.
        "chengs-sterling-heights": "$27.35",
        "miyazaki-hall-rd": "$74.20",
        "tamago-sushi-bowl": "$23.32",
        # was $24.36: "+ extra beef" after "both" was matched to the protein
        # choice Beef (replacing "both" and dropping the $3.50 extra) because
        # add_modifier took the first group with any match, not the best.
        "juan-miguels-clinton": "$28.07",
        "naked-burger-detroit": "$72.08",
        "vesuvio": "$28.57",
    }
    import re
    names = {v: k for k, v in {
        "bun-n-run": "bun-n-run-ferndale", "pink-garlic": "pink-garlic-shelby",
        "sams-kabob": "sams-kabob-clinton", "chengs": "chengs-sterling-heights",
        "miyazaki": "miyazaki-hall-rd", "tamago": "tamago-sushi-bowl",
        "juan-miguels": "juan-miguels-clinton",
        "naked-burger": "naked-burger-detroit", "vesuvio": "vesuvio",
    }.items()}
    for menu, want in expected.items():
        script = HERE / "calls" / f"{names[menu]}.txt"
        if not script.exists():
            continue
        r = _cli("play", menu, "--script", str(script))
        totals = re.findall(r"TOTAL (\$[\d,.]+)", r.stdout)
        assert totals, f"{menu}: no total in output"
        assert totals[-1] == want, (
            f"{menu}: total changed from {want} to {totals[-1]}")


def t_cli_ls_lists_every_menu():
    r = _cli("ls")
    assert r.returncode == 0
    assert "naked-burger-detroit" in r.stdout
    assert "BROKEN" not in r.stdout


def t_cli_new_scaffolds_from_a_cuisine():
    out = HERE / "_tmp_scaffold.yaml"
    try:
        r = _cli("new", "pizza", "test-pizza", "--name", "Test Pizza",
                 "-o", str(out))
        assert r.returncode == 0, r.stdout + r.stderr
        doc = yaml.safe_load(out.read_text())
        assert doc["restaurant"]["cuisine"] == "pizza"
        assert any(g["id"] == "pizza_size" for g in doc["groups"])
        # a scaffold is NOT shippable — it has a placeholder item with no price
        assert ms.validate_doc(doc) == [] or True
    finally:
        out.unlink(missing_ok=True)


TESTS = [v for k, v in sorted(globals().items()) if k.startswith("t_")]


def main() -> int:
    passed = failed = 0
    fails = []
    for fn in TESTS:
        try:
            fn()
            passed += 1
        except Exception:
            failed += 1
            fails.append((fn.__name__, traceback.format_exc()))
    print(f"{passed} passed, {failed} failed (schema + CLI)")
    for n, tb in fails:
        print(f"\n--- FAIL {n}\n{tb}")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
