# Cherry developer handover — 22 September 2026

## Where development stands

Cherry is at **integration and live-acceptance stage**, not production launch. The
ordering engine, seven pilot catalogs, multi-location routing, itemized Square
checkout, Telnyx SMS/transfer adapters, Inworld HTTP tool contract, persistence,
operator controls, and deployment checks exist in the repository. No pilot
location has a recorded real-call, real-payment, and merchant-POS acceptance.
Passing local tests does not establish that a location is live.

The current working tree adds a **forwarded-number, checkout-handoff-only**
launch mode. A restaurant keeps its published number at its current carrier
and forwards it to a separate Telnyx DID. Cherry sends an order-specific,
itemized Square checkout link and ends its call flow. Square's checkout/POS
handles the paid order; Cherry does not issue a second kitchen ticket. This
mode is selected by `CHERRY_CHECKOUT_HANDOFF_ONLY=1`. The older paid-webhook
kitchen-release path remains in code but is not the mode described in
`DEVELOPER_HANDOFF.md` and `VOICE_FORWARDING.md`.

## What is ready to hand over

- Seven location-specific pilot menus and routing entries in
  `deployments/pilot-locations.yaml`. Menus pass local validation; owner
  approval of live prices, modifiers, tax, hours, and fallback numbers remains.
- `voice_gateway.py` and `voice/inworld_bridge.py` expose call start, tool,
  finish, abandon, and staff-handoff events. They are HTTP adapters, not a SIP
  media server or a completed Inworld-specific worker.
- `pilot_deploy.py` now requires a separate direct staff fallback when
  `CHERRY_REQUIRE_DIRECT_FALLBACK=1`; it rejects routes that would loop through
  a forwarded public number or another active Telnyx DID.
- The Square path creates an order-specific review-and-pay link. A generic
  restaurant ordering page cannot receive Cherry's already-built cart.
- Managed Postgres setup, backup/restore tooling, signed webhook adapters,
  operator UI, monitoring jobs, failover drill, and per-location smoke checks
  are implemented but need production configuration and live proof.
- Ten named draft demo locations have practice packets toward the separate
  target of 20 by December 2026. These demos are not certified live locations.

## Developer's first sequence

1. Review the current working tree, especially the uncommitted launch-mode
   changes, and use `DEVELOPER_HANDOFF.md` as the current deployment sequence.
   `PRODUCTION_HANDOFF.md`, `DEPLOYMENT_STATUS.md`, `TASKS.md`, and
   `NEW_CHAT_HANDOFF.md` still describe the earlier paid-webhook release mode in
   places. Reconcile those documents before treating an older archive as the
   launch runbook.
2. In the actual Telnyx and Inworld accounts, prove how the DID's audio reaches
   Inworld and whether that call exposes the Telnyx `call_control_id` to the
   worker. If a plain SIP route does not expose it, implement a supported SIP
   transfer or change the Telnyx route before promising human handoff.
3. Provision the production host, TLS, managed Postgres with backup and a
   successful restore drill, scoped API principals, and a secret manager.
4. For the first location, obtain owner-approved menu/hours, merchant Square
   authorization and location ID, one voice-capable Telnyx DID, an approved
   messaging number/campaign, and a separately reachable direct staff line.
5. Deploy one Cherry server and one voice gateway initially; connect Inworld
   events and real SMS. Run `pilot_deploy.py plan`, `apply --sink square`,
   `verify`, `checkout-ready`, `pilot_smoke.py`, and `failover_drill.py` for that
   location with production settings.
6. Before public-number forwarding, call the Telnyx DID directly and verify
   greeting, precise cart and tax, caller ID, SMS delivery, checkout contents,
   controlled payment and merchant order visibility, and direct staff transfer.
   Then enable carrier forwarding and repeat from an outside phone. Record
   owner signoff and rollback instructions. Repeat separately per location.

## Current verification and limits

On 22 September, focused checks passed in the current working tree:
`test_voice_gateway.py` (6), `test_server.py` (151), `test_voice.py` (24),
`test_production_jobs.py` (17), `test_payment_gate.py` (8),
`test_telnyx_voice.py` (12), and `test_pilot_deploy.py` (28). This is 246
focused checks. `git diff --check` passed. The previously packaged paid-first
version had a reported full regression run of 1,354 passing tests, but that
count does **not** verify the current uncommitted changes. Run the complete
suite in the developer environment before deployment.

The root project folder is not the Git repository;
`work/cherry-order-engine/` is. The current launch-mode work is modified or
untracked there and is not committed. The older
`cherry-seven-location-paid-checkout-handoff.tar.gz` predates these changes.
Do not deploy from that archive for the forwarded-number, handoff-only launch.

## Product decision to keep explicit

The earlier plan used a signed Square paid event to trigger Cherry's kitchen
release. The current launch mode stops after checkout-link delivery and relies
on Square to surface the paid order to the merchant. Choose and document one
mode for each deployment; do not run the old reconciliation job in a way that
creates a duplicate ticket. Live Square/POS acceptance is required in either
mode.
