#!/usr/bin/env python3
"""The correction flywheel: caller re-phrasings become owner-confirmed aliases.

Covers the three sources (corrections, repeats, seeds), the patch writer,
and the apply gate — including the refusals that make automatic writing safe.
"""
from __future__ import annotations

import _ensure_deps  # noqa: F401  (re-runs under .venv, or says how to install, if PyYAML is missing)
import copy
import json
import tempfile
from pathlib import Path

import yaml

import alias_mining as am
from order_store import OrderStore

CHECKS = 0


def ok(cond: bool, label: str):
    global CHECKS
    CHECKS += 1
    if not cond:
        raise AssertionError(label)
    print(f"  ok  {label}")


def fixture() -> OrderStore:
    store = OrderStore.sqlite()
    store.upsert_restaurant("r", "Restaurant", "test", active=True)
    store.conn.execute("""INSERT INTO menu_version
      (restaurant_id,version,yaml,yaml_sha256,item_count,published_at,is_live)
      VALUES ('r',1,'x','x',1,CURRENT_TIMESTAMP,1)""")
    store.conn.commit()
    return store


def session_with(store, n, events):
    """events: list of (tool, kind, heard, outcome, resolved_id, resolved_name)."""
    sid = store.start_session("r", 1, external_id=f"mine-{n}")
    for tool, kind, heard, outcome, rid, rname in events:
        store.record_resolution(sid, {
            "tool": tool, "kind": kind, "heard": heard, "outcome": outcome,
            "resolved_id": rid, "resolved_name": rname, "score": None,
            "runner_up_id": None, "runner_up_name": None,
            "runner_up_score": None})
    return sid


# ---------------------------------------------------------------- corrections

def test_corrections():
    print("corrections")
    store = fixture()
    # two sessions with the same re-phrasing -> confident
    for n in (1, 2):
        session_with(store, n, [
            ("add_item", "item", "shish tawook sandwich", "no_match",
             None, None),
            ("add_item", "item", "chicken shawarma wrap", "matched",
             "cs_wrap", "Chicken Shawarma Wrap"),
        ])
    # one session where the caller plainly changed their mind -> still a
    # suggestion, never a fact; owner gate decides
    session_with(store, 3, [
        ("add_item", "item", "pie", "no_match", None, None),
        ("add_item", "item", "double burger", "matched", "dblb", "Double Burger"),
    ])
    # a miss with no retry matches nothing
    session_with(store, 4, [
        ("add_item", "item", "mystery", "no_match", None, None),
    ])
    # junk phrases never become suggestions
    session_with(store, 5, [
        ("add_item", "item", "2", "no_match", None, None),
        ("add_item", "item", "burger", "matched", "dblb", "Double Burger"),
    ])

    out = am.mine_corrections(store.conn)
    by_phrase = {c.phrase: c for c in out}
    ok("shish tawook sandwich" in by_phrase, "re-phrasing becomes a suggestion")
    c = by_phrase["shish tawook sandwich"]
    ok(c.item_id == "cs_wrap" and c.item_name == "Chicken Shawama Wrap".replace(
        "Chicken Shawama", "Chicken Shawarma"), "correction targets the retry match")
    ok(c.sessions == 2 and c.confident, "repeated pair is confident")
    ok("pie" in by_phrase and not by_phrase["pie"].confident,
       "changed-mind pair is a single-occurrence suggestion")
    ok("mystery" not in by_phrase, "unmatched-only session yields nothing")
    ok("2" not in by_phrase, "numeric junk rejected")
    ok(len([c for c in out if c.phrase == "pie"]) == 1,
       "same pair aggregates, not duplicates")

    # retry phrased identically is not a correction, it is a repeat
    session_with(store, 6, [
        ("add_item", "item", "identical", "no_match", None, None),
        ("add_item", "item", "identical", "no_match", None, None),
    ])
    out = am.mine_corrections(store.conn)
    ok("identical" not in {c.phrase for c in out},
       "identical retry is not a correction")


# --------------------------------------------------------------------- repeats

def test_repeats():
    print("repeats")
    store = fixture()
    for n in range(3):
        session_with(store, 100 + n, [
            ("add_item", "item", "baklava", "no_match", None, None)])
    session_with(store, 103, [
        ("add_item", "item", "once-only", "no_match", None, None)])

    reps = am.mine_repeats(store.conn, minimum=2)
    by_phrase = {r.phrase: r for r in reps}
    ok("baklava" in by_phrase and by_phrase["baklava"].count == 3,
       "frequent miss reported with its count")
    ok("once-only" not in by_phrase, "single miss below minimum")
    ok(all(r.restaurant_id == "r" for r in reps), "repeat carries restaurant")


# ----------------------------------------------------------------------- seeds

def test_seeds():
    print("seeds")
    doc = {
        "items": [
            {"id": "i1", "name": "Chicken Shawarma"},
            {"id": "i2", "name": "Beef Shawarma"},
            {"id": "i3", "name": "Falafel Plate"},
            {"id": "i4", "name": "Hummus Side"},
        ],
        "options": [
            {"id": "o1", "name": "Onion"},
            {"id": "o2", "name": "Avocado"},
        ],
    }
    seeds, broad = am.seed_suggestions(doc)
    ok(not broad, "small menu has nothing too broad")
    ok({"pollo", "shawarma"} <= {p for p, _ in seeds["i1"]},
       "chicken item gets spanish and arabic seeds")
    ok("shish tawook" not in {p for p, _ in seeds["i1"]},
       "shish tawook only matches dishes named tawook, not every chicken dish")
    ok({"carne", "shawarma"} <= {p for p, _ in seeds["i2"]},
       "beef item gets its seeds")
    ok("falafel" in {p for p, _ in seeds["i3"]}, "falafel dish gets its seed")
    ok("hummus" in {p for p, _ in seeds["i4"]}, "hummus gets its seed")
    ok("cebolla" in {p for p, _ in seeds["o1"]}, "onion option gets spanish noun")
    ok("aguacate" in {p for p, _ in seeds["o2"]}, "avocado option gets spanish noun")
    ok("queso" not in {p for p, _ in seeds.get("i4", [])},
       "no seed without a keyword in the name")

    # a menu with four chicken dishes: pollo is a human question, not an alias
    big = {"items": [{"id": f"c{i}", "name": f"Chicken Dish {i}"}
                     for i in range(4)]}
    seeds, broad = am.seed_suggestions(big)
    ok("pollo" in broad and broad["pollo"] == 4,
       "seed over the cap becomes 'too broad' with its count")
    ok(not any("pollo" == p for targets in seeds.values() for p, _ in targets),
       "too-broad seed never lands on a menu row")


# ------------------------------------------------------------- worklist + cli

def test_worklist_and_cli():
    print("worklist + cli")
    store = fixture()
    for n in (1, 2):
        session_with(store, n, [
            ("add_item", "item", "shish tawook sandwich", "no_match",
             None, None),
            ("add_item", "item", "chicken shawarma wrap", "matched",
             "cs_wrap", "Chicken Shawarma Wrap"),
        ])

    with tempfile.TemporaryDirectory() as td:
        tdp = Path(td)
        db_path = tdp / "cherry.db"
        # persist the synthetic history so the CLI can read it
        store.conn.commit()
        store.conn.execute("VACUUM INTO ?", (str(db_path),))

        docs = {"r": {"items": [{"id": "cs_wrap", "name":
                                 "Chicken Shawarma Wrap"}],
                      "options": [{"id": "o1", "name": "Onion"}]}}
        wl = am.build_worklist(store.conn, docs)
        ok(len(wl) == 1 and wl[0].restaurant_id == "r", "worklist scoped")
        ok(any(c.phrase == "shish tawook sandwich" for c in wl[0].corrections),
           "worklist carries the correction")
        ok("cebolla" in {p for p, _ in wl[0].seeds["o1"]},
           "worklist carries seed suggestions")

        # CLI report (json)
        import io
        import contextlib
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            rc = am.main(["--db", str(db_path)])
        ok(rc == 0, "cli exits clean")
        ok("shish tawook sandwich" in buf.getvalue(), "cli prints the correction")

        # patch file round-trip
        patch = tdp / "patch.yaml"
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            am.main(["--db", str(db_path), "--patch-out", str(patch)])
        body = patch.read_text()
        ok("cs_wrap" in body and "shish tawook sandwich" in body,
           "patch names the target and the phrase")
        parsed = yaml.safe_load(body)
        ok("menus" in parsed and "r" in parsed["menus"], "patch parses as yaml")


# ------------------------------------------------------------------- apply gate

MENU = {
    "schema_version": 1,
    "restaurant": {"id": "menu-x", "name": "Menu X", "cuisine": "burger",
                   "tax_rate_bps": 600, "pay_now_threshold_cents": 0,
                   "pay_now_basis": "subtotal", "pos_type": "manual",
                   "currency": "USD"},
    "options": [
        {"id": "x_onion", "name": "Onion"},
        {"id": "x_pickle", "name": "Pickles"},
    ],
    "items": [
        {"id": "x_burger", "name": "Hamburger", "price": 8.99},
        {"id": "x_cheese", "name": "Cheeseburger", "price": 9.49},
    ],
}


def write_menu(td: Path) -> Path:
    import menu_schema as ms
    doc = copy.deepcopy(MENU)
    problems = ms.validate_doc(doc)
    assert not problems, problems
    path = td / "menu-x.yaml"
    path.write_text(yaml.safe_dump(doc, sort_keys=False))
    return path


def test_apply():
    print("apply gate")
    with tempfile.TemporaryDirectory() as td:
        tdp = Path(td)
        menu = write_menu(tdp)

        patch = tdp / "p.yaml"
        patch.write_text(yaml.safe_dump({
            "menus": {"menu-x": {
                "items": {"x_cheese": ["double double"]},
                "options": {"x_onion": ["cebolla"]},
            }}}))
        added, refusals = am.apply_patch(patch, menu)
        ok(added == 2 and not refusals, "clean patch applies both aliases")
        doc = yaml.safe_load(menu.read_text())
        items = {i["id"]: i for i in doc["items"]}
        opts = {o["id"]: o for o in doc["options"]}
        ok(items["x_cheese"]["aliases"] == ["double double"],
           "item alias merged")
        ok(opts["x_onion"]["aliases"] == ["cebolla"], "option alias merged")

        # duplicate
        added, refusals = am.apply_patch(patch, menu)
        ok(added == 0 and len(refusals) == 2, "re-apply refuses duplicates")

        # collision with a different item's name
        patch2 = tdp / "p2.yaml"
        patch2.write_text(yaml.safe_dump({
            "menus": {"menu-x": {
                "items": {"x_burger": ["cheeseburger"]}}}}))
        added, refusals = am.apply_patch(patch2, menu)
        ok(added == 0 and any("cheeseburger" in r for r in refusals),
           "two dishes cannot share a phrase")

        # wrong restaurant in patch
        patch3 = tdp / "p3.yaml"
        patch3.write_text(yaml.safe_dump({"menus": {"other-r": {}}}))
        try:
            am.apply_patch(patch3, menu)
            ok(False, "wrong restaurant must fail")
        except SystemExit:
            ok(True, "wrong restaurant must fail")

        # merged menu still passes the real gate
        import menu_schema as ms
        from config_validator import lint_config
        cfg = ms.load_yaml(menu)
        ok(not [f for f in lint_config(cfg) if f.level == "ERROR"],
           "merged menu still lints clean")


# ------------------------------------------------------------- honest empties

def test_empty():
    print("honest empty")
    store = fixture()
    out = am.mine_corrections(store.conn)
    ok(out == [], "no history yields no corrections, not invented ones")
    reps = am.mine_repeats(store.conn)
    ok(reps == [], "no history yields no repeats")
    wl = am.build_worklist(store.conn, {})
    ok(wl == [] or all(w.empty for w in wl),
       "no menus and no history yields empty worklist")


if __name__ == "__main__":
    test_corrections()
    test_repeats()
    test_seeds()
    test_worklist_and_cli()
    test_apply()
    test_empty()
    print(f"\n{CHECKS} passed, 0 failed (alias mining)")
