"""
Square bridge — orders and pay links.

THE TWO FACTS THAT DETERMINE THIS ENTIRE DESIGN
-----------------------------------------------
1. **A Square order does not reach the kitchen until it is PAID.** Square's own
   docs are explicit: an order appears on the Dashboard, POS and KDS only if it
   has a fulfillment *and* it is paid. Creating an order is not enough.

2. **A payment link cannot be attached to an order you already created.**
   `CreatePaymentLink` has no `order_id` input — `PaymentLink.order_id` is
   read-only, and Square creates its own order from the `order` you inline in
   the request.

Put together, the obvious pipeline — create order, then create a pay link for
it — produces TWO orders and bills the wrong one. So:

    PAY NOW (over the restaurant's threshold)
        ONE call: CreatePaymentLink with the full order inlined. Text the
        returned url. The customer pays, the order becomes paid, and it lands
        on the KDS. The kitchen ticket and the payment are the same object.

    PAY AT PICKUP (under the threshold)
        CreateOrder puts the order in Square for the record — but it will NOT
        appear for the kitchen until someone takes payment. So the SMS ticket
        is still what gets the food cooked. This is not a workaround; it is the
        only correct behaviour given fact 1, and it is why ManualSink does not
        go away when a restaurant is "on Square".

That second case is worth being loud about with the owner: an unpaid Square
order is invisible to their line until they ring it up.

AD HOC VS CATALOG
-----------------
Line items and modifiers are sent ad hoc — `name` + `base_price_money`, no
`catalog_object_id`. Square explicitly supports this ("base_price_money is
required for ad hoc modifiers"), and it means a restaurant can go live without
mapping 126 menu items to Square catalog ids first.

What that costs the merchant, stated plainly because they should choose it
knowingly: ad-hoc items do not roll up into per-item sales reports, do not
decrement inventory, and do not pick up catalog-configured taxes. Every item
and option already carries a `pos_refs` dict for exactly this — fill in
`square_catalog_object_id` (the *variation* id, not the item id) and this
bridge starts sending catalog-linked lines with no other change. `pos_ref_gaps`
below reports how much of a menu is still unmapped.

TAX
---
Square computes totals itself; they are read-only on the request. With ad-hoc
lines there is no catalog tax to apply, so we send our own rate as an
order-level tax. Without it Square would total the order without tax and
disagree with what Lily read out loud.
"""

from __future__ import annotations

from vault import secret as vault_secret
import json
import os
import socket
import time
import urllib.error
import urllib.request
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Tuple

from payments import PayLink
from sinks import DeliveryResult, SinkContext

SQUARE_PROD = "https://connect.squareup.com"
SQUARE_SANDBOX = "https://connect.squareupsandbox.com"

# Pinned deliberately. Square changes behaviour between versions, and an
# unpinned integration breaks on their schedule rather than ours.
SQUARE_VERSION = "2026-08-19"

# Square publishes no retryable/permanent classification, so this branches on
# HTTP status, which is well defined. Every request carries an idempotency key,
# which is what makes a retry safe.
_RETRYABLE_STATUS = {408, 429, 500, 502, 503, 504}
_RETRYABLE_CODES = {"RATE_LIMITED", "INTERNAL_SERVER_ERROR", "SERVICE_UNAVAILABLE",
                    "GATEWAY_TIMEOUT", "BAD_GATEWAY", "REQUEST_TIMEOUT",
                    "TEMPORARY_ERROR"}
# Recoverable, but only by refreshing the merchant's OAuth token first.
_TOKEN_EXPIRED = {"ACCESS_TOKEN_EXPIRED"}


class SquareError(Exception):
    def __init__(self, detail: str, *, retryable: bool, code: str = "",
                 token_expired: bool = False) -> None:
        super().__init__(detail)
        self.detail = detail
        self.retryable = retryable
        self.code = code
        self.token_expired = token_expired


class SquareClient:
    """Thin HTTP client. One method per endpoint we actually use."""

    def __init__(self, access_token: Optional[str] = None,
                 location_id: Optional[str] = None, *,
                 sandbox: bool = False, timeout: float = 8.0,
                 opener=None) -> None:
        self.access_token = access_token or os.environ.get("SQUARE_ACCESS_TOKEN", "")
        self.location_id = location_id or os.environ.get("SQUARE_LOCATION_ID", "")
        self.base = SQUARE_SANDBOX if sandbox else SQUARE_PROD
        self.timeout = timeout
        self._opener = opener or urllib.request.urlopen
        if not self.access_token:
            raise ValueError("SquareClient needs an access token (OAuth, per "
                             "merchant — a personal access token only reaches "
                             "your own account)")
        if not self.location_id:
            raise ValueError("SquareClient needs a location_id; fetch it from "
                             "the Locations API rather than hand-configuring")

    def post(self, path: str, body: Dict[str, Any]) -> Dict[str, Any]:
        req = urllib.request.Request(
            f"{self.base}{path}", data=json.dumps(body).encode(),
            headers={"Authorization": f"Bearer {self.access_token}",
                     "Square-Version": SQUARE_VERSION,
                     "Content-Type": "application/json"},
            method="POST")
        try:
            with self._opener(req, timeout=self.timeout) as resp:
                return json.loads(resp.read() or b"{}")
        except urllib.error.HTTPError as exc:
            raw = exc.read() if hasattr(exc, "read") else b""
            codes, detail = _parse_errors(raw)
            raise SquareError(
                f"square {exc.code}: {detail}",
                retryable=(exc.code in _RETRYABLE_STATUS
                           or any(c in _RETRYABLE_CODES for c in codes)),
                code=codes[0] if codes else str(exc.code),
                token_expired=any(c in _TOKEN_EXPIRED for c in codes)) from exc
        except urllib.error.URLError as exc:
            raise SquareError(f"square unreachable: {exc.reason}",
                              retryable=True, code="transport") from exc
        except (TimeoutError, socket.timeout) as exc:
            # socket.timeout is not a TimeoutError before Python 3.10.
            raise SquareError("square timed out", retryable=True,
                              code="timeout") from exc
        except OSError as exc:                       # reset, broken pipe
            raise SquareError(f"square connection failed: {exc}",
                              retryable=True, code="transport") from exc

    def create_payment_link(self, order: Dict[str, Any], idempotency_key: str,
                            *, buyer_phone: Optional[str] = None,
                            note: str = "") -> Dict[str, Any]:
        body: Dict[str, Any] = {"idempotency_key": idempotency_key,
                                "order": order}
        if note:
            body["payment_note"] = note[:500]
        if buyer_phone:
            # maxLength 17 on this field, shorter than everywhere else Square
            # takes a phone number.
            body["pre_populated_data"] = {"buyer_phone_number": buyer_phone[:17]}
        doc = self.post("/v2/online-checkout/payment-links", body)
        return doc.get("payment_link") or {}

    def create_order(self, order: Dict[str, Any],
                     idempotency_key: str) -> Dict[str, Any]:
        doc = self.post("/v2/orders", {"idempotency_key": idempotency_key,
                                       "order": order})
        return doc.get("order") or {}

    def retrieve_order(self, order_id: str) -> Dict[str, Any]:
        if not order_id:
            raise ValueError("Square order id is required")
        from urllib.parse import quote
        req = urllib.request.Request(
            f"{self.base}/v2/orders/{quote(order_id, safe='')}",
            headers={"Authorization": f"Bearer {self.access_token}",
                     "Square-Version": SQUARE_VERSION,
                     "Content-Type": "application/json"})
        try:
            with self._opener(req, timeout=self.timeout) as resp:
                return (json.loads(resp.read() or b"{}").get("order") or {})
        except (urllib.error.URLError, TimeoutError, socket.timeout,
                OSError) as exc:
            raise SquareError(f"Square order verification failed: {exc}",
                              retryable=True, code="transport") from exc

    def delete_payment_link(self, payment_link_id: str) -> None:
        if not payment_link_id:
            raise ValueError("Square payment-link id is required")
        req = urllib.request.Request(
            f"{self.base}/v2/online-checkout/payment-links/{payment_link_id}",
            headers={"Authorization": f"Bearer {self.access_token}",
                     "Square-Version": SQUARE_VERSION,
                     "Content-Type": "application/json"}, method="DELETE")
        try:
            with self._opener(req, timeout=self.timeout):
                return
        except urllib.error.HTTPError as exc:
            raw = exc.read() if hasattr(exc, "read") else b""
            codes, detail = _parse_errors(raw)
            raise SquareError(
                f"square {exc.code}: {detail}",
                retryable=(exc.code in _RETRYABLE_STATUS
                           or any(c in _RETRYABLE_CODES for c in codes)),
                code=codes[0] if codes else str(exc.code),
                token_expired=any(c in _TOKEN_EXPIRED for c in codes)) from exc
        except (urllib.error.URLError, TimeoutError, socket.timeout,
                OSError) as exc:
            raise SquareError(f"square payment-link revocation failed: {exc}",
                              retryable=True, code="transport") from exc


def _parse_errors(raw: bytes) -> Tuple[List[str], str]:
    try:
        doc = json.loads(raw or b"{}")
    except ValueError:
        return [], (raw[:200].decode("utf-8", "replace") if raw else "no body")
    errs = doc.get("errors") or []
    codes = [str(e.get("code")) for e in errs if e.get("code")]
    bits = []
    for e in errs:
        field = e.get("field")
        bits.append(f"{e.get('code')}{f' at {field}' if field else ''}: "
                    f"{e.get('detail') or ''}".strip())
    return codes, "; ".join(bits) or "no detail"


# ---------------------------------------------------------------------------
# Snapshot -> Square order
# ---------------------------------------------------------------------------

def _pickup_note(snapshot: Dict[str, Any]) -> str:
    """'Taken by phone', plus any allergy the caller gave (Square keeps 500)."""
    import host_voice
    extra = host_voice.staff_line(snapshot.get("allergy"))
    return f"Taken by phone. {extra}"[:490] if extra else "Taken by phone"


def build_square_order(snapshot: Dict[str, Any], location_id: str, *,
                       reference_id: str = "", ticket_name: str = "",
                       customer_name: str = "", customer_phone: str = "",
                       prep_minutes: int = 20,
                       tax_rate_bps: int = 0) -> Dict[str, Any]:
    """Translate our normalized order into Square's shape.

    Every decision here is load-bearing; the comments say which fact forces it.
    """
    line_items: List[Dict[str, Any]] = []

    for idx, line in enumerate(snapshot.get("lines", [])):
        name = line["item_name"]
        if line.get("size_name"):
            name = f"{name} ({line['size_name']})"

        # Square adds every modifier's price ON TOP of the line's base price,
        # while our snapshot's unit_price_cents already includes them. Send
        # the base price and the exact per-selection charges instead, so
        # Square's total is ours (a mismatch revokes the link and the caller
        # is bounced to staff). Snapshots stored before charge_cents existed
        # fall back to the option list price.
        live_mods = [m for m in line.get("modifiers", [])
                     if not m.get("informational")]
        exact = all("charge_cents" in m for m in live_mods)
        modifiers: List[Dict[str, Any]] = []
        mod_sum = 0
        for m in live_mods:
            qty_m = max(1, int(m.get("quantity", 1) or 1))
            if exact:
                amount = int(m.get("charge_cents") or 0)
            else:
                amount = int(m.get("price_cents") or 0) * qty_m
            mod_sum += amount
            label = m["option_name"]
            if qty_m > 1:
                label = f"{qty_m}x {label}"
            mod: Dict[str, Any] = {
                "uid": f"m{idx}-{len(modifiers)}",
                "name": label,
                # Required for ad-hoc modifiers, even at zero. The whole
                # selection is one modifier at its total charge, so Square's
                # quantity is never used (no per-unit rounding to disagree).
                "base_price_money": {"amount": amount, "currency": "USD"},
            }
            if m.get("placement", "whole") != "whole":
                mod["name"] = f"{label} ({m['placement']})"
            cat = (m.get("pos_refs") or {}).get("square_catalog_object_id")
            if cat:
                mod["catalog_object_id"] = cat
            modifiers.append(mod)
        if "unit_base_cents" in line:
            unit_base = int(line["unit_base_cents"])
        else:
            unit_base = int(line["unit_price_cents"]) - mod_sum

        # A removal is its own zero-price modifier, NOT a note. Square has no
        # concept of a negative or exclusion modifier, and modifiers render as
        # their own structured line on the ticket where a note is one free-text
        # blob a cook can skim past. A missed "no onion" is an allergy
        # incident, so it gets its own line, in capitals.
        for removed in line.get("removed_defaults", []):
            modifiers.append({
                "uid": f"m{idx}-no-{len(modifiers)}",
                "name": f"NO {str(removed).upper()}",
                "base_price_money": {"amount": 0, "currency": "USD"},
            })

        item: Dict[str, Any] = {
            "uid": f"li{idx}",
            "name": name,
            "quantity": str(int(line["quantity"])),         # a string in Square
            "base_price_money": {"amount": unit_base, "currency": "USD"},
        }
        if modifiers:
            item["modifiers"] = modifiers
        if line.get("note"):
            item["note"] = str(line["note"])[:2000]
        cat = (line.get("pos_refs") or {}).get("square_catalog_object_id")
        if cat:
            item["catalog_object_id"] = cat
        line_items.append(item)

    order: Dict[str, Any] = {
        "location_id": location_id,
        "line_items": line_items,
        "state": "OPEN",        # DRAFT can never be paid or fulfilled
        "source": {"name": "Cherry"},
        "fulfillments": [{
            "uid": "f1",
            "type": "PICKUP",
            "state": "PROPOSED",
            "pickup_details": {
                # ASAP, not the SCHEDULED default. A scheduled order stays off
                # the KDS until pickup-time-minus-prep, which presents exactly
                # as "we sent the order and nothing printed".
                "schedule_type": "ASAP",
                "prep_time_duration": f"PT{int(prep_minutes)}M",
                "recipient": {
                    "display_name": customer_name or "Phone order",
                    **({"phone_number": customer_phone[:18]}
                       if customer_phone else {}),
                },
                "note": _pickup_note(snapshot),
            },
        }],
    }
    if reference_id:
        order["reference_id"] = reference_id[:40]
    if ticket_name:
        order["ticket_name"] = ticket_name[:255]

    # Ad-hoc lines carry no catalog tax, so Square would otherwise total the
    # order without tax and disagree with the total Lily read out loud.
    if tax_rate_bps:
        order["taxes"] = [{
            "uid": "tax1",
            "name": "Sales Tax",
            "percentage": f"{tax_rate_bps / 100:.3f}".rstrip("0").rstrip("."),
            "scope": "ORDER",
        }]
    return order


def pos_ref_gaps(config) -> Dict[str, List[str]]:
    """What still has no Square catalog id.

    Ad-hoc ordering works without any of this, so it is not a launch blocker —
    but the merchant loses per-item reporting and inventory until it is filled
    in, and they should be told the number rather than discover it at
    month end.
    """
    key = "square_catalog_object_id"
    return {
        "items": [i.id for i in config.items
                  if not (i.pos_refs or {}).get(key)],
        "options": [o.id for o in config.options
                    if not (getattr(o, "pos_refs", {}) or {}).get(key)],
    }


# ---------------------------------------------------------------------------
# Hosted checkout and the sink
# ---------------------------------------------------------------------------


class SquareCheckoutProvider:
    """Create one itemized Square order and its hosted checkout page.

    Payment makes this same order visible to Square POS/KDS.  The webhook must
    therefore record the handoff, not create another Square order.
    """

    name = "square"

    def __init__(self, client: SquareClient, *, checkout_minutes: int = 30):
        self.client = client
        self.checkout_minutes = checkout_minutes

    def create_pay_link(self, order_id: str, amount_cents: int,
                        pos_order_ref: Optional[str] = None, *, snapshot: dict,
                        context: Dict[str, Any]) -> PayLink:
        if int(snapshot.get("total_cents") or -1) != int(amount_cents):
            raise ValueError("checkout amount does not match immutable order")
        order = build_square_order(
            snapshot, self.client.location_id,
            reference_id=context.get("short_code", ""),
            ticket_name=f"{context.get('short_code', '')} phone".strip(),
            customer_name=context.get("customer_name", "") or
                          context.get("customer_phone", "") or "Phone order",
            customer_phone=context.get("customer_phone", ""),
            tax_rate_bps=int(context.get("tax_rate_bps") or 0))
        # The idempotency key is stable per order, so repeating the request
        # after a 5xx / 429 / timeout cannot create a second checkout. One
        # retry turns a blip into a working call instead of a transfer.
        link = self._retry(lambda: self.client.create_payment_link(
            order, f"cherry-pay-{order_id}"[:192],
            buyer_phone=context.get("customer_phone") or None,
            note=f"Phone order {context.get('short_code', '')}".strip()))
        url = str(link.get("url") or "")
        order_ref = str(link.get("order_id") or "")
        link_ref = str(link.get("id") or "")
        if not url or not order_ref or not link_ref:
            raise ValueError("Square returned an incomplete payment link")
        # Square computes its own tax and rounding. A link with a different
        # payable total must never reach the guest, even though the submitted
        # line items came from Cherry's immutable snapshot.
        try:
            verified = self._retry(lambda: self.client.retrieve_order(order_ref))
            total = verified.get("total_money") or {}
            if (verified.get("id") != order_ref or
                    total.get("amount") != amount_cents or
                    total.get("currency") != "USD"):
                self.client.delete_payment_link(link_ref)
                raise ValueError("Square checkout total differs from the "
                                 "quoted Cherry order; link revoked")
        except Exception:
            # Retrieval failures may leave an untexted checkout in Square.
            # Its stable idempotency key prevents creating a second one on
            # retry; never text it until verification succeeds.
            raise
        expires = (datetime.now(timezone.utc) +
                   timedelta(minutes=self.checkout_minutes)).isoformat(
                       timespec="seconds")
        return PayLink(url=url, expires_at=expires, pos_ref=order_ref,
                       provider_link_ref=link_ref)

    @staticmethod
    def _retry(call, attempts: int = 2, pause: float = 0.4):
        for attempt in range(attempts):
            try:
                return call()
            except SquareError as exc:
                if not exc.retryable or attempt == attempts - 1:
                    raise
                time.sleep(pause)

    def revoke_pay_link(self, provider_link_ref: str) -> None:
        self.client.delete_payment_link(provider_link_ref)


class SquareSink:
    """Push an order into Square.

    Which call is made depends on how the order is being paid, because Square
    ties the kitchen ticket to payment:

      pay_now        one CreatePaymentLink with the order inlined. The link is
                     returned on the DeliveryResult for the SMS relay to send.
      pay_at_pickup  CreateOrder for the record. The order will NOT appear for
                     the kitchen until it is paid, so the caller must also run
                     ManualSink — see `needs_manual_ticket`.
    """

    name = "square"

    def __init__(self, client: SquareClient, *, prep_minutes: int = 20,
                 tax_rate_bps: int = 0) -> None:
        self.client = client
        self.prep_minutes = prep_minutes
        self.tax_rate_bps = tax_rate_bps
        self.last_pay_url: Optional[str] = None

    @staticmethod
    def needs_manual_ticket(snapshot: Dict[str, Any]) -> bool:
        """True when Square alone will not show this order to the kitchen."""
        return snapshot.get("payment_mode") != "pay_now"

    def send(self, order_id: str, snapshot: Dict[str, Any],
             ctx: SinkContext) -> DeliveryResult:
        order = build_square_order(
            snapshot, self.client.location_id,
            reference_id=ctx.short_code,
            ticket_name=f"{ctx.short_code} phone",
            customer_name=ctx.customer_phone or "Phone order",
            customer_phone=ctx.customer_phone or "",
            prep_minutes=self.prep_minutes,
            tax_rate_bps=self.tax_rate_bps)

        # Keyed to our order id, so a retry is the same request and Square
        # de-duplicates it rather than creating a second ticket.
        pay_now = snapshot.get("payment_mode") == "pay_now"
        key = f"cherry-{'pay' if pay_now else 'ord'}-{order_id}"[:192]

        try:
            if pay_now:
                link = self.client.create_payment_link(
                    order, key, buyer_phone=ctx.customer_phone or None,
                    note=f"Phone order {ctx.short_code}")
                self.last_pay_url = link.get("url")
                ref = link.get("order_id") or link.get("id")
                if not self.last_pay_url:
                    return DeliveryResult.rejected(
                        "Square returned a payment link with no url")
            else:
                created = self.client.create_order(order, key)
                ref = created.get("id")
            if not ref:
                return DeliveryResult.rejected("Square returned no order id")
        except SquareError as exc:
            if exc.token_expired:
                # Recoverable, but only by a human or a refresh job — not by
                # repeating the same call with the same dead token.
                return DeliveryResult(False, error_kind="auth",
                                      error_detail=f"{exc.detail} — refresh "
                                                   f"the merchant's OAuth token",
                                      retryable=False)
            return DeliveryResult(
                False,
                error_kind="connection" if exc.retryable else "rejected",
                error_detail=f"{exc.detail} (code {exc.code})",
                retryable=exc.retryable)
        return DeliveryResult.sent(str(ref))


def square_sandbox_enabled() -> bool:
    """CHERRY_SQUARE_SANDBOX=1: every Square call goes to Square's sandbox."""
    return os.environ.get("CHERRY_SQUARE_SANDBOX") == "1"


def _merchant_credentials(restaurant_id: str, sandbox: bool):
    """This restaurant's own token and location, from the secret store.

    The process-wide SQUARE_ACCESS_TOKEN / SQUARE_LOCATION_ID pair belongs to
    ONE merchant. Using it for a restaurant that has no authorization of its
    own would send that restaurant's customers' money to the wrong account,
    so it is only a fallback for the sandbox (and for an explicit
    CHERRY_ALLOW_GLOBAL_SQUARE_TOKEN=1 single-merchant deployment).
    """
    rid = restaurant_id.upper().replace("-", "_")
    token = vault_secret(f"SQUARE_TOKEN_{rid}")
    loc = vault_secret(f"SQUARE_LOCATION_{rid}")
    if (sandbox or os.environ.get("CHERRY_ALLOW_GLOBAL_SQUARE_TOKEN") == "1"):
        token = token or os.environ.get("SQUARE_ACCESS_TOKEN", "")
        loc = loc or os.environ.get("SQUARE_LOCATION_ID", "")
    return token, loc


def square_sink_for(restaurant_row, *, opener=None,
                    sandbox: Optional[bool] = None) -> SquareSink:
    """Build a sink from a restaurant row. Credentials come from the
    environment; per-merchant OAuth tokens belong in a secret store, never in
    the menu YAML."""
    if sandbox is None:
        sandbox = square_sandbox_enabled()
    token, loc = _merchant_credentials(restaurant_row["id"], sandbox)
    if not token or not loc:
        raise ValueError(f"Square is not authorized for {restaurant_row['id']}")
    client = SquareClient(token, loc, sandbox=sandbox, opener=opener)
    return SquareSink(client,
                      tax_rate_bps=int(restaurant_row["tax_rate_bps"] or 0))


def square_checkout_provider_for(restaurant_row, *, opener=None,
                                 sandbox: Optional[bool] = None,
                                 checkout_minutes: int = 30
                                 ) -> SquareCheckoutProvider:
    """Build the itemized checkout provider from deployment secrets."""
    if sandbox is None:
        sandbox = square_sandbox_enabled()
    token, loc = _merchant_credentials(restaurant_row["id"], sandbox)
    # SquareClient itself falls back to the process-wide SQUARE_ACCESS_TOKEN
    # when given none, which would undo the merchant scoping above.
    if not token or not loc:
        raise ValueError(f"Square is not authorized for {restaurant_row['id']}")
    client = SquareClient(token, loc, sandbox=sandbox, opener=opener)
    return SquareCheckoutProvider(client, checkout_minutes=checkout_minutes)
