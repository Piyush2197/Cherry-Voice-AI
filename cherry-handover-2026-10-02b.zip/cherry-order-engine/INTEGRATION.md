# Cherry — integration handoff

For the developers wiring Telnyx and Inworld to the order engine. The current
forwarded-number, checkout-handoff-only launch sequence is in
`DEVELOPER_HANDOFF.md`; older paid-webhook release steps below describe an
optional mode.

The repository has automated checks; run every suite before production.
Nothing below is a plan; it is the contract for code that already runs.

---

## 0. Two things that will surprise you

**Square will not show an unpaid order to the kitchen.** Square's docs are
explicit: an order appears on the Dashboard, POS and KDS only if it has a
fulfillment *and* it is paid. And `CreatePaymentLink` cannot attach to an order
you already created — it builds its own, so the obvious "create order, then get
a link" pipeline produces two orders and bills the wrong one.

All seven pilot menus now require review-and-pay checkout at every amount:

| | What it does | Kitchen sees it |
|---|---|---|
| Pilot order | **One** `CreatePaymentLink` with the immutable itemized order inlined. Text customer the link | When the customer pays, Square releases that same order to POS/KDS |
| A separately configured future pay-at-pickup location | `CreateOrder` for the record | Not until staff rings it up; a manual ticket remains necessary |

For pilots, `server.finish` arranges checkout before any kitchen delivery.
`square_webhook.handle` validates the signed, matching-amount paid event and
records the same Square POS order; it must not create a second order. A
manual-only location holds its order and is not live-ready.

**A Telnyx 200 means queued, not delivered**, and the two failures that matter
most — `40010` (number not on a 10DLC campaign) and `40300` (recipient sent
STOP) — arrive on the *webhook*, not in the send response. A retry classifier
reading only the response cannot see either. That is why
`telnyx_sms.handle_webhook()` and the `sms_suppression` table exist: an opt-out
can only be honoured by remembering it and checking before the next send.

---

## 1. The one thing to understand first

**Inworld decides what the caller MEANT. Cherry decides everything about the ORDER.**

| Inworld's job | Cherry's job |
|---|---|
| Hear the audio | Match the words to a menu item |
| Classify intent ("they're adding something") | Decide if it's ambiguous, and refuse to guess |
| Pass the caller's words through verbatim | Price it, in integer cents |
| **Say the `say` string it gets back** | Decide what still has to be asked |
| | Decide whether the order may be placed |

The voice model never invents a price, never picks between two items, and never
decides an order is done.

**The single most important rule: speak the `say` field verbatim.** Every tool
returns a `say` string. It carries prices, clarifying questions and sold-out
notices that have to be exact. If the model paraphrases it — "that'll be about
thirteen dollars" — that is a bug in the prompt, not a style choice. Put this in
the system prompt and test it.

---

## 2. What to give the developers

| File | Who needs it | What it is |
|---|---|---|
| `agent_api.py` | Inworld dev | **The only file they call.** `CallSession` + the tool surface |
| `tools.json` | Inworld dev | The 19 tool definitions in generic JSON; map them to the active Inworld product's function-calling configuration |
| `test_agent_api.py` | Inworld dev | 195 checks showing every tool's behaviour, including failures |
| `voice/inworld_bridge.py` | Voice dev | Credential-free HTTP relay, verbatim audit, and one-shot human-handoff hook |
| `test_voice.py`, `test_voice_http.py` | Voice dev | Simulated and real-socket coverage for both pilot locations |
| `order_store.py`, `db/schema.sql` | Backend dev | The database and repository |
| `production_db.py` | Backend dev | Postgres bootstrap/verification plus guarded backup and restore-drill commands |
| `sinks.py` | Backend dev | Where a finished order goes: the `OrderSink` protocol + `ManualSink` |
| `telnyx_sms.py` | Backend dev | **Built.** Real sender, error-code table, webhook handler, opt-out suppression |
| `square_bridge.py` | Backend dev | **Built.** Order + pay-link bridge, ad-hoc line items, `pos_ref_gaps` |
| `test_bridges.py` | Backend dev | 140 tests asserting the exact bytes sent to both APIs |
| `cherry_ops.py` | Backend dev | `deploy` `call` `orders` `ack` `86` `trace` `evidence` — the reference call flow |
| `evidence_report.py` | Support/backend dev | Builds one redacted complaint packet from the immutable order, transcript, delivery acknowledgement, payment and audit history |
| `payments.py` | Backend dev | The POS pay-link relay. **Do not modify without reading the guard** |
| `ops_monitor.py` | Backend dev | Identity-free fleet metrics plus stable alert rules; wire alerts to the chosen on-call provider |
| `ops_console.py`, `production_jobs.py` | Backend dev | Operator UI, exactly-once alert delivery, transcript review and reconciliation jobs |
| `access_control.py`, `restaurant_controls.py` | Backend dev | Tenant roles, restaurant scopes, hours, holidays, wait/prep, languages and AI disablement |
| `catalog_nightly.py`, `release_guard.py` | Backend dev | Fail-closed nightly menu sync, load/SLO gate and audited menu rollback |
| `square_oauth.py`, `square_webhook.py` | Backend dev | Scheduled token renewal seam and authenticated/idempotent payment status webhook |
| `TEN_RESTAURANT_READINESS.md` | Both | Honest product/platform gaps and the ten-location production checklist |
| `ONBOARDING.md` | Both | How a restaurant gets modelled and what the engine guarantees |
| `menus/*.yaml` | Both | 17 restaurant menu files including the pilots |
| `calls/*.txt` | QA | Nine scripted calls with pinned totals |

**Tell them not to touch:** `order_engine.py`, `config_validator.py`,
`cuisine_library.py`, `menu_ingest.py`, `menu_schema.py`. Those are covered by
432 conformance invariants and verified by mutation testing. If the engine needs
to change, the invariant that should have caught the problem needs to change
first.

---

## 3. The tool surface

Eleven tools. Every one returns the same envelope:

```json
{
  "ok": true,
  "say": "Got it — Lamb Saag. How spicy would you like that? We do mild, mild plus, medium, medium plus, hot, or extra hot.",
  "action": "add_item",
  "needs": {
    "question": "How spicy would you like that? ...",
    "line_id": "a1b2c3d4",
    "group_id": "pg_spice",
    "code": "missing_required_group",
    "candidates": ["pg_mild", "pg_medium", "..."]
  },
  "order": {
    "lines": [{"line_id": "a1b2c3d4", "item_id": "pg_lamb_saag",
               "name": "Lamb or Goat Saag", "quantity": 1,
               "description": "Lamb or Goat Saag", "line_total_cents": 1699}],
    "subtotal_cents": 1699, "tax_cents": 102, "total_cents": 1801,
    "payment_mode": "pay_at_pickup", "submittable": false
  },
  "error": null
}
```

| Field | What it means to the voice layer |
|---|---|
| `say` | **Speak this, verbatim.** Never empty, even on failure |
| `ok` | `false` means the action did not happen. `say` explains it to the caller |
| `needs` | Non-null: the engine is waiting for an answer. Route the caller's next words to `answer` |
| `order.submittable` | `false`: the order **cannot** be placed. Not advisory |
| `error` | A machine code for logs: `no_match`, `ambiguous`, `item_unavailable`, `qty_exceeded`, `incomplete`, … |

### The tools

| Tool | When Inworld calls it |
|---|---|
| `add_item(text, quantity?, note?)` | Caller names something they want |
| `answer(text)` | The previous turn ended with a question from the engine |
| `add_modifier(text, line_id?, quantity?, placement?)` | Caller adds a topping, side or upgrade |
| `remove_modifier(text, line_id?)` | "no onion", "hold the mayo" |
| `set_quantity(quantity, line_id?)` | "make it three" |
| `split_line(line_id?, take?)` | **Before** a modifier that applies to only some units |
| `remove_item(line_id?)` | "take that off" |
| `search_menu(text?)` | "what do you have?" |
| `read_back()` | Caller asks what they have; also before ending |
| `ready_to_place()` | Before hanging up. If `ok` is false, **do not end the call** |

### Routing rule, which is where integrations usually go wrong

```
if session.pending() is not None:   →  answer(text)
else:                               →  add_item(text)
```

An earlier version of the harness got this backwards and **nothing could be
ordered at all**: an empty cart produces a question ("what can I get you?"), so
every utterance routed into the answer path. `CallSession.pending()` already
excludes that case — use it, don't reimplement the check.

### Two behaviours to build the prompt around

**Ambiguity is a question, not a guess.** `add_item("pizza")` on a pizzeria
returns `ok: false`, `error: "ambiguous"`, and `say: "Did you want the Cheese
Pizza or the Margherita or the Three Topping Special?"` The model must ask, not
pick. Same for a bare "saag" where the restaurant sells chicken, lamb and
paneer versions at different prices — guessing chicken there is a $3 error on
every order.

**Modifiers are per-unit.** `add_modifier("guacamole")` on a line of three tacos
charges guacamole three times, which is correct. When the caller wants it on one
of them, call `split_line()` **first**. This will not happen on its own, and it
is the most likely thing to be missed.

---

## 4. The call flow

`cherry_ops.py cmd_call` is the working reference. In order:

```python
rest       = store.restaurant_for_number(telnyx_to_number)   # dialled number → restaurant
cfg, mv    = store.load_live_config(rest["id"])              # live menu + tonight's 86s
session_id = store.start_session(rest["id"], mv,
                                 external_id=telnyx_call_id, # ← idempotency
                                 caller_phone=telnyx_from)
call       = CallSession(cfg)                                # hold this for the whole call

store.record_turn(session_id, "agent", call.greeting()["say"])
# ... tools, one per caller turn, recording both sides ...

final = call.ready_to_place()
if not final["ok"]:
    store.escalate(session_id, final["error"])               # a human takes it
else:
    oid, code = store.place_order(rest["id"], mv, call.snapshot(),
                                  session_id=session_id,
                                  customer_phone=telnyx_from)
    arrange_payment(store, oid, sms=sms, provider=pos)       # itemized checkout
    # No kitchen handoff until the signed, matching-amount paid webhook.
    # For Square the checkout already owns the POS order; record its reference.
store.end_session(session_id, "completed")
```

**Pass the Telnyx call id as `external_id`.** Telnyx retries webhooks. Without
it you get duplicate sessions; and `place_order` is idempotent per session, so
with it a retry cannot double-submit an order to the kitchen. That bug was found
by `test_ops.py` — the kitchen would have cooked the order twice.

**Hold one `CallSession` per active call** for the life of the call. Rebuilding
it per turn loses the cart.

---

## 5. What each side owns, and what's left

### Waiting on Inworld (your blocker)
- **SIP endpoint.** Nothing from our side is needed for it. When it lands,
  Telnyx points at it. For the forwarding-only call lifecycle and HTTP tool
  contract, see `VOICE_FORWARDING.md` and `voice_gateway.py`.

### The voice team owns
| Task | Notes |
|---|---|
| Wire the 19 ordering, reservation, allergen/diet, allergy-note and host tools from `tools.json` | The schemas and behaviour are settled and tested |
| System prompt: speak `say` verbatim | Include the ambiguity and `split_line` rules above |
| Route `pending()` → `answer`, else `add_item` | See section 3 |
| Load the ASR keyterm list per restaurant | `./cherry.py keyterms <restaurant>` — ranked, capped at 100 terms / 500 tokens |
| Barge-in and end-of-turn handling | Ours ends at the `say` string |

### The backend team owns
| Task | Notes |
|---|---|
| Set `TELNYX_API_KEY` and `TELNYX_FROM_NUMBER` | The sender is written and tested; it needs credentials, not code |
| **Confirm the 10DLC campaign is `MNO_PROVISIONED`, not just bought** | Buying a number is not the same as an approved brand + campaign with that number *assigned* to it. Check `GET /v2/10dlc/phone_number_campaigns/{number}` shows `assignmentStatus: ASSIGNED`, and the campaign's `campaignStatus` is `MNO_PROVISIONED` or `MNO_ACCEPTED`. A number that is bought but unassigned sends fine to your own phone and gets silently filtered by AT&T and T-Mobile |
| **The SMS webhook endpoint** | Point Telnyx at `/v1/webhooks/telnyx/sms` and set `TELNYX_PUBLIC_KEY`. Cherry verifies the Ed25519 signature, rejects stale requests and ignores duplicate event ids before applying delivery status or STOP. |
| Provision Postgres | The connector, bounded pool and idempotent bootstrap are built. Create the managed instance, set `CHERRY_DATABASE_URL`, enable point-in-time recovery and execute the restore drill in `DATABASE.md`. |
| The webhook endpoints | Configure signed Telnyx SMS delivery at `/v1/webhooks/telnyx/sms` and signed Square payment status at `/v1/webhooks/square/payment` |
| Square OAuth, per merchant | Complete merchant authorization, put tokens in the secret manager, connect its adapter to `square_oauth.py`, and schedule the built renewal job every seven days or less |
| Per-restaurant env: `SQUARE_TOKEN_<ID>`, `SQUARE_LOCATION_<ID>` | Fetch `location_id` from the Locations API rather than hand-configuring it |
| Operations presentation and paging | `/ops`, tenant-scoped metrics, review queues and exactly-once alert webhooks are built; configure the on-call URL and scheduler |
| Call-recording policy | Cherry stores the transcript but not audio. Decide consent language, retention and access; if approved, keep only the provider recording reference in Cherry rather than copying audio into the order database. |

### Optional product scope and external activation
| Item | State |
|---|---|
| `ToastSink` | Built with Toast price verification and idempotent Orders v2 submission. Activation needs the restaurant/dining/group/item GUIDs and access token; a combo maps to its separate Toast item GUID. |
| Square catalog mapping | The bridge sends **ad-hoc** line items, so no mapping is needed to go live. The merchant loses per-item sales reporting and inventory until it is done. `square_bridge.pos_ref_gaps(config)` reports what is unmapped; fill `pos_refs["square_catalog_object_id"]` (the *variation* id, not the item id) and the same bridge starts sending catalog-linked lines with no other change |
| QR ordering channel | Decision pending — page on the restaurant's site vs SMS thread. `channel='web'` already exists in the schema, so it changes only the front end |
| Accuracy dashboard presentation | The private, identity-free `/v1/ops/snapshot` feed and alert rules are built. Render the dashboard only after real pilot calls exist; never ship invented sample performance. |
| Juan Miguel's menu | **Blocked on the owner.** Their site exposes 17 of ~100 items. Cannot be onboarded from the web — someone has to get the printed menu |
| Two menu shapes the engine can't express | Per-topping nested options (Juan Miguel's Botana) and a modifier group whose options are other menu items (Sam's "choice of any sandwich"). Neither affects the three pilots |

The application-side pilot scope is frozen here. New catalog automation,
dashboards and broader restaurant features start only after live pilot evidence
shows they are needed; they are not prerequisites for the first deployment.

---

## 6. Before the first test call

Run these in order. Each is a real gate, not a formality.

1. `python3 test_conformance.py && python3 test_agent_api.py` — 604 of the 722
   tests, and the two that matter most for a live call.
2. `./cherry.py check menus/bun-n-run-ferndale.yaml` — must print **READY**.
3. `./cherry.py deploy menus/bun-n-run-ferndale.yaml --db cherry.db --sink manual --staff-phone <owner's mobile> --inbound <Telnyx number>`
4. `./cherry.py call --inbound <Telnyx number> --db cherry.db --script calls/bun-n-run.txt`
   — should create an itemized checkout, hold the kitchen ticket until
   payment and total **$13.77**.
5. Sit with the owner and run `./cherry.py play bun-n-run-ferndale` by hand.
   They will catch two things no test can: prices that drifted since the printed
   menu, and combinations they refuse to make.
6. Then the live call — and `./cherry.py trace <code>` afterwards to see every
   turn, the ticket, the delivery and the payment in one place.

## 7. Three decisions still on the owner, not the developers

These are money differences, one config line each, and they should be confirmed
per restaurant rather than assumed:

1. **Free-allowance policy.** When a group gives "first 2 free", the engine
   spends the allowance on the most expensive picks (customer-favourable). Most
   POS systems do the opposite. `free_policy`.
2. **Half-topping price.** Set to 50% of a whole topping. Plenty of pizzerias
   charge full. `half_placement_multiplier`.
3. **Pilot payment policy.** All seven pilot menus set the pay-now threshold
   to zero: every amount requires customer review/payment before handoff.
   Other menus can retain a distinct owner-approved pay-at-pickup policy.
