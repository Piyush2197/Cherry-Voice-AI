# Onboarding your first customer — what runs today, what does not

Written 2026-09-30, after driving a complete call through the real voice
contract on a real pilot menu. Every claim below was executed, not read.

## The short answer

**The engine runs. The phone does not.** Cherry has a brain — a deterministic
order engine, a menu data model and a wall of invariants. It has no ears and no
mouth. That is the whole gap between "works on my laptop" and "answers a
customer's phone".

`voice_gateway.py` says it itself, in its own docstring:

> The SIP/media worker owns speech recognition, LLM tool selection, and TTS.
> This service does not pretend to terminate SIP or RTP.

## What was proven to work today

Pink Garlic Oak Park — the real pilot restaurant, 128 items, Square merchant —
driven through `voice_gateway.py`, the same HTTP contract Inworld's worker will
call:

```
GET  /v1/voice/tools                    -> 19 tool schemas + system prompt
POST /v1/voice/calls                    -> "Thanks for calling Pink Garlic
                                            Indian Cuisine (Oak Park), what can
                                            I get you?"
POST .../tools/add_item  "butter chicken" -> "Got it — Butter Chicken (Creamy).
                                            How spicy would you like that?
                                            We do mild, mild plus, medium, ..."
POST .../tools/answer    "medium please"  -> "Medium, got it."
POST .../tools/add_item  "garlic naan"    -> "Got it — Garlic Naan."
POST .../tools/read_back                  -> "...Your total comes to $19.59."
POST .../finish                           -> texts the itemized checkout link
```

Then, exactly where Square's signed webhook lands in production:

```
payment: paid   amount: 1959   short_code: 4117
release: released=true  sink=manual
events: order.placed -> payment.link_sent -> payment.paid
        -> order.released_after_payment
```

Two messages came out, both real:

> **to the customer:** Pink Garlic Indian Cuisine (Oak Park): your order #4117
> is $19.59. Review your order and pay on the restaurant's secure page: … Wrong
> item? Do not pay; call +12488086495 for a correction.

> **to the restaurant:**
> `#4117  Pink Garlic Indian Cuisine (Oak Park)`
> `1x Butter Chicken (Creamy)  $14.99  + Medium`
> `1x Garlic Naan  $3.49`
> `Subtotal $18.48   Tax $1.11   TOTAL $19.59`
> `PAYMENT: link sent to customer`

So everything from `voice_gateway.py` inward is real, on a real restaurant.

## Two hard gates the engine enforced on me

Both are features, not obstacles — and both will bite during onboarding if you
do not know them:

1. **The gateway refused to start** because I set the direct staff line to the
   restaurant's published number: `forwarding_loop:CHERRY_DIRECT_FALLBACK_…`.
   A transfer to a number that forwards into Cherry is an infinite loop, and
   the engine will not boot with one. The direct line must differ from the
   published number **and** from every DID.
2. **The gateway refused to start** without `TELNYX_API_KEY`
   (`TELNYX_API_KEY is required for voice transfer`). Transfers are part of the
   call path, so there is no "voice without Telnyx".

## The chain for a live customer call

| Step | State |
| --- | --- |
| Customer dials the published number | — |
| **Telnyx DID** + messaging profile + 10DLC campaign | **needs account** |
| **Inworld media worker**: ASR, LLM tool selection, TTS over SIP | **provider account** |
| **`inworld_adapter.py`** — Inworld events → the engine | **built 2026-09-30, tested** |
| `voice_gateway.py` — HTTP call-lifecycle contract | **built, tested** |
| `agent_api.py` — 19 tools | **built, tested** |
| `order_engine.py` — deterministic cart, pricing, tax | **built, tested** |
| **Square itemized checkout** (merchant OAuth per location) | **needs merchant** |
| Kitchen ticket / SMS to restaurant | **built, tested** |

**Update 2026-09-30: the adapter is written.** `inworld_adapter.py` translates
Inworld call events into the gateway contract, and `POST /v1/inworld/events`
accepts them. Cherry's side of a live call is now complete; what remains is
provider accounts, not code. See `CHANGES_2026-09-30.md` part 3.

## What you need, in the order that unblocks you

1. **Inworld SIP access and the four answers** (`DEVELOPER_HANDOFF.md` §Phase 3):
   the REFER transfer path; whether the DID and caller ID are passed through;
   whether the worker receives the real Telnyx `call_control_id`; and whether
   text can go straight to TTS. **The adapter that consumes those answers is now
   built** — when access lands, capture one real event and run
   `python3 inworld_adapter.py check --file event.json`. If Inworld names a field
   differently, that is an environment variable, not a code change:
   `CHERRY_INWORLD_CALL_ID_FIELD=conversation_id`. `python3 inworld_adapter.py
   dialect` prints the live mapping.
2. **Telnyx**: one DID per location, messaging profile, and 10DLC campaign
   assignment. Buying a number is not enough; the campaign must be assigned or
   the checkout SMS never arrives.
3. **Square merchant authorization** per restaurant, so the checkout link is
   real rather than `--dev-checkout`. Send each owner their
   `square_oauth.py authorize-url` link once the Square app exists.
4. **A server**: TLS in front, Cherry API private, secrets set, jobs scheduled.
5. **A direct staff line per location** that does not forward into Cherry.

**As of 2026-09-30, none of these is code in this repository.** Items 1–3 are
accounts and authorizations.

## What you can do with a real customer THIS WEEK

You do not have to wait for the voice layer to onboard customer #1 and prove
the engine on their menu. Two things work right now:

**1. Their menu, for real.** `cherry.py ingest` now reads a pasted or typed menu
as written — bare prices and all — and `cherry.py check` refuses anything
unsafe. A brand-new restaurant was taken from pasted text to a paid order with
zero Python written. Do this with the owner's actual menu and you will find out
immediately whether their data is clean.

**2. A Wizard-of-Oz test call, at the counter.** `cherry.py play` is the
harness for exactly this: the owner (or you) speaks as the caller, types what
they said, and Lily's reply is the engine's real reply. It is not a
simulation of the engine — it *is* the engine. You can sit with the owner and
take real orders by hand against their real menu, today, and they can judge the
answers. Every ambiguity, every missing modifier price and every wrong alias
shows up in that session rather than on a customer's call.

That is a legitimate way to onboard the first restaurant: prove the engine
against their menu with a human in the loop, then put the voice layer in front
of the same contract once Inworld is connected. The thing being tested — the
part that is your moat — does not change between those two steps.

## The strategic point this evidence supports

The gap is precisely the commodity layer. Speech recognition, tool selection
and TTS are things Inworld, Vapi, Retell and others sell by the minute; the
deterministic engine, the menu model and the invariants (`check` refusing a
config that would overcharge, the loop guard, "never state a price you were not
given") are the parts nobody sells you. That is consistent with calling the
engine the moat — and it argues for **buying** the voice layer rather than
building it, and spending the build effort on onboarding automation and the
provider provisioning that currently blocks every location after the tenth.
