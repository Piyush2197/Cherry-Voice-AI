#!/usr/bin/env python3
"""Every third-party import is declared, and a missing dependency is explained.

`import yaml` appears all over the engine. PyYAML was always in requirements.txt
and in `.venv` — but the system `python3` has none of it, so running a command
from a plain terminal died with `ModuleNotFoundError: No module named 'yaml'`.
This keeps two promises:

  1. nothing imports a package that requirements.txt / requirements-postgres.txt
     do not declare (so a fresh server's `pip install` is enough);
  2. running an entry point with an interpreter that lacks the dependencies
     either re-runs itself under `.venv` or prints the commands that fix it —
     never a bare traceback.
"""

from __future__ import annotations

import ast
import importlib.util
import os
import re
import subprocess
import sys
import sysconfig
import traceback
from pathlib import Path

HERE = Path(__file__).resolve().parent
_passed = _failed = 0

# import name -> distribution name in requirements*.txt
DISTRIBUTION = {"yaml": "pyyaml", "cryptography": "cryptography", "openpyxl": "openpyxl",
                "psycopg": "psycopg", "psycopg_pool": "psycopg-pool"}


def check(name, cond, detail=""):
    global _passed, _failed
    if cond:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


def declared() -> set:
    out = set()
    for fname in ("requirements.txt", "requirements-postgres.txt"):
        for line in (HERE / fname).read_text().splitlines():
            line = line.strip()
            if not line or line.startswith(("#", "-r")):
                continue
            out.add(re.split(r"[\[<>=!~ ;]", line, maxsplit=1)[0].lower().replace("_", "-"))
    return out


def project_modules() -> set:
    return {p.stem for p in HERE.glob("*.py")} | {p.name for p in HERE.iterdir() if p.is_dir()}


def is_stdlib(name: str) -> bool:
    if name in sys.builtin_module_names or name == "__future__":
        return True
    try:
        spec = importlib.util.find_spec(name)
    except (ImportError, ValueError):
        return False
    if spec is None:
        return False
    origin = spec.origin or ""
    std = sysconfig.get_paths()["stdlib"]
    return origin in ("built-in", "frozen") or (origin.startswith(std) and "site-packages" not in origin)


def third_party_imports() -> dict:
    local = project_modules()
    found = {}
    for path in sorted(HERE.rglob("*.py")):
        rel = path.relative_to(HERE)
        if rel.parts[0] in (".venv", "node_modules") or "web-integration" in rel.parts:
            continue
        for node in ast.walk(ast.parse(path.read_text())):
            names = []
            if isinstance(node, ast.Import):
                names = [a.name.split(".")[0] for a in node.names]
            elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
                names = [node.module.split(".")[0]]
            for n in names:
                if n not in local and not is_stdlib(n):
                    found.setdefault(n, set()).add(str(rel))
    return found


def t_every_third_party_import_is_declared() -> None:
    have = declared()
    check("requirements.txt declares PyYAML", "pyyaml" in have, str(sorted(have)))
    check("…and cryptography, openpyxl and tzdata (zoneinfo needs it on a slim server)",
          {"cryptography", "openpyxl", "tzdata"} <= have, str(sorted(have)))
    check("the PostgreSQL file adds psycopg and its pool", {"psycopg", "psycopg-pool"} <= have)
    imports = third_party_imports()
    check("the scan found the dependencies the engine really uses", {"yaml", "cryptography"} <= set(imports), str(sorted(imports)))
    for module, files in sorted(imports.items()):
        dist = DISTRIBUTION.get(module, module).lower()
        check(f"`import {module}` ({sorted(files)[0]}…) is declared as {dist}", dist in have, f"declared: {sorted(have)}")
    uses_zoneinfo = any("zoneinfo" in p.read_text() for p in HERE.glob("*.py"))
    check("zoneinfo is used, so tzdata must be installed", not uses_zoneinfo or "tzdata" in have)


def _run(args, *, no_site=False, extra_env=None):
    env = {k: v for k, v in os.environ.items() if k != "PYTHONPATH"}
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env.update(extra_env or {})
    cmd = [sys.executable] + (["-S"] if no_site else []) + args
    return subprocess.run(cmd, cwd=HERE, env=env, capture_output=True, text=True, timeout=120)


def t_an_interpreter_without_the_dependencies_is_handled() -> None:
    venv = HERE / ".venv" / "bin" / "python"
    # `-S` drops site-packages, so this interpreter really has no PyYAML (the user's situation)
    bare = _run(["-S", "-c", "import yaml"], no_site=False)
    check("(the test's own premise: `-S` interpreter cannot import yaml)", bare.returncode != 0, bare.stderr[-200:])

    r = _run(["-S", "go_live.py", "--help"], extra_env={"CHERRY_NO_REEXEC": "1"})
    check("with the re-run switched off it explains the fix and exits 2, no traceback",
          r.returncode == 2 and "missing PyYAML" in r.stderr and "pip install -r requirements.txt" in r.stderr
          and "Traceback" not in r.stderr, f"{r.returncode}: {r.stderr[-300:]}")
    check("…and names the file that was being run", "go_live.py" in r.stderr)

    r = _run(["-S", "go_live.py", "--help"])
    if venv.exists():
        check("with a .venv present the same command re-runs under it and works",
              r.returncode == 0 and "usage: go_live.py" in r.stdout, f"{r.returncode}: {r.stderr[-300:]}")
    else:
        check("with no .venv it explains the fix instead of a traceback",
              r.returncode == 2 and "pip install -r requirements.txt" in r.stderr, f"{r.returncode}: {r.stderr[-300:]}")

    r = _run(["-S", "-c", "import _ensure_deps"])
    check("an interactive / `-c` session is never silently re-run under another interpreter",
          r.returncode == 2 and "missing PyYAML" in r.stderr, f"{r.returncode}: {r.stderr[-200:]}")

    r = _run(["-m", "py_compile", "menu_schema.py"])
    check("the guard does not break ordinary tooling that compiles the module", r.returncode == 0, r.stderr[-200:])


def t_the_entry_points_carry_the_guard() -> None:
    for name in ("server.py", "voice_gateway.py", "cherry.py", "go_live.py", "pilot_deploy.py",
                 "menu_schema.py", "order_store.py", "call_review.py", "model_bakeoff.py"):
        check(f"{name} imports the dependency guard", "import _ensure_deps" in (HERE / name).read_text())
    src = (HERE / "_ensure_deps.py").read_text()
    first = src.split("\nimport _ensure_deps")[0]
    check("the guard itself imports no third-party package", "import yaml" not in src and "import cryptography" not in src)
    check("the deployed units run the venv's interpreter explicitly",
          all("/opt/cherry/.venv/bin/python" in (HERE / "deploy" / "systemd" / u).read_text()
              for u in ("cherry-server.service", "cherry-gateway.service")))


def main() -> int:
    global _failed
    for name, fn in sorted((k, v) for k, v in globals().items() if k.startswith("t_")):
        try:
            fn()
        except Exception:                                    # noqa: BLE001
            _failed += 1
            print(f"\n--- FAIL {name} raised")
            traceback.print_exc()
    print(f"{_passed} passed, {_failed} failed (dependencies)")
    return 1 if _failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
