# Cherry launch operating plan

Decision record updated 2026-09-23. `PRICING_PLANS_2026-09-23.md` is the
current pricing decision for the three plans. Unresolved commercial terms must
not be improvised during sales.

## Launch offer

- Small Tier: $299 month-to-month or $2,988 paid upfront for a twelve-month
  contract ($249/month equivalent), with 3,000 voice minutes per month.
- Medium Tier: $399 month-to-month or $4,188 paid upfront for a twelve-month
  contract ($349/month equivalent), with 5,000 voice minutes per month.
- Grande Tier: $799 month-to-month or $8,988 paid upfront for a twelve-month
  contract ($749/month equivalent), with 10,000 voice minutes per month.
- No implementation fee for the first 50 restaurants.
- The offer is per location, not per restaurant brand.
- Never describe it as unlimited. There is no surprise overage charge. If a
  location exceeds its plan's included minutes for three consecutive completed
  billing months, review it for the next plan. The current partial month never
  counts. The code currently monitors only the 3,000-minute threshold and
  needs a per-location tier before this rule is automated for all plans.
- The advertised daily call examples assume 2.5-minute average calls; they
  are estimates, not a separate daily cap. The older engineering cost model
  uses 90-second calls and requires recalibration with live provider invoices.

## Bun N Run launch boundary

- Bun N Run is first because the small menu is the safest live proof.
- Pickup ordering only at launch.
- Every pilot order, regardless of amount, requires an itemized, restaurant-
  hosted review-and-pay checkout before restaurant/POS handoff. The previous
  $30 threshold no longer applies to the seven pilot menus.
- A generic website ordering page is not a checkout for Cherry's existing
  order. If no order-specific provider is available, the order is held and
  the caller is told the restaurant has not received it.
- Square's itemized checkout creates its POS order at link creation. Payment
  makes that order available to the restaurant. Cherry ends its call flow after
  texting the link and never creates a second order or kitchen ticket.
- Cherry stores the final order, immutable menu version, delivery trail and
  transcript. Cherry does not store call audio.
- Human fallback goes to a verified direct staff line that does not forward
  back to Cherry. The existing public number forwards to the Telnyx DID.
- Each location receives its own Telnyx number.
- Reservations remain disabled for Bun N Run unless its owner explicitly
  confirms that the location accepts them and supplies its policy.

## Support and incident model

- Customer-facing support is email-first.
- The founder owns sales, onboarding, restaurant communication and customer
  success through restaurant 50.
- The backend developer owns deployment, secrets, provider wiring, database,
  production alerts, recovery and compliance implementation.
- The AI operations assistant diagnoses current alerts, safely closes only
  stale sessions with no order, prepares a privacy-safe developer handoff and
  escalates the same incident signature to the main developer on occurrence
  three within seven days. It never changes orders, menus, prices, payments,
  routing or credentials.
- AI assistants are not contractual on-call staff. Human fallback handles the
  live caller when Cherry cannot, and the founder/main developer remain
  accountable for persistent incidents even when AI performs the diagnosis.
- During restaurant hours automated monitoring watches order-delivery failures,
  transfers, payment-link failures and unusual complaint volume. Human fallback
  protects the live caller; the founder responds when available and the main
  developer owns persistent technical repair.
- The pilot is best-effort with human fallback. No uptime percentage or
  service-credit promise may be quoted until the owner approves one and it has
  been measured in production.
- Customer SMS is retained as the order-review and Square-hosted payment
  checkpoint. Do not remove that message during cost work.

## Incorrect orders and complaints

- Every complaint is investigated against the immutable final order and call
  transcript. No original audio is retained.
- Duplicate orders, incorrect price, missed removal/allergy language and an
  order delivered to the wrong location are severity-one product incidents.
- Who pays for a remake/refund is unresolved. The OWNER must approve a written
  policy and liability cap before the first paid agreement. Until then, sales
  must not promise that Cherry or the restaurant automatically absorbs it.

## Product decisions

- Keep one cuisine-agnostic order engine with cuisine knowledge packs.
- Multilingual capability can be activated only after a real-call acceptance
  test for that language and restaurant menu.
- Guest memory is desired, but requires explicit consent, retention, deletion,
  tenant isolation and a customer opt-out before activation.
- Catering is location-specific and remains disabled until the owner supplies
  lead time, minimums, deposits, capacity and cancellation rules.
- Delivery dispatch and a mobile app are not launch priorities.
- The operator dashboard exists; production access and live alerts remain a
  deployment responsibility.

## Phone reservations

The code supports request-only phone reservations. Each location must enable a
policy with maximum party size, minimum notice and advance-booking window.
Cherry checks those limits and configured opening hours, issues an eight-
character code, texts the restaurant and guest, and waits for staff to confirm
or decline. Cancellation requires the code and matching caller phone.

Cherry must never say a table is confirmed merely because the request was
recorded. OpenTable/Toast synchronization can be added later through a provider
adapter; it is not required for the safe request-only workflow.

## Hiring trigger

At or before 50 restaurants, hire one customer-success/operator role and one
backend/reliability role. Hire earlier if founder support exceeds 20 hours per
week, any open-hours shift lacks a named human owner, or onboarding success
falls below 90% within two business days.
