#!/usr/bin/env python3
"""
The demo line and the prospect pipeline.

Two things are being protected here.

**The safety boundary.** A demo must be incapable of becoming a real order. It
drives `agent_api.CallSession` over a YAML config and touches no database, no
SMS sender and no payment provider. If that ever stops being true, a
demonstration shown before a contract exists could leave a restaurant with a
phantom ticket — so the tests assert the absence, not just the behaviour.

**The honesty boundary.** A prospect has no menu on file until someone ingests
one. Until then every entry is a `cuisine_demo`: the closest menu we have, never
claimed as theirs. The greeting may borrow their name — that is what makes the
demo land — but `menu_kind` must not quietly become `their_menu`, because that
is the flag the rep relies on to know what they may say out loud.
"""

from __future__ import annotations

import _ensure_deps  # noqa: F401  (re-runs under .venv, or says how to install, if PyYAML is missing)
import io
import json
import os
import tempfile
from contextlib import redirect_stdout
from pathlib import Path

import yaml

import demo_line as dl
import prospect as pr

_passed = _failed = 0


def check(name, condition, detail=""):
    global _passed, _failed
    if condition:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


FIELD_PLAN = Path(__file__).resolve().parent.parent / \
    "sales" / "cherry-clinton-first-field-plan-v2.xlsx"


def entry(code="101", name="Thai Delight", menu="menus/demo-thai.yaml",
          kind="cuisine_demo", **kw):
    return dl.DemoEntry(code=code, name=name, menu=menu, menu_kind=kind, **kw)


# ---------------------------------------------------------------------------
# Resolution — the routing behind the number
# ---------------------------------------------------------------------------


def t_a_typed_code_wins_and_is_exact():
    line = [entry("101", "Thai Delight"), entry("102", "Kaveri")]
    got = dl.resolve(line, code="102")
    check("the typed code picks the right stop", got.name == "Kaveri", got.name)


def t_an_unknown_code_names_the_known_ones():
    line = [entry("101"), entry("102")]
    try:
        dl.resolve(line, code="999")
        check("an unknown code raises", False, "no exception")
    except dl.DemoLineError as exc:
        check("an unknown code raises", True)
        check("and lists codes that would work",
              "101" in str(exc) and "102" in str(exc), str(exc))


def t_nothing_is_guessed_when_no_code_is_given():
    """Answering with the wrong restaurant's menu is worse than asking."""
    line = [entry("101"), entry("102")]
    try:
        dl.resolve(line)
        check("resolution without a code refuses", False, "it guessed")
    except dl.DemoLineError as exc:
        check("resolution without a code refuses", True)
        check("and asks which restaurant", "which restaurant" in str(exc).lower(),
              str(exc))


def t_a_pin_answers_without_typing_a_code():
    line = [entry("101", "Thai Delight"), entry("102", "Kaveri")]
    got = dl.resolve(line, caller="+13135551234",
                     pins={"+13135551234": "102"})
    check("a pinned caller resolves silently", got.name == "Kaveri", got.name)


def t_a_stale_pin_says_so_rather_than_falling_back():
    line = [entry("101", "Thai Delight")]
    try:
        dl.resolve(line, caller="+13135551234", pins={"+13135551234": "999"})
        check("a pin to a removed stop raises", False, "it fell back")
    except dl.DemoLineError as exc:
        check("a pin to a removed stop raises", True)
        check("and explains the pin is stale", "not on the" in str(exc), str(exc))


def t_inactive_entries_are_unreachable():
    line = [entry("101", "Gone", active=False), entry("102", "Here")]
    try:
        dl.resolve(line, code="101")
        check("an inactive entry is not served", False, "it answered")
    except dl.DemoLineError:
        check("an inactive entry is not served", True)


def t_pins_come_from_the_environment():
    pins = dl.pins_from_env({"CHERRY_DEMO_PIN_13135551234": "102",
                             "OTHER": "x"})
    check("an env pin is read", pins.get("+13135551234") == "102", str(pins))


# ---------------------------------------------------------------------------
# The registry
# ---------------------------------------------------------------------------


def t_the_registry_refuses_a_bad_code():
    """Codes are typed on a phone keypad in front of an owner."""
    with tempfile.TemporaryDirectory() as td:
        p = Path(td) / "line.yaml"
        for bad in ("", "1", "12345", "abc"):
            p.write_text(yaml.safe_dump({"schema_version": 1, "entries": [
                {"code": bad, "name": "X", "menu": ""}]}))
            try:
                dl.load_line(p)
                check(f"code {bad!r} is refused", False, "accepted")
            except dl.DemoLineError:
                check(f"code {bad!r} is refused", True)


def t_the_registry_refuses_a_duplicate_code():
    with tempfile.TemporaryDirectory() as td:
        p = Path(td) / "line.yaml"
        p.write_text(yaml.safe_dump({"schema_version": 1, "entries": [
            {"code": "101", "name": "A", "menu": ""},
            {"code": "101", "name": "B", "menu": ""}]}))
        try:
            dl.load_line(p)
            check("a duplicate code is refused", False, "accepted")
        except dl.DemoLineError as exc:
            check("a duplicate code is refused", True)
            check("and says so", "duplicate" in str(exc), str(exc))


def t_the_registry_refuses_a_menu_that_does_not_exist():
    with tempfile.TemporaryDirectory() as td:
        p = Path(td) / "line.yaml"
        p.write_text(yaml.safe_dump({"schema_version": 1, "entries": [
            {"code": "101", "name": "A", "menu": "menus/nope.yaml"}]}))
        try:
            dl.load_line(p)
            check("a missing menu is refused at load", False, "accepted")
        except dl.DemoLineError as exc:
            check("a missing menu is refused at load", True)
            check("and names the file", "nope.yaml" in str(exc), str(exc))


def t_a_missing_line_says_how_to_build_one():
    try:
        dl.load_line(Path("/tmp/definitely-not-here-9182.yaml"))
        check("a missing line raises", False, "no exception")
    except dl.DemoLineError as exc:
        check("a missing line raises", True)
        check("and points at the command that builds it",
              "prospect" in str(exc), str(exc))


# ---------------------------------------------------------------------------
# The safety boundary
# ---------------------------------------------------------------------------


def t_running_a_demo_touches_no_database_and_sends_nothing():
    """The property that lets a demo be shown before a contract exists."""
    import inspect
    src = inspect.getsource(dl.run_demo)
    for forbidden, why in (("OrderStore", "a database"),
                           ("place_order", "a persisted order"),
                           ("arrange_payment", "a payment"),
                           ("deliver(", "a POS/kitchen handoff")):
        check(f"run_demo touches no {why}", forbidden not in src, forbidden)
    check("the whole module avoids a database",
          "OrderStore" not in inspect.getsource(dl))


def t_a_demo_over_a_cuisine_menu_completes_and_says_it_is_a_demo():
    e = entry("101", "Thai Delight", "menus/demo-thai.yaml")
    script = Path(tempfile.mkdtemp()) / "order.txt"
    script.write_text("pad thai\nchicken\nmedium\nread\n")
    buf = io.StringIO()
    with redirect_stdout(buf):
        rc = dl.run_demo(e, script)
    out = buf.getvalue()
    check("the demo order completes", rc == 0, out[-300:])
    check("the greeting uses the restaurant's name",
          "Thanks for calling" in out, out[:300])
    check("the cuisine-demo warning is printed BEFORE any claim",
          "CUISINE DEMO" in out and out.index("CUISINE DEMO") < out.index("Thanks for calling"),
          out[:400])
    check("and it says nothing was really ordered",
          "nothing was sent" in out.lower(), out[-200:])


def t_personalising_borrows_the_name_but_not_the_menu():
    p = pr.Prospect(name="Kaveri Indian Cuisine", day=2, status="Prospect",
                    address="39890 Garfield Rd")
    with tempfile.TemporaryDirectory() as td:
        rel = pr.personalise(p, "menus/saffron_house.yaml", Path(td))
        doc = yaml.safe_load((Path(td) / Path(rel).name).read_text())
    check("the greeting name is theirs",
          doc["restaurant"]["name"] == "Kaveri Indian Cuisine",
          doc["restaurant"]["name"])
    check("the id marks it a demo",
          doc["restaurant"]["id"].startswith("demo-"), doc["restaurant"]["id"])
    check("the file itself says it is not their menu",
          "NOT this restaurant's menu" in doc["restaurant"]["notes"],
          doc["restaurant"]["notes"][:120])
    check("the items are the cuisine demo's, not invented",
          doc["restaurant"]["cuisine"] == "indian",
          doc["restaurant"]["cuisine"])


# ---------------------------------------------------------------------------
# The prospect pipeline
# ---------------------------------------------------------------------------


def t_cuisine_guessing_is_a_table_not_a_model():
    cases = [("Thai Delight", "thai"), ("Golden Gate Thai Cuisine", "thai"),
             ("China Moon To-Go", "chinese"), ("Kaveri Indian Cuisine", "indian"),
             ("Aurelio's Restaurant", "pizza" if False else ""),
             ("El Taco Dojo", "mexican"), ("Zestia Greek Street Food",
                                           "mediterranean"),
             ("Kabob Castle", "mediterranean"), ("Sorrento Pizza", "pizza"),
             ("Copper Kettle Restaurant", "american")]
    for name, want in cases:
        got = pr.guess_cuisine(name)
        if want:
            check(f"{name!r} -> {want}", got == want, f"got {got!r}")
    check("an unrecognised name returns nothing rather than guessing",
          pr.guess_cuisine("Bigtime Eatz") == "",
          pr.guess_cuisine("Bigtime Eatz"))


def t_every_recognised_cuisine_has_a_menu():
    """A recognised cuisine with no menu would put a wrong dish in front of an
    owner. Either we have the menu or we say we do not."""
    for cuisine, _words in pr.CUISINE_KEYWORDS:
        if cuisine in ("seafood",):        # recognised but deliberately absent
            continue
        check(f"a demo menu exists for {cuisine}",
              cuisine in pr.CUISINE_DEMO_MENU, cuisine)
    for cuisine, menu in pr.CUISINE_DEMO_MENU.items():
        check(f"the {cuisine} menu is present", (pr.ROOT / menu).exists(), menu)


def t_codes_are_typeable():
    check("codes start at 101, not 001",
          pr.code_for(0) == "100" and pr.code_for(1) == "101",
          f"{pr.code_for(0)}, {pr.code_for(1)}")
    check("codes stay short", len(pr.code_for(26)) <= 3, pr.code_for(26))


def t_the_real_field_plan_produces_a_usable_line():
    """The end-to-end check, against the actual workbook."""
    if not FIELD_PLAN.exists():
        check("field plan present", False, f"missing {FIELD_PLAN}")
        return
    prospects = list(pr.read_plan(FIELD_PLAN))
    check("the plan is read", len(prospects) >= 30, f"{len(prospects)} rows")
    pitchable = [p for p in prospects if p.is_pitchable]
    check("pitchable stops are identified", len(pitchable) >= 20,
          f"{len(pitchable)}")

    with tempfile.TemporaryDirectory() as td:
        entries, gaps = pr.build_line(pitchable, personalise_dir=Path(td))
        # Assert inside the block: the personalised configs live in the
        # temporary directory and are gone once it closes.
        check("every pitchable stop gets a menu", not gaps,
              f"{len(gaps)} gap(s): {[g.name for g in gaps][:4]}")
        check("codes are unique", len({e.code for e in entries}) == len(entries))
        check("every entry points at a real menu",
              all(e.menu_path.exists() for e in entries),
              str([e.menu for e in entries if not e.menu_path.exists()][:3]))
        check("nothing is claimed as the prospect's own menu",
              all(e.menu_kind == "cuisine_demo" for e in entries),
              str({e.menu_kind for e in entries}))


def t_the_committed_line_matches_the_pipeline():
    """The registry in the repo must still be loadable and honest."""
    line = dl.load_line()
    check("the committed line loads", len(line) >= 20, f"{len(line)} entries")
    check("every code is reachable", all(dl.CODE.fullmatch(e.code) for e in line))
    check("every menu exists", all(e.menu_path.exists() for e in line),
          str([e.menu for e in line if not e.menu_path.exists()][:3]))
    check("cuisine demos are labelled",
          all(e.menu_kind in dl.MENU_KINDS for e in line))
    check("describe() never calls a cuisine demo 'theirs'",
          all("not their menu" in e.describe().lower()
              or e.menu_kind == "their_menu" for e in line),
          str([e.describe() for e in line if e.menu_kind == "cuisine_demo"][:1]))


def t_cli_round_trip():
    def run(argv):
        buf = io.StringIO()
        with redirect_stdout(buf):
            rc = dl.main(argv)
        return rc, buf.getvalue()

    rc, out = run(["list"])
    check("list works", rc == 0 and "Demo line" in out, out[:200])
    rc, out = run(["list", "--json"])
    check("list --json parses", rc == 0 and isinstance(json.loads(out), list))
    rc, out = run(["resolve", "--code", "101"])
    check("resolve works", rc == 0, out[:200])
    rc, out = run(["resolve", "--code", "does-not-exist"])
    check("resolve fails loudly on a bad code", rc == 1, out[:200])


def main():
    tests = [v for k, v in sorted(globals().items())
             if k.startswith("t_") and callable(v)]
    for fn in tests:
        try:
            fn()
        except Exception as exc:                       # noqa: BLE001
            import traceback
            check(f"{fn.__name__} raised", False, repr(exc))
            traceback.print_exc()
    if _failed:
        print(f"{_passed} passed, {_failed} failed (demo line)")
        return 1
    print(f"{_passed} passed, 0 failed (demo line)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
