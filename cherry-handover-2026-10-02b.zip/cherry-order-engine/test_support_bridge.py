#!/usr/bin/env python3
"""The support bridge: alerts and owner messages reach Slack or fail loudly."""
from __future__ import annotations

import io
import json
import sys
import unittest
from contextlib import redirect_stderr
from pathlib import Path
from unittest import mock

import support_bridge as sb


class _FakeResponse:
    def __init__(self, status):
        self.status = status

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


class FakeOpener:
    def __init__(self, status=200, exc=None):
        self.status = status
        self.exc = exc
        self.requests = []

    def urlopen(self, req, timeout=None):
        self.requests.append({"url": req.full_url,
                              "body": json.loads(req.data.decode()),
                              "timeout": timeout})
        if self.exc:
            raise self.exc
        return _FakeResponse(self.status)


class TestSupportBridge(unittest.TestCase):
    URL = "https://hooks.slack.com/services/T000/B000/XYZ"

    def test_missing_webhook_is_a_clean_noop(self):
        # local development and tests must not crash on missing infra
        with mock.patch.dict("os.environ", {}, clear=True):
            self.assertEqual(sb.notify_support("hi")["status"], "disabled")
            self.assertEqual(sb.notify_alerts([{"a": 1}])["status"],
                             "disabled")

    def test_support_message_posts_and_formats(self):
        fake = FakeOpener()
        with mock.patch("urllib.request.urlopen", fake.urlopen):
            result = sb.notify_support("Need a price changed for the lunch "
                                       "special", restaurant="The Copper "
                                       "Kettle", severity="urgent",
                                       webhook_url=self.URL)
        self.assertTrue(result["ok"])
        sent = fake.requests[0]["body"]
        self.assertIn("The Copper Kettle", sent["text"])
        self.assertIn("price changed", sent["text"])
        self.assertEqual(sent["blocks"][0]["type"], "section")

    def test_failed_post_is_returned_never_swallowed(self):
        fake = FakeOpener(exc=OSError("network down"))
        with mock.patch("urllib.request.urlopen", fake.urlopen):
            result = sb.notify_support("owner question", webhook_url=self.URL)
        self.assertFalse(result["ok"])
        self.assertIn("network down", result["error"])

    def test_empty_alerts_post_nothing(self):
        # silence should mean quiet, not a lost connection
        fake = FakeOpener()
        with mock.patch("urllib.request.urlopen", fake.urlopen):
            result = sb.notify_alerts([], webhook_url=self.URL)
        self.assertTrue(result["ok"])
        self.assertFalse(result["posted"])
        self.assertEqual(fake.requests, [])

    def test_alerts_are_capped_and_formatted(self):
        fake = FakeOpener()
        alerts = [{"kind": f"alert-{i}"} for i in range(40)]
        with mock.patch("urllib.request.urlopen", fake.urlopen):
            result = sb.notify_alerts(alerts, webhook_url=self.URL)
        self.assertTrue(result["ok"])
        text = fake.requests[0]["body"]["text"]
        self.assertIn("alert-0", text)
        self.assertIn("alert-19", text)
        self.assertNotIn("alert-20", text)


if __name__ == "__main__":
    unittest.main(verbosity=1)
