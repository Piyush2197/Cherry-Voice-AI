#!/usr/bin/env python3
"""Offline end-to-end drill of Cherry outage -> Telnyx human transfer.

No network request is made. The real bridge and transfer adapter run against
recording transports, proving every configured inbound number transfers once
to the correct restaurant number when Cherry is unavailable.
"""

from __future__ import annotations

import argparse
import asyncio
import os
from pathlib import Path
from typing import Any, Dict, List, Optional

import pilot_deploy as pd
from telnyx_voice import TelnyxCallTransfer, routes_from_manifest
from voice.inworld_bridge import CherryBridge, DEAD


class OfflineCherry:
    async def request(self, method, url, headers, body, timeout):
        raise ConnectionError("simulated Cherry outage")


class RecordingTelnyx:
    def __init__(self) -> None:
        self.calls: List[Dict[str, Any]] = []

    async def post(self, url, headers, body, timeout):
        self.calls.append({"url": url, "headers": headers, "body": body})
        return 200, {"data": {"result": "ok"}}


async def drill(locations: List[pd.Location], env: Dict[str, str]) -> int:
    routes = routes_from_manifest(
        locations, env,
        require_direct=env.get("CHERRY_REQUIRE_DIRECT_FALLBACK") == "1")
    if not routes:
        print("DRILL BLOCKED: configure at least one inbound number")
        return 2
    failures = 0
    for number, fallback in routes.items():
        telnyx = RecordingTelnyx()
        audits = []
        transfer = TelnyxCallTransfer(
            routes, api_key="offline-drill-key", transport=telnyx,
            audit=lambda **row: audits.append(row))
        bridge = CherryBridge("https://offline.invalid", "drill",
                              transport=OfflineCherry(), handoff=transfer)
        call_id = "drill-" + number.replace("+", "")
        first = await bridge.start(call_id, dialled=number)
        second = await bridge.handle_tool_call(call_id, "add_item",
                                               {"text": "test item"})
        ok = (first == DEAD and second == DEAD and len(telnyx.calls) == 1
              and telnyx.calls[0]["body"]["to"] == fallback
              and len(audits) == 1 and audits[0]["status"] == "succeeded")
        if ok:
            print(f"PASS {number} -> {fallback}: transferred once and audited")
        else:
            failures += 1
            print(f"FAIL {number} -> {fallback}: calls={telnyx.calls}, audit={audits}")
    return 2 if failures else 0


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, default=pd.DEFAULT_MANIFEST)
    parser.add_argument("--only", action="append", default=[])
    args = parser.parse_args(argv)
    try:
        locations = pd.selected(pd.load_manifest(args.manifest), args.only)
    except ValueError as exc:
        parser.error(str(exc))
    return asyncio.run(drill(locations, dict(os.environ)))


if __name__ == "__main__":
    raise SystemExit(main())
