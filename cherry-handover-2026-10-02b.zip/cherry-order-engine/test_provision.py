#!/usr/bin/env python3
"""provision.py against a fake Telnyx that behaves as Telnyx's documentation says.

The fake enforces the documented rules: a number cannot join a 10DLC campaign
until it has a messaging profile, the campaign must be ACTIVE, an order is
pending before it succeeds, and a rate-limited call (429) was refused before it
did anything. What these tests are really about is the money: a number must
never be bought twice, however a call fails — a timeout after an order may have
gone through must be *looked at*, never re-sent.
"""

from __future__ import annotations

import contextlib
import io
import json
import os
import tempfile
import traceback
import urllib.error
import urllib.parse
from pathlib import Path

import pilot_deploy as pd
import provision as pv

_passed = _failed = 0
KEY = "KEY0123456789SECRET"
LOC = "pink-garlic-shelby"          # +15869805142 published -> area code 586


def check(name, cond, detail=""):
    global _passed, _failed
    if cond:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


class Resp:
    def __init__(self, status, doc):
        self.status, self._raw = status, json.dumps(doc).encode()

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def read(self):
        return self._raw


class FakeTelnyx:
    def __init__(self, *, campaign_active=True, order_polls=1, camel_only=False):
        self.available = {f"+1586555{n:04d}": ("1.00", "1.00") for n in (123, 124, 125)}
        self.available["+15865559999"] = ("12.00", "9.00")         # too expensive
        self.numbers, self.orders, self.assign = {}, {}, {}
        self.calls, self.fail_next = [], []                        # [(method, path_prefix, status, body, processed)]
        self.campaign_active, self.order_polls, self.camel_only = campaign_active, order_polls, camel_only
        self.n = 0

    def err(self, code, detail, headers=None):
        raise urllib.error.HTTPError("u", code, "x", headers or {}, io.BytesIO(json.dumps(
            {"errors": [{"code": str(code), "title": "err", "detail": detail}]}).encode()))

    def __call__(self, req, timeout=None):
        parsed = urllib.parse.urlparse(req.full_url)
        path, q = parsed.path.replace("/v2", "", 1), urllib.parse.parse_qs(parsed.query)
        body = json.loads(req.data) if req.data else None
        assert req.get_header("Authorization") == f"Bearer {KEY}", "the key must be sent as a bearer token"
        method = req.get_method()
        self.calls.append((method, path, q, body))
        for i, (m, prefix, status, b, processed) in enumerate(self.fail_next):
            if m == method and path.startswith(prefix):
                self.fail_next.pop(i)
                if processed:
                    self.route(method, path, q, body)              # it happened, but the answer is lost
                if status == "timeout":
                    raise TimeoutError(f"timed out talking to {KEY}")
                self.err(status, b or "boom", {"Retry-After": "0"} if status == 429 else None)
        return self.route(method, path, q, body)

    # --- the documented API ---------------------------------------------------
    def route(self, method, path, q, body):
        if method == "GET" and path == "/available_phone_numbers":
            nd = q.get("filter[national_destination_code]", [""])[0]
            assert q.get("filter[country_code]") == ["US"] and q.get("filter[features][]") == ["voice", "sms"], q
            rows = [{"phone_number": n, "cost_information": {"upfront_cost": u, "monthly_cost": m},
                     "region_information": [{"region_type": "location", "region_name": "Warren"}],
                     "features": [{"name": "voice"}, {"name": "sms"}], "best_effort": False}
                    for n, (u, m) in self.available.items() if n[2:5] == nd and not self.owned_number(n)]
            rows.append({"phone_number": "garbage", "cost_information": {}})
            return Resp(200, {"data": rows[:int(q.get("filter[limit]", ["20"])[0]) + 1]})
        if method == "POST" and path == "/number_orders":
            n = body["phone_numbers"][0]["phone_number"]
            if n not in self.available or self.owned_number(n):
                self.err(422, "number not available")
            self.n += 1
            oid = f"order-{self.n}"
            self.orders[oid] = {"id": oid, "number": n, "polls": 0, "body": body, "status": "pending"}
            return Resp(201, {"data": {"id": oid, "status": "pending"}})
        if method == "GET" and path == "/number_orders":
            ref = q.get("filter[customer_reference]", [None])[0]
            return Resp(200, {"data": [{"id": o["id"], "status": o["status"], "customer_reference": o["body"].get("customer_reference"),
                                        "phone_numbers": [{"phone_number": o["number"]}]}
                                       for o in self.orders.values() if not ref or o["body"].get("customer_reference") == ref]})
        if method == "GET" and path.startswith("/number_orders/"):
            o = self.orders[path.rsplit("/", 1)[1]]
            o["polls"] += 1
            if o["polls"] >= self.order_polls and o["status"] == "pending":
                o["status"] = "success"
                b = o["body"]
                self.numbers[f"id-{o['number']}"] = {
                    "id": f"id-{o['number']}", "phone_number": o["number"], "status": "active",
                    "connection_id": b.get("connection_id"), "messaging_profile_id": b.get("messaging_profile_id"),
                    "customer_reference": b.get("customer_reference"), "tags": [], "billing_group_id": b.get("billing_group_id")}
            return Resp(200, {"data": {"id": o["id"], "status": o["status"]}})
        if method == "GET" and path == "/phone_numbers":
            self.settle_orders()
            ref, num = q.get("filter[customer_reference]"), q.get("filter[phone_number]")
            rows = [r for r in self.numbers.values()
                    if (not ref or r["customer_reference"] == ref[0]) and (not num or r["phone_number"] == num[0])]
            return Resp(200, {"data": rows})
        if method == "PATCH" and path.startswith("/phone_numbers/"):
            r = self.numbers[path.rsplit("/", 1)[1]]
            r.update(body)
            return Resp(200, {"data": r})
        if method == "PATCH" and path.startswith("/messaging_phone_numbers/"):
            e164 = urllib.parse.unquote(path.rsplit("/", 1)[1])
            r = next(x for x in self.numbers.values() if x["phone_number"] == e164)
            r["messaging_profile_id"] = body["messaging_profile_id"]
            return Resp(200, {"data": {"phone_number": e164, "messaging_profile_id": body["messaging_profile_id"]}})
        for base in ("/10dlc/phone_number_campaigns", "/10dlc/phoneNumberCampaign"):
            if path == base and method == "POST" or path.startswith(base + "/"):
                if (base == "/10dlc/phone_number_campaigns") == self.camel_only:
                    self.err(404, "no such route")
                if method == "POST":
                    r = next((x for x in self.numbers.values() if x["phone_number"] == body["phoneNumber"]), None)
                    if r is None or not r.get("messaging_profile_id"):
                        self.err(422, "number must be assigned to a messaging profile first")
                    if not self.campaign_active:
                        self.err(422, "campaign is not ACTIVE")
                    self.assign[body["phoneNumber"]] = {"assignmentStatus": "PENDING_ASSIGNMENT", "failureReasons": ""}
                    return Resp(200, {"phoneNumber": body["phoneNumber"], "assignmentStatus": "PENDING_ASSIGNMENT"})
                e164 = urllib.parse.unquote(path.rsplit("/", 1)[1])
                if e164 not in self.assign:
                    self.err(404, "not assigned")
                return Resp(200, dict(self.assign[e164], phoneNumber=e164))
        self.err(404, f"unrouted {method} {path}")

    def owned_number(self, n):
        return any(r["phone_number"] == n for r in self.numbers.values())

    def settle_orders(self):
        pass

    def carriers_finish(self):
        for v in self.assign.values():
            v["assignmentStatus"] = "ASSIGNED"

    def posted(self, path):
        return [c for c in self.calls if c[0] == "POST" and c[1] == path]

    def mutations(self):
        return [c for c in self.calls if c[0] in ("POST", "PATCH")]


SETTINGS = dict(connection_id="conn-1", messaging_profile_id="prof-1", campaign_id="camp-1")


def prov(fake, **kw):
    api = pv.TelnyxAPI(KEY, opener=fake, sleep=lambda s: None, spacing=0)
    return pv.Provisioner(api, pv.Settings(**{**SETTINGS, **kw}), sleep=lambda s: None, poll_seconds=0, poll_timeout=5)


def loc():
    return next(x for x in pd.load_manifest() if x.id == LOC)


def states(steps):
    return {s.name: s.state for s in steps}


# ------------------------------------------------------------------------------

def t_the_client_retries_only_what_is_safe_to_retry() -> None:
    f = FakeTelnyx()
    api = pv.TelnyxAPI(KEY, opener=f, sleep=lambda s: None, spacing=0)
    f.fail_next = [("GET", "/phone_numbers", 429, None, False), ("GET", "/phone_numbers", 503, None, False)]
    api.request("GET", "/phone_numbers", params={"filter[phone_number]": "+15865550000"})
    check("a GET survives a 429 and then a 503 (3 attempts)", len([c for c in f.calls if c[1] == "/phone_numbers"]) == 3)
    sent = [c for c in f.calls if c[1] == "/phone_numbers"][-1]
    check("filter[...] parameters arrive intact", sent[2] == {"filter[phone_number]": ["+15865550000"]}, str(sent[2]))

    f = FakeTelnyx()
    api = pv.TelnyxAPI(KEY, opener=f, sleep=lambda s: None, spacing=0)
    f.fail_next = [("POST", "/number_orders", 429, None, False)]
    f.available["+15865550001"] = ("1.00", "1.00")
    api.request("POST", "/number_orders", body={"phone_numbers": [{"phone_number": "+15865550001"}]})
    check("a POST IS retried after a 429 (Telnyx refused it before doing anything)", len(f.posted("/number_orders")) == 2)

    f = FakeTelnyx()
    api = pv.TelnyxAPI(KEY, opener=f, sleep=lambda s: None, spacing=0)
    f.fail_next = [("POST", "/number_orders", 502, "bad gateway", True)]
    try:
        api.request("POST", "/number_orders", body={"phone_numbers": [{"phone_number": "+15865550123"}]})
        check("a 502 on a POST raises", False)
    except pv.TelnyxError as exc:
        check("a 502 on a POST is NOT retried and is flagged ambiguous", exc.ambiguous and len(f.posted("/number_orders")) == 1, str(exc))

    f = FakeTelnyx()
    api = pv.TelnyxAPI(KEY, opener=f, sleep=lambda s: None, spacing=0)
    f.fail_next = [("POST", "/number_orders", "timeout", None, True)]
    try:
        api.request("POST", "/number_orders", body={"phone_numbers": [{"phone_number": "+15865550123"}]})
        check("a timeout on a POST raises", False)
    except pv.TelnyxError as exc:
        check("a timeout on a POST is ambiguous, and the API key is scrubbed from the message", exc.ambiguous and KEY not in str(exc), str(exc))

    f = FakeTelnyx()
    api = pv.TelnyxAPI(KEY, opener=f, sleep=lambda s: None, spacing=0)
    try:
        api.request("GET", "/nope")
    except pv.TelnyxError as exc:
        check("an unrouted call is a plain 404 error naming the detail", exc.status == 404 and "unrouted" in exc.detail and not exc.ambiguous)
    try:
        pv.TelnyxAPI("")
        check("an empty key is refused up front", False)
    except ValueError:
        check("an empty key is refused up front", True)


def t_search_reads_costs_and_skips_junk() -> None:
    f = FakeTelnyx()
    cands = prov(f).search("586", limit=10)
    check("candidates with prices, junk rows dropped", sorted(c.number for c in cands) == sorted(n for n in f.available if n.startswith("+1586")), str([c.number for c in cands]))
    c = next(x for x in cands if x.number == "+15865550123")
    check("prices are whole cents", (c.upfront_cents, c.monthly_cents) == (100, 100) and c.region == "Warren", str(c))
    check("an area code with nothing is an empty list", prov(f).search("999") == [])
    check("area_code() reads a US number", pv.area_code("+15869805142") == "586" and pv.area_code("+442071234567") == "" and pv.area_code("garbage") == "")


def t_apply_buys_wires_registers_and_records_once() -> None:
    f, env_file = FakeTelnyx(), tempfile.mkdtemp() + "/cherry.env"
    Path(env_file).write_text("CHERRY_API_KEY=abc\n# keep me\n")
    os.chmod(env_file, 0o640)
    p = prov(f)
    before = p.status(loc(), {})
    check("before: no number, nothing set", states(before)["number"] == pv.TODO and states(before)["env"] == pv.TODO, str(states(before)))
    steps = p.apply(loc(), "+15865550123", {}, yes=True, env_file=env_file)
    check("every step ran: number, route, messaging, 10DLC, env", states(steps) == {
        "number": "done", "voice-connection": "done", "messaging-profile": "done", "10dlc": "waiting", "env": "done"}, str(states(steps)))
    order = f.posted("/number_orders")
    check("exactly one order, with the connection, profile and the location as reference",
          len(order) == 1 and order[0][3] == {"phone_numbers": [{"phone_number": "+15865550123"}], "connection_id": "conn-1",
                                              "messaging_profile_id": "prof-1", "customer_reference": LOC}, str(order))
    rec = next(iter(f.numbers.values()))
    check("the number is tagged for the location", rec["tags"] == sorted({"cherry", LOC}) and rec["customer_reference"] == LOC, str(rec))
    camp = f.posted("/10dlc/phone_number_campaigns")
    check("assigned to the campaign by E.164 number", len(camp) == 1 and camp[0][3] == {"phoneNumber": "+15865550123", "campaignId": "camp-1"}, str(camp))
    text = Path(env_file).read_text()
    check("the env file gained the line and kept everything else", "CHERRY_INBOUND_PINK_GARLIC_SHELBY=+15865550123" in text
          and "CHERRY_API_KEY=abc" in text and "# keep me" in text, text)
    check("…without loosening the file's permissions", (os.stat(env_file).st_mode & 0o777) == 0o640)

    f.carriers_finish()
    after = p.status(loc(), {"CHERRY_INBOUND_PINK_GARLIC_SHELBY": "+15865550123", "SQUARE_TOKEN_PINK_GARLIC_SHELBY": "tok"})
    check("later, with carriers done: everything is done", all(s.state == "done" for s in after), str([(s.name, s.state) for s in after]))
    n_before = len(f.mutations())
    again = p.apply(loc(), "+15865550123", {}, yes=True, env_file=env_file)
    check("a second apply changes NOTHING and buys nothing", len(f.mutations()) == n_before and states(again)["number"] == "done",
          str(f.mutations()[n_before:]))


def t_apply_refuses_before_it_spends() -> None:
    f = FakeTelnyx()
    p = prov(f)
    cases = [
        ("without --yes", lambda: p.apply(loc(), "+15865550123", {}, yes=False), PermissionError, "--yes"),
        ("an invalid number", lambda: p.apply(loc(), "586-555-0123", {}, yes=True), ValueError, "E.164"),
        ("a number that is not on offer", lambda: p.apply(loc(), "+15865550777", {}, yes=True), ValueError, "not available"),
        ("a number over the price cap", lambda: p.apply(loc(), "+15865559999", {}, yes=True), ValueError, "over the caps"),
        ("no connection configured", lambda: prov(f, connection_id="").apply(loc(), "+15865550123", {}, yes=True), ValueError, "TELNYX_CONNECTION_ID"),
        ("no messaging profile", lambda: prov(f, messaging_profile_id="").apply(loc(), "+15865550123", {}, yes=True), ValueError, "TELNYX_MESSAGING_PROFILE"),
        ("no campaign", lambda: prov(f, campaign_id="").apply(loc(), "+15865550123", {}, yes=True), ValueError, "TELNYX_10DLC_CAMPAIGN_ID"),
    ]
    for label, fn, exc_type, needle in cases:
        try:
            fn()
            check(f"refused: {label}", False, "no error")
        except exc_type as exc:
            check(f"refused: {label}", needle in str(exc), str(exc))
    check("none of those bought anything", not f.mutations(), str(f.mutations()))
    # an unknown price is refused, not guessed
    f.available["+15865550555"] = (None, None)
    try:
        prov(f).apply(loc(), "+15865550555", {}, yes=True)
        check("an unstated price is refused", False)
    except ValueError as exc:
        check("an unstated price is refused", "did not state" in str(exc), str(exc))
    check("the caps can be raised on purpose", prov(f, max_monthly_cents=1000, max_upfront_cents=1500).apply(
        loc(), "+15865559999", {}, yes=True, skip_campaign=True)[0].state == "done")


def t_a_location_never_owns_two_numbers_and_foreign_numbers_are_not_taken() -> None:
    f = FakeTelnyx()
    p = prov(f)
    p.apply(loc(), "+15865550123", {}, yes=True)
    n = len(f.mutations())
    try:
        p.apply(loc(), "+15865550124", {}, yes=True)
        check("a second number for the same location is refused", False)
    except ValueError as exc:
        check("a second number for the same location is refused", "already owns +15865550123" in str(exc), str(exc))
    f.numbers["x"] = {"id": "x", "phone_number": "+15865550125", "status": "active", "customer_reference": "someone-else", "tags": []}
    other = next(x for x in pd.load_manifest() if x.id != LOC and x.pos_type == "square")
    try:
        p.apply(other, "+15865550125", {}, yes=True)
        check("a number that exists untagged on the account is not taken over", False)
    except ValueError as exc:
        check("a number that exists untagged on the account is not taken over", "refusing to take it over" in str(exc), str(exc))
    check("neither refusal changed anything", len(f.mutations()) == n)
    f.numbers["dup"] = dict(f.numbers["x"], id="dup", phone_number="+15865550126", customer_reference=LOC)
    st = states(p.status(loc(), {}))
    check("two numbers carrying one location's reference are reported, not guessed between", st == {"number": "failed"}, str(st))


def t_a_lost_order_response_is_looked_at_never_re_sent() -> None:
    f = FakeTelnyx()
    f.fail_next = [("POST", "/number_orders", 502, "gateway", True)]       # the order WAS placed; the reply was lost
    steps = prov(f).apply(loc(), "+15865550123", {}, yes=True)
    check("one order only, and the run carried on", len(f.posted("/number_orders")) == 1 and states(steps)["number"] == "done", str(states(steps)))

    f = FakeTelnyx()
    f.fail_next = [("POST", "/number_orders", "timeout", None, False)]     # it was NOT placed
    try:
        prov(f).apply(loc(), "+15865550123", {}, yes=True)
        check("an order that may not have happened is reported", False)
    except pv.TelnyxError as exc:
        check("an order that may not have happened is reported, with no second POST",
              "may or may not" in exc.detail and len(f.posted("/number_orders")) == 1, str(exc))
    steps = prov(f).apply(loc(), "+15865550123", {}, yes=True)
    check("after checking, a re-run buys it (once)", len(f.posted("/number_orders")) == 2 and states(steps)["number"] == "done")


def t_a_pending_order_is_resumed_not_repeated() -> None:
    f = FakeTelnyx(order_polls=10 ** 9)
    p = prov(f)
    steps = p.apply(loc(), "+15865550123", {}, yes=True)
    check("a slow order is WAITING, and the run stops there", states(steps) == {"number": "waiting"}, str(states(steps)))
    steps = p.apply(loc(), "+15865550123", {}, yes=True)
    check("the re-run finds the order in flight and does NOT place another",
          len(f.posted("/number_orders")) == 1 and states(steps) == {"number": "waiting"}, str(len(f.posted("/number_orders"))))
    try:
        p.apply(loc(), "+15865550124", {}, yes=True)
        check("asking for a different number while one is pending is refused", False)
    except ValueError as exc:
        check("asking for a different number while one is pending is refused", "pending for +15865550123" in str(exc), str(exc))
    f.order_polls = 1
    steps = p.apply(loc(), "+15865550123", {}, yes=True)
    check("once Telnyx finishes it, the run completes the wiring — still one order ever placed",
          len(f.posted("/number_orders")) == 1 and states(steps)["number"] == "done" and states(steps)["10dlc"] == "waiting", str(states(steps)))

    f2 = FakeTelnyx()
    orig = f2.route

    def fail_order(method, path, q, body):
        if method == "GET" and path.startswith("/number_orders/"):
            return Resp(200, {"data": {"id": "x", "status": "failure"}})
        return orig(method, path, q, body)
    f2.route = fail_order
    try:
        prov(f2).apply(loc(), "+15865550123", {}, yes=True)
        check("a failed order raises", False)
    except pv.TelnyxError as exc:
        check("a failed order raises, naming the number", "+15865550123" in exc.detail, str(exc))
    f2.route = orig
    f2.orders = {k: dict(v, status="failure") for k, v in f2.orders.items()}
    steps = prov(f2).apply(loc(), "+15865550123", {}, yes=True)
    check("after a FAILED order, trying again is allowed (that order is over)", states(steps)["number"] == "done")


def t_10dlc_follows_the_documented_rules() -> None:
    f = FakeTelnyx(campaign_active=False)
    steps = prov(f).apply(loc(), "+15865550123", {}, yes=True)
    st = {s.name: s for s in steps}
    check("an inactive campaign fails that step only — the bought, routed number stays",
          st["10dlc"].state == "failed" and "ACTIVE" in st["10dlc"].detail and st["number"].state == "done" and st["env"].state == "todo",
          str({k: (v.state, v.detail) for k, v in st.items()}))
    f.campaign_active = True
    n_orders = len(f.posted("/number_orders"))
    steps = prov(f).apply(loc(), "+15865550123", {}, yes=True)
    check("fix the campaign and re-run: assigned, and nothing is bought again",
          states(steps)["10dlc"] == "waiting" and len(f.posted("/number_orders")) == n_orders)

    f = FakeTelnyx(camel_only=True)
    steps = prov(f).apply(loc(), "+15865550123", {}, yes=True)
    check("when only the guide's camelCase path exists, that one is used",
          states(steps)["10dlc"] == "waiting" and len(f.posted("/10dlc/phoneNumberCampaign")) == 1, str(states(steps)))
    st = prov(f).status(loc(), {})
    check("…and status reads the assignment through it", {s.name: s.state for s in st}["10dlc"] == "waiting")

    f = FakeTelnyx()
    p = prov(f)
    p.apply(loc(), "+15865550123", {}, yes=True)
    f.assign["+15865550123"].update(assignmentStatus="FAILED_ASSIGNMENT", failureReasons="campaign suspended")
    st = {s.name: s for s in p.status(loc(), {})}
    check("a carrier-side failure is shown with its reason", st["10dlc"].state == "failed" and "suspended" in st["10dlc"].detail)

    f = FakeTelnyx()
    steps = prov(f).apply(loc(), "+15865550123", {}, yes=True, skip_campaign=True)
    check("--skip-campaign skips it and says so", states(steps)["10dlc"] == "blocked" and not f.posted("/10dlc/phone_number_campaigns"))


def t_drift_is_repaired_and_unconfigured_status_is_blocked_not_wrong() -> None:
    f = FakeTelnyx()
    p = prov(f)
    p.apply(loc(), "+15865550123", {}, yes=True)
    rec = next(iter(f.numbers.values()))
    rec.update(connection_id="somewhere-else", messaging_profile_id="old-profile", tags=[])
    st = states(p.status(loc(), {}))
    check("status spots a number routed elsewhere", st["voice-connection"] == "todo" and st["messaging-profile"] == "todo", str(st))
    p.apply(loc(), "+15865550123", {}, yes=True)
    check("apply repairs the route, the profile and the tags",
          rec["connection_id"] == "conn-1" and rec["messaging_profile_id"] == "prof-1" and "cherry" in rec["tags"], str(rec))
    unconf = states(prov(f, connection_id="", messaging_profile_id="", campaign_id="").status(loc(), {}))
    check("with nothing configured, status says BLOCKED rather than inventing a verdict",
          unconf["voice-connection"] == "blocked" and unconf["messaging-profile"] == "blocked" and unconf["10dlc"] == "blocked", str(unconf))
    st = states(p.status(loc(), {"CHERRY_INBOUND_PINK_GARLIC_SHELBY": "+19999999999"}))
    check("an env var that disagrees with Telnyx is a failure", st["env"] == "failed", str(st))


def t_the_env_file_writer_is_careful() -> None:
    d = tempfile.mkdtemp()
    p = d + "/sub/cherry.env"
    check("a missing file is created, private", pv.set_env_line(p, "CHERRY_INBOUND_X", "+15865550123") == "added" and (os.stat(p).st_mode & 0o777) == 0o600)
    check("the same value again is unchanged", pv.set_env_line(p, "CHERRY_INBOUND_X", "+15865550123") == "unchanged")
    try:
        pv.set_env_line(p, "CHERRY_INBOUND_X", "+15865550124")
        check("a different value is refused", False)
    except ValueError as exc:
        check("a different value is refused", "already set" in str(exc))
    check("…unless replacing is asked for", pv.set_env_line(p, "CHERRY_INBOUND_X", "+15865550124", replace=True) == "replaced"
          and "+15865550124" in Path(p).read_text() and "+15865550123" not in Path(p).read_text())
    Path(p).write_text('export CHERRY_INBOUND_X="+15865550124"\nOTHER=1\n')
    check("an `export NAME=\"value\"` line is recognised", pv.set_env_line(p, "CHERRY_INBOUND_X", "+15865550124") == "unchanged")
    for name, value in (("lower_case", "+15865550123"), ("X; rm -rf /", "+15865550123"), ("CHERRY_X", "5865550123"), ("CHERRY_X", "+1586\n555")):
        try:
            pv.set_env_line(p, name, value)
            check(f"refused: {name!r}={value!r}", False)
        except ValueError:
            check(f"refused: {name!r}={value!r}", True)
    check("no temp files are left behind", [x for x in os.listdir(os.path.dirname(p)) if x.startswith(".tmp")] == [])


def run_cli(fake, *argv, env=None):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = pv.main(list(argv), env={"TELNYX_API_KEY": KEY, "TELNYX_CONNECTION_ID": "conn-1", "TELNYX_MESSAGING_PROFILE": "prof-1",
                                      "TELNYX_10DLC_CAMPAIGN_ID": "camp-1", **(env or {})}, opener=fake)
    return rc, buf.getvalue()


def t_the_command_line() -> None:
    f = FakeTelnyx()
    pv.TelnyxAPI.__init__.__defaults__                      # (touch: the CLI builds its own client from `opener`)
    rc, out = run_cli(f, "plan", "--location", LOC)
    check("plan lists numbers with prices and says nothing was bought",
          rc == 0 and "+15865550123" in out and "$1.00 up front" in out and "Nothing was bought" in out and not f.mutations(), out)
    check("the API key never appears in output", KEY not in out)

    rc, out = run_cli(f, "apply", "--location", LOC, "--number", "+15865550123")
    check("apply without --yes is refused (exit 1) and buys nothing", rc == 1 and "--yes" in out and not f.mutations(), out)

    rc, out = run_cli(f, "plan", "--location", LOC, "--area-code", "")
    check("plan derives the area code from the published number", "586" in out)

    env_file = tempfile.mkdtemp() + "/cherry.env"
    rc, out = run_cli(f, "apply", "--location", LOC, "--number", "+15865550123", "--yes", "--env-file", env_file)
    check("apply --yes buys and wires it (exit 3 while carriers finish the 10DLC)", rc == 3 and "bought +15865550123" in out and "waiting" in out, out)
    check("the next command is named", "pilot_deploy.py apply --only pink-garlic-shelby" in out)
    f.carriers_finish()
    rc, out = run_cli(f, "status", "--location", LOC, env={"CHERRY_INBOUND_PINK_GARLIC_SHELBY": "+15865550123", "SQUARE_TOKEN_PINK_GARLIC_SHELBY": "t"})
    check("status exits 0 when everything is done", rc == 0 and "todo" not in out and "FAILED" not in out, out)
    rc, out = run_cli(f, "status", "--all")
    check("status --all covers every manifest location and exits 3 for the unfinished", rc == 3 and out.count("[") >= len(pd.load_manifest()) and "no Telnyx number" in out, out[:300])
    check("the key is still absent from everything printed", KEY not in out)

    rc, out = run_cli(f, "plan", "--location", "no-such-place")
    check("an unknown location is an error, not a traceback", rc == 1 and "unknown" in out, out)
    rc, out = run_cli(f, "plan", "--location", LOC, env={"TELNYX_API_KEY": ""})
    check("a missing key says so", rc == 1 and "TELNYX_API_KEY is not set" in out, out)


def main() -> int:
    global _failed
    for name, fn in sorted((k, v) for k, v in globals().items() if k.startswith("t_")):
        try:
            fn()
        except Exception:                                    # noqa: BLE001
            _failed += 1
            print(f"\n--- FAIL {name} raised")
            traceback.print_exc()
    print(f"{_passed} passed, {_failed} failed (Telnyx provisioning)")
    return 1 if _failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
