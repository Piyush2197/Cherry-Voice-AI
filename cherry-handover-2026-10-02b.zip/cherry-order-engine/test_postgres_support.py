#!/usr/bin/env python3
"""Checks for the production Postgres connector and recovery guardrails."""

from __future__ import annotations

import os
import tempfile
import traceback
from pathlib import Path

import production_db as pdb
from order_store import OrderStore, _postgres_sql


HERE = Path(__file__).resolve().parent
_passed = _failed = 0


def check(name, condition, detail=""):
    global _passed, _failed
    if condition:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


def t_sql_adapter_and_open_selection() -> None:
    sql = _postgres_sql("SELECT * FROM restaurant WHERE id=? AND active=TRUE")
    check("qmark parameters become Postgres parameters", "%s" in sql and "?" not in sql)
    store = OrderStore.open(":memory:")
    check("open keeps local development on SQLite",
          store.conn.execute("SELECT 1 AS n").fetchone()["n"] == 1)
    store.close()
    try:
        OrderStore.postgres("not-a-postgres-url")
        check("invalid Postgres targets are rejected before connecting", False)
    except ValueError:
        check("invalid Postgres targets are rejected before connecting", True)


def t_schema_is_repeatable_and_has_recovery_invariants() -> None:
    schema = (HERE / "db" / "schema.sql").read_text()
    check("production tables use repeatable bootstrap",
          "CREATE TABLE restaurant (" not in schema and
          schema.count("CREATE TABLE IF NOT EXISTS") == 26)
    check("immutable order trigger is safely recreated",
          'DROP TRIGGER IF EXISTS order_immutable ON "order"' in schema)
    check("production dependency set is explicit",
          "psycopg-pool" in (HERE / "requirements-postgres.txt").read_text())


def t_credentials_and_restore_target_are_guarded() -> None:
    previous = os.environ.pop("CHERRY_TEST_MISSING_DSN", None)
    try:
        try:
            pdb.dsn_from_env("CHERRY_TEST_MISSING_DSN")
            check("missing DSN fails closed", False)
        except RuntimeError:
            check("missing DSN fails closed", True)
    finally:
        if previous is not None:
            os.environ["CHERRY_TEST_MISSING_DSN"] = previous
    check("database name is parsed without exposing credentials",
          pdb.database_name("postgresql://user:secret@host/cherry_restore") ==
          "cherry_restore")
    pg_env = pdb.pg_environment(
        "postgresql://user:secret@db.example/cherry_restore?sslmode=require")
    check("backup credentials stay out of process arguments",
          pg_env["PGPASSWORD"] == "secret" and
          pg_env["PGDATABASE"] == "cherry_restore" and
          pg_env["PGSSLMODE"] == "require")
    with tempfile.TemporaryDirectory() as td:
        archive = Path(td) / "backup.dump"
        archive.write_bytes(b"test")
        for target, confirmed in (("postgresql://host/cherry", True),
                                  ("postgresql://host/cherry_restore", False)):
            try:
                pdb.restore_drill(archive, target, confirmed=confirmed)
                check("unsafe restore target is rejected", False)
            except RuntimeError:
                check("unsafe restore target is rejected", True)


def t_optional_real_postgres_contract() -> None:
    dsn = os.getenv("CHERRY_TEST_POSTGRES_URL")
    if not dsn:
        check("real Postgres contract is opt-in", True)
        return
    store = OrderStore.postgres(dsn, bootstrap=True, min_size=1, max_size=3)
    try:
        report = pdb.verify_store(store)
        check("real Postgres schema verifies", report["ok"], str(report))
        store.upsert_restaurant("postgres-contract", "Postgres Contract", "test",
                                active=False)
        row = store.restaurant("postgres-contract")
        check("real Postgres repository round trip", row["name"] == "Postgres Contract")
    finally:
        store.close()


def main() -> int:
    for name, fn in sorted(globals().items()):
        if not name.startswith("t_"):
            continue
        try:
            fn()
        except Exception:
            global _failed
            _failed += 1
            print(f"\n--- FAIL {name}\n{traceback.format_exc()}")
    print(f"\n{_passed} passed, {_failed} failed (Postgres + recovery)")
    return 1 if _failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
