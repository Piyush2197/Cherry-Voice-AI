"""Common food, number and politeness words in the languages Detroit-area
restaurants hear every day, mapped to the English the menus are written in.

WHAT THIS IS FOR
----------------
The matcher compares what a caller said with English menu names. A caller who
says "quiero dos tacos sin cebolla" or "ek chicken tikka, bina mirch" gets
"sorry, we don't have that", even though every dish is on the menu. The voice
model may translate for us — and should be allowed to — but the engine must not
depend on it: models paraphrase, retry, or pass the words through untouched.

HOW IT STAYS SAFE
-----------------
* It only ever ADDS a second attempt. The caller's own words are always tried
  first, and the translation is used only if it matches clearly better, so a
  dish named exactly as the caller said it (queso fundido, carne asada, murgh
  makhani if the menu says so) is never rewritten.
* A word that is also an English word (Hindi "do" = two, Spanish "con" = with)
  is translated only when a DISTINCTIVE word of the same language is in the
  same utterance. "Do you have naan?" is never read as "2 you have naan".
* Dish words that menus already use as they are (naan, paneer, dal, saag,
  shawarma, falafel, tikka...) are deliberately NOT in the lists.
* Only words the author is sure of are included. Adding a language is adding a
  dict; a wrong word here is a wrong dish on a ticket.
"""

from __future__ import annotations

import re
import unicodedata
from typing import Dict, FrozenSet, Optional, Tuple

# Each language: DISTINCT words are unambiguous evidence the speaker is using it
# and are always translated; AMBIGUOUS words also look like English (or another
# language) and are translated only alongside distinctive evidence.
_LANG: Dict[str, Dict[str, Dict[str, str]]] = {
    "es": {
        "distinct": {
            # numbers
            "uno": "1", "una": "1", "dos": "2", "tres": "3", "cuatro": "4", "cinco": "5",
            "seis": "6", "siete": "7", "ocho": "8", "nueve": "9", "diez": "10", "doce": "12",
            "docena": "12",
            # asking
            "quiero": "i want", "quisiera": "i would like", "queria": "i wanted",
            "deme": "give me", "dame": "give me", "ponme": "give me", "ordenar": "order",
            "pedir": "order", "hola": "hello", "gracias": "thanks", "si": "yes",
            # modifiers
            "sin": "no", "mas": "extra", "poco": "little", "mucho": "lots",
            "picante": "spicy", "grande": "large", "chico": "small", "pequeno": "small",
            "mediano": "medium",
            # food
            "pollo": "chicken", "res": "beef", "cerdo": "pork", "puerco": "pork",
            "camaron": "shrimp", "camarones": "shrimp", "pescado": "fish", "queso": "cheese",
            "frijoles": "beans", "arroz": "rice", "cebolla": "onion", "tomate": "tomato",
            "lechuga": "lettuce", "aguacate": "avocado", "huevo": "egg", "huevos": "eggs",
            "papas": "potatoes", "tortilla": "tortilla", "refresco": "soda", "agua": "water",
            "jugo": "juice", "cerveza": "beer", "cafe": "coffee", "leche": "milk",
            "hielo": "ice", "carne": "meat", "tocino": "bacon", "jamon": "ham",
            "salchicha": "sausage", "pepinillos": "pickles", "mostaza": "mustard",
            "mayonesa": "mayo", "mantequilla": "butter", "champinones": "mushrooms",
            "hongos": "mushrooms", "pavo": "turkey", "cordero": "lamb", "pimiento": "pepper",
            "doble": "double", "sencillo": "single",
        },
        "ambiguous": {"con": "with", "y": "and", "pan": "bread"},
        "phrases": {
            "media docena": "6", "para llevar": "to go", "para recoger": "pickup",
            "por favor": "please", "papas fritas": "fries", "sin picante": "mild",
            "muy picante": "extra hot", "me gustaria": "i would like", "carne de res": "beef",
            "con todo": "everything", "buenos dias": "good morning", "buenas tardes": "good afternoon",
            "buenas noches": "good evening",
        },
    },
    "ar": {   # Arabic as it is usually written in Latin letters
        "distinct": {
            "wahid": "1", "wahed": "1", "ithnain": "2", "itnain": "2", "ithnan": "2",
            "thalatha": "3", "talata": "3", "arbaa": "4", "arba3a": "4", "khamsa": "5",
            "sitta": "6", "sabaa": "7", "sab3a": "7", "thamania": "8", "tamanya": "8",
            "tisaa": "9", "tis3a": "9", "ashara": "10",
            "bidun": "no", "bedoon": "no", "shukran": "thanks", "fadlak": "please",
            "naam": "yes", "aywa": "yes",
            "dajaj": "chicken", "lahm": "meat", "lahme": "meat", "samak": "fish",
            "ruz": "rice", "khubz": "bread", "khobz": "bread", "batata": "potato",
            "jibneh": "cheese", "jibne": "cheese", "basal": "onion", "tamatem": "tomato",
            "qahwa": "coffee", "shay": "tea", "asir": "juice", "kabir": "large", "saghir": "small",
        },
        "ambiguous": {"ma": "with", "wa": "and"},
        "phrases": {"min fadlak": "please", "law samaht": "please", "maa shukran": "no thanks"},
    },
    "hi": {   # Hindi / Urdu as it is usually written in Latin letters
        "distinct": {
            "ek": "1", "paanch": "5", "panch": "5", "chhe": "6", "cheh": "6", "aath": "8",
            "bina": "no", "bagair": "no", "aur": "and", "thoda": "little", "zyada": "extra",
            "teekha": "spicy", "tikha": "spicy", "mirchi": "chili", "kripya": "please",
            "dhanyavad": "thanks", "shukriya": "thanks", "haan": "yes", "nahi": "no",
            "nahin": "no", "murgh": "chicken", "murg": "chicken", "murgi": "chicken",
            "gosht": "lamb", "machhli": "fish", "machli": "fish", "jhinga": "shrimp",
            "pyaaz": "onion", "pyaz": "onion", "lehsun": "garlic", "adrak": "ginger",
            "chawal": "rice", "dahi": "yogurt", "paani": "water", "doodh": "milk",
            "chini": "sugar", "makhani": "butter",
        },
        # "do" (2), "teen" (3), "char" (4), "saat" (7), "nau" (9), "das" (10), "kam"
        # (less) are all words other languages use: only alongside distinctive Hindi.
        "ambiguous": {"do": "2", "teen": "3", "char": "4", "saat": "7", "nau": "9",
                      "das": "10", "kam": "less"},
        "phrases": {"ke saath": "with", "bina mirch": "mild", "thoda kam": "less",
                    "ek aur": "one more"},
    },
}

_WORD = re.compile(r"[a-z0-9]+")
#: Every word that is distinctive of some language: a cheap test that lets
#: ordinary English skip the whole thing.
_DISTINCT_ANY: FrozenSet[str] = frozenset(
    w for spec in _LANG.values() for w in spec["distinct"])
_PHRASE_FIRST: FrozenSet[str] = frozenset(
    p.split()[0] for spec in _LANG.values() for p in spec["phrases"])


def _fold(text: str) -> str:
    """Lower-case, strip accents ('camarón' -> 'camaron'), keep letters/digits."""
    t = unicodedata.normalize("NFKD", (text or "").lower())
    t = "".join(c for c in t if not unicodedata.combining(c))
    return t.replace("’", "'").replace("'", "")


def detect(text: str) -> Optional[str]:
    """The language whose distinctive words appear in the text, or None."""
    toks = _WORD.findall(_fold(text))
    if not toks or not (_DISTINCT_ANY.intersection(toks) or _PHRASE_FIRST.intersection(toks)):
        return None
    best, best_n = None, 0
    for lang, spec in _LANG.items():
        n = sum(1 for t in toks if t in spec["distinct"])
        joined = " ".join(toks)
        n += sum(1 for p in spec["phrases"] if p in joined)
        if n > best_n:
            best, best_n = lang, n
    return best


def to_english(text: str) -> Tuple[str, Optional[str]]:
    """(english, language). The text unchanged and None when there is nothing
    to translate — the caller then keeps using its own words."""
    lang = detect(text)
    if lang is None:
        return text, None
    spec = _LANG[lang]
    t = " " + " ".join(_WORD.findall(_fold(text))) + " "
    for phrase, english in sorted(spec["phrases"].items(), key=lambda kv: -len(kv[0])):
        t = t.replace(f" {phrase} ", f" {english} ")
    out = []
    for tok in t.split():
        out.append(spec["distinct"].get(tok) or spec["ambiguous"].get(tok) or tok)
    result = " ".join(out)
    return (result, lang) if result != " ".join(_WORD.findall(_fold(text))) else (text, None)


def numbers_to_english(text: str) -> str:
    """'dos tacos' -> '2 tacos'; 'media docena' -> '6'. Only the number words:
    quantities must be right even when the dish matched on the caller's own
    words (so 'dos tacos al pastor' is not one taco)."""
    lang = detect(text)
    if lang is None:
        return text
    spec = _LANG[lang]
    t = " " + " ".join(_WORD.findall(_fold(text))) + " "
    for phrase, english in spec["phrases"].items():
        if english.isdigit():
            t = t.replace(f" {phrase} ", f" {english} ")
    out = []
    for tok in t.split():
        mapped = spec["distinct"].get(tok) or spec["ambiguous"].get(tok)
        out.append(mapped if mapped and mapped.isdigit() else tok)
    return " ".join(out)
