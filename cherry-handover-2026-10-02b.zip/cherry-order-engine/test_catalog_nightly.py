#!/usr/bin/env python3
from pathlib import Path
import menu_schema as ms
from order_store import OrderStore
import catalog_nightly

HERE=Path(__file__).resolve().parent
def main():
    s=OrderStore.sqlite();p=HERE/"menus"/"tamago-sushi-bowl.yaml";c=ms.load_yaml(p)
    s.upsert_restaurant(c.id,c.name,c.cuisine,active=True);s.publish_menu(c.id,p.read_text(),item_count=len(c.items))
    item=c.item("tg_edamame")
    pos=[{"catalog_object_id":"new-ref","item_id":"item","name":item.name,
          "variation_name":"","price_cents":item.base_price_cents+100,
          "currency":"USD","category_id":"c","available":True}]
    # A partial fixture intentionally generates removal reviews, but the safe
    # price change must still publish atomically.
    report=catalog_nightly.sync_one(s,c.id,pos)
    updated,_=s.load_live_config(c.id)
    assert report["prices_applied"]==1
    assert updated.item("tg_edamame").base_price_cents==item.base_price_cents+100
    assert report["review"] and s.events("catalog.review_required",restaurant_id=c.id)
    print("3 passed, 0 failed (nightly catalog sync)");return 0
if __name__=="__main__":raise SystemExit(main())
