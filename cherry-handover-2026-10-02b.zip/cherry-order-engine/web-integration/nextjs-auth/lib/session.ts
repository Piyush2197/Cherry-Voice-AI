/**
 * Session tokens: the one place that signs and verifies them.
 *
 * Only `jose` is imported, so this file runs in Next's Edge runtime too —
 * `middleware.ts` verifies the signature with it instead of just checking that
 * a cookie exists. There is deliberately NO built-in secret: if JWT_SECRET is
 * missing or short, nothing can be signed and nothing verifies (fail closed).
 */
import { SignJWT, jwtVerify } from 'jose'

export const SESSION_COOKIE = 'cherry_token'
export const ISSUER = 'cherry-dashboard'
export const AUDIENCE = 'cherry-dashboard'
export const SESSION_HOURS = 12

export interface User {
  username: string
  role: 'admin' | 'viewer'
}

/** The signing key, or null when JWT_SECRET is missing or too short to trust. */
export function sessionSecret(): Uint8Array | null {
  const secret = process.env.JWT_SECRET || ''
  if (secret.length < 32) return null
  return new TextEncoder().encode(secret)
}

export async function signSession(user: User): Promise<string> {
  const key = sessionSecret()
  if (!key) throw new Error('JWT_SECRET is not set (at least 32 characters)')
  return new SignJWT({ username: user.username, role: user.role })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setIssuer(ISSUER)
    .setAudience(AUDIENCE)
    .setExpirationTime(`${SESSION_HOURS}h`)
    .sign(key)
}

/** The user a token proves, or null for anything forged, expired or malformed. */
export async function verifySession(token: string): Promise<User | null> {
  const key = sessionSecret()
  if (!key || !token) return null
  try {
    const { payload } = await jwtVerify(token, key, {
      algorithms: ['HS256'],
      issuer: ISSUER,
      audience: AUDIENCE,
    })
    if (typeof payload.username !== 'string' || !payload.username) return null
    if (payload.role !== 'admin' && payload.role !== 'viewer') return null
    return { username: payload.username, role: payload.role }
  } catch {
    return null
  }
}
