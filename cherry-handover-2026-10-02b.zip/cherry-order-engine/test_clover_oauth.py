#!/usr/bin/env python3
"""Clover OAuth, held to Clover's own documentation.

Every request shape asserted here comes from docs.clover.com (see the module
docstring of clover_oauth.py): a JSON token exchange with no grant_type or
redirect_uri, a refresh with no client secret, Unix-second expiries, a
30-minute access token, a single-use refresh token, and the merchant id on the
redirect rather than in the token reply.
"""

from __future__ import annotations

import io
import json
import os
import tempfile
import threading
import time
import urllib.error
import urllib.parse
from datetime import datetime, timedelta, timezone

import clover_oauth as co
from clover_oauth import CloverAuthError, CloverOAuthClient
from vault import FileVault

SECRET = "state-secret-0123456789"
NOW = datetime.now(timezone.utc).replace(microsecond=0)      # the fake Clover also uses the real clock


class Response:
    status = 200

    def __init__(self, body):
        self.body = body

    def __enter__(self):
        return self

    def __exit__(self, *_):
        return False

    def read(self):
        return self.body if isinstance(self.body, bytes) else json.dumps(self.body).encode()


def reply(n=1, *, access_in=1800, refresh_in=86400 * 365):
    """What Clover sends: Unix-second expiries, a rotating pair."""
    t = int(time.time())
    return {"access_token": f"acc-{n}", "access_token_expiration": t + access_in,
            "refresh_token": f"ref-{n}", "refresh_token_expiration": t + refresh_in}


class Clover:
    """A fake Clover that records every request and enforces single-use refresh."""

    def __init__(self, delay=0.0, fail=None):
        self.calls, self.n, self.spent, self.delay, self.fail = [], 0, set(), delay, fail
        self.lock = threading.Lock()

    def __call__(self, request, timeout):
        body = json.loads(request.data.decode())
        with self.lock:
            self.calls.append({"url": request.full_url, "method": request.get_method(),
                               "type": request.get_header("Content-type"), "body": body})
        if self.fail:
            raise self.fail
        time.sleep(self.delay)
        with self.lock:
            if request.full_url.endswith("/refresh"):
                if body.get("refresh_token") in self.spent:
                    raise urllib.error.HTTPError(request.full_url, 401, "bad", {},
                                                 io.BytesIO(b'{"message":"refresh token already used"}'))
                self.spent.add(body["refresh_token"])          # single use, as documented
            self.n += 1
            return Response(reply(self.n))


def client(opener=None, sandbox=True):
    return CloverOAuthClient("app", "app-secret", sandbox=sandbox, opener=opener or Clover())


def vault():
    return FileVault(tempfile.mkdtemp() + "/v")


def authorized(v, rid="bun-n-run-ferndale", *, access_in=1800, refresh_in=86400 * 365, merchant="MERCH123"):
    """A restaurant whose refresh token is ``ref-<rid>``."""
    names = co.secret_names(rid)
    v.put(names["access"], "acc-old")
    v.put(names["refresh"], f"ref-{rid}")
    v.put(names["merchant"], merchant)
    v.put(names["expires"], (NOW + timedelta(seconds=access_in)).isoformat())
    v.put(names["refresh_expires"], (NOW + timedelta(seconds=refresh_in)).isoformat())
    return names


# --- the wire format, as documented -------------------------------------------

def t_the_code_exchange_is_a_json_post_with_exactly_the_documented_fields():
    c = Clover()
    pair = client(c).exchange_code("THE-CODE")
    call = c.calls[0]
    assert call["url"] == "https://apisandbox.dev.clover.com/oauth/v2/token" and call["method"] == "POST"
    assert call["type"] == "application/json"
    assert call["body"] == {"client_id": "app", "client_secret": "app-secret", "code": "THE-CODE"}, call["body"]
    assert pair["access_token"] == "acc-1" and pair["refresh_token"] == "ref-1"
    assert pair["access_expires_at"].tzinfo is not None
    assert 1700 < (pair["access_expires_at"] - datetime.now(timezone.utc)).total_seconds() <= 1800
    prod = CloverOAuthClient("app", "s", opener=c)
    prod.exchange_code("x")
    assert c.calls[-1]["url"] == "https://api.clover.com/oauth/v2/token"


def t_the_refresh_has_no_client_secret_and_goes_to_the_refresh_endpoint():
    c = Clover()
    client(c).refresh_token("ref-0")
    call = c.calls[0]
    assert call["url"] == "https://apisandbox.dev.clover.com/oauth/v2/refresh"
    assert call["body"] == {"client_id": "app", "refresh_token": "ref-0"}, call["body"]
    prod = CloverOAuthClient("app", "s", opener=c)
    prod.refresh_token("ref-1")
    assert c.calls[-1]["url"] == "https://api.clover.com/oauth/v2/refresh"


def t_half_a_reply_is_refused_not_stored():
    for broken in ({}, {"access_token": "a"},
                   {"access_token": "a", "refresh_token": "r"},
                   {"access_token": "a", "refresh_token": "r", "access_token_expiration": "soon",
                    "refresh_token_expiration": 1},
                   {"access_token": "a", "refresh_token": "r", "access_token_expiration": True,
                    "refresh_token_expiration": 1},
                   {"access_token": "a", "access_token_expiration": 1, "refresh_token_expiration": 1},
                   {"access_token": "", "refresh_token": "r", "access_token_expiration": 1,
                    "refresh_token_expiration": 1}):
        c = client(lambda *_a, _b=broken, **_k: Response(_b))
        try:
            c.exchange_code("x")
        except CloverAuthError:
            continue
        raise AssertionError(f"accepted {broken}")
    for bad_body in (b"<html>", b"[]", b"null"):
        try:
            client(lambda *_a, _b=bad_body, **_k: Response(_b)).exchange_code("x")
        except CloverAuthError:
            continue
        raise AssertionError(f"accepted {bad_body!r}")


def t_failures_are_named_without_leaking_the_secret():
    def http(*_a, **_k):
        raise urllib.error.HTTPError("u", 401, "bad", {}, io.BytesIO(b'{"error":"bad app-secret"}'))
    try:
        client(http).exchange_code("x")
    except CloverAuthError as exc:
        assert "401" in str(exc) and "app-secret" not in str(exc), str(exc)
    else:
        raise AssertionError("no error")
    import socket
    for exc_ in (socket.timeout("slow"), urllib.error.URLError("down"), ConnectionResetError("rst")):
        try:
            client(Clover(fail=exc_)).refresh_token("r")
        except CloverAuthError as exc:
            assert "unavailable" in str(exc)
        else:
            raise AssertionError(f"{exc_!r} escaped")
    for cid, sec in (("", "s"), ("c", "")):
        try:
            CloverOAuthClient(cid, sec)
        except ValueError:
            continue
        raise AssertionError("missing credentials accepted")


def t_the_authorize_link_asks_only_what_clover_documents():
    url = co.authorize_url("app", SECRET, "bun-n-run-ferndale", "https://x.example/v1/oauth/clover/callback", sandbox=True)
    parsed = urllib.parse.urlparse(url)
    q = urllib.parse.parse_qs(parsed.query)
    assert f"{parsed.scheme}://{parsed.netloc}{parsed.path}" == "https://sandbox.dev.clover.com/oauth/v2/authorize"
    assert set(q) == {"client_id", "redirect_uri", "state"}, set(q)          # no scope, no response_type
    assert co.verify_state(SECRET, q["state"][0]) == "bun-n-run-ferndale"
    assert co.authorize_url("a", SECRET, "r", "https://x", sandbox=False).startswith("https://www.clover.com/oauth/v2/authorize?")


# --- authorization: the merchant arrives on the redirect ------------------------

def t_authorization_stores_the_pair_the_expiries_and_the_merchant_from_the_redirect():
    v, c = vault(), Clover()
    state = co.sign_state(SECRET, "bun-n-run-ferndale")
    out = co.complete_authorization(client(c), v, SECRET, state=state, code="C", merchant_id="MERCH123")
    n = co.secret_names("bun-n-run-ferndale")
    assert out["merchant_id"] == "MERCH123" and "acc-" not in json.dumps(out)
    assert v.get(n["access"]) == "acc-1" and v.get(n["refresh"]) == "ref-1" and v.get(n["merchant"]) == "MERCH123"
    assert co._parse_expiry(v.get(n["expires"])) and co._parse_expiry(v.get(n["refresh_expires"]))
    assert co.token_status(v, "bun-n-run-ferndale")["state"] == "ok"
    assert "redirect_uri" not in c.calls[0]["body"] and "grant_type" not in c.calls[0]["body"]


def t_a_missing_or_malformed_merchant_id_stops_before_the_code_is_spent():
    for bad in ("", None, "a b", "x" * 40, "../../etc", "M;DROP"):
        v, c = vault(), Clover()
        try:
            co.complete_authorization(client(c), v, SECRET, state=co.sign_state(SECRET, "r1"),
                                      code="C", merchant_id=bad)
        except CloverAuthError:
            assert c.calls == [] and v.names() == [], bad
            continue
        raise AssertionError(f"accepted merchant id {bad!r}")


def t_forged_expired_and_replayed_links_write_nothing():
    v, c = vault(), Clover()
    for state in ("forged.x", "", co.sign_state(SECRET, "r1", now=time.time() - co.STATE_TTL_SECONDS - 10),
                  co.sign_state("a-different-secret-0000", "r1")):
        try:
            co.complete_authorization(client(c), v, SECRET, state=state, code="C", merchant_id="M1")
        except CloverAuthError:
            continue
        raise AssertionError("bad state accepted")
    assert c.calls == [] and v.names() == []

    class Store:
        def __init__(self):
            self.claims, self.events = set(), []

        def claim_webhook(self, kind, key, rid):
            if key in self.claims:
                return False
            self.claims.add(key)
            return True

        def release_webhook(self, kind, key):
            self.claims.discard(key)

        def log_event(self, kind, **kw):
            self.events.append(kind)

    store, state = Store(), co.sign_state(SECRET, "r1")
    co.complete_authorization(client(c), v, SECRET, state=state, code="C", merchant_id="M1", store=store)
    try:
        co.complete_authorization(client(c), v, SECRET, state=state, code="C", merchant_id="M1", store=store)
    except CloverAuthError as exc:
        assert "already used" in str(exc)
    else:
        raise AssertionError("replay accepted")
    assert store.events == ["clover.oauth_authorized"]
    # a failed exchange releases the claim so the owner can retry the same link
    s2 = co.sign_state(SECRET, "r2")
    try:
        co.complete_authorization(client(Clover(fail=urllib.error.URLError("down"))), vault(), SECRET,
                                  state=s2, code="C", merchant_id="M2", store=store)
    except CloverAuthError:
        pass
    co.complete_authorization(client(Clover()), vault(), SECRET, state=s2, code="C", merchant_id="M2", store=store)


def t_a_restaurant_cannot_be_silently_moved_to_another_clover_account():
    v = vault()
    authorized(v, "r1", merchant="OLDMERCH")
    c = Clover()
    try:
        co.complete_authorization(client(c), v, SECRET, state=co.sign_state(SECRET, "r1"),
                                  code="C", merchant_id="NEWMERCH")
    except CloverAuthError as exc:
        assert "different Clover account" in str(exc)
    else:
        raise AssertionError("rebound without --rebind")
    assert c.calls == [], "the code must not be spent"
    assert v.get(co.secret_names("r1")["merchant"]) == "OLDMERCH"
    co.complete_authorization(client(c), v, SECRET, state=co.sign_state(SECRET, "r1", rebind=True),
                              code="C", merchant_id="NEWMERCH")
    assert v.get(co.secret_names("r1")["merchant"]) == "NEWMERCH"


# --- using the token: 30 minutes, single-use refresh ----------------------------

def t_a_fresh_token_is_returned_without_calling_clover():
    v, c = vault(), Clover()
    authorized(v)
    assert co.access_token(client(c), v, "bun-n-run-ferndale", now=NOW) == "acc-old"
    assert c.calls == []


def t_a_stale_token_is_refreshed_once_and_the_new_pair_is_saved_refresh_first():
    v, c = vault(), Clover()
    names = authorized(v, access_in=120)          # inside the 5-minute margin
    writes = []
    real_put = v.put
    v.put = lambda name, value: (writes.append(name), real_put(name, value))[1]
    assert co.access_token(client(c), v, "bun-n-run-ferndale", now=NOW) == "acc-1"
    assert [x["url"].rsplit("/", 1)[1] for x in c.calls] == ["refresh"]
    assert c.calls[0]["body"]["refresh_token"] == "ref-bun-n-run-ferndale"
    assert writes.index(names["refresh"]) < writes.index(names["access"]), writes
    assert v.get(names["refresh"]) == "ref-1"


def t_eight_callers_at_once_spend_the_single_use_refresh_token_exactly_once():
    v = vault()
    authorized(v, access_in=60)
    c = Clover(delay=0.15)
    cl = client(c)
    got, errors = [], []

    def go():
        try:
            got.append(co.access_token(cl, v, "bun-n-run-ferndale", now=NOW))
        except Exception as exc:                          # noqa: BLE001
            errors.append(exc)

    threads = [threading.Thread(target=go) for _ in range(8)]
    [t.start() for t in threads]
    [t.join() for t in threads]
    assert not errors, errors
    assert len([x for x in c.calls if x["url"].endswith("/refresh")]) == 1, c.calls
    assert set(got) == {"acc-1"}, got


def t_the_lock_also_holds_across_processes_sharing_a_vault_directory():
    import fcntl
    v = vault()
    authorized(v, access_in=60)
    lock_file = v.directory / ".locks" / "clover-BUN_N_RUN_FERNDALE"
    with co._refresh_lock(v, "bun-n-run-ferndale"):
        assert lock_file.exists()
        fd = open(lock_file, "a")
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            blocked = True
        else:
            blocked = False
        finally:
            fd.close()
    assert blocked, "another process could have taken the lock mid-refresh"
    assert all(not n.startswith(".") for n in v.names()) and "clover-BUN_N_RUN_FERNDALE" not in v.names()


def t_a_dead_authorization_is_reported_not_retried():
    v, c = vault(), Clover()
    for rid, kw, needle in (("never", None, "not authorized"),
                            ("old", {"refresh_in": -3600}, "approve Cherry again")):
        if kw is not None:
            authorized(v, rid, access_in=-60, **kw)
        try:
            co.access_token(client(c), v, rid, now=NOW)
        except CloverAuthError as exc:
            assert needle in str(exc), str(exc)
        else:
            raise AssertionError(rid)
    assert c.calls == []


def t_a_refresh_clover_rejects_leaves_the_old_pair_in_place_and_says_so():
    v = vault()
    names = authorized(v, access_in=60)
    c = Clover()
    c.spent = {"ref-bun-n-run-ferndale"}              # Clover already spent this one
    events = []

    class Store:
        def log_event(self, kind, **kw):
            events.append(kind)

    try:
        co.access_token(client(c), v, "bun-n-run-ferndale", now=NOW, store=Store())
    except CloverAuthError as exc:
        assert "401" in str(exc)
    else:
        raise AssertionError("no error")
    assert v.get(names["refresh"]) == "ref-bun-n-run-ferndale" and v.get(names["access"]) == "acc-old"
    assert events == ["clover.oauth_refresh_failed"]


def t_losing_the_new_refresh_token_is_loud_and_never_half_saved():
    v = vault()
    names = authorized(v, access_in=60)

    class Disk(FileVault):
        def put(self, name, value):
            if name == names["refresh"]:
                raise OSError("disk full")
            super().put(name, value)

    d = Disk(v.directory)
    try:
        co.access_token(client(Clover()), d, "bun-n-run-ferndale", now=NOW)
    except CloverAuthError as exc:
        assert "approve Cherry again" in str(exc)
    else:
        raise AssertionError("a lost refresh token went unreported")
    assert d.get(names["access"]) == "acc-old", "the access token must not be replaced without its refresh token"


# --- state and the scheduled job ------------------------------------------------

def t_status_states():
    v = vault()
    assert co.token_status(v, "none", now=NOW)["state"] == "not_authorized"
    authorized(v, "ok1")
    assert co.token_status(v, "ok1", now=NOW)["state"] == "ok"
    authorized(v, "stale", access_in=-5)
    assert co.token_status(v, "stale", now=NOW)["state"] == "stale_access"      # normal: renewed on use
    authorized(v, "due", refresh_in=86400 * 30)
    assert co.token_status(v, "due", now=NOW)["state"] == "due"
    authorized(v, "dead", refresh_in=-1)
    assert co.token_status(v, "dead", now=NOW)["state"] == "expired"
    authorized(v, "odd")
    v.put(co.secret_names("odd")["expires"], "garbage")
    assert co.token_status(v, "odd", now=NOW)["state"] == "unknown_expiry"
    s = co.token_status(v, "due", now=NOW)
    assert s["refresh_days_left"] == 30.0


def t_the_job_rotates_only_refresh_tokens_near_their_end():
    v, c = vault(), Clover()
    authorized(v, "ok1")
    authorized(v, "stale", access_in=-5)
    authorized(v, "due", refresh_in=86400 * 30)
    authorized(v, "dead", refresh_in=-1)
    out = co.refresh_due(client(c), v, ["ok1", "stale", "due", "dead", "never"], now=NOW)
    assert out["refreshed"] == 1 and out["failed"] == 0, out
    assert out["not_authorized"] == ["never"] and out["reauthorize"] == ["dead"] and out["skipped_ok"] == 2, out
    assert len(c.calls) == 1, "a stale access token must not spend the single-use refresh token"
    assert v.get(co.secret_names("due")["refresh"]) == "ref-1"
    assert v.get(co.secret_names("ok1")["refresh"]) == "ref-ok1"
    out = co.refresh_due(client(c), v, ["ok1"], now=NOW, force=True)
    assert out["refreshed"] == 1


def t_cli_exit_codes_make_the_scheduler_alert():
    d = tempfile.mkdtemp() + "/v"
    os.environ.update(CHERRY_SECRET_DIR=d, CLOVER_CLIENT_ID="a", CLOVER_CLIENT_SECRET="b")
    try:
        assert co.main(["status", "--restaurant", "never"]) == 3
        assert co.main(["refresh", "--restaurant", "never"]) == 3
        v = FileVault(d)
        n = co.secret_names("fine")
        real = datetime.now(timezone.utc)
        for k, val in ((n["access"], "a"), (n["refresh"], "r"),
                       (n["expires"], (real + timedelta(minutes=20)).isoformat()),
                       (n["refresh_expires"], (real + timedelta(days=300)).isoformat())):
            v.put(k, val)
        assert co.main(["status", "--restaurant", "fine"]) == 0
        assert co.main(["refresh", "--restaurant", "fine"]) == 0
        assert co.main(["--sandbox", "status", "--restaurant", "fine"]) == 0
    finally:
        for k in ("CHERRY_SECRET_DIR", "CLOVER_CLIENT_ID", "CLOVER_CLIENT_SECRET"):
            os.environ.pop(k, None)


# --- the server callback, over a real socket -------------------------------------

def t_callback_endpoint_end_to_end():
    import test_server as ts
    d = tempfile.mkdtemp() + "/v"
    v = FileVault(d)
    os.environ.update(CHERRY_OAUTH_STATE_SECRET=SECRET, CLOVER_CLIENT_ID="app",
                      CLOVER_CLIENT_SECRET="app-secret", CHERRY_CLOVER_SANDBOX="1")
    h = ts.Harness()
    try:
        c = Clover()
        h.app.vault, h.app.oauth_opener = v, c
        state = co.sign_state(SECRET, "bun-n-run-ferndale")
        code, body = h.req("GET", f"/v1/oauth/clover/callback?code=C&merchant_id=MERCH123&state={state}", key=None)
        assert code == 200 and "connected" in str(body).lower(), (code, body)
        n = co.secret_names("bun-n-run-ferndale")
        assert v.get(n["merchant"]) == "MERCH123" and v.get(n["access"]) == "acc-1"
        assert "acc-" not in str(body) and "ref-" not in str(body)
        assert c.calls[0]["url"] == "https://apisandbox.dev.clover.com/oauth/v2/token"
        assert any(e["kind"] == "clover.oauth_authorized" for e in h.store.events())
        # the same link twice, a missing merchant, no state (Clover not echoing it), a forged
        # state, a cancelled approval, an unknown restaurant — all refused with a plain page
        code, body = h.req("GET", f"/v1/oauth/clover/callback?code=C&merchant_id=MERCH123&state={state}", key=None)
        assert code == 400 and "Traceback" not in str(body)
        fresh = co.sign_state(SECRET, "bun-n-run-ferndale")
        for q in (f"code=C&state={fresh}", "code=C&merchant_id=MERCH123",
                  "code=C&merchant_id=MERCH123&state=forged.x", ""):
            code, body = h.req("GET", f"/v1/oauth/clover/callback?{q}", key=None)
            assert code == 400 and "Traceback" not in str(body), (q, code)
        code, _ = h.req("GET", "/v1/oauth/clover/callback?error=access_denied", key=None)
        assert code == 200
        ghost = co.sign_state(SECRET, "ghost-restaurant")
        before = len(c.calls)
        code, _ = h.req("GET", f"/v1/oauth/clover/callback?code=C&merchant_id=M9&state={ghost}", key=None)
        assert code == 400 and len(c.calls) == before, "an unknown restaurant must not spend the code"
        assert not any(x.endswith("GHOST_RESTAURANT") for x in v.names())
        assert any(e["kind"] == "clover.oauth_authorization_failed" for e in h.store.events())
    finally:
        h.stop()
        for k in ("CHERRY_OAUTH_STATE_SECRET", "CLOVER_CLIENT_ID", "CLOVER_CLIENT_SECRET", "CHERRY_CLOVER_SANDBOX"):
            os.environ.pop(k, None)


TESTS = [v for k, v in sorted(globals().items()) if k.startswith("t_")]


def main() -> int:
    passed, fails = 0, []
    for fn in TESTS:
        try:
            fn()
            passed += 1
        except Exception as exc:                          # noqa: BLE001
            import traceback
            fails.append(fn.__name__)
            print(f"FAIL {fn.__name__}: {exc!r}")
            traceback.print_exc()
    print(f"{passed} passed, {len(fails)} failed (Clover OAuth, per Clover's docs)")
    return 1 if fails else 0


if __name__ == "__main__":
    raise SystemExit(main())
