# Cherry readiness for a ten-restaurant company

Updated 2026-09-21. Cherry uses one cuisine-agnostic engine and separate,
versioned restaurant menus. Forking the engine by cuisine would multiply bugs
and make identical rules disagree; cuisine behavior belongs in menu data and
tested schema primitives.

## What the repository now provides

- Complete deterministic ordering for configured menus, including ambiguity,
  required choices, defaults/removals, per-unit modifiers, exact prices/tax,
  availability, read-back and completion refusal.
- Multi-tenant location routing, roles, per-location controls, immutable menu
  versions, orders and complaint evidence.
- Inworld-facing HTTP tools, persisted calls, Telnyx transfer, manual kitchen
  tickets, Square order/payment flow and native Toast order submission.
- Signed payment webhooks, daily reconciliation, alert delivery, transcript QA,
  operator dashboard, catalog review and automated nightly catalog updates.
- Postgres pooling, backup/restore tooling, release SLO probes and audited menu
  rollback.
- Optional hours/holidays/wait-time controls, safe multilingual output,
  request-only phone reservations and delivery quotes.

## What code cannot prove

No test suite can prove a provider account is approved, a telephone number is
routed correctly, a merchant granted OAuth, a restaurant mapped the right POS
GUID, or a managed database can be restored. Those are deployment acceptance
tasks, not missing application features. Before serving ten restaurants, run
every item in `PRODUCTION_HANDOFF.md` and retain the evidence for each location.

## Competitive position

For the pickup-order scope, the framework now covers the major call-to-order
layers: voice seam, deterministic cart, POS delivery, hosted payment status,
fallback, tenant isolation, operations, menu sync and audit evidence. Products
such as Loman or Certus may still have broader production history, more turnkey
POS partnerships, richer owner UX, catering/guest-memory features and proven
support operations. Cherry should claim only capabilities that have passed the
live acceptance record for that restaurant.

Reservations, delivery and multilingual service are not automatically enabled
for the pilot. Reservations no longer require an external provider, but every
location still needs an owner-approved policy and real voice acceptance test.
Delivery requires a provider; each language requires a real-call test.
