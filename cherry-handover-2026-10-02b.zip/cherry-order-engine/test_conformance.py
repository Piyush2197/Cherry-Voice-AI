"""
Conformance suite.

Part 1 runs the SAME adversarial invariants against all eight cuisine packs.
An invariant that holds for eight very different menus is an invariant the
engine actually enforces, not one the burger menu happened to satisfy.

Part 2 is cuisine-specific: the exact pricing and flow each cuisine's real
menu shape demands.

Runs standalone (`python3 test_conformance.py`) with no dependencies, and
also works under pytest.
"""

from __future__ import annotations

import random
import traceback
from decimal import Decimal

from config_validator import assert_config_ok, lint_config
from cuisine_packs import ALL_PACKS, BURGER_TEMPLATE, INDIAN, ITALIAN, \
    JAPANESE, KOREAN, MEDITERRANEAN, MEXICAN, PIZZA
from restaurants import BUN_N_RUN, REAL_RESTAURANTS, from_toast_menu_response


def _menu(name: str):
    """Load a conformance fixture from the menus that actually get deployed.

    The four per-restaurant Python modules these names used to come from were
    deleted on 2026-09-30: five of the six were identical to their YAML across
    412 items and the sixth had already drifted. Loading the same file that
    `pilot_deploy.py` publishes means a fixture and a live menu cannot disagree.
    See REDUNDANCY_AUDIT_2026-09-30.md §2.
    """
    import menu_schema as _ms
    from pathlib import Path as _Path
    return _ms.load_yaml(_Path(__file__).parent / "menus" / f"{name}.yaml")


CHENGS = _menu("chengs-sterling-heights")
JUAN_MIGUELS = _menu("juan-miguels-clinton")
MIYAZAKI = _menu("miyazaki-hall-rd")
TAMAGO = _menu("tamago-sushi-bowl")
from order_engine import (
    normalize,
    IssueCode,
    OrderEngine,
    Placement,
    Selection,
    Severity,
    money,
)


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------


def autofill(engine: OrderEngine, max_steps: int = 60) -> None:
    """Drive the cart to a submittable state using only what the engine says.

    This is the test-harness stand-in for Lily. If it cannot converge, the
    engine has asked a question it does not accept an answer to — which on a
    live call is an infinite loop with a customer on the line.
    """
    for _ in range(max_steps):
        issues = [i for i in engine.validate() if i.blocking]
        if not issues:
            return
        issue = issues[0]
        line = engine.get_line(issue.line_id) if issue.line_id else None
        if issue.code is IssueCode.SIZE_REQUIRED and line is not None:
            engine.set_size(line.line_id, issue.candidates[0])
            continue
        if (issue.code is IssueCode.GROUP_CONFIRMATION_REQUIRED
                and line is not None):
            assert engine.confirm_group(line.line_id, issue.group_id)
            continue
        if issue.code in (IssueCode.MISSING_REQUIRED_GROUP,
                          IssueCode.TOO_FEW_SELECTED) and line is not None:
            chosen = {s.option_id for s in line.selections
                      if s.group_id == issue.group_id}
            progressed = False
            for cand in issue.candidates:
                if cand in chosen:
                    continue
                probs = engine.apply_option(line.line_id, issue.group_id, cand)
                if not probs:
                    progressed = True
                    break
            if progressed:
                continue
        raise AssertionError(
            f"autofill stuck on {issue.code.value}: {issue.message} "
            f"(q={issue.question!r})")
    raise AssertionError("autofill did not converge")


def fresh(cfg) -> OrderEngine:
    return OrderEngine(cfg)


def orderable_items(cfg):
    """Items a caller could plausibly order (skip nothing — all of them)."""
    return [i for i in cfg.items if i.available]


# ===========================================================================
# PART 1 — invariants across all eight packs
# ===========================================================================


def inv_config_is_clean(name, cfg):
    assert_config_ok(cfg)


def inv_every_item_is_reachable_by_speech(name, cfg):
    """A menu item nobody can say is a menu item nobody can order."""
    e = fresh(cfg)
    for it in cfg.items:
        cands = e.matcher.match_items(it.name)
        assert cands, f"{name}: '{it.name}' matches nothing"
        assert cands[0].target_id == it.id, (
            f"{name}: '{it.name}' resolved to '{cands[0].target_name}' "
            f"instead of itself")


def inv_every_option_is_reachable_by_speech(name, cfg):
    e = fresh(cfg)
    for op in cfg.options:
        cands = e.matcher.match_options(op.name)
        assert cands, f"{name}: option '{op.name}' matches nothing"
        assert op.id in [c.target_id for c in cands[:3]], (
            f"{name}: option '{op.name}' not in its own top-3 matches")


def inv_required_groups_produce_a_question(name, cfg):
    """Adding a bare item must never leave Lily with nothing to say."""
    for it in orderable_items(cfg):
        e = fresh(cfg)
        e.add_line(it.id)
        blocking = [i for i in e.validate() if i.blocking]
        if not blocking:
            continue
        q = e.next_question()
        assert q, (f"{name}/{it.id}: {len(blocking)} blocking issues but "
                   f"next_question() is None — dead air")
        assert q.strip(), f"{name}/{it.id}: empty question"


def inv_no_blocking_issue_without_a_question(name, cfg):
    for it in orderable_items(cfg):
        e = fresh(cfg)
        e.add_line(it.id)
        for i in e.validate():
            if i.blocking:
                assert i.question, (
                    f"{name}/{it.id}: blocking {i.code.value} has no question")


def inv_every_item_can_be_completed(name, cfg):
    """The engine must accept its own suggested answers, for every item."""
    for it in orderable_items(cfg):
        e = fresh(cfg)
        e.add_line(it.id)
        autofill(e)
        assert e.is_submittable(), f"{name}/{it.id}: not submittable after autofill"
        assert e.next_question() is None


def inv_pricing_is_deterministic(name, cfg):
    for it in orderable_items(cfg):
        e = fresh(cfg)
        e.add_line(it.id)
        autofill(e)
        a = e.price()
        b = e.price()
        assert a.subtotal_cents == b.subtotal_cents
        assert a.tax_cents == b.tax_cents
        assert a.total_cents == b.total_cents


def inv_money_is_sane(name, cfg):
    for it in orderable_items(cfg):
        e = fresh(cfg)
        e.add_line(it.id, quantity=3)
        autofill(e)
        p = e.price()
        assert p.subtotal_cents > 0, f"{name}/{it.id}: free order"
        for lp in p.lines:
            assert isinstance(lp.unit_total_cents, int)
            assert lp.line_total_cents == lp.unit_total_cents * lp.quantity
            assert lp.unit_total_cents == lp.unit_base_cents + lp.unit_modifier_cents
        expected_tax = int((Decimal(p.subtotal_cents) * cfg.tax_rate_bps
                            / Decimal(10000)).quantize(Decimal("1")))
        assert abs(p.tax_cents - expected_tax) <= 1
        assert p.total_cents == p.subtotal_cents + p.tax_cents


def inv_normalized_order_matches_price(name, cfg):
    for it in orderable_items(cfg):
        e = fresh(cfg)
        e.add_line(it.id, quantity=2)
        autofill(e)
        p = e.price()
        n = e.to_normalized_order()
        assert n["subtotal_cents"] == p.subtotal_cents
        assert n["total_cents"] == p.total_cents
        assert sum(l["line_total_cents"] for l in n["lines"]) == p.subtotal_cents
        assert n["payment_mode"] in ("pay_now", "pay_at_pickup")


def inv_single_select_replaces(name, cfg):
    for g in cfg.groups:
        if g.max_select != 1 or len(g.option_ids) < 2 or g.reveal_only:
            continue
        host = next((i for i in cfg.items if g.id in i.modifier_group_ids), None)
        if host is None:
            continue
        e = fresh(cfg)
        line = e.add_line(host.id)
        if host.has_sizes:
            e.set_size(line.line_id, host.sizes[0].id)
        a, b = g.option_ids[0], g.option_ids[1]
        e.apply_option(line.line_id, g.id, a)
        e.apply_option(line.line_id, g.id, b)
        sels = [s for s in line.selections if s.group_id == g.id]
        assert len(sels) == 1, f"{name}/{g.id}: single-select accumulated {sels}"
        assert sels[0].option_id == b


def inv_max_select_is_enforced(name, cfg):
    for g in cfg.groups:
        if g.reveal_only or g.informational:
            continue
        if len(g.option_ids) <= g.max_select:
            continue
        host = next((i for i in cfg.items if g.id in i.modifier_group_ids), None)
        if host is None:
            continue
        e = fresh(cfg)
        line = e.add_line(host.id)
        if host.has_sizes:
            e.set_size(line.line_id, host.sizes[0].id)
        # Force-push more than max directly onto the line, bypassing
        # apply_option, to prove validate() is the real backstop.
        for oid in g.option_ids[: g.max_select + 1]:
            line.selections.append(Selection(group_id=g.id, option_id=oid))
        codes = {i.code for i in e.validate_line(line)}
        assert IssueCode.TOO_MANY_SELECTED in codes, (
            f"{name}/{g.id}: over-selection not caught")


def inv_sold_out_options_are_refused(name, cfg):
    for op in cfg.options:
        if op.available:
            continue
        g = next((x for x in cfg.groups if op.id in x.option_ids), None)
        if g is None:
            continue
        host = next((i for i in cfg.items if g.id in i.modifier_group_ids), None)
        if host is None:
            continue
        e = fresh(cfg)
        line = e.add_line(host.id)
        if host.has_sizes:
            e.set_size(line.line_id, host.sizes[0].id)
        issues = e.apply_option(line.line_id, g.id, op.id)
        assert any(i.code is IssueCode.OPTION_UNAVAILABLE for i in issues), (
            f"{name}: sold-out '{op.name}' was accepted")


def inv_quantity_cap_is_enforced(name, cfg):
    for op in cfg.options:
        g = next((x for x in cfg.groups if op.id in x.option_ids), None)
        if g is None:
            continue
        host = next((i for i in cfg.items if g.id in i.modifier_group_ids), None)
        if host is None or not op.available:
            continue
        e = fresh(cfg)
        line = e.add_line(host.id)
        if host.has_sizes:
            e.set_size(line.line_id, host.sizes[0].id)
        issues = e.apply_option(line.line_id, g.id, op.id,
                               quantity=op.max_quantity + 1)
        assert any(i.code is IssueCode.QTY_EXCEEDED for i in issues), (
            f"{name}: '{op.name}' accepted qty {op.max_quantity + 1} "
            f"over cap {op.max_quantity}")


def inv_placement_requires_opt_in(name, cfg):
    for g in cfg.groups:
        if g.placement_enabled or g.reveal_only or not g.option_ids:
            continue
        host = next((i for i in cfg.items if g.id in i.modifier_group_ids), None)
        if host is None:
            continue
        oid = next((o.id for o in cfg.options_for(g) if o.available), None)
        if oid is None:
            continue
        e = fresh(cfg)
        line = e.add_line(host.id)
        if host.has_sizes:
            e.set_size(line.line_id, host.sizes[0].id)
        issues = e.apply_option(line.line_id, g.id, oid, placement=Placement.LEFT)
        assert any(i.code is IssueCode.PLACEMENT_NOT_ALLOWED for i in issues), (
            f"{name}/{g.id}: half-placement accepted on a non-placement group")


def inv_86ed_item_blocks_with_an_apology(name, cfg):
    import dataclasses
    it = orderable_items(cfg)[0]
    dead = dataclasses.replace(it, available=False)
    cfg2 = dataclasses.replace(cfg, items=tuple(
        dead if x.id == it.id else x for x in cfg.items))
    e = fresh(cfg2)
    e.add_line(it.id)
    issues = e.validate()
    assert any(i.code is IssueCode.ITEM_UNAVAILABLE for i in issues)
    assert e.next_question()
    assert not e.is_submittable()


def inv_empty_cart_asks_a_question(name, cfg):
    e = fresh(cfg)
    assert not e.is_submittable()
    assert e.next_question()


def inv_read_back_never_crashes_and_names_the_item(name, cfg):
    for it in orderable_items(cfg):
        e = fresh(cfg)
        e.add_line(it.id)
        autofill(e)
        text = e.read_back()
        assert it.name.lower().split("(")[0].strip() in text.lower(), (
            f"{name}/{it.id}: read-back omits the item name: {text}")
        assert "$" in text


def inv_informational_groups_are_never_asked_and_never_charged(name, cfg):
    info = [g for g in cfg.groups if g.informational]
    for g in info:
        host = next((i for i in cfg.items if g.id in i.modifier_group_ids), None)
        if host is None:
            continue
        e = fresh(cfg)
        line = e.add_line(host.id)
        autofill(e)
        for i in e.validate():
            assert i.group_id != g.id, f"{name}: informational group asked about"
        lp = e.price_line(line)
        names = {n for n, _ in lp.charged_modifiers}
        for o in cfg.options_for(g):
            assert o.name not in names, f"{name}: charged for included {o.name}"
        # but it must still reach the ticket
        n = e.to_normalized_order()
        mod_groups = {m["group_id"] for m in n["lines"][0]["modifiers"]}
        assert g.id in mod_groups, f"{name}: included items missing from ticket"


def inv_negated_default_actually_leaves_the_ticket(name, cfg):
    """'No onion' must remove onion from the KITCHEN TICKET, not just from
    what Lily reads back.

    Caught by mutation testing: the original read-back-only assertion passed
    even when the negated topping was still being sent to the POS, which is
    the single worst failure this engine can have — the customer is told one
    thing and the kitchen makes another.
    """
    for g in cfg.groups:
        if not g.default_option_ids or not g.allow_negate_defaults:
            continue
        host = next((i for i in cfg.items if g.id in i.modifier_group_ids), None)
        if host is None:
            continue
        target = g.default_option_ids[0]
        e = fresh(cfg)
        line = e.add_line(host.id)
        if host.has_sizes:
            e.set_size(line.line_id, host.sizes[0].id)
        assert any(s.option_id == target for s in e.effective_selections(line)), \
            f"{name}/{g.id}: default '{target}' was never applied"
        assert e.remove_option(line.line_id, target), \
            f"{name}/{g.id}: could not negate default '{target}'"
        assert not any(s.option_id == target
                       for s in e.effective_selections(line)), \
            f"{name}/{g.id}: negated '{target}' is still an active selection"
        autofill(e)
        ticket = e.to_normalized_order()
        sent = {m["option_id"] for l in ticket["lines"] for m in l["modifiers"]}
        assert target not in sent, (
            f"{name}/{g.id}: negated '{target}' still reached the POS ticket")


def inv_informational_options_are_never_charged(name, cfg):
    """Included items must stay free even if someone types a price into the
    config by mistake. Otherwise a typo silently bills every customer."""
    import dataclasses
    info = [g for g in cfg.groups if g.informational]
    for g in info:
        host = next((i for i in cfg.items if g.id in i.modifier_group_ids), None)
        if host is None:
            continue
        poisoned = dataclasses.replace(cfg, options=tuple(
            dataclasses.replace(o, price_cents=999) if o.id in g.option_ids else o
            for o in cfg.options))
        base = fresh(cfg)
        bl = base.add_line(host.id)
        autofill(base)
        pois = fresh(poisoned)
        pl = pois.add_line(host.id)
        autofill(pois)
        assert pois.price().subtotal_cents == base.price().subtotal_cents, (
            f"{name}/{g.id}: a price on an included item changed the bill")


def inv_quantity_prefix_does_not_break_matching(name, cfg):
    """Saying a quantity must not change WHICH item is matched.

    Found while migrating Bun N Run: the leading quantity word was being fed
    into the similarity score, which pushed 'one cheeseburger' close enough to
    'double cheeseburger' to read as ambiguous. Callers say a number before
    almost every item, so this is not an edge case.

    The assertion is deliberately "same answer with and without the prefix",
    not "always decisive" — some menus genuinely sell two things by the same
    name (Sam's Kabob has a Shish Tawook and a lunch Chicken Kabob), and
    asking about those is correct behaviour, prefix or no prefix.
    """
    e = fresh(cfg)
    for it in cfg.items:
        bare = e.matcher.match_items(it.name)
        bare_top = bare[0].target_id if bare else None
        bare_decisive = e.matcher.is_decisive(bare)
        for prefix in ("two", "3", "a couple of"):
            cands = e.matcher.match_items(f"{prefix} {it.name}")
            assert cands, f"{name}: '{prefix} {it.name}' matched nothing"
            top = cands[0].target_id if cands else None
            assert top == bare_top, (
                f"{name}: '{it.name}' resolves to {bare_top} alone but to "
                f"{top} when a quantity is spoken")
            assert e.matcher.is_decisive(cands) == bare_decisive, (
                f"{name}: saying '{prefix}' before '{it.name}' changed whether "
                f"the match was decisive")


def inv_shared_words_between_items_are_never_decisive(name, cfg):
    """If a caller says only the words two items have in common, the engine
    must ask which one — it must never pick on name length.

    Found on Pink Garlic, where thirteen dishes exist in both a chicken and a
    lamb version. Saying 'saag' or 'korma' resolved silently to the chicken
    one every time, because 'Chicken Saag' is a shorter name than 'Lamb or
    Goat Saag' and so scored higher. Fourteen dishes out of fourteen.
    """
    e = fresh(cfg)
    items = list(cfg.items)
    for i in range(len(items)):
        for j in range(i + 1, len(items)):
            a, b = items[i], items[j]
            ta = set(normalize(a.name).split())
            tb = set(normalize(b.name).split())
            shared = ta & tb
            if not shared or shared == ta or shared == tb:
                continue
            cands = e.matcher.match_items(" ".join(sorted(shared)))
            if not cands:
                continue
            if e.matcher.is_decisive(cands):
                top = cands[0].target_id
                assert top not in (a.id, b.id), (
                    f"{name}: saying only {sorted(shared)} — the words "
                    f"'{a.name}' and '{b.name}' share — resolved decisively "
                    f"to '{cands[0].target_name}' instead of asking")


def inv_multi_pick_groups_vary_their_prompt(name, cfg):
    for g in cfg.groups:
        if g.min_select <= 1:
            continue
        host = next((i for i in cfg.items if g.id in i.modifier_group_ids), None)
        if host is None:
            continue
        e = fresh(cfg)
        line = e.add_line(host.id)
        if host.has_sizes:
            e.set_size(line.line_id, host.sizes[0].id)
        opener = next((i.question for i in e.validate()
                       if i.group_id == g.id and i.blocking), None)
        first = next((o.id for o in cfg.options_for(g) if o.available), None)
        if first is None:
            continue
        e.apply_option(line.line_id, g.id, first)
        follow = next((i.question for i in e.validate()
                       if i.group_id == g.id and i.blocking), None)
        if follow is None:
            continue
        assert follow != opener, (
            f"{name}/{g.id}: same question asked twice in a row")


def inv_split_line_preserves_totals(name, cfg):
    it = next((i for i in orderable_items(cfg)), None)
    e = fresh(cfg)
    line = e.add_line(it.id, quantity=3)
    autofill(e)
    before = e.price().subtotal_cents
    e.split_line(line.line_id, take=1)
    assert e.price().subtotal_cents == before, \
        f"{name}: splitting a line changed the total"
    assert e.is_submittable()


def inv_fuzz_never_raises(name, cfg):
    """Random operation sequences must never throw. A crash mid-call drops
    the customer; a structured issue does not."""
    rng = random.Random(1234 + len(name))
    items = orderable_items(cfg)
    for trial in range(120):
        e = fresh(cfg)
        for _ in range(rng.randint(1, 4)):
            it = rng.choice(items)
            line = e.add_line(it.id, quantity=rng.randint(1, 3))
            if it.has_sizes and rng.random() < 0.7:
                e.set_size(line.line_id, rng.choice(it.sizes).id)
            for _ in range(rng.randint(0, 6)):
                gids = e.active_group_ids(line)
                if not gids:
                    break
                gid = rng.choice(gids)
                g = cfg.group(gid)
                if g is None or not g.option_ids:
                    continue
                oid = rng.choice(list(g.option_ids))
                e.apply_option(
                    line.line_id, gid, oid,
                    quantity=rng.randint(1, 3),
                    placement=rng.choice(list(Placement)))
            if rng.random() < 0.3:
                opts = [o.id for o in cfg.options]
                e.remove_option(line.line_id, rng.choice(opts))
        e.validate()
        e.price()
        e.read_back()
        e.to_normalized_order()
        e.next_question()


INVARIANTS = [
    inv_config_is_clean,
    inv_every_item_is_reachable_by_speech,
    inv_every_option_is_reachable_by_speech,
    inv_required_groups_produce_a_question,
    inv_no_blocking_issue_without_a_question,
    inv_every_item_can_be_completed,
    inv_pricing_is_deterministic,
    inv_money_is_sane,
    inv_normalized_order_matches_price,
    inv_single_select_replaces,
    inv_max_select_is_enforced,
    inv_sold_out_options_are_refused,
    inv_quantity_cap_is_enforced,
    inv_placement_requires_opt_in,
    inv_86ed_item_blocks_with_an_apology,
    inv_empty_cart_asks_a_question,
    inv_read_back_never_crashes_and_names_the_item,
    inv_informational_groups_are_never_asked_and_never_charged,
    inv_negated_default_actually_leaves_the_ticket,
    inv_informational_options_are_never_charged,
    inv_quantity_prefix_does_not_break_matching,
    inv_shared_words_between_items_are_never_decisive,
    inv_multi_pick_groups_vary_their_prompt,
    inv_split_line_preserves_totals,
    inv_fuzz_never_raises,
]


# ===========================================================================
# PART 2 — cuisine-specific behaviour
# ===========================================================================


def t_indian_spice_is_required_with_no_default():
    e = fresh(INDIAN)
    line = e.add_line("tikka_masala")
    issues = e.validate()
    codes = [(i.code, i.group_id) for i in issues]
    assert (IssueCode.MISSING_REQUIRED_GROUP, "spice") in codes
    assert "spicy" in e.next_question().lower()
    e.apply_option(line.line_id, "spice", "spice_medium")
    e.apply_option(line.line_id, "protein", "prot_chicken")
    assert e.is_submittable()
    assert e.price().subtotal_cents == 1695


def t_indian_protein_upcharge_and_stacked_naan():
    e = fresh(INDIAN)
    line = e.add_line("tikka_masala")
    e.apply_option(line.line_id, "spice", "spice_hot")
    e.apply_option(line.line_id, "protein", "prot_shrimp")      # +3.50
    e.apply_option(line.line_id, "indian_addons", "add_naan", quantity=2)  # 2 x 3.50
    assert e.is_submittable()
    assert e.price().subtotal_cents == 1695 + 350 + 700


def t_indian_switching_protein_replaces_not_stacks():
    e = fresh(INDIAN)
    line = e.add_line("tikka_masala")
    e.apply_option(line.line_id, "spice", "spice_mild")
    e.apply_option(line.line_id, "protein", "prot_lamb")
    e.apply_option(line.line_id, "protein", "prot_chicken")   # "actually, chicken"
    assert e.price().subtotal_cents == 1695


def t_mexican_two_free_salsas_then_charged():
    e = fresh(MEXICAN)
    line = e.add_line("taco")
    e.apply_option(line.line_id, "mx_protein", "mx_asada")
    e.apply_option(line.line_id, "mx_tortilla", "tort_corn")
    for s in ("salsa_verde", "salsa_roja"):
        e.apply_option(line.line_id, "mx_salsa", s)
    assert e.price().subtotal_cents == 375, "first two salsas must be free"
    e.apply_option(line.line_id, "mx_salsa", "salsa_habanero")
    assert e.price().subtotal_cents == 375 + 75, "third salsa must cost 75c"
    e.apply_option(line.line_id, "mx_salsa", "salsa_pico")
    assert e.price().subtotal_cents == 375 + 150


def t_mexican_included_sides_are_free_and_on_the_ticket():
    e = fresh(MEXICAN)
    line = e.add_line("burrito")
    e.apply_option(line.line_id, "mx_protein", "mx_carnitas")
    assert e.is_submittable()
    assert e.price().subtotal_cents == 1195
    n = e.to_normalized_order()
    names = {m["option_name"] for m in n["lines"][0]["modifiers"]}
    assert {"Mexican Rice", "Pinto Beans"} <= names


def t_mexican_shrimp_upcharge_and_double_guac():
    e = fresh(MEXICAN)
    line = e.add_line("burrito", quantity=2)
    e.apply_option(line.line_id, "mx_protein", "mx_camaron")        # +2.00
    e.apply_option(line.line_id, "mx_addons", "add_guac", quantity=2)  # 2 x 2.50
    unit = 1195 + 200 + 500
    assert e.price().subtotal_cents == unit * 2


def t_mediterranean_both_bundled_choices_are_required_and_free():
    e = fresh(MEDITERRANEAN)
    line = e.add_line("chicken_kabob")
    blocking = [i for i in e.validate() if i.blocking]
    gids = {i.group_id for i in blocking}
    assert {"med_side", "med_starter"} <= gids, \
        "both included choices must be asked"
    e.apply_option(line.line_id, "med_side", "side_rice")
    assert not e.is_submittable(), "starter still outstanding"
    e.apply_option(line.line_id, "med_starter", "start_soup")
    assert e.is_submittable()
    assert e.price().subtotal_cents == 1695, "included choices must cost nothing"


def t_mediterranean_side_upgrade_is_priced():
    e = fresh(MEDITERRANEAN)
    line = e.add_line("gyro_plate")
    e.apply_option(line.line_id, "med_side", "side_fattoush")   # +2.50
    e.apply_option(line.line_id, "med_starter", "start_salad")
    assert e.price().subtotal_cents == 1595 + 250


def t_mediterranean_one_question_at_a_time():
    e = fresh(MEDITERRANEAN)
    line = e.add_line("falafel_plate")
    q1 = e.next_question()
    assert q1 and "side" in q1.lower()
    e.apply_option(line.line_id, "med_side", "side_fries")
    q2 = e.next_question()
    assert q2 and q2 != q1 and ("salad" in q2.lower() or "soup" in q2.lower())


def t_japanese_boat_requires_exactly_three_rolls():
    e = fresh(JAPANESE)
    line = e.add_line("sushi_boat")
    assert any(i.group_id == "boat_rolls" for i in e.validate())
    e.apply_option(line.line_id, "boat_rolls", "roll_cali")
    e.apply_option(line.line_id, "boat_rolls", "roll_cucumber")
    issues = [i for i in e.validate() if i.blocking]
    assert any(i.code is IssueCode.TOO_FEW_SELECTED for i in issues), \
        "two rolls must not be enough"
    e.apply_option(line.line_id, "boat_rolls", "roll_salmon_avo")
    assert e.is_submittable()
    assert e.price().subtotal_cents == 3295

    # a fourth roll is over the limit
    line.selections.append(Selection("boat_rolls", "roll_spicy_tuna"))
    assert any(i.code is IssueCode.TOO_MANY_SELECTED for i in e.validate())


def t_japanese_premium_roll_upcharges_inside_the_boat():
    e = fresh(JAPANESE)
    line = e.add_line("sushi_boat")
    for r in ("roll_cali", "roll_dragon", "roll_rainbow"):   # +4.00 each
        e.apply_option(line.line_id, "boat_rolls", r)
    assert e.is_submittable()
    assert e.price().subtotal_cents == 3295 + 800


def t_japanese_sold_out_uni_is_refused_politely():
    e = fresh(JAPANESE)
    line = e.add_line("nigiri")
    issues = e.apply_option(line.line_id, "nigiri_fish", "fish_uni")
    assert issues and issues[0].code is IssueCode.OPTION_UNAVAILABLE
    assert "uni" in issues[0].question.lower()
    assert not any(s.option_id == "fish_uni" for s in line.selections)


def t_japanese_poke_four_free_toppings_then_priced():
    e = fresh(JAPANESE)
    line = e.add_line("poke_bowl")
    e.apply_option(line.line_id, "bowl_base", "rice_white")
    e.apply_option(line.line_id, "poke_protein", "fish_salmon")
    for t in ("poke_topping_edamame", "poke_topping_avocado",
              "poke_topping_mango", "poke_topping_seaweed"):
        e.apply_option(line.line_id, "poke_toppings", t)
    assert e.price().subtotal_cents == 1595, "first four toppings included"
    # Crab ($2.00) is the most expensive, so the free allowance moves to it
    # and the cheapest previously-free topping starts being charged.
    e.apply_option(line.line_id, "poke_toppings", "poke_topping_crab")
    assert e.price().subtotal_cents == 1595 + 100, \
        "free allowance must be spent on the most expensive picks"


def t_japanese_brown_rice_upcharge():
    e = fresh(JAPANESE)
    line = e.add_line("poke_bowl")
    e.apply_option(line.line_id, "bowl_base", "rice_brown")
    e.apply_option(line.line_id, "poke_protein", "fish_tuna")
    assert e.price().subtotal_cents == 1595 + 100


def t_korean_banchan_is_included_never_asked_never_charged():
    e = fresh(KOREAN)
    line = e.add_line("bibimbap")
    e.apply_option(line.line_id, "kr_protein", "kr_tofu")
    e.apply_option(line.line_id, "kr_spice", "kr_medium")
    assert e.is_submittable()
    for i in e.validate():
        assert i.group_id != "banchan"
    assert e.price().subtotal_cents == 1595
    n = e.to_normalized_order()
    banchan = [m for m in n["lines"][0]["modifiers"] if m["group_id"] == "banchan"]
    assert len(banchan) == 4 and all(m["informational"] for m in banchan)


def t_korean_sauce_cup_price_depends_on_chicken_size():
    small = fresh(KOREAN)
    l1 = small.add_line("korean_fried_chicken")
    small.set_size(l1.line_id, "kfc_small")
    small.apply_option(l1.line_id, "kfc_sauce", "kfc_soy_garlic")
    small.apply_option(l1.line_id, "kr_addons", "kr_sauce_cup", quantity=2)
    assert small.price().subtotal_cents == 1795 + 200   # 2 x $1.00

    large = fresh(KOREAN)
    l2 = large.add_line("korean_fried_chicken")
    large.set_size(l2.line_id, "kfc_large")
    large.apply_option(l2.line_id, "kfc_sauce", "kfc_soy_garlic")
    large.apply_option(l2.line_id, "kr_addons", "kr_sauce_cup", quantity=2)
    assert large.price().subtotal_cents == 3195 + 300   # 2 x $1.50


def t_korean_half_and_half_sauce_upcharge():
    e = fresh(KOREAN)
    line = e.add_line("korean_fried_chicken")
    e.set_size(line.line_id, "kfc_large")
    e.apply_option(line.line_id, "kfc_sauce", "kfc_half_half")
    assert e.price().subtotal_cents == 3195 + 200


def t_burger_defaults_are_free_and_negatable():
    e = fresh(BURGER_TEMPLATE)
    line = e.add_line("double_cheeseburger")
    assert e.is_submittable(), "a burger with defaults needs no questions"
    assert e.price().subtotal_cents == 995
    assert e.remove_option(line.line_id, "top_onion")
    assert "no Onion" in e.describe_line(line)
    assert e.price().subtotal_cents == 995, "removing a default is free"
    e.apply_option(line.line_id, "toppings", "top_bacon", quantity=2)
    assert e.price().subtotal_cents == 995 + 400


def t_burger_combo_reveals_two_required_groups():
    e = fresh(BURGER_TEMPLATE)
    line = e.add_line("single_cheeseburger")
    assert "combo_side" not in e.active_group_ids(line)
    assert e.is_submittable()
    e.apply_option(line.line_id, "combo_upgrade", "combo_yes")
    active = e.active_group_ids(line)
    assert "combo_side" in active and "combo_drink" in active
    assert not e.is_submittable(), "combo must force a side and a drink"
    q = e.next_question()
    assert q and "side" in q.lower()
    e.apply_option(line.line_id, "combo_side", "cside_rings")   # +1.50
    e.apply_option(line.line_id, "combo_drink", "cdrink_sprite")
    assert e.is_submittable()
    assert e.price().subtotal_cents == 725 + 450 + 150


def t_burger_ambiguity_is_asked_not_guessed():
    e = fresh(BURGER_TEMPLATE)
    cands = e.matcher.match_items("gimme a double with cheese")
    assert cands[0].target_id == "double_cheeseburger"
    assert e.matcher.is_decisive(cands), "clear phrasing must resolve"
    vague = e.matcher.match_items("a double")
    if len(vague) > 1:
        assert not e.matcher.is_decisive(vague), \
            "'a double' is genuinely ambiguous and must trigger a question"


def t_burger_thirty_dollar_rule():
    e = fresh(BURGER_TEMPLATE)
    l1 = e.add_line("double_cheeseburger")
    assert e.price().pay_now is False
    e.add_line("double_cheeseburger")
    e.add_line("double_cheeseburger")
    p = e.price()
    assert p.subtotal_cents == 2985
    assert p.pay_now is False, "just under the line"
    e.apply_option(l1.line_id, "toppings", "top_bacon")   # +2.00 -> 31.85
    assert e.price().pay_now is True


def t_pizza_topping_price_follows_size():
    for size, expect in (("p_sm", 1195 + 250), ("p_md", 1695 + 325),
                         ("p_lg", 2195 + 400)):
        e = fresh(PIZZA)
        line = e.add_line("byo_pizza")
        e.set_size(line.line_id, size)
        e.apply_option(line.line_id, "crust", "crust_regular")
        e.apply_option(line.line_id, "pizza_sauce", "sauce_red")
        e.apply_option(line.line_id, "toppings_byo", "t_pepperoni")
        assert e.is_submittable()
        assert e.price().subtotal_cents == expect, f"{size} pepperoni wrong"


def t_pizza_half_topping_is_half_price():
    e = fresh(PIZZA)
    line = e.add_line("byo_pizza")
    e.set_size(line.line_id, "p_lg")
    e.apply_option(line.line_id, "crust", "crust_thin")
    e.apply_option(line.line_id, "pizza_sauce", "sauce_red")
    e.apply_option(line.line_id, "toppings_byo", "t_pepperoni",
                   placement=Placement.LEFT)                    # 400 -> 200
    e.apply_option(line.line_id, "toppings_byo", "t_mushroom",
                   placement=Placement.RIGHT)                   # 275 -> 138
    assert e.price().subtotal_cents == 2195 + 200 + 138
    assert "on the left" in e.describe_line(line)


def t_pizza_double_pepperoni_is_double_price():
    e = fresh(PIZZA)
    line = e.add_line("byo_pizza")
    e.set_size(line.line_id, "p_md")
    e.apply_option(line.line_id, "crust", "crust_regular")
    e.apply_option(line.line_id, "pizza_sauce", "sauce_red")
    e.apply_option(line.line_id, "toppings_byo", "t_pepperoni", quantity=2)
    assert e.price().subtotal_cents == 1695 + 650
    # and it still counts as ONE topping choice, not two
    line2 = e.get_line(line.line_id)
    sels = [s for s in e.effective_selections(line2)
            if s.group_id == "toppings_byo"]
    assert len(sels) == 1


def t_pizza_gluten_free_not_available_at_large():
    e = fresh(PIZZA)
    line = e.add_line("byo_pizza")
    e.set_size(line.line_id, "p_md")
    e.apply_option(line.line_id, "crust", "crust_gf")
    e.apply_option(line.line_id, "pizza_sauce", "sauce_red")
    assert e.price().subtotal_cents == 1695 + 400
    # Customer upsizes. The GF crust must be dropped and flagged, not
    # silently carried at a price that does not exist.
    issues = e.set_size(line.line_id, "p_lg")
    assert any(i.code is IssueCode.OPTION_UNAVAILABLE for i in issues)
    assert not any(s.option_id == "crust_gf" for s in line.selections)
    assert not e.is_submittable(), "crust must be re-asked"


def t_pizza_three_topping_special_frees_the_dearest_three():
    e = fresh(PIZZA)
    line = e.add_line("three_topping")
    e.set_size(line.line_id, "p_lg")
    e.apply_option(line.line_id, "crust", "crust_regular")
    e.apply_option(line.line_id, "pizza_sauce", "sauce_red")
    for t in ("t_pepperoni", "t_sausage", "t_mushroom"):   # 400,400,275
        e.apply_option(line.line_id, "toppings_special", t)
    assert e.is_submittable()
    assert e.price().subtotal_cents == 2595, "three toppings are included"
    # A fourth, cheap topping: the allowance stays on the dear ones and the
    # cheapest topping is what gets charged.
    e.apply_option(line.line_id, "toppings_special", "t_onion")   # 275
    assert e.price().subtotal_cents == 2595 + 275


def t_pizza_size_is_asked_before_anything_else():
    e = fresh(PIZZA)
    e.add_line("byo_pizza")
    q = e.next_question()
    assert q and "size" in q.lower()


def t_italian_shape_and_sauce_both_required():
    e = fresh(ITALIAN)
    line = e.add_line("pasta_bowl")
    e.set_size(line.line_id, "it_dinner")
    gids = {i.group_id for i in e.validate() if i.blocking}
    assert {"pasta_shape", "pasta_sauce"} <= gids
    e.apply_option(line.line_id, "pasta_shape", "shape_penne")
    e.apply_option(line.line_id, "pasta_sauce", "sauce_marinara")
    assert e.is_submittable()
    assert e.price().subtotal_cents == 1795


def t_italian_gluten_free_and_bolognese_upcharges_stack():
    e = fresh(ITALIAN)
    line = e.add_line("pasta_bowl")
    e.set_size(line.line_id, "it_dinner")
    e.apply_option(line.line_id, "pasta_shape", "shape_gf")        # +3.00
    e.apply_option(line.line_id, "pasta_sauce", "sauce_bolognese") # +2.00
    e.apply_option(line.line_id, "it_addons", "add_meatballs", quantity=3)  # +12.00
    assert e.price().subtotal_cents == 1795 + 300 + 200 + 1200


def t_italian_family_size_and_pay_now():
    e = fresh(ITALIAN)
    line = e.add_line("pasta_bowl")
    e.set_size(line.line_id, "it_family")
    e.apply_option(line.line_id, "pasta_shape", "shape_spaghetti")
    e.apply_option(line.line_id, "pasta_sauce", "sauce_alfredo")
    p = e.price()
    assert p.subtotal_cents == 3295
    assert p.pay_now is True


def t_italian_parmesan_default_can_be_refused():
    e = fresh(ITALIAN)
    line = e.add_line("lasagna")
    assert "Grated Parmesan" in e.describe_line(line)
    assert e.remove_option(line.line_id, "cheese_parm")
    assert "no Grated Parmesan" in e.describe_line(line)
    assert e.price().subtotal_cents == 1895


# --- the linter must actually catch broken configs -------------------------


def t_partial_group_does_not_repeat_the_same_question():
    """Found by running the demo: the boat asked 'which three rolls?' three
    times verbatim. A caller hears that as the system not listening."""
    e = fresh(JAPANESE)
    line = e.add_line("sushi_boat")
    first = e.next_question()
    e.apply_option(line.line_id, "boat_rolls", "roll_cali")
    second = e.next_question()
    assert second and second != first, "Lily repeated herself verbatim"
    assert "2 more" in second
    e.apply_option(line.line_id, "boat_rolls", "roll_cucumber")
    third = e.next_question()
    assert "1 more roll " in third and "rolls" not in third, \
        f"singular/plural not handled: {third!r}"


def t_read_back_omits_untouched_defaults_but_keeps_changes():
    e = fresh(BURGER_TEMPLATE)
    line = e.add_line("double_cheeseburger")
    e.remove_option(line.line_id, "top_onion")
    e.apply_option(line.line_id, "toppings", "top_bacon", quantity=2)
    spoken = e.read_back()
    assert "Lettuce" not in spoken and "Ketchup" not in spoken, \
        f"read-back recites unchanged defaults: {spoken}"
    assert "2x Bacon" in spoken and "no Onion" in spoken
    # the kitchen still gets everything
    ticket = e.to_normalized_order()
    sent = {m["option_name"] for m in ticket["lines"][0]["modifiers"]}
    assert "Lettuce" in sent and "Ketchup" in sent
    assert "Onion" not in sent


def t_split_line_lets_one_of_three_tacos_differ():
    """'Three tacos — actually put guac on just one of them.'"""
    e = fresh(MEXICAN)
    line = e.add_line("taco", quantity=3)
    e.apply_option(line.line_id, "mx_protein", "mx_asada")
    e.apply_option(line.line_id, "mx_tortilla", "tort_corn")
    assert e.price().subtotal_cents == 375 * 3

    solo = e.split_line(line.line_id, take=1)
    assert solo is not None and solo.quantity == 1
    assert e.get_line(line.line_id).quantity == 2
    e.apply_option(solo.line_id, "mx_addons", "add_guac")
    assert e.price().subtotal_cents == 375 * 3 + 250, \
        "guac must be charged once, not three times"
    assert e.is_submittable()
    assert len(e.to_normalized_order()["lines"]) == 2


def t_split_line_refuses_impossible_splits():
    e = fresh(MEXICAN)
    line = e.add_line("taco", quantity=1)
    assert e.split_line(line.line_id, take=1) is None
    assert e.split_line(line.line_id, take=5) is None
    assert e.split_line("nope", take=1) is None


# --- Bun N Run migration parity ------------------------------------------
# Every assertion below is pinned to a value taken from the OLD engine's
# restaurant_configs.py. If a number here changes, the migration lost
# something.


def t_bnr_base_prices_match_the_old_config():
    expected = {"hamburger": 599, "cheeseburger": 699, "double_hamburger": 799,
                "double_cheeseburger": 899, "veggie_burger": 699,
                "french_fries": 399, "wild_fries": 599, "shake": 599,
                "beverage": 249}
    for item_id, cents in expected.items():
        e = fresh(BUN_N_RUN)
        e.add_line(item_id)
        assert e.is_submittable(), f"{item_id} should need no questions"
        assert e.price().subtotal_cents == cents, item_id


def t_bnr_combo_prices_match_the_old_config():
    expected = {"hamburger": 999, "cheeseburger": 1099,
                "double_hamburger": 1199, "double_cheeseburger": 1299,
                "veggie_burger": 1099}
    for item_id, cents in expected.items():
        e = fresh(BUN_N_RUN)
        line = e.add_line(item_id)
        e.apply_option(line.line_id, "bnr_combo_group", "bnr_combo")
        assert e.price().subtotal_cents == cents, item_id


def t_bnr_cheese_burgers_default_to_cheese_and_plain_ones_do_not():
    """The old config carried two different default_toppings lists. The new
    model carries two groups. This is the check that the split survived."""
    cheesy = fresh(BUN_N_RUN)
    c = cheesy.add_line("cheeseburger")
    on_cheeseburger = {s.option_id for s in cheesy.effective_selections(c)}
    assert on_cheeseburger == {"bnr_tomato", "bnr_onion", "bnr_ketchup",
                               "bnr_mayo", "bnr_cheese"}

    plain = fresh(BUN_N_RUN)
    p = plain.add_line("hamburger")
    on_hamburger = {s.option_id for s in plain.effective_selections(p)}
    assert on_hamburger == {"bnr_tomato", "bnr_onion", "bnr_ketchup", "bnr_mayo"}
    assert "bnr_cheese" not in on_hamburger


def t_bnr_no_onion_leaves_the_toast_ticket():
    e = fresh(BUN_N_RUN)
    line = e.add_line("double_cheeseburger")
    assert e.remove_option(line.line_id, "bnr_onion")
    ticket = e.to_normalized_order()
    mods = ticket["lines"][0]["modifiers"]
    assert "bnr_onion" not in {m["option_id"] for m in mods}
    assert "Onion" in ticket["lines"][0]["removed_defaults"]
    assert e.price().subtotal_cents == 899


def t_bnr_pickle_is_not_on_the_menu():
    """The old engine's known bad case. Bun N Run's Toast modifier group has
    no Pickle, so 'no pickle' must find nothing rather than be accepted."""
    e = fresh(BUN_N_RUN)
    line = e.add_line("cheeseburger")
    assert not e.matcher.match_options("pickle"), \
        "pickle must not resolve to any Bun N Run modifier"
    assert not e.remove_option(line.line_id, "bnr_pickle")


def t_bnr_single_cheeseburger_does_not_match_the_double():
    """The second bug the old engine's testing caught, pinned here so the new
    matcher can never regress into it."""
    e = fresh(BUN_N_RUN)
    for phrase in ("cheeseburger", "single cheeseburger", "one cheeseburger",
                   "just a cheeseburger"):
        cands = e.matcher.match_items(phrase)
        assert cands and cands[0].target_id == "cheeseburger", \
            f"{phrase!r} -> {cands[0].target_name if cands else None}"
        assert e.matcher.is_decisive(cands), f"{phrase!r} was ambiguous"
    doubles = e.matcher.match_items("double cheeseburger")
    assert doubles[0].target_id == "double_cheeseburger"


def t_bnr_hamburger_combo_with_extra_cheese():
    """The first bug the old engine's testing caught: 'cheese' got lost when
    'with' and 'extra' both grabbed the next word. Here the three intents
    arrive separately, and all three must land."""
    e = fresh(BUN_N_RUN)
    line = e.add_line("hamburger")
    e.apply_option(line.line_id, "bnr_combo_group", "bnr_combo")
    e.apply_option(line.line_id, "bnr_toppings_plain", "bnr_cheese")
    active = {s.option_id for s in e.effective_selections(line)}
    assert "bnr_combo" in active and "bnr_cheese" in active
    assert e.price().subtotal_cents == 999   # cheese price still unconfirmed


def t_bnr_thirty_dollar_rule_matches_old_behaviour():
    e = fresh(BUN_N_RUN)
    for _ in range(3):
        line = e.add_line("double_cheeseburger")
        e.apply_option(line.line_id, "bnr_combo_group", "bnr_combo")
    p = e.price()
    assert p.subtotal_cents == 1299 * 3
    assert p.pay_now is True
    small = fresh(BUN_N_RUN)
    small.add_line("hamburger")
    assert small.price().pay_now is False


def t_bnr_toast_guids_survived_the_migration():
    e = fresh(BUN_N_RUN)
    line = e.add_line("double_cheeseburger")
    ticket = e.to_normalized_order()
    refs = ticket["lines"][0]["pos_refs"]
    assert refs["toast_guid"] == "a1b2-double-cheeseburger"
    assert refs["toast_combo_guid"] == "a1b2-double-cheeseburger-combo"
    mods = {m["option_name"]: m["pos_refs"] for m in ticket["lines"][0]["modifiers"]}
    assert mods["Onion"]["toast_guid"] == "mo-onion"
    assert mods["Ketchup"]["toast_guid"] == "mo-ketchup"
    assert ticket["pos_type"] == "toast"


def t_bnr_availability_comes_from_sync_not_from_the_menu():
    """Wild Fries was outOfStock in the Toast fixture. That belongs to a
    sync, not to the config — otherwise it can never come back in stock."""
    assert fresh(BUN_N_RUN).config.item("wild_fries").available, \
        "the menu must not hardcode a sold-out state"
    response = {"menus": [{"menuGroups": [{"menuItems": [
        {"guid": "a1b2-wild-fries", "outOfStock": True},
        {"guid": "a1b2-french-fries", "outOfStock": False},
    ]}]}]}
    synced = from_toast_menu_response(BUN_N_RUN, response)
    assert synced.item("wild_fries").available is False
    assert synced.item("french_fries").available is True
    e = fresh(synced)
    e.add_line("wild_fries")
    issues = e.validate()
    assert any(i.code is IssueCode.ITEM_UNAVAILABLE for i in issues)
    assert "wild fries" in e.next_question().lower()
    # and the original config is untouched — sync must not mutate the menu
    assert BUN_N_RUN.item("wild_fries").available is True


def t_miyazaki_calcifer_has_two_independent_pick_groups():
    """The hardest shape across all seven menus: one item, two required
    multi-pick groups, each with its own count and option list."""
    e = fresh(MIYAZAKI)
    line = e.add_line("my_tray_calcifer")
    gids = {i.group_id for i in e.validate() if i.blocking}
    assert {"my_tray5_basic", "my_tray2_special"} <= gids

    q1 = e.next_question()
    assert q1 and "five basic" in q1.lower()
    for r in ("my_basic_california", "my_basic_spicy_tuna",
              "my_basic_philadelphia", "my_basic_salmon", "my_basic_aac"):
        e.apply_option(line.line_id, "my_tray5_basic", r)
    # first group satisfied, second must now be asked — and differently
    q2 = e.next_question()
    assert q2 and q2 != q1 and "special" in q2.lower()
    assert not e.is_submittable()

    e.apply_option(line.line_id, "my_tray2_special", "my_special_dragon")
    q3 = e.next_question()
    assert "one more special roll" in q3.lower(), q3
    e.apply_option(line.line_id, "my_tray2_special", "my_special_rainbow")
    assert e.is_submittable()
    assert e.price().subtotal_cents == 7000
    assert e.price().pay_now is True


def t_miyazaki_tray_counts_are_enforced_separately():
    e = fresh(MIYAZAKI)
    line = e.add_line("my_tray_calcifer")
    for r in ("my_basic_california", "my_basic_spicy_tuna",
              "my_basic_philadelphia", "my_basic_salmon"):
        e.apply_option(line.line_id, "my_tray5_basic", r)
    issues = [i for i in e.validate() if i.blocking]
    codes = {(i.code, i.group_id) for i in issues}
    assert (IssueCode.TOO_FEW_SELECTED, "my_tray5_basic") in codes
    assert (IssueCode.MISSING_REQUIRED_GROUP, "my_tray2_special") in codes


def t_miyazaki_kaonashi_excludes_rainbow():
    """KAONASHI's special-roll list is the CALCIFER list minus Rainbow."""
    e = fresh(MIYAZAKI)
    line = e.add_line("my_tray_kaonashi")
    issues = e.apply_option(line.line_id, "my_tray2_special_norainbow",
                            "my_special_rainbow")
    assert issues and issues[0].code is IssueCode.OPTION_NOT_IN_GROUP


def t_chengs_price_range_is_a_size_axis():
    """$4.95-$7.50 on the menu means Small $4.95 / Large $7.50."""
    e = fresh(CHENGS)
    line = e.add_line("cz_egg_drop_soup")
    q = e.next_question()
    assert q and "size" in q.lower()
    e.set_size(line.line_id, "cz_sm")
    assert e.price().subtotal_cents == 495
    e.set_size(line.line_id, "cz_lg")
    assert e.price().subtotal_cents == 750


def t_chengs_wontons_are_priced_as_discrete_options():
    """Their POS models quantity as separate options; the config copies it
    rather than 'improving' it into a repeatable modifier."""
    e = fresh(CHENGS)
    line = e.add_line("cz_egg_drop_soup")
    e.set_size(line.line_id, "cz_lg")
    e.apply_option(line.line_id, "cz_wontons", "cz_wonton_3")
    assert e.price().subtotal_cents == 750 + 255
    # single-select: asking for 4 replaces 3, it does not add to it
    e.apply_option(line.line_id, "cz_wontons", "cz_wonton_4")
    assert e.price().subtotal_cents == 750 + 350


def t_chengs_included_rice_is_free_and_unasked():
    e = fresh(CHENGS)
    line = e.add_line("cz_general_chicken")
    assert e.is_submittable(), "an included side must not be a question"
    assert e.price().subtotal_cents == 1575
    ticket = e.to_normalized_order()
    mods = ticket["lines"][0]["modifiers"]
    assert any(m["option_name"].startswith("White Rice") and m["informational"]
               for m in mods)


def t_tamago_bundles_are_included_not_charged():
    e = fresh(TAMAGO)
    line = e.add_line("tg_bowl_rainbow")
    assert e.is_submittable()
    assert e.price().subtotal_cents == 1600
    names = {m["option_name"] for m in e.to_normalized_order()["lines"][0]["modifiers"]}
    assert "Sushi Rice (included)" in names and "Avocado (included)" in names


def t_tamago_inline_addon_prices():
    """'Add Chicken 2 / Beef 2 / Tofu 1' printed on the menu, as dollars."""
    e = fresh(TAMAGO)
    line = e.add_line("tg_rb_bibimbap")
    assert e.price().subtotal_cents == 1200
    e.apply_option(line.line_id, "tg_bibimbap_add", "tg_add_chicken")
    e.apply_option(line.line_id, "tg_bibimbap_add", "tg_add_tofu")
    assert e.price().subtotal_cents == 1200 + 200 + 100


def t_juan_miguels_botana_requires_a_protein():
    e = fresh(JUAN_MIGUELS)
    line = e.add_line("jm_botana")
    assert not e.is_submittable()
    q = e.next_question()
    assert q and "beef" in q.lower()
    e.apply_option(line.line_id, "jm_botana_protein", "jm_add_both")
    assert e.is_submittable()
    assert e.price().subtotal_cents == 1499 + 500


def t_juan_miguels_fajitas_need_protein_and_tortilla():
    e = fresh(JUAN_MIGUELS)
    line = e.add_line("jm_fajitas")
    gids = {i.group_id for i in e.validate() if i.blocking}
    assert {"jm_fajita_protein", "jm_fajita_tortilla"} <= gids
    e.apply_option(line.line_id, "jm_fajita_protein", "jm_fajita_combo")
    e.apply_option(line.line_id, "jm_fajita_tortilla", "jm_tortilla_flour")
    assert e.is_submittable()
    assert e.price().subtotal_cents == 1999


def t_linter_catches_a_broken_config():
    import dataclasses
    from order_engine import ModifierGroup
    bad = dataclasses.replace(
        INDIAN,
        groups=tuple(
            dataclasses.replace(g, prompt="") if g.id == "spice" else g
            for g in INDIAN.groups))
    findings = lint_config(bad)
    assert any(f.level == "ERROR" and "prompt" in f.message for f in findings), \
        "a required group with no prompt must be an ERROR"

    broken_ref = dataclasses.replace(
        INDIAN,
        groups=INDIAN.groups + (ModifierGroup(
            id="ghost", name="Ghost", prompt="?",
            option_ids=("does_not_exist",), min_select=1, max_select=1),))
    findings = lint_config(broken_ref)
    assert any(f.level == "ERROR" and "unknown option" in f.message
               for f in findings)


def t_linter_catches_unreachable_reveal_group():
    import dataclasses
    from order_engine import ModifierGroup
    cfg = dataclasses.replace(
        BURGER_TEMPLATE,
        groups=BURGER_TEMPLATE.groups + (ModifierGroup(
            id="orphan_reveal", name="Orphan", prompt="Which one?",
            option_ids=("cside_fries",), min_select=1, max_select=1,
            reveal_only=True),))
    findings = lint_config(cfg)
    assert any(f.level == "ERROR" and "never revealed" in f.message
               for f in findings)


CUISINE_TESTS = [v for k, v in sorted(globals().items()) if k.startswith("t_")]


# ===========================================================================
# runner
# ===========================================================================


def main() -> int:
    passed = failed = 0
    failures = []

    suites = dict(ALL_PACKS)
    suites.update(REAL_RESTAURANTS)   # real restaurants face the same gate
    for name, cfg in suites.items():
        for inv in INVARIANTS:
            try:
                inv(name, cfg)
                passed += 1
            except Exception as exc:
                failed += 1
                failures.append((f"{inv.__name__}[{name}]", exc,
                                 traceback.format_exc()))

    for fn in CUISINE_TESTS:
        try:
            fn()
            passed += 1
        except Exception as exc:
            failed += 1
            failures.append((fn.__name__, exc, traceback.format_exc()))

    print(f"\n{passed} passed, {failed} failed "
          f"({len(INVARIANTS)} invariants x {len(ALL_PACKS) + len(REAL_RESTAURANTS)} configs "
          f"+ {len(CUISINE_TESTS)} cuisine-specific)")
    for name, exc, tb in failures:
        print(f"\n--- FAIL {name}\n{tb}")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
