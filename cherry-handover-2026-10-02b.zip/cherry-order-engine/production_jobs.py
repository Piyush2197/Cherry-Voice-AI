#!/usr/bin/env python3
"""Credential-ready production jobs: alerts, reconciliation and QA review.

Every external dependency is injected.  The code is therefore fully testable
without credentials, while deployment only has to supply the provider client
or webhook URL and put this command on the platform scheduler.
"""

from __future__ import annotations

import argparse
import json
import os
import urllib.request
import urllib.error
from urllib.parse import quote
from collections import Counter
from dataclasses import asdict
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Iterable, Protocol

import ops_monitor
import ai_ops_assistant
import cost_control
import payments
from order_store import OrderStore, json_value
from vault import secret as vault_secret
from square_bridge import SQUARE_PROD, SQUARE_SANDBOX, SQUARE_VERSION
from sinks import FakeSmsSender


class PaymentStatusProvider(Protocol):
    def payment_status(self, pos_reference: str) -> str: ...


FINAL_PAYMENT_STATES = {"paid", "expired", "failed", "refunded"}


def reconcile_payments(store: OrderStore, provider: PaymentStatusProvider,
                       *, restaurant_id: str = "",
                       release_on_paid: bool = True) -> Dict[str, int]:
    """Reconcile every non-final hosted payment against its POS reference."""
    where_restaurant = " AND o.restaurant_id=?" if restaurant_id else ""
    params = (restaurant_id,) if restaurant_id else ()
    rows = store.conn.execute("""
        SELECT p.order_id, p.status, p.pos_payment_ref, p.amount_cents,
               o.restaurant_id, r.sink
        FROM payment p JOIN "order" o ON o.id=p.order_id
          JOIN restaurant r ON r.id=o.restaurant_id
        WHERE p.status IN ('link_pending','link_sent')
          AND p.pos_payment_ref IS NOT NULL
    """ + where_restaurant, params).fetchall()
    counts = Counter(checked=0, changed=0, errors=0)
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    for row in rows:
        counts["checked"] += 1
        try:
            proof = getattr(provider, "payment_proof", None)
            payment_ref = (proof(row["pos_payment_ref"], int(row["amount_cents"]))
                           if proof is not None else "")
            status = ("paid" if payment_ref else "link_sent") if proof else \
                str(provider.payment_status(row["pos_payment_ref"])).lower()
        except Exception as exc:  # provider/network error is audited, not hidden
            counts["errors"] += 1
            store.log_event("payment.reconciliation_failed",
                            restaurant_id=row["restaurant_id"],
                            order_id=row["order_id"], detail={"error": str(exc)})
            continue
        if status not in FINAL_PAYMENT_STATES or status == row["status"]:
            continue
        if status == "paid":
            # The stored reference is the Square ORDER id. A status string
            # alone cannot prove amount, currency or the payment's order id.
            if row["sink"] != "square" or proof is None:
                counts["errors"] += 1
                store.log_event("payment.reconciliation_unverified",
                                restaurant_id=row["restaurant_id"],
                                order_id=row["order_id"],
                                detail={"reason": "no matching amount-bearing "
                                        "Square payment proof"})
                continue
            if payments.mark_paid(store, row["order_id"], payment_ref):
                if release_on_paid:
                    released = payments.release_paid_order(
                        store, row["order_id"], sms=FakeSmsSender())
                    if not released.get("released"):
                        counts["errors"] += 1
        else:
            with store.tx() as conn:
                conn.execute("UPDATE payment SET status=?, settled_at=?, updated_at=? "
                             "WHERE order_id=?", (status, now, now, row["order_id"]))
        store.log_event("payment.reconciled", restaurant_id=row["restaurant_id"],
                        order_id=row["order_id"],
                        detail={"old": row["status"], "new": status,
                                "pos_ref": row["pos_payment_ref"]})
        counts["changed"] += 1
    return dict(counts)


class SquarePaymentStatus:
    """Read only the status needed for reconciliation; store no card fields."""

    def __init__(self, access_token: str, *, sandbox: bool = False,
                 opener=None, timeout: float = 15.0):
        if not access_token:
            raise ValueError("Square reconciliation needs an access token")
        self.token = access_token
        self.base = SQUARE_SANDBOX if sandbox else SQUARE_PROD
        self.opener, self.timeout = opener or urllib.request.urlopen, timeout

    def payment_status(self, pos_reference: str) -> str:
        request = urllib.request.Request(
            f"{self.base}/v2/payments/{quote(pos_reference, safe='')}",
            headers={"Authorization": f"Bearer {self.token}",
                     "Square-Version": SQUARE_VERSION,
                     "Content-Type": "application/json"})
        try:
            with self.opener(request, timeout=self.timeout) as response:
                payment = (json.loads(response.read() or b"{}").get("payment") or {})
        except urllib.error.HTTPError as exc:
            raise RuntimeError(f"Square payment lookup returned HTTP {exc.code}") from exc
        status = str(payment.get("status") or "").upper()
        refunded = int((payment.get("refunded_money") or {}).get("amount") or 0)
        total = int((payment.get("total_money") or {}).get("amount") or 0)
        if total > 0 and refunded >= total:
            return "refunded"
        return {"COMPLETED": "paid", "CANCELED": "failed",
                "FAILED": "failed", "APPROVED": "link_sent",
                "PENDING": "link_sent"}.get(status, "link_sent")

    def payment_proof(self, order_id: str, amount_cents: int) -> str:
        """Verify Square order -> tender -> payment, never an ID guess."""
        def read(path):
            request = urllib.request.Request(
                f"{self.base}{path}",
                headers={"Authorization": f"Bearer {self.token}",
                         "Square-Version": SQUARE_VERSION,
                         "Content-Type": "application/json"})
            with self.opener(request, timeout=self.timeout) as response:
                return json.loads(response.read() or b"{}")
        order = read(f"/v2/orders/{quote(order_id, safe='')}").get("order") or {}
        if order.get("id") != order_id:
            return ""
        for tender in order.get("tenders") or []:
            payment_id = tender.get("payment_id")
            if not payment_id:
                continue
            payment = read(f"/v2/payments/{quote(payment_id, safe='')}").get(
                "payment") or {}
            money = payment.get("amount_money") or {}
            if (payment.get("id") == payment_id and
                    payment.get("order_id") == order_id and
                    payment.get("status") == "COMPLETED" and
                    money.get("amount") == amount_cents and
                    money.get("currency") == "USD"):
                return str(payment_id)
        return ""


class JsonWebhook:
    def __init__(self, url: str, *, opener=None, timeout: int = 10):
        if not url.startswith("https://"):
            raise ValueError("alert webhook must use https")
        self.url, self.opener, self.timeout = url, opener or urllib.request.urlopen, timeout

    def send(self, payload: dict) -> None:
        req = urllib.request.Request(self.url,
            data=json.dumps(payload).encode(), method="POST",
            headers={"Content-Type": "application/json",
                     "User-Agent": "Cherry-Operations/1"})
        with self.opener(req, timeout=self.timeout) as response:
            if not 200 <= int(getattr(response, "status", 200)) < 300:
                raise RuntimeError(f"alert webhook returned {response.status}")


class SmsAlert:
    """Text an alert to the owner's phone(s) through Cherry's own Telnyx line.

    No third-party pager is needed: a failed call, undelivered checkout or
    failed staff transfer reaches the responsible person by SMS. Keep it short;
    it is read on a lock screen. No caller phone numbers are included.
    """

    def __init__(self, sms, phones):
        import re
        pattern = re.compile(r"^\+[1-9][0-9]{7,14}$")
        self.phones = [p.strip() for p in phones if p.strip()]
        if not self.phones:
            raise ValueError("at least one alert phone number is required")
        for phone in self.phones:
            if not pattern.fullmatch(phone):
                raise ValueError(f"alert phone {phone!r} must be E.164, e.g. +13135550100")
        self.sms = sms

    def send(self, payload: dict) -> None:
        alert = payload["alert"]
        where = f" [{alert['restaurant_id']}]" if alert.get("restaurant_id") else ""
        text = (f"Cherry {str(alert['severity']).upper()}{where}: {alert['title']}. "
                f"{alert['action']}")[:300]
        failures = []
        for phone in self.phones:
            try:
                self.sms.send(phone, text)
            except Exception as exc:                    # noqa: BLE001
                failures.append(f"{phone}: {exc}")
        if len(failures) == len(self.phones):           # nobody was reached
            raise RuntimeError("alert SMS failed for every recipient: " + "; ".join(failures))


class MultiAlertSender:
    """Send to every configured channel; fail only if none delivered, so one
    dead channel neither drops the alert nor re-pages the working one."""

    def __init__(self, senders):
        self.senders = list(senders)

    def send(self, payload: dict) -> None:
        errors = []
        for sender in self.senders:
            try:
                sender.send(payload)
            except Exception as exc:                    # noqa: BLE001
                errors.append(repr(exc))
        if len(errors) == len(self.senders):
            raise RuntimeError("every alert channel failed: " + "; ".join(errors))


def alert_sender_from_env(store=None, env=None):
    """CHERRY_ALERT_PHONE (comma-separated E.164) and/or CHERRY_ALERT_WEBHOOK."""
    env = os.environ if env is None else env
    senders = []
    url = env.get("CHERRY_ALERT_WEBHOOK", "")
    if url:
        senders.append(JsonWebhook(url))
    phones = [p for p in env.get("CHERRY_ALERT_PHONE", "").split(",") if p.strip()]
    if phones:
        from telnyx_sms import TelnyxSmsSender
        # No store: an owner who once replied STOP to a customer thread must
        # still receive pages, and opt-out tracking is per customer number.
        senders.append(SmsAlert(TelnyxSmsSender(), phones))
    if not senders:
        raise ValueError("set CHERRY_ALERT_PHONE and/or CHERRY_ALERT_WEBHOOK")
    return senders[0] if len(senders) == 1 else MultiAlertSender(senders)


def dispatch_alerts(store: OrderStore, sender, *, now=None) -> Dict[str, int]:
    """Send each current alert once; release the claim after a failed send."""
    counts = Counter(found=0, sent=0, duplicate=0, errors=0)
    for alert in ops_monitor.scan_alerts(store, now=now):
        counts["found"] += 1
        if not store.claim_webhook("ops-alert", alert.key, alert.category):
            counts["duplicate"] += 1
            continue
        try:
            sender.send({"type": "cherry.alert", "alert": asdict(alert)})
        except Exception:
            store.release_webhook("ops-alert", alert.key)
            counts["errors"] += 1
            continue
        store.log_event("ops.alert_sent", restaurant_id=alert.restaurant_id,
                        detail={"key": alert.key, "severity": alert.severity})
        counts["sent"] += 1
    return dict(counts)


def transcript_review(store: OrderStore, *, hours: int = 24) -> Dict[str, Any]:
    """Create the real-call review queue; contains no caller phone numbers."""
    since = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat(timespec="seconds")
    sessions = store.conn.execute("""
        SELECT s.id, s.restaurant_id, s.started_at, s.end_reason,
               s.escalation_reason,
               COUNT(t.id) AS turns,
               SUM(CASE WHEN t.engine_issue_code IS NOT NULL THEN 1 ELSE 0 END) AS issues,
               AVG(t.latency_ms) AS avg_latency_ms
        FROM session s LEFT JOIN turn t ON t.session_id=s.id
        WHERE s.channel='voice' AND s.started_at>=?
        GROUP BY s.id, s.restaurant_id, s.started_at, s.end_reason,
                 s.escalation_reason
        ORDER BY issues DESC, s.started_at DESC
    """, (since,)).fetchall()
    queue = []
    for row in sessions:
        reasons = []
        if int(row["issues"] or 0): reasons.append("engine_issue")
        if row["escalation_reason"]: reasons.append("escalated")
        if row["end_reason"] not in (None, "completed"): reasons.append(row["end_reason"])
        if row["avg_latency_ms"] and float(row["avg_latency_ms"]) > 1500:
            reasons.append("slow")
        if reasons:
            queue.append({"session_id": row["id"],
                          "restaurant_id": row["restaurant_id"],
                          "started_at": row["started_at"],
                          "turns": int(row["turns"] or 0),
                          "issue_turns": int(row["issues"] or 0),
                          "avg_latency_ms": (round(float(row["avg_latency_ms"]), 1)
                                             if row["avg_latency_ms"] else None),
                          "review_reasons": reasons})
    return {"window_hours": hours, "sessions": len(sessions),
            "review_count": len(queue), "review_queue": queue}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("alerts", "transcripts",
                                             "reconcile-square", "plan-review",
                                             "cost-savings", "ai-triage"))
    parser.add_argument("--db", required=True)
    parser.add_argument("--hours", type=int, default=24)
    parser.add_argument("--restaurant")
    parser.add_argument("--sandbox", action="store_true",
                        default=os.environ.get("CHERRY_SQUARE_SANDBOX") == "1")
    parser.add_argument("--apply-safe-fixes", action="store_true")
    args = parser.parse_args()
    store = OrderStore.open(args.db)
    if args.command == "alerts":
        try:
            sender = alert_sender_from_env(store)
        except ValueError as exc:
            parser.error(str(exc))
        result = dispatch_alerts(store, sender)
    elif args.command == "transcripts":
        result = transcript_review(store, hours=args.hours)
    elif args.command == "reconcile-square":
        if not args.restaurant:
            parser.error("--restaurant is required for reconcile-square")
        rid = args.restaurant.upper().replace("-", "_")
        token = vault_secret(f"SQUARE_TOKEN_{rid}")
        if not token:
            parser.error(f"SQUARE_TOKEN_{rid} is required")
        result = reconcile_payments(
            store, SquarePaymentStatus(token, sandbox=args.sandbox),
            restaurant_id=args.restaurant,
            release_on_paid=os.environ.get("CHERRY_CHECKOUT_HANDOFF_ONLY") != "1")
        # Handoff-only deployments record status without a separate kitchen
        # release. Other deployments retain the existing paid release path.
    elif args.command == "plan-review":
        result = {"plans": cost_control.plan_reviews(store)}
    elif args.command == "cost-savings":
        result = cost_control.savings_report(
            store, restaurant_id=args.restaurant or "")
    else:
        result = ai_ops_assistant.triage(
            store, apply_safe_fixes=args.apply_safe_fixes)
    print(json.dumps(result, indent=2, default=str))
    return 2 if result.get("errors") else 0


if __name__ == "__main__":
    raise SystemExit(main())
