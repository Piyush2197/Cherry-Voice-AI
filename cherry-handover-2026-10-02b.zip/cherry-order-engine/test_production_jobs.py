#!/usr/bin/env python3
"""Production job regressions: paging, POS reconciliation and call review."""

from __future__ import annotations

import traceback
from datetime import datetime, timedelta, timezone
from pathlib import Path
import json

import menu_schema as ms
import production_jobs as jobs
from order_engine import OrderEngine
from order_store import OrderStore

HERE = Path(__file__).resolve().parent
_passed = _failed = 0


def check(name, condition, detail=""):
    global _passed, _failed
    if condition: _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


def fixture():
    store = OrderStore.sqlite()
    path = HERE / "menus" / "tamago-sushi-bowl.yaml"
    cfg = ms.load_yaml(path)
    store.upsert_restaurant(cfg.id, cfg.name, cfg.cuisine,
                            inbound_phone="+13135550111", active=True)
    mv = store.publish_menu(cfg.id, path.read_text(), item_count=len(cfg.items))
    return store, cfg, mv


def make_order(store, cfg, mv):
    engine = OrderEngine(cfg); engine.add_line("tg_edamame")
    return store.place_order(cfg.id, mv, engine.to_normalized_order())[0]


def t_payment_reconciliation_updates_and_audits_final_state():
    store, cfg, mv = fixture(); oid = make_order(store, cfg, mv)
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    with store.tx() as conn:
        conn.execute("INSERT INTO payment (order_id,method,status,amount_cents,"
                     "pos_payment_ref,updated_at) VALUES "
                     "(?,'pay_link','link_sent',530,'pos-1',?)", (oid, now))
    class Provider:
        def payment_status(self, ref): return "paid"
    result = jobs.reconcile_payments(store, Provider())
    row = store.conn.execute("SELECT status FROM payment WHERE order_id=?", (oid,)).fetchone()
    check("status-only paid claim is flagged, not trusted",
          result["changed"] == 0 and result["errors"] == 1)
    check("order remains unpaid until signed amount-bearing webhook",
          row["status"] == "link_sent")
    check("unverified reconciliation is audited", bool(store.events(
        "payment.reconciliation_unverified", order_id=oid)))


def t_handoff_only_reconciliation_never_releases_a_kitchen_order():
    store, cfg, mv = fixture(); oid = make_order(store, cfg, mv)
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    with store.tx() as conn:
        conn.execute("UPDATE restaurant SET sink='square' WHERE id=?", (cfg.id,))
        conn.execute("INSERT INTO payment (order_id,method,status,amount_cents,"
                     "pos_payment_ref,updated_at) VALUES "
                     "(?,'pay_link','link_sent',530,'square-order-1',?)", (oid, now))
    class Provider:
        def payment_proof(self, ref, amount):
            return "square-payment-1" if ref == "square-order-1" and amount == 530 else ""
    result = jobs.reconcile_payments(store, Provider(), release_on_paid=False)
    payment = store.conn.execute("SELECT status FROM payment WHERE order_id=?",
                                 (oid,)).fetchone()
    delivery = store.conn.execute("SELECT 1 FROM order_delivery WHERE order_id=?",
                                  (oid,)).fetchone()
    check("handoff-only may record paid status", result["changed"] == 1 and
          payment["status"] == "paid", str(result))
    check("handoff-only never sends a separate kitchen ticket", delivery is None)


def t_square_status_lookup_uses_read_only_payment_endpoint():
    seen = {}
    class Response:
        status = 200
        def __enter__(self): return self
        def __exit__(self, *_): return False
        def read(self):
            return json.dumps({"payment": {"status": "COMPLETED",
                               "total_money": {"amount": 530}}}).encode()
    def open_(request, timeout):
        seen["url"] = request.full_url
        seen["authorization"] = request.headers.get("Authorization")
        return Response()
    provider = jobs.SquarePaymentStatus("merchant-token", opener=open_)
    check("Square completed payment maps to Cherry paid",
          provider.payment_status("pay/id") == "paid")
    check("Square lookup escapes the payment id and authenticates",
          seen["url"].endswith("/v2/payments/pay%2Fid") and
          seen["authorization"] == "Bearer merchant-token", str(seen))


def t_square_full_refund_maps_to_refunded():
    class Response:
        def __enter__(self): return self
        def __exit__(self, *_): return False
        def read(self):
            return b'{"payment":{"status":"COMPLETED","total_money":{"amount":530},"refunded_money":{"amount":530}}}'
    provider = jobs.SquarePaymentStatus("merchant-token", opener=lambda *_a, **_k: Response())
    check("fully refunded Square payment maps to refunded",
          provider.payment_status("pay-1") == "refunded")


def t_square_reconciliation_verifies_order_tender_payment_and_amount():
    seen = []
    class Response:
        def __init__(self, data): self.data = data
        def __enter__(self): return self
        def __exit__(self, *_): return False
        def read(self): return json.dumps(self.data).encode()
    def open_(request, timeout):
        seen.append(request.full_url)
        if "/orders/" in request.full_url:
            return Response({"order": {"id": "order-1", "tenders": [
                {"payment_id": "pay-1"}]}})
        return Response({"payment": {"id": "pay-1", "order_id": "order-1",
                          "status": "COMPLETED", "amount_money": {
                              "amount": 530, "currency": "USD"}}})
    provider = jobs.SquarePaymentStatus("token", opener=open_)
    check("matching Square order and payment is verified",
          provider.payment_proof("order-1", 530) == "pay-1")
    check("wrong amount refuses paid proof",
          provider.payment_proof("order-1", 531) == "")
    check("order id is resolved before payment id", "/orders/order-1" in seen[0]
          and "/payments/pay-1" in seen[1], str(seen))


def t_alert_dispatch_is_exactly_once_and_retries_failures():
    store, cfg, mv = fixture(); oid = make_order(store, cfg, mv)
    store.record_delivery(oid, "manual", "failed", error_kind="connection",
                          error_detail="offline")
    class Sender:
        def __init__(self): self.sent=[]
        def send(self, payload): self.sent.append(payload)
    sender=Sender(); first=jobs.dispatch_alerts(store, sender); second=jobs.dispatch_alerts(store, sender)
    check("one current alert is delivered", first["sent"] == 1, str(first))
    check("stable alert key prevents repeat paging", second["duplicate"] == 1, str(second))
    check("page contains an operational action", bool(sender.sent[0]["alert"]["action"]))


def t_transcript_review_selects_real_problem_calls_without_identity():
    store, cfg, mv = fixture()
    sid = store.start_session(cfg.id, mv, external_id="provider-secret",
                              caller_phone="+13135559999")
    store.record_turn(sid, "agent", "Please repeat that", intent="add_item",
                      engine_issue_code="ambiguous", latency_ms=2001)
    store.end_session(sid, "escalated")
    report = jobs.transcript_review(store)
    encoded = str(report)
    check("problem call enters review queue", report["review_count"] == 1, encoded)
    check("review reports both accuracy and latency reasons",
          {"engine_issue", "slow", "escalated"} <= set(report["review_queue"][0]["review_reasons"]))
    check("review contains no customer or provider identity",
          "+13135559999" not in encoded and "provider-secret" not in encoded)


def t_sms_alert_channel():
    class Sms:
        def __init__(self, fail=()): self.sent, self.fail = [], set(fail)
        def send(self, to, body):
            if to in self.fail: raise RuntimeError("blocked")
            self.sent.append((to, body))
    alert = {"alert": {"severity": "critical", "restaurant_id": "r1",
                       "title": "Staff transfer failed", "action": "Call the restaurant."}}
    sms = Sms()
    jobs.SmsAlert(sms, ["+13135550100", "+13135550101"]).send(alert)
    check("every recipient is texted", [p for p, _ in sms.sent] == ["+13135550100", "+13135550101"])
    check("text is short, severity first, no call detail",
          sms.sent[0][1].startswith("Cherry CRITICAL [r1]:") and len(sms.sent[0][1]) <= 300)
    partial = Sms(fail={"+13135550100"})
    jobs.SmsAlert(partial, ["+13135550100", "+13135550101"]).send(alert)
    check("one reachable recipient is enough", len(partial.sent) == 1)
    try:
        jobs.SmsAlert(Sms(fail={"+13135550100"}), ["+13135550100"]).send(alert)
        check("all recipients failing raises so the alert is retried", False)
    except RuntimeError:
        check("all recipients failing raises so the alert is retried", True)
    for bad in ([], ["3135550100"], ["+0123"]):
        try:
            jobs.SmsAlert(Sms(), bad); check(f"bad phone list {bad} refused", False)
        except ValueError:
            check(f"bad phone list {bad} refused", True)
    check("sender selection needs a channel",
          not _raises_nothing(lambda: jobs.alert_sender_from_env(env={})))
    check("webhook channel still works",
          isinstance(jobs.alert_sender_from_env(env={"CHERRY_ALERT_WEBHOOK": "https://x.example/h"}),
                     jobs.JsonWebhook))


def _raises_nothing(fn):
    try: fn(); return True
    except ValueError: return False


def main():
    for name, fn in sorted(globals().items()):
        if name.startswith("t_"):
            try: fn()
            except Exception:
                global _failed; _failed += 1
                print(f"\n--- FAIL {name}\n{traceback.format_exc()}")
    print(f"\n{_passed} passed, {_failed} failed (production jobs)")
    return 1 if _failed else 0


if __name__ == "__main__": raise SystemExit(main())
