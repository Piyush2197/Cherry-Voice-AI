#!/usr/bin/env python3
"""The tablet kitchen display: one iPad page per restaurant, no app store.

Covers the whole path over a real socket: key scoping, the page, the orders
feed (with the asked-for / asked-with separation), and staff acceptance.
"""
from __future__ import annotations

import json
import os
import tempfile
import threading
import time
import urllib.request
import unittest
from pathlib import Path

import payments
from dev_checkout import DevCheckoutProvider
from sinks import FakeSmsSender
import server as srv
from order_engine import OrderEngine
from order_store import OrderStore

import menu_schema as ms

HERE = Path(__file__).parent


def make_order(store, path="menus/bun-n-run-ferndale.yaml"):
    cfg = ms.load_yaml(HERE / path)
    store.upsert_restaurant(cfg.id, cfg.name, cfg.cuisine, sink="manual",
                            tax_rate_bps=cfg.tax_rate_bps,
                            staff_phone="+13135550999", active=True)
    mv = store.publish_menu(cfg.id, path, item_count=len(cfg.items))
    engine = OrderEngine(cfg)
    line = engine.add_line("double_cheeseburger")
    for gid in engine.active_group_ids(line):
        group = cfg.group(gid)
        if group and group.required:
            engine.apply_option(line.line_id, gid, group.option_ids[0])
    snap = engine.to_normalized_order()
    oid, code = store.place_order(cfg.id, mv, snap,
                                  customer_phone="+13135550123")
    payments.arrange_payment(store, oid, sms=FakeSmsSender(),
                             provider=DevCheckoutProvider())
    assert payments.mark_paid(store, oid, "dev-kds")
    rel = payments.release_paid_order(store, oid, sms=FakeSmsSender())
    assert rel["released"], rel
    return cfg.id, oid, code, snap["total_cents"]


class TestTabletDisplay(unittest.TestCase):
    PORT = 8971
    KEY = "kds-test-secret"

    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        db = os.path.join(cls.tmp.name, "cherry.db")
        store = OrderStore.sqlite(db)
        cls.rid, cls.oid, cls.code, cls.total = make_order(store)
        cls.app = srv.Cherry(store, api_key=cls.KEY, dev_checkout=True)
        cls.httpd = srv.build_server(cls.app, cls.PORT)
        cls.httpd.app = cls.app
        cls.t = threading.Thread(target=cls.httpd.serve_forever, daemon=True)
        cls.t.start()
        time.sleep(0.2)
        cls.base = f"http://127.0.0.1:{cls.PORT}"

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.tmp.cleanup()

    def get(self, path, expect=200):
        try:
            with urllib.request.urlopen(self.base + path) as r:
                return r.status, r.read().decode()
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode()

    def post(self, path):
        req = urllib.request.Request(self.base + path, data=b"", method="POST")
        try:
            with urllib.request.urlopen(req) as r:
                return r.status, r.read().decode()
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode()

    def acknowledged(self, rid, code):
        k = srv.kds_key(self.KEY, rid)
        _, body = self.get(f"/kds/orders?r={rid}&k={k}")
        return {o["code"]: o["acknowledged"] for o in json.loads(body)["orders"]}[code]

    def test_key_is_derived_and_scoped(self):
        self.assertEqual(len(srv.kds_key(self.KEY, self.rid)), 16)
        self.assertNotEqual(srv.kds_key(self.KEY, self.rid),
                            srv.kds_key(self.KEY, "other-restaurant"))
        self.assertEqual(srv.kds_key("", self.rid), "",
                         "no server secret -> no display keys")

    def test_page_serves_with_key_and_refuses_without(self):
        good = f"/kds?r={self.rid}&k={srv.kds_key(self.KEY, self.rid)}"
        status, html = self.get(good)
        self.assertEqual(status, 200)
        self.assertIn("kitchen display", html)
        self.assertIn(self.rid, html)
        status, _ = self.get(f"/kds?r={self.rid}&k=wrong")
        self.assertEqual(status, 403)
        status, _ = self.get(f"/kds?r=other-restaurant&k={srv.kds_key(self.KEY, 'other-restaurant')}")
        self.assertEqual(status, 404, "key for another restaurant must not open this one")

    def test_orders_feed_shows_released_order_kitchen_only(self):
        k = srv.kds_key(self.KEY, self.rid)
        status, body = self.get(f"/kds/orders?r={self.rid}&k={k}")
        self.assertEqual(status, 200)
        data = json.loads(body)
        self.assertEqual(len(data["orders"]), 1)
        o = data["orders"][0]
        self.assertEqual(o["code"], self.code)
        self.assertEqual(o["total_cents"], self.total)
        self.assertFalse(o["acknowledged"])
        # kitchen-only: no caller phone, no transcript anywhere in the feed
        self.assertNotIn("+13135550123", body)
        self.assertNotIn("customer_phone", body)
        # the asked-for / ships-with separation survives into the feed
        line = o["lines"][0]
        self.assertIn("onion", " ".join(line["defaults"]).lower())

    def test_staff_accept_via_tablet_marks_acknowledged(self):
        k = srv.kds_key(self.KEY, self.rid)
        req = urllib.request.Request(
            f"{self.base}/t/{self.code}/accept", data=b"", method="POST")
        with urllib.request.urlopen(req) as r:
            self.assertEqual(r.status, 200)
        status, body = self.get(f"/kds/orders?r={self.rid}&k={k}")
        o = json.loads(body)["orders"][0]
        self.assertTrue(o["acknowledged"])

    def test_keyed_accept_refuses_a_bad_missing_or_foreign_key(self):
        other = srv.kds_key(self.KEY, "other-restaurant")
        for q in (f"r={self.rid}&k=nope&code={self.code}",
                  f"r={self.rid}&code={self.code}",
                  f"r=other-restaurant&k={other}&code={self.code}"):
            status, _ = self.post("/kds/accept?" + q)
            self.assertIn(status, (403, 404), q)
        self.assertFalse(self.acknowledged(self.rid, self.code),
                         "a refused request must not acknowledge anything")

    def test_tablet_accept_is_keyed_scoped_and_idempotent(self):
        rid, _, code, _ = make_order(self.app.store)       # a fresh, unacknowledged order
        k = srv.kds_key(self.KEY, rid)
        self.assertFalse(self.acknowledged(rid, code))
        status, body = self.post(f"/kds/accept?r={rid}&k={k}&code={code}")
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(body), {"ok": True, "already": False})
        self.assertTrue(self.acknowledged(rid, code))
        status, body = self.post(f"/kds/accept?r={rid}&k={k}&code={code}")
        self.assertEqual((status, json.loads(body)["already"]), (200, True))
        status, _ = self.post(f"/kds/accept?r={rid}&k={k}&code=0000")
        self.assertEqual(status, 404, "an unknown code is a 404, not a crash")

    def test_the_tablet_page_uses_the_keyed_endpoint_not_the_open_one(self):
        _, html = self.get(f"/kds?r={self.rid}&k={srv.kds_key(self.KEY, self.rid)}")
        self.assertIn("/kds/accept?", html)
        self.assertNotIn("/t/", html, "the page must not depend on the unscoped four-digit route")

    def test_bad_key_on_feed_refused(self):
        status, _ = self.get(f"/kds/orders?r={self.rid}&k=nope")
        self.assertEqual(status, 403)


if __name__ == "__main__":
    unittest.main(verbosity=1)
