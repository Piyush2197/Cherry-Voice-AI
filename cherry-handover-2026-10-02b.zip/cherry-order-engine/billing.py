#!/usr/bin/env python3
"""Subscription billing: what each location owes Cherry, ready for QuickBooks.

Cherry never touches a restaurant's money (customers pay the restaurant's own
checkout). This is the other direction — the restaurant's subscription to
Cherry. It does the part that is error-prone by hand and leaves the rest where
the founder put it: **invoices are created and collected in QuickBooks** (card
or ACH). Here:

  * a price book (`billing/price_book.yaml`: Small $399 / Medium $499 / Large
    $649, annual $349 / $469 / $649 paid up front, Large annual-only, onboarding
    $500 or $1,000 and waived on annual) — change a price in the file, not in code;
  * one contract per location: plan, monthly or annual term, go-live date;
  * a monthly run that issues each invoice exactly once, however often it is
    run and however many months were missed;
  * credits and one-off charges that ride on the next invoice;
  * an export QuickBooks can import, and the deferred-revenue schedule an
    annual prepayment needs.

Billing is by **anniversary**: a contract that goes live on the 15th is invoiced
on the 15th, in advance, each month (an annual one every 12 months). Nothing is
prorated, so there is no half-month arithmetic to get wrong. Overage does not
exist (the plans promise "no surprise overage"): usage appears on the invoice as
a memo and in `cost_control`'s plan reviews, and never as a charge.

    python3 billing.py --db cherry.db contract set --restaurant pink-garlic-shelby \\
        --customer "Pink Garlic" --plan small --term monthly --starts 2026-10-15
    python3 billing.py --db cherry.db run --dry-run         # what would be issued today
    python3 billing.py --db cherry.db run
    python3 billing.py --db cherry.db export --out invoices.csv --mark-exported
    python3 billing.py --db cherry.db report --month 2026-11

Run `run` from cron daily; it is idempotent. NOT YET USED IN PRODUCTION: the first
real run should be read line by line against the signed contracts before anything
is imported into QuickBooks.
"""

from __future__ import annotations

import _ensure_deps  # noqa: F401  (re-runs under .venv, or says how to install, if PyYAML is missing)
import argparse
import calendar
import csv
import io
import json
import sys
import threading
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional

import yaml

ROOT = Path(__file__).resolve().parent
PRICE_BOOK = ROOT / "billing" / "price_book.yaml"
PLAN_ALIASES = {"grande": "large"}          # cost_control's older name for the top plan
ONBOARDING_ANNUAL_RULES = ("waive", "halve", "full")
_MAX_PERIODS = 1200


class BillingError(ValueError):
    pass


# ---------------------------------------------------------------------------
# the price book
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Plan:
    key: str
    name: str
    calls_per_day: int
    monthly_cents: int
    annual_monthly_cents: int
    monthly_allowed: bool
    annual_allowed: bool


@dataclass(frozen=True)
class Book:
    effective_from: date
    plans: Mapping[str, Plan]
    onboarding_independent: int
    onboarding_multi: int
    onboarding_annual: str
    payment_terms_days: int


def _int(value: Any, what: str, *, minimum: int = 0) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise BillingError(f"{what} must be a whole number of at least {minimum}, got {value!r}")
    return value


def load_price_book(path: Path = PRICE_BOOK) -> List[Book]:
    doc = yaml.safe_load(Path(path).read_text())
    if not isinstance(doc, dict) or doc.get("schema_version") != 1:
        raise BillingError("price book must have schema_version: 1")
    if doc.get("currency") != "USD":
        raise BillingError("price book currency must be USD")
    raw = doc.get("books")
    if not isinstance(raw, list) or not raw:
        raise BillingError("price book has no books")
    books: List[Book] = []
    for n, b in enumerate(raw):
        try:
            eff = date.fromisoformat(str(b["effective_from"]))
        except (KeyError, ValueError):
            raise BillingError(f"books[{n}].effective_from must be YYYY-MM-DD") from None
        plans: Dict[str, Plan] = {}
        for key, p in (b.get("plans") or {}).items():
            where = f"books[{n}].plans.{key}"
            monthly = _int(p.get("monthly_cents"), f"{where}.monthly_cents")
            annual = _int(p.get("annual_monthly_cents"), f"{where}.annual_monthly_cents")
            if annual > monthly:
                raise BillingError(f"{where}: the annual per-month price ({annual}) is higher than monthly ({monthly})")
            plans[key] = Plan(key, str(p.get("name") or key.title()), _int(p.get("calls_per_day"), f"{where}.calls_per_day", minimum=1),
                              monthly, annual, bool(p.get("monthly_allowed", True)), bool(p.get("annual_allowed", True)))
            if not (plans[key].monthly_allowed or plans[key].annual_allowed):
                raise BillingError(f"{where} cannot be sold at all")
        if not plans:
            raise BillingError(f"books[{n}] has no plans")
        ob = b.get("onboarding") or {}
        rule = str(ob.get("annual_term", "waive"))
        if rule not in ONBOARDING_ANNUAL_RULES:
            raise BillingError(f"books[{n}].onboarding.annual_term must be one of {ONBOARDING_ANNUAL_RULES}")
        books.append(Book(eff, plans, _int(ob.get("independent_cents"), f"books[{n}].onboarding.independent_cents"),
                          _int(ob.get("multi_location_cents"), f"books[{n}].onboarding.multi_location_cents"), rule,
                          _int(b.get("payment_terms_days", 0), f"books[{n}].payment_terms_days")))
    books.sort(key=lambda x: x.effective_from)
    if len({b.effective_from for b in books}) != len(books):
        raise BillingError("two books share an effective_from date")
    return books


def book_for(books: List[Book], on: date) -> Book:
    current = [b for b in books if b.effective_from <= on]
    if not current:
        raise BillingError(f"no price book is in effect on {on}")
    return current[-1]


def plan_key(value: str) -> str:
    key = str(value or "").strip().lower()
    return PLAN_ALIASES.get(key, key)


# ---------------------------------------------------------------------------
# dates
# ---------------------------------------------------------------------------

def parse_day(value: Any, what: str = "date") -> date:
    try:
        return value if isinstance(value, date) else date.fromisoformat(str(value))
    except ValueError:
        raise BillingError(f"{what} must be YYYY-MM-DD, got {value!r}") from None


def add_months(d: date, n: int) -> date:
    """``d`` plus ``n`` months, on the same day of the month where the month has it
    and its last day where it does not. Always add to the ORIGINAL date (never to
    a previous result), so Jan 31 gives Feb 28, then Mar 31, then Apr 30."""
    total = d.year * 12 + (d.month - 1) + n
    year, month = divmod(total, 12)
    month += 1
    return date(year, month, min(d.day, calendar.monthrange(year, month)[1]))


def period_bounds(starts_on: date, term: str, k: int) -> tuple:
    step = 12 if term == "annual" else 1
    start = add_months(starts_on, k * step)
    end = add_months(starts_on, (k + 1) * step) - timedelta(days=1)
    return start, end


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


# ---------------------------------------------------------------------------
# contracts
# ---------------------------------------------------------------------------

def get_contract(store, restaurant_id: str) -> Optional[dict]:
    row = store.conn.execute("SELECT * FROM billing_contract WHERE restaurant_id=?", (restaurant_id,)).fetchone()
    return dict(row) if row else None


def list_contracts(store) -> List[dict]:
    return [dict(r) for r in store.conn.execute("SELECT * FROM billing_contract ORDER BY customer, restaurant_id").fetchall()]


def _has_invoices(store, restaurant_id: str) -> bool:
    return store.conn.execute("SELECT 1 FROM invoice WHERE restaurant_id=? LIMIT 1", (restaurant_id,)).fetchone() is not None


def set_contract(store, restaurant_id: str, *, customer: str, plan: str, term: str, starts_on: Any,
                 billing_email: str = "", multi_location: bool = False,
                 onboarding_fee_cents: Optional[int] = None, price_override_cents: Optional[int] = None,
                 notes: str = "", books: Optional[List[Book]] = None) -> dict:
    """Create or update a location's contract. Changing the plan only affects
    periods that have not been invoiced; the start date and term cannot change
    once an invoice exists (cancel and write a new contract instead)."""
    books = books or load_price_book()
    if store.restaurant(restaurant_id) is None:
        raise BillingError(f"unknown restaurant {restaurant_id!r}")
    customer = (customer or "").strip()
    if not customer:
        raise BillingError("a customer name is required (it becomes the QuickBooks customer)")
    key, term = plan_key(plan), str(term or "").strip().lower()
    starts = parse_day(starts_on, "starts_on")
    if term not in ("monthly", "annual"):
        raise BillingError("term must be monthly or annual")
    book = book_for(books, starts)
    if key not in book.plans:
        raise BillingError(f"unknown plan {plan!r}; expected one of {', '.join(sorted(book.plans))}")
    p = book.plans[key]
    if term == "monthly" and not p.monthly_allowed:
        raise BillingError(f"the {p.name} plan is annual only")
    if term == "annual" and not p.annual_allowed:
        raise BillingError(f"the {p.name} plan cannot be taken annually")
    for what, val in (("onboarding_fee_cents", onboarding_fee_cents), ("price_override_cents", price_override_cents)):
        if val is not None:
            _int(val, what)
    if price_override_cents is not None and price_override_cents > p.monthly_cents:
        raise BillingError("a negotiated price above the list price is almost certainly a typo; raise the list price instead")
    existing = get_contract(store, restaurant_id)
    if existing and _has_invoices(store, restaurant_id):
        if existing["starts_on"] != starts.isoformat() or existing["term"] != term:
            raise BillingError("the start date and term cannot change once an invoice exists: cancel this contract and start a new one")
    now = _now()
    with store.tx() as c:
        c.execute("""INSERT INTO billing_contract
            (restaurant_id, customer, billing_email, plan, term, starts_on, multi_location,
             onboarding_fee_cents, price_override_cents, notes, created_at, updated_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT (restaurant_id) DO UPDATE SET
              customer=excluded.customer, billing_email=excluded.billing_email, plan=excluded.plan,
              term=excluded.term, starts_on=excluded.starts_on, multi_location=excluded.multi_location,
              onboarding_fee_cents=excluded.onboarding_fee_cents, price_override_cents=excluded.price_override_cents,
              notes=excluded.notes, updated_at=excluded.updated_at""",
                  (restaurant_id, customer, billing_email.strip() or None, key, term, starts.isoformat(),
                   bool(multi_location), onboarding_fee_cents, price_override_cents, notes or None, now, now))
    store.log_event("billing.contract_set", restaurant_id=restaurant_id,
                    detail={"plan": key, "term": term, "starts_on": starts.isoformat()})
    return get_contract(store, restaurant_id)


def set_status(store, restaurant_id: str, status: str, *, on: Optional[Any] = None) -> dict:
    """``pause`` stops new invoices; ``resume --on D`` restarts them from the first
    period that begins on or after D (paused months are NOT back-billed); ``cancel
    --on D`` stops every period that would begin on or after D."""
    c = get_contract(store, restaurant_id)
    if c is None:
        raise BillingError(f"{restaurant_id} has no billing contract")
    day = parse_day(on, "date").isoformat() if on else date.today().isoformat()
    if status == "paused":
        sql, params = "UPDATE billing_contract SET status='paused', updated_at=? WHERE restaurant_id=?", (_now(), restaurant_id)
    elif status == "active":
        if c["status"] == "cancelled":
            raise BillingError("a cancelled contract cannot be resumed: write a new one")
        sql, params = ("UPDATE billing_contract SET status='active', bill_from=?, updated_at=? WHERE restaurant_id=?",
                       (day, _now(), restaurant_id))
    elif status == "cancelled":
        sql, params = ("UPDATE billing_contract SET status='cancelled', ends_on=?, updated_at=? WHERE restaurant_id=?",
                       (day, _now(), restaurant_id))
    else:
        raise BillingError(f"unknown status {status!r}")
    with store.tx() as conn:
        conn.execute(sql, params)
    store.log_event("billing.contract_" + status, restaurant_id=restaurant_id, detail={"on": day})
    return get_contract(store, restaurant_id)


def add_adjustment(store, restaurant_id: str, cents: int, memo: str) -> int:
    """A credit (negative) or one-off charge (positive) that rides on the NEXT invoice."""
    if get_contract(store, restaurant_id) is None:
        raise BillingError(f"{restaurant_id} has no billing contract")
    if isinstance(cents, bool) or not isinstance(cents, int) or cents == 0:
        raise BillingError("an adjustment is a non-zero whole number of cents (negative = credit)")
    if not (memo or "").strip():
        raise BillingError("an adjustment needs a memo: it is printed on the invoice")
    with store.tx() as conn:
        cur = conn.execute("INSERT INTO billing_adjustment (restaurant_id, amount_cents, memo, created_at) VALUES (?,?,?,?)",
                           (restaurant_id, cents, memo.strip(), _now()))
        new_id = int(cur.lastrowid)
    store.log_event("billing.adjustment", restaurant_id=restaurant_id, detail={"cents": cents, "memo": memo.strip()[:200]})
    return new_id


def pending_adjustments(store, restaurant_id: str) -> List[dict]:
    return [dict(r) for r in store.conn.execute(
        "SELECT * FROM billing_adjustment WHERE restaurant_id=? AND applied_invoice_id IS NULL ORDER BY id", (restaurant_id,)).fetchall()]


# ---------------------------------------------------------------------------
# building and issuing invoices
# ---------------------------------------------------------------------------

def monthly_equivalent_cents(contract: Mapping, plan: Plan) -> int:
    """What this location pays per month of service."""
    if contract.get("price_override_cents") is not None:
        return int(contract["price_override_cents"])
    return plan.annual_monthly_cents if contract["term"] == "annual" else plan.monthly_cents


def onboarding_fee_cents(contract: Mapping, book: Book) -> int:
    if contract.get("onboarding_fee_cents") is not None:
        return int(contract["onboarding_fee_cents"])
    fee = book.onboarding_multi if contract.get("multi_location") else book.onboarding_independent
    if contract["term"] == "annual":
        return {"waive": 0, "halve": fee // 2, "full": fee}[book.onboarding_annual]
    return fee


def usage_memo(store, restaurant_id: str, before: date, days: int = 30) -> str:
    """A courtesy line: how busy the line was. Never a charge."""
    since = (before - timedelta(days=days)).isoformat()
    row = store.conn.execute("SELECT COUNT(*) AS n FROM session WHERE restaurant_id=? AND channel='voice' "
                             "AND started_at >= ? AND started_at < ?", (restaurant_id, since, before.isoformat())).fetchone()
    n = int(row["n"]) if row else 0
    return f"Last {days} days: about {n / days:.0f} calls a day." if n else ""


def build_invoice(store, contract: Mapping, k: int, books: List[Book], *, restaurant_name: str = "",
                  pending: Optional[List[dict]] = None, first: bool = False) -> dict:
    """The invoice for period ``k`` of a contract, not yet saved."""
    starts = parse_day(contract["starts_on"])
    start, end = period_bounds(starts, contract["term"], k)
    book = book_for(books, start)
    key = plan_key(contract["plan"])
    if key not in book.plans:
        raise BillingError(f"plan {key!r} is not in the price book in effect on {start}")
    plan = book.plans[key]
    if contract["term"] == "monthly" and not plan.monthly_allowed:
        raise BillingError(f"the {plan.name} plan is annual only (price book of {book.effective_from})")
    each = monthly_equivalent_cents(contract, plan)
    months = 12 if contract["term"] == "annual" else 1
    where = f" — {restaurant_name}" if restaurant_name else ""
    lines: List[dict] = [{
        "kind": "subscription", "item": f"Cherry Subscription - {plan.name}",
        "description": (f"Cherry {plan.name} plan{where}, {'12 months paid in full' if months == 12 else 'monthly'}: "
                        f"{start:%b} {start.day}, {start.year} to {end:%b} {end.day}, {end.year}"),
        "quantity": months, "unit_cents": each, "amount_cents": months * each}]
    if first:
        fee = onboarding_fee_cents(contract, book)
        if fee:
            lines.append({"kind": "onboarding", "item": "Cherry Onboarding",
                          "description": f"One-time onboarding and setup{where}", "quantity": 1, "unit_cents": fee, "amount_cents": fee})
    total = sum(x["amount_cents"] for x in lines)
    applied: List[dict] = []
    for adj in pending or []:
        amount = int(adj["amount_cents"])
        take = amount
        if total + amount < 0:                 # an invoice never goes below zero: the rest of the credit waits
            take = -total
            if take == 0:
                continue
            adj = {**adj, "_remainder": amount - take}
        applied.append({**adj, "_taken": take})
        total += take
        lines.append({"kind": "adjustment", "item": "Cherry Adjustment",
                      "description": adj["memo"] + (" (part of a larger credit)" if "_remainder" in adj else ""),
                      "quantity": 1, "unit_cents": take, "amount_cents": take})
    memo_bits = [f"Plan: {plan.name} (up to {plan.calls_per_day} calls a day, no overage charges)."]
    usage = usage_memo(store, contract["restaurant_id"], start)
    if usage:
        memo_bits.append(usage)
    return {"restaurant_id": contract["restaurant_id"], "customer": contract["customer"], "plan": key, "term": contract["term"],
            "period_start": start.isoformat(), "period_end": end.isoformat(), "issued_on": start.isoformat(),
            "due_on": (start + timedelta(days=book.payment_terms_days)).isoformat(),
            "total_cents": total, "memo": " ".join(memo_bits), "lines": lines, "_applied": applied,
            "_location": restaurant_name}


def _next_number(conn, year: int) -> str:
    row = conn.execute("SELECT COALESCE(MAX(CAST(SUBSTR(number, 9) AS INTEGER)), 0) AS n FROM invoice WHERE number LIKE ?",
                       (f"CH-{year}-%",)).fetchone()
    return f"CH-{year}-{int(row['n']) + 1:04d}"


_issue_lock = threading.Lock()


def issue(store, inv: dict) -> Optional[str]:
    """Save an invoice. Returns its number, or None if that period already has one."""
    with _issue_lock:
        with store.tx() as c:
            if c.execute("SELECT 1 FROM invoice WHERE restaurant_id=? AND period_start=?",
                         (inv["restaurant_id"], inv["period_start"])).fetchone():
                return None
            number = _next_number(c, parse_day(inv["issued_on"]).year)
            cur = c.execute("""INSERT INTO invoice (number, restaurant_id, customer, plan, term, period_start, period_end,
                               issued_on, due_on, status, total_cents, memo, created_at)
                               VALUES (?,?,?,?,?,?,?,?,?,'issued',?,?,?)""",
                            (number, inv["restaurant_id"], inv["customer"], inv["plan"], inv["term"], inv["period_start"],
                             inv["period_end"], inv["issued_on"], inv["due_on"], inv["total_cents"], inv["memo"], _now()))
            iid = int(cur.lastrowid)
            for seq, ln in enumerate(inv["lines"], 1):
                c.execute("""INSERT INTO invoice_line (invoice_id, seq, kind, item, description, quantity, unit_cents, amount_cents)
                             VALUES (?,?,?,?,?,?,?,?)""", (iid, seq, ln["kind"], ln["item"], ln["description"],
                                                           ln["quantity"], ln["unit_cents"], ln["amount_cents"]))
            for adj in inv["_applied"]:
                done = c.execute("UPDATE billing_adjustment SET applied_invoice_id=?, amount_cents=? "
                                 "WHERE id=? AND applied_invoice_id IS NULL", (iid, adj["_taken"], adj["id"]))
                if done.rowcount != 1:
                    raise BillingError(f"adjustment {adj['id']} was applied by someone else; run again")
                if adj.get("_remainder"):          # the rest of a credit too big for this invoice waits for the next
                    c.execute("INSERT INTO billing_adjustment (restaurant_id, amount_cents, memo, created_at) VALUES (?,?,?,?)",
                              (inv["restaurant_id"], adj["_remainder"], adj["memo"], _now()))
    store.log_event("billing.invoice_issued", restaurant_id=inv["restaurant_id"],
                    detail={"number": number, "total_cents": inv["total_cents"], "period_start": inv["period_start"]})
    return number


def due_periods(store, contract: Mapping, today: date, *, lead_days: int = 0) -> List[int]:
    """Period numbers of this contract that should be invoiced by ``today`` and are not yet."""
    if contract["status"] == "paused" or (contract["status"] == "cancelled" and not contract.get("ends_on")):
        return []                       # a cancelled contract still owes the periods that begin before its end date
    starts = parse_day(contract["starts_on"])
    bill_from = parse_day(contract["bill_from"]) if contract.get("bill_from") else starts
    ends = parse_day(contract["ends_on"]) if contract.get("ends_on") else None
    have = {r["period_start"] for r in store.conn.execute(
        "SELECT period_start FROM invoice WHERE restaurant_id=?", (contract["restaurant_id"],)).fetchall()}
    out = []
    for k in range(_MAX_PERIODS):
        start, _end = period_bounds(starts, contract["term"], k)
        if start - timedelta(days=lead_days) > today or (ends and start >= ends):
            break
        if start >= bill_from and start.isoformat() not in have:
            out.append(k)
    return out


def run(store, *, today: Optional[date] = None, lead_days: int = 0, dry_run: bool = False,
        only: Optional[List[str]] = None, books: Optional[List[Book]] = None) -> dict:
    """Issue every invoice that is due. Safe to run any number of times: a period
    that already has an invoice (even a voided one) is never invoiced again."""
    today = today or date.today()
    books = books or load_price_book()
    created, problems = [], []
    for contract in list_contracts(store):
        if only and contract["restaurant_id"] not in only:
            continue
        rest = store.restaurant(contract["restaurant_id"])
        name = rest["name"] if rest else ""
        for k in due_periods(store, contract, today, lead_days=lead_days):
            try:
                has_onboarding = store.conn.execute(
                    "SELECT 1 FROM invoice_line l JOIN invoice i ON i.id=l.invoice_id WHERE i.restaurant_id=? AND l.kind='onboarding' LIMIT 1",
                    (contract["restaurant_id"],)).fetchone() is not None
                ever = store.conn.execute("SELECT 1 FROM invoice WHERE restaurant_id=? LIMIT 1", (contract["restaurant_id"],)).fetchone()
                inv = build_invoice(store, contract, k, books, restaurant_name=name,
                                    pending=pending_adjustments(store, contract["restaurant_id"]),
                                    first=not has_onboarding and ever is None)
                if dry_run:
                    created.append({"number": "(dry run)", **{x: inv[x] for x in ("restaurant_id", "customer", "period_start", "period_end", "total_cents")}})
                    continue
                number = issue(store, inv)
                if number:
                    created.append({"number": number, **{x: inv[x] for x in ("restaurant_id", "customer", "period_start", "period_end", "total_cents")}})
            except BillingError as exc:
                problems.append({"restaurant_id": contract["restaurant_id"], "period": k, "problem": str(exc)})
    return {"today": today.isoformat(), "created": created, "problems": problems}


# ---------------------------------------------------------------------------
# reading, voiding, exporting
# ---------------------------------------------------------------------------

def invoices(store, *, status: Optional[str] = None, number: Optional[str] = None,
             restaurant_id: Optional[str] = None, with_lines: bool = True) -> List[dict]:
    q, params = "SELECT i.*, r.name AS location FROM invoice i LEFT JOIN restaurant r ON r.id=i.restaurant_id WHERE 1=1", []
    for col, val in (("i.status", status), ("i.number", number), ("i.restaurant_id", restaurant_id)):
        if val:
            q += f" AND {col}=?"
            params.append(val)
    out = []
    for row in store.conn.execute(q + " ORDER BY i.issued_on, i.number", params).fetchall():
        d = dict(row)
        if with_lines:
            d["lines"] = [dict(x) for x in store.conn.execute(
                "SELECT * FROM invoice_line WHERE invoice_id=? ORDER BY seq", (d["id"],)).fetchall()]
        out.append(d)
    return out


def void_invoice(store, number: str, reason: str) -> None:
    """Void an invoice. Its period stays occupied (it will NOT be invoiced again by
    the run); credits it carried return to pending."""
    if not (reason or "").strip():
        raise BillingError("a reason is required to void an invoice")
    inv = next(iter(invoices(store, number=number, with_lines=False)), None)
    if inv is None:
        raise BillingError(f"no invoice {number}")
    if inv["status"] == "void":
        return
    with store.tx() as c:
        c.execute("UPDATE invoice SET status='void', void_reason=? WHERE number=?", (reason.strip(), number))
        c.execute("UPDATE billing_adjustment SET applied_invoice_id=NULL WHERE applied_invoice_id=?", (inv["id"],))
    store.log_event("billing.invoice_voided", restaurant_id=inv["restaurant_id"], detail={"number": number, "reason": reason.strip()[:200]})


def mark_exported(store, numbers: List[str]) -> int:
    n = 0
    with store.tx() as c:
        for number in numbers:
            n += c.execute("UPDATE invoice SET status='exported', exported_at=? WHERE number=? AND status='issued'",
                           (_now(), number)).rowcount
    return n


def _dollars(cents: int) -> str:
    sign = "-" if cents < 0 else ""
    return f"{sign}{abs(cents) // 100}.{abs(cents) % 100:02d}"


def export_quickbooks_csv(invs: List[dict], *, payment_terms_days: int = 0) -> str:
    """One row per invoice line (QuickBooks wants the invoice fields repeated on
    each line). In QuickBooks Online: Settings > Import Data > Invoices, upload this
    file and map the columns on the next screen. Amounts are before tax: set the
    tax code on the QuickBooks side."""
    out = io.StringIO()
    w = csv.writer(out, lineterminator="\n")
    w.writerow(["InvoiceNo", "Customer", "InvoiceDate", "DueDate", "Terms", "Location", "Memo", "Item(Product/Service)",
                "ItemDescription", "ItemQuantity", "ItemRate", "ItemAmount", "ServiceDate", "Currency"])
    for inv in invs:
        terms = "Due on receipt" if payment_terms_days == 0 else f"Net {payment_terms_days}"
        for ln in inv["lines"]:
            w.writerow([inv["number"], inv["customer"], inv["issued_on"], inv["due_on"], terms, inv.get("location") or "",
                        inv.get("memo") or "", ln["item"], ln["description"], ln["quantity"], _dollars(ln["unit_cents"]),
                        _dollars(ln["amount_cents"]), inv["period_start"] if ln["kind"] == "subscription" else inv["issued_on"], "USD"])
    return out.getvalue()


# ---------------------------------------------------------------------------
# revenue and reports
# ---------------------------------------------------------------------------

def recognition(inv: Mapping) -> Dict[str, int]:
    """Revenue by calendar month. The subscription is spread evenly by the day across
    its service period (so a year paid in advance is deferred and earned monthly);
    onboarding and adjustments are earned when invoiced. Whole cents: each month gets
    its share rounded down and the remainder goes to the months with the largest
    fractions, so the months always add up to the invoice exactly."""
    if inv["status"] == "void":
        return {}
    out: Dict[str, int] = {}
    sub = sum(x["amount_cents"] for x in inv["lines"] if x["kind"] == "subscription")
    start, end = parse_day(inv["period_start"]), parse_day(inv["period_end"])
    days = (end - start).days + 1
    per_month: Dict[str, int] = {}
    d = start
    while d <= end:
        per_month[d.strftime("%Y-%m")] = per_month.get(d.strftime("%Y-%m"), 0) + 1
        d += timedelta(days=1)
    shares = {m: (sub * n // days, (sub * n) % days) for m, n in per_month.items()}
    short = sub - sum(s[0] for s in shares.values())
    for m in sorted(shares, key=lambda m: (-shares[m][1], m))[:short]:
        shares[m] = (shares[m][0] + 1, shares[m][1])
    for m, (cents, _frac) in shares.items():
        out[m] = out.get(m, 0) + cents
    other = sum(x["amount_cents"] for x in inv["lines"] if x["kind"] != "subscription")
    if other:
        m = parse_day(inv["issued_on"]).strftime("%Y-%m")
        out[m] = out.get(m, 0) + other
    return out


def report(store, month: str, *, books: Optional[List[Book]] = None) -> dict:
    """Recurring revenue now, and the month's invoicing, revenue and deferred balance."""
    books = books or load_price_book()
    first = parse_day(month + "-01", "month")
    last = add_months(first, 1) - timedelta(days=1)
    book = book_for(books, max(first, books[0].effective_from))
    mrr, by_plan = 0, {}
    for c in list_contracts(store):
        if c["status"] == "paused" or (c["status"] == "cancelled" and (not c.get("ends_on") or c["ends_on"] <= first.isoformat())):
            continue                    # paused, or already over by the start of the month
        plan = book.plans.get(plan_key(c["plan"]))
        if plan is None:
            continue
        each = monthly_equivalent_cents(c, plan)
        mrr += each
        row = by_plan.setdefault(plan.name, {"locations": 0, "mrr_cents": 0})
        row["locations"] += 1
        row["mrr_cents"] += each
    invoiced = recognized = deferred = 0
    for inv in invoices(store):
        if inv["status"] == "void":
            continue
        if first.isoformat() <= inv["issued_on"] <= last.isoformat():
            invoiced += inv["total_cents"]
        rec = recognition(inv)
        recognized += rec.get(month, 0)
        if inv["issued_on"] <= last.isoformat():
            deferred += sum(c for m, c in rec.items() if m > month)
    return {"month": month, "mrr_cents": mrr, "arr_cents": mrr * 12, "by_plan": by_plan, "invoiced_cents": invoiced,
            "recognized_cents": recognized, "deferred_cents": deferred, "contracts": len(list_contracts(store))}


# ---------------------------------------------------------------------------
# command line
# ---------------------------------------------------------------------------

def _money(cents: int) -> str:
    return ("-" if cents < 0 else "") + "$" + f"{abs(cents) / 100:,.2f}"


def _show_invoice(inv: dict) -> str:
    out = [f"{inv['number']}  {inv['customer']} — {inv.get('location') or inv['restaurant_id']}  [{inv['status']}]",
           f"  period {inv['period_start']} to {inv['period_end']}   issued {inv['issued_on']}   due {inv['due_on']}"]
    for ln in inv["lines"]:
        out.append(f"    {ln['description']}\n        {ln['quantity']} x {_money(ln['unit_cents'])} = {_money(ln['amount_cents'])}")
    out.append(f"  TOTAL {_money(inv['total_cents'])}   {inv.get('memo') or ''}")
    return "\n".join(out)


def main(argv: Optional[List[str]] = None, *, today: Optional[date] = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--db", required=True, help="SQLite path or a postgres:// DSN")
    ap.add_argument("--price-book", default=str(PRICE_BOOK))
    sub = ap.add_subparsers(dest="cmd", required=True)

    ct = sub.add_parser("contract")
    cts = ct.add_subparsers(dest="sub", required=True)
    cs = cts.add_parser("set")
    cs.add_argument("--restaurant", required=True)
    cs.add_argument("--customer", required=True)
    cs.add_argument("--plan", required=True)
    cs.add_argument("--term", required=True, choices=["monthly", "annual"])
    cs.add_argument("--starts", required=True, help="go-live date, YYYY-MM-DD (the billing anniversary)")
    cs.add_argument("--email", default="")
    cs.add_argument("--multi-location", action="store_true")
    cs.add_argument("--onboarding-cents", type=int, default=None)
    cs.add_argument("--price-cents", type=int, default=None, help="negotiated per-month price")
    cs.add_argument("--notes", default="")
    cts.add_parser("list")
    cshow = cts.add_parser("show")
    cshow.add_argument("--restaurant", required=True)
    for name in ("pause", "resume", "cancel"):
        p = cts.add_parser(name)
        p.add_argument("--restaurant", required=True)
        p.add_argument("--on", default=None)

    cr = sub.add_parser("credit", help="a credit (or --charge) for the next invoice")
    cr.add_argument("--restaurant", required=True)
    cr.add_argument("--cents", type=int, required=True, help="positive: credit; with --charge: a one-off charge")
    cr.add_argument("--charge", action="store_true")
    cr.add_argument("--memo", required=True)

    rn = sub.add_parser("run")
    rn.add_argument("--date", default=None)
    rn.add_argument("--lead-days", type=int, default=0)
    rn.add_argument("--dry-run", action="store_true")
    rn.add_argument("--only", action="append", default=[])

    ls = sub.add_parser("list")
    ls.add_argument("--status", choices=["issued", "exported", "void"])
    sh = sub.add_parser("show")
    sh.add_argument("number")
    ex = sub.add_parser("export")
    ex.add_argument("--out", required=True)
    ex.add_argument("--include-exported", action="store_true")
    ex.add_argument("--mark-exported", action="store_true")
    vd = sub.add_parser("void")
    vd.add_argument("number")
    vd.add_argument("--reason", required=True)
    rp = sub.add_parser("report")
    rp.add_argument("--month", required=True, help="YYYY-MM")
    args = ap.parse_args(argv)

    from order_store import OrderStore
    store = OrderStore.open(args.db)
    try:
        books = load_price_book(Path(args.price_book))
        if args.cmd == "contract":
            if args.sub == "set":
                c = set_contract(store, args.restaurant, customer=args.customer, plan=args.plan, term=args.term, starts_on=args.starts,
                                 billing_email=args.email, multi_location=args.multi_location, onboarding_fee_cents=args.onboarding_cents,
                                 price_override_cents=args.price_cents, notes=args.notes, books=books)
                print(json.dumps(c, indent=2, default=str))
            elif args.sub == "list":
                for c in list_contracts(store):
                    print(f"{c['restaurant_id']:28} {c['customer']:24} {c['plan']:7} {c['term']:8} from {c['starts_on']}  [{c['status']}]")
            elif args.sub == "show":
                print(json.dumps(get_contract(store, args.restaurant), indent=2, default=str))
            else:
                status = {"pause": "paused", "resume": "active", "cancel": "cancelled"}[args.sub]
                print(json.dumps(set_status(store, args.restaurant, status, on=args.on), indent=2, default=str))
            return 0
        if args.cmd == "credit":
            cents = args.cents if args.charge else -abs(args.cents)
            print(f"recorded adjustment #{add_adjustment(store, args.restaurant, cents, args.memo)} ({_money(cents)}): it goes on the next invoice")
            return 0
        if args.cmd == "run":
            res = run(store, today=parse_day(args.date) if args.date else today, lead_days=args.lead_days,
                      dry_run=args.dry_run, only=args.only, books=books)
            print(f"{'Would issue' if args.dry_run else 'Issued'} {len(res['created'])} invoice(s) as of {res['today']}:")
            for c in res["created"]:
                print(f"  {c['number']}  {c['customer']} — {c['restaurant_id']}  {c['period_start']} to {c['period_end']}  {_money(c['total_cents'])}")
            for p in res["problems"]:
                print(f"  PROBLEM {p['restaurant_id']}: {p['problem']}")
            return 3 if res["problems"] else 0
        if args.cmd == "list":
            for inv in invoices(store, status=args.status, with_lines=False):
                print(f"{inv['number']}  {inv['issued_on']}  {inv['customer']:24} {inv.get('location') or inv['restaurant_id']:36} {_money(inv['total_cents']):>10}  {inv['status']}")
            return 0
        if args.cmd == "show":
            inv = next(iter(invoices(store, number=args.number)), None)
            if inv is None:
                print(f"no invoice {args.number}")
                return 1
            print(_show_invoice(inv))
            return 0
        if args.cmd == "export":
            rows = [i for i in invoices(store) if i["status"] == "issued" or (args.include_exported and i["status"] == "exported")]
            Path(args.out).write_text(export_quickbooks_csv(rows, payment_terms_days=book_for(books, today or date.today()).payment_terms_days))
            print(f"wrote {len(rows)} invoice(s) to {args.out}")
            if args.mark_exported:
                print(f"marked {mark_exported(store, [r['number'] for r in rows])} as exported")
            return 0
        if args.cmd == "void":
            void_invoice(store, args.number, args.reason)
            print(f"voided {args.number}")
            return 0
        if args.cmd == "report":
            r = report(store, args.month, books=books)
            print(f"{r['month']}: {r['contracts']} contract(s); MRR {_money(r['mrr_cents'])} (ARR {_money(r['arr_cents'])})")
            for plan, row in sorted(r["by_plan"].items()):
                print(f"  {plan:8} {row['locations']} location(s)  {_money(row['mrr_cents'])}/month")
            print(f"  invoiced this month {_money(r['invoiced_cents'])}   revenue earned {_money(r['recognized_cents'])}   "
                  f"deferred at month end {_money(r['deferred_cents'])}")
            return 0
    except BillingError as exc:
        print(f"billing: {exc}")
        return 1
    return 1


if __name__ == "__main__":
    sys.exit(main())
