#!/usr/bin/env python3
"""
The HTTP service. This is what Inworld and Telnyx actually talk to.

WHY THIS FILE EXISTS
--------------------
`agent_api.py` and `guest_services.py` define fourteen tools. Inworld calls them over HTTP, so
without a server somebody has to invent the hosting, the session registry and
the routing — and that is precisely where an integration goes wrong. This is
that server, so nobody has to guess.

    python3 server.py --db cherry.db --port 8080 --key <shared-secret>
    CHERRY_DATABASE_URL=postgresql://... python3 server.py --key <shared-secret>

WHAT INWORLD CALLS
------------------
    POST /v1/calls                        a call arrived; start a session
    POST /v1/calls/{call_id}/tools/{tool} an ordering or reservation tool
    POST /v1/calls/{call_id}/finish       caller is done; place the order
    POST /v1/calls/{call_id}/handoff      a person is taking over: text staff a briefing
    POST /v1/calls/{call_id}/abandon      caller hung up with nothing

Every tool response is the same envelope `agent_api` returns, unchanged. The
`say` field is the literal sentence Lily speaks.

WHAT TELNYX CALLS
-----------------
    POST /v1/webhooks/telnyx/sms          delivery status and inbound replies

WHAT SQUARE CALLS
-----------------
    GET  /v1/oauth/square/callback        the owner's approval; the signed
                                          `state` is the only credential

    GET  /v1/oauth/clover/callback        the same for Clover (merchant_id on
                                          the redirect; signed `state`)

WHAT A HUMAN OPENS
------------------
    GET  /kds?r=&k=                       the kitchen tablet (device key per
                                          restaurant); /kds/orders, /kds/accept
    GET  /t/{code}                        the kitchen ticket (private port only:
                                          the code is four digits, not scoped)
    POST /t/{code}/accept                 'we've got it' — the acknowledgement

SESSION STATE
-------------
A CallSession is held in memory, keyed by the telephony call id, for the life
of the call. The cart is also written to the database after every turn, so a
crash loses at most the current utterance rather than the order. Sessions
older than an hour are swept, because a dropped call never sends `finish` and
otherwise they accumulate forever.

ABOUT ThreadingHTTPServer
-------------------------
The measured peak for all three pilots is about one concurrent call, and five
channels covers it with room. A threaded stdlib server handles that with an
enormous margin and needs nothing installed. Put it behind nginx or a load
balancer for TLS. When there are thirty restaurants rather than three, move
the same handlers to a real ASGI server — the logic here does not change.

SECURITY
--------
Every endpoint except /health and the ticket pages requires
`X-Cherry-Key`. When `TELNYX_PUBLIC_KEY` is set, the SMS webhook instead
requires Telnyx's Ed25519 signature and a fresh timestamp. Without that setting
it falls back to `X-Cherry-Key` for local testing. Do not run this open to the
internet without authentication: an unauthenticated /v1/calls lets anyone
place orders into a real kitchen.
"""

from __future__ import annotations

import _ensure_deps  # noqa: F401  (re-runs under .venv, or says how to install, if PyYAML is missing)
import argparse
import collections
import contextlib
import hashlib
import hmac
import inspect
import json
import logging
import os
import threading
import time
import traceback
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Dict, Optional, Tuple
from zoneinfo import ZoneInfo
from urllib.parse import unquote, urlparse

import ops_monitor
import ops_console
import access_control
import restaurant_controls
import localization
import payments
import dev_checkout
import telnyx_sms
import telnyx_webhook
import telnyx_voice
import square_webhook
import host_voice
import speech
import clover_oauth
import square_oauth
import vault as secret_vault
import guest_services
from agent_api import TOOL_SCHEMAS, CallSession
from bounded_http import BoundedThreadingHTTPServer
from order_store import OrderStore, json_value, redact_dsn
from sinks import FakeSmsSender, ManualSink, deliver, format_ticket, sink_for

log = logging.getLogger("cherry")

ALL_TOOL_SCHEMAS = TOOL_SCHEMAS + guest_services.RESERVATION_TOOL_SCHEMAS
TOOL_NAMES = {t["name"] for t in ALL_TOOL_SCHEMAS}
RESERVATION_TOOLS = {"request_reservation", "cancel_reservation"}
SESSION_TTL_SECONDS = 3600


# Tools that change the cart. Each is journaled so a restarted server can
# rebuild the call; read-only tools and reservations are not replayed.
JOURNALED_TOOLS = frozenset({"add_item", "answer", "confirm_mods", "add_modifier",
                             "remove_modifier", "set_quantity", "split_line",
                             "remove_item",
                             # The allergy question is asked once, by
                             # ready_to_place, and answered by note_allergy:
                             # a restart mid-call must replay both.
                             "note_allergy", "ready_to_place",
                             # state a restart must rebuild: the name for the
                             # order, where the link goes, and "the usual"
                             "set_name", "set_text_number", "reorder_last"})

#: A model retries (Gemini 3.8 Live is documented to repeat a tool 2-5 times in
#: one turn when it gets no result). An IDENTICAL cart-changing call within this
#: many seconds is the same request again, not a second wish: answer it from
#: the first result instead of adding a second item. A caller who really wants
#: two says "two", in one utterance.
DUPLICATE_WINDOW_SECONDS = 2.5
def _square_checkout(restaurant_row):
    from square_bridge import square_checkout_provider_for
    return square_checkout_provider_for(restaurant_row)


#: sink name -> a function that builds that location's `payments.PayLinkProvider`
#: from its deployment secrets (raise if it is not configured). Adding Toast,
#: Clover or EPIPay checkout is one class implementing `PayLinkProvider`, one
#: entry here, and `test_provider_contract.py` run against it. Until a provider
#: exists a non-Square location can only take pay-at-pickup orders (see
#: POS_INTEGRATION_PLAN.md, "Payments without integration").
CHECKOUT_PROVIDERS = {"square": _square_checkout}

DEDUP_TOOLS = frozenset({"add_item", "add_modifier", "remove_modifier",
                         "remove_item", "split_line", "set_quantity",
                         "reorder_last", "set_name", "set_text_number",
                         "note_allergy"})


def _local_time(value, tz_name: str) -> str:
    """'Fri Oct 02, 7:00 PM' in the restaurant's own timezone.

    Postgres hands back UTC, so printing the stored value told a guest their
    7 pm table was at 23:00.
    """
    try:
        when = value if isinstance(value, datetime) else \
            datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if when.tzinfo is None:
            when = when.replace(tzinfo=timezone.utc)
        local = when.astimezone(ZoneInfo(tz_name or "UTC"))
        return local.strftime("%a %b %d, %I:%M %p").replace(" 0", " ")
    except Exception:                                  # noqa: BLE001
        return str(value)


def _reservation_refusal(reason: str) -> str:
    """A sentence a caller can act on for each reason a request is refused."""
    r = reason.lower()
    if "notice" in r:
        return ("That's too soon for this restaurant to accept a request. "
                "Could you try a later time?")
    if "days ahead" in r:
        return "That's further ahead than this restaurant takes requests. Could you try a nearer date?"
    if "closed" in r:
        return "The restaurant is closed then. Could you try another day or time?"
    if "party size" in r:
        return "That's a bigger party than I can request online. Let me connect you with the restaurant."
    if "future" in r:
        return "That time has already passed. What date and time would you like?"
    if "phone" in r:
        return "What phone number should the restaurant use to reach you?"
    return "I couldn't use that date and time. Could you tell me the day and time again?"


class Live:
    """One call in flight."""

    __slots__ = ("call", "session_id", "restaurant_id", "menu_version",
                 "caller_phone", "language", "started_at", "lock",
                 "reservation_id", "last_tool")

    def __init__(self, call: CallSession, session_id: str, restaurant_id: str,
                 menu_version: int, caller_phone: str, language: str = "en") -> None:
        self.call = call
        self.session_id = session_id
        self.restaurant_id = restaurant_id
        self.menu_version = menu_version
        self.caller_phone = caller_phone
        self.language = language
        self.started_at = time.time()
        self.reservation_id = ""
        self.last_tool = None          # (signature, monotonic time, result)
        # One caller cannot talk twice at once, but a retried webhook can
        # arrive while the first is still running.
        self.lock = threading.Lock()


class Cherry:
    """The application. Holds the store, the live calls and the senders."""

    def __init__(self, store: OrderStore, *, sms=None, api_key: str = "",
                 pay_provider=None, telnyx_public_key: str = "",
                 telnyx_webhook_tolerance: int = 300,
                 api_principals: str = "", translator=None,
                 square_webhook_key: str = "", square_webhook_url: str = "",
                 checkout_handoff_only: bool = False,
                 dev_checkout: bool = False) -> None:
        self.store = store
        self.sms = sms or FakeSmsSender()
        self.api_key = api_key
        self.access = access_control.AccessPolicy.from_json(
            api_principals or os.environ.get("CHERRY_API_PRINCIPALS", ""),
            legacy_admin_key=api_key)
        self.localizer = localization.SafeLocalizer(translator)
        self.pay_provider = pay_provider
        self.checkout_handoff_only = checkout_handoff_only
        # Dev checkout is a flag on the app, not merely a provider, because the
        # /v1/dev/pay endpoint must not exist without it.
        self.dev_checkout = dev_checkout
        self.telnyx_public_key = telnyx_public_key
        self.telnyx_webhook_tolerance = telnyx_webhook_tolerance
        self.square_webhook_key = square_webhook_key or os.environ.get("SQUARE_WEBHOOK_SIGNATURE_KEY", "")
        self.square_webhook_url = square_webhook_url or os.environ.get("SQUARE_WEBHOOK_URL", "")
        self.live: Dict[str, Live] = {}
        self._lock = threading.Lock()
        # finish() is once-per-call; see finish().
        self._finish_guard = threading.Lock()
        self._finish_gates: Dict[str, threading.Lock] = {}
        self._start_gates: Dict[str, threading.Lock] = {}
        self._finish_results: "collections.OrderedDict[str, Dict[str, Any]]" = \
            collections.OrderedDict()
        self._briefed: "collections.OrderedDict[str, bool]" = collections.OrderedDict()

    def health(self) -> Dict[str, Any]:
        """Safe deployment signal: database, active routes, and live menus."""
        try:
            row = self.store.conn.execute("""
                SELECT
                  (SELECT count(*) FROM restaurant WHERE active=TRUE) AS active,
                  (SELECT count(*) FROM restaurant
                     WHERE active=TRUE AND inbound_phone IS NOT NULL
                       AND inbound_phone != '') AS routed,
                  (SELECT count(DISTINCT restaurant_id) FROM menu_version
                     WHERE is_live=TRUE) AS menus
            """).fetchone()
            active, routed, menus = row["active"], row["routed"], row["menus"]
            return {"ok": True, "database": "ok", "live_calls": len(self.live),
                    "active_restaurants": active, "routed_restaurants": routed,
                    "live_menus": menus,
                    # A monitor must be able to see that this server is taking
                    # payments through the non-resolving development provider.
                    "checkout": "dev" if self.dev_checkout else "provider",
                    "telnyx_webhook_auth": (
                        "signature" if self.telnyx_public_key else
                        "shared_key" if self.api_key else "not_configured")}
        except Exception as exc:  # noqa: BLE001
            log.error("health database check failed: %s", exc)
            return {"ok": False, "database": "error",
                    "live_calls": len(self.live)}

    # -- sessions --------------------------------------------------------

    def start_call(self, call_id: str, dialled: str,
                   caller: str = "", language: str = "en") -> Dict[str, Any]:
        rest = self.store.restaurant_for_number(dialled)
        if rest is None:
            raise KeyError(f"no restaurant answers {dialled}")
        if not rest["active"]:
            raise KeyError(f"{rest['id']} is not active")
        service = restaurant_controls.service_state(self.store, rest["id"])
        language = language if language in service["languages"] else "en"
        if not service["accepting_orders"]:
            reason = service["reason"].replace("_", " ")
            return {"ok": False, "handoff_required": True,
                    "restaurant_id": rest["id"],
                    "say": (f"This location is not accepting automated orders "
                            f"right now ({reason}). Let me connect you with the restaurant.")}

        # One start per CALL at a time (never one per process: loading a menu
        # is slow enough that serialising unrelated calls queues the last
        # caller past the voice layer's timeout). A provider retry of
        # call_started can arrive while the first is still creating the
        # session, and two would each create one, orphaning the first.
        with self._call_gate(self._start_gates, call_id):
            with self._lock:
                existing = self.live.get(call_id)
            if existing is None and self.checkout_handoff_only:
                # In handoff-only mode a call can only end usefully by texting an
                # itemized checkout link. If this location has no way to make one
                # (not Square, Square not authorized, token missing), taking a
                # whole order and then failing at the end wastes the caller's
                # time: send them to staff before the first question.
                cfg_now, _mv = self.store.load_live_config(rest["id"])
                # The same applies to a caller we cannot text: a blocked caller
                # ID, or a number that replied STOP. Every order is pay-now, so
                # without a reachable number the call can only end in a transfer
                # after the whole order has been taken.
                if cfg_now.pay_now_threshold_cents == 0 and (
                        not caller or self.store.is_suppressed(caller)):
                    self.store.log_event(
                        "call.refused_no_sms", restaurant_id=rest["id"],
                        detail={"reason": "no_caller_id" if not caller
                                else "opted_out"})
                    return {"ok": False, "handoff_required": True,
                            "restaurant_id": rest["id"],
                            "say": ("I can't text a checkout link to the number "
                                    "you're calling from, so let me connect you "
                                    "with the restaurant to place your order.")}
                if cfg_now.pay_now_threshold_cents == 0 and \
                        self.checkout_provider_for(rest) is None:
                    self.store.log_event("call.refused_no_checkout",
                                         restaurant_id=rest["id"],
                                         detail={"sink": rest["sink"]})
                    return {"ok": False, "handoff_required": True,
                            "restaurant_id": rest["id"],
                            "say": ("Phone ordering isn't available at this "
                                    "location yet. Let me connect you with the "
                                    "restaurant.")}
            if existing is not None:
                # A replayed webhook. Return where the call already is rather than
                # starting a second one and losing the cart.
                resumed = existing.call.read_back()
                resumed["say"] = self._localize(
                    resumed["say"], existing.call, existing.language)
                return {"resumed": True, "session_id": existing.session_id,
                        "restaurant_id": existing.restaurant_id, **resumed}

            if existing is None:
                existing = self._resume(call_id)      # a replay after a restart
            if existing is not None:
                resumed = existing.call.read_back()
                resumed["say"] = self._localize(
                    resumed["say"], existing.call, existing.language)
                return {"resumed": True, "session_id": existing.session_id,
                        "restaurant_id": existing.restaurant_id, **resumed}

            cfg, mv = self.store.load_live_config(rest["id"])
            began = datetime.now(timezone.utc).isoformat(timespec="seconds")
            sid = self.store.start_session(rest["id"], mv, channel="voice",
                                           external_id=call_id,
                                           caller_phone=caller or None)
            call = CallSession(cfg)
            self._prime(call, rest, service, caller, began)
            with self._lock:
                self.live[call_id] = Live(call, sid, rest["id"], mv, caller, language)

            greeting = call.greeting()
            greeting["say"] = self._localize(greeting["say"], call, language)
            self.store.record_turn(sid, "agent", greeting["say"], intent="greeting")
            greeting.update({"resumed": False, "session_id": sid,
                             "restaurant_id": rest["id"],
                             "restaurant_name": rest["name"],
                             "prep_minutes": service["prep_minutes"],
                             "wait_minutes": service["wait_minutes"],
                             "languages": service["languages"]})
            return greeting

    def _prime(self, call: CallSession, rest, service: Dict[str, Any],
               caller: str, began: str) -> None:
        """Give a call what only the server knows: the restaurant's clock and
        hours, how long an order takes, and who is calling (a regular's last
        order). Identical on a resume, so a replay says the same words."""
        try:
            tz = ZoneInfo((rest["timezone"] if rest else None) or "UTC")
            call.set_context(
                local_hour=datetime.now(tz).hour,
                prep_minutes=(int(service.get("prep_minutes") or 0)
                              + int(service.get("wait_minutes") or 0)) or None,
                hours=restaurant_controls.hours_summary(self.store, rest["id"]),
                returning=self._returning_for(rest["id"], caller, began),
                is_suppressed=self.store.is_suppressed)
        except Exception:                                   # noqa: BLE001
            # Context is garnish: a failure here must never cost a call.
            log.exception("could not prime call context")

    def _returning_for(self, restaurant_id: str, caller: str, began: str):
        """The caller's last real order here — only from this restaurant's own
        history, only within four months. Two switches turn it off: the owner's
        per-restaurant `remember_callers` control, and CHERRY_REMEMBER_CALLERS=0
        for a whole deployment."""
        if not caller or os.environ.get("CHERRY_REMEMBER_CALLERS", "1") == "0":
            return None
        try:
            if not restaurant_controls.get_controls(
                    self.store, restaurant_id)["remember_callers"]:
                return None
        except Exception:                                   # noqa: BLE001
            log.exception("could not read the remember-callers switch; not remembering")
            return None
        try:
            since = (datetime.fromisoformat(began) - timedelta(days=120)).isoformat(
                timespec="seconds")
            row = self.store.previous_order_for_caller(restaurant_id, caller, began, since)
        except Exception:                                   # noqa: BLE001
            log.exception("could not look up the caller's previous order")
            return None
        if row is None:
            return None
        snap = json_value(row["snapshot"]) or {}
        if not snap.get("lines"):
            return None
        name = (row["customer_name"] or "").strip()
        return {"name": "" if name.lower() in ("", "phone order") else name,
                "lines": snap["lines"],
                "allergy_note": (snap.get("allergy") or {}).get("note", ""),
                "placed_at": row["placed_at"]}

    def _localize(self, text: str, call: CallSession, language: str) -> str:
        terms = [item.name for item in call.config.items]
        terms.extend(option.name for option in call.config.options)
        # Translate first (it protects menu names exactly as written), THEN make
        # it sound like speech: brackets, "2Pcs", "Lamb/Goat", "#2".
        return speech.speakable(self.localizer.translate(text, language, terms))

    def _get(self, call_id: str) -> Live:
        with self._lock:
            live = self.live.get(call_id)
        if live is None:
            live = self._resume(call_id)
        if live is None:
            raise KeyError(f"no live call {call_id}; call POST /v1/calls first")
        return live

    def _resume(self, call_id: str) -> Optional[Live]:
        """Rebuild a call this process does not know (a restart or deploy
        mid-call) by replaying its journal on the menu version it started on.

        Safety: the rebuilt cart must equal the cart last saved for the call,
        byte for byte. If it does not, the call is NOT resumed and the caller
        is handed to staff exactly as before; a wrong cart is worse than none.
        """
        try:
            row = self.store.open_session_for_call(call_id)
            if row is None or row["channel"] != "voice":
                return None
            cfg = self.store.load_config_for_version(
                row["restaurant_id"], int(row["menu_version_id"]))
            call = CallSession(cfg)
            rest_row = self.store.restaurant(row["restaurant_id"])
            self._prime(call, rest_row,
                        restaurant_controls.service_state(self.store, row["restaurant_id"]),
                        row["caller_phone"] or "", str(row["started_at"]))
            for tool, args in self.store.load_journal(row["id"]):
                fn = getattr(call, tool)
                accepted = set(inspect.signature(fn).parameters)
                fn(**{k: v for k, v in args.items() if k in accepted})
            call.take_resolutions()       # a replay is not new evidence
            saved = self.store.load_cart(row["id"])
            rebuilt = json.loads(json.dumps(call.snapshot())) if call.e.lines else None
            if json.dumps(saved, sort_keys=True) != json.dumps(rebuilt, sort_keys=True):
                raise ValueError("rebuilt cart differs from the saved cart")
            live = Live(call, str(row["id"]), row["restaurant_id"],
                        int(row["menu_version_id"]), row["caller_phone"] or "")
            with self._lock:
                live = self.live.setdefault(call_id, live)
            self.store.log_event("call.resumed", restaurant_id=row["restaurant_id"],
                                 session_id=str(row["id"]),
                                 detail={"tools_replayed": len(self.store.load_journal(row["id"]))})
            return live
        except Exception as exc:                          # noqa: BLE001
            log.warning("could not resume call %s: %s", call_id, exc)
            try:
                self.store.log_event("call.resume_failed", detail={"error": str(exc)[:300]})
            except Exception:                             # noqa: BLE001
                pass
            return None

    @staticmethod
    def _typed_args(tool: str, args: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Check tool arguments against the published schema.

        A model can send "two" for an integer, null for an optional field, or
        a number where text belongs. Left alone those reach the engine and
        raise, the request becomes a 500, and the caller is transferred.
        Returns the cleaned arguments (null means omitted; "2" and 2.0 become
        2), or None when a value cannot be used.
        """
        schema = next(t for t in ALL_TOOL_SCHEMAS if t["name"] == tool)
        props = schema["parameters"].get("properties", {})
        out: Dict[str, Any] = {}
        for key, value in args.items():
            if value is None:
                continue
            spec = props.get(key)
            kind = spec.get("type") if spec else None
            if kind == "integer":
                if isinstance(value, bool):
                    return None
                if isinstance(value, float) and value.is_integer():
                    value = int(value)
                elif isinstance(value, str) and value.strip().lstrip("-").isdigit():
                    value = int(value.strip())
                elif not isinstance(value, int):
                    return None
                if "minimum" in spec and value < spec["minimum"]:
                    return None
                if value > 1000:                # no order has a thousand of anything
                    return None
            elif kind == "string":
                if isinstance(value, bool):
                    return None
                if isinstance(value, (int, float)):
                    value = str(value)
                elif not isinstance(value, str):
                    return None
                if len(value) > 2000:
                    return None
            out[key] = value
        return out

    def run_tool(self, call_id: str, tool: str,
                 args: Dict[str, Any]) -> Dict[str, Any]:
        if tool not in TOOL_NAMES:
            raise ValueError(f"unknown tool {tool!r}; have {sorted(TOOL_NAMES)}")
        live = self._get(call_id)
        typed = self._typed_args(tool, args)
        if typed is None:
            log.warning("unusable argument types for %s: %s", tool,
                        {k: type(v).__name__ for k, v in args.items()})
            with live.lock:
                return live.call.argument_error(tool)
        # Nothing a caller says is stored or journaled with a card number in it.
        args = {k: (payments.scrub_payment_text(v) if isinstance(v, str) else v)
                for k, v in typed.items()}
        if tool in RESERVATION_TOOLS:
            return self._run_reservation_tool(live, tool, args)
        fn = getattr(live.call, tool)

        with live.lock:
            spoken = args.get("text")
            if spoken:
                self.store.record_turn(live.session_id, "caller", str(spoken),
                                       intent=tool)
            t0 = time.perf_counter()
            signature = inspect.signature(fn)
            accepted = set(signature.parameters)
            dropped = sorted(set(args) - accepted)
            if dropped:
                log.warning("dropping unexpected argument(s) for %s: %s",
                            tool, ", ".join(dropped))
            clean_args = {k: v for k, v in args.items() if k in accepted}

            sig = (tool, json.dumps(clean_args, sort_keys=True, default=str))
            last = live.last_tool
            if (tool in DEDUP_TOOLS and last is not None and last[0] == sig
                    and time.monotonic() - last[1] < DUPLICATE_WINDOW_SECONDS):
                # Answered from the first result and not run again. Logged, so
                # `call_review.py` can show how often the model retries.
                try:
                    self.store.log_event("call.duplicate_tool",
                                         restaurant_id=live.restaurant_id,
                                         session_id=live.session_id,
                                         detail={"tool": tool})
                except Exception:                      # noqa: BLE001
                    log.exception("could not log a duplicate tool call")
                return {**last[2], "duplicate": True}

            if "text" in dropped:
                # The text is the caller's actual request.  Running the tool
                # after discarding it can silently perform the opposite action
                # (for example confirming an item after "no onions").
                result = live.call.argument_error(tool, misrouted=True)
            else:
                try:
                    signature.bind(**clean_args)
                except TypeError as exc:
                    log.warning("bad argument(s) for %s: %s", tool, exc)
                    result = live.call.argument_error(tool)
                else:
                    try:
                        result = fn(**clean_args)
                    except Exception:                  # noqa: BLE001
                        # The engine refused something it cannot explain (an
                        # unknown line id, say). A 500 here ends the call in
                        # a transfer; ask the caller to repeat instead.
                        log.exception("tool %s failed on call %s", tool, call_id)
                        result = live.call.argument_error(tool)
                    else:
                        if tool in JOURNALED_TOOLS:
                            try:
                                self.store.journal_tool(live.session_id, tool,
                                                        clean_args)
                            except Exception:          # noqa: BLE001
                                log.exception("could not journal %s for %s",
                                              tool, call_id)
            ms = int((time.perf_counter() - t0) * 1000)
            result["say"] = self._localize(result["say"], live.call, live.language)
            live.last_tool = (sig, time.monotonic(), dict(result))
            self.store.record_turn(live.session_id, "agent", result["say"],
                                   intent=tool, latency_ms=ms,
                                   engine_issue_code=result.get("error"))
            try:
                for res in live.call.take_resolutions():
                    self.store.record_resolution(live.session_id, res)
            except Exception:                          # noqa: BLE001
                log.exception("could not record resolution for %s", call_id)
            try:
                self.store.save_cart(live.session_id,
                                     live.call.snapshot() if live.call.e.lines
                                     else None)
            except Exception:                          # noqa: BLE001
                log.exception("could not persist cart for %s", call_id)
        return result

    def _run_reservation_tool(self, live: Live, tool: str,
                              args: Dict[str, Any]) -> Dict[str, Any]:
        """Run guest-service tools without letting the voice model promise a table."""
        allowed = ({"guest_name", "party_size", "reserved_at", "guest_phone", "notes"}
                   if tool == "request_reservation" else
                   {"confirmation_code", "guest_phone"})
        dropped = sorted(set(args) - allowed)
        if dropped:
            log.warning("dropping unexpected reservation argument(s): %s",
                        ", ".join(dropped))
        if "text" in dropped:
            return live.call.argument_error(tool, misrouted=True)
        phone = live.caller_phone or str(args.get("guest_phone") or "").strip()
        if live.caller_phone and args.get("guest_phone") \
                and str(args["guest_phone"]).strip() != live.caller_phone:
            result = live.call._reply(
                "For security, I can only use the number you're calling from.",
                tool, ok=False, error="phone_mismatch")
            return result
        if not phone:
            return live.call._reply(
                "What phone number should the restaurant use to reach you?",
                tool, ok=False, error="phone_required")

        with live.lock:
            try:
                if tool == "request_reservation":
                    required = ("guest_name", "party_size", "reserved_at")
                    if any(k not in args for k in required):
                        return live.call._reply(
                            "I still need the name, party size, and exact date and time.",
                            tool, ok=False, error="bad_arguments")
                    if live.reservation_id:
                        existing = self.store.conn.execute(
                            """SELECT r.id,r.status,r.reserved_at,r.party_size,
                                      x.confirmation_code
                               FROM reservation r JOIN reservation_reference x
                                 ON x.reservation_id=r.id WHERE r.id=?""",
                            (live.reservation_id,)).fetchone()
                        if existing is not None:
                            reservation = dict(existing)
                            result = live.call._reply(
                                f"Reservation request {existing['confirmation_code']} "
                                "was already sent. It is not confirmed until the "
                                "restaurant accepts it.", tool)
                            result.update({"reservation": reservation,
                                           "call_complete": True,
                                           "idempotent_replay": True})
                            result["say"] = self._localize(
                                result["say"], live.call, live.language)
                            self.store.record_turn(
                                live.session_id, "agent", result["say"],
                                intent=tool)
                            return result
                    reservation = guest_services.request_phone_reservation(
                        self.store, live.restaurant_id,
                        guest_name=str(args["guest_name"]), guest_phone=phone,
                        party_size=int(args["party_size"]),
                        reserved_at=str(args["reserved_at"]),
                        notes=str(args.get("notes") or ""))
                    live.reservation_id = reservation["reservation_id"]
                    rest = self.store.restaurant(live.restaurant_id)
                    code = reservation["confirmation_code"]
                    say = (f"I've sent reservation request {code} to the restaurant. "
                           "It is not confirmed until the restaurant accepts it.")
                    result = live.call._reply(say, tool)
                    result.update({"reservation": reservation, "call_complete": True})
                    when = _local_time(reservation["reserved_at"],
                                       rest["timezone"] if rest else "")
                    staff_body = (f"Reservation request {code}: {args['guest_name']}, "
                                  f"party of {reservation['party_size']}, {when}. "
                                  f"Call {phone} to confirm or decline.")
                    guest_body = (f"{rest['name']} reservation request {code} received "
                                  f"for party of {reservation['party_size']} at {when}. "
                                  "This is not confirmed until the restaurant accepts it.")
                    self._send_reservation_notice(live, rest, phone,
                                                  staff_body, guest_body)
                else:
                    code = str(args.get("confirmation_code") or "").strip()
                    if not code:
                        return live.call._reply(
                            "What is the confirmation code from your message?",
                            tool, ok=False, error="bad_arguments")
                    reservation = guest_services.cancel_phone_reservation(
                        self.store, live.restaurant_id,
                        confirmation_code=code, guest_phone=phone)
                    # Cancelled: the call may go on to make a NEW request, which
                    # must not be answered with the cancelled one.
                    live.reservation_id = ""
                    result = live.call._reply(
                        f"Reservation request {reservation['confirmation_code']} is cancelled.",
                        tool)
                    result.update({"reservation": reservation, "call_complete": True})
            except PermissionError:
                result = live.call._reply(
                    "This location does not take reservation requests through Cherry. "
                    "Let me connect you with the restaurant.",
                    tool, ok=False, error="reservations_disabled")
                result["handoff_required"] = True
            except LookupError:
                result = live.call._reply(
                    "I couldn't find that reservation request. Let me connect you with the restaurant.",
                    tool, ok=False, error="reservation_not_found")
                result["handoff_required"] = True
            except (TypeError, ValueError) as exc:
                # The reason is for the log. Spoken, a raw exception ("reservation
                # time must be ISO 8601") means nothing to a guest on the phone.
                log.info("reservation request refused: %s", exc)
                result = live.call._reply(
                    _reservation_refusal(str(exc)), tool, ok=False,
                    error="invalid_reservation")

            result["say"] = self._localize(result["say"], live.call, live.language)
            self.store.record_turn(live.session_id, "agent", result["say"],
                                   intent=tool,
                                   engine_issue_code=result.get("error"))
            return result

    def _send_reservation_notice(self, live: Live, rest, guest_phone: str,
                                 staff_body: str, guest_body: str) -> None:
        failed = []
        for label, phone, body in (("staff", rest["staff_phone"], staff_body),
                                   ("guest", guest_phone, guest_body)):
            if not phone:
                failed.append(label)
                continue
            try:
                self.sms.send(phone, body)
            except Exception:  # noqa: BLE001
                log.exception("reservation %s SMS failed", label)
                failed.append(label)
        if failed:
            self.store.escalate(live.session_id,
                                "reservation notice failed: " + ",".join(failed))

    @contextlib.contextmanager
    def _call_gate(self, gates: Dict[str, threading.Lock], call_id: str):
        """A lock private to one call id; unrelated calls never wait on it."""
        with self._finish_guard:
            gate = gates.setdefault(call_id, threading.Lock())
        gate.acquire()
        try:
            yield
        finally:
            gate.release()
            with self._finish_guard:
                if gates.get(call_id) is gate:
                    del gates[call_id]

    def finish(self, call_id: str, customer_name: str = "") -> Dict[str, Any]:
        """Finalize the order exactly once per call.

        A worker that retries finish while the first is still creating the
        checkout (it takes seconds) would otherwise place a second order and
        text a second link. Callers of the same call_id queue here, and any
        that arrive afterwards get the first answer back.
        """
        with self._call_gate(self._finish_gates, call_id):
            cached = self._finish_results.get(call_id)
            if cached is not None:
                return dict(cached)
            out = self._finish_once(call_id, customer_name)
            if isinstance(out.get("say"), str):
                out["say"] = speech.speakable(out["say"])     # the appended checkout text
            if out.get("placed"):
                self._finish_results[call_id] = dict(out)
                while len(self._finish_results) > 2000:
                    self._finish_results.popitem(last=False)
            return out

    def _finish_once(self, call_id: str, customer_name: str = "") -> Dict[str, Any]:
        """Finalize the order, then enforce its payment-before-POS policy."""
        live = self._get(call_id)
        with live.lock:
            ready = live.call.ready_to_place()
            ready["say"] = self._localize(ready["say"], live.call, live.language)
            if not ready["ok"]:
                # Not an error — the call is simply not done. The voice layer
                # must ask what is in `needs` rather than hang up.
                return {**ready, "placed": False}

            snapshot = live.call.snapshot()
            oid, code = self.store.place_order(
                live.restaurant_id, live.menu_version, snapshot,
                session_id=live.session_id, channel="voice",
                customer_name=customer_name or live.call.customer_name or None,
                customer_phone=live.caller_phone or None)
            sms_to = live.call.text_to or live.caller_phone or ""
            who = customer_name or live.call.customer_name or ""
            self.store.end_session(live.session_id, "completed")

        rest = self.store.restaurant(live.restaurant_id)
        out: Dict[str, Any] = {"placed": True, "order_id": oid,
                               "short_code": code,
                               "total_cents": snapshot["total_cents"],
                               "say": ready["say"]}

        # Money first for pay-now orders.  The hosted checkout contains this
        # exact immutable snapshot; no POS/kitchen handoff happens until its
        # authenticated payment webhook arrives.
        try:
            provider = (self.checkout_provider_for(rest)
                        if snapshot.get("payment_mode") == "pay_now" else None)
            status = payments.arrange_payment(
                self.store, oid, sms=self.sms, provider=provider,
                customer_phone=sms_to or None)
            out["payment"] = status
        except Exception as exc:                       # noqa: BLE001
            log.exception("payment arrangement failed for %s", oid)
            status = "error"
            out["payment"] = status
            out["payment_error"] = str(exc)

        if snapshot.get("payment_mode") == "pay_now":
            out["delivered"] = False
            out["awaiting_payment"] = (status == "link_sent"
                                       and not self.checkout_handoff_only)
            if status == "link_sent":
                if self.checkout_handoff_only:
                    out["checkout_handed_off"] = True
                    out["say"] += (" I texted your checkout link to the number "
                                   f"ending in {host_voice.spoken_digits(sms_to[-4:])}. "
                                   "Please review the order and complete your "
                                   "transaction on the restaurant's secure page."
                                   + host_voice.sign_off(who))
                else:
                    out["say"] += (" I texted your itemized secure checkout to the "
                                   f"number ending in {host_voice.spoken_digits(sms_to[-4:])}. "
                                   "Please review it and pay; only then will "
                                   "the restaurant receive the order."
                                   + host_voice.sign_off(who))
            else:
                self.store.escalate(live.session_id,
                                    "itemized checkout was not delivered")
                out["say"] += (" I could not deliver the secure checkout. "
                               "The restaurant has not received the order; "
                               "staff will need to help you.")
            self._drop(call_id)
            return out

        # Pay-at-pickup orders can go straight to the configured sink.
        try:
            sink = sink_for(rest, self.sms)
            res = deliver(self.store, oid, sink)
            out["delivered"] = res.ok
            if res.ok:
                if "pay when you pick it up" not in out["say"]:
                    out["say"] += host_voice.PAY_AT_PICKUP          # the caller must know how they pay
                out["say"] += host_voice.sign_off(who)
            if not res.ok:
                out["delivery_error"] = res.error_detail
                self.store.escalate(live.session_id,
                                    f"delivery {res.error_kind}")
        except Exception as exc:                       # noqa: BLE001
            log.exception("delivery failed for %s", oid)
            out["delivered"] = False
            out["delivery_error"] = str(exc)
            self.store.escalate(live.session_id, "delivery crashed")

        self._drop(call_id)
        return out

    def checkout_provider_for(self, restaurant_row):
        """The itemized-checkout provider for a location, or None when it has none
        (then a pay-now order cannot be taken; see CHECKOUT_PROVIDERS)."""
        if self.pay_provider is not None:
            return self.pay_provider
        if restaurant_row is not None:
            factory = CHECKOUT_PROVIDERS.get(restaurant_row["sink"])
            if factory is not None:
                try:
                    return factory(restaurant_row)
                except Exception as exc:              # credentials/configuration
                    log.error("itemized %s checkout unavailable for %s: %s",
                              restaurant_row["sink"], restaurant_row["id"], exc)
        return None

    def release_paid_order(self, order_id: str) -> Dict[str, Any]:
        return payments.release_paid_order(self.store, order_id, sms=self.sms)

    def payment_maintenance(self) -> Dict[str, Any]:
        """Retry paid handoffs and safely revoke expired hosted links."""
        if self.checkout_handoff_only:
            return {
                "releases": {"checked": 0, "released": 0, "failed": 0},
                "expirations": payments.expire_due_links(
                    self.store, provider_for=self.checkout_provider_for),
            }
        return {
            "releases": payments.retry_paid_deliveries(
                self.store, sms=self.sms),
            "expirations": payments.expire_due_links(
                self.store, provider_for=self.checkout_provider_for),
        }

    def handoff_briefing(self, call_id: str, reason: str = "") -> Dict[str, Any]:
        """A caller is being transferred to a person: text staff what Cherry
        knows (who, why, what is in the cart) so whoever picks up does not
        start from zero. Best effort and once per call; it never gets in the
        way of the transfer itself."""
        live = self._get(call_id)
        with self._finish_guard:
            if call_id in self._briefed:
                return {"ok": True, "texted": False, "duplicate": True}
            self._briefed[call_id] = True
            while len(self._briefed) > 2000:
                self._briefed.popitem(last=False)
        rest = self.store.restaurant(live.restaurant_id)
        phone = (rest["staff_phone"] if rest else None) or ""
        body = host_voice.staff_briefing(
            caller=live.caller_phone, name=live.call.customer_name,
            reason=str(reason or "")[:80], snapshot=live.call.snapshot())
        self.store.escalate(live.session_id, str(reason or "handoff")[:200])
        texted = False
        if phone:
            try:
                self.sms.send(phone, body)
                texted = True
            except Exception:                              # noqa: BLE001
                log.exception("handoff briefing SMS failed for %s", call_id)
        self.store.log_event("handoff.briefing", restaurant_id=live.restaurant_id,
                             session_id=live.session_id,
                             detail={"texted": texted, "reason": str(reason or "")[:80]})
        return {"ok": True, "texted": texted}

    def abandon(self, call_id: str, reason: str = "caller_hung_up") -> Dict:
        live = self._get(call_id)
        had = bool(live.call.e.lines)
        self.store.end_session(live.session_id,
                               "abandoned" if had else "no_order")
        if had:
            # Worth a human's attention: they got partway and dropped.
            self.store.escalate(live.session_id, reason)
        self._drop(call_id)
        return {"ok": True, "had_items": had}

    def _drop(self, call_id: str) -> None:
        with self._lock:
            self.live.pop(call_id, None)

    def sweep(self, ttl: int = SESSION_TTL_SECONDS) -> int:
        """Drop calls that never said goodbye. A dropped call sends nothing."""
        cutoff = time.time() - ttl
        with self._lock:
            stale = [(cid, l) for cid, l in self.live.items()
                     if l.started_at < cutoff]
            for cid, _live in stale:
                self.live.pop(cid, None)
        for _cid, live in stale:
            try:
                self.store.end_session(live.session_id, "timed_out")
            except Exception:                          # noqa: BLE001
                pass
        # Rows orphaned by a restart are not in memory any more.
        cutoff_iso = datetime.fromtimestamp(cutoff, timezone.utc).isoformat(
            timespec="seconds")
        try:
            orphaned = self.store.close_stale_sessions(cutoff_iso)
        except Exception:                              # noqa: BLE001
            log.exception("could not close orphaned sessions")
            orphaned = 0
        return len(stale) + orphaned


# ---------------------------------------------------------------------------
# HTTP
# ---------------------------------------------------------------------------


class Handler(BaseHTTPRequestHandler):
    app: Cherry = None          # type: ignore[assignment]
    server_version = "cherry/1.0"

    def log_message(self, fmt, *args):
        log.info("%s %s", self.address_string(), fmt % args)

    # -- plumbing --------------------------------------------------------

    def _send(self, code: int, body: Any, content_type="application/json"):
        raw = (json.dumps(body).encode() if content_type == "application/json"
               else str(body).encode())
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def _raw_body(self) -> bytes:
        n = int(self.headers.get("Content-Length") or 0)
        return self.rfile.read(n) if n else b""

    @staticmethod
    def _decode_body(raw: bytes) -> Dict[str, Any]:
        try:
            body = json.loads(raw or b"{}")
        except ValueError:
            raise ValueError("body is not JSON")
        if not isinstance(body, dict):
            raise ValueError("body must be a JSON object")
        return body

    def _body(self) -> Dict[str, Any]:
        return self._decode_body(self._raw_body())

    def _principal(self):
        if not self.app.access.configured:
            return access_control.Principal("local", "admin", frozenset({"*"}))
        return self.app.access.authenticate(self.headers.get("X-Cherry-Key", ""))

    def _authed(self, role: str = "service") -> bool:
        if not self.app.access.configured:
            return True
        return access_control.AccessPolicy.permits(self._principal(), role)

    # -- routing ---------------------------------------------------------

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        if path == "/health":
            health = self.app.health()
            return self._send(200 if health["ok"] else 503, health)
        if path == "/v1/tools":
            if not self._authed():
                return self._send(401, {"error": "bad or missing X-Cherry-Key"})
            return self._send(200, {"tools": ALL_TOOL_SCHEMAS})
        if path == "/ops":
            # The shell contains no data or credentials. Its API request is
            # authenticated with the operator key entered in the browser.
            return self._send(200, ops_console.HTML, "text/html; charset=utf-8")
        if path == "/v1/ops/snapshot":
            if not self._authed("viewer"):
                return self._send(401, {"error": "bad or missing X-Cherry-Key"})
            try:
                from urllib.parse import parse_qs
                hours = int(parse_qs(parsed.query).get("hours", ["24"])[0])
                hours = min(720, max(1, hours))
            except (TypeError, ValueError):
                return self._send(400, {"error": "hours must be an integer"})
            snapshot = ops_monitor.operations_snapshot(self.app.store, hours=hours)
            return self._send(200, access_control.scope_snapshot(
                snapshot, self._principal()))
        parts = [unquote(p) for p in path.split("/") if p]
        if len(parts) == 4 and parts[:2] == ["v1", "restaurants"] \
                and parts[3] == "controls":
            restaurant_id = parts[2]
            principal = self._principal()
            if not access_control.AccessPolicy.permits(
                    principal, "viewer", restaurant_id):
                return self._send(403, {"error": "restaurant access denied"})
            return self._send(200, restaurant_controls.get_controls(
                self.app.store, restaurant_id))
        if len(parts) == 4 and parts[:2] == ["v1", "restaurants"] \
                and parts[3] == "reservation-policy":
            restaurant_id = parts[2]
            principal = self._principal()
            if not access_control.AccessPolicy.permits(
                    principal, "viewer", restaurant_id):
                return self._send(403, {"error": "restaurant access denied"})
            return self._send(200, guest_services.get_reservation_policy(
                self.app.store, restaurant_id))
        if len(parts) == 4 and parts[:2] == ["v1", "restaurants"] \
                and parts[3] == "reservations":
            restaurant_id = parts[2]
            principal = self._principal()
            if not access_control.AccessPolicy.permits(
                    principal, "operator", restaurant_id):
                return self._send(403, {"error": "restaurant access denied"})
            rows = self.app.store.conn.execute("""SELECT r.*,x.confirmation_code
                FROM reservation r JOIN reservation_reference x
                  ON x.reservation_id=r.id
                WHERE r.restaurant_id=? ORDER BY r.reserved_at""",
                (restaurant_id,)).fetchall()
            return self._send(200, {"reservations": [dict(row) for row in rows]})
        if path == "/v1/oauth/square/callback":
            return self._square_callback(parsed)
        if path == "/v1/oauth/clover/callback":
            return self._clover_callback(parsed)
        if path == "/kds":
            return self._kds_page(parsed)
        if path == "/kds/orders":
            return self._kds_orders(parsed)
        if path.startswith("/t/"):
            return self._ticket(path[3:])
        return self._send(404, {"error": "not found"})

    def _oauth_page(self, code, text):
        """The small page an owner sees after approving (or not). Fixed text
        only: never tokens, never internal error detail."""
        return self._send(
            code, "<!doctype html><meta charset=utf-8><meta name=viewport "
                  "content='width=device-width,initial-scale=1'>"
                  f"<title>Cherry</title><body style='font:18px system-ui;"
                  f"max-width:30em;margin:3em auto;padding:0 1em'>{text}",
            "text/html; charset=utf-8")

    def _clover_callback(self, parsed):
        """Finish a restaurant owner's Clover approval. Same trust model as
        Square's: unauthenticated by design, the HMAC-signed expiring `state`
        is the credential. Clover names the merchant on the redirect
        (`merchant_id`), not in the token reply. If Clover does not echo
        `state` this refuses — it cannot tell which restaurant approved."""
        from urllib.parse import parse_qs
        query = parse_qs(parsed.query)
        page = self._oauth_page
        if query.get("error"):
            return page(200, "<h2>Authorization cancelled</h2><p>Nothing was "
                             "connected. You can close this page.</p>")
        code = (query.get("code") or [""])[0]
        state = (query.get("state") or [""])[0]
        merchant_id = (query.get("merchant_id") or [""])[0]
        state_secret = os.environ.get("CHERRY_OAUTH_STATE_SECRET", "")
        vault = getattr(self.app, "vault", None) or secret_vault.default_vault()
        if not (code and state and merchant_id and state_secret and vault):
            return page(400, "<h2>This link is not valid</h2><p>Ask Cherry "
                             "support for a new authorization link.</p>")
        try:
            client = clover_oauth.CloverOAuthClient(
                os.environ.get("CLOVER_CLIENT_ID", ""),
                os.environ.get("CLOVER_CLIENT_SECRET", ""),
                sandbox=os.environ.get("CHERRY_CLOVER_SANDBOX") == "1",
                opener=getattr(self.app, "oauth_opener", None))
            rid = clover_oauth.verify_state(state_secret, state)
            if self.app.store.restaurant(rid) is None:
                raise clover_oauth.CloverAuthError("unknown restaurant")
            clover_oauth.complete_authorization(
                client, vault, state_secret, state=state, code=code,
                merchant_id=merchant_id, store=self.app.store)
        except Exception as exc:                      # noqa: BLE001
            log.warning("clover oauth callback failed: %s", exc)
            self.app.store.log_event("clover.oauth_authorization_failed",
                                     detail={"error": str(exc)[:300]})
            return page(400, "<h2>We could not connect Clover</h2><p>Nothing "
                             "was changed. Ask Cherry support for a new link.</p>")
        return page(200, "<h2>Clover is connected</h2><p>Thank you. You can "
                         "close this page.</p>")

    def _square_callback(self, parsed):
        """Finish a restaurant owner's Square approval. Unauthenticated by
        design (Square's redirect carries no Cherry key); the HMAC-signed,
        expiring `state` is the credential. The page never shows tokens or
        internal error text."""
        from urllib.parse import parse_qs
        query = parse_qs(parsed.query)
        page = self._oauth_page
        if query.get("error"):
            return page(200, "<h2>Authorization cancelled</h2><p>Nothing was "
                             "connected. You can close this page.</p>")
        code = (query.get("code") or [""])[0]
        state = (query.get("state") or [""])[0]
        state_secret = os.environ.get("CHERRY_OAUTH_STATE_SECRET", "")
        vault = getattr(self.app, "vault", None) or secret_vault.default_vault()
        if not (code and state and state_secret and vault):
            return page(400, "<h2>This link is not valid</h2><p>Ask Cherry "
                             "support for a new authorization link.</p>")
        try:
            client = square_oauth.SquareOAuthClient(
                os.environ.get("SQUARE_OAUTH_CLIENT_ID", ""),
                os.environ.get("SQUARE_OAUTH_CLIENT_SECRET", ""),
                sandbox=os.environ.get("CHERRY_SQUARE_SANDBOX") == "1",
                opener=getattr(self.app, "oauth_opener", None))
            rid = square_oauth.verify_state(state_secret, state)
            if self.app.store.restaurant(rid) is None:
                raise square_oauth.OAuthRefreshError("unknown restaurant")
            result = square_oauth.complete_authorization(
                client, vault, state_secret, state=state, code=code,
                sandbox=os.environ.get("CHERRY_SQUARE_SANDBOX") == "1",
                opener=getattr(self.app, "oauth_opener", None),
                store=self.app.store)
        except Exception as exc:                      # noqa: BLE001
            log.warning("square oauth callback failed: %s", exc)
            self.app.store.log_event("square.oauth_authorization_failed",
                                     detail={"error": str(exc)[:300]})
            return page(400, "<h2>We could not connect Square</h2><p>Nothing "
                             "was changed. Ask Cherry support for a new link.</p>")
        note = ("" if result["location_id"] else
                "<p>Your Square account has more than one location. Cherry "
                "support will finish the setup with you.</p>")
        return page(200, "<h2>Square is connected</h2><p>Thank you. You can "
                         f"close this page.</p>{note}")

    def do_POST(self):
        path = urlparse(self.path).path
        try:
            if path == "/kds/accept":
                return self._kds_accept(urlparse(self.path))
            if path.startswith("/t/") and path.endswith("/accept"):
                return self._accept(path[3:-len("/accept")])

            if path == "/v1/webhooks/telnyx/sms":
                raw = self._raw_body()
                if self.app.telnyx_public_key:
                    try:
                        telnyx_webhook.verify(
                            raw, self.headers, self.app.telnyx_public_key,
                            tolerance_seconds=self.app.telnyx_webhook_tolerance)
                    except telnyx_webhook.WebhookVerificationError as exc:
                        log.warning("rejected Telnyx webhook: %s", exc)
                        return self._send(401, {"error": str(exc)})
                elif not self._authed():
                    return self._send(
                        401, {"error": "bad or missing X-Cherry-Key"})

                body = self._decode_body(raw)
                data = body.get("data") or {}
                event_id = str(data.get("id") or "")
                event_type = str(data.get("event_type") or "")
                if event_id and not self.app.store.claim_webhook(
                        "telnyx", event_id, event_type):
                    return self._send(200, {"action": "duplicate",
                                            "event_id": event_id})
                try:
                    result = telnyx_sms.handle_webhook(self.app.store, body)
                except Exception:
                    if event_id:
                        self.app.store.release_webhook("telnyx", event_id)
                    raise
                return self._send(200, result)

            if path == "/v1/webhooks/square/payment":
                raw=self._raw_body()
                try:
                    square_webhook.verify(
                        raw,self.headers.get("X-Square-HmacSha256-Signature",""),
                        self.app.square_webhook_key,self.app.square_webhook_url)
                    result=square_webhook.handle(
                        self.app.store, self._decode_body(raw),
                        on_paid=(None if self.app.checkout_handoff_only
                                 else self.app.release_paid_order))
                except square_webhook.SquareWebhookError as exc:
                    return self._send(401,{"error":str(exc)})
                return self._send(200,result)

            if not self._authed():
                return self._send(401, {"error": "bad or missing X-Cherry-Key"})

            # Development checkout. 404 — not 403 — when the flag is off, so a
            # production server does not even advertise that the route exists.
            if path.startswith("/v1/dev/pay/"):
                return self._dev_pay(path[len("/v1/dev/pay/"):])

            parts = [unquote(p) for p in path.split("/") if p]
            if len(parts) == 4 and parts[:2] == ["v1", "orders"] \
                    and parts[3] == "cancel-checkout":
                order = self.app.store.order(parts[2])
                if order is None:
                    return self._send(404, {"error": "unknown order"})
                principal = self._principal()
                if not access_control.AccessPolicy.permits(
                        principal, "operator", order["restaurant_id"]):
                    return self._send(403, {"error": "restaurant access denied"})
                rest = self.app.store.restaurant(order["restaurant_id"])
                try:
                    cancelled = payments.cancel_unpaid_checkout(
                        self.app.store, order["id"],
                        provider=self.app.checkout_provider_for(rest))
                except (ValueError, LookupError) as exc:
                    return self._send(409, {"error": str(exc)})
                return self._send(200, {"cancelled": cancelled,
                                         "replacement_required": cancelled})
            if len(parts) == 4 and parts[:2] == ["v1", "restaurants"] \
                    and parts[3] == "controls":
                restaurant_id = parts[2]
                principal = self._principal()
                if not access_control.AccessPolicy.permits(
                        principal, "operator", restaurant_id):
                    return self._send(403, {"error": "restaurant access denied"})
                body = self._body()
                # Fields not in the request keep their current value. Replacing
                # every column meant "pause the AI" (ai_enabled only) also wiped
                # the opening hours and reset prep time.
                current = restaurant_controls.get_controls(
                    self.app.store, restaurant_id)
                restaurant_controls.set_controls(
                    self.app.store, restaurant_id,
                    weekly_hours=body.get("weekly_hours", current["weekly_hours"]),
                    holiday_closures=body.get("holiday_closures",
                                              current["holiday_closures"]),
                    prep_minutes=int(body.get("prep_minutes",
                                              current["prep_minutes"])),
                    wait_minutes=int(body.get("wait_minutes",
                                              current["wait_minutes"])),
                    ai_enabled=bool(body.get("ai_enabled",
                                             current["ai_enabled"])),
                    languages=body.get("languages", current["languages"]),
                    remember_callers=bool(body.get("remember_callers",
                                                   current["remember_callers"])),
                    updated_by=principal.name)
                return self._send(200, restaurant_controls.get_controls(
                    self.app.store, restaurant_id))

            if len(parts) == 4 and parts[:2] == ["v1", "restaurants"] \
                    and parts[3] == "reservation-policy":
                restaurant_id = parts[2]
                principal = self._principal()
                if not access_control.AccessPolicy.permits(
                        principal, "operator", restaurant_id):
                    return self._send(403, {"error": "restaurant access denied"})
                body = self._body()
                policy = guest_services.set_reservation_policy(
                    self.app.store, restaurant_id,
                    enabled=bool(body.get("enabled", False)),
                    max_party_size=int(body.get("max_party_size", 12)),
                    min_notice_minutes=int(body.get("min_notice_minutes", 60)),
                    max_advance_days=int(body.get("max_advance_days", 90)),
                    updated_by=principal.name)
                return self._send(200, policy)

            if len(parts) == 5 and parts[:2] == ["v1", "restaurants"] \
                    and parts[3] == "reservations":
                restaurant_id, code = parts[2], parts[4]
                principal = self._principal()
                if not access_control.AccessPolicy.permits(
                        principal, "operator", restaurant_id):
                    return self._send(403, {"error": "restaurant access denied"})
                row = guest_services.reservation_by_code(
                    self.app.store, restaurant_id, code)
                if row is None:
                    return self._send(404, {"error": "reservation not found"})
                status = str(self._body().get("status") or "")
                changed = row["status"] != status
                guest_services.update_reservation(
                    self.app.store, row["id"], status, by=principal.name)
                if changed and row["guest_phone"] \
                        and status in {"confirmed", "declined"}:
                    rest = self.app.store.restaurant(restaurant_id)
                    try:
                        self.app.sms.send(
                            row["guest_phone"],
                            f"{rest['name']} reservation {row['confirmation_code']} "
                            f"is {status} for "
                            f"{_local_time(row['reserved_at'], rest['timezone'])}.")
                    except Exception:  # noqa: BLE001
                        log.exception("reservation status SMS failed")
                return self._send(200, {"ok": True,
                                        "confirmation_code": row["confirmation_code"],
                                        "status": status,
                                        "idempotent_replay": not changed})

            if len(parts) == 4 and parts[:2] == ["v1", "calls"] \
                    and parts[3] == "handoff-outcome":
                # The voice gateway reports each human-transfer attempt so a
                # FAILED one raises the existing critical operations alert.
                body = self._body()
                status = str(body.get("status", ""))
                if status not in ("succeeded", "failed"):
                    return self._send(400, {"error": "status must be "
                                                     "succeeded or failed"})
                telnyx_voice.StoreTransferAudit(self.app.store)(
                    call_control_id=parts[2],
                    dialled=str(body.get("dialled", ""))[:20],
                    fallback=str(body.get("fallback", ""))[:20],
                    status=status, reason=str(body.get("reason", ""))[:200],
                    detail=str(body.get("detail", ""))[:500])
                return self._send(200, {"ok": True})

            if path == "/v1/calls":
                b = self._body()
                return self._send(200, self.app.start_call(
                    str(b["call_id"]), str(b["to"]), str(b.get("from") or ""),
                    str(b.get("language") or "en")))

            if len(parts) == 4 and parts[:2] == ["v1", "calls"] \
                    and parts[3] == "usage":
                body = self._body()
                self.app.store.record_voice_usage(
                    parts[2], provider=str(body.get("provider") or "inworld"),
                    processed_characters=int(
                        body.get("processedCharactersCount") or 0),
                    transcribed_audio_ms=int(
                        body.get("transcribedAudioMs") or 0))
                return self._send(200, {"ok": True})

            # /v1/calls/{id}/tools/{tool} | /v1/calls/{id}/finish | .../abandon
            if len(parts) >= 4 and parts[0] == "v1" and parts[1] == "calls":
                call_id = parts[2]
                if parts[3] == "tools" and len(parts) == 5:
                    return self._send(200, self.app.run_tool(
                        call_id, parts[4], self._body()))
                if parts[3] == "finish":
                    return self._send(200, self.app.finish(
                        call_id, str(self._body().get("customer_name") or "")))
                if parts[3] == "abandon":
                    return self._send(200, self.app.abandon(
                        call_id, str(self._body().get("reason") or "hung_up")))
                if parts[3] == "handoff":
                    return self._send(200, self.app.handoff_briefing(
                        call_id, str(self._body().get("reason") or "")))

            return self._send(404, {"error": "not found"})

        except KeyError as exc:
            return self._send(404, {"error": str(exc)})
        except ValueError as exc:
            return self._send(400, {"error": str(exc)})
        except Exception as exc:                       # noqa: BLE001
            # Never leak a stack trace to the caller, always keep it locally.
            log.error("unhandled: %s\n%s", exc, traceback.format_exc())
            return self._send(500, {"error": "internal error"})

    # -- the ticket page -------------------------------------------------

    def _kds_page(self, parsed):
        """The tablet kitchen display. One page, opened once on the
        restaurant's iPad; it polls, beeps, and accepts. Scoped per
        restaurant by a device key derived from the server secret."""
        from urllib.parse import parse_qs
        query = parse_qs(parsed.query)
        rid = (query.get("r") or [""])[0]
        key = (query.get("k") or [""])[0]
        if not _kds_key_ok(self.app.api_key, rid, key):
            return self._send(403, "Bad or missing display key",
                              "text/plain; charset=utf-8")
        if self.app.store.restaurant(rid) is None:
            return self._send(404, "Unknown restaurant",
                              "text/plain; charset=utf-8")
        return self._send(200, _KDS_HTML.format(rid=_esc(rid),
                                                key=_esc(key),
                                                name=_esc(
                                                    self.app.store
                                                    .restaurant(rid)["name"])),
                          "text/html; charset=utf-8")

    def _kds_orders(self, parsed):
        """Recent released orders for one tablet. Scoped by the same device
        key as the page; returns only what a kitchen needs — no caller
        phone, no payment data beyond the total, no transcript."""
        from urllib.parse import parse_qs
        query = parse_qs(parsed.query)
        rid = (query.get("r") or [""])[0]
        key = (query.get("k") or [""])[0]
        if not _kds_key_ok(self.app.api_key, rid, key):
            return self._send(403, {"error": "bad display key"})
        if self.app.store.restaurant(rid) is None:
            return self._send(404, {"error": "unknown restaurant"})
        rows = self.app.store.conn.execute("""
            SELECT o.short_code, o.placed_at, o.status, o.total_cents,
                   o.snapshot, o.fulfilment, o.channel, d.status AS delivery
            FROM "order" o JOIN order_delivery d ON d.order_id = o.id
            WHERE o.restaurant_id=? AND o.placed_at >= ?
              AND d.status IN ('sent','acknowledged')
            ORDER BY o.placed_at DESC LIMIT 30""",
            (rid, (datetime.now(timezone.utc) - timedelta(hours=8))
             .isoformat(timespec="seconds"))).fetchall()
        out = []
        for r in rows:
            snap = json_value(r["snapshot"]) or {}
            lines = []
            for ln in (snap.get("lines") or []):
                mods, defaults = [], []
                for m in (ln.get("modifiers") or []):
                    label = m.get("option_name", "")
                    if m.get("quantity", 1) != 1:
                        label = f"{m.get('quantity')}x {label}"
                    if m.get("placement", "whole") not in ("whole", None):
                        label = f"{label} ({m.get('placement')})"
                    (defaults if m.get("is_default") else mods).append(label)
                lines.append({
                    "quantity": ln.get("quantity"),
                    "name": ln.get("item_name") or ln.get("item_id"),
                    "size": ln.get("size_name"),
                    "modifiers": mods,          # what the caller ASKED for
                    "defaults": defaults,       # what it ships with
                    "note": ln.get("note") or "",
                    "line_total_cents": ln.get("line_total_cents"),
                })
            out.append({
                "allergy": host_voice.staff_line(snap.get("allergy")),
                "code": r["short_code"],
                "placed_at": r["placed_at"],
                "acknowledged": r["status"] == "acknowledged",
                "total_cents": int(r["total_cents"]),
                "fulfilment": r["fulfilment"],
                "channel": r["channel"],
                "lines": lines,
            })
        return self._send(200, {"orders": out})

    def _ticket(self, code: str):
        row = self.app.store.conn.execute(
            'SELECT * FROM "order" WHERE short_code=? ORDER BY placed_at DESC '
            'LIMIT 1', (code,)).fetchone()
        if row is None:
            return self._send(404, "No such order", "text/plain; charset=utf-8")
        delivery = self.app.store.conn.execute("""SELECT 1 FROM order_delivery
            WHERE order_id=? AND status IN ('sent','acknowledged') LIMIT 1""",
            (row["id"],)).fetchone()
        if delivery is None:
            return self._send(404, "Order not released to the restaurant",
                              "text/plain; charset=utf-8")
        rest = self.app.store.restaurant(row["restaurant_id"])
        ticket = format_ticket(json_value(row["snapshot"]), row["short_code"],
                               restaurant_name=rest["name"] if rest else "",
                               customer_phone=row["customer_phone"] or "")
        done = row["status"] == "acknowledged"
        html = _TICKET_HTML.format(
            code=_esc(row["short_code"]), ticket=_esc(ticket),
            status="Confirmed" if done else "Not yet confirmed",
            colour="#137333" if done else "#b06000",
            button="" if done else _ACCEPT_BUTTON.format(code=_esc(code)))
        return self._send(200, html, "text/html; charset=utf-8")

    def _kds_accept(self, parsed):
        """'Got it' from the kitchen tablet. Unlike `/t/{code}/accept` this
        needs the tablet's device key and only touches that restaurant's
        orders — the four-digit code alone is guessable and is not unique
        across restaurants, so it is never exposed to the internet by itself
        (see deploy/nginx/cherry.conf)."""
        from urllib.parse import parse_qs
        query = parse_qs(parsed.query)
        rid = (query.get("r") or [""])[0]
        key = (query.get("k") or [""])[0]
        code = (query.get("code") or [""])[0]
        if not _kds_key_ok(self.app.api_key, rid, key):
            return self._send(403, {"error": "bad or missing display key"})
        return self._accept(code, restaurant_id=rid)

    def _accept(self, code: str, restaurant_id: Optional[str] = None):
        if restaurant_id is None:
            row = self.app.store.conn.execute(
                'SELECT id FROM "order" WHERE short_code=? '
                'ORDER BY placed_at DESC LIMIT 1', (code,)).fetchone()
        else:
            row = self.app.store.conn.execute(
                'SELECT id FROM "order" WHERE restaurant_id=? AND short_code=? '
                'ORDER BY placed_at DESC LIMIT 1',
                (restaurant_id, code)).fetchone()
        if row is None:
            return self._send(404, {"error": "no such order"})
        delivery = self.app.store.conn.execute("""SELECT 1 FROM order_delivery
            WHERE order_id=? AND status IN ('sent','acknowledged') LIMIT 1""",
            (row["id"],)).fetchone()
        if delivery is None:
            return self._send(409, {"error": "order has not been released"})
        changed = self.app.store.acknowledge_delivery(row["id"], "staff")
        return self._send(200, {"ok": True, "already": not changed})

    def _dev_pay(self, order_id: str):
        """Complete payment on the development checkout. Dev servers only.

        This is the local stand-in for a provider's signed webhook. It calls
        the same `payments.mark_paid()` and `release_paid_order()` the Square
        webhook calls, so an order released here went through the real
        payment-gated handoff rather than a shortcut.
        """
        if not self.app.dev_checkout:
            # Match an unknown route exactly: do not reveal that a dev payment
            # endpoint exists on a production server.
            return self._send(404, {"error": "not found"})

        order = self.app.store.order(order_id)
        if order is None:
            return self._send(404, {"error": "unknown order"})

        amount = int(order["total_cents"])
        paid = payments.mark_paid(self.app.store, order_id,
                                  f"dev-{order_id[:8]}")
        if not paid:
            current = payments.payment_for(self.app.store, order_id)
            return self._send(409, {
                "ok": False, "paid": False,
                "reason": "payment is not awaiting settlement",
                "payment_status": current["status"] if current else None})

        out: Dict[str, Any] = {"ok": True, "paid": True, "order_id": order_id,
                               "amount_cents": amount,
                               "short_code": order["short_code"],
                               "dev_checkout": True}
        try:
            out["release"] = self.app.release_paid_order(order_id)
        except Exception as exc:                       # noqa: BLE001
            log.exception("dev checkout release failed for %s", order_id)
            out["ok"] = False
            out["release"] = {"released": False, "error": str(exc)}
        return self._send(200, out)


def _esc(s: str) -> str:
    return (str(s).replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))


_ACCEPT_BUTTON = """
<form method="post" action="/t/{code}/accept">
  <button type="submit">Got it — start this order</button>
</form>"""

# Deliberately plain and dependency-free: this opens on a phone in a kitchen,
# on whatever connection the restaurant has.
def kds_key(api_key: str, restaurant_id: str) -> str:
    """Per-restaurant display key, derived not stored: HMAC of the
    restaurant id under the server secret. Rotating the server key retires
    every tablet at once; nothing extra to leak per location."""
    if not api_key:
        return ""
    return hmac.new(api_key.encode(), restaurant_id.encode(),
                    hashlib.sha256).hexdigest()[:16]


def _kds_key_ok(api_key: str, restaurant_id: str, presented: str) -> bool:
    """Constant-time, and safe for any bytes: compare_digest on a non-ASCII
    str raises, which would turn a bad key into a 500 instead of a 403."""
    want = kds_key(api_key, restaurant_id)
    return bool(restaurant_id and presented and want
                and hmac.compare_digest(want.encode(), presented.encode("utf-8")))


_KDS_HTML = """<!doctype html>
<html><head><meta charset=utf-8>
<meta name=viewport content='width=device-width,initial-scale=1'>
<meta name=apple-mobile-web-app-capable content=yes>
<title>Cherry — {name}</title>
<style>
  body {{ margin:0; font:16px system-ui; background:#101214; color:#e8eaed; }}
  h1 {{ font-size:18px; margin:12px 16px 4px; }}
  .sub {{ color:#9aa0a6; margin:0 16px 12px; font-size:13px; }}
  .order {{ margin:12px 16px; padding:14px; border-radius:10px;
            background:#1c1f22; border:2px solid #4b636e; }}
  .order.done {{ opacity:.45; border-color:#2c3236; }}
  .order .code {{ font-size:22px; font-weight:700; letter-spacing:2px; }}
  .order .total {{ float:right; font-size:20px; font-weight:700; }}
  .order .when {{ color:#9aa0a6; font-size:13px; }}
  .line {{ margin:8px 0 0; font-size:17px; }}
  .line .qty {{ font-weight:700; margin-right:6px; }}
  .mods {{ color:#fdd663; font-size:14px; margin-left:26px; }}
  .defaults {{ color:#6f767c; font-size:12px; margin-left:26px; }}
  .note {{ color:#f28b82; font-size:14px; margin-left:26px; }}
  .allergy {{ background:#b3261e; color:#fff; font-weight:700; font-size:18px;
              padding:8px 10px; border-radius:6px; margin:10px 0 0; }}
  button {{ margin-top:10px; font-size:17px; font-weight:700; padding:10px 22px;
            border-radius:8px; border:0; background:#137333; color:white;
            width:100%; }}
  .banner {{ display:none; background:#5c1a1a; color:#f28b82; padding:8px 16px;
             font-size:14px; }}
</style></head><body>
<h1>{name}</h1>
<div class=sub>Cherry kitchen display — new orders appear and chime
automatically. Keep this page open.</div>
<div id=banner class=banner></div>
<div id=orders></div>
<script>
const Q = 'r={rid}&k={key}';
let known = {{}};
function beep() {{
  try {{
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const t0 = ctx.currentTime;
    [880, 1175, 880].forEach((f, i) => {{
      const o = ctx.createOscillator(), g = ctx.createGain();
      o.frequency.value = f; o.connect(g); g.connect(ctx.destination);
      g.gain.setValueAtTime(0.001, t0 + i * 0.22);
      g.gain.exponentialRampToValueAtTime(0.4, t0 + i * 0.22 + 0.03);
      g.gain.exponentialRampToValueAtTime(0.001, t0 + i * 0.22 + 0.2);
      o.start(t0 + i * 0.22); o.stop(t0 + i * 0.22 + 0.22);
    }});
  }} catch (e) {{}}
}}
function money(c) {{ return '$' + (c / 100).toFixed(2); }}
function esc(v) {{ return String(v == null ? '' : v).replace(/[&<>"']/g,
  c => ({{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}})[c]); }}
function render(os) {{
  const box = document.getElementById('orders');
  box.innerHTML = '';
  os.forEach(o => {{
    const d = document.createElement('div');
    d.className = 'order' + (o.acknowledged ? ' done' : '');
    let h = '<div class=code>' + esc(o.code) + '</div>' +
            '<div class=total>' + money(o.total_cents) + '</div>' +
            '<div class=when>' + esc(o.placed_at) + ' · ' + esc(o.fulfilment) +
            ' · ' + esc(o.channel) + '</div>';
    if (o.allergy) h += '<div class=allergy>⚠ ' + esc(o.allergy) + '</div>';
    o.lines.forEach(ln => {{
      h += '<div class=line><span class=qty>' + esc(ln.quantity) + '×</span>' +
           esc(ln.name) + (ln.size ? ' (' + esc(ln.size) + ')' : '') + '</div>';
      ln.modifiers.forEach(m => h += '<div class=mods>+' + esc(m) + '</div>');
      if (ln.defaults.length)
        h += '<div class=defaults>comes with: ' + esc(ln.defaults.join(', ')) + '</div>';
      if (ln.note) h += '<div class=note>"' + esc(ln.note) + '"</div>';
    }});
    if (!o.acknowledged)
      h += '<button onclick=ack(\\'' + o.code + '\\')>Accept — kitchen saw it</button>';
    else
      h += '<div class=when>confirmed by staff</div>';
    d.innerHTML = h;
    box.appendChild(d);
  }});
}}
function ack(code) {{
  fetch('/kds/accept?' + Q + '&code=' + encodeURIComponent(code), {{ method: 'POST' }})
    .then(r => {{ if (!r.ok) throw 0; poll(); }})
    .catch(() => {{
      const b = document.getElementById('banner');
      b.style.display = 'block';
      b.textContent = 'Could not confirm ' + code + ' — check the connection';
    }});
}}
function poll() {{
  fetch('/kds/orders?' + Q)
    .then(r => r.json())
    .then(data => {{
      document.getElementById('banner').style.display = 'none';
      const fresh = (data.orders || []).filter(o => !o.acknowledged &&
                        !known[o.code]);
      if (fresh.length && Object.keys(known).length) beep();
      data.orders.forEach(o => known[o.code] = 1);
      render(data.orders || []);
    }})
    .catch(() => {{
      const b = document.getElementById('banner');
      b.style.display = 'block';
      b.textContent = 'Connection lost — retrying…';
    }});
}}
poll();
setInterval(poll, 8000);
// the first user tap unlocks audio on iPad; invite it once
document.body.addEventListener('touchstart', function unlock() {{
  beep(); document.body.removeEventListener('touchstart', unlock);
}});
</script></body></html>
"""

_TICKET_HTML = """<!doctype html>
<html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Order #{code}</title>
<style>
  body {{ font: 16px/1.5 -apple-system, system-ui, sans-serif; margin: 0;
         padding: 16px; background: #faf9f7; color: #1a1a1a; }}
  .status {{ color: {colour}; font-weight: 600; margin-bottom: 12px; }}
  pre {{ background: #fff; border: 1px solid #e3e0db; border-radius: 8px;
        padding: 16px; font-size: 15px; overflow-x: auto; }}
  button {{ width: 100%; padding: 18px; font-size: 18px; font-weight: 600;
           color: #fff; background: #137333; border: 0; border-radius: 8px; }}
</style></head>
<body>
  <div class="status">{status}</div>
  <pre>{ticket}</pre>
  {button}
</body></html>"""


def build_server(app: Cherry, port: int) -> ThreadingHTTPServer:
    handler = type("BoundHandler", (Handler,), {"app": app})
    # Shared with voice_gateway.py (see bounded_http.py). Cherry's API is the
    # busier of the two services — it answers every tool call on every live
    # conversation — so it carries the same backlog and concurrency cap as the
    # gateway instead of a second, drifted copy of the same class.
    return BoundedThreadingHTTPServer(("0.0.0.0", port), handler)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--db", default=os.getenv("CHERRY_DATABASE_URL", "cherry.db"),
                    help="SQLite path or Postgres URL; defaults to "
                         "CHERRY_DATABASE_URL, then cherry.db")
    ap.add_argument("--bootstrap-db", action="store_true",
                    help="create the Postgres schema idempotently before start")
    ap.add_argument("--port", type=int, default=8080)
    ap.add_argument("--key", default=os.getenv("CHERRY_API_KEY", ""),
                    help="shared secret for X-Cherry-Key; defaults to "
                         "CHERRY_API_KEY")
    ap.add_argument(
        "--telnyx-public-key", default=os.getenv("TELNYX_PUBLIC_KEY", ""),
        help="base64 Ed25519 public key; defaults to TELNYX_PUBLIC_KEY")
    ap.add_argument("--real-sms", action="store_true",
                    help="use Telnyx (needs TELNYX_API_KEY and "
                         "TELNYX_FROM_NUMBER); otherwise messages are logged "
                         "and not sent")
    ap.add_argument("--checkout-handoff-only", action="store_true",
                    default=os.getenv("CHERRY_CHECKOUT_HANDOFF_ONLY") == "1",
                    help="end Cherry's responsibility after sending the "
                         "itemized checkout link; do not release a kitchen ticket")
    ap.add_argument("--dev-checkout", action="store_true",
                    default=os.getenv("CHERRY_DEV_CHECKOUT") == "1",
                    help="DEVELOPMENT ONLY: take payment through a local, "
                         "non-resolving checkout so a whole order can be run "
                         "with no provider account. Never use for a pilot.")
    args = ap.parse_args()
    if args.checkout_handoff_only:
        # The alert rules (/v1/ops/snapshot here, the cron job elsewhere) read
        # the mode from the environment, so the server must agree with its own
        # flag or every paid order pages as "not released".
        os.environ["CHERRY_CHECKOUT_HANDOFF_ONLY"] = "1"

    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s %(levelname)s %(message)s")
    store = OrderStore.open(args.db, **({"bootstrap": True}
                                       if args.bootstrap_db else {}))

    if args.real_sms:
        sms = telnyx_sms.TelnyxSmsSender(store=store)
        log.info("SMS: Telnyx, sending from %s", sms.from_number)
    else:
        sms = FakeSmsSender()
        log.warning("SMS: FAKE — nothing will actually be sent. "
                    "Pass --real-sms when you mean it.")

    if not args.key:
        log.warning("no --key: every endpoint is unauthenticated. Fine on "
                    "localhost, never on a public address.")
    if not args.telnyx_public_key:
        log.warning("no TELNYX_PUBLIC_KEY: the SMS webhook uses X-Cherry-Key "
                    "instead of Telnyx signature verification")

    pay_provider = None
    if args.dev_checkout:
        # Loud on purpose: this must be impossible to leave on by accident.
        log.warning(dev_checkout.BANNER)
        pay_provider = dev_checkout.DevCheckoutProvider()

    app = Cherry(store, sms=sms, api_key=args.key,
                 pay_provider=pay_provider,
                 telnyx_public_key=args.telnyx_public_key,
                 checkout_handoff_only=args.checkout_handoff_only,
                 dev_checkout=args.dev_checkout)

    def sweeper():
        while True:
            time.sleep(300)
            # One bad pass must not end this thread: it also expires unpaid
            # checkout links, and a dead sweeper stops that silently.
            try:
                n = app.sweep()
                if n:
                    log.info("swept %d abandoned call(s)", n)
            except Exception:                         # noqa: BLE001
                log.exception("session sweep failed")
            try:
                report = app.payment_maintenance()
                if report["releases"]["released"] or report["expirations"]["expired"]:
                    log.info("payment maintenance: %s", report)
            except Exception:                         # noqa: BLE001
                log.exception("payment maintenance failed")
    threading.Thread(target=sweeper, daemon=True).start()

    srv = build_server(app, args.port)
    log.info("cherry listening on :%d  (db=%s)", args.port, redact_dsn(args.db))
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        log.info("shutting down")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
