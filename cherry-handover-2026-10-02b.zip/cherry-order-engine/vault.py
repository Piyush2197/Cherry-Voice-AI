"""Where merchant secrets live at runtime.

Environment variables cannot be updated while a server is running, so a
refreshed Square token would never reach the process that needs it. Cherry
therefore reads secrets from a *vault* first and falls back to the
environment for static values (Telnyx keys, a sandbox token, local tests).

The vault interface is two methods, ``get(name)`` and ``put(name, value)``.
``FileVault`` is the default implementation: one owner-only file per secret
in an owner-only directory, replaced atomically, so a crash mid-refresh can
never leave a half-written token. Deployments that use a managed secret
manager supply their own object with the same two methods.

    export CHERRY_SECRET_DIR=/var/lib/cherry/secrets     # chmod 700, not in git
"""

from __future__ import annotations

import contextlib
import os
import re
import tempfile
import threading
from pathlib import Path
from typing import Dict, Optional

try:                                          # POSIX only; the server runs on Linux
    import fcntl
except ImportError:                           # pragma: no cover
    fcntl = None

_NAME = re.compile(r"^[A-Za-z0-9_.-]{1,128}$")


class FileVault:
    def __init__(self, directory: os.PathLike | str):
        self.directory = Path(directory)
        self.directory.mkdir(mode=0o700, parents=True, exist_ok=True)
        self.directory.chmod(0o700)

    def _path(self, name: str) -> Path:
        if not _NAME.match(name) or name in {".", ".."}:
            raise ValueError(f"invalid secret name {name!r}")
        return self.directory / name

    def names(self):
        return sorted(p.name for p in self.directory.iterdir()
                      if p.is_file() and not p.name.startswith(".tmp-"))

    def get(self, name: str) -> str:
        try:
            return self._path(name).read_text().strip()
        except FileNotFoundError:
            raise KeyError(name) from None

    def put(self, name: str, value: str) -> None:
        if not value:
            raise ValueError(f"refusing to store an empty value for {name}")
        target = self._path(name)
        fd, tmp = tempfile.mkstemp(dir=self.directory, prefix=".tmp-")
        try:
            with os.fdopen(fd, "w") as handle:
                handle.write(value)
                handle.flush()
                os.fsync(handle.fileno())
            os.chmod(tmp, 0o600)
            os.replace(tmp, target)          # atomic on POSIX
        except BaseException:
            try:
                os.unlink(tmp)
            except FileNotFoundError:
                pass
            raise


_THREAD_LOCKS: Dict[str, threading.Lock] = {}
_THREAD_LOCKS_GUARD = threading.Lock()


@contextlib.contextmanager
def exclusive(vault, name: str):
    """Hold a named lock while a token is read, renewed and written back.

    Providers that rotate a single-use refresh token (Clover) or hand every
    caller the same token until its last minute (Toast) must be asked once,
    not by every worker at the same moment. The lock covers every thread, and
    — when the vault is a directory — every process sharing it (a lock file in
    ``<dir>/.locks/``, which ``names()`` never lists). A vault with no
    directory (a managed secret manager) gets the thread lock only; such an
    adapter must supply its own cross-process lock.
    """
    safe = re.sub(r"[^A-Za-z0-9_.-]", "_", name)[:100]
    with _THREAD_LOCKS_GUARD:
        thread_lock = _THREAD_LOCKS.setdefault(f"{id(vault)}:{safe}" if getattr(vault, "directory", None) is None
                                               else f"{Path(vault.directory).resolve()}:{safe}", threading.Lock())
    with thread_lock:
        handle = None
        directory = getattr(vault, "directory", None)
        if directory is not None and fcntl is not None:
            lock_dir = Path(directory) / ".locks"      # a directory: names() skips it
            lock_dir.mkdir(mode=0o700, exist_ok=True)
            handle = open(lock_dir / safe, "a")
            fcntl.flock(handle, fcntl.LOCK_EX)
        try:
            yield
        finally:
            if handle is not None:
                fcntl.flock(handle, fcntl.LOCK_UN)
                handle.close()


def default_vault() -> Optional[FileVault]:
    directory = os.environ.get("CHERRY_SECRET_DIR", "").strip()
    return FileVault(directory) if directory else None


def secret(name: str, default: str = "", *, vault=None) -> str:
    """Vault first (it holds refreshed values), then the environment."""
    vault = vault if vault is not None else default_vault()
    if vault is not None:
        try:
            value = vault.get(name)
            if value:
                return value
        except KeyError:
            pass
    return os.environ.get(name, default)


def restaurant_key(restaurant_id: str) -> str:
    """Suffix used in every per-location secret name."""
    return restaurant_id.upper().replace("-", "_")


def overlay_env(env: dict, *, vault=None) -> dict:
    """``env`` plus every vault secret (vault wins), for readiness checks."""
    vault = vault if vault is not None else default_vault()
    merged = dict(env)
    if vault is not None and hasattr(vault, "names"):
        for name in vault.names():
            try:
                merged[name] = vault.get(name)
            except KeyError:
                pass
    return merged
