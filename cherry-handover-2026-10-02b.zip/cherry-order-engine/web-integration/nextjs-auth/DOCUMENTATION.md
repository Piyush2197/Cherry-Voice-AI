# Cherry Voice AI - Next.js Authentication & API Integration

Complete documentation for integrating the Next.js website (cherryvoiceai.com) with the CHERRY backend order engine.

## 📋 Table of Contents

1. [Installation](#installation)
2. [Setup](#setup)
3. [Authentication Flow](#authentication-flow)
4. [API Endpoints](#api-endpoints)
5. [Frontend Components](#frontend-components)
6. [Security](#security)
7. [Deployment](#deployment)

---

## Installation

### 1. Copy Files to Your Next.js Project

```bash
# Copy authentication middleware
cp middleware.ts <your-nextjs-project>/middleware.ts

# Copy auth library
cp lib/auth.ts <your-nextjs-project>/lib/auth.ts

# Copy CHERRY API client
cp lib/cherry-api.ts <your-nextjs-project>/lib/cherry-api.ts

# Copy API routes
cp -r app/api <your-nextjs-project>/app/api

# Copy pages
cp -r app/login <your-nextjs-project>/app/login
cp -r app/dashboard <your-nextjs-project>/app/dashboard
```

### 2. Install Dependencies

```bash
cd <your-nextjs-project>
npm install jose
```

The `jose` library is used for JWT token generation and verification.

---

## Setup

### Environment Variables

Add these to your `.env.local` file:

```env
# CHERRY Backend Configuration
CHERRY_API_URL=https://your-cherry-api.com
CHERRY_API_KEY=your-cherry-api-key-here

# Authentication Configuration
# You choose these. No defaults exist: if any is missing or weak, sign-in is off.
ADMIN_USERNAME=you@yourcompany.com
ADMIN_PASSWORD=<at least 12 characters: openssl rand -base64 18>
JWT_SECRET=<at least 32 characters: openssl rand -hex 32>

# Next.js Configuration
NODE_ENV=production
```

### Generate JWT Secret

```bash
# Generate a secure random secret
openssl rand -hex 32
```

Use this as your `JWT_SECRET`.

### Get CHERRY API Key

The CHERRY API key is generated from the CHERRY backend:

```bash
# In the CHERRY backend directory
openssl rand -hex 24

# Set it as environment variable
export CHERRY_API_KEY="<generated-key>"

# Start the CHERRY server
python3 server.py --db cherry.db --key "$CHERRY_API_KEY"
```

---

## Authentication Flow

### 1. User Login

```
User → POST /api/auth/login
  → Validates credentials
  → Generates JWT token
  → Sets HTTP-only cookie
  → Returns user data
```

### 2. Protected Route Access

```
User → Protected Route
  → Middleware checks cookie
  → Verifies JWT token
  → Allows access or redirects to login
```

### 3. API Access

```
User → Protected API Route
  → Middleware validates JWT
  → Route validates user role
  → Calls CHERRY API with CHERRY_API_KEY
  → Returns data
```

### 4. Logout

```
User → POST /api/auth/logout
  → Clears auth cookie
  → Redirects to login
```

---

## API Endpoints

### Authentication Endpoints

#### POST /api/auth/login
Login user with username and password.

**Request:**
```json
{
  "username": "<ADMIN_USERNAME>",
  "password": "<ADMIN_PASSWORD>"
}
```

**Response (200):**
```json
{
  "success": true,
  "user": {
    "username": "<ADMIN_USERNAME>",
    "role": "admin"
  }
}
```

**Response (401):**
```json
{
  "success": false,
  "error": "Invalid credentials"
}
```

#### POST /api/auth/logout
Logout user and clear session.

**Response (200):**
```json
{
  "success": true
}
```

### CHERRY API Proxy Endpoints

These endpoints proxy requests to the CHERRY backend and require authentication.

#### GET /api/cherry/snapshot?hours=24
Get operations snapshot from CHERRY backend.

**Response (200):**
```json
{
  "summary": {
    "calls": 150,
    "orders": 45,
    "conversion_percent": 30.0,
    "revenue_cents": 532500,
    "escalated_calls": 3,
    "abandoned_calls": null,
    "open_alerts": 1
  },
  "by_restaurant": [
    {
      "restaurant_id": "bun-n-run-ferndale",
      "name": "Bun N Run Ferndale",
      "calls": 75,
      "orders": 25,
      "revenue_cents": 250000,
      "escalations": 1
    }
  ],
  "alerts": [
    {
      "severity": "high",
      "title": "High escalation rate",
      "detail": "Escalation rate above threshold",
      "action": "Review call transcripts"
    }
  ]
}
```

#### GET /api/cherry/restaurants
Get all restaurants from CHERRY backend.

**Response (200):**
```json
[
  {
    "id": "bun-n-run-ferndale",
    "name": "Bun N Run Ferndale",
    "active": true,
    "inbound_phone": "+13135550123"
  }
]
```

---

## Frontend Components

### Login Page (`app/login/page.tsx`)

Simple login form with:
- Username/password fields
- Error handling
- Loading state
- Redirect after successful login
- Demo credentials displayed

### Dashboard Page (`app/dashboard/page.tsx`)

Protected dashboard showing:
- Summary metrics (calls, orders, conversion, revenue)
- Alerts panel
- Restaurant performance table
- Logout button
- Automatic authentication check

### Middleware (`middleware.ts`)

Route protection middleware that:
- Checks for auth cookie on protected routes
- Redirects to login if not authenticated
- Validates token format
- Configurable protected paths

### Auth Library (`lib/auth.ts`)

Core authentication functions:
- `validateCredentials()` - Check username/password
- `generateToken()` - Create JWT token
- `verifyToken()` - Validate JWT token
- `getCurrentUser()` - Get user from cookie
- `setAuthCookie()` - Set HTTP-only cookie
- `clearAuthCookie()` - Clear cookie
- `loginUser()` - Complete login flow
- `logoutUser()` - Complete logout flow

### CHERRY API Client (`lib/cherry-api.ts`)

Type-safe API client for CHERRY backend:
- `getSnapshot()` - Get operations snapshot
- `getRestaurants()` - Get restaurant list
- `getRestaurant()` - Get restaurant details
- `updateRestaurantControls()` - Update restaurant settings
- `getOrder()` - Get order by short code
- `checkHealth()` - Check API health
- `getToolSchemas()` - Get voice tool schemas
- `createCall()` - Create call session
- `executeTool()` - Execute voice tool
- `finishCall()` - Finish call
- `getKDSUrl()` - Get Kitchen Display URL

---

## Security

### Cookie Security

- **HTTP-only**: Prevents XSS attacks
- **Secure**: HTTPS only in production
- **SameSite**: Lax for cross-site navigation
- **MaxAge**: 7 days token expiry
- **Path**: Root path for site-wide access

### JWT Security

- **Algorithm**: HS256 (HMAC SHA-256)
- **Secret**: Environment variable (never in code)
- **Expiration**: 7 days
- **Payload**: Username and role only (no sensitive data)

### API Key Security

- CHERRY_API_KEY stored in environment variables
- Never logged or exposed
- Separate from user credentials
- Validated on every CHERRY API call

### Password Security

**Current**: Plain text in environment variables (demo)

**Production Recommendation**: 
```typescript
// In production, use bcrypt for password hashing
import bcrypt from 'bcrypt'

const hashedPassword = await bcrypt.hash(password, 10)
const isValid = await bcrypt.compare(inputPassword, hashedPassword)
```

### CORS Configuration

Add to your Next.js config if needed:

```typescript
// next.config.js
module.exports = {
  async headers() {
    return [
      {
        source: '/api/:path*',
        headers: [
          { key: 'Access-Control-Allow-Origin', value: '*' },
          { key: 'Access-Control-Allow-Methods', value: 'GET, POST, PUT, DELETE, OPTIONS' },
          { key: 'Access-Control-Allow-Headers', value: 'Content-Type, Authorization' },
        ],
      },
    ]
  },
}
```

---

## Deployment

### 1. Environment Variables for Production

```bash
# Generate secure secrets
JWT_SECRET=$(openssl rand -hex 32)
CHERRY_API_KEY=$(openssl rand -hex 24)

# Set in production environment
export JWT_SECRET="$JWT_SECRET"
export CHERRY_API_KEY="$CHERRY_API_KEY"
export CHERRY_API_URL="https://api.cherryvoiceai.com"
export ADMIN_USERNAME="you@yourcompany.com"
export ADMIN_PASSWORD="$(openssl rand -base64 18)"   # keep it: this is your sign-in
export NODE_ENV="production"
```

### 2. Build Next.js App

```bash
npm run build
```

### 3. Deploy

Deploy to your hosting platform (Vercel, Netlify, AWS, etc.)

### 4. Update CHERRY Backend

Ensure CHERRY backend is running with:
- Correct API key
- TLS/HTTPS enabled
- CORS configured for your domain
- Firewall allows Next.js server IP

---

## Usage Examples

### Using the CHERRY API Client

```typescript
import { getSnapshot, withErrorHandling } from '@/lib/cherry-api'

// Get snapshot
const snapshot = await withErrorHandling(() => getSnapshot(24))
console.log(snapshot.summary.calls)

// Get restaurants
const restaurants = await withErrorHandling(() => getRestaurants())
restaurants.forEach(r => console.log(r.name))
```

### Protected API Route

```typescript
// app/api/admin/route.ts
import { getCurrentUser } from '@/lib/auth'
import { NextResponse } from 'next/server'

export async function GET() {
  const user = await getCurrentUser()
  
  if (!user || user.role !== 'admin') {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }
  
  // Admin-only logic here
  return NextResponse.json({ data: 'admin data' })
}
```

### Adding New Protected Routes

1. Add route to `protectedPaths` in `middleware.ts`
2. Add authentication check in route handler
3. Optionally check user role

---

## Troubleshooting

### Login Not Working

1. Check environment variables are set
2. Verify JWT_SECRET is the same on both login and verification
3. Check browser console for errors
4. Verify cookies are being set (browser dev tools → Application → Cookies)

### API Calls Failing

1. Verify CHERRY_API_URL is correct
2. Check CHERRY_API_KEY matches backend
3. Verify CHERRY backend is running
4. Check CORS configuration
5. Check network tab in browser dev tools

### Middleware Not Protecting Routes

1. Verify middleware.ts is in app directory root
2. Check protectedPaths includes your route
3. Ensure middleware config matcher is correct
4. Check Next.js version compatibility

---

## Sign-in credentials

There is no demo login. `ADMIN_USERNAME`, `ADMIN_PASSWORD` (12+ characters) and
`JWT_SECRET` (32+ characters) must be set in the environment; if any is missing
or weak, `/api/auth/login` answers 503 and the server log names the problem.
Failed sign-ins are throttled (5 per 15 minutes per address and per username).

---

## Next Steps

1. **Password Hashing**: Implement bcrypt for production passwords
2. **User Database**: Store users in database instead of environment variables
3. **Role-Based Access**: Implement more granular permissions
4. **Multi-Factor Auth**: Add 2FA for admin accounts
5. **Audit Logging**: Log all admin actions
6. **Session Management**: Implement session expiration on logout
7. **Rate Limiting**: Add rate limiting to login endpoint

---

## Support

For issues with:
- **Authentication**: Check lib/auth.ts and middleware.ts
- **CHERRY API**: Check lib/cherry-api.ts and verify backend connection
- **Next.js**: Check Next.js documentation for version compatibility
- **Deployment**: Check environment variables and hosting platform logs
