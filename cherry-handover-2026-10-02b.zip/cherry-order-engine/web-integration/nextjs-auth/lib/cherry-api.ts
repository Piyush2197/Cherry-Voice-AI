/**
 * CHERRY Backend API Client for Next.js
 *
 * SERVER ONLY. This reads CHERRY_API_KEY, so import it from route handlers and
 * server components — never from a 'use client' file (a client component may
 * `import type` from here, which is erased at build time, and must fetch the
 * data through this site's own /api/cherry/* routes).
 *
 * Every path below is one the Cherry server actually serves; the earlier
 * version also called /v1/restaurants and /v1/orders/{code}, which do not exist.
 */
import { createHmac } from 'crypto'

const CHERRY_API_URL = (process.env.CHERRY_API_URL || 'http://localhost:8080').replace(/\/+$/, '')
const REQUEST_TIMEOUT_MS = 10_000

export interface CherryResponse<T = any> {
  ok: boolean
  data?: T
  error?: string
}

export interface Restaurant {
  id: string
  name: string
}

export interface Snapshot {
  summary: {
    calls: number
    orders: number
    conversion_percent: number | null
    revenue_cents: number
    escalated_calls: number
    abandoned_calls: number | null
    open_alerts: number
  }
  by_restaurant: Array<{
    restaurant_id: string
    name: string
    calls: number
    orders: number
    revenue_cents: number
    escalations: number
  }>
  alerts: Array<{
    severity: 'critical' | 'high' | 'medium' | 'low'
    title: string
    detail: string
    action: string
  }>
}

/** What POST /v1/restaurants/{id}/controls reads. Fields left out keep their value. */
export interface RestaurantControls {
  ai_enabled?: boolean
  languages?: string[]
  prep_minutes?: number
  wait_minutes?: number
  weekly_hours?: Record<string, [string, string] | null>
  holiday_closures?: string[]
  remember_callers?: boolean
}

/**
 * Make authenticated request to CHERRY API
 */
async function cherryRequest<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<CherryResponse<T>> {
  const apiKey = process.env.CHERRY_API_KEY || ''
  if (!apiKey) {
    // Never send a request with an empty key and show the visitor a 401.
    return { ok: false, error: 'CHERRY_API_KEY is not set on this server' }
  }

  const url = `${CHERRY_API_URL}${endpoint}`

  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    'X-Cherry-Key': apiKey,
    ...options.headers,
  }

  try {
    const response = await fetch(url, {
      ...options,
      headers,
      signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
      cache: 'no-store',
    })

    const data = await response.json().catch(() => null)

    if (!response.ok) {
      return {
        ok: false,
        error: (data && data.error) || `HTTP ${response.status}`,
      }
    }

    return {
      ok: true,
      data,
    }
  } catch (error) {
    return {
      ok: false,
      error: error instanceof Error ? error.message : 'Unknown error',
    }
  }
}

/**
 * Get operations snapshot
 */
export async function getSnapshot(hours: number = 24): Promise<CherryResponse<Snapshot>> {
  return cherryRequest<Snapshot>(`/v1/ops/snapshot?hours=${encodeURIComponent(String(hours))}`)
}

/**
 * The restaurants Cherry knows, read from the operations snapshot (the server
 * has no list endpoint).
 */
export async function getRestaurants(): Promise<CherryResponse<Restaurant[]>> {
  const snapshot = await getSnapshot(24)
  if (!snapshot.ok || !snapshot.data) {
    return { ok: false, error: snapshot.error || 'Failed to fetch restaurants' }
  }
  return {
    ok: true,
    data: snapshot.data.by_restaurant.map((r) => ({ id: r.restaurant_id, name: r.name })),
  }
}

/**
 * Update restaurant controls. The field that pauses the AI is `ai_enabled`
 * (false pauses); the earlier `disable_ai` was never read by the server, so a
 * "pause" button built on it would have done nothing.
 */
export async function updateRestaurantControls(
  restaurantId: string,
  controls: RestaurantControls
): Promise<CherryResponse> {
  return cherryRequest(`/v1/restaurants/${encodeURIComponent(restaurantId)}/controls`, {
    method: 'POST',
    body: JSON.stringify(controls),
  })
}

/**
 * Check API health
 */
export async function checkHealth(): Promise<CherryResponse<{
  ok: boolean
  database: string
  live_calls: number
  active_restaurants: number
  routed_restaurants: number
  live_menus: number
}>> {
  return cherryRequest('/health')
}

/**
 * Get tool schemas (for integration with voice system)
 */
export async function getToolSchemas(): Promise<CherryResponse<{ tools: any[] }>> {
  return cherryRequest('/v1/tools')
}

/**
 * Create a new call session
 */
export async function createCall(
  callId: string,
  to: string,
  from: string
): Promise<CherryResponse<any>> {
  return cherryRequest('/v1/calls', {
    method: 'POST',
    body: JSON.stringify({
      call_id: callId,
      to,
      from,
    }),
  })
}

/**
 * Execute a tool on a call
 */
export async function executeTool(
  callId: string,
  tool: string,
  args: Record<string, any>
): Promise<CherryResponse<any>> {
  return cherryRequest(
    `/v1/calls/${encodeURIComponent(callId)}/tools/${encodeURIComponent(tool)}`,
    {
      method: 'POST',
      body: JSON.stringify(args),
    }
  )
}

/**
 * Finish a call
 */
export async function finishCall(callId: string): Promise<CherryResponse<any>> {
  return cherryRequest(`/v1/calls/${encodeURIComponent(callId)}/finish`, {
    method: 'POST',
    body: JSON.stringify({}),
  })
}

/**
 * The kitchen-display link for one restaurant's tablet.
 *
 * The key is derived exactly as the Cherry server derives it
 * (server.kds_key: first 16 hex characters of HMAC-SHA256 of the restaurant id
 * under the API key), so it needs no extra call. Treat the URL as a password:
 * anyone holding it can open that restaurant's tickets. `baseUrl` must be the
 * PUBLIC address the tablet reaches (CHERRY_PUBLIC_URL), not the private API.
 */
export function getKDSUrl(
  restaurantId: string,
  baseUrl: string = process.env.CHERRY_PUBLIC_URL || CHERRY_API_URL
): string | null {
  const apiKey = process.env.CHERRY_API_KEY || ''
  if (!apiKey) return null
  const key = createHmac('sha256', apiKey).update(restaurantId).digest('hex').slice(0, 16)
  return `${baseUrl.replace(/\/+$/, '')}/kds?r=${encodeURIComponent(restaurantId)}&k=${key}`
}

/**
 * Error helper
 */
export class CherryApiError extends Error {
  constructor(message: string, public response?: CherryResponse) {
    super(message)
    this.name = 'CherryApiError'
  }
}

/**
 * Helper function to throw on API errors
 */
export async function withErrorHandling<T>(
  fn: () => Promise<CherryResponse<T>>
): Promise<T> {
  const response = await fn()

  if (!response.ok) {
    throw new CherryApiError(response.error || 'API request failed', response)
  }

  return response.data as T
}
