#!/usr/bin/env python3
"""Launch-contract checks shared by both Bun N Run pilot locations."""

from pathlib import Path
import traceback

import menu_schema as ms
from order_engine import OrderEngine

MENUS = Path(__file__).parent / "menus"
LOCATIONS = ("bun-n-run-ferndale", "bun-n-run-clinton")


def load(location):
    return ms.load_yaml(MENUS / f"{location}.yaml")


def t_locations_have_the_same_menu_and_prices():
    a, b = (load(x) for x in LOCATIONS)
    assert [(x.id, x.base_price_cents) for x in a.items] == \
           [(x.id, x.base_price_cents) for x in b.items]
    assert a.id != b.id and a.name != b.name
    assert len(a.items) == 21


def t_every_published_price_is_exact():
    expected = {
        "double_cheeseburger": 999, "double_cheeseburger_combo": 1399,
        "single_cheeseburger": 899, "single_cheeseburger_combo": 1249,
        "double_hamburger": 949, "double_hamburger_combo": 1299,
        "hamburger": 849, "hamburger_combo": 1199,
        "veggie_burger": 849, "veggie_burger_combo": 1199,
        "french_fries": 449, "wild_fries": 649, "fresh_shake": 449,
        "coke": 279, "diet_coke": 279, "sprite": 279,
        "root_beer": 279, "dr_pepper": 279, "iced_tea": 279,
        "lemonade": 279, "water": 200,
    }
    for location in LOCATIONS:
        cfg = load(location)
        assert {x.id: x.base_price_cents for x in cfg.items} == expected


def t_combo_requires_one_included_fountain_drink():
    for location in LOCATIONS:
        e = OrderEngine(load(location))
        line = e.add_line("double_cheeseburger_combo")
        assert not e.is_submittable()
        assert "changes" in e.next_question().lower()
        assert e.confirm_group(line.line_id, "bnr_cheeseburger_toppings")
        assert "drink" in e.next_question().lower()
        assert e.apply_option(line.line_id, "bnr_combo_drink", "bnr_drink_coke") == []
        assert e.is_submittable()
        p = e.price()
        assert (p.subtotal_cents, p.tax_cents, p.total_cents) == (1399, 84, 1483)


def t_shake_is_not_a_combo_drink():
    for location in LOCATIONS:
        e = OrderEngine(load(location))
        line = e.add_line("hamburger_combo")
        problems = e.apply_option(line.line_id, "bnr_combo_drink", "fresh_shake")
        assert problems
        assert not e.is_submittable()


def t_burgers_have_the_advertised_defaults_and_support_no_onion():
    for location in LOCATIONS:
        e = OrderEngine(load(location))
        line = e.add_line("double_cheeseburger")
        assert {x.option_id for x in e.effective_selections(line)} == {
            "bnr_lettuce", "bnr_tomato", "bnr_onion", "bnr_wild_sauce",
            "bnr_cheese",
        }
        assert e.remove_option(line.line_id, "bnr_onion")
        assert not e.is_submittable()
        assert e.confirm_group(line.line_id, "bnr_cheeseburger_toppings")
        assert e.is_submittable()
        ticket = e.to_normalized_order()["lines"][0]
        assert ticket["removed_defaults"] == ["Onion"]
        assert "bnr_onion" not in {x["option_id"] for x in ticket["modifiers"]}


def t_modification_confirmation_is_invalidated_by_a_later_change():
    for location in LOCATIONS:
        e = OrderEngine(load(location))
        line = e.add_line("hamburger")
        assert e.confirm_group(line.line_id, "bnr_burger_toppings")
        assert e.is_submittable()
        assert e.remove_option(line.line_id, "bnr_onion")
        assert not e.is_submittable()
        assert "changes" in e.next_question().lower()


def main():
    passed = failed = 0
    for name, fn in sorted(globals().items()):
        if not name.startswith("t_"):
            continue
        try:
            fn()
            passed += 1
        except Exception:
            failed += 1
            print(f"\n--- FAIL {name}\n{traceback.format_exc()}")
    print(f"\n{passed} passed, {failed} failed (Bun N Run pilot contract)")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
