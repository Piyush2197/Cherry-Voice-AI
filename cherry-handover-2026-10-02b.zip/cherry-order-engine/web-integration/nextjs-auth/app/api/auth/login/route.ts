import { NextRequest, NextResponse } from 'next/server'
import { loginUser } from '@/lib/auth'
import { lockedFor, recordFailure, recordSuccess } from '@/lib/rate-limit'

function clientIp(request: NextRequest): string {
  // Behind a proxy the first X-Forwarded-For entry is the caller.
  const forwarded = request.headers.get('x-forwarded-for')
  return (forwarded ? forwarded.split(',')[0].trim() : '') || 'unknown'
}

export async function POST(request: NextRequest) {
  let body: unknown
  try {
    body = await request.json()
  } catch {
    return NextResponse.json({ success: false, error: 'Invalid request' }, { status: 400 })
  }

  const { username, password } = (body || {}) as { username?: unknown; password?: unknown }
  if (typeof username !== 'string' || typeof password !== 'string' || !username || !password) {
    return NextResponse.json(
      { success: false, error: 'Username and password are required' },
      { status: 400 }
    )
  }
  if (username.length > 256 || password.length > 256) {
    return NextResponse.json({ success: false, error: 'Invalid credentials' }, { status: 401 })
  }

  const ip = clientIp(request)
  const wait = lockedFor(ip, username)
  if (wait > 0) {
    return NextResponse.json(
      { success: false, error: 'Too many attempts. Try again later.' },
      { status: 429, headers: { 'Retry-After': String(wait) } }
    )
  }

  try {
    const result = await loginUser(username, password)

    if (!result.success) {
      if (!result.configured) {
        // Not the caller's fault and not a wrong password: the server is not set up.
        return NextResponse.json({ success: false, error: result.error }, { status: 503 })
      }
      recordFailure(ip, username)
      return NextResponse.json({ success: false, error: result.error }, { status: 401 })
    }

    recordSuccess(username)
    return NextResponse.json({ success: true, user: result.user })
  } catch (error) {
    console.error('[cherry-dashboard] sign-in failed', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
