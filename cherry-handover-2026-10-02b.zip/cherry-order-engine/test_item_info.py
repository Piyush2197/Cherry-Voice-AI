#!/usr/bin/env python3
"""The allergen / dietary tool (`item_info`) and the tool contract around it.

A caller with an allergy is the one call where a wrong answer is not a refund.
Found by playing real questions at the first version of this tool on a real menu:

  * "does that have nuts?" (the tool's own example) -> "we don't have that —
    what else can I get you?"; "I have a nut allergy" got the same dead end;
  * a declared allergen list was read out with no hint that it could be
    incomplete, so a peanut-allergic caller hearing "tree nuts, milk" would
    take peanuts to be absent;
  * "the korma" / "the samosa" silently answered for whichever dish matched
    first, attaching one dish's allergens to another;
  * "any gluten-free options" failed (speech-to-text writes the hyphen);
  * "pad thai" (not on the menu) became the Paratha.

It also pins the things that went stale the moment a fourteenth tool was added:
`tools.json`, the model prompt and the go-live smoke test, which hard-coded
thirteen and would have failed against a correct server.
"""

from __future__ import annotations

import json
import sys
import time
import traceback
from pathlib import Path

import agent_api
import menu_schema as ms

HERE = Path(__file__).resolve().parent
_passed = _failed = 0


def check(name, cond, detail=""):
    global _passed, _failed
    if cond:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


def declared_menu():
    """A real pilot menu with a few owner-style declarations (the shipped
    menus declare nothing yet)."""
    cfg = ms.load_yaml(HERE / "menus" / "pink-garlic-oak-park.yaml")
    by_name = {i.name: i for i in cfg.items}

    def declare(name, allergens=(), dietary=()):
        it = by_name[name]
        object.__setattr__(it, "allergens", tuple(allergens))
        object.__setattr__(it, "dietary", tuple(dietary))

    declare("Chicken Korma (Creamy)", ("tree_nuts", "milk"))
    declare("Paneer Korma", ("tree_nuts", "milk"), ("vegetarian",))
    declare("Vegetable Samosa (2Pcs)", ("wheat",), ("vegetarian",))
    declare("Tarka Dal", (), ("vegan", "gluten_free"))
    return cfg


def silent_menu():
    return ms.load_yaml(HERE / "menus" / "pink-garlic-oak-park.yaml")


def ask(cfg, text, order=()):
    s = agent_api.CallSession(cfg)
    for o in order:
        s.add_item(o)
    base = time.monotonic()
    s.now = lambda: base + 8.0          # a caller takes seconds to ask their next question
    return s, s.item_info(text)


def t_declared_facts_are_spoken_with_the_caveat() -> None:
    cfg = declared_menu()
    _, r = ask(cfg, "does the chicken korma have nuts")
    check("declared allergens are named", "tree nuts" in r["say"] and "milk" in r["say"], r["say"])
    check("…and never without the incomplete-list caveat",
          "only what the restaurant has written down" in r["say"], r["say"])
    _, r = ask(cfg, "does the vegetable samosa have wheat")
    check("a specific allergen that is declared is confirmed",
          r["say"].startswith("Yes") and "wheat" in r["say"], r["say"])
    check("…with the caveat", "confirm any allergy" in r["say"], r["say"])
    _, r = ask(cfg, "does the chicken korma have peanuts")
    check("an allergen that is NOT declared is not denied",
          "can't confirm" in r["say"] and "free of peanuts" in r["say"], r["say"])
    check("…and it is not a 'no'", " no " not in f" {r['say'].lower()} ", r["say"])


def t_diet_questions_use_the_vocabulary_aliases() -> None:
    cfg = declared_menu()
    for phrase in ("is the tarka dal gluten free", "is the tarka dal gluten-free",
                   "is the tarka dal GF"):
        _, r = ask(cfg, phrase)
        check(f"{phrase!r} -> listed", r["ok"] and "listed as gluten free" in r["say"], r["say"])
    _, r = ask(cfg, "is the chicken korma vegan")
    check("a dish not declared vegan is not called vegan, and is not answered with "
          "a list of other dishes",
          "written down" in r["say"] and "won't guess" in r["say"]
          and "Tarka" not in r["say"], r["say"])
    for phrase, want in (("any gluten-free options", "Tarka Dal"),
                         ("what's vegan", "Tarka Dal"),
                         ("anything plant based", "Tarka Dal"),
                         ("any vegetarian dishes", "Paneer Korma")):
        _, r = ask(cfg, phrase)
        check(f"{phrase!r} lists what is declared", r["ok"] and want in r["say"], r["say"])
    _, r = ask(cfg, "any gluten-free options")
    check("a *_free list also carries the caveat", "confirm any allergy" in r["say"], r["say"])
    _, r = ask(silent_menu(), "any gluten-free options")
    check("nothing declared -> says so, never 'we don't have that'",
          "Nothing on this menu is marked gluten free" in r["say"]
          and "what else can I get you" not in r["say"], r["say"])


def t_that_and_it_mean_the_item_just_ordered() -> None:
    cfg = declared_menu()
    for phrase in ("does that have nuts", "does it have nuts", "is it safe"):
        s, r = ask(cfg, phrase, order=["chicken korma"])
        check(f"{phrase!r} resolves to the korma", "Chicken Korma" in r["say"], r["say"])
    s, r = ask(cfg, "does that have nuts", order=["chicken korma"])
    check("the question the order was waiting on is asked again, in the same reply",
          r["say"].rstrip().endswith("extra hot."), r["say"])
    s.answer("medium")
    check("…and answering it still works afterwards (item_info did not disturb it)",
          s.pending() is None or "spicy" not in (s.pending().question or "").lower(),
          str(s.pending()))
    _, r = ask(cfg, "does that have nuts")
    check("'that' with nothing ordered is an allergy referral, not a dead end",
          r["ok"] and "tell the restaurant" in r["say"], r["say"])


def t_allergy_statements_are_sent_to_the_restaurant() -> None:
    for cfg in (declared_menu(), silent_menu()):
        for phrase in ("I have a nut allergy", "does anything have peanuts",
                       "i'm allergic to peanuts, what can i eat",
                       "what has tree nuts in it", "is anything here safe for celiac"):
            _, r = ask(cfg, phrase)
            check(f"{phrase!r} -> referral, ok, no pivot to ordering",
                  r["ok"] and "tell the restaurant before ordering" in r["say"]
                  and "what else can I get you" not in r["say"], r["say"])
            check(f"{phrase!r} never lists dishes (that would read as 'the rest are safe')",
                  "Korma" not in r["say"] and "Samosa" not in r["say"], r["say"])


def t_a_dish_that_is_not_on_the_menu_is_not_swapped_for_another() -> None:
    cfg = declared_menu()
    _, r = ask(cfg, "does the pad thai have peanuts")
    check("off-menu dish is not answered as the Paratha", "Paratha" not in r["say"], r["say"])
    check("…it goes to the restaurant", "tell the restaurant" in r["say"], r["say"])
    _, r = ask(cfg, "is the garden salad vegan")
    check("a similar dish is not substituted silently", "Green Salad" not in r["say"], r["say"])


def t_an_ambiguous_dish_word_is_asked_about_not_guessed() -> None:
    cfg = declared_menu()
    s, r = ask(cfg, "does the korma have nuts")
    check("some korma declare nuts -> asks which", not r["ok"] and r["error"] == "ambiguous"
          and r["say"].startswith("Which one"), str(r))
    check("…as a question the model can see", r["needs"] and r["needs"]["candidates"], str(r["needs"]))
    # the paneer korma is not among the three read out, but it is a candidate
    r2 = s.answer("paneer")
    check("answering resolves the dish, even one that was not read out",
          r2["ok"] and "Paneer Korma" in r2["say"] and "tree nuts" in r2["say"], r2["say"])
    check("…and does not put it on the order", not s.e.lines)
    s2, r = ask(cfg, "does the korma have nuts")
    r = s2.answer("chicken")
    check("the reply answers the allergen question", r["ok"] and "tree nuts" in r["say"], r["say"])
    check("…and does NOT put the dish on the order", not s2.e.lines, str(s2.snapshot()["lines"]))
    check("…and the question is closed", s2._ambiguous is None)
    s3, r = ask(silent_menu(), "does the korma have nuts")
    check("nothing declared anywhere -> one honest sentence, no pointless question",
          r["ok"] and "hasn't marked" in r["say"] and s3._ambiguous is None, r["say"])
    s4, _ = ask(declared_menu(), "does the samosa have wheat")
    r = s4.answer("meat")
    check("samosa: choosing the meat one answers for the meat one",
          "Meat Samosa" in r["say"], r["say"])


def t_bad_input_never_raises() -> None:
    cfg = declared_menu()
    s = agent_api.CallSession(cfg)
    for bad in ("", "   ", None, 5, ["x"], "???", "a" * 5000):
        try:
            r = s.item_info(bad)
            ok = isinstance(r, dict) and isinstance(r.get("say"), str) and r["say"]
        except Exception as exc:                              # noqa: BLE001
            ok, r = False, repr(exc)
        check(f"item_info({str(bad)[:12]!r}) answers", ok, str(r)[:100])


def t_the_tool_contract_is_consistent() -> None:
    import server
    names = {t["name"] for t in server.ALL_TOOL_SCHEMAS}
    check("item_info is a published tool", "item_info" in names)
    on_disk = json.loads((HERE / "tools.json").read_text(encoding="utf-8"))
    check("tools.json is exactly what the server publishes (it had no item_info)",
          on_disk == server.ALL_TOOL_SCHEMAS,
          f"missing {sorted(names - {t['name'] for t in on_disk})}")
    from voice.inworld_bridge import SYSTEM_PROMPT
    check("the model prompt routes allergy questions to item_info and forbids guessing",
          "item_info" in SYSTEM_PROMPT and "never tell a caller a dish is safe"
          in " ".join(SYSTEM_PROMPT.split()), SYSTEM_PROMPT[-300:])
    for t in server.ALL_TOOL_SCHEMAS:
        if t["name"] == "item_info":
            check("item_info requires the caller's words", t["parameters"]["required"] == ["text"])


def t_end_to_end_and_the_go_live_smoke_test() -> None:
    """Through the real gateway and server, and then the real smoke test against
    that server — which hard-coded thirteen tools and failed a correct one."""
    import contextlib
    import io
    import pilot_deploy as pd
    import pilot_smoke
    import rehearsal
    st = rehearsal.Stack()
    try:
        st.call("ii-1")
        st.tool("ii-1", "add_item", text="chicken korma")
        code, b = st.tool("ii-1", "item_info", text="does that have nuts")
        check("item_info reaches the engine over HTTP", code == 200 and "Chicken Korma" in b.get("say", ""), str(b)[:160])
        code, b = st.tool("ii-1", "item_info", text="I have a nut allergy")
        check("an allergy statement over HTTP is referred, not dropped",
              code == 200 and "tell the restaurant" in b.get("say", ""), str(b)[:160])
        code, b = st.tool("ii-1", "item_info", text=5)
        check("a non-text argument over HTTP does not crash the call", code == 200 and b.get("say"), str(b)[:160])
        locs = pd.selected(pd.load_manifest(pd.DEFAULT_MANIFEST), ["pink-garlic-shelby"])
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            rc = pilot_smoke.run(locs, rehearsal.URL, st.env,
                                 base_url=f"http://127.0.0.1:{st.sport}", api_key="apikey")
        out = buf.getvalue()
        check("go-live smoke test passes against a correct server", rc == 0, out[-300:])
        check("…and reports the tools it checked", "tools exposed" in out, out[-300:])
    finally:
        st.close()


def main() -> int:
    global _failed
    for name, fn in sorted((k, v) for k, v in globals().items() if k.startswith("t_")):
        try:
            fn()
        except Exception:                                    # noqa: BLE001
            _failed += 1
            print(f"\n--- FAIL {name} raised")
            traceback.print_exc()
    print(f"{_passed} passed, {_failed} failed (item_info allergen/diet tool + tool contract)")
    return 1 if _failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
