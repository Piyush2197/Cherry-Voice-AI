# Restoring to a point in time

The recipe below was run and verified on PostgreSQL 16 on 2026-09-28
(`pitr_recipe_test.sh`): a database with 300 rows was restored to the moment it
held 200, from a base backup plus archived WAL. Do the same drill on the real
server before launch, and again after any change to backups.

1. Stop Cherry (`systemctl stop cherry-server cherry-gateway`) so nothing writes.
2. Bring back the off-site files: `rclone copy $OFFSITE/backups ./backups` and
   `rclone copy $OFFSITE/wal-archive ./wal-archive`.
3. Restore into a NEW empty data directory (never over the live one):
   ```
   mkdir -p /restore/data && chmod 700 /restore/data
   tar -xzf backups/base-<stamp>/base.tar.gz -C /restore/data
   mkdir -p /restore/data/pg_wal && tar -xzf backups/base-<stamp>/pg_wal.tar.gz -C /restore/data/pg_wal
   touch /restore/data/recovery.signal
   cat >> /restore/data/postgresql.conf <<CONF
   restore_command='cp /path/to/wal-archive/%f %p'
   recovery_target_time='2026-09-28 21:30:00-04'
   recovery_target_action='promote'
   archive_mode=off
   CONF
   ```
4. Start Postgres on that directory (a throwaway container or `pg_ctl`), check
   the data, then point Cherry at it (or dump and load into the live database).
5. `python3 production_db.py verify` against the restored database.
6. Record the date, the target time, and the row counts you checked.

Logical drill (also required): `production_db.py backup`, then `restore-drill`
into a database whose name contains `restore` or `drill`.
