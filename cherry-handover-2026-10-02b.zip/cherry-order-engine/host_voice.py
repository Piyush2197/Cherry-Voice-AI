"""Lily's voice: the warm host, and the waiter's allergy question.

WHY THIS LIVES IN THE ENGINE, NOT IN THE MODEL
----------------------------------------------
The voice model speaks Cherry's text word for word — that is what stops it
inventing a dish or a price. So warmth cannot be left to the model's mood: it
has to be written here, in the lines the engine returns. It also means the
personality survives a change of model, because it is not the model's.

Everything that MUST happen — the allergy question above all — is enforced by
the engine (`CallSession.ready_to_place`), not requested of the model. A model
that "knows" to ask about allergies will still sometimes skip it on a noisy
call; the engine cannot.

THE ONE RULE ON ALLERGIES
-------------------------
Cherry can only pass an allergy on; it cannot clear a dish. So Lily never says
a dish is safe, writes what the caller said onto the order so the kitchen sees
it, and says plainly that she cannot check ingredients herself.
"""

from __future__ import annotations

import re
from typing import Sequence

GREETING = ("Thank you for calling {name}, this is Lily. "
            "What can I get started for you today?")

#: Openers for "I've added that". The first is the plain one, so a one-item
#: call sounds exactly as it always did; later items rotate.
ACKS: Sequence[str] = ("Got it", "Perfect", "Lovely", "Wonderful")

#: The caller said they want to order but named nothing.
WELCOME_ORDER: Sequence[str] = (
    "Absolutely, I'd be happy to help with that. What can I get started for you?",
    "Of course! What would you like to order?",
    "Wonderful, let's get that started. What can I get for you?",
)

ALLERGY_ASK = ("Almost there. Before I read that back, are there any allergies "
               "or dietary needs I should flag for the kitchen?")
ALLERGY_NONE = "Perfect, thank you."
ALLERGY_NOTED = ("Thank you for telling me. I've flagged that for the kitchen. "
                 "I can't check ingredients myself, so please mention it again "
                 "when you pick up.")
ALLERGY_FOLLOWUP = "Of course. What should I tell the kitchen?"

#: Said last on a call that went through. Only on success: a failed delivery
#: must never end with "enjoy your meal".
SIGN_OFF = " Thank you so much for calling, and enjoy your meal!"


def sign_off(name: str = "") -> str:
    """The same, by name when we have one."""
    first = (name or "").split()[0] if name else ""
    return (f" Thank you so much for calling, {first}, and enjoy your meal!"
            if first else SIGN_OFF)


def staff_line(allergy) -> str:
    """What the kitchen reads. One wording for the ticket, Square and the tablet.

    Empty when the question was answered "none" (nothing to flag), so a quiet
    ticket stays quiet; loud when there is a note, and explicit when the caller
    never answered, so silence is never mistaken for "no allergies".
    """
    if not allergy:
        return ""
    if allergy.get("note"):
        return f"ALLERGY / DIET (caller said): {allergy['note']}"
    if allergy.get("checked") is False:
        return "ALLERGIES NOT CONFIRMED - ask the guest at pickup"
    return ""


def staff_briefing(*, caller: str, name: str, reason: str, snapshot: dict) -> str:
    """The text the person who picks up a transferred call reads: who, why,
    and what is already in the cart, so they never start from zero. Two SMS
    segments at most."""
    lines = []
    for ln in (snapshot or {}).get("lines", [])[:5]:
        q = int(ln.get("quantity") or 1)
        size = f" {ln['size_name']}" if ln.get("size_name") else ""
        lines.append((f"{q}x " if q > 1 else "") + ln["item_name"] + size)
    cart = ("; ".join(lines) + (f" (about ${snapshot['total_cents'] / 100:.2f})"
                                if snapshot.get("total_cents") else "")) if lines else "no items yet"
    who = f"{name} " if name else ""
    flag = staff_line((snapshot or {}).get("allergy"))
    text = (f"Cherry transfer: {who}{caller or 'unknown number'}. "
            f"Why: {reason or 'caller asked for a person'}. Cart: {cart}.")
    if flag:
        text += f" {flag}."
    return text[:320]


#: A note longer than this is a transcript, not a note; Square's pickup note
#: holds 500 characters and the kitchen ticket has to stay readable.
NOTE_LIMIT = 300


# --- the greeting: time of day, and recognising a regular --------------------

GREETING_DAYPART = ("{part}, thank you for calling {name}. This is Lily. "
                    "What can I get started for you today?")
GREETING_BACK = "Welcome back to {name}! This is Lily. {offer}"
GREETING_BACK_NAMED = "Welcome back, {who}! This is Lily at {name}. {offer}"
OFFER_USUAL = ("Would you like the same as last time, {summary}, or something "
               "different today?")
OFFER_USUAL_LONG = "Would you like the same as your last order, or something different today?"
USUAL_ADDED = "Wonderful, I've added your usual: {summary}."
USUAL_NONE = "I don't have a previous order to repeat. What can I get started for you?"
USUAL_SKIPPED = " I couldn't repeat {skipped}. Would you like to choose something else for that?"


def day_part(hour) -> str:
    """'Good evening' — by the RESTAURANT's clock, and silent in the small hours
    (a 'good evening' at 1 a.m. sounds like a recording)."""
    if hour is None:
        return ""
    if 5 <= hour < 12:
        return "Good morning"
    if 12 <= hour < 17:
        return "Good afternoon"
    if 17 <= hour < 22:
        return "Good evening"
    return ""


def describe_lines(lines) -> str:
    """'the Chicken Korma and 2 Garlic Naan' for up to two lines; '' beyond that
    (a long list read back as an offer is a monologue)."""
    parts = []
    for ln in (lines or [])[:3]:
        q = int(ln.get("quantity") or 1)
        parts.append(f"{q} {ln['item_name']}" if q > 1 else f"the {ln['item_name']}")
    return " and ".join(parts) if 0 < len(parts) <= 2 else ""


# --- the name for the order ---------------------------------------------------

GATE_BOTH = ("Almost there. Can I get a name for the order, and are there any "
             "allergies or dietary needs I should flag for the kitchen?")
GATE_NAME = "Almost there. Can I get a name for the order?"
GATE_ALLERGY_AGAIN = ("Almost there. Last time you mentioned {note}. Does that "
                      "still apply?")
GATE_BOTH_AGAIN = ("Almost there. Can I get a name for the order? And last time "
                   "you mentioned {note}. Does that still apply?")
#: Not "thank you": the allergy acknowledgement that often follows in the same
#: breath already says it.
NAME_THANKS = ("Lovely to meet you, {first}!", "Nice to meet you, {first}.", "Great, {first}.")
NAME_RETRY = "Sorry, I didn't catch the name. Could you say it again?"

_NAME_LEAD = re.compile(
    r"^(?:(?:um+|uh+|er+|well|yeah|yes|sure|okay|ok|so|oh)[\s,.]+)*"
    r"(?:(?:it'?s|its|this is|my name is|my name's|name is|name's|the name is|"
    r"i am|i'm|im|call me|put it under|put it for|under|for|that's|thats|"
    r"me llamo|mi nombre es|soy|ponlo a nombre de|a nombre de|ismi|esmi|"
    r"mera naam|mera nam|naam)[\s,.]+)*",
    re.I)
_NAME_STOP = frozenset("""and please thanks thank no none nothing nope any allergies my is we i he she they hai hain
allergy allergic dietary nah yes yeah yep for the order with but also""".split())
_NAME_NOT = frozenset("""no none nothing nope nah yes yeah yep sure ok okay please
thanks thank you um uh good fine""".split())
_LETTERS = re.compile(r"[^\W\d_]+(?:['\u2019-][^\W\d_]+)*", re.UNICODE)


_FOOD_WORDS = None
_EXTRA_FOOD = frozenset("""pork beef meat chicken lamb onion onions garlic spicy spice
vegetarian vegan halal kosher gluten dairy nuts nut peanut peanuts shellfish shrimp
fish eggs egg soy sesame wheat milk cheese mushroom mushrooms celiac coeliac lactose
tomato tomatoes""".split())


def _food_words():
    """Words that are food or diet vocabulary, never a name ('shellfish')."""
    global _FOOD_WORDS
    if _FOOD_WORDS is None:
        import menu_enrichment as me
        words = set(_EXTRA_FOOD)
        for table in (me.ALLERGENS, me.DIETARY):
            for cid, (_label, aliases) in table.items():
                for name in (cid, *aliases):
                    words.update(re.findall(r"[a-z]+", name.lower()))
        _FOOD_WORDS = frozenset(words)
    return _FOOD_WORDS


def split_name(text: str):
    """('Sam Lee', 'no allergies') from "it's Sam Lee, no allergies".

    The name is up to three words, letters only, after any "my name is"; the
    rest is whatever followed it. ('', text) when there is no name in it
    ('no', 'nothing', anything with a digit).
    """
    raw = (text or "").strip()
    if re.search(r"\d", raw):
        return "", raw                   # a name has no digits ("3 people")
    t = _NAME_LEAD.sub("", raw)
    words, end = [], 0
    for m in _LETTERS.finditer(t):
        if m.group(0).lower() in _NAME_STOP:
            break
        if m.group(0).lower() in _food_words():
            break                        # "shellfish" is an allergy, not a name
        if words and re.search(r"[,.;:]", t[end:m.start()]):
            break                        # a comma ends the name: "Dana, my son is..."
        words.append(m.group(0))
        end = m.end()
        if len(words) == 3:
            break
    if not words or all(w.lower() in _NAME_NOT for w in words):
        return "", raw
    name = " ".join(w[:1].upper() + w[1:] for w in words)[:40]
    rest = t[end:].strip(" ,.;-")
    if re.fullmatch(r"(?i)(?:please|thanks|thank you)[\s,.!]*", rest):
        rest = ""                        # politeness is not an answer
    return name, rest


def extract_name(text: str) -> str:
    """'it's Sam Lee, thanks' -> 'Sam Lee'. '' when there is no name in it."""
    return split_name(text)[0]


# --- the number the checkout link is texted to --------------------------------

NUMBER_OK = "Perfect, I'll text it to the number ending in {digits}."
NUMBER_BAD = "I didn't quite get all ten digits. Could you say the number again?"
NUMBER_BLOCKED = "I'm not able to text that number. Is there another one I can use?"
_DIGIT_WORDS = {"zero": "0", "oh": "0", "o": "0", "one": "1", "two": "2", "three": "3",
                "four": "4", "five": "5", "six": "6", "seven": "7", "eight": "8", "nine": "9"}
_SPOKEN = "zero one two three four five six seven eight nine".split()


def parse_us_number(text: str) -> str:
    """'five eight six, 980-5199' -> '+15869805199'; '' when it is not a full
    US number (10 digits, or 11 with a leading 1, area code and exchange 2-9)."""
    digits = ""
    for tok in re.findall(r"[a-z]+|\d", (text or "").lower()):
        digits += _DIGIT_WORDS.get(tok, tok if tok.isdigit() else "")
    if len(digits) == 11 and digits[0] == "1":
        digits = digits[1:]
    if len(digits) != 10 or digits[0] in "01" or digits[3] in "01":
        return ""
    return "+1" + digits


def spoken_digits(digits: str) -> str:
    """'0123' -> 'zero one two three' (a TTS reads '0123' as a quantity)."""
    return " ".join(_SPOKEN[int(d)] for d in digits if d.isdigit())


# --- answering the questions a host answers all day ---------------------------

HOURS_OPEN = "We're open until {closes} today."
HOURS_CLOSED = "We're closed right now. We open {next_open}."
HOURS_UNKNOWN = "I don't have the hours in front of me. The restaurant can tell you."
WAIT_TIME = "Orders are usually ready in about {n} minutes."
#: Said with the read-back. In pay-now mode the kitchen starts when the guest
#: has paid, so the clock is promised from checkout, not from the call.
READY_AFTER_PAYING = " It should be ready about {n} minutes after you complete checkout."
READY_AT_PICKUP = " It should be ready in about {n} minutes, and you'll pay when you pick it up."
#: Said at the end of a pay-at-pickup call that did not already say it (no prep time configured).
PAY_AT_PICKUP = " You'll pay when you pick it up."
WAIT_UNKNOWN = "It depends on how busy we are. I'll tell you the time when I read your order back."
PICKUP_ONLY = "I take pickup orders by phone."
ADDRESS_UNKNOWN = ("I don't have the address in front of me. The restaurant's "
                   "website or maps listing will have it.")
INFO_GENERIC = "I can help with hours, wait times and your order. For anything else, the restaurant can tell you."

_TOPICS = (
    ("delivery", re.compile(r"\b(deliver|delivery|doordash|uber ?eats|grubhub)\b", re.I)),
    ("address", re.compile(r"\b(where|address|located|location|directions|parking|cross street)\b", re.I)),
    ("wait", re.compile(r"\b(how long|wait|ready|minutes|pick ?up time|long will)\b", re.I)),
    ("hours", re.compile(r"\b(open|close|closing|closes|hours|until|late|tonight|what time)\b", re.I)),
)


def info_topic(text: str) -> str:
    for name, rx in _TOPICS:
        if rx.search(text or ""):
            return name
    return ""


# --- what the voice worker enforces around the call ----------------------------

IDLE_PROMPT = "Are you still there? Take your time."
IDLE_GOODBYE = ("I'll let you go for now. Please call us back any time. "
                "Thank you!")
MAX_CALL_GOODBYE = ("I want to be sure you're taken care of, so let me connect "
                    "you with the restaurant.")

#: Sent to the voice worker with the tools. Silence and runaway calls cost real
#: money on every per-minute provider (Gemini Live bills silent audio like
#: speech), so the worker is told, once, when to prompt, when to give up and
#: how long any call may run. 8 s is long enough for a caller to think and
#: short enough that a dead line is not paid for.
CALL_POLICY = {
    "idle_prompt_after_seconds": 8,
    "idle_prompt": IDLE_PROMPT,
    "hang_up_after_idle_prompts": 2,
    "idle_goodbye": IDLE_GOODBYE,
    "max_call_seconds": 600,
    "max_call_goodbye": MAX_CALL_GOODBYE,
    # Gemini 3.8 Live defaults to NON-blocking tool calls (the model keeps
    # talking while a tool runs). Cherry's text must be spoken verbatim, so
    # every tool must be declared BLOCKING.
    "tool_behavior": "BLOCKING",
}


def rotate(bank: Sequence[str], n: int) -> str:
    """Deterministic, so a restart that replays the call says the same words."""
    return bank[n % len(bank)]


_WORDS = re.compile(r"[a-z0-9]+")

# Said when there is nothing to flag.
_NEGATIVE = frozenset("""no nope nah none nothing nada negative nobody not
never dont doesnt didnt good fine set
sin ninguna ninguno nunca bidun mafi mafee nahi nahin koi""".split())
# Filler that may surround a "no" without adding a restriction. Anything NOT in
# here ("no peanuts", "no pork") is a restriction and is recorded.
_FILLER = frozenset("""please thanks thank you at all that i im ive know of
really we have are is its it nothing special allergies allergy allergic
dietary restrictions restriction needs need to and or just aware as far
anyone anybody today tonight for us me my our were thats any all so
nobody
alergias alergia tengo gracias muchas hay para nosotros todo bien
hasasiya shukran afwan aywa hai hain kuch bilkul dhanyavad""".split())
_YES = frozenset("""yes yeah yep yup yea sure i do we have actually
unfortunately um uh well oh si claro naam aywa haan ji""".split())


def classify_allergy(text: str) -> str:
    """'empty' | 'none' | 'yes' | 'note'.

    Deliberately conservative toward recording: the only things treated as
    "nothing to flag" are short, plainly negative answers made entirely of
    negatives and filler. "No peanuts" is a restriction, not a refusal, and
    anything unrecognised is kept as a note rather than thrown away.
    """
    # "i'm" and "don't" become "im" and "dont": one spelling to match against.
    cleaned = _WORDS.findall((text or "").lower().replace("’", "'")
                             .replace("'", ""))
    if not cleaned:
        return "empty"
    if (len(cleaned) <= 8 and any(w in _NEGATIVE for w in cleaned)
            and all(w in _NEGATIVE or w in _FILLER for w in cleaned)):
        return "none"
    if all(w in _YES or w in _FILLER for w in cleaned):
        return "yes"                     # "yes" — but to WHAT? ask.
    return "note"


_AFFIRM = frozenset("""yes yeah yep yup yea sure ok okay absolutely definitely
fine perfect great good please thanks thank you that works sounds let lets do
it that thatd be i will""".split())
_AFFIRM_CORE = frozenset("yes yeah yep yup yea sure ok okay absolutely definitely fine perfect".split())
_REFUSE = frozenset("no nope nah never mind not".split())


_SAME = re.compile(
    r"(?i)(?:yes|yeah|yep|yup|same|still|that'?s right|correct|it does|they do|"
    r"same as (?:before|last time)|still the case|still applies?)[\s,.!]*")


def confirms_remembered(text: str) -> bool:
    """'yes', 'same as before', 'still the case' — to 'does that still apply?'"""
    return bool(_SAME.fullmatch((text or "").strip())) or is_yes(text)


def is_yes(text: str) -> bool:
    """A plain 'yes' to an offer. Conservative: anything else is not a yes."""
    w = _WORDS.findall((text or "").lower().replace("'", ""))
    return bool(w) and any(x in _AFFIRM_CORE for x in w) and all(x in _AFFIRM for x in w)


def is_no(text: str) -> bool:
    w = _WORDS.findall((text or "").lower().replace("'", ""))
    return bool(w) and w[0] in _REFUSE


SOLD_OUT_ONE = ("I'm so sorry, we're out of the {name} today. The {alt} is very "
                "close. Would you like that instead?")
SOLD_OUT_TWO = ("I'm so sorry, we're out of the {name} today. The {alt} or the "
                "{alt2} are very close. Would either of those work?")
SOLD_OUT_NONE = "I'm so sorry, we're out of the {name} today. What else can I get you?"
OFFER_DECLINED = "No problem at all. What else can I get you?"

_INTENT = re.compile(
    r"\b(order|pick ?up|take ?out|carry ?out|to go|place an?)\b", re.I)


def order_intent(text: str) -> bool:
    """'I'd like to place an order' — wants to order, named nothing yet."""
    return bool(_INTENT.search(text or ""))


def clean_note(text: str) -> str:
    """The caller's words, whitespace-collapsed and bounded."""
    return " ".join((text or "").split())[:NOTE_LIMIT]
