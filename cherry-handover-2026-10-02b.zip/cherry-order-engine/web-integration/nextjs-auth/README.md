# Cherry Voice AI - Next.js Authentication Integration

This directory contains the authentication middleware and API integration for connecting the Next.js website (cherryvoiceai.com) to the CHERRY backend.

## Setup

1. Copy the files to your Next.js project:
   - `middleware.ts` → Next.js `middleware.ts` (app directory root)
   - `lib/auth.ts`, `lib/session.ts`, `lib/cherry-api.ts`, `lib/rate-limit.ts`, `lib/safe-redirect.ts` → Next.js `lib/`
   - `app/api`, `app/login`, `app/dashboard` → Next.js `app/` (includes `app/api/auth/me`)

2. Install dependencies:
   ```bash
   npm install jose
   ```

3. Add environment variables to `.env.local`:
   ```env
   CHERRY_API_URL=https://your-cherry-api.com
   CHERRY_API_KEY=your-cherry-api-key
   # You choose these. There are NO defaults: with any of them missing or weak,
   # sign-in is switched off (and the server log says why).
   ADMIN_USERNAME=you@yourcompany.com
   ADMIN_PASSWORD=<at least 12 characters: openssl rand -base64 18>
   JWT_SECRET=<at least 32 characters: openssl rand -hex 32>
   ```

## Architecture

### Authentication Flow

1. User signs in with the `ADMIN_USERNAME` / `ADMIN_PASSWORD` you configured (no built-in login exists)
2. Server validates credentials
3. Server issues a JWT token
4. Token is stored in HTTP-only cookie
5. Middleware validates token on protected routes
6. Token is used to authenticate CHERRY API calls

### Security Features

- HTTP-only cookies (prevents XSS)
- Secure cookies (HTTPS only in production)
- JWT tokens with expiration
- CSRF protection
- Password hashing (bcrypt)
- API key validation

## Security notes

- **No default credentials, no default signing secret.** `lib/auth.ts` reads
  `ADMIN_USERNAME`, `ADMIN_PASSWORD` (12+ characters) and `JWT_SECRET` (32+
  characters) from the environment only. If any is missing, sign-in answers 503
  and logs which one; middleware keeps every protected path closed.
- **The middleware verifies the token** (`lib/session.ts`: HS256 only, issuer,
  audience, expiry) — it no longer accepts any cookie longer than ten characters.
- **Sessions last 12 hours** (`SESSION_HOURS` in `lib/session.ts`).
- **Sign-in is throttled**: 5 failures per 15 minutes per address and per
  username (`lib/rate-limit.ts`, in memory: one count per server process).
- **`?redirect=` only accepts a path on this site** (`lib/safe-redirect.ts`).
- **The dashboard is a client component and imports no server code.** It calls
  `/api/auth/me`, `/api/cherry/snapshot` and `/api/auth/logout`; only the
  routes read `CHERRY_API_KEY`.
- Passwords are compared in constant time. They are still plain environment
  values, not hashes in a user table — fine for one operator, not for a team.

**Verification status:** the TypeScript here was type-checked (strict) against
hand-written stubs for `next`, `react`, `jose` and `crypto`, and the redirect
guard and rate limiter were run under Node. It has **not** been built or run
inside a Next.js project, which is the real test: run `next build`, sign in, and
confirm `/dashboard` redirects when signed out. Written for Next 13.4–15
(`cookies()` is awaited, which works in all of them).
