#!/usr/bin/env python3
"""Understanding callers who order in Spanish, Arabic or Hindi/Urdu.

The rule this file protects above all: THE PHRASEBOOK NEVER CHANGES WHAT AN
ENGLISH CALLER GETS. A dish said exactly as the menu writes it (queso fundido,
chili con queso dip, dal makhani) must resolve to that dish, on every menu,
with the phrasebook on. After that: numbers, food words and "without" in three
languages must land the same cart an English caller would have got.
"""

from __future__ import annotations

import random
import sys
import traceback
from pathlib import Path

import agent_api
import menu_schema as ms
import phrasebook as pb
from order_engine import Matcher, parse_quantity

HERE = Path(__file__).resolve().parent
_passed = _failed = 0


def check(name, cond, detail=""):
    global _passed, _failed
    if cond:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


def menu(name):
    return ms.load_yaml(HERE / "menus" / f"{name}.yaml")


def cart(s):
    return [(l["item_name"], l["quantity"]) for l in s.snapshot()["lines"]]


def t_detection_needs_a_distinctive_word() -> None:
    check("plain English is not a language", pb.detect("two garlic naan please") is None)
    check("'do you have naan' is not Hindi (do = 2 only with Hindi evidence)",
          pb.detect("do you have naan") is None and pb.numbers_to_english("do you have naan") == "do you have naan")
    check("spanish is detected", pb.detect("quiero dos tacos") == "es")
    check("arabic is detected", pb.detect("wahid hommus shukran") == "ar")
    check("hindi is detected", pb.detect("ek chicken tikka bina mirch") == "hi")
    check("accents are folded", pb.detect("quiero camarón") == "es" and pb.to_english("camarón")[0] == "shrimp")
    check("with Hindi evidence, 'do' is two", pb.numbers_to_english("ek garlic naan aur do plain naan") == "1 garlic naan aur 2 plain naan",
          pb.numbers_to_english("ek garlic naan aur do plain naan"))
    check("'media docena' is six", pb.numbers_to_english("media docena de alitas") == "6 de alitas")
    check("nothing to translate -> unchanged and no language", pb.to_english("garlic naan") == ("garlic naan", None))


def t_quantities_in_three_languages() -> None:
    for text, want in (("dos tacos al pastor", 2), ("tres burritos", 3), ("media docena de chips", 6), ("una quesabirria", 1),
                       ("wahid hommus", 1), ("ithnain falafel", 2), ("thalatha tabbouli", 3),
                       ("ek garlic naan", 1), ("paanch samosa", 5), ("number 3 combo", 1), ("two tacos", 2), ("a couple of fries", 2),
                       ("do you have fries", 1)):
        check(f"parse_quantity({text!r}) == {want}", parse_quantity(text) == want, str(parse_quantity(text)))


def t_spanish_arabic_hindi_land_the_same_cart_as_english() -> None:
    jm, sk, pg, bnr = menu("juan-miguels-clinton"), menu("sams-kabob-clinton"), menu("pink-garlic-shelby"), menu("bun-n-run-ferndale")
    cases = [
        (jm, [("add_item", "quiero dos burritos"), ("answer", "pollo")], [("Burritos", 2)]),
        (jm, [("add_item", "una quesabirria por favor")], [("Quesabirria", 1)]),
        (jm, [("add_item", "tres kids taco")], [("Kids Taco", 3)]),
        (jm, [("add_item", "media docena de bag of chips")], [("Bag of Chips", 6)]),
        (sk, [("add_item", "wahid hommus")], [("Hommus", 1)]),
        (sk, [("add_item", "ithnain falafel plate")], [("Falafel Plate", 2)]),
        (sk, [("add_item", "thalatha tabbouli salad shukran")], [("Tabbouli Salad", 3)]),
        (pg, [("add_item", "ek garlic naan"), ("add_item", "aur do plain naan")], [("Garlic Naan", 1), ("Plain Naan", 2)]),
        (pg, [("add_item", "ek murgh makhani")], [("Butter Chicken (Creamy)", 1)]),
    ]
    for cfg, steps, want in cases:
        s = agent_api.CallSession(cfg)
        for tool, arg in steps:
            getattr(s, tool)(arg)
        check(f"{cfg.id}: {steps[0][1]!r} -> {want}", cart(s) == want, str(cart(s)))

    def line(cfg, base, tool, text):
        s = agent_api.CallSession(cfg)
        s.add_item(base)
        for _ in range(4):
            p = s.pending()
            if not p:
                break
            s.answer(cfg.option(p.candidates[0]).name if p.candidates else "")
        getattr(s, tool)(text)
        ln = s.snapshot()["lines"][-1]
        return [m["option_name"] for m in ln["modifiers"] if not m["is_default"]], ln["removed_defaults"]
    check("'sin cebolla' removes the onion exactly as 'no onion' does",
          line(bnr, "double cheeseburger", "remove_modifier", "sin cebolla") == line(bnr, "double cheeseburger", "remove_modifier", "no onion"))
    check("'queso extra' adds what 'extra cheese' adds",
          line(bnr, "double cheeseburger", "add_modifier", "queso extra") == line(bnr, "double cheeseburger", "add_modifier", "extra cheese"))
    check("'extra pollo' and 'zyada chicken' add Extra Chicken",
          "Extra Chicken" in line(pg, "chicken tikka", "add_modifier", "extra pollo")[0]
          and "Extra Chicken" in line(pg, "chicken tikka", "add_modifier", "zyada chicken")[0])
    cheng = menu("chengs-sterling-heights")
    s = agent_api.CallSession(cheng); s.add_item("egg roll")
    check("'grande' answers a size question (as 'large')", agent_api.CallSession is not None and
          "Large" in s.answer("grande")["say"])


def t_english_callers_are_never_changed() -> None:
    """Every item name and alias, on every menu, resolves to the same item with
    the phrasebook on as with it off. This is the property that makes it safe."""
    checked = 0
    for path in sorted((HERE / "menus").glob("*.yaml")) + sorted((HERE / "demos" / "prospects").glob("*.yaml")):
        try:
            cfg = ms.load_yaml(path)
        except Exception:                                    # noqa: BLE001
            continue
        m = Matcher(cfg)
        for item in cfg.items:
            for text in [item.name] + list(item.aliases):
                on = m.match_items(text)
                off = m._rank_words(text, m._item_names, "item")
                checked += 1
                same = (on[:1] and off[:1] and on[0].target_id == off[0].target_id and abs(on[0].score - off[0].score) < 1e-9) or (not on and not off)
                if not same:
                    check(f"{path.name}: {text!r} unchanged", False, f"on={[c.target_id for c in on[:2]]} off={[c.target_id for c in off[:2]]}")
    check("a large number of English names were checked", checked > 2500, str(checked))


def t_english_phrases_with_foreign_looking_words() -> None:
    jm = menu("juan-miguels-clinton")
    for text, want in (("chili con queso dip", "Chili Con Queso Dip"), ("do you have guacamole", "Guacamole"),
                       ("two kids taco", "Kids Taco"), ("a bag of chips please", "Bag of Chips")):
        s = agent_api.CallSession(jm)
        s.add_item(text)
        check(f"English {text!r} -> {want}", [n for n, _ in cart(s)] == [want], str(cart(s)))


def t_nothing_raises() -> None:
    rng = random.Random(5)
    words = ("quiero dos tres pollo sin cebolla con queso wahid shukran ek aur do teen murgh bina mirch the naan a an i would like "
             "123 ## ... ñ é ü pan y por favor ").split()
    bad = []
    for _ in range(3000):
        text = " ".join(rng.choice(words) for _ in range(rng.randint(1, 8)))
        try:
            out, lang = pb.to_english(text)
            n = pb.numbers_to_english(text)
            q = parse_quantity(text)
            assert isinstance(out, str) and isinstance(n, str) and 1 <= q <= 99
            if lang is None:
                assert out == text
        except Exception as exc:                                # noqa: BLE001
            bad.append((text, repr(exc)))
    check("3000 random mixed-language strings never raise", not bad, str(bad[:2]))


def main() -> int:
    global _failed
    for name, fn in sorted((k, v) for k, v in globals().items() if k.startswith("t_")):
        try:
            fn()
        except Exception:                                    # noqa: BLE001
            _failed += 1
            print(f"\n--- FAIL {name} raised")
            traceback.print_exc()
    print(f"{_passed} passed, {_failed} failed (phrasebook: es / ar / hi)")
    return 1 if _failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
