#!/usr/bin/env python3
"""
Go-live preflight — the checks that decide whether a launch happens.

The value of this tool is entirely in what it refuses. A preflight that always
says READY is worse than none, because it converts "I have not checked" into "I
checked". So these tests concentrate on the refusals, and on the two that have
already bitten this repository:

  * a direct staff line that equals the published number (a forwarding loop, and
    the reason the gateway refuses to start),
  * `--dev-checkout` left on, which marks orders paid without money moving.

They also pin the line between FAIL and WAITING. A FAIL is something wrong now;
WAITING is something a human still has to do (buy a number, get an owner's
signature). Collapsing the two either blocks a launch on an owner's paperwork or
lets a real defect through as "waiting".
"""

from __future__ import annotations

import io
import json
import os
import threading
import urllib.request

import go_live as gl
import pilot_deploy as pd

_passed = _failed = 0


def check(name, condition, detail=""):
    global _passed, _failed
    if condition:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


def group(rep, name):
    return [c for c in rep.checks if c.group == name]


def find(rep, needle):
    return [c for c in rep.checks if needle.lower() in c.name.lower()]


def status_of(rep, needle):
    hits = find(rep, needle)
    return hits[0].status if hits else "MISSING"


LOCATIONS = pd.load_manifest()

# The preflight checks that the secret dir exists; make the test own it rather
# than depend on a leftover /tmp directory from some earlier run.
import tempfile as _tf
SECRET_DIR = _tf.mkdtemp(prefix="glsecrets-test-")


def full_env(**over):
    """An environment that is deliberately complete, so each test can break
    exactly one thing."""
    env = {
        "CHERRY_API_KEY": "a" * 40,
        "CHERRY_VOICE_KEY": "b" * 40,
        "CHERRY_OAUTH_STATE_SECRET": "c" * 40,
        "CHERRY_SECRET_DIR": SECRET_DIR,
        "CHERRY_ALERT_PHONE": "+12485550100",
        "CHERRY_ALERT_WEBHOOK": "https://hooks.example.test/cherry",
        "CHERRY_CHECKOUT_HANDOFF_ONLY": "1",
        "TELNYX_API_KEY": "tlnx-key",
        "TELNYX_FROM_NUMBER": "+12485550111",
        "TELNYX_PUBLIC_KEY": "pubkey",
        "SQUARE_OAUTH_CLIENT_ID": "cid",
        "SQUARE_OAUTH_CLIENT_SECRET": "csec",
    }
    for n, loc in enumerate(LOCATIONS):
        # Distinct, well-formed, and never equal to each other or to a
        # published number: DID in the 555-1xxx range, staff line in 555-9xxx.
        env[loc.inbound_env] = f"+1313555{n:04d}"
        env[loc.fallback_env_name] = f"+1313999{n:04d}"
        env[f"SQUARE_TOKEN_{loc.id.upper().replace('-', '_')}"] = "tok"
        env[f"SQUARE_LOCATION_{loc.id.upper().replace('-', '_')}"] = "LOC1"
    env.update(over)
    return env


def run_checks(env, db=None, url=None):
    rep = gl.Report()
    gl.check_secrets(rep, env)
    gl.check_menus(rep, LOCATIONS)
    gl.check_routing(rep, LOCATIONS, env)
    gl.check_providers(rep, LOCATIONS, env)
    if url:
        gl.check_runtime(rep, url, env)
    return rep


# ---------------------------------------------------------------------------
# The refusals
# ---------------------------------------------------------------------------


def t_a_missing_direct_line_is_a_blocker_not_a_warning():
    """The exact failure seen in this repo: a fallback env var named wrongly.

    For tamago-sushi-bowl the inbound var is CHERRY_INBOUND_TAMAGO_HALL_RD while
    the fallback used to derive to ..._TAMAGO_SUSHI_BOWL. Setting the wrong one
    silently stored the PUBLISHED number, which forwards into Cherry.
    """
    env = full_env()
    # Simulate the operator setting the plausible-but-wrong name.
    env.pop("CHERRY_DIRECT_FALLBACK_TAMAGO_HALL_RD", None)
    env["CHERRY_DIRECT_FALLBACK_TAMAGO_SUSHI_BOWL"] = "+12485559007"
    rep = run_checks(env)
    hits = find(rep, "tamago-sushi-bowl direct staff line")
    check("the missing direct line is reported", bool(hits), "no check emitted")
    if hits:
        check("and it BLOCKS rather than waiting", hits[0].status == gl.FAIL,
              hits[0].status)
        check("and it says what to set",
              "CHERRY_DIRECT_FALLBACK_TAMAGO_HALL_RD" in hits[0].fix,
              hits[0].fix)
        check("and it explains the loop risk",
              "forwards into Cherry" in hits[0].detail, hits[0].detail)


def t_a_direct_line_equal_to_the_did_blocks():
    env = full_env()
    loc = LOCATIONS[0]
    env[loc.fallback_env_name] = env[loc.inbound_env]
    rep = run_checks(env)
    hits = find(rep, f"{loc.id} direct staff line")
    check("transfer target equal to the DID blocks",
          hits and hits[0].status == gl.FAIL,
          str([(h.status, h.detail) for h in hits]))


def t_duplicate_dids_block():
    env = full_env()
    a, b = LOCATIONS[0], LOCATIONS[1]
    env[b.inbound_env] = env[a.inbound_env]
    rep = run_checks(env)
    check("a shared DID blocks", status_of(rep, f"{b.id} DID") == gl.FAIL
          or status_of(rep, f"{b.id} DID is unique") == gl.FAIL,
          str([(c.name, c.status) for c in group(rep, "Routing")][:4]))


def t_placeholder_secrets_block():
    for bad in ("dev-secret", "changeme", "placeholder", ""):
        env = full_env(CHERRY_API_KEY=bad)
        rep = run_checks(env)
        hits = find(rep, "CHERRY_API_KEY")
        ok = hits and hits[0].status == gl.FAIL
        check(f"API key {bad!r} blocks", ok,
              str([(h.status, h.detail) for h in hits]))
    env = full_env(CHERRY_API_KEY="a-real-random-secret-value")
    rep = run_checks(env)
    check("a real key passes", status_of(rep, "CHERRY_API_KEY") == gl.PASS)


def t_an_unreadable_manifest_menu_blocks():
    rep = gl.Report()
    broken = pd.Location(id="x", group="g", name="X",
                         menu=None, catalog_status="ready",
                         inbound_env="CHERRY_INBOUND_X", fallback_phone="+1",
                         pos_type="manual_fallback")
    gl.check_menus(rep, [broken])
    check("a location with no menu blocks",
          status_of(rep, "every manifest menu loads") == gl.FAIL)


def t_dev_checkout_server_is_refused():
    """The guard that matters most: orders marked paid with no money."""
    import server as srv
    from order_store import OrderStore

    store = OrderStore.sqlite()
    store.upsert_restaurant("r", "R", "burger", active=True,
                            staff_phone="+13135550100",
                            inbound_phone="+13135550111")
    app = srv.Cherry(store, sms=srv.FakeSmsSender(), api_key="k",
                     dev_checkout=True)
    httpd = srv.build_server(app, 0)
    port = httpd.server_address[1]
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    try:
        rep = gl.Report()
        gl.check_runtime(rep, f"http://127.0.0.1:{port}", full_env())
        hits = find(rep, "checkout is real")
        check("a dev-checkout server is refused as live",
              hits and hits[0].status == gl.FAIL,
              str([(h.status, h.detail) for h in hits]))
        check("and the fix says to restart without it",
              hits and "--dev-checkout" in hits[0].fix, str(hits))
        check("the report as a whole is not ok",
              not gl.Report([hits[0]]).ok)
    finally:
        httpd.shutdown()
        httpd.server_close()


def t_an_unreachable_server_blocks():
    rep = gl.Report()
    gl.check_runtime(rep, "http://127.0.0.1:9", full_env())
    check("an unreachable server is a blocker",
          status_of(rep, "running server") == gl.FAIL)


# ---------------------------------------------------------------------------
# FAIL versus WAITING
# ---------------------------------------------------------------------------


def t_not_yet_bought_is_waiting_not_failed():
    """An owner's paperwork must not read as a defect, and vice versa."""
    env = full_env()
    for loc in LOCATIONS:
        env.pop(loc.inbound_env, None)
    rep = run_checks(env)
    st = {c.status for c in group(rep, "Routing")}
    check("a DID that has not been bought yet is WAITING", st == {gl.WAITING},
          str(st))
    check("and nothing in Routing blocks", not [c for c in group(rep, "Routing")
                                                if c.blocking])


def t_sqlite_is_waiting_for_a_pilot_not_a_failure():
    rep = gl.Report()
    gl.check_database(rep, "/tmp/anything.db")
    hits = find(rep, "database is production-grade")
    check("SQLite is called out", hits and hits[0].status == gl.WAITING,
          str([(h.status, h.detail) for h in hits]))
    check("but does not block", not (hits and hits[0].blocking))


def t_a_missing_database_blocks():
    rep = gl.Report()
    gl.check_database(rep, None)
    check("no database configured blocks",
          status_of(rep, "database configured") == gl.FAIL)


def t_alerts_missing_is_a_warning():
    rep = gl.Report()
    gl.check_providers(rep, [], full_env(CHERRY_ALERT_PHONE=""))
    check("no alert phone warns", status_of(rep, "alerts reach a handset") == gl.WARN)


def t_telnyx_missing_blocks_because_the_gateway_will_not_start():
    rep = gl.Report()
    gl.check_providers(rep, [], full_env(TELNYX_API_KEY=""))
    hits = find(rep, "Telnyx configured")
    check("missing Telnyx blocks", hits and hits[0].status == gl.FAIL, str(hits))
    check("and says the gateway will not start",
          hits and "refuses to start" in hits[0].fix, str(hits))


def t_a_complete_environment_reports_ready():
    rep = run_checks(full_env())
    blocking = [(c.group, c.name, c.status, c.detail) for c in rep.blocked]
    check("a complete environment has no blockers", not blocking, str(blocking))


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def t_cli_exit_codes_and_json():
    def run(argv, env):
        import contextlib
        saved = dict(os.environ)
        os.environ.clear()
        os.environ.update(env)
        buf = io.StringIO()
        try:
            with contextlib.redirect_stdout(buf):
                rc = gl.main(argv)
        finally:
            os.environ.clear()
            os.environ.update(saved)
        return rc, buf.getvalue()

    rc, out = run(["--no-color"], {})
    check("an unconfigured run exits 1", rc == 1, f"rc={rc}")
    check("and says NOT READY", "NOT READY" in out, out[:200])
    check("and names a fix", "fix:" in out)

    rc, out = run(["--json"], {})
    check("json mode exits 1 too", rc == 1, f"rc={rc}")
    payload = json.loads(out)
    check("json has an ok flag", payload["ok"] is False)
    check("json lists checks with fixes",
          payload["checks"] and "status" in payload["checks"][0])

    # A database is part of a complete environment; without one the run still
    # exits 1, which is correct and is covered by the unconfigured case above.
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        rc, out = run(["--no-color", "--db", f"{td}/cherry.db"], full_env())
    check("a complete environment exits 0", rc == 0, f"rc={rc}\n{out[-400:]}")
    check("and says READY", "READY" in out)
    check("while still listing what waits on a human",
          "still waiting on a human" in out or "READY" in out, out[-300:])


def t_wired_into_cherry_cli_with_working_flags():
    """`go-live --no-color` must survive the top-level parser.

    It did not at first: the subparser used argparse.REMAINDER, which does not
    forward a leading option, so the flag died at the top level with
    "unrecognized arguments". The flags are declared explicitly now; this pins
    that, because the failure was invisible in `--help`.
    """
    import contextlib
    import cherry
    import go_live

    seen = {}

    def fake_main(argv):
        seen["argv"] = list(argv)
        return 0

    real, go_live.main = go_live.main, fake_main
    try:
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            rc = cherry.main(["go-live", "--no-color", "--json",
                              "--db", "/tmp/x.db",
                              "--only", "tamago-sushi-bowl",
                              "--only", "pink-garlic"])
    finally:
        go_live.main = real

    check("the subcommand dispatches", rc == 0, f"rc={rc}")
    argv = seen.get("argv", [])
    check("--no-color reaches the preflight", "--no-color" in argv, str(argv))
    check("--json reaches the preflight", "--json" in argv, str(argv))
    check("--db is forwarded with its value",
          "--db" in argv and "/tmp/x.db" in argv, str(argv))
    check("every repeated --only is forwarded",
          argv.count("--only") == 2, str(argv))


def main():
    tests = [v for k, v in sorted(globals().items())
             if k.startswith("t_") and callable(v)]
    for fn in tests:
        try:
            fn()
        except Exception as exc:                       # noqa: BLE001
            import traceback
            check(f"{fn.__name__} raised", False, repr(exc))
            traceback.print_exc()
    if _failed:
        print(f"{_passed} passed, {_failed} failed (go-live preflight)")
        return 1
    print(f"{_passed} passed, 0 failed (go-live preflight)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
