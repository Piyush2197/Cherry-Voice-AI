#!/usr/bin/env python3
"""The owner-question ledger — questions accumulate; coding never blocks.

Every onboarding pass surfaces questions only the owner can answer: is the
Protein group really free, does this place genuinely have no tortilla choice,
what does "wild sauce" contain. The gate prints them and moves on; this
ledger REMEMBERS them, per restaurant, so nothing is asked twice and nothing
is lost between the sales visit and the go-live call.

Design rules:
  * accumulate, never block — the command always exits 0 and never gates a
    deploy; a restaurant can be READY with open questions (the owner call is
    on the checklist, not in the code path);
  * dedupe by stable id — a question's id is its text with counts collapsed,
    so "8 items missing allergens" and "12 items missing allergens" are the
    same question re-asked, not a new row;
  * answers are recorded, never applied — the menu is only changed by a
    person editing the YAML (or the alias flywheel), so the ledger can never
    silently rewrite food.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date, datetime
from pathlib import Path
from typing import Dict, List, Optional

import yaml


@dataclass
class Question:
    id: str
    text: str
    source: str          # "cuisine-library" | "gate" | "enrichment"
    asked: str           # ISO date first asked
    status: str = "open"  # open | answered | wontfix
    answer: str = ""
    updated: str = ""

    def to_dict(self) -> Dict:
        return {"id": self.id, "text": self.text, "source": self.source,
                "asked": self.asked, "status": self.status,
                "answer": self.answer, "updated": self.updated}

    @classmethod
    def from_dict(cls, d: Dict) -> "Question":
        return cls(id=d.get("id", ""), text=d.get("text", ""),
                   source=d.get("source", "gate"), asked=d.get("asked", ""),
                   status=d.get("status", "open"),
                   answer=d.get("answer", ""), updated=d.get("updated", ""))


def question_id(text: str) -> str:
    """Stable across runs: words only, counts collapsed, bounded."""
    words = re.sub(r"\d+", "N", text.lower())
    words = re.sub(r"[^a-z n]+", " ", words)
    words = re.sub(r"\s+", " ", words).strip()
    return re.sub(r"\s+", "-", words)[:120]


def collect(config) -> List[Question]:
    """Every open question this menu owes its owner, source-tagged."""
    today = date.today().isoformat()
    out: List[Question] = []

    try:
        import menu_ingest as mi
        for text in mi.library_lint(config, config.cuisine):
            out.append(Question(id=question_id(text), text=text,
                                source="cuisine-library", asked=today))
    except Exception:                              # advisory only
        pass

    try:
        from config_validator import lint_config
        for f in lint_config(config):
            if getattr(f, "level", "") == "WARN":
                out.append(Question(id=question_id(str(f)), text=str(f),
                                    source="gate", asked=today))
    except Exception:
        pass

    try:
        import menu_enrichment as me
        cov = me.coverage(config)
        counts = cov.counts
        total, complete = counts.get("items", 0), counts.get("complete", 0)
        if total and total > complete:
            text = (f"{total - complete} of {total} items have no allergen, "
                    f"dietary or description data — fill in with the owner; "
                    f"until then callers are told to check with the "
                    f"restaurant")
            out.append(Question(id=question_id(text), text=text,
                                source="enrichment", asked=today))
    except Exception:
        pass

    return out


def ledger_path(base: Path, restaurant_id: str) -> Path:
    return base / f"{restaurant_id}.yaml"


def load(base: Path, restaurant_id: str) -> Dict:
    p = ledger_path(base, restaurant_id)
    if p.exists():
        doc = yaml.safe_load(p.read_text()) or {}
        return {"restaurant": doc.get("restaurant", restaurant_id),
                "questions": [Question.from_dict(q)
                              for q in doc.get("questions", [])]}
    return {"restaurant": restaurant_id, "questions": []}


def save(base: Path, ledger: Dict) -> Path:
    base.mkdir(parents=True, exist_ok=True)
    p = ledger_path(base, ledger["restaurant"])
    doc = {"restaurant": ledger["restaurant"],
           "updated": datetime.now().isoformat(timespec="seconds"),
           "questions": [q.to_dict() for q in ledger["questions"]]}
    p.write_text(yaml.safe_dump(doc, sort_keys=False, allow_unicode=True,
                                width=100))
    return p


def accumulate(config, base: Path) -> tuple:
    """Merge today's questions into the restaurant's ledger. Returns
    (ledger, added_count). Existing entries keep status/answer/asked; a
    re-asked question only refreshes, never duplicates."""
    ledger = load(base, config.id)
    known = {q.id: q for q in ledger["questions"]}
    today = date.today().isoformat()
    added = 0
    for q in collect(config):
        if q.id in known:
            # same question, asked again: keep the answer, refresh the text
            old = known[q.id]
            old.text = q.text
            continue
        known[q.id] = q
        ledger["questions"].append(q)
        added += 1
    ledger["questions"].sort(key=lambda q: (q.status != "open", q.source,
                                            q.id))
    save(base, ledger)
    return ledger, added


def answer(base: Path, restaurant_id: str, qid: str, text: str,
           status: str = "answered") -> Optional[Question]:
    """Record the owner's answer. The menu is NOT touched here."""
    ledger = load(base, restaurant_id)
    for q in ledger["questions"]:
        if q.id == qid or q.id.startswith(qid):
            q.status = status
            q.answer = text
            q.updated = datetime.now().isoformat(timespec="seconds")
            save(base, ledger)
            return q
    return None


def open_questions(ledger: Dict) -> List[Question]:
    return [q for q in ledger["questions"] if q.status == "open"]


def render(ledger: Dict, show_all: bool = False) -> str:
    qs = ledger["questions"] if show_all else open_questions(ledger)
    lines = [f"{ledger['restaurant']}: "
             f"{len(open_questions(ledger))} open / "
             f"{len(ledger['questions'])} total"]
    for q in qs:
        mark = {"open": "?", "answered": "A", "wontfix": "-"}.get(q.status, "?")
        lines.append(f"  [{mark}] ({q.source}) {q.text}")
        if q.status == "answered" and q.answer:
            lines.append(f"        -> {q.answer}")
    return "\n".join(lines)
