"""
Telnyx SMS — the real sender.

WHAT THE DOCS ACTUALLY SAY, AND WHY THE CODE LOOKS LIKE THIS
------------------------------------------------------------
Four things about the Telnyx Messaging API shape this file, and three of them
are easy to get wrong:

1. **`to` is a STRING, not an array.** One API call per recipient. The
   *response* `to` is an array of per-recipient objects, which is what invites
   the mistake.

2. **A 200 means QUEUED, not delivered.** `data.to[0].status` comes back
   `queued` or `sending`. Delivery is only ever known from the
   `message.finalized` webhook. So `send()` returns a provider id and nothing
   more is claimed; `handle_webhook()` is what records what happened.

3. **The failures that matter arrive ASYNCHRONOUSLY.** Telnyx documents that
   API request errors (403xx) come back in the response, but *delivery* errors
   appear in the webhook. That includes the two that matter most to us:
      * 40010 — number not registered to a 10DLC campaign
      * 40300 — blocked, recipient sent STOP
   A retry classifier that only reads the send response cannot see either. That
   is the whole reason for the webhook path and the suppression list.

4. **A long code is rated at 0.1 messages/sec — one per ten seconds.** Telnyx
   queues the excess (4 hours, FIFO) rather than rejecting it, so this does not
   fail loudly; a busy dinner service just sees tickets arrive late. At the
   pilot volumes (100 calls/day at the busiest restaurant, 1-2 messages each)
   there is ample headroom, but `min_interval_seconds` exists so the spacing is
   ours to control rather than a surprise from the carrier.

ON THE ERROR TABLE BELOW
------------------------
Telnyx's own pages disagree about what a few codes mean — 40300 is documented
as both "blocked (STOP)" and "number not registered for 10DLC" on different
pages, and 40310/40313/40315 vary. So the table is deliberately conservative:
anything not explicitly known to be transient is treated as NOT retryable. A
wrongly-retried permanent failure burns dead air on a live call and can double
a message; a wrongly-not-retried transient one escalates to a human, which is
the safe direction.

CONFIGURATION
-------------
    TELNYX_API_KEY            the API key
    TELNYX_FROM_NUMBER        the 10DLC-registered sending number, +E.164
    TELNYX_MESSAGING_PROFILE  optional; required only for number pools or an
                              alphanumeric sender id, not for a plain `from`
"""

from __future__ import annotations

import json
import os
import socket
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

TELNYX_MESSAGES_URL = "https://api.telnyx.com/v2/messages"

# Documented by Telnyx as genuinely temporary — safe to retry as-is.
#   40006  recipient carrier is down
#   40008  general undeliverable, transient
_AUTO_RETRY = {"40006", "40008"}

# Retryable, but only after slowing down. Treated as retryable here because the
# backoff in deliver() is the "slowing down".
#   40011  carrier rate limit         40016  T-Mobile sending limit
#   40018  AT&T sending limit         40318  Telnyx queue full
_RETRY_AFTER_BACKOFF = {"40011", "40016", "40018", "40318"}

# Never retry. Retrying cannot change any of these.
#   40001/40003  invalid request      40010  no 10DLC campaign registration
#   40300        blocked / STOP       40305  'from' not on the messaging profile
#   40100        number not messaging-enabled
#   40314/40322  permanent delivery failures
_PERMANENT = {"40001", "40003", "40010", "40100", "40300", "40305",
              "40314", "40322"}

# Codes that mean the recipient must never be texted again.
_OPT_OUT = {"40300"}

# Codes that mean the SENDING NUMBER is not set up — an operator problem, not a
# per-message one. Worth its own alarm: every message will fail until fixed.
_SENDER_NOT_READY = {"40010", "40100", "40305", "40320"}

_STOP_WORDS = {"stop", "stopall", "stop all", "unsubscribe", "cancel", "end",
               "quit", "revoke", "optout", "opt-out", "opt out"}
_START_WORDS = {"start", "unstop", "yes", "optin", "opt-in"}


class SmsError(Exception):
    """A send that failed, carrying whether another attempt could ever help."""

    def __init__(self, detail: str, *, retryable: bool = False,
                 code: Optional[str] = None,
                 sender_not_ready: bool = False,
                 retry_after: Optional[float] = None) -> None:
        super().__init__(detail)
        self.detail = detail
        self.retryable = retryable
        self.code = code
        self.sender_not_ready = sender_not_ready
        self.retry_after = retry_after


def classify(codes: List[str], http_status: Optional[int] = None
             ) -> Tuple[bool, bool]:
    """(retryable, sender_not_ready) for a set of Telnyx error codes.

    Unknown codes are NOT retryable on purpose. An unrecognised failure that
    escalates to a human is recoverable; one that retries in a loop on a live
    call is dead air.
    """
    codes = [str(c) for c in codes]
    sender = any(c in _SENDER_NOT_READY for c in codes)
    if any(c in _PERMANENT for c in codes):
        return False, sender
    if any(c in _AUTO_RETRY or c in _RETRY_AFTER_BACKOFF for c in codes):
        return True, sender
    if http_status == 429:
        return True, sender
    if http_status is not None and http_status >= 500:
        return True, sender
    return False, sender


class TelnyxSmsSender:
    """Sends one SMS per call. Raises SmsError on failure.

    Honours a suppression list when a store is supplied: a number that has
    opted out is never texted, which is the only way to comply given that
    Telnyx reports the block after the fact.
    """

    name = "telnyx"

    def __init__(self, api_key: Optional[str] = None,
                 from_number: Optional[str] = None,
                 messaging_profile_id: Optional[str] = None,
                 *, store=None, timeout: float = 8.0,
                 min_interval_seconds: float = 0.0,
                 opener=None, clock=time.monotonic,
                 sleep=time.sleep) -> None:
        self.api_key = api_key or os.environ.get("TELNYX_API_KEY", "")
        self.from_number = from_number or os.environ.get("TELNYX_FROM_NUMBER", "")
        self.messaging_profile_id = (
            messaging_profile_id or os.environ.get("TELNYX_MESSAGING_PROFILE") or None)
        self.store = store
        self.timeout = timeout
        self.min_interval_seconds = min_interval_seconds
        self._opener = opener or urllib.request.urlopen
        self._clock = clock
        self._sleep = sleep
        self._last_send_at: Optional[float] = None
        if not self.api_key:
            raise ValueError(
                "TelnyxSmsSender needs an API key. Set TELNYX_API_KEY or pass "
                "api_key= — failing here rather than at 7pm on a Friday.")
        if not self.from_number:
            raise ValueError(
                "TelnyxSmsSender needs a from_number. Set TELNYX_FROM_NUMBER "
                "to the 10DLC-registered sending number in +E.164 form.")

    # -- sending ---------------------------------------------------------

    def send(self, to: str, body: str) -> str:
        """Send and return Telnyx's message id. Raises SmsError on failure.

        The id identifies a QUEUED message. Delivery is confirmed only by
        `handle_webhook`.
        """
        if self.store is not None and self.store.is_suppressed(to):
            raise SmsError(
                f"{to} has opted out of messages; not sending",
                retryable=False, code="suppressed")

        self._respect_rate()
        payload: Dict[str, Any] = {"from": self.from_number, "to": to,
                                   "text": body}
        if self.messaging_profile_id:
            payload["messaging_profile_id"] = self.messaging_profile_id

        req = urllib.request.Request(
            TELNYX_MESSAGES_URL,
            data=json.dumps(payload).encode(),
            headers={"Authorization": f"Bearer {self.api_key}",
                     "Content-Type": "application/json",
                     "Accept": "application/json"},
            method="POST")

        try:
            with self._opener(req, timeout=self.timeout) as resp:
                raw = resp.read()
                status = getattr(resp, "status", 200)
        except urllib.error.HTTPError as exc:
            raw = exc.read() if hasattr(exc, "read") else b""
            status = exc.code
            codes, detail = _parse_errors(raw)
            retryable, sender = classify(codes, status)
            retry_after = _retry_after(getattr(exc, "headers", None))
            raise SmsError(f"telnyx {status}: {detail}", retryable=retryable,
                           code=codes[0] if codes else str(status),
                           sender_not_ready=sender,
                           retry_after=retry_after) from exc
        except urllib.error.URLError as exc:
            # No response at all — the network, not Telnyx. Always worth retrying.
            raise SmsError(f"telnyx unreachable: {exc.reason}",
                           retryable=True, code="transport") from exc
        except (TimeoutError, socket.timeout) as exc:
            # socket.timeout is not a TimeoutError before Python 3.10, and an
            # unclassified one would escape send() as a raw OSError.
            raise SmsError("telnyx timed out", retryable=True,
                           code="timeout") from exc
        except OSError as exc:                       # reset, broken pipe
            raise SmsError(f"telnyx connection failed: {exc}",
                           retryable=True, code="transport") from exc

        self._last_send_at = self._clock()
        try:
            doc = json.loads(raw)
        except ValueError as exc:
            raise SmsError(f"telnyx returned unparseable body: {raw[:200]!r}",
                           retryable=False, code="bad_response") from exc

        data = doc.get("data") or {}
        msg_id = data.get("id")
        if not msg_id:
            codes, detail = _parse_errors(raw)
            retryable, sender = classify(codes, status)
            raise SmsError(f"telnyx accepted nothing: {detail}",
                           retryable=retryable,
                           code=codes[0] if codes else "no_id",
                           sender_not_ready=sender)
        return str(msg_id)

    def _respect_rate(self) -> None:
        """Space sends out when asked to.

        A Telnyx long code is rated at 0.1 messages/sec. Telnyx queues rather
        than rejects, so exceeding it shows up as late tickets rather than
        errors — which is worse, because nothing alerts.
        """
        if not self.min_interval_seconds or self._last_send_at is None:
            return
        wait = self.min_interval_seconds - (self._clock() - self._last_send_at)
        if wait > 0:
            self._sleep(wait)


def _parse_errors(raw: bytes) -> Tuple[List[str], str]:
    """Pull codes and a readable detail out of a Telnyx error body.

    `code` is a JSON string in Telnyx's schema even though it looks numeric, so
    everything here stays a string.
    """
    try:
        doc = json.loads(raw or b"{}")
    except ValueError:
        return [], (raw[:200].decode("utf-8", "replace") if raw else "no body")
    errs = doc.get("errors") or []
    codes = [str(e.get("code")) for e in errs if e.get("code") is not None]
    parts = [str(e.get("detail") or e.get("title") or "") for e in errs]
    detail = "; ".join(p for p in parts if p) or "no detail"
    if codes:
        detail = f"[{', '.join(codes)}] {detail}"
    return codes, detail


def _retry_after(headers) -> Optional[float]:
    if not headers:
        return None
    for key in ("retry-after", "Retry-After"):
        val = headers.get(key) if hasattr(headers, "get") else None
        if val:
            try:
                return float(val)
            except (TypeError, ValueError):
                return None
    return None


# ---------------------------------------------------------------------------
# The webhook — where the truth arrives
# ---------------------------------------------------------------------------

_FINAL_OK = {"delivered"}
_FINAL_BAD = {"sending_failed", "delivery_failed", "expired"}


def handle_webhook(store, payload: Dict[str, Any]) -> Dict[str, Any]:
    """Apply a Telnyx message webhook. Returns what was done, for logging.

    Handles both directions:

    * OUTBOUND finalisation — records whether the message actually arrived, and
      suppresses the number on an opt-out code. This is the only place a STOP
      block becomes visible, because Telnyx does not report it in the send
      response.

    * INBOUND message — a reply. STOP suppresses, START un-suppresses. Anything
      else is logged for a human; we do not run an SMS conversation.

    The payload is treated as untrusted input: missing and unexpected fields
    produce a recorded no-op, never an exception. A webhook handler that raises
    makes the provider retry, which multiplies the problem.
    """
    data = (payload or {}).get("data") or {}
    event_type = str(data.get("event_type") or "")
    p = data.get("payload") or {}
    direction = str(p.get("direction") or "")

    if direction == "inbound" or event_type == "message.received":
        return _handle_inbound(store, p)

    ref = p.get("id")
    if not ref:
        store.log_event("sms.webhook_ignored",
                        detail={"reason": "no message id", "event": event_type})
        return {"action": "ignored", "reason": "no message id"}

    to_entries = p.get("to") or []
    status = str((to_entries[0].get("status") if to_entries else "") or "")
    errors = p.get("errors") or []
    codes = [str(e.get("code")) for e in errors if e.get("code") is not None]
    detail = "; ".join(str(e.get("detail") or e.get("title") or "")
                       for e in errors) or None
    phone = (to_entries[0].get("phone_number") if to_entries else None)

    if status in _FINAL_OK:
        store.update_sms_status(str(ref), "delivered")
        return {"action": "delivered", "provider_ref": str(ref)}

    if status in _FINAL_BAD or codes:
        store.update_sms_status(str(ref), "failed",
                                error_detail=f"[{','.join(codes)}] {detail or status}")
        row = store.sms_by_ref(str(ref))
        opted_out = any(c in _OPT_OUT for c in codes)
        if opted_out and phone:
            store.suppress(phone, f"provider code {','.join(codes)}",
                           "provider_error")
        if any(c in _SENDER_NOT_READY for c in codes):
            # Every message will fail until an operator fixes this, so it is
            # not a per-order problem and must not be logged as one.
            store.log_event("sms.sender_not_ready",
                            detail={"codes": codes, "detail": detail,
                                    "note": "the sending number is not "
                                            "provisioned; all SMS will fail"})
        store.log_event("sms.failed",
                        order_id=row["order_id"] if row else None,
                        detail={"codes": codes, "status": status,
                                "detail": detail, "suppressed": opted_out})
        return {"action": "failed", "codes": codes, "suppressed": opted_out}

    # queued / sending / delivery_unconfirmed — not final, nothing to conclude
    store.update_sms_status(str(ref), "sent")
    return {"action": "in_flight", "status": status}


def _handle_inbound(store, p: Dict[str, Any]) -> Dict[str, Any]:
    frm = (p.get("from") or {})
    phone = frm.get("phone_number") if isinstance(frm, dict) else None
    text = str(p.get("text") or "")
    word = " ".join(text.strip().lower().strip(".!?").split())

    if phone and word in _STOP_WORDS:
        store.suppress(phone, f"replied {word!r}", "inbound_stop")
        return {"action": "suppressed", "phone": phone}

    if phone and word in _START_WORDS:
        store.unsuppress(phone)
        store.log_event("sms.opted_back_in", detail={"phone": phone})
        return {"action": "unsuppressed", "phone": phone}

    # A customer may text a card number back to the checkout link; it must
    # never reach the database or the backups.
    from payments import scrub_payment_text
    text = scrub_payment_text(text)
    if phone:
        store.log_sms(phone, text, "reply", direction="in",
                      from_phone=phone, status="delivered")
    store.log_event("sms.inbound", detail={"phone": phone, "text": text[:200]})
    return {"action": "logged", "phone": phone}
