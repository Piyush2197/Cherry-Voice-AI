#!/usr/bin/env python3
"""The owner-question ledger — questions accumulate, coding never blocks.

Rules under test:
  * collecting twice adds nothing (idempotent — no duplicate rows);
  * question ids are stable even when counts inside the text change;
  * answers are recorded and the question leaves the open list, but the
    MENU IS NEVER TOUCHED by an answer;
  * the command never gates: exit 0 even with every question open;
  * every menu in menus/ can produce a ledger (the accumulator runs fleet-wide).
"""

from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path

import menu_schema as ms
import owner_questions as oq
import yaml

HERE = Path(__file__).parent
MENUS = HERE / "menus"
CHERRY = HERE / "cherry.py"

_passed, _failed = 0, 0


def check(name: str, cond: bool, detail: str = "") -> None:
    global _passed, _failed
    if cond:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail[:260]}" if detail else ""))


def t_collect_produces_questions() -> None:
    cfg = ms.load_yaml(MENUS / "pink-garlic-shelby.yaml")
    qs = oq.collect(cfg)
    check("PG Shelby owes its owner questions", len(qs) >= 3, str(len(qs)))
    sources = {q.source for q in qs}
    check("questions are source-tagged", "cuisine-library" in sources,
          str(sources))
    check("every question has a stable non-empty id",
          all(q.id and q.text for q in qs), "")


def t_accumulate_is_idempotent() -> None:
    cfg = ms.load_yaml(MENUS / "tamago-sushi-bowl.yaml")
    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        _, added1 = oq.accumulate(cfg, base)
        _, added2 = oq.accumulate(cfg, base)
        check("first run adds questions", added1 > 0, str(added1))
        check("second run adds nothing", added2 == 0, str(added2))
        ledger = oq.load(base, cfg.id)
        texts = [q.id for q in ledger["questions"]]
        check("no duplicate ids in the ledger",
              len(texts) == len(set(texts)), str(len(texts)))


def t_ids_survive_changing_counts() -> None:
    """'8 items missing allergens' and '12 items missing' are the same row."""
    a = oq.question_id("8 of 144 items have no allergen data — ask the owner")
    b = oq.question_id("12 of 144 items have no allergen data — ask the owner")
    check("count changes do not mint new ids", a == b, f"{a} vs {b}")
    check("different questions keep different ids",
          a != oq.question_id("Group 'Protein' is entirely $0.00"))


def t_answers_record_but_never_touch_the_menu() -> None:
    cfg = ms.load_yaml(MENUS / "bun-n-run-ferndale.yaml")
    menu_before = (MENUS / "bun-n-run-ferndale.yaml").read_text()
    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        ledger, _ = oq.accumulate(cfg, base)
        q = oq.open_questions(ledger)[0]
        got = oq.answer(base, cfg.id, q.id, "Owner says: yes, free refills")
        check("answer is recorded", got is not None and got.status == "answered"
              and "free refills" in got.answer, str(got))
        ledger2 = oq.load(base, cfg.id)
        check("answered question leaves the open list",
              q.id not in {x.id for x in oq.open_questions(ledger2)}, "")
        check("menu file untouched by answering",
              menu_before == (MENUS / "bun-n-run-ferndale.yaml").read_text(), "")
    # partial-id answering works (owner pastes a prefix)
    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        ledger, _ = oq.accumulate(cfg, base)
        q = oq.open_questions(ledger)[0]
        got = oq.answer(base, cfg.id, q.id[:20], "ok")
        check("a question-id prefix is accepted", got is not None, q.id)


def t_command_never_gates_and_runs_fleet_wide() -> None:
    for menu in sorted(MENUS.glob("*.yaml")):
        with tempfile.TemporaryDirectory() as td:
            r = subprocess.run(
                [sys.executable, str(CHERRY), "owner-questions", str(menu),
                 "--dir", td],
                capture_output=True, text=True, timeout=120)
            check(f"exit 0 with open questions: {menu.name}",
                  r.returncode == 0, r.stderr[:200])
    # the seeded fleet ledger answers from earlier runs are preserved
    seeded = HERE / "owner_questions" / "tamago-sushi-bowl.yaml"
    if seeded.exists():
        doc = yaml.safe_load(seeded.read_text())
        answered = [q for q in doc.get("questions", [])
                    if q.get("status") == "answered"]
        check("the live ledger kept the recorded owner answer",
              len(answered) >= 1, str(len(answered)))


def t_render_is_owner_readable() -> None:
    cfg = ms.load_yaml(MENUS / "juan-miguels-clinton.yaml")
    with tempfile.TemporaryDirectory() as td:
        ledger, _ = oq.accumulate(cfg, Path(td))
        text = oq.render(ledger)
        check("render names the restaurant", "juan-miguels-clinton" in text, "")
        check("render marks open questions", "[?]" in text, text[:120])
        check("render tags sources", "(cuisine-library)" in text, "")


def main() -> None:
    batteries = [
        t_collect_produces_questions,
        t_accumulate_is_idempotent,
        t_ids_survive_changing_counts,
        t_answers_record_but_never_touch_the_menu,
        t_command_never_gates_and_runs_fleet_wide,
        t_render_is_owner_readable,
    ]
    for fn in batteries:
        print(f"== {fn.__name__}")
        fn()
    print(f"\n{_passed} passed, {_failed} failed")


if __name__ == "__main__":
    main()
