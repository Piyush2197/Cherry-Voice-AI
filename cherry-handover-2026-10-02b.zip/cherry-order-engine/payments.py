"""
Payment — relay only.

THE RULE
--------
Cherry never collects money and never touches payment data. The restaurant's
POS is the merchant of record. Cherry's entire involvement is:

    1. ask the POS for its own hosted checkout link
    2. text that link to the customer
    3. write down what the POS later says happened

That is it. No card number, no CVV, no expiry, no cardholder name, no bank
detail, no payment token is accepted, stored, logged or passed through — by
this module or any other. `reject_payment_data()` below is a live guard, not
a comment: it raises if anything that looks like card data reaches it, so a
well-meaning future change fails loudly instead of quietly creating a PCI
obligation nobody signed up for.

WHAT THIS BUYS
--------------
Cherry stays out of PCI scope entirely. There is no SAQ to complete, no
tokenisation vault, no key rotation, and a breach of Cherry's database
exposes no payment instrument. The cost is that payment status is only as
good as what the POS reports back — which is the right trade at this stage.

PILOT POLICY
------------
Every pilot menu has a zero pay-now threshold. An itemized hosted checkout is
required for every amount. In checkout-handoff-only mode Cherry stops after
sending the link and never sends a separate kitchen ticket. The earlier paid
release mode remains available for deployments that explicitly use it.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Callable, Dict, Optional, Protocol

# ---------------------------------------------------------------------------
# The guard
# ---------------------------------------------------------------------------

# Deliberately broad. A false positive here costs someone thirty seconds of
# confusion; a false negative costs a PCI incident.
_CARD_LIKE = re.compile(r"\b(?:\d[ -]?){13,19}\b")
_FORBIDDEN_KEYS = {
    "card", "card_number", "cardnumber", "pan", "cvv", "cvc", "cvv2", "csc",
    "expiry", "exp_month", "exp_year", "cardholder", "cardholder_name",
    "account_number", "routing_number", "iban", "sort_code", "track_data",
    "payment_token", "card_token", "nonce",
}


_CARD_RUN = re.compile(r"(?<![\d])(?:\d[ -]?){12,18}\d(?![\d])")


def scrub_payment_text(text: str) -> str:
    """Replace anything in free text that passes a card checksum.

    A caller can read a card number aloud while ordering, or a customer can
    text one back to a checkout link; either arrives as ordinary text and used
    to be stored verbatim in transcripts, the call journal and backups.
    Refusing the whole turn would hang up on a customer who merely said a long
    number, so the digits are removed and the rest is kept.
    """
    if not isinstance(text, str) or len(text) < 13:
        return text

    def _sub(match):
        return "[card number removed]" if _luhn(match.group(0)) else match.group(0)

    return _CARD_RUN.sub(_sub, text)


class PaymentDataRefused(Exception):
    """Raised when something that looks like payment data reaches Cherry."""


def reject_payment_data(value, where: str = "payload") -> None:
    """Raise if `value` looks like it carries payment data.

    Call this at every boundary where data arrives from a POS, a webhook, or
    a caller transcript before it is stored. It is cheap and it is the
    difference between a rule and a wish.
    """
    if isinstance(value, dict):
        for k, v in value.items():
            if str(k).strip().lower().replace("-", "_") in _FORBIDDEN_KEYS:
                raise PaymentDataRefused(
                    f"{where}: refusing key {k!r}. Cherry never stores payment "
                    f"data — the POS is the merchant of record.")
            reject_payment_data(v, f"{where}.{k}")
        return
    if isinstance(value, (list, tuple)):
        for i, v in enumerate(value):
            reject_payment_data(v, f"{where}[{i}]")
        return
    if isinstance(value, str):
        candidate = value.strip()
        if _CARD_LIKE.fullmatch(candidate) and _luhn(candidate):
            raise PaymentDataRefused(
                f"{where}: refusing a value that passes a card checksum. "
                f"Cherry never stores payment data.")


def _luhn(text: str) -> bool:
    digits = [int(c) for c in re.sub(r"[ -]", "", text) if c.isdigit()]
    if not 13 <= len(digits) <= 19:
        return False
    total, parity = 0, len(digits) % 2
    for i, d in enumerate(digits):
        if i % 2 == parity:
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return total % 10 == 0


# ---------------------------------------------------------------------------
# The POS side
# ---------------------------------------------------------------------------


@dataclass
class PayLink:
    url: str
    expires_at: Optional[str] = None
    pos_ref: Optional[str] = None
    provider_link_ref: Optional[str] = None

    def __post_init__(self) -> None:
        if not self.url.startswith("https://"):
            raise ValueError(
                f"pay link must be https, got {self.url!r} — a payment link "
                f"over plain http is not one we will text to a customer")


class PayLinkProvider(Protocol):
    """A POS that can issue its own hosted checkout link."""

    name: str

    def create_pay_link(self, order_id: str, amount_cents: int,
                        pos_order_ref: Optional[str], *, snapshot: dict,
                        context: Dict[str, Any]) -> PayLink: ...

    def revoke_pay_link(self, provider_link_ref: str) -> None: ...


class FakePayLinkProvider:
    """Test double. Issues a plausible https link; holds no payment data."""

    name = "fake"

    def __init__(self, fail: bool = False) -> None:
        self.fail = fail
        self.created: list = []
        self.requests: list = []
        self.revoked: list = []

    def create_pay_link(self, order_id: str, amount_cents: int,
                        pos_order_ref: Optional[str] = None, *, snapshot: dict,
                        context: Dict[str, Any]) -> PayLink:
        if self.fail:
            raise ConnectionError("simulated POS timeout creating pay link")
        if snapshot.get("total_cents") is not None and int(snapshot["total_cents"]) != int(amount_cents):
            raise ValueError("checkout amount does not match immutable order")
        self.requests.append({"order_id": order_id, "amount_cents": amount_cents,
                              "snapshot": snapshot, "context": context})
        link = PayLink(
            url=f"https://pay.example-pos.test/{order_id[:8]}",
            expires_at=(datetime.now(timezone.utc) + timedelta(hours=2)
                        ).isoformat(timespec="seconds"),
            pos_ref=pos_order_ref or f"pos-{order_id[:8]}",
            provider_link_ref=f"link-{order_id[:8]}")
        self.created.append(link)
        return link

    def revoke_pay_link(self, provider_link_ref: str) -> None:
        if self.fail:
            raise ConnectionError("simulated POS timeout revoking pay link")
        self.revoked.append(provider_link_ref)


# ---------------------------------------------------------------------------
# Flow
# ---------------------------------------------------------------------------

PAY_LINK_SMS = (
    "{restaurant}: your order #{code} is ${dollars}. "
    "Review your order and pay on the restaurant's secure page: {url} "
    "Wrong item? Do not pay; call {contact} for a correction.")


def _checkout_message(rest, row, amount: int, url: str) -> str:
    return PAY_LINK_SMS.format(
        restaurant=(rest["name"] if rest else "Your order"),
        code=row["short_code"], dollars=f"{amount // 100}.{amount % 100:02d}",
        url=url, contact=(rest["staff_phone"] if rest and rest["staff_phone"]
                          else "the restaurant"))


def arrange_payment(store, order_id: str, *, sms, provider=None,
                    customer_phone: Optional[str] = None) -> str:
    """Decide what payment this order needs, and set it up. Returns status.

    Under the restaurant's threshold: pay at pickup, no link, nothing to do.
    Over it: ask the POS for a link and text it. Cherry never sees a card
    either way.
    """
    row = store.order(order_id)
    if row is None:
        raise LookupError(f"no such order {order_id}")
    snapshot = store.order_snapshot(order_id)
    reject_payment_data(snapshot, "order snapshot")

    amount = int(row["total_cents"])
    rest = store.restaurant(row["restaurant_id"])
    phone = customer_phone or row["customer_phone"]
    existing = payment_for(store, order_id)
    if existing and existing["status"] in ("link_sent", "paid", "expired",
                                            "failed", "refunded"):
        return existing["status"]
    if existing and existing["status"] == "link_pending" and existing["pay_url"]:
        # A previous SMS may have failed. Reuse that *same* hosted checkout;
        # never create a second payable POS order on a voice/webhook retry.
        if phone:
            body = _checkout_message(rest, row, amount, existing["pay_url"])
            try:
                ref = sms.send(phone, body)
            except Exception as exc:
                store.log_event("payment.sms_retry_failed", order_id=order_id,
                                detail={"error": str(exc)})
                return "link_pending"
            store.log_sms(phone, body, "pay_link", order_id=order_id,
                          restaurant_id=row["restaurant_id"],
                          provider_ref=ref, status="sent")
            with store.tx() as conn:
                conn.execute("""UPDATE payment SET status='link_sent',
                    link_sent_at=?,updated_at=? WHERE order_id=?
                    AND status='link_pending'""", (
                        datetime.now(timezone.utc).isoformat(timespec="seconds"),
                        datetime.now(timezone.utc).isoformat(timespec="seconds"),
                        order_id))
            return "link_sent"
        return "link_pending"

    if snapshot.get("payment_mode") != "pay_now":
        _write_payment(store, order_id, method="at_pickup",
                       status="not_required", amount_cents=amount)
        return "not_required"

    if provider is None:
        # A pay-now order must never quietly become pay-at-pickup.  Doing so
        # would send food to the kitchen before the customer reviewed the
        # itemized checkout — exactly the race this gate exists to prevent.
        _write_payment(store, order_id, method="pay_link",
                       status="link_pending", amount_cents=amount)
        store.log_event("payment.no_provider", order_id=order_id,
                        restaurant_id=row["restaurant_id"],
                        detail={"amount_cents": amount,
                                "note": "pay-now order held; no itemized "
                                        "checkout provider is configured"})
        return "link_pending"

    if not phone:
        _write_payment(store, order_id, method="pay_link",
                       status="link_pending", amount_cents=amount)
        store.log_event("payment.no_phone", order_id=order_id,
                        restaurant_id=row["restaurant_id"],
                        detail={"amount_cents": amount})
        return "link_pending"

    try:
        link = provider.create_pay_link(
            order_id, amount, None, snapshot=snapshot,
            context={"restaurant_id": row["restaurant_id"],
                     "restaurant_name": rest["name"] if rest else row["restaurant_id"],
                     "short_code": row["short_code"],
                     "customer_name": row["customer_name"] or "",
                     "customer_phone": phone or "",
                     "tax_rate_bps": int(rest["tax_rate_bps"] or 0)
                     if rest else 0})
    except Exception as exc:
        _write_payment(store, order_id, method="pay_link",
                       status="link_pending", amount_cents=amount)
        # restaurant_id matters: the operations monitor groups "callers
        # cannot get a checkout link" per restaurant and ignores events
        # that do not name one.
        store.log_event("payment.link_failed", order_id=order_id,
                        restaurant_id=row["restaurant_id"],
                        detail={"error": str(exc)})
        return "link_pending"

    body = _checkout_message(rest, row, amount, link.url)
    # Record the link BEFORE texting it. A database error after the text went
    # out would leave a live, payable checkout that Cherry has no record of
    # (and the caller would be told checkout failed).
    _write_payment(store, order_id, method="pay_link",
                   status="link_pending", amount_cents=amount,
                   pay_url=link.url, pay_url_expires_at=link.expires_at,
                   pos_payment_ref=link.pos_ref,
                   provider_link_ref=link.provider_link_ref)
    try:
        ref = sms.send(phone, body)
        sms_status = "sent"
    except Exception as exc:
        store.log_sms(phone, body, "pay_link", order_id=order_id,
                      restaurant_id=row["restaurant_id"], status="failed",
                      error_detail=str(exc))
        return "link_pending"

    store.log_sms(phone, body, "pay_link", order_id=order_id,
                  restaurant_id=row["restaurant_id"], provider_ref=ref,
                  status=sms_status)
    _write_payment(store, order_id, method="pay_link", status="link_sent",
                   amount_cents=amount, pay_url=link.url,
                   pay_url_expires_at=link.expires_at,
                   pos_payment_ref=link.pos_ref,
                   provider_link_ref=link.provider_link_ref, link_sent=True)
    store.log_event("payment.link_sent", order_id=order_id,
                    restaurant_id=row["restaurant_id"],
                    detail={"amount_cents": amount, "pos_ref": link.pos_ref})
    return "link_sent"


def mark_paid(store, order_id: str, pos_payment_ref: str,
              raw_pos_payload: Optional[dict] = None) -> bool:
    """Record that the POS says this order is paid.

    The payload is scanned before anything is written: a POS webhook is the
    single most likely place for card data to arrive uninvited.
    """
    if raw_pos_payload is not None:
        reject_payment_data(raw_pos_payload, "pos webhook")
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    with store.tx() as c:
        cur = c.execute("""UPDATE payment SET status='paid',
                     pos_payment_ref=COALESCE(pos_payment_ref, ?),
                     settled_at=?, updated_at=?
                     WHERE order_id=?
                       AND status IN ('link_pending','link_sent','failed')""",
                  (pos_payment_ref, now, now, order_id))
        changed = cur.rowcount > 0
    if not changed:
        return False
    store.log_event("payment.paid", order_id=order_id,
                    detail={"pos_ref": pos_payment_ref})
    return True


def release_paid_order(store, order_id: str, *, sms) -> Dict[str, Any]:
    """Release a paid immutable order exactly once to its configured sink.

    Square's itemized checkout already owns the POS order.  Once its payment
    webhook arrives, recording that reference is the handoff; creating a
    second Square order would duplicate the ticket.  Other sinks are invoked
    only after the payment row says ``paid``.
    """
    row = store.order(order_id)
    payment = payment_for(store, order_id)
    if row is None or payment is None:
        raise LookupError("paid-order release references an unknown order")
    if payment["status"] != "paid":
        return {"released": False, "reason": "not_paid"}
    with store.tx() as conn:
        cur = conn.execute("""INSERT INTO order_release
            (order_id,status,claimed_at) VALUES (?,'claimed',?)
            ON CONFLICT(order_id) DO NOTHING""", (order_id,
                datetime.now(timezone.utc).isoformat(timespec="seconds")))
        claimed = cur.rowcount > 0
    if not claimed:
        return {"released": False, "reason": "already_claimed"}

    rest = store.restaurant(row["restaurant_id"])
    try:
        if rest is None:
            raise LookupError("paid-order release has no restaurant")
        if rest["sink"] == "square":
            ref = payment["pos_payment_ref"]
            if not ref:
                raise ValueError("paid Square checkout has no POS order reference")
            store.record_delivery(order_id, "square", "sent", external_ref=ref)
            result = {"released": True, "sink": "square", "external_ref": ref}
        else:
            from sinks import deliver, sink_for
            delivered = deliver(store, order_id, sink_for(rest, sms),
                                max_attempts=1)
            if not delivered.ok:
                if row["session_id"]:
                    store.escalate(row["session_id"],
                                   f"paid order delivery {delivered.error_kind}")
                return {"released": False, "reason": "delivery_failed",
                        "error": delivered.error_detail}
            result = {"released": True, "sink": rest["sink"],
                      "external_ref": delivered.external_ref}
        with store.tx() as conn:
            conn.execute("""UPDATE order_release SET status='sent'
                WHERE order_id=?""", (order_id,))
        store.log_event("order.released_after_payment",
                        restaurant_id=row["restaurant_id"], order_id=order_id,
                        detail={"sink": result["sink"],
                                "external_ref": result["external_ref"]})
        return result
    except Exception as exc:
        store.log_event("order.paid_release_failed", order_id=order_id,
                        restaurant_id=row["restaurant_id"],
                        detail={"error": str(exc)})
        if row["session_id"]:
            store.escalate(row["session_id"], "paid order handoff needs review")
        return {"released": False, "reason": "needs_review",
                "error": str(exc)}


def retry_paid_deliveries(store, *, sms) -> Dict[str, int]:
    """Retry paid orders that have no successful POS/kitchen handoff."""
    rows = store.conn.execute("""SELECT p.order_id FROM payment p
        WHERE p.status='paid' AND NOT EXISTS (
          SELECT 1 FROM order_release r WHERE r.order_id=p.order_id)""").fetchall()
    result = {"checked": len(rows), "released": 0, "failed": 0}
    for row in rows:
        try:
            released = release_paid_order(store, row["order_id"], sms=sms)
            result["released" if released.get("released") else "failed"] += 1
        except Exception as exc:  # noqa: BLE001 - audit and retry next sweep
            result["failed"] += 1
            store.log_event("order.paid_release_failed", order_id=row["order_id"],
                            detail={"error": str(exc)})
    return result


def expire_due_links(store, *, provider_for: Callable[[Any], Any],
                     now: Optional[datetime] = None) -> Dict[str, int]:
    """Revoke expired hosted links before marking them expired locally."""
    now = now or datetime.now(timezone.utc)
    rows = store.conn.execute("""SELECT p.*,o.restaurant_id,o.session_id
        FROM payment p JOIN "order" o ON o.id=p.order_id
        WHERE p.status IN ('link_pending','link_sent')
          AND p.pay_url_expires_at IS NOT NULL AND p.pay_url_expires_at<=?""",
        (now.isoformat(timespec="seconds"),)).fetchall()
    result = {"checked": len(rows), "expired": 0, "failed": 0}
    for row in rows:
        try:
            provider = provider_for(store.restaurant(row["restaurant_id"]))
            if provider is None or not row["provider_link_ref"]:
                raise RuntimeError("checkout provider cannot revoke this link")
            provider.revoke_pay_link(row["provider_link_ref"])
            stamp = now.isoformat(timespec="seconds")
            with store.tx() as conn:
                cur = conn.execute("""UPDATE payment SET status='expired',
                    settled_at=?,updated_at=? WHERE order_id=?
                    AND status IN ('link_pending','link_sent')""",
                    (stamp, stamp, row["order_id"]))
                if cur.rowcount:
                    conn.execute('UPDATE "order" SET status=? WHERE id=?',
                                 ("cancelled", row["order_id"]))
            if not cur.rowcount:
                continue
            store.log_event("payment.expired", order_id=row["order_id"],
                            restaurant_id=row["restaurant_id"],
                            detail={"provider_link_ref": row["provider_link_ref"]})
            result["expired"] += 1
        except Exception as exc:  # leave link live and retry; never lie locally
            result["failed"] += 1
            store.log_event("payment.expiry_failed", order_id=row["order_id"],
                            restaurant_id=row["restaurant_id"],
                            detail={"error": str(exc)})
    return result


def cancel_unpaid_checkout(store, order_id: str, *, provider) -> bool:
    """Revoke the original hosted checkout before replacing an immutable order.

    A correction is a *new* order from a new call/session. If revocation fails,
    neither the payment nor order is marked cancelled; an operator must first
    settle the uncertain provider state to avoid two live checkouts.
    """
    row = store.order(order_id)
    payment = payment_for(store, order_id)
    if row is None or payment is None:
        raise LookupError("checkout cancellation references an unknown order")
    if payment["status"] not in ("link_pending", "link_sent"):
        return False
    if not payment["provider_link_ref"] or provider is None:
        raise ValueError("checkout cannot be cancelled without provider link id")
    provider.revoke_pay_link(payment["provider_link_ref"])
    stamp = datetime.now(timezone.utc).isoformat(timespec="seconds")
    with store.tx() as conn:
        cur = conn.execute("""UPDATE payment SET status='expired',
            settled_at=?,updated_at=? WHERE order_id=?
            AND status IN ('link_pending','link_sent')""",
            (stamp, stamp, order_id))
        if cur.rowcount:
            conn.execute('UPDATE "order" SET status=? WHERE id=?',
                         ("cancelled", order_id))
    if not cur.rowcount:
        return False
    store.log_event("payment.checkout_cancelled", order_id=order_id,
                    restaurant_id=row["restaurant_id"],
                    detail={"provider_link_ref": payment["provider_link_ref"],
                            "reason": "order correction or guest cancellation"})
    return True


def payment_for(store, order_id: str):
    return store.conn.execute("SELECT * FROM payment WHERE order_id=?",
                              (order_id,)).fetchone()


def _write_payment(store, order_id: str, *, method: str, status: str,
                   amount_cents: int, pay_url: Optional[str] = None,
                   pay_url_expires_at: Optional[str] = None,
                   pos_payment_ref: Optional[str] = None,
                   provider_link_ref: Optional[str] = None,
                   link_sent: bool = False) -> None:
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    with store.tx() as c:
        c.execute("""
            INSERT INTO payment (order_id, collected_by, method, status,
                amount_cents, pay_url, pay_url_expires_at, pos_payment_ref,
                provider_link_ref, link_sent_at, updated_at)
            VALUES (?, 'restaurant_pos', ?,?,?,?,?,?,?,?,?)
            ON CONFLICT(order_id) DO UPDATE SET
                method=excluded.method, status=excluded.status,
                pay_url=excluded.pay_url,
                pay_url_expires_at=excluded.pay_url_expires_at,
                pos_payment_ref=excluded.pos_payment_ref,
                provider_link_ref=excluded.provider_link_ref,
                link_sent_at=excluded.link_sent_at,
                updated_at=excluded.updated_at
        """, (order_id, method, status, amount_cents, pay_url,
              pay_url_expires_at, pos_payment_ref,
              provider_link_ref, now if link_sent else None, now))
