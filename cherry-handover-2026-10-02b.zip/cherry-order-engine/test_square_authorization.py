#!/usr/bin/env python3
"""Merchant Square authorization, the secret vault, and scheduled renewal."""

from __future__ import annotations

import json
import os
import stat
import tempfile
import traceback
import urllib.error
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path

import square_oauth as so
import vault as vault_mod
from vault import FileVault

SECRET = "state-secret-0123456789"
NOW = datetime(2026, 9, 28, 12, 0, tzinfo=timezone.utc)


class Resp:
    def __init__(self, body): self.body = body
    def __enter__(self): return self
    def __exit__(self, *_): return False
    def read(self): return json.dumps(self.body).encode()


def square(locations=1, expires="2026-10-28T12:00:00Z", fail_token=False):
    """A fake Square answering ObtainToken and ListLocations."""
    calls = []
    def opener(request, timeout=0):
        url = request.full_url
        calls.append(url)
        if url.endswith("/oauth2/token"):
            if fail_token:
                raise urllib.error.HTTPError(url, 400, "bad", {}, None)
            body = json.loads(request.data)
            token = {"access_token": "acc-" + body["grant_type"],
                     "expires_at": expires, "merchant_id": "M1"}
            if body["grant_type"] == "authorization_code":
                token["refresh_token"] = "ref-new"
            return Resp(token)
        if url.endswith("/v2/locations"):
            return Resp({"locations": [{"id": f"LOC{i}", "name": f"L{i}",
                                        "status": "ACTIVE"} for i in range(locations)]
                         + [{"id": "OLD", "status": "INACTIVE"}]})
        raise AssertionError(url)
    opener.calls = calls
    return opener


def client(opener):
    return so.SquareOAuthClient("app", "secret", opener=opener)


def tmp_vault():
    return FileVault(tempfile.mkdtemp() + "/v")


# --- state -----------------------------------------------------------------

def t_state_round_trip_and_tamper_and_expiry():
    state = so.sign_state(SECRET, "bun-n-run-ferndale", now=NOW.timestamp())
    assert so.verify_state(SECRET, state, now=NOW.timestamp()) == "bun-n-run-ferndale"
    for bad in (state[:-2] + "xx", "junk", state.split(".")[0] + ".", ""):
        try:
            so.verify_state(SECRET, bad, now=NOW.timestamp())
            raise AssertionError("accepted a bad state")
        except so.OAuthRefreshError:
            pass
    try:
        so.verify_state("another-secret-0123456789", state, now=NOW.timestamp())
        raise AssertionError("accepted a state signed with another secret")
    except so.OAuthRefreshError:
        pass
    try:
        so.verify_state(SECRET, state, now=NOW.timestamp() + 8 * 86400)
        raise AssertionError("accepted an expired state")
    except so.OAuthRefreshError:
        pass


def t_weak_state_secret_is_refused():
    try:
        so.sign_state("short", "r")
        raise AssertionError
    except ValueError:
        pass


def t_authorize_url_shape():
    url = so.authorize_url("APP", SECRET, "r1", sandbox=True)
    assert url.startswith("https://connect.squareupsandbox.com/oauth2/authorize?")
    assert "client_id=APP" in url and "ORDERS_WRITE" in url and "state=" in url
    assert "secret" not in url.lower().replace("state-secret", "")
    assert so.authorize_url("APP", SECRET, "r1").startswith("https://connect.squareup.com/")


# --- authorization ---------------------------------------------------------

def t_single_location_is_stored_with_all_secrets():
    v = tmp_vault()
    state = so.sign_state(SECRET, "bun-n-run-ferndale")
    result = so.complete_authorization(client(square(1)), v, SECRET, state=state,
                                       code="CODE", opener=square(1))
    assert result["location_id"] == "LOC0" and result["needs_location"] == []
    assert "acc-" not in json.dumps(result) and "ref-new" not in json.dumps(result)
    assert v.get("SQUARE_TOKEN_BUN_N_RUN_FERNDALE") == "acc-authorization_code"
    assert v.get("SQUARE_REFRESH_BUN_N_RUN_FERNDALE") == "ref-new"
    assert v.get("SQUARE_LOCATION_BUN_N_RUN_FERNDALE") == "LOC0"


def t_several_locations_need_a_human_choice_but_tokens_are_kept():
    v = tmp_vault()
    state = so.sign_state(SECRET, "r1")
    result = so.complete_authorization(client(square(3)), v, SECRET, state=state,
                                       code="C", opener=square(3))
    assert result["location_id"] is None
    assert [x["id"] for x in result["needs_location"]] == ["LOC0", "LOC1", "LOC2"]
    assert v.get("SQUARE_TOKEN_R1")                    # approval is not lost
    try:
        v.get("SQUARE_LOCATION_R1")
        raise AssertionError("guessed a location")
    except KeyError:
        pass
    so.set_location(v, "r1", "LOC1")
    assert v.get("SQUARE_LOCATION_R1") == "LOC1"


def t_bad_code_or_state_writes_nothing():
    v = tmp_vault()
    try:
        so.complete_authorization(client(square(fail_token=True)), v, SECRET,
                                  state=so.sign_state(SECRET, "r1"), code="X")
        raise AssertionError
    except so.OAuthRefreshError:
        pass
    try:
        so.complete_authorization(client(square()), v, SECRET, state="forged.sig", code="X")
        raise AssertionError
    except so.OAuthRefreshError:
        pass
    assert v.names() == []


def t_unknown_restaurant_is_refused():
    v = tmp_vault()
    try:
        so.complete_authorization(client(square()), v, SECRET, code="C",
                                  state=so.sign_state(SECRET, "ghost"),
                                  known_restaurants={"r1"})
        raise AssertionError
    except so.OAuthRefreshError:
        pass
    assert v.names() == []


# --- vault -----------------------------------------------------------------

def t_vault_files_are_private_atomic_and_validated():
    v = tmp_vault()
    v.put("SQUARE_TOKEN_R1", "abc")
    path = v.directory / "SQUARE_TOKEN_R1"
    assert stat.S_IMODE(path.stat().st_mode) == 0o600
    assert stat.S_IMODE(v.directory.stat().st_mode) == 0o700
    v.put("SQUARE_TOKEN_R1", "def")
    assert v.get("SQUARE_TOKEN_R1") == "def"
    assert v.names() == ["SQUARE_TOKEN_R1"]             # no temp-file leftovers
    for bad in ("../etc/passwd", "a/b", "", "x" * 200):
        try:
            v.put(bad, "x")
            raise AssertionError(bad)
        except ValueError:
            pass
    try:
        v.put("EMPTY", "")
        raise AssertionError
    except ValueError:
        pass


def t_secret_prefers_vault_then_environment():
    v = tmp_vault()
    os.environ["SQUARE_TOKEN_R9"] = "from-env"
    try:
        assert vault_mod.secret("SQUARE_TOKEN_R9", vault=v) == "from-env"
        v.put("SQUARE_TOKEN_R9", "from-vault")
        assert vault_mod.secret("SQUARE_TOKEN_R9", vault=v) == "from-vault"
    finally:
        del os.environ["SQUARE_TOKEN_R9"]


def t_the_bridge_uses_a_refreshed_token_without_a_restart():
    """The reason the vault exists."""
    from square_bridge import square_sink_for
    d = tempfile.mkdtemp() + "/v"
    os.environ["CHERRY_SECRET_DIR"] = d
    try:
        v = FileVault(d)
        v.put("SQUARE_TOKEN_R1", "token-1")
        v.put("SQUARE_LOCATION_R1", "LOC0")
        row = {"id": "r1", "tax_rate_bps": 600}
        assert square_sink_for(row).client.access_token == "token-1"
        v.put("SQUARE_TOKEN_R1", "token-2")             # what a refresh does
        assert square_sink_for(row).client.access_token == "token-2"
    finally:
        del os.environ["CHERRY_SECRET_DIR"]


# --- renewal ---------------------------------------------------------------

def _authorized(v, rid, expires):
    n = so.secret_names(rid)
    v.put(n["access"], "acc-old"); v.put(n["refresh"], "ref-old")
    v.put(n["expires"], expires)


def t_status_states():
    v = tmp_vault()
    _authorized(v, "ok", (NOW + timedelta(days=20)).isoformat())
    _authorized(v, "due", (NOW + timedelta(days=3)).isoformat())
    _authorized(v, "gone", (NOW - timedelta(days=1)).isoformat())
    states = {r: so.token_status(v, r, now=NOW)["state"]
              for r in ("ok", "due", "gone", "never")}
    assert states == {"ok": "ok", "due": "due", "gone": "expired",
                      "never": "not_authorized"}, states


def t_refresh_touches_only_due_tokens_and_reports_the_unauthorized():
    v = tmp_vault()
    _authorized(v, "ok", (NOW + timedelta(days=20)).isoformat())
    _authorized(v, "due", (NOW + timedelta(days=3)).isoformat())
    op = square()
    result = so.refresh_due(client(op), v, ["ok", "due", "never"], now=NOW)
    assert result["refreshed"] == 1 and result["failed"] == 0
    assert result["not_authorized"] == ["never"] and result["skipped_ok"] == 1
    assert v.get("SQUARE_TOKEN_DUE") == "acc-refresh_token"
    assert v.get("SQUARE_TOKEN_OK") == "acc-old"
    assert len(op.calls) == 1


def t_failed_refresh_keeps_the_old_working_token():
    v = tmp_vault()
    _authorized(v, "due", (NOW + timedelta(days=3)).isoformat())
    result = so.refresh_due(client(square(fail_token=True)), v, ["due"], now=NOW)
    assert result["failed"] == 1
    assert v.get("SQUARE_TOKEN_DUE") == "acc-old"


def t_cli_exit_codes_make_the_scheduler_alert():
    d = tempfile.mkdtemp() + "/v"
    os.environ.update(CHERRY_SECRET_DIR=d, SQUARE_OAUTH_CLIENT_ID="a",
                      SQUARE_OAUTH_CLIENT_SECRET="b")
    try:
        assert so.main(["status", "--restaurant", "never"]) == 3
        assert so.main(["refresh", "--restaurant", "never"]) == 3
        v = FileVault(d)
        _authorized(v, "fine", (datetime.now(timezone.utc) + timedelta(days=25)).isoformat())
        assert so.main(["status", "--restaurant", "fine"]) == 0
    finally:
        for k in ("CHERRY_SECRET_DIR", "SQUARE_OAUTH_CLIENT_ID", "SQUARE_OAUTH_CLIENT_SECRET"):
            os.environ.pop(k, None)


# --- the server callback, over a real socket ---------------------------------

def t_callback_endpoint_end_to_end():
    import test_server as ts
    d = tempfile.mkdtemp() + "/v"
    v = FileVault(d)
    os.environ.update(CHERRY_OAUTH_STATE_SECRET=SECRET,
                      SQUARE_OAUTH_CLIENT_ID="app", SQUARE_OAUTH_CLIENT_SECRET="sec",
                      CHERRY_SQUARE_SANDBOX="1")
    h = ts.Harness()
    try:
        h.app.vault, h.app.oauth_opener = v, square(1)
        state = so.sign_state(SECRET, "bun-n-run-ferndale")
        code, body = h.req("GET", f"/v1/oauth/square/callback?code=C&state={state}",
                           key=None)
        assert code == 200 and "connected" in str(body).lower(), (code, body)
        assert v.get("SQUARE_LOCATION_BUN_N_RUN_FERNDALE") == "LOC0"
        assert "acc-" not in str(body) and "ref-new" not in str(body)
        assert any(e["kind"] == "square.oauth_authorized" for e in h.store.events())
        # forged state, cancelled approval, unknown restaurant
        code, body = h.req("GET", "/v1/oauth/square/callback?code=C&state=forged.x", key=None)
        assert code == 400 and "Traceback" not in str(body)
        code, _ = h.req("GET", "/v1/oauth/square/callback?error=access_denied", key=None)
        assert code == 200
        ghost = so.sign_state(SECRET, "ghost-restaurant")
        code, _ = h.req("GET", f"/v1/oauth/square/callback?code=C&state={ghost}", key=None)
        assert code == 400
        assert not any(n.endswith("GHOST_RESTAURANT") for n in v.names())
    finally:
        h.stop()
        for k in ("CHERRY_OAUTH_STATE_SECRET", "SQUARE_OAUTH_CLIENT_ID",
                  "SQUARE_OAUTH_CLIENT_SECRET", "CHERRY_SQUARE_SANDBOX"):
            os.environ.pop(k, None)


TESTS = [v for k, v in sorted(globals().items()) if k.startswith("t_")]


def main() -> int:
    passed, fails = 0, []
    for fn in TESTS:
        try:
            fn()
            passed += 1
        except Exception:                                   # noqa: BLE001
            fails.append((fn.__name__, traceback.format_exc()))
    print(f"{passed} passed, {len(fails)} failed (Square authorization + vault)")
    for n, tb in fails:
        print(f"\n--- FAIL {n}\n{tb}")
    return 1 if fails else 0


if __name__ == "__main__":
    raise SystemExit(main())
