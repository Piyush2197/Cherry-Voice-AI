#!/usr/bin/env python3
"""Everything the voice provider's console needs, as files — and a check that it still matches.

Configuring the voice agent (Inworld today, a native-audio model tomorrow) means
pasting three things into a console: Lily's instructions, the engine's tool
definitions, and the call policy. Those live in this repository and change with
it (the prompt, the 19 tool schemas, the idle/cap/goodbye settings). Copying them
by hand is how a console ends up running last month's prompt against this month's
engine. This writes them out, and later proves the live engine still matches.

    python3 voice_pack.py make --out voice-pack --base-url https://api.example.com
    CHERRY_VOICE_KEY=... python3 voice_pack.py verify --pack voice-pack --url https://api.example.com

`make` reads only this repository. `verify` makes one read-only GET of the
gateway's /v1/voice/tools, with the voice key taken from the NAMED environment
variable (never printed, never written to the pack). The pack contains no secrets.

Files:
    system_prompt.txt      Lily's instructions, verbatim from voice/inworld_bridge.py
    tools.json             the tool definitions (name, description, JSON-schema parameters)
    tools.gemini.json      the same as Gemini Live function declarations, every one BLOCKING
    call_policy.json       idle prompt, hang-up rule, call-length cap, goodbye lines
    CONNECT.md             the endpoints, the auth header, and the settings to match
    CHECKLIST.md           what to confirm on the first real call (then run call_review.py)
    pack.json              a fingerprint of every file, for `verify`
"""

from __future__ import annotations

import _ensure_deps  # noqa: F401  (re-runs under .venv, or says how to install, if PyYAML is missing)
import argparse
import hashlib
import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Dict, List, Optional

HERE = Path(__file__).resolve().parent
FILES = ("system_prompt.txt", "tools.json", "tools.gemini.json", "call_policy.json", "CONNECT.md", "CHECKLIST.md")


def _sha(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _json(doc: Any) -> str:
    return json.dumps(doc, indent=2, sort_keys=True, ensure_ascii=False) + "\n"


def gemini_declarations(tools: List[dict]) -> List[dict]:
    """Gemini Live function declarations. Gemini 3.8 Live runs tools NON-BLOCKING by
    default (the model keeps talking while a tool runs); Cherry needs the model to wait
    and say the engine's words, so every declaration is BLOCKING."""
    return [{"name": t["name"], "description": t["description"], "parameters": t["parameters"], "behavior": "BLOCKING"}
            for t in tools]


def content(base_url: str = "https://YOUR-API-HOST") -> Dict[str, str]:
    """The pack's files as {name: text}, built from this repository."""
    from voice.inworld_bridge import SYSTEM_PROMPT
    import host_voice
    import server
    tools = [{"name": t["name"], "description": t["description"], "parameters": t["parameters"]}
             for t in server.ALL_TOOL_SCHEMAS]
    policy = dict(host_voice.CALL_POLICY)
    base = base_url.rstrip("/")
    files = {
        "system_prompt.txt": SYSTEM_PROMPT.rstrip("\n") + "\n",
        "tools.json": _json(tools),
        "tools.gemini.json": _json(gemini_declarations(tools)),
        "call_policy.json": _json(policy),
        "CONNECT.md": f"""# Connecting the voice agent to Cherry

Nothing in this folder is a secret. The voice key is set in the provider's console as an
HTTP header value; it is never written here.

## Where the agent calls

| What | Method and URL |
|---|---|
| A call starts | `POST {base}/v1/voice/calls` with `{{"call_control_id": "<id>", "to": "<dialled DID>", "from": "<caller>"}}` |
| A tool runs | `POST {base}/v1/voice/calls/<call_control_id>/tools/<tool name>` with the tool's arguments as JSON |
| The call ends | `POST {base}/v1/voice/calls/<call_control_id>/finish`  /  `.../abandon`  /  `.../handoff` |
| Event webhook (if the provider posts whole call events) | `POST {base}/v1/inworld/events` |
| Current prompt, tools and policy | `GET {base}/v1/voice/tools` |

Every request carries the header `X-Voice-Key: <the value of CHERRY_VOICE_KEY on the server>`.

## What to match in the console

1. **Instructions**: paste `system_prompt.txt` exactly. Do not paraphrase it: it tells Lily to speak the
   engine's words verbatim and to call each tool once.
2. **Tools**: import `tools.json` (OpenAI-style JSON schema) or `tools.gemini.json` (Gemini Live; every
   tool declared `BLOCKING`). There are {len(tools)} tools. A tool added to the engine is not usable until
   it is added here: run `voice_pack.py verify` after every engine deploy.
3. **Tool behaviour**: blocking. The model must wait for the engine's reply and say it.
4. **Call policy** (`call_policy.json`): idle prompt after {policy.get('idle_prompt_after_seconds')} s of silence,
   release the caller after {policy.get('hang_up_after_idle_prompts')} unanswered prompts, end any call at
   {policy.get('max_call_seconds')} s. Per-minute providers bill silence like speech.
5. **Output transcription**: turn it on and keep it, one reply per line, for `call_review.py --spoken`.
6. **Barge-in**: allow callers to talk over Lily.
""",
        "CHECKLIST.md": """# First real call: what to confirm

Make one test order that includes a name, an allergy, "what time do you close tonight?" and a sentence
in Spanish. Then:

    python3 call_review.py --db "$CHERRY_DATABASE_URL" --latest --spoken spoken.txt \\
        --expect set_name,note_allergy,store_info

- [ ] The greeting is Lily's, and sounds unhurried and warm (pick the voice by ear).
- [ ] The name and the allergy went to `set_name` / `note_allergy`, not `add_item`.
- [ ] No tool was called twice for one request (the review counts the repeats the engine absorbed).
- [ ] Every spoken line matches the engine's words (a changed price or quantity fails the review).
- [ ] A caller can interrupt, and the cart is still right (`read_back`).
- [ ] Silence is handled: an idle prompt, then a goodbye; and no call runs past the cap.
- [ ] The transfer to staff works and does not loop (a direct staff line, not the published number).

Re-run `voice_pack.py verify` after every engine deploy.
""",
    }
    return files


def make(out: Path, base_url: str) -> Dict[str, str]:
    files = content(base_url)
    out.mkdir(parents=True, exist_ok=True)
    for name, text in files.items():
        (out / name).write_text(text, encoding="utf-8")
    manifest = {"files": {n: _sha(t) for n, t in files.items()}, "tool_count": len(json.loads(files["tools.json"])),
                "note": "fingerprints of the files in this folder; `voice_pack.py verify` compares them with the live engine"}
    (out / "pack.json").write_text(_json(manifest), encoding="utf-8")
    return files


def read_pack(pack: Path) -> Dict[str, str]:
    out = {}
    for name in FILES:
        p = pack / name
        out[name] = p.read_text(encoding="utf-8") if p.exists() else ""
    return out


def fetch_live(url: str, voice_key: str, *, opener=None, timeout: float = 15.0) -> dict:
    req = urllib.request.Request(url.rstrip("/") + "/v1/voice/tools", headers={"X-Voice-Key": voice_key, "Accept": "application/json"})
    try:
        with (opener or urllib.request.urlopen)(req, timeout=timeout) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as exc:
        raise RuntimeError(f"the gateway answered HTTP {exc.code} (is the voice key right?)") from None
    except (urllib.error.URLError, OSError, ValueError) as exc:
        raise RuntimeError(f"could not read {url}/v1/voice/tools: {type(exc).__name__}") from None


def compare(pack: Dict[str, str], live: dict) -> List[str]:
    """What differs between the files in the pack and what the live engine serves."""
    problems = []
    want_prompt = (live.get("system_prompt") or "").rstrip("\n") + "\n"
    if pack["system_prompt.txt"] != want_prompt:
        problems.append("system_prompt.txt is not what the engine serves: the console is running an older (or edited) prompt")
    live_tools = {t["name"]: t for t in live.get("tools") or []}
    try:
        pack_tools = {t["name"]: t for t in json.loads(pack["tools.json"] or "[]")}
    except ValueError:
        return problems + ["tools.json is not valid JSON"]
    for name in sorted(set(live_tools) - set(pack_tools)):
        problems.append(f"the engine has a tool the pack lacks: {name} (the model cannot call it until it is added)")
    for name in sorted(set(pack_tools) - set(live_tools)):
        problems.append(f"the pack has a tool the engine no longer has: {name} (the model would call a missing endpoint)")
    for name in sorted(set(live_tools) & set(pack_tools)):
        lt, pt = live_tools[name], pack_tools[name]
        if lt.get("parameters") != pt.get("parameters"):
            problems.append(f"tool {name}: the parameters differ from the engine's")
        if lt.get("description") != pt.get("description"):
            problems.append(f"tool {name}: the description differs from the engine's")
    try:
        policy = json.loads(pack["call_policy.json"] or "{}")
    except ValueError:
        return problems + ["call_policy.json is not valid JSON"]
    if policy != (live.get("call_policy") or {}):
        problems.append("call_policy.json differs from the engine's call policy")
    if (live.get("call_policy") or {}).get("tool_behavior") != "BLOCKING":
        problems.append("the engine no longer declares tool_behavior BLOCKING")
    try:
        gem = json.loads(pack["tools.gemini.json"] or "[]")
        if any(d.get("behavior") != "BLOCKING" for d in gem) or {d["name"] for d in gem} != set(live_tools):
            problems.append("tools.gemini.json is not every live tool declared BLOCKING")
    except (ValueError, KeyError, TypeError):
        problems.append("tools.gemini.json is not valid")
    return problems


def verify(pack: Path, url: str, voice_key: str, *, opener=None) -> List[str]:
    files = read_pack(pack)
    missing = [n for n, t in files.items() if not t]
    if missing:
        return [f"the pack is missing {', '.join(missing)}: run `voice_pack.py make`"]
    problems = compare(files, fetch_live(url, voice_key, opener=opener))
    manifest_path = pack / "pack.json"
    if manifest_path.exists():
        recorded = json.loads(manifest_path.read_text()).get("files", {})
        for n, t in files.items():
            if recorded.get(n) and recorded[n] != _sha(t):
                problems.append(f"{n} was edited after `make` (its fingerprint changed)")
    return problems


def main(argv: Optional[List[str]] = None, *, env: Optional[dict] = None, opener=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    mk = sub.add_parser("make")
    mk.add_argument("--out", required=True)
    mk.add_argument("--base-url", default="https://YOUR-API-HOST")
    vf = sub.add_parser("verify")
    vf.add_argument("--pack", required=True)
    vf.add_argument("--url", required=True)
    vf.add_argument("--voice-key-env", default="CHERRY_VOICE_KEY", help="NAME of the variable holding the voice key")
    args = ap.parse_args(argv)
    env = os.environ if env is None else env
    if args.cmd == "make":
        files = make(Path(args.out), args.base_url)
        print(f"wrote {len(files) + 1} files to {args.out}: " + ", ".join(sorted(files)) + ", pack.json")
        print("Paste system_prompt.txt and the tools into the voice console, then run `verify` against the live engine.")
        return 0
    key = str(env.get(args.voice_key_env, "")).strip()
    if not key:
        print(f"{args.voice_key_env} is not set: export it in your shell first (it is read by name and never printed)")
        return 2
    try:
        problems = verify(Path(args.pack), args.url, key, opener=opener)
    except RuntimeError as exc:
        print(f"verify: {exc}")
        return 2
    if problems:
        print(f"{len(problems)} difference(s) between the pack and the live engine:")
        for p in problems:
            print("  - " + p)
        return 3
    print("the pack matches the live engine: prompt, tools, call policy")
    return 0


if __name__ == "__main__":
    sys.exit(main())
