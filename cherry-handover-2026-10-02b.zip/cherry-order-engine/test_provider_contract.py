#!/usr/bin/env python3
"""What every itemized-checkout provider must do — the bar for Toast, Clover, EPIPay.

A provider turns Cherry's immutable order into a hosted checkout page whose
total is exactly the quoted total. The rules below are the ones that protect a
restaurant's customer (and Cherry) from a wrong charge; they are run against the
test double, the development provider and the real Square provider, and a new
provider is added by appending ONE case to CASES:

    1. it returns an https link and a reference that can later revoke it;
    2. it refuses an amount that differs from the immutable order — before it
       asks anyone to create anything;
    3. nothing it sends contains card data;
    4. a failure at the processor is an exception, never a link nobody checked.

Square additionally proves the two things only a real processor can get wrong:
the same order always carries the same idempotency key (a retry cannot create
a second payable checkout), and a processor total that drifts from ours by one
cent revokes the link before the customer is ever sent it.
"""

from __future__ import annotations

import json
import traceback
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional

import dev_checkout
import payments
import square_bridge
from test_bridges import FakeHTTP
from test_payment_gate import fixture

_passed = _failed = 0


def check(name, cond, detail=""):
    global _passed, _failed
    if cond:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


@dataclass
class Case:
    name: str
    make: Callable[[int], Any]                 # amount the processor will "compute" -> (provider, probe)
    sent: Callable[[Any], List[str]]           # every payload the provider handed to the processor, as text
    created: Callable[[Any], int]              # how many checkouts the processor was asked to create
    fail_next: Optional[Callable[[Any], None]] = None


class Probe:
    def __init__(self, **kw):
        self.__dict__.update(kw)


def fake_case() -> Case:
    def make(_amount):
        p = payments.FakePayLinkProvider()
        return p, Probe(provider=p)
    return Case("FakePayLinkProvider", make, lambda pr: [json.dumps(part) for r in pr.provider.requests for part in (r["snapshot"], r["context"])],
                lambda pr: len(pr.provider.created), lambda pr: setattr(pr.provider, "fail", True))


def dev_case() -> Case:
    def make(_amount):
        p = dev_checkout.DevCheckoutProvider()
        return p, Probe(provider=p)
    return Case("DevCheckoutProvider", make, lambda pr: [json.dumps(part) for r in pr.provider.requests for part in (r["snapshot"], r["context"])],
                lambda pr: len(pr.provider.created))


def square_case() -> Case:
    def make(amount):
        http = FakeHTTP()
        n = {"i": 0}

        def reply(req, timeout=None):
            if req.get_method() == "POST":
                n["i"] += 1
                return {"payment_link": {"url": f"https://square.link/u/{n['i']}", "order_id": f"sq-order-{n['i']}", "id": f"sq-link-{n['i']}"}}
            if req.get_method() == "GET":
                return {"order": {"id": req.full_url.rsplit("/", 1)[1], "total_money": {"amount": amount, "currency": "USD"}}}
            return {}
        original = http.__call__

        def call(req, timeout=None):
            http.responses = [reply(req)]
            if getattr(http, "boom", None):                    # the processor is down (and stays down)
                http.requests.append({"url": req.full_url, "method": req.get_method(), "headers": {}, "body": None})
                raise http.boom
            return original(req, timeout)
        p = square_bridge.SquareCheckoutProvider(square_bridge.SquareClient("secret", "L-1", opener=call))
        return p, Probe(provider=p, http=http)
    return Case("SquareCheckoutProvider", make,
                lambda pr: [json.dumps(r["body"]) for r in pr.http.requests if r["body"]],
                lambda pr: len([r for r in pr.http.requests if r["method"] == "POST"]),
                lambda pr: setattr(pr.http, "boom", ConnectionError("processor unreachable")))


# One line per provider. A Toast or EPIPay provider is added here.
CASES = [fake_case, dev_case, square_case]


def run(order, *, drift=0):
    store, oid, code, snapshot = fixture(sink="square")
    return store, oid, snapshot, {"short_code": code, "customer_phone": "+13135550123", "customer_name": "Sam",
                                  "tax_rate_bps": 600, "restaurant_id": "bun-n-run-ferndale"}


def t_every_provider_meets_the_contract() -> None:
    for build in CASES:
        case = build()
        _store, oid, snapshot, ctx = run(None)
        total = snapshot["total_cents"]

        provider, probe = case.make(total)
        link = provider.create_pay_link(oid, total, None, snapshot=snapshot, context=ctx)
        check(f"{case.name}: the link is https", link.url.startswith("https://"), link.url)
        check(f"{case.name}: it returns a reference that can revoke the link", bool(link.provider_link_ref), str(link))
        check(f"{case.name}: it names the processor's order (the payment webhook finds the order by it)", bool(link.pos_ref), str(link))
        try:
            provider.revoke_pay_link(link.provider_link_ref)
            check(f"{case.name}: the link can be revoked", True)
        except Exception as exc:                              # noqa: BLE001
            check(f"{case.name}: the link can be revoked", False, str(exc))

        provider, probe = case.make(total)
        try:
            provider.create_pay_link(oid, total + 1, None, snapshot=snapshot, context=ctx)
            check(f"{case.name}: an amount that is not the order's total is refused", False, "created a link")
        except ValueError:
            check(f"{case.name}: an amount that is not the order's total is refused", True)
        check(f"{case.name}: …and nothing was created at the processor", case.created(probe) == 0, str(case.created(probe)))

        provider, probe = case.make(total)
        provider.create_pay_link(oid, total, None, snapshot=snapshot, context=ctx)
        clean = True
        for payload in case.sent(probe):
            try:
                payments.reject_payment_data(json.loads(payload), "provider payload")
            except Exception:                                  # noqa: BLE001
                clean = False
        check(f"{case.name}: something was actually sent (the card-data check is not vacuous)", bool(case.sent(probe)))
        check(f"{case.name}: nothing sent to the processor looks like card data", clean)

        if case.fail_next is not None:
            provider, probe = case.make(total)
            case.fail_next(probe)
            try:
                got = provider.create_pay_link(oid, total, None, snapshot=snapshot, context=ctx)
                check(f"{case.name}: a processor failure is an exception, not a link", False, str(got))
            except Exception:                                  # noqa: BLE001
                check(f"{case.name}: a processor failure is an exception, not a link", True)


def t_square_alone_proves_idempotency_and_total_drift() -> None:
    _store, oid, snapshot, ctx = run(None)
    total = snapshot["total_cents"]
    provider, probe = square_case().make(total)
    provider.create_pay_link(oid, total, None, snapshot=snapshot, context=ctx)
    provider.create_pay_link(oid, total, None, snapshot=snapshot, context=ctx)
    keys = [json.loads(json.dumps(r["body"]))["idempotency_key"] for r in probe.http.requests if r["method"] == "POST" and r["body"]]
    check("the same order carries the same idempotency key on a retry, so Square cannot create two checkouts",
          len(keys) == 2 and keys[0] == keys[1] and oid in keys[0], str(keys))
    other = "another-order-id"
    provider.create_pay_link(other, total, None, snapshot=snapshot, context=ctx)
    k3 = [r["body"]["idempotency_key"] for r in probe.http.requests if r["method"] == "POST" and r["body"]][-1]
    check("…and a different order carries a different one", k3 != keys[0])

    provider, probe = square_case().make(total + 1)                 # Square computes a total one cent higher
    try:
        provider.create_pay_link(oid, total, None, snapshot=snapshot, context=ctx)
        check("a processor total one cent off is refused", False, "link returned")
    except ValueError as exc:
        check("a processor total one cent off is refused, naming the reason", "differs" in str(exc), str(exc))
    check("…and the unsent link was revoked at Square", any(r["method"] == "DELETE" for r in probe.http.requests),
          str([r["method"] for r in probe.http.requests]))


def main() -> int:
    global _failed
    for name, fn in sorted((k, v) for k, v in globals().items() if k.startswith("t_")):
        try:
            fn()
        except Exception:                                    # noqa: BLE001
            _failed += 1
            print(f"\n--- FAIL {name} raised")
            traceback.print_exc()
    print(f"{_passed} passed, {_failed} failed (checkout provider contract)")
    return 1 if _failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
