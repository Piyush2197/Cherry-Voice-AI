#!/usr/bin/env python3
"""Run Cherry's store, sink and payment suite against a REAL PostgreSQL.

The mocked checks in test_postgres_support.py cannot catch SQL-dialect,
JSONB, trigger or connection-pool mistakes. This file does. It is skipped
(exit 0) unless a throwaway database is supplied:

    createdb cherry_test
    CHERRY_TEST_POSTGRES_URL=postgresql://user@localhost/cherry_test \
        python3 test_postgres_live.py

SAFETY: every test starts by dropping the whole `public` schema, so the
database name must contain "test". Never point this at production.
"""

from __future__ import annotations

import os
import sys
import threading
import traceback
from urllib.parse import urlparse

import test_store
from order_store import OrderStore

URL = os.getenv("CHERRY_TEST_POSTGRES_URL", "").strip()
_open_stores = []


def _fresh_store(*args, **kwargs):
    """Stand-in for OrderStore.sqlite(): an empty, bootstrapped Postgres."""
    import psycopg
    for old in _open_stores:
        old.close()
    _open_stores.clear()
    with psycopg.connect(URL, autocommit=True) as conn:
        conn.execute("DROP SCHEMA public CASCADE")
        conn.execute("CREATE SCHEMA public")
    store = OrderStore.postgres(URL, min_size=1, max_size=4, bootstrap=True)
    _open_stores.append(store)
    return store


def t_concurrent_callers_do_not_collide() -> None:
    """Twenty simultaneous callers, each placing an order — no lost writes,
    no duplicate short codes, no exception. This is the reason production is
    Postgres and not SQLite."""
    store, cfg, mv = test_store._fixture()
    errors, ids = [], []
    lock = threading.Lock()

    def caller(n: int) -> None:
        try:
            oid = test_store._an_order(store, cfg, mv, phone=f"+1313555{n:04d}")
            with lock:
                ids.append(oid)
        except Exception:                                  # noqa: BLE001
            with lock:
                errors.append(traceback.format_exc())

    threads = [threading.Thread(target=caller, args=(n,)) for n in range(20)]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=60)
    assert not errors, errors[0]
    assert len(set(ids)) == 20, f"expected 20 distinct orders, got {len(set(ids))}"
    n = store.conn.execute('SELECT count(*) AS n FROM "order"').fetchone()["n"]
    assert int(n) == 20, n


def t_rows_look_like_sqlite_rows_and_serialise_to_json() -> None:
    """ids and timestamps must be plain strings: server.py json.dumps() rows
    and compares ids with the strings the API hands back."""
    import json
    store, cfg, mv = test_store._fixture()
    oid, _code = test_store._an_order(store, cfg, mv)
    row = store.order(oid)
    assert isinstance(row["id"], str) and isinstance(row["placed_at"], str), \
        {k: type(v).__name__ for k, v in row.items()}
    json.dumps(row)                       # must not raise
    sid = store.start_session(cfg.id, mv, external_id="ext-1")
    assert isinstance(sid, str), type(sid)
    json.dumps(store.conn.execute(
        "SELECT * FROM session WHERE id=?", (sid,)).fetchone())


def t_bootstrap_is_idempotent_and_keeps_data() -> None:
    store, cfg, mv = test_store._fixture()
    oid, _code = test_store._an_order(store, cfg, mv)
    store.close()
    _open_stores.clear()
    again = OrderStore.postgres(URL, bootstrap=True)     # a second deploy
    _open_stores.append(again)
    assert again.order(oid)["id"] == oid


def main() -> int:
    if not URL:
        print("SKIPPED: set CHERRY_TEST_POSTGRES_URL to a throwaway database")
        return 0
    name = urlparse(URL).path.lstrip("/").lower()
    if "test" not in name:
        print(f"refusing to run: database name {name!r} must contain 'test'")
        return 2
    test_store.OrderStore.sqlite = staticmethod(_fresh_store)
    tests = list(test_store.TESTS) + [
        v for k, v in sorted(globals().items()) if k.startswith("t_")]
    passed, fails = 0, []
    for fn in tests:
        try:
            fn()
            passed += 1
        except Exception:                                  # noqa: BLE001
            fails.append((fn.__name__, traceback.format_exc()))
    for s in _open_stores:
        s.close()
    print(f"{passed} passed, {len(fails)} failed (real PostgreSQL)")
    for n, tb in fails:
        print(f"\n--- FAIL {n}\n{tb}")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
