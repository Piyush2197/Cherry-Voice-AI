"""Tests for the cuisine library and menu ingestion.

These run at onboarding time, not on a call, so the bar is different from the
engine's: the library is allowed to be wrong, but it must never be silently
wrong, and it must never emit something that looks ready to ship.
"""
from __future__ import annotations

import traceback

import menu_ingest as mi
from cuisine_library import CUISINES, HOMOPHONE_TRAPS, all_mishears
from order_engine import OrderEngine, RestaurantConfig, normalize
from restaurants import BUN_N_RUN

# This was `from restaurant_pink_garlic import PINK_GARLIC`, a hand-written
# module holding 51 items at a time when the real Oak Park location sold 128.
# It was deleted on 2026-09-30 (REDUNDANCY_AUDIT_2026-09-30.md §2); the library
# checks now run against the menu that is actually deployed.
import menu_schema as _ms
from pathlib import Path as _Path

PINK_GARLIC = _ms.load_yaml(_Path(__file__).parent / "menus"
                            / "pink-garlic-oak-park.yaml")

SAMPLE_INDIAN = """CHICKEN
29. Butter Chk. (Creamy)
A rich creamy curry. Serve with Rice
$13.99
41. Chk Saag
Chicken with spinach. Serve with Rice.
$13.99
LAMB
58. Lamb/Goat Saag.
Tender meat with spinach. Serve with Rice.
$14.99
NAAN BREAD
104. Garlic Naan
$3.50
"""


def t_engine_never_imports_the_library():
    """The one architectural rule, enforced rather than documented."""
    import order_engine
    src = open(order_engine.__file__).read()
    for banned in ("cuisine_library", "menu_ingest"):
        assert banned not in src, (
            f"order_engine.py references {banned} — cuisine knowledge must "
            f"never reach a live call")


def t_every_cuisine_profile_is_well_formed():
    for cid, prof in CUISINES.items():
        assert prof.dishes, f"{cid} has no dishes"
        assert prof.archetypes, f"{cid} has no archetypes"
        arch_ids = {a.id for a in prof.archetypes}
        for d in prof.dishes:
            for aid in d.implies:
                assert aid in arch_ids, (
                    f"{cid}: dish '{d.canonical}' implies unknown archetype "
                    f"'{aid}'")
        for _, aid in prof.menu_signals:
            assert aid in arch_ids, (
                f"{cid}: menu signal points at unknown archetype '{aid}'")
        for a in prof.archetypes:
            if a.min_select > 0:
                assert a.prompt.strip(), (
                    f"{cid}/{a.id}: required archetype with no prompt")
            assert a.confirm.strip(), (
                f"{cid}/{a.id}: archetype with no confirm text — every "
                f"proposal must come with a question for the owner")


def t_no_archetype_invents_a_price():
    """The library must never carry a number that could become a bill."""
    for cid, prof in CUISINES.items():
        for a in prof.archetypes:
            for name, cents in a.typical_options:
                assert cents == 0, (
                    f"{cid}/{a.id}/{name} carries a price of {cents}c. The "
                    f"library must not suggest prices — they are always asked.")


def t_mishears_do_not_collide_across_dishes():
    for cid in CUISINES:
        seen = {}
        for d in CUISINES[cid].dishes:
            for m in d.mishears:
                if m in seen and seen[m] != d.canonical:
                    raise AssertionError(
                        f"{cid}: '{m}' is listed as a mishearing of both "
                        f"{seen[m]} and {d.canonical}")
                seen[m] = d.canonical


def t_detects_indian():
    guesses = mi.detect_cuisine(SAMPLE_INDIAN)
    assert guesses and guesses[0].cuisine_id == "indian"
    assert guesses[0].score > (guesses[1].score if len(guesses) > 1 else 0)


def t_proposal_finds_the_lamb_preference_group():
    """The group that only showed up by opening a live item page."""
    p = mi.propose(SAMPLE_INDIAN, "indian")
    ids = {a.id for a in p.archetypes}
    assert "spice_level" in ids
    assert "meat_preference" in ids, \
        "'Lamb/Goat' in the menu text must propose the bone-in/boneless group"


def t_proposal_never_fills_in_a_price_it_was_not_given():
    p = mi.propose(SAMPLE_INDIAN, "indian")
    for item in p.items:
        assert item.price_cents in (1399, 1499, 350), item
    # and every proposed group carries a price question
    priced = [c for c in p.confirmations if c.topic.startswith("prices in")]
    assert priced, "no price confirmations raised"


def t_proposal_flags_shared_dish_names():
    p = mi.propose(SAMPLE_INDIAN, "indian")
    assert any("saag" in w for w in p.protein_split_warnings), \
        "chicken saag + lamb saag must be flagged as needing disambiguation"


def t_proposal_flags_the_naan_homophone():
    p = mi.propose(SAMPLE_INDIAN, "indian")
    assert any("naan" in c.topic for c in p.confirmations)


def t_aliases_pick_the_most_specific_dish():
    from cuisine_library import suggested_aliases
    plain = suggested_aliases("indian", "Plain Naan")
    assert "garlic none" not in plain, \
        "Plain Naan must not inherit Garlic Naan's mishearings"
    assert "none" in plain


def t_aliases_respect_word_boundaries():
    from cuisine_library import suggested_aliases
    # "vindaloo" contains "dal"; it must not inherit Dal Makhani's aliases
    al = suggested_aliases("indian", "35. Chk Vindaloo")
    assert "lentils" not in al and "daal" not in al


def t_library_lint_catches_an_unpriced_group():
    """Bun N Run's bacon and cheese sit at $0.00 pending the owner's answer."""
    findings = mi.library_lint(BUN_N_RUN, "burger")
    assert any("entirely $0.00" in f for f in findings)
    assert len(findings) == len(set(findings)), "duplicate lint findings"


def t_library_lint_recognises_a_reordered_group_name():
    findings = mi.library_lint(PINK_GARLIC, "indian")
    assert not any("resembling 'Spice Level'" in f for f in findings), \
        "'Level of Spice' is the Spice Level group with the words reordered"


def t_asr_keyterms_respect_the_budget():
    kt = mi.asr_keyterms(PINK_GARLIC, "indian", max_terms=100, max_tokens=500)
    assert kt, "no keyterms selected"
    assert len(kt) <= 100
    import math
    tokens = sum(math.ceil(len(k.term.split()) * 1.4) + 1 for k in kt)
    assert tokens <= 500, f"{tokens} tokens exceeds the 500 budget"
    scores = [k.score for k in kt]
    assert scores == sorted(scores, reverse=True), "not ranked by risk"
    assert all(k.reason for k in kt), "a keyterm without a reason is a guess"


def t_asr_keyterms_prefer_colliding_items():
    kt = mi.asr_keyterms(PINK_GARLIC, "indian")
    top = [k.term for k in kt[:10]]
    assert any("Korma" in t for t in top), \
        "Chicken Korma collides with Chicken Pakora and should be boosted"


def t_render_draft_is_obviously_not_shippable():
    p = mi.propose(SAMPLE_INDIAN, "indian")
    src = mi.render_draft(p, "test-restaurant", "Test Restaurant")
    assert "NOT READY TO SHIP" in src
    assert "TODO" in src
    compile(src, "<draft>", "exec")   # must at least be valid Python


def t_parser_handles_price_on_its_own_line_and_inline():
    items = mi.parse_menu_text("Gyro Plate\n$14.99\nHummus $7.25\n")
    by = {i.name: i.price_cents for i in items}
    assert by.get("Gyro Plate") == 1499
    assert by.get("Hummus") == 725


def t_parser_reports_items_with_no_price():
    items = mi.parse_menu_text("SPECIALS\nMarket Fish\nAsk your server\n")
    assert any(i.price_cents is None for i in items)


TESTS = [v for k, v in sorted(globals().items()) if k.startswith("t_")]


def main() -> int:
    passed = failed = 0
    fails = []
    for fn in TESTS:
        try:
            fn()
            passed += 1
        except Exception as exc:
            failed += 1
            fails.append((fn.__name__, traceback.format_exc()))
    print(f"{passed} passed, {failed} failed (cuisine library + ingestion)")
    for n, tb in fails:
        print(f"\n--- FAIL {n}\n{tb}")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
