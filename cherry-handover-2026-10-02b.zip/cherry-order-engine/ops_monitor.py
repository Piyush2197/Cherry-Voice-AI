#!/usr/bin/env python3
"""Source-backed operations feed and alert rules for Cherry.

This reads the existing operational database and emits no notifications on its
own. The developer can send the returned alerts to PagerDuty, Slack, email, or
another on-call system without changing the rule definitions.
"""

from __future__ import annotations

import argparse
import json
import os
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from order_store import OrderStore
import cost_control


@dataclass(frozen=True)
class Alert:
    key: str
    severity: str
    category: str
    restaurant_id: str
    title: str
    detail: str
    action: str


def _iso(dt: datetime) -> str:
    return dt.isoformat(timespec="seconds")


def scan_alerts(store: OrderStore, *, now: Optional[datetime] = None,
                unacknowledged_minutes: int = 5,
                payment_minutes: int = 35,
                stuck_session_minutes: int = 120,
                handoff_only: Optional[bool] = None) -> List[Alert]:
    """Return current actionable conditions with stable de-duplication keys.

    ``payment_minutes`` defaults past the 30-minute life of a Square checkout
    link: a guest who simply has not paid yet is not an incident.

    In checkout-handoff-only mode (CHERRY_CHECKOUT_HANDOFF_ONLY=1) Square owns
    the order once it is paid and Cherry deliberately never releases a kitchen
    ticket, so "paid but not released" is the normal end state, not a fault.
    """
    now = now or datetime.now(timezone.utc)
    if handoff_only is None:
        handoff_only = os.environ.get("CHERRY_CHECKOUT_HANDOFF_ONLY") == "1"
    q = store.conn.execute
    alerts: List[Alert] = []
    # Every rule below runs every two minutes for as long as the system lives.
    # Without a horizon, the work (and the alert set) grows with all history.
    horizon = _iso(now - timedelta(days=7))

    for row in q("""
        SELECT o.id, o.short_code, o.restaurant_id, d.sink, d.status,
               d.error_kind, d.error_detail
        FROM order_delivery d JOIN "order" o ON o.id=d.order_id
        WHERE d.status='failed' AND d.created_at >= ?
          AND NOT EXISTS (
            SELECT 1 FROM order_delivery d2
            WHERE d2.order_id=d.order_id AND d2.sink=d.sink
              AND d2.status IN ('sent','acknowledged') AND d2.id>d.id)
        ORDER BY d.created_at
    """, (horizon,)).fetchall():
        alerts.append(Alert(
            f"delivery-failed:{row['id']}", "critical", "delivery",
            row["restaurant_id"], f"Order {row['short_code']} was not delivered",
            f"{row['sink']} failed: {row['error_kind'] or 'unknown'} — "
            f"{row['error_detail'] or 'no detail'}",
            "Call the restaurant, deliver the ticket manually, then trace the order."))

    unacked_before = _iso(now - timedelta(minutes=unacknowledged_minutes))
    for row in q("""
        SELECT DISTINCT o.id, o.short_code, o.restaurant_id, d.sink, d.sent_at
        FROM order_delivery d JOIN "order" o ON o.id=d.order_id
        WHERE d.status='sent' AND d.sent_at < ? AND d.sent_at >= ?
        ORDER BY d.sent_at
    """, (unacked_before, horizon)).fetchall():
        alerts.append(Alert(
            f"delivery-unacknowledged:{row['id']}", "critical", "delivery",
            row["restaurant_id"],
            f"Order {row['short_code']} has no kitchen acknowledgement",
            f"Sent through {row['sink']} at {row['sent_at']} and still unconfirmed.",
            "Call the restaurant before the customer arrives."))

    payment_before = _iso(now - timedelta(minutes=payment_minutes))
    for row in q("""
        SELECT p.order_id, p.status, p.updated_at, o.short_code, o.restaurant_id
        FROM payment p JOIN "order" o ON o.id=p.order_id
        WHERE p.status IN ('link_pending','link_sent') AND p.updated_at < ?
        ORDER BY p.updated_at
    """, (payment_before,)).fetchall():
        alerts.append(Alert(
            f"payment-stuck:{row['order_id']}", "high", "payment",
            row["restaurant_id"], f"Order {row['short_code']} payment is stuck",
            f"Payment has remained {row['status']} since {row['updated_at']}.",
            "Check the POS payment status and contact the customer if required."))

    paid_before = _iso(now - timedelta(minutes=2))
    for row in ([] if handoff_only else q("""SELECT o.id,o.short_code,o.restaurant_id,
             r.status AS release_status
        FROM payment p JOIN "order" o ON o.id=p.order_id
        LEFT JOIN order_release r ON r.order_id=o.id
        WHERE p.status='paid' AND p.settled_at < ?
          AND (r.order_id IS NULL OR r.status='claimed')
        ORDER BY p.settled_at""", (paid_before,)).fetchall()):
        alerts.append(Alert(
            f"paid-not-released:{row['id']}", "critical", "delivery",
            row["restaurant_id"],
            f"Paid order {row['short_code']} needs handoff review",
            f"Payment verified; release is {row['release_status'] or 'unclaimed'}.",
            "Check the POS and restaurant before manually retrying; an "
            "uncertain kitchen send must not create a duplicate ticket."))

    stuck_before = _iso(now - timedelta(minutes=stuck_session_minutes))
    for row in q("""
        SELECT id, restaurant_id, started_at FROM session
        WHERE ended_at IS NULL AND started_at < ? ORDER BY started_at
    """, (stuck_before,)).fetchall():
        alerts.append(Alert(
            f"session-stuck:{row['id']}", "high", "call",
            row["restaurant_id"], "Call session did not close",
            f"Session {row['id']} has been open since {row['started_at']}.",
            "Inspect the call trace and close or recover the session."))

    for row in q("""
        SELECT e.id, e.restaurant_id, e.detail, e.created_at
        FROM event e WHERE e.kind='voice.handoff_failed' AND e.created_at >= ?
          AND NOT EXISTS (
            SELECT 1 FROM event e2 WHERE e2.kind='voice.handoff_succeeded'
              AND e2.session_id=e.session_id AND e2.id>e.id)
        ORDER BY e.created_at
    """, (horizon,)).fetchall():
        alerts.append(Alert(
            f"handoff-failed:{row['id']}", "critical", "handoff",
            row["restaurant_id"] or "unknown", "Human call transfer failed",
            f"Transfer failed at {row['created_at']}: {row['detail']}",
            "Call the customer or restaurant and inspect the Telnyx call trace."))

    # Callers cannot get an itemized checkout link: Square down, token expired
    # or never authorized, or the location has no checkout at all. Each such
    # call is already handed to staff, but a run of them means every caller
    # is being turned away and a person must fix the cause.
    window_start = _iso(now - timedelta(minutes=60))
    for row in q("""
        SELECT restaurant_id, COUNT(*) AS n, MAX(kind) AS kind
        FROM event
        WHERE kind IN ('payment.link_failed','payment.no_provider',
                       'call.refused_no_checkout')
          AND restaurant_id IS NOT NULL AND created_at >= ?
        GROUP BY restaurant_id ORDER BY restaurant_id
    """, (window_start,)).fetchall():
        n = int(row["n"])
        alerts.append(Alert(
            f"checkout-failing:{row['restaurant_id']}:{now.strftime('%Y%m%d%H')}",
            "critical" if n >= 3 else "high", "checkout", row["restaurant_id"],
            f"{n} caller(s) could not get a checkout link in the last hour",
            f"Latest cause: {row['kind']}. Callers were transferred to staff.",
            "Check the Square authorization (python3 square_oauth.py status) "
            "and Square's status page; re-authorize the merchant if needed."))

    # Money arrived in a way Cherry cannot reconcile on its own: the paid
    # amount differs from the quote, or a guest paid a link after it expired
    # or the order was cancelled. Until now these only set a session flag that
    # nobody reads, so a customer could be charged for an order nobody made.
    for row in q("""
        SELECT id, restaurant_id, order_id, kind, created_at FROM event
        WHERE kind IN ('payment.amount_mismatch',
                       'payment.completed_after_expiry')
          AND created_at >= ? ORDER BY id
    """, (horizon,)).fetchall():
        alerts.append(Alert(
            f"payment-anomaly:{row['id']}", "critical", "payment",
            row["restaurant_id"] or "unknown",
            "A payment needs a human to reconcile",
            f"{row['kind']} on order {row['order_id']} at {row['created_at']}.",
            "Check the payment in Square; refund it or remake the order, and "
            "tell the customer."))

    for row in q("""
        SELECT e.id, e.restaurant_id, e.created_at FROM event e
        WHERE e.kind='square.oauth_refresh_failed'
          AND NOT EXISTS (
            SELECT 1 FROM event e2 WHERE e2.kind='square.oauth_refreshed'
              AND e2.restaurant_id=e.restaurant_id AND e2.id>e.id)
          AND e.id=(SELECT MAX(e3.id) FROM event e3
                    WHERE e3.kind='square.oauth_refresh_failed'
                      AND e3.restaurant_id=e.restaurant_id)
        ORDER BY e.id
    """).fetchall():
        alerts.append(Alert(
            f"square-token-refresh:{row['id']}", "critical", "checkout",
            row["restaurant_id"] or "unknown",
            "Square token refresh is failing",
            f"Last failure {row['created_at']}. Checkout links stop working "
            "when the current token expires (within 30 days of its last refresh).",
            "Run python3 square_oauth.py status; if the merchant revoked access, "
            "send them a new python3 square_oauth.py authorize-url link."))

    for row in q("""
        SELECT id, restaurant_id, kind, error_detail, created_at
        FROM sms_message WHERE status='failed' AND created_at >= ?
        ORDER BY created_at
    """, (horizon,)).fetchall():
        alerts.append(Alert(
            f"sms-failed:{row['id']}", "high", "sms",
            row["restaurant_id"] or "unknown", "Customer or kitchen text failed",
            f"{row['kind']} text failed at {row['created_at']}: "
            f"{row['error_detail'] or 'no provider detail'}",
            "Check suppression and carrier status, then use a non-SMS fallback."))

    for row in q("""
        SELECT r.id FROM restaurant r
        LEFT JOIN menu_version m ON m.restaurant_id=r.id AND m.is_live=TRUE
        WHERE r.active=TRUE AND m.id IS NULL ORDER BY r.id
    """).fetchall():
        alerts.append(Alert(
            f"live-menu-missing:{row['id']}", "critical", "configuration",
            row["id"], "Active restaurant has no live menu",
            "Incoming calls cannot construct an order session.",
            "Disable the route or publish a verified menu immediately."))

    # Rising usage, not an outage: a location reaching its plan's daily call
    # figure (PRICING_PLANS_2026-09-23.md calls these illustrations). The
    # point is to open the plan conversation before the monthly allowance is
    # blown — never to cut a caller off. Keyed per day so it pages once.
    day_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    day_end = day_start + timedelta(days=1)
    plans = cost_control.location_plans(store)
    for row in q("""
        SELECT restaurant_id, COUNT(*) AS n FROM session
        WHERE channel='voice' AND started_at>=? AND started_at<?
        GROUP BY restaurant_id
    """, (_iso(day_start), _iso(day_end))).fetchall():
        rid = row["restaurant_id"]
        plan = plans.get(rid, cost_control.DEFAULT_PLAN)
        threshold = cost_control.PLANS[plan]["daily_calls"]
        n = int(row["n"])
        if n >= threshold:
            alerts.append(Alert(
                f"plan-daily-usage:{rid}:{now.strftime('%Y%m%d')}",
                "warning", "usage", rid,
                f"{n} calls today, at the {plan} plan's daily figure of {threshold}",
                f"The {plan} plan includes "
                f"{cost_control.PLANS[plan]['monthly_minutes']:,.0f} voice "
                "minutes a month. The daily figure is a signal, not a limit.",
                "Do not interrupt calls. Check month-to-date minutes against "
                "the allowance; raise the plan if the trend holds."))

    rank = {"critical": 0, "high": 1, "warning": 2}
    return sorted(alerts, key=lambda a: (rank.get(a.severity, 9), a.key))


def operations_snapshot(store: OrderStore, *, hours: int = 24,
                        now: Optional[datetime] = None) -> Dict[str, Any]:
    """Privacy-safe dashboard feed at restaurant and issue-code grain."""
    now = now or datetime.now(timezone.utc)
    since = _iso(now - timedelta(hours=hours))
    q = store.conn.execute
    totals = q("""
        SELECT COUNT(*) AS calls,
               SUM(CASE WHEN ended_at IS NOT NULL THEN 1 ELSE 0 END) AS ended,
               SUM(CASE WHEN escalated_at IS NOT NULL THEN 1 ELSE 0 END) AS escalated,
               SUM(CASE WHEN end_reason IN ('abandoned','no_order','timed_out')
                        THEN 1 ELSE 0 END) AS abandoned
        FROM session WHERE started_at >= ? AND channel='voice'
    """, (since,)).fetchone()
    orders = q("""
        SELECT COUNT(*) AS orders, COALESCE(SUM(o.total_cents),0) AS revenue_cents
        FROM "order" o JOIN session s ON s.id=o.session_id
        WHERE o.placed_at >= ? AND s.channel='voice'
    """, (since,)).fetchone()
    calls, order_count = int(totals["calls"] or 0), int(orders["orders"] or 0)

    by_restaurant = [dict(row) for row in q("""
        SELECT r.id AS restaurant_id, r.name,
               COUNT(DISTINCT s.id) AS calls,
               COUNT(DISTINCT o.id) AS orders,
               COALESCE(SUM(o.total_cents),0) AS revenue_cents,
               COUNT(DISTINCT CASE WHEN s.escalated_at IS NOT NULL THEN s.id END)
                   AS escalations
        FROM restaurant r
        LEFT JOIN session s ON s.restaurant_id=r.id AND s.started_at >= ?
                           AND s.channel='voice'
        LEFT JOIN "order" o ON o.session_id=s.id AND o.placed_at >= ?
        WHERE r.active=TRUE GROUP BY r.id, r.name ORDER BY r.name
    """, (since, since)).fetchall()]
    for row in by_restaurant:
        row["conversion_percent"] = (
            round(row["orders"] / row["calls"] * 100, 1) if row["calls"] else None)

    issues = [dict(row) for row in q("""
        SELECT engine_issue_code AS code, COUNT(*) AS count
        FROM turn WHERE created_at >= ? AND engine_issue_code IS NOT NULL
        GROUP BY engine_issue_code ORDER BY count DESC, code
    """, (since,)).fetchall()]
    catalog_reviews = []
    for row in q("""SELECT id,restaurant_id,detail,created_at FROM event
                     WHERE kind='catalog.review_required' AND created_at>=?
                     ORDER BY created_at DESC""", (since,)).fetchall():
        from order_store import json_value
        catalog_reviews.append({"id": row["id"],
                                "restaurant_id": row["restaurant_id"],
                                "created_at": row["created_at"],
                                "detail": json_value(row["detail"])})
    alerts = [asdict(a) for a in scan_alerts(store, now=now)]
    return {
        "generated_at": _iso(now), "window_hours": hours,
        "summary": {
            "calls": calls, "orders": order_count,
            "conversion_percent": round(order_count / calls * 100, 1)
            if calls else None,
            "revenue_cents": int(orders["revenue_cents"] or 0),
            "escalated_calls": int(totals["escalated"] or 0),
            "abandoned_calls": int(totals["abandoned"] or 0),
            "open_alerts": len(alerts),
        },
        "by_restaurant": by_restaurant,
        "engine_issues": issues,
        "catalog_reviews": catalog_reviews,
        "alerts": alerts,
        "definitions": {
            "conversion_percent": "orders divided by inbound call sessions",
            "revenue_cents": "sum of immutable placed-order totals",
            "escalated_calls": "sessions with a recorded escalation timestamp",
            "open_alerts": "current conditions returned by scan_alerts",
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--db", required=True)
    parser.add_argument("--hours", type=int, default=24)
    parser.add_argument("--alerts-only", action="store_true")
    args = parser.parse_args()
    store = OrderStore.open(args.db)
    payload = ([asdict(a) for a in scan_alerts(store)] if args.alerts_only
               else operations_snapshot(store, hours=args.hours))
    print(json.dumps(payload, indent=2, sort_keys=True))
    alerts = payload if isinstance(payload, list) else payload["alerts"]
    return 2 if any(a["severity"] == "critical" for a in alerts) else 0


if __name__ == "__main__":
    raise SystemExit(main())
