#!/usr/bin/env python3
"""
Tests for the two real bridges: Telnyx SMS and Square.

Neither touches the network. Both are driven through a fake urlopen, which
means the tests assert the EXACT bytes we would put on the wire — the field
names, the string-vs-integer types, the idempotency keys. That is the part
that breaks in production, and it is invisible to a mocked client library.
"""

from __future__ import annotations

import io
import json
import traceback
import urllib.error
from dataclasses import replace
from pathlib import Path
from typing import Any, Dict, List, Optional

import menu_schema as ms
import square_bridge as sq
import telnyx_sms as tx
from order_engine import OrderEngine
from order_store import OrderStore
from sinks import DeliveryResult, SinkContext, ManualSink, deliver

HERE = Path(__file__).parent
MENUS = HERE / "menus"

_passed, _failed = 0, 0


def check(name: str, cond: bool, detail: str = "") -> None:
    global _passed, _failed
    if cond:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


# ---------------------------------------------------------------------------
# A fake urlopen that records what we sent
# ---------------------------------------------------------------------------


class _Resp(io.BytesIO):
    status = 200

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


class FakeHTTP:
    """Records every request; replies with queued responses."""

    def __init__(self, responses: Optional[List[Any]] = None) -> None:
        self.requests: List[Dict[str, Any]] = []
        self.responses = list(responses or [])

    def __call__(self, req, timeout=None):
        self.requests.append({
            "url": req.full_url,
            "method": req.get_method(),
            "headers": {k.lower(): v for k, v in req.header_items()},
            "body": json.loads(req.data.decode()) if req.data else None,
        })
        reply = self.responses.pop(0) if self.responses else {"data": {"id": "m1"}}
        if isinstance(reply, Exception):
            raise reply
        return _Resp(json.dumps(reply).encode())

    @property
    def last_body(self):
        return self.requests[-1]["body"]


def http_error(status: int, codes: List[str], detail: str = "nope",
               headers: Optional[Dict[str, str]] = None):
    body = json.dumps({"errors": [{"code": c, "title": "t", "detail": detail}
                                  for c in codes]}).encode()
    return urllib.error.HTTPError("https://x", status, detail,
                                  headers or {}, io.BytesIO(body))


def _store_with_order(menu="bun-n-run-ferndale", item="double_cheeseburger",
                      qty=1, sink="manual"):
    store = OrderStore.sqlite()
    cfg = replace(ms.load_yaml(MENUS / f"{menu}.yaml"),
                  pay_now_threshold_cents=3000)
    store.upsert_restaurant(cfg.id, cfg.name, cfg.cuisine,
                            tax_rate_bps=cfg.tax_rate_bps, sink=sink,
                            staff_phone="+13135550100", active=True)
    mv = store.publish_menu(cfg.id, (MENUS / f"{menu}.yaml").read_text(),
                            item_count=len(cfg.items))
    e = OrderEngine(cfg)
    line = e.add_line(item, quantity=qty)
    for gid in e.active_group_ids(line):
        g = cfg.group(gid)
        if g and g.required:
            e.apply_option(line.line_id, gid, g.option_ids[0])
    snap = e.to_normalized_order()
    oid, code = store.place_order(cfg.id, mv, snap, customer_phone="+13135550123")
    return store, cfg, oid, code, snap, e


# ---------------------------------------------------------------------------
# Telnyx
# ---------------------------------------------------------------------------


def t_telnyx_sends_the_documented_payload() -> None:
    http = FakeHTTP([{"data": {"id": "msg-abc",
                               "to": [{"phone_number": "+13135550100",
                                       "status": "queued"}]}}])
    s = tx.TelnyxSmsSender("key-1", "+13135559999", opener=http)
    ref = s.send("+13135550100", "ticket text")

    check("returns the provider message id", ref == "msg-abc", ref)
    req = http.requests[0]
    check("posts to /v2/messages", req["url"] == tx.TELNYX_MESSAGES_URL, req["url"])
    check("uses POST", req["method"] == "POST")
    check("authenticates with a bearer token",
          req["headers"].get("authorization") == "Bearer key-1",
          str(req["headers"]))
    body = req["body"]
    check("'to' is a STRING, not an array", isinstance(body["to"], str),
          type(body["to"]).__name__)
    check("'from' is the registered sender", body["from"] == "+13135559999")
    check("text is the body", body["text"] == "ticket text")
    check("no messaging_profile_id when sending from an explicit number",
          "messaging_profile_id" not in body, str(body))


def t_telnyx_includes_the_profile_only_when_given_one() -> None:
    http = FakeHTTP()
    s = tx.TelnyxSmsSender("k", "+1313", messaging_profile_id="prof-1", opener=http)
    s.send("+1555", "hi")
    check("messaging_profile_id is passed through when configured",
          http.last_body.get("messaging_profile_id") == "prof-1")


def t_telnyx_refuses_to_start_without_credentials() -> None:
    for kwargs, want in ((dict(api_key="", from_number="+1"), "API key"),
                         (dict(api_key="k", from_number=""), "from_number")):
        try:
            tx.TelnyxSmsSender(**kwargs)
        except ValueError as exc:
            check(f"missing {want} fails at construction", want in str(exc), str(exc))
        else:
            check(f"missing {want} fails at construction", False,
                  "constructed anyway")


def t_telnyx_classifies_errors_the_way_the_docs_do() -> None:
    cases = [
        # (codes, http, retryable, sender_not_ready, why)
        (["40006"], 400, True, False, "carrier down is transient"),
        (["40008"], 400, True, False, "general undeliverable is transient"),
        (["40011"], 400, True, False, "rate limited, retry with backoff"),
        (["40318"], 400, True, False, "queue full, retry with backoff"),
        (["40010"], 400, False, True, "no 10DLC campaign — never retry"),
        (["40300"], 400, False, False, "recipient sent STOP — never retry"),
        (["40305"], 400, False, True, "'from' not on the profile"),
        (["40001"], 400, False, False, "invalid request"),
        ([], 429, True, False, "HTTP 429 is retryable"),
        ([], 503, True, False, "HTTP 5xx is retryable"),
        ([], 400, False, False, "unknown 4xx is NOT retryable"),
        (["99999"], 400, False, False, "an unknown code is NOT retryable"),
        # A permanent code must win over a retryable STATUS. Otherwise a
        # 10DLC block or an opt-out that happens to arrive alongside a 503
        # gets retried — texting someone who sent STOP is the one failure
        # here with a regulator attached to it.
        (["40010"], 503, False, True, "10DLC block beats a retryable 5xx"),
        (["40300"], 429, False, False, "an opt-out beats a 429"),
        (["40001"], 500, False, False, "an invalid request beats a 500"),
    ]
    for codes, status, want_retry, want_sender, why in cases:
        retry, sender = tx.classify(codes, status)
        check(f"classify {codes or status}: {why}", retry == want_retry,
              f"got retryable={retry}")
        check(f"sender readiness for {codes or status}", sender == want_sender,
              f"got sender_not_ready={sender}")


def t_telnyx_raises_a_typed_error_carrying_retryability() -> None:
    http = FakeHTTP([http_error(400, ["40010"], "not registered")])
    s = tx.TelnyxSmsSender("k", "+1", opener=http)
    try:
        s.send("+1555", "x")
    except tx.SmsError as exc:
        check("10DLC failure is not retryable", exc.retryable is False)
        check("it flags the sending number, not the message",
              exc.sender_not_ready is True)
        check("it carries the code", exc.code == "40010", str(exc.code))
        check("the detail names the code", "40010" in exc.detail, exc.detail)
    else:
        check("10DLC failure raises", False, "no raise")


def t_telnyx_treats_a_dead_network_as_retryable() -> None:
    http = FakeHTTP([urllib.error.URLError("connection refused")])
    s = tx.TelnyxSmsSender("k", "+1", opener=http)
    try:
        s.send("+1555", "x")
    except tx.SmsError as exc:
        check("transport failure is retryable", exc.retryable is True)
        check("it is labelled transport", exc.code == "transport")
    else:
        check("transport failure raises", False, "no raise")


def t_telnyx_never_texts_a_suppressed_number() -> None:
    store = OrderStore.sqlite()
    store.suppress("+13135550123", "replied STOP", "inbound_stop")
    http = FakeHTTP()
    s = tx.TelnyxSmsSender("k", "+1", store=store, opener=http)
    try:
        s.send("+13135550123", "hello again")
    except tx.SmsError as exc:
        check("a suppressed number is refused", "opted out" in exc.detail, exc.detail)
        check("refusal is not retryable", exc.retryable is False)
        check("and nothing was put on the wire", http.requests == [],
              str(http.requests))
    else:
        check("a suppressed number is refused", False, "it sent anyway")


def t_telnyx_spaces_sends_when_asked() -> None:
    """A long code is rated at one message per ten seconds."""
    slept: List[float] = []
    now = [100.0]
    http = FakeHTTP([{"data": {"id": "a"}}, {"data": {"id": "b"}}])
    s = tx.TelnyxSmsSender("k", "+1", opener=http, min_interval_seconds=10.0,
                           clock=lambda: now[0], sleep=slept.append)
    s.send("+1555", "one")
    now[0] += 2.0
    s.send("+1555", "two")
    check("the second send waits out the remaining interval",
          slept and abs(slept[0] - 8.0) < 0.01, str(slept))


def t_a_200_means_queued_not_delivered() -> None:
    """The single most misread part of the Telnyx API."""
    store = OrderStore.sqlite()
    store.log_sms("+1555", "body", "ticket", provider_ref="msg-1", status="queued")
    row = store.sms_by_ref("msg-1")
    check("a sent message starts as queued", row["status"] == "queued",
          row["status"])

    tx.handle_webhook(store, {"data": {"event_type": "message.finalized",
                                       "payload": {"id": "msg-1", "direction": "outbound",
                                                   "to": [{"phone_number": "+1555",
                                                           "status": "delivered"}]}}})
    check("only the webhook can mark it delivered",
          store.sms_by_ref("msg-1")["status"] == "delivered")


def t_webhook_failure_records_the_reason() -> None:
    store = OrderStore.sqlite()
    store.log_sms("+1555", "b", "ticket", provider_ref="msg-2", status="sent")
    res = tx.handle_webhook(store, {"data": {
        "event_type": "message.finalized",
        "payload": {"id": "msg-2", "direction": "outbound",
                    "to": [{"phone_number": "+1555", "status": "delivery_failed"}],
                    "errors": [{"code": "40008", "detail": "undeliverable"}]}}})
    row = store.sms_by_ref("msg-2")
    check("failure is recorded", row["status"] == "failed", row["status"])
    check("the code is kept for the dashboard", "40008" in (row["error_detail"] or ""))
    check("the handler reports what it did", res["action"] == "failed", str(res))


def t_an_opt_out_code_suppresses_the_number() -> None:
    """40300 arrives on the webhook, after the message has already gone."""
    store = OrderStore.sqlite()
    store.log_sms("+13135550123", "b", "pay_link", provider_ref="msg-3")
    tx.handle_webhook(store, {"data": {
        "event_type": "message.finalized",
        "payload": {"id": "msg-3", "direction": "outbound",
                    "to": [{"phone_number": "+13135550123",
                            "status": "delivery_failed"}],
                    "errors": [{"code": "40300", "detail": "blocked"}]}}})
    check("the number is suppressed", store.is_suppressed("+13135550123"))


def t_an_inbound_stop_suppresses_and_start_restores() -> None:
    store = OrderStore.sqlite()
    for word in ("STOP", "stop", "Stop.", "UNSUBSCRIBE", "quit"):
        store.unsuppress("+1555")
        tx.handle_webhook(store, {"data": {"event_type": "message.received",
                                           "payload": {"direction": "inbound",
                                                       "from": {"phone_number": "+1555"},
                                                       "text": word}}})
        check(f"{word!r} opts the caller out", store.is_suppressed("+1555"))

    tx.handle_webhook(store, {"data": {"event_type": "message.received",
                                       "payload": {"direction": "inbound",
                                                   "from": {"phone_number": "+1555"},
                                                   "text": "START"}}})
    check("START opts them back in", not store.is_suppressed("+1555"))


def t_an_ordinary_inbound_reply_is_logged_not_actioned() -> None:
    store = OrderStore.sqlite()
    tx.handle_webhook(store, {"data": {"event_type": "message.received",
                                       "payload": {"direction": "inbound",
                                                   "from": {"phone_number": "+1555"},
                                                   "text": "can I add fries"}}})
    check("the reply is kept", any(e["kind"] == "sms.inbound"
                                   for e in store.events()))
    check("but it does not suppress", not store.is_suppressed("+1555"))


def t_a_malformed_webhook_never_raises() -> None:
    """A handler that raises makes the provider retry, multiplying the mess."""
    store = OrderStore.sqlite()
    for payload in ({}, {"data": {}}, {"data": {"payload": {}}},
                    {"data": {"payload": {"id": None}}},
                    {"data": {"payload": {"id": "x", "to": []}}}):
        try:
            tx.handle_webhook(store, payload)
            check(f"survives {str(payload)[:40]}", True)
        except Exception as exc:                      # noqa: BLE001
            check(f"survives {str(payload)[:40]}", False, repr(exc))


def t_manual_sink_does_not_retry_a_permanent_sms_failure() -> None:
    store, cfg, oid, code, snap, _ = _store_with_order()
    http = FakeHTTP([http_error(400, ["40010"]) for _ in range(3)])
    sender = tx.TelnyxSmsSender("k", "+1", opener=http)
    res = deliver(store, oid, ManualSink(sender), sleep=lambda s: None)
    check("delivery failed", res.ok is False)
    check("it was recorded as a rejection, not a connection problem",
          res.error_kind == "rejected", str(res.error_kind))
    check("and it was attempted exactly once", len(http.requests) == 1,
          f"{len(http.requests)} attempts")


def t_manual_sink_does_retry_a_transient_sms_failure() -> None:
    store, cfg, oid, code, snap, _ = _store_with_order()
    http = FakeHTTP([http_error(503, []), http_error(503, []),
                     {"data": {"id": "msg-ok"}}])
    sender = tx.TelnyxSmsSender("k", "+1", opener=http)
    res = deliver(store, oid, ManualSink(sender), sleep=lambda s: None)
    check("it eventually succeeds", res.ok is True, str(res.error_detail))
    check("after three attempts", len(http.requests) == 3, str(len(http.requests)))


# ---------------------------------------------------------------------------
# Square
# ---------------------------------------------------------------------------


def t_square_order_uses_squares_types_not_ours() -> None:
    store, cfg, oid, code, snap, _ = _store_with_order(qty=3)
    order = sq.build_square_order(snap, "L-1", reference_id=code,
                                  tax_rate_bps=cfg.tax_rate_bps)
    li = order["line_items"][0]
    check("quantity is a STRING", isinstance(li["quantity"], str),
          type(li["quantity"]).__name__)
    check("quantity is right", li["quantity"] == "3", li["quantity"])
    check("money is integer cents",
          isinstance(li["base_price_money"]["amount"], int))
    check("currency is set", li["base_price_money"]["currency"] == "USD")
    check("location_id is present", order["location_id"] == "L-1")
    check("state is OPEN, never DRAFT", order["state"] == "OPEN")


def t_square_order_is_pickup_asap_or_the_kitchen_never_sees_it() -> None:
    store, cfg, oid, code, snap, _ = _store_with_order()
    order = sq.build_square_order(snap, "L-1", prep_minutes=25)
    f = order["fulfillments"][0]
    check("there is a fulfillment — without one it never appears", bool(f))
    check("type is PICKUP", f["type"] == "PICKUP")
    check("state is PROPOSED", f["state"] == "PROPOSED")
    pd = f["pickup_details"]
    check("schedule_type is ASAP, not the SCHEDULED default",
          pd["schedule_type"] == "ASAP", pd.get("schedule_type"))
    check("prep time is minutes, not months (PT25M not P25M)",
          pd["prep_time_duration"] == "PT25M", pd["prep_time_duration"])
    check("the recipient has a display name",
          bool(pd["recipient"]["display_name"]))


def t_a_removal_is_its_own_zero_price_modifier() -> None:
    """Not a note. A cook skims a note; a modifier is its own line."""
    cfg = ms.load_yaml(MENUS / "bun-n-run-ferndale.yaml")
    e = OrderEngine(cfg)
    line = e.add_line("double_cheeseburger")
    onion = next(o.id for o in cfg.options if o.name.lower() == "onion")
    e.remove_option(line.line_id, onion)
    order = sq.build_square_order(e.to_normalized_order(), "L-1")
    mods = order["line_items"][0]["modifiers"]
    no_onion = [m for m in mods if m["name"].startswith("NO ")]
    check("the removal is a modifier", len(no_onion) == 1, str(mods))
    check("it is shouted for the line cook", no_onion[0]["name"] == "NO ONION",
          no_onion[0]["name"])
    check("it costs nothing", no_onion[0]["base_price_money"]["amount"] == 0)
    check("it is not hidden in a note",
          "onion" not in (order["line_items"][0].get("note") or "").lower())


def t_ad_hoc_modifiers_always_carry_a_price() -> None:
    """Square requires base_price_money on an ad-hoc modifier, even free ones."""
    store, cfg, oid, code, snap, e = _store_with_order()
    order = sq.build_square_order(snap, "L-1")
    for li in order["line_items"]:
        for m in li.get("modifiers", []):
            check(f"modifier {m['name']} has a price",
                  "base_price_money" in m, str(m))
            check(f"modifier {m['name']} has no catalog id it cannot back up",
                  "catalog_object_id" not in m or bool(m["catalog_object_id"]))


def t_informational_options_never_reach_square() -> None:
    cfg = ms.load_yaml(MENUS / "seoul_stone.yaml")
    e = OrderEngine(cfg)
    line = e.add_line(cfg.items[0].id)
    for gid in e.active_group_ids(line):
        g = cfg.group(gid)
        if g and g.required:
            e.apply_option(line.line_id, gid, g.option_ids[0])
    order = sq.build_square_order(e.to_normalized_order(), "L-1")
    names = [m["name"] for li in order["line_items"]
             for m in li.get("modifiers", [])]
    info_ids = {o for g in cfg.groups if g.informational for o in g.option_ids}
    info_names = {cfg.option(o).name for o in info_ids if cfg.option(o)}
    check("banchan and the like are not sent as modifiers",
          not (set(names) & info_names), str(set(names) & info_names))


def t_tax_is_sent_because_ad_hoc_lines_carry_none() -> None:
    store, cfg, oid, code, snap, _ = _store_with_order()
    order = sq.build_square_order(snap, "L-1", tax_rate_bps=600)
    taxes = order.get("taxes") or []
    check("a tax line is included", len(taxes) == 1, str(taxes))
    check("600 bps is rendered as 6 percent", taxes[0]["percentage"] == "6",
          taxes[0]["percentage"])
    check("it applies to the whole order", taxes[0]["scope"] == "ORDER")

    order = sq.build_square_order(snap, "L-1", tax_rate_bps=0)
    check("no tax line when the restaurant has no rate", "taxes" not in order)


def t_pay_now_makes_one_call_and_returns_the_link() -> None:
    """Not CreateOrder then a link — that bills the wrong one of two orders."""
    store, cfg, oid, code, snap, _ = _store_with_order()
    snap["payment_mode"] = "pay_now"
    http = FakeHTTP([{"payment_link": {"url": "https://sq.link/abc",
                                       "order_id": "sq-order-1", "id": "pl-1"}}])
    sink = sq.SquareSink(sq.SquareClient("tok", "L-1", opener=http))
    ctx = SinkContext(restaurant_id=cfg.id, restaurant_name=cfg.name,
                      short_code=code, customer_phone="+13135550123")
    res = sink.send(oid, snap, ctx)

    check("it succeeded", res.ok is True, str(res.error_detail))
    check("exactly one HTTP call", len(http.requests) == 1, str(len(http.requests)))
    check("it is the payment-links endpoint",
          http.requests[0]["url"].endswith("/v2/online-checkout/payment-links"),
          http.requests[0]["url"])
    check("the pay url is captured for the SMS relay",
          sink.last_pay_url == "https://sq.link/abc", str(sink.last_pay_url))
    check("the Square order id is the delivery ref",
          res.external_ref == "sq-order-1", str(res.external_ref))
    body = http.requests[0]["body"]
    check("the whole order is inlined in the link request",
          body["order"]["line_items"], str(body)[:200])
    check("the buyer's number is pre-filled",
          body["pre_populated_data"]["buyer_phone_number"] == "+13135550123")
    check("an idempotency key is always sent", bool(body.get("idempotency_key")))
    check("the API version is pinned",
          http.requests[0]["headers"]["square-version"] == sq.SQUARE_VERSION)


def t_pay_at_pickup_creates_an_order_and_still_needs_a_paper_ticket() -> None:
    """Square will not show an unpaid order to the kitchen. This is the
    finding that keeps ManualSink in the picture for Square restaurants."""
    store, cfg, oid, code, snap, _ = _store_with_order()
    snap["payment_mode"] = "pay_at_pickup"
    http = FakeHTTP([{"order": {"id": "sq-order-2"}}])
    sink = sq.SquareSink(sq.SquareClient("tok", "L-1", opener=http))
    ctx = SinkContext(restaurant_id=cfg.id, restaurant_name=cfg.name,
                      short_code=code)
    res = sink.send(oid, snap, ctx)
    check("the order is created", res.ok is True, str(res.error_detail))
    check("via the orders endpoint",
          http.requests[0]["url"].endswith("/v2/orders"), http.requests[0]["url"])
    check("and we know a manual ticket is still required",
          sq.SquareSink.needs_manual_ticket(snap) is True)

    snap["payment_mode"] = "pay_now"
    check("a paid order does not need one",
          sq.SquareSink.needs_manual_ticket(snap) is False)


def t_square_idempotency_key_is_stable_per_order() -> None:
    store, cfg, oid, code, snap, _ = _store_with_order()
    snap["payment_mode"] = "pay_now"
    keys = []
    for _ in range(2):
        http = FakeHTTP([{"payment_link": {"url": "https://x/1", "order_id": "o"}}])
        sink = sq.SquareSink(sq.SquareClient("tok", "L-1", opener=http))
        sink.send(oid, snap, SinkContext(cfg.id, cfg.name, code))
        keys.append(http.requests[0]["body"]["idempotency_key"])
    check("a retry reuses the key, so Square de-duplicates",
          keys[0] == keys[1], str(keys))
    check("the key is within Square's 192-char limit", len(keys[0]) <= 192)


def t_square_errors_are_classified() -> None:
    store, cfg, oid, code, snap, _ = _store_with_order()
    cases = [
        (http_error(429, ["RATE_LIMITED"]), True, "connection", "rate limit retries"),
        (http_error(503, []), True, "connection", "5xx retries"),
        (http_error(404, ["NOT_FOUND"]), False, "rejected", "bad catalog id is permanent"),
        (http_error(400, ["INVALID_LOCATION"]), False, "rejected", "bad location is permanent"),
    ]
    for err, want_retry, want_kind, why in cases:
        http = FakeHTTP([err])
        sink = sq.SquareSink(sq.SquareClient("tok", "L-1", opener=http))
        res = sink.send(oid, snap, SinkContext(cfg.id, cfg.name, code))
        check(why, res.retryable == want_retry, f"retryable={res.retryable}")
        check(f"{why} → {want_kind}", res.error_kind == want_kind, str(res.error_kind))


def t_an_expired_token_is_not_retried_but_is_named() -> None:
    store, cfg, oid, code, snap, _ = _store_with_order()
    http = FakeHTTP([http_error(401, ["ACCESS_TOKEN_EXPIRED"])])
    sink = sq.SquareSink(sq.SquareClient("tok", "L-1", opener=http))
    res = sink.send(oid, snap, SinkContext(cfg.id, cfg.name, code))
    check("an expired token is not retried with the same dead token",
          res.retryable is False)
    check("it is flagged as auth", res.error_kind == "auth", str(res.error_kind))
    check("and it says what to do", "refresh" in (res.error_detail or "").lower(),
          str(res.error_detail))


def t_square_client_refuses_to_start_half_configured() -> None:
    for kwargs, want in ((dict(access_token="", location_id="L"), "access token"),
                         (dict(access_token="t", location_id=""), "location_id")):
        try:
            sq.SquareClient(**kwargs)
        except ValueError as exc:
            check(f"missing {want} fails at construction", want in str(exc), str(exc))
        else:
            check(f"missing {want} fails at construction", False, "constructed")


def t_pos_ref_gaps_reports_what_is_unmapped() -> None:
    cfg = ms.load_yaml(MENUS / "pink-garlic-shelby.yaml")
    gaps = sq.pos_ref_gaps(cfg)
    check("every item is reported unmapped before a catalog sync",
          len(gaps["items"]) == len(cfg.items),
          f"{len(gaps['items'])} of {len(cfg.items)}")
    check("options are reported too", len(gaps["options"]) == len(cfg.options))


def t_a_mapped_item_sends_its_catalog_id() -> None:
    """The upgrade path: fill pos_refs and the same bridge sends catalog lines."""
    store, cfg, oid, code, snap, _ = _store_with_order()
    snap["lines"][0]["pos_refs"] = {"square_catalog_object_id": "VAR-123"}
    snap["lines"][0]["modifiers"][0]["pos_refs"] = {
        "square_catalog_object_id": "MOD-9"}
    order = sq.build_square_order(snap, "L-1")
    li = order["line_items"][0]
    check("the item carries its variation id",
          li.get("catalog_object_id") == "VAR-123", str(li.get("catalog_object_id")))
    check("the modifier carries its catalog id",
          li["modifiers"][0].get("catalog_object_id") == "MOD-9")
    check("and the price is still sent so it cannot silently drift",
          "base_price_money" in li)


def t_square_totals_match_what_lily_read_out() -> None:
    """We cannot send totals — Square computes them — so the inputs must be
    right: unit price x quantity plus modifiers, and our tax rate."""
    store, cfg, oid, code, snap, _ = _store_with_order(qty=2)
    order = sq.build_square_order(snap, "L-1", tax_rate_bps=cfg.tax_rate_bps)
    computed = 0
    for li, src in zip(order["line_items"], snap["lines"]):
        qty = int(li["quantity"])
        unit = li["base_price_money"]["amount"]
        mods = sum(m["base_price_money"]["amount"] * int(m.get("quantity", 1))
                   for m in li.get("modifiers", []))
        computed += (unit + mods) * qty
    check("line totals reconstruct our subtotal",
          computed == snap["subtotal_cents"],
          f"square {computed} vs ours {snap['subtotal_cents']}")


def _square_subtotal(order: Dict[str, Any]) -> int:
    total = 0
    for li in order["line_items"]:
        mods = sum(m["base_price_money"]["amount"] * int(m.get("quantity", 1))
                   for m in li.get("modifiers", []))
        total += (li["base_price_money"]["amount"] + mods) * int(li["quantity"])
    return total


def t_square_total_matches_with_paid_modifiers_on_every_menu() -> None:
    """Square ADDS modifier prices to the line's base price. The snapshot's
    unit price already includes them, so sending both made every order with a
    paid add-on 'differ from the quote' and revoked the checkout link."""
    checked = 0
    for path in sorted(MENUS.glob("*.yaml")):
        try:
            cfg = ms.load_yaml(path)
        except Exception:                             # noqa: BLE001
            continue
        for item in cfg.items:
            done = False
            for gid in item.modifier_group_ids:
                g = cfg.group(gid)
                if not g or g.informational:
                    continue
                for oid in g.option_ids:
                    if not (cfg.option(oid).price_for_size(None) or 0) > 0:
                        continue
                    e = OrderEngine(cfg)
                    line = e.add_line(item.id, quantity=2)
                    e.apply_option(line.line_id, gid, oid)
                    snap = e.to_normalized_order()
                    order = sq.build_square_order(
                        snap, "L-1", tax_rate_bps=cfg.tax_rate_bps)
                    check(f"{path.stem}: {item.id}+{oid} reconciles",
                          _square_subtotal(order) == snap["subtotal_cents"],
                          f"square {_square_subtotal(order)} vs "
                          f"ours {snap['subtotal_cents']}")
                    checked += 1
                    done = True
                    break
                if done:
                    break
            if done:
                break
    check("every menu with a paid option was exercised", checked >= 15,
          str(checked))


def t_square_total_matches_free_allowance_and_stored_snapshots() -> None:
    """A free allowance charges nothing, and a snapshot stored before
    charge_cents existed still reconciles through the legacy path."""
    store, cfg, oid, code, snap, _ = _store_with_order(qty=2)
    order = sq.build_square_order(snap, "L-1", tax_rate_bps=cfg.tax_rate_bps)
    check("current snapshot reconciles",
          _square_subtotal(order) == snap["subtotal_cents"])
    legacy = json.loads(json.dumps(snap))
    for line in legacy["lines"]:
        line.pop("unit_base_cents", None)
        for m in line["modifiers"]:
            m.pop("charge_cents", None)
    order = sq.build_square_order(legacy, "L-1", tax_rate_bps=cfg.tax_rate_bps)
    check("legacy snapshot (no charge_cents) still reconciles",
          _square_subtotal(order) == legacy["subtotal_cents"])


def main() -> int:
    for name, fn in sorted(globals().items()):
        if not name.startswith("t_"):
            continue
        try:
            fn()
        except Exception:                             # noqa: BLE001
            global _failed
            _failed += 1
            print(f"\n--- FAIL {name}")
            traceback.print_exc()
    print(f"\n{_passed} passed, {_failed} failed (Telnyx + Square bridges)")
    return 1 if _failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
