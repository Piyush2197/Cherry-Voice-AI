"""Turn what callers actually said into menu aliases — the correction flywheel.

Three sources, in confidence order:

1. **Corrections.** A ``no_match`` followed by a ``matched`` in the same
   session: the caller re-phrased until the engine understood. The phrase
   that failed plus the item that finally matched is the highest-confidence
   alias candidate there is — the caller proved both halves. The caller may
   also simply have changed their mind, so every suggestion still passes the
   owner before it becomes menu fact.
2. **Repeats.** Phrases that matched nothing and were never corrected
   in-session. These are questions for the owner ("what do your regulars
   mean when they say this?"), not suggestions with a target.
3. **Seeds.** A small, deliberately high-precision multilingual vocabulary
   (Spanish, transliterated Arabic) matched against item and modifier names —
   the Level-1 wedge from ``ENGINE_MOAT.md``. Loose translations are left out
   on purpose: a wrong alias matches the wrong dish, and ambiguity handling
   cannot repair a bad map.

The governing rule is the one the rest of the menu layer obeys: **an alias is
a fact the owner confirmed.** Nothing here writes to a menu on its own.
``report`` prints the worklist, ``patch`` writes a prunable YAML, and
``apply`` merges only what survived review — refusing collisions, and proving
the merged menu still passes the schema/lint gate before the file is replaced.

One honest limit: negation is engine work, not alias work. ``cebolla`` can be
an alias for Onion so the word *matches*, but "sin cebolla" is understood as
a removal only when the engine's negation layer learns the phrase. That is a
separate, deliberate change; this module does not sneak it in.
"""

from __future__ import annotations

import _ensure_deps  # noqa: F401  (re-runs under .venv, or says how to install, if PyYAML is missing)
import argparse
import json
import sys
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

from order_engine import normalize

# ---------------------------------------------------------------------------
# vocabulary


@dataclass(frozen=True)
class Seed:
    """phrase -> applies to items whose name contains one of `keywords`."""
    phrase: str
    keywords: Tuple[str, ...]
    language: str


# Kept small on purpose. Every entry must survive the question "would a
# wrong match here bill a customer for the wrong dish?" — vague translations
# (e.g. Arabic "lahm" for any meat) are excluded because they cannot.
SEEDS: Tuple[Seed, ...] = (
    # Spanish — proteins and staples callers use as the noun itself
    Seed("pollo", ("chicken",), "spanish"),
    Seed("carne", ("beef", "steak"), "spanish"),
    Seed("carne asada", ("steak",), "spanish"),
    Seed("camaron", ("shrimp",), "spanish"),
    Seed("camarones", ("shrimp",), "spanish"),
    Seed("pescado", ("fish",), "spanish"),
    Seed("queso", ("cheese",), "spanish"),
    # transliterated Arabic — dishes and proteins that ARE the menu names
    Seed("shawarma", ("shawarma",), "arabic"),
    Seed("falafel", ("falafel",), "arabic"),
    Seed("hummus", ("hummus",), "arabic"),
    Seed("shish tawook", ("tawook",), "arabic"),
    Seed("kabob", ("kabob", "kebab"), "arabic"),
    Seed("kibbeh", ("kibbeh", "kibbi"), "arabic"),
    # modifier-option nouns (matching only; negation is engine work)
    Seed("cebolla", ("onion",), "spanish"),
    Seed("tomate", ("tomato",), "spanish"),
    Seed("aguacate", ("avocado",), "spanish"),
    Seed("jalapeno", ("jalapeno", "jalapeño"), "spanish"),
)


# ---------------------------------------------------------------------------
# mining


@dataclass
class Correction:
    restaurant_id: str
    phrase: str
    item_id: str
    item_name: str
    sessions: int = 1

    @property
    def confident(self) -> bool:
        """The pair repeated across sessions — two callers, same re-phrasing."""
        return self.sessions >= 2


@dataclass
class Repeat:
    restaurant_id: str
    phrase: str
    count: int


def _phrase_ok(phrase: str) -> bool:
    """Reject junk before it can become a suggestion."""
    p = phrase.strip()
    if not p or len(p) < 3 or len(p) > 60:
        return False
    if p.isdigit():
        return False
    return any(ch.isalpha() for ch in p)


def mine_corrections(conn: Any) -> List[Correction]:
    """Same-session re-phrasings: no_match -> later matched, same tool.

    Uses the ``resolution`` log (schema migration 5). A correction is only
    counted within one session, so a caller who asked for pie, was refused,
    and ordered a burger yields a *suggestion* — never a fact.
    """
    rows = conn.execute(
        """SELECT r.session_id, r.restaurant_id, r.tool, r.kind, r.heard,
                  r.outcome, r.resolved_id, r.resolved_name, r.id
           FROM resolution r
           WHERE r.outcome IN ('no_match', 'matched')
           ORDER BY r.session_id, r.id"""
    ).fetchall()

    by_session: Dict[str, List[Any]] = defaultdict(list)
    for r in rows:
        by_session[r["session_id"]].append(r)

    pairs: Dict[Tuple[str, str, str], Correction] = {}
    for entries in by_session.values():
        misses = [e for e in entries if e["outcome"] == "no_match"]
        hits = [e for e in entries if e["outcome"] == "matched"
                and e["resolved_id"]]
        for miss in misses:
            if not _phrase_ok(miss["heard"]):
                continue
            # nearest later match for the same tool: the caller's retry
            later = [h for h in hits
                     if h["id"] > miss["id"] and h["tool"] == miss["tool"]
                     and normalize(h["heard"]) != normalize(miss["heard"])]
            if not later:
                continue
            hit = later[0]
            key = (miss["restaurant_id"], normalize(miss["heard"]),
                   hit["resolved_id"])
            if key in pairs:
                pairs[key].sessions += 1
            else:
                pairs[key] = Correction(
                    restaurant_id=miss["restaurant_id"],
                    phrase=miss["heard"].strip(),
                    item_id=hit["resolved_id"],
                    item_name=hit["resolved_name"] or hit["resolved_id"],
                )
    return sorted(pairs.values(),
                  key=lambda c: (-c.sessions, c.restaurant_id, c.phrase))


def mine_repeats(conn: Any, minimum: int = 2) -> List[Repeat]:
    """Phrases that keep missing, in every restaurant, most frequent first."""
    rows = conn.execute(
        """SELECT restaurant_id, heard, COUNT(*) AS n FROM resolution
           WHERE outcome='no_match'
           GROUP BY restaurant_id, lower(heard)
           HAVING n >= ? ORDER BY n DESC, heard""",
        (minimum,)).fetchall()
    return [Repeat(r["restaurant_id"], r["heard"].strip(), int(r["n"]))
            for r in rows if _phrase_ok(r["heard"])]


def seed_suggestions(doc: Dict[str, Any], max_targets: int = 3
                      ) -> Tuple[Dict[str, List[Tuple[str, str]]],
                                 Dict[str, int]]:
    """Match SEEDS against item and modifier names in one menu document.

    Returns ``(suggestions, broad)``. A seed that would land on more than
    ``max_targets`` rows is moved to ``broad`` (phrase -> row count) instead:
    on a menu with twenty-two chicken dishes, ``pollo`` is a question for a
    human, not an alias — the tool refuses to flood a menu with matches a
    wrong hit could bill for. Within the cap, several targets are fine: the
    engine then asks the caller which one, which is its designed behaviour.
    """
    rows: List[Tuple[str, str, Tuple[str, ...]]] = []
    for item in doc.get("items") or []:
        rows.append((item["id"], "item", tuple(
            normalize(item.get("name") or "").split())))
    for opt in doc.get("options") or []:
        rows.append((opt["id"], "option", tuple(
            normalize(opt.get("name") or "").split())))

    per_seed: Dict[str, List[str]] = defaultdict(list)
    languages = {s.phrase: s.language for s in SEEDS}
    for rid, _kind, tokens in rows:
        for seed in SEEDS:
            if set(tokens) & set(seed.keywords):
                per_seed[seed.phrase].append(rid)

    out: Dict[str, List[Tuple[str, str]]] = defaultdict(list)
    broad: Dict[str, int] = {}
    for phrase, targets in per_seed.items():
        if len(targets) > max_targets:
            broad[phrase] = len(targets)
            continue
        for rid in targets:
            out[rid].append((phrase, languages[phrase]))
    return dict(out), broad


# ---------------------------------------------------------------------------
# worklist assembly


@dataclass
class Worklist:
    restaurant_id: str
    corrections: List[Correction] = field(default_factory=list)
    repeats: List[Repeat] = field(default_factory=list)
    seeds: Dict[str, List[Tuple[str, str]]] = field(default_factory=dict)
    broad: Dict[str, int] = field(default_factory=dict)

    @property
    def empty(self) -> bool:
        return not (self.corrections or self.repeats or self.seeds
                    or self.broad)


def build_worklist(conn: Any, menu_docs: Dict[str, Dict[str, Any]],
                   restaurant_id: Optional[str] = None) -> List[Worklist]:
    ids = [restaurant_id] if restaurant_id else sorted(
        set(list(menu_docs) +
            [r["restaurant_id"] for r in conn.execute(
                "SELECT DISTINCT restaurant_id FROM resolution").fetchall()]))
    corrections = mine_corrections(conn)
    repeats = mine_repeats(conn)
    out = []
    for rid in ids:
        doc = menu_docs.get(rid)
        seeds: Dict[str, List[Tuple[str, str]]] = {}
        broad: Dict[str, int] = {}
        if doc:
            seeds, broad = seed_suggestions(doc)
        out.append(Worklist(
            restaurant_id=rid,
            corrections=[c for c in corrections if c.restaurant_id == rid],
            repeats=[r for r in repeats if r.restaurant_id == rid],
            seeds=seeds,
            broad=broad,
        ))
    return out


# ---------------------------------------------------------------------------
# patch + apply


def write_patch(worklists: Iterable[Worklist], path: Path,
                menu_files: Dict[str, Path]) -> int:
    """Write the prunable YAML. The human deletes what they reject."""
    lines = [
        "# Alias suggestions — PRUNE BEFORE APPLYING.",
        "# Delete any line you would not expect a caller of THIS restaurant",
        "# to say. Surviving lines become menu facts via `apply`.",
        "",
    ]
    count = 0
    lines.append("menus:")
    for w in worklists:
        if w.empty or not (w.corrections or w.seeds):
            continue
        menu = menu_files.get(w.restaurant_id)
        lines.append(f"  {w.restaurant_id}:"
                     + ("" if menu else "  # no menu file — cannot be applied"))
        items: Dict[str, List[str]] = defaultdict(list)
        for c in w.corrections:
            items[c.item_id].append(
                f"{c.phrase}    # correction x{c.sessions}"
                f"{'' if c.confident else ' — single occurrence, check with owner'}")
        for item_id, notes in items.items():
            lines.append(f"    items:")
            lines.append(f"      {item_id}:")
            for note in notes:
                lines.append(f"        - {note}")
                count += 1
        opts: Dict[str, List[str]] = defaultdict(list)
        for target, pairs in w.seeds.items():
            for phrase, language in pairs:
                opts[target].append(f"{phrase}    # seed: {language}")
        for opt_id, notes in opts.items():
            lines.append(f"    options:")
            lines.append(f"      {opt_id}:")
            for note in notes:
                lines.append(f"        - {note}")
                count += 1
        if not items and not opts:
            lines.append("    {}")
    lines.append("")
    lines.append("# Repeats (no target found — ask the owner what these mean):")
    any_repeat = False
    for w in worklists:
        for r in w.repeats:
            any_repeat = True
            lines.append(f"#   {w.restaurant_id}: \"{r.phrase}\" x{r.count}")
    if not any_repeat:
        lines.append("#   none")
    path.write_text("\n".join(lines) + "\n")
    return count


def apply_patch(patch_path: Path, menu_path: Path) -> Tuple[int, List[str]]:
    """Merge a pruned patch into one menu file. Returns (added, refusals).

    Refuses, with a reason, any alias that already exists on the target, or
    that collides with a *different* item's name or alias — a collision would
    manufacture ambiguity on purpose. Proves the merged menu still passes
    schema + lint before the file is written.
    """
    import yaml
    import menu_schema as ms
    from config_validator import lint_config

    patch = yaml.safe_load(patch_path.read_text()) or {}
    doc = yaml.safe_load(menu_path.read_text())
    if not isinstance(doc, dict) or "items" not in doc:
        raise SystemExit(f"{menu_path}: not a menu document")

    rid = (doc.get("restaurant") or {}).get("id")
    entry = (patch.get("menus") or {}).get(rid)
    if not entry:
        raise SystemExit(
            f"{menu_path}: patch has no entry for '{rid}'. "
            f"Patch ids must match the menu's restaurant id.")

    # the collision map: normalized phrase -> owner of that phrase
    def alias_targets(d: Dict[str, Any], kind: str) -> Dict[str, str]:
        targets: Dict[str, str] = {}
        for row in d.get(kind) or []:
            owner = row["id"]
            names = [row.get("name") or ""] + list(row.get("aliases") or [])
            for n in names:
                key = normalize(str(n))
                if key:
                    targets.setdefault(key, owner)
        return targets

    owners: Dict[str, str] = {}
    for kind in ("items", "options"):
        for k, v in alias_targets(doc, kind).items():
            owners.setdefault(k, v)

    added, refusals = 0, []
    for kind in ("items", "options"):
        rows = {r["id"]: r for r in doc.get(kind) or []}
        for target_id, phrases in (entry.get(kind) or {}).items():
            row = rows.get(target_id)
            if row is None:
                refusals.append(f"{target_id}: not in this menu")
                continue
            existing = {normalize(str(a))
                        for a in ([row.get("name") or ""] +
                                  list(row.get("aliases") or []))}
            for phrase in phrases or []:
                key = normalize(str(phrase))
                if not key or not _phrase_ok(str(phrase)):
                    refusals.append(f"{target_id}: '{phrase}' is not a usable alias")
                    continue
                if key in existing:
                    refusals.append(f"{target_id}: '{phrase}' already present")
                    continue
                if key in owners and owners[key] != target_id:
                    refusals.append(
                        f"{target_id}: '{phrase}' already belongs to "
                        f"{owners[key]} — two dishes cannot share a phrase")
                    continue
                row.setdefault("aliases", []).append(str(phrase).strip())
                owners[key] = target_id
                existing.add(key)
                added += 1

    # prove the merged menu still loads before touching the file
    problems = ms.validate_doc(doc)
    if problems:
        raise SystemExit("merged menu fails schema validation — "
                         "nothing written:\n  " + "\n  ".join(problems[:10]))
    cfg = ms.build_config(doc)
    errors = [f for f in lint_config(cfg) if f.level == "ERROR"]
    if errors:
        raise SystemExit("merged menu fails lint — nothing written:\n  "
                         + "\n  ".join(str(e) for e in errors[:10]))

    if added:
        # rewritten programmatically, like ingest does; comments are not kept
        menu_path.write_text(yaml.safe_dump(doc, sort_keys=False,
                                            allow_unicode=True))
    return added, refusals


# ---------------------------------------------------------------------------
# CLI


def _open_db(db_arg: Optional[str]):
    if db_arg:
        import sqlite3
        conn = sqlite3.connect(db_arg)
        conn.row_factory = sqlite3.Row
        return conn
    return None


def _load_menu_docs(menus_dir: Path) -> Tuple[Dict[str, Dict[str, Any]],
                                               Dict[str, Path]]:
    import yaml
    docs, files = {}, {}
    for path in sorted(menus_dir.glob("*.yaml")):
        try:
            doc = yaml.safe_load(path.read_text())
        except Exception:
            continue
        if not isinstance(doc, dict):
            continue
        rid = (doc.get("restaurant") or {}).get("id")
        if rid:
            docs[rid] = doc
            files[rid] = path
    return docs, files


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(
        prog="alias_mining.py",
        description="Mine caller corrections into menu-alias suggestions "
                    "(owner-confirmed before they become menu fact).")
    p.add_argument("--db", help="cherry database with resolution rows")
    p.add_argument("--menus", default="menus", help="menus directory")
    p.add_argument("--restaurant", help="limit to one restaurant id")
    p.add_argument("--json", action="store_true", help="machine-readable")
    p.add_argument("--patch-out", type=Path,
                   help="write a prunable YAML patch instead of printing")
    p.add_argument("--apply", type=Path, help="apply a pruned patch file")
    p.add_argument("--menu", type=Path,
                   help="menu file for --apply (or single menu to report on)")
    args = p.parse_args(argv)

    if args.apply:
        if not args.menu:
            p.error("--apply needs --menu menus/<slug>.yaml")
        added, refusals = apply_patch(args.apply, args.menu)
        print(f"applied {added} alias(es) to {args.menu}")
        for r in refusals:
            print(f"  refused: {r}")
        print("run: python3 cherry.py check", args.menu)
        return 0 if added or not refusals else 1

    conn = _open_db(args.db)
    if conn is None:
        print("no --db given: reporting seed suggestions only "
              "(corrections need call history)")
        docs = {}
        files = {}
        if args.menu:
            import yaml
            doc = yaml.safe_load(args.menu.read_text())
            rid = (doc.get("restaurant") or {}).get("id")
            docs[rid] = doc
            files[rid] = args.menu
        else:
            docs, files = _load_menu_docs(Path(args.menus))
        worklists = build_worklist(_EmptyConn(), docs, args.restaurant)
    else:
        docs, files = _load_menu_docs(Path(args.menus))
        worklists = build_worklist(conn, docs, args.restaurant)
        if args.menu:  # single-menu focus
            import yaml
            doc = yaml.safe_load(args.menu.read_text())
            rid = (doc.get("restaurant") or {}).get("id")
            for w in worklists:
                if w.restaurant_id == rid:
                    w.seeds, w.broad = seed_suggestions(doc)
                else:
                    w.seeds, w.broad = {}, {}

    if args.patch_out:
        n = write_patch(worklists, args.patch_out, files)
        print(f"{n} suggestion(s) written to {args.patch_out}")
        print("prune it, then: python3 alias_mining.py --apply "
              f"{args.patch_out} --menu <menu.yaml>")
        return 0

    if args.json:
        def _w(w: Worklist) -> Dict[str, Any]:
            return {
                "restaurant_id": w.restaurant_id,
                "corrections": [
                    {"phrase": c.phrase, "item_id": c.item_id,
                     "item_name": c.item_name, "sessions": c.sessions,
                     "confident": c.confident}
                    for c in w.corrections],
                "repeats": [{"phrase": r.phrase, "count": r.count}
                            for r in w.repeats],
                "seeds": {k: [{"phrase": p, "language": l} for p, l in v]
                          for k, v in w.seeds.items()},
                "too_broad": [{"phrase": p, "matches": n}
                              for p, n in sorted(w.broad.items())],
            }
        print(json.dumps([_w(w) for w in worklists], indent=2))
        return 0

    for w in worklists:
        if w.empty:
            continue
        print(f"{w.restaurant_id}")
        for c in w.corrections:
            mark = "confident" if c.confident else "single occurrence"
            print(f"  correction  \"{c.phrase}\" -> {c.item_name}  "
                  f"(x{c.sessions}, {mark})")
        for r in w.repeats:
            print(f"  repeat      \"{r.phrase}\" x{r.count} — "
                  f"ask the owner what this means")
        for phrase, n in sorted(w.broad.items()):
            print(f"  too broad   \"{phrase}\" would match {n} dishes on "
                  f"this menu — not suggested; ask the owner which one "
                  f"they mean")
        if w.seeds:
            multi: Dict[str, List[str]] = defaultdict(list)
            item_ids = {i["id"] for i in (docs.get(w.restaurant_id)
                                          or {}).get("items") or []}
            for target, pairs in w.seeds.items():
                kind = "item" if target in item_ids else "option"
                for phrase, language in pairs:
                    multi[phrase].append(f"{kind} {target}")
            for phrase, targets in multi.items():
                note = ""
                if len(targets) > 1:
                    note = ("  [several dishes match this phrase — the "
                            "engine will ask the caller which one]")
                print(f"  seed        \"{phrase}\" -> "
                      f"{', '.join(targets)}{note}")
    print("\nNothing is written automatically: prune a patch and apply it, "
          "or put confirmed phrases in the menu's aliases by hand.")
    return 0


class _EmptyConn:
    """Lets build_worklist run with no database (seeds only)."""

    def execute(self, *_a, **_k):
        class _Result:
            def fetchall(self_inner):
                return []
        return _Result()


if __name__ == "__main__":
    raise SystemExit(main())
