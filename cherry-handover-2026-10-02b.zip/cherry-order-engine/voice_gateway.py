#!/usr/bin/env python3
"""HTTP call-lifecycle adapter between a SIP voice worker and Cherry.

The SIP/media worker owns speech recognition, LLM tool selection, and TTS.
It calls this service for each call event and speaks ``say`` exactly. Telnyx
Call Control transfers are available when the worker supplies its real
``call_control_id``. This service does not pretend to terminate SIP or RTP.
"""

from __future__ import annotations

import _ensure_deps  # noqa: F401  (re-runs under .venv, or says how to install, if PyYAML is missing)
import argparse
import asyncio
import hmac
import json
import os
import re
from http.server import BaseHTTPRequestHandler
from typing import Any, Dict
from urllib.parse import unquote, urlparse

from pilot_deploy import load_manifest
from telnyx_voice import TelnyxCallTransfer, routes_from_manifest
from host_voice import CALL_POLICY
from voice.inworld_bridge import CherryBridge, SYSTEM_PROMPT
from bounded_http import BoundedThreadingHTTPServer
from inworld_adapter import (Dialect, InworldAdapter, NO_ROUTE_SAY, RETRY_SAY,
                             normalize_number)

_E164 = re.compile(r"^\+[1-9][0-9]{7,14}$")
#: Spoken with a 502 so the worker is never left with nothing to say.
UNAVAILABLE_SAY = ("I'm having trouble with our ordering system. Let me "
                   "connect you with the restaurant.")
_TOOL = re.compile(r"^/v1/voice/calls/([^/]+)/tools/([a-z][a-z0-9_]*)$")
_ACTION = re.compile(r"^/v1/voice/calls/([^/]+)/(finish|abandon|handoff)$")


class Gateway:
    def __init__(self, bridge: CherryBridge, routes: Dict[str, str],
                 voice_key: str, dialect=None) -> None:
        if not voice_key:
            raise ValueError("CHERRY_VOICE_KEY is required")
        self.bridge = bridge
        self.routes = dict(routes)
        self.voice_key = voice_key
        # Inworld posts whole call events here; the adapter translates them
        # into the bridge calls the endpoints above already serve. One voice
        # service, so there is only one place to point a provider at.
        self.adapter = InworldAdapter(bridge, dialect=dialect)

    async def dispatch(self, method: str, path: str, body: dict) -> tuple[int, dict]:
        if method == "GET" and path == "/v1/voice/tools":
            return 200, {"tools": await self.bridge.tool_schemas(),
                         "system_prompt": SYSTEM_PROMPT,
                         "call_policy": CALL_POLICY}
        if method != "POST":
            return 404, {"error": "not found"}
        if path == "/v1/inworld/events":
            # Never 500 on a bad event: the reply says which event was refused
            # so a developer can fix the dialect from the response alone.
            return 200, await self.adapter.handle_payload(body)
        if not isinstance(body, dict):
            return 400, {"error": "request body must be an object",
                         "say": RETRY_SAY}
        if path == "/v1/voice/calls":
            call_id = body.get("call_control_id")
            dialled = normalize_number(body.get("to"))
            if not isinstance(call_id, str) or not call_id or \
                    dialled not in self.routes:
                return 400, {"error": "call_control_id and configured to number are required"}
            # A withheld or malformed caller ID ("anonymous", "private") must
            # not stop the call: the caller is simply unknown. Refusing it
            # would leave them in silence and unable to be transferred.
            caller = normalize_number(body.get("from"))
            return 200, {"say": await self.bridge.start(
                call_id, dialled=dialled, caller=caller)}
        match = _TOOL.fullmatch(path)
        if match:
            call_id, tool = unquote(match.group(1)), match.group(2)
            if not call_id:
                return 400, {"error": "invalid tool request"}
            return 200, {"say": await self.bridge.handle_tool_call(call_id, tool, body)}
        match = _ACTION.fullmatch(path)
        if not match:
            return 404, {"error": "not found"}
        call_id, action = unquote(match.group(1)), match.group(2)
        if not call_id:
            return 400, {"error": "call_control_id is required"}
        if action == "finish":
            name = body.get("customer_name") or ""
            if not isinstance(name, str):
                return 400, {"error": "customer_name must be text"}
            return 200, {"say": await self.bridge.finish(call_id, name)}
        if action == "abandon":
            await self.bridge.abandon(call_id, str(body.get("reason", "caller_hung_up")))
            return 200, {"ok": True}
        try:
            hint = normalize_number(body.get("to"))
            say = await (self.bridge.request_handoff(call_id, dialled=hint)
                         if hint else self.bridge.request_handoff(call_id))
            return 200, {"say": say}
        except LookupError:
            # This process has no record of the call (it restarted mid-call)
            # and was not told the dialled number. Say something usable.
            return 200, {"say": NO_ROUTE_SAY, "handoff": False}


def handler_for(gateway: Gateway):
    class Handler(BaseHTTPRequestHandler):
        def _send(self, status: int, payload: dict) -> None:
            raw = json.dumps(payload).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

        def _handle(self) -> None:
            # Compare bytes: str comparison raises on a non-ASCII header and
            # would kill the request with no response at all.
            supplied = self.headers.get("X-Voice-Key", "").encode("utf-8", "replace")
            if not hmac.compare_digest(supplied,
                                       gateway.voice_key.encode("utf-8")):
                self._send(401, {"error": "unauthorized"})
                return
            if self.command == "POST":
                try:
                    size = int(self.headers.get("Content-Length", "0"))
                    if size < 0 or size > 65536:
                        raise ValueError("request too large")
                    raw = self.rfile.read(size) if size else b""
                    # An action such as /finish or /abandon may legitimately
                    # arrive with no body at all.
                    body = json.loads(raw) if raw.strip() else {}
                    # A bare list is a batch of events, valid only there.
                    if not isinstance(body, (dict, list)):
                        raise ValueError("request body must be an object")
                except (ValueError, json.JSONDecodeError):
                    self._send(400, {"error": "invalid JSON body",
                                     "say": RETRY_SAY})
                    return
            else:
                body = {}
            try:
                status, payload = asyncio.run(gateway.dispatch(
                    self.command, urlparse(self.path).path, body))
            except Exception:
                self._send(502, {"error": "voice backend unavailable",
                                 "say": UNAVAILABLE_SAY})
                return
            self._send(status, payload)

        def do_GET(self) -> None:
            self._handle()

        def do_POST(self) -> None:
            self._handle()

    return Handler


class CherryHandoffAudit:
    """Record each transfer outcome in Cherry's event log so the operations
    monitor can page on a failed one. The gateway has no database of its own.
    Best effort: an audit failure must never block or delay a human transfer."""

    def __init__(self, base_url: str, api_key: str, timeout: float = 3.0) -> None:
        self.base_url, self.api_key, self.timeout = base_url.rstrip("/"), api_key, timeout

    def __call__(self, *, call_control_id: str, dialled: str, fallback: str,
                 status: str, reason: str, detail: str = "") -> None:
        import urllib.parse
        import urllib.request
        body = json.dumps({"dialled": dialled, "fallback": fallback,
                           "status": status, "reason": reason[:200],
                           "detail": detail[:500]}).encode()
        request = urllib.request.Request(
            f"{self.base_url}/v1/calls/{urllib.parse.quote(call_control_id, safe='')}"
            "/handoff-outcome", data=body, method="POST",
            headers={"X-Cherry-Key": self.api_key,
                     "Content-Type": "application/json"})
        with urllib.request.urlopen(request, timeout=self.timeout):
            pass


def build_gateway(env: dict[str, str] | None = None) -> Gateway:
    env = dict(os.environ if env is None else env)
    for key in ("CHERRY_BASE_URL", "CHERRY_API_KEY", "CHERRY_VOICE_KEY"):
        if not env.get(key):
            raise ValueError(f"missing_env:{key}")
    base_url = env["CHERRY_BASE_URL"]
    if not (base_url.startswith("https://") or
            base_url.startswith("http://127.0.0.1:") or
            base_url.startswith("http://localhost:")):
        raise ValueError("CHERRY_BASE_URL must use HTTPS outside localhost")
    routes = routes_from_manifest(load_manifest(), env, require_direct=True)
    if not routes:
        raise ValueError("configure at least one CHERRY_INBOUND_* number")
    transfer = TelnyxCallTransfer(
        routes, api_key=env.get("TELNYX_API_KEY"),
        audit=CherryHandoffAudit(base_url, env["CHERRY_API_KEY"]))
    bridge = CherryBridge(base_url, env["CHERRY_API_KEY"],
                          handoff=transfer)
    return Gateway(bridge, routes, env.get("CHERRY_VOICE_KEY", ""),
                   dialect=Dialect.from_env(env))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8090)
    args = parser.parse_args()
    gateway = build_gateway()
    server = BoundedThreadingHTTPServer(("0.0.0.0", args.port), handler_for(gateway))
    server.serve_forever()


if __name__ == "__main__":
    main()
