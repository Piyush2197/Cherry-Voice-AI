import { NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'

// Who is signed in. The dashboard (a client component) asks here instead of
// importing server-only code into the browser bundle.
export async function GET() {
  const user = await getCurrentUser()
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }
  return NextResponse.json({ user })
}
