# Reference run of the point-in-time recovery recipe on a throwaway local cluster (run as the postgres user).
# Uses /tmp/pitr_test and port 5544. Not for production.
set -e
B=/usr/lib/postgresql/16/bin; T=/tmp/pitr_test
$B/initdb -D $T/data -A trust >/dev/null
cat >> $T/data/postgresql.conf <<CONF
port=5544
listen_addresses=''
unix_socket_directories='$T'
wal_level=replica
archive_mode=on
archive_command='test ! -f $T/wal/%f && cp %p $T/wal/%f'
archive_timeout=300
CONF
$B/pg_ctl -D $T/data -l $T/log -w start >/dev/null
P="$B/psql -h $T -p 5544 -Atq postgres"
$P -c "create table orders(n int)"; $P -c "insert into orders select generate_series(1,100)"
$B/pg_basebackup -h $T -p 5544 -D $T/base/b1 -Ft -z -Xs
$P -c "insert into orders select generate_series(101,200)"
$P -c "select pg_switch_wal()" >/dev/null
sleep 2
TARGET=$($P -c "select now()")
sleep 2
$P -c "insert into orders select generate_series(201,300)"
$P -c "select pg_switch_wal()" >/dev/null
sleep 2
echo "target=$TARGET count_now=$($P -c 'select count(*) from orders')"
$B/pg_ctl -D $T/data -m fast stop >/dev/null
# restore
mkdir -p $T/restore; chmod 700 $T/restore
tar -xzf $T/base/b1/base.tar.gz -C $T/restore
mkdir -p $T/restore/pg_wal; tar -xzf $T/base/b1/pg_wal.tar.gz -C $T/restore/pg_wal
touch $T/restore/recovery.signal
cat >> $T/restore/postgresql.conf <<CONF
restore_command='cp $T/wal/%f %p'
recovery_target_time='$TARGET'
recovery_target_action='promote'
archive_mode=off
CONF
$B/pg_ctl -D $T/restore -l $T/rlog -w start >/dev/null
echo "restored count=$($B/psql -h $T -p 5544 -Atq postgres -c 'select count(*) from orders')"
$B/pg_ctl -D $T/restore -m fast stop >/dev/null
