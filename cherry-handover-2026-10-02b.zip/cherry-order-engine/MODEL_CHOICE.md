# Choosing the model behind Lily

Researched 2026-10-02 from Google's own documentation (links at the end). Prices
and behaviour change often; **re-check before committing**, and put verified new
prices in a rates file for `call_cost.py --rates` rather than editing code.

## The decision, in short

Keep today's stack (Telnyx + Inworld STT + Gemma + Inworld TTS) for launch.
Measure Gemini 3.8 Live against it with `model_bakeoff.py` and **one real call
with an invoice** before moving, because:

* it is **not a free swap on cost**: roughly **2.4–5.1 cents per call** against
  **1.4 cents today** (about $36–$78 per location per month against ~$21, on a
  $299 plan — 12–26% of the plan against 7%). The spread is things Google does
  not publish (below);
* it is **not a drop-in swap on architecture**: Cherry relies on the voice
  speaking the engine's exact words, and a native-audio model speaks its own;
* the quality gain **for taking orders** is not documented anywhere I could find
  — the documented differences are structural, not accuracy figures.

The engine is built so you can change your mind cheaply: tools are plain JSON
(`tools.json`), the personality lives in the engine's own lines (`host_voice.py`),
and `model_bakeoff.py` scores any model on the same scripted calls.

## What is verified about Gemini 3.8 Live vs 2.5 Flash native audio

| | Gemini 2.5 Flash native audio | Gemini 3.8 Live |
|---|---|---|
| Status | **Preview; access limited to prior active users; Google recommends migrating** | **Generally available, released 2026-09-15** (`gemini-3.8-live`) |
| Variants | one | default (`gemini-3.8-live`) and **Extended Thinking** (configurable background reasoning: `low`/`medium`/`high`) |
| Reasoning | described as "native audio reasoning" | **interleaved reasoning** in the default model |
| Function calling | asynchronous tool calls allowed | **asynchronous by default** (`NON_BLOCKING`); `BLOCKING` available per tool |
| Mid-session updates | not stated | `send_client_content` supported **throughout the session** (the release notes call it "full session client content updates"): push the cart, the clock, a menu change |
| Languages | not stated | **99** languages in the Live API |
| Context | not stated | 128k tokens (native-audio models); audio-only sessions capped at **15 minutes** |
| Transcription | yes | input and output audio transcription configurable |
| Price: audio in / out | $3.00 / $12.00 per 1M tokens | $3.00 / $12.00 per 1M tokens |
| Price: text in / out | $0.50 / $2.00 | $0.75 / $4.50 |

Audio is billed at **25 tokens a second** (about $0.005/min in, $0.018/min out).
A Google billing reply on the developer forum says **silent input audio is billed
like speech** (stated for 2.5; assume the same for 3.8) — so a phone call pays for
its whole length, not just the words.

Two documented behaviours of 3.8 matter more to Cherry than any benchmark:

1. **Non-blocking tool calls are the default.** The model keeps talking while a
   tool runs. Cherry needs the opposite: say the tool's text, verbatim. Every
   tool must be declared `behavior: BLOCKING` — and Google notes a blocking call
   is **cancelled if new input arrives** while it runs, so a caller who talks over
   Lily can leave the engine and the model disagreeing about the cart.
2. **Redundant back-to-back tool calls.** Google's migration notes say 3.8
   "sometimes makes redundant back-to-back function calls … sweeping two to five
   times" when a tool returns nothing. For an `add_item` that can mean three
   dishes. They recommend explicit status codes, retryable flags and a prompt
   that forbids silent retries.

## What Cherry already does about it (model-independent)

* every failure reply carries `retryable` (false unless the arguments were
  malformed), and the prompt says to call each tool **once** per request;
* the server answers an **identical cart-changing call within 2.5 s from the first
  result** instead of adding the dish again (and does not journal it, so a
  restart replay cannot add it either);
* `GET /v1/voice/tools` returns a `call_policy` with `tool_behavior: BLOCKING`,
  idle prompts, a call-length cap and goodbye lines for whatever voice worker you
  run — silence and runaway calls are paid for on every per-minute provider;
* the engine's own lines carry the warmth, so the personality survives a model change;
* "verbatim" can still be audited on a native-audio model: turn on **output audio
  transcription** and compare it with the engine's text (`verbatim_audit`).

## Cost, per call and per location (`python3 call_cost.py compare`)

One measured call: 90 s, Lily speaks 246 characters (~16 s), 8 tool turns,
~3,900 tokens of prompt and tools. **LOW** assumes the best reading of everything
unpublished, **HIGH** the worst.

| | per call | per location per month (50 calls/day) | share of the $299 plan |
|---|---|---|---|
| Today (Inworld cascade) | $0.0138 | $21 | 7% |
| Gemini 3.8 Live | $0.0239 – $0.0510 | $36 – $78 | 12% – 26% |
| Gemini 2.5 native audio (retiring) | $0.0222 – $0.0424 | $34 – $65 | 11% – 22% |

What separates LOW from HIGH — **not published; run one call and read the invoice**:

* is the accumulated context (our ~3,900-token prompt and tools) **re-billed on
  every tool turn**? (the single biggest swing)
* how are 3.8's interleaved **reasoning tokens** billed?
* 25 or 32 audio tokens a second?
* a native-audio model speaks **its own words**, so output audio can exceed our
  verbatim text.

## What is better in 3.8 for a restaurant, honestly

Documented: it is the supported, GA model (2.5 is being retired); it reasons while
it speaks; it accepts mid-call context updates (useful for pushing the cart or a
sold-out dish into the session); it covers 99 languages end to end — a real
advantage for callers who switch languages, where Cherry's phrasebook covers
three. **Not documented anywhere I could find: any measurement of order accuracy,
latency on a phone line, or behaviour on menus.** Forum reports about the 3.1
preview — first audio taking 16–26 s on one project, a pronunciation regression
in Polish versus 2.5 — are anecdotal but show why you measure a model version
before trusting it.

## How to decide

1. Run `model_bakeoff.py run --brain openai …` (any OpenAI-compatible endpoint;
   Gemini's API has an OpenAI-compatible mode — confirm it for the exact model you test) for each candidate **brain** on the 25 scripted calls. For Gemini, with the key in your shell (never in a file in the repo):

   ```bash
   export GEMINI_API_KEY=…            # yours; the harness reads it by name and never prints it
   python3 model_bakeoff.py run --brain openai --api-key-env GEMINI_API_KEY \
       --base-url https://generativelanguage.googleapis.com/v1beta/openai \
       --model <a Gemini text model id> --price-in <$/1M in> --price-out <$/1M out> --out gemini.json
   ```

   This scores cart accuracy, retries, verbatim speech, tokens and cost — it needs
   no phone line. (It tests the *text* brain; a native-audio model's speech
   quality has to be judged by ear on a real call.)
2. Make **one real call on each candidate** and read the invoice. Put the true
   per-minute numbers in a rates file and re-run `call_cost.py compare --rates`.
   Run `call_review.py --latest --spoken …` on each call: it shows whether the
   model called the engine's tools as the prompt says, and whether it spoke the
   engine's words.
3. Switch only if the model wins on cart accuracy or on callers it currently
   fails (other languages, noisy lines) **and** the cost fits the margin you want.
   Revisit when Gemini publishes the context-billing rule, or when a model's price
   falls.

## Sources

* Pricing: https://ai.google.dev/gemini-api/docs/pricing (page dated 2026-10-01 UTC)
* Models: https://ai.google.dev/gemini-api/docs/models
* Release notes: https://ai.google.dev/gemini-api/docs/changelog
* Live API capabilities (function calling, languages, limits): https://ai.google.dev/gemini-api/docs/live-api/capabilities
* Migration from 2.5 to 3.8: https://docs.cloud.google.com/gemini-enterprise-agent-platform/models/live-api/migrate-from-gemini-2-5-to-gemini-3-8-live
* Silent-audio billing: https://discuss.ai.google.dev/t/live-api-pricing-audio-tokens-second-silent-audio/92653
