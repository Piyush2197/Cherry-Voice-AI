# Developer checklist: everything before the POS API work (2026-09-28)

Built from every earlier list: `TASKS.md`, `DEVELOPER_HANDOFF.md`, `DEPLOYMENT_STATUS.md`,
`GAPS_2026-09-28.md`, and the Project docs (`START-HERE-developer-handoff`, `DEV-START-HERE-bun-n-run-pilot`,
`developer-handoff-integration-contract`, `whats-left-and-next-tasks`, `status-2026-09-24-handover-audit`).
Runbook commands live in `DEVELOPER_HANDOFF.md`; database commands in `DATABASE.md`.
**Ready-made files for every server step below are in `deploy/` (start at `deploy/README.md`).** They are syntax-checked, and the Postgres recovery recipe was run for real; nothing was run on Hostinger itself.

**Out of this list, by decision:** Bun N Run / Toast (parked), the dashboard (developer has built it),
subscription invoicing (Zoho). Juan Miguel's stays on hold (menu incomplete).

**"POS API work" starts at Phase 6.** Phases 0-5 are the platform under it. The Square checkout code
is already written and tested; what is missing is proof against Square itself.

## What can start today, and what waits on someone else

Start now, nothing to wait for (this is several days of work): Phases 0, 1, 4, the Telnyx numbers and 10DLC in Phase 2, and the Square developer app plus sandbox proof in Phase 6.
Waiting on Inworld: Phase 3 only (SIP access and their event format). Owner decisions are all recorded (2026-09-29, see `OWNER_DECISIONS_2026-09-29.md`): Pink Garlic is signed off on Square, the direct staff line is each restaurant's existing line, Bun N Run waits on Toast API access, Tamago waits on an EPIPay integration. Everything else is the developer's alone.

## Phase 0. Database server (Hostinger)

Hostinger's PostgreSQL is self-managed Postgres in Docker on a VPS, not a managed service.
Its included backups are weekly snapshots, which are not point-in-time recovery. So the developer owns:

- [ ] Provision the VPS. Install PostgreSQL 16 (Cherry was proven on 16). Port 5432 closed to the internet; only the Cherry server and jobs reach it.
- [ ] Create the `cherry` database and a least-privilege role (not superuser). Put the URL in the secret store, not in git.
- [ ] `production_db.py bootstrap` (schema version 6, 22 tables), then `production_db.py verify`.
- [ ] Point-in-time recovery: `deploy/postgres/` has WAL archiving, weekly base backup and off-site sync (the recipe was proven on Postgres 16). Set the off-site storage; prune the local WAL archive or monitor disk. Weekly snapshots alone are not enough for an order database.
- [ ] Nightly `production_db.py backup` copied off the VPS.
- [ ] Run a real `restore-drill` into a database named `*restore*` or `*drill*`, and the point-in-time drill in `deploy/postgres/RESTORE_PITR.md`. Keep the output as evidence.

## Phase 1. Server, TLS, secrets

- [ ] Host `server.py` and `voice_gateway.py`. TLS in front of both (nginx or a load balancer). The Cherry API (`server.py`) is private; only the gateway and Telnyx/Square webhooks are public.
- [ ] Set `CHERRY_CHECKOUT_HANDOFF_ONLY=1` in BOTH the server and the job environments.
- [ ] Secrets: `CHERRY_SECRET_DIR` (chmod 700, not in git) or a secret manager. Set `CHERRY_OAUTH_STATE_SECRET`, `X-Cherry-Key`, `X-Voice-Key`.
- [ ] Scoped API principals for `/ops` and any dashboard calls (`access_control.py`).

## Phase 2. Telnyx and phones

- [ ] One Telnyx DID per location; messaging profile on it.
- [ ] 10DLC: brand approved, campaign `MNO_PROVISIONED`, and each number ASSIGNED to the campaign. Buying a number is not enough.
- [ ] Signed SMS webhook to `/v1/webhooks/telnyx/sms`; set `TELNYX_PUBLIC_KEY`. Prove a delivered checkout SMS and a STOP reply.
- [ ] Direct staff line per location — DECIDED: each restaurant's existing phone line (owner, 2026-09-29). Set `CHERRY_REQUIRE_DIRECT_FALLBACK=1` and `CHERRY_DIRECT_FALLBACK_<LOCATION>` to that number. It must not forward into Cherry (must differ from the published number and every DID), or a transfer loops — verify once in a live transfer.
- [ ] Telnyx failover to the restaurant's own line on no-answer or failure, set at the carrier. Do this before any restaurant goes live.

## Phase 3. Inworld (waiting on SIP access)

- [ ] Get the four answers: transfer path (REFER), DID and caller ID passed through, the real Telnyx `call_control_id`, and whether text can go straight to TTS.
- [ ] Build the Inworld event adapter calling `voice_gateway.py` on start, tool, finish, abandon, handoff. Contract is in `DEVELOPER_HANDOFF.md` §8.
- [ ] TTS language handling per `DEVELOPER_HANDOFF.md` §8a: pass the caller's language on every TTS request (empty means TTS guesses toward English — test it, it takes five minutes).
- [ ] Lily's voice: custom bilingual clone (5–15 s clean audio + written consent from the speaker) or Inworld voice localization judged by a native speaker. Never ship the default voice for Spanish/Arabic callers.
- [ ] Prove `say` is spoken verbatim (`verbatim_audit`).
- [ ] Prove a warm transfer to the direct line, and that a transfer failure tells the caller the number.

## Phase 4. Jobs and alerts

- [ ] Put every job in `DEVELOPER_HANDOFF.md` §9b on the scheduler: Square token refresh (daily), nightly catalog, alerts, reconciliation, backup.
- [ ] Set `CHERRY_ALERT_PHONE`; confirm a real test page reaches the owner's handset over the 10DLC number.

## Phase 5. Proof before traffic

- [ ] Staging load run and rollback drill; keep the evidence per location.
- [ ] Menu, tax, hours, modifiers and fallback reviewed with each owner (Pink Garlic Oak Park and Allen Park prices signed off 2026-09-29; still confirm current menu/tax/hours at the counter before the acceptance call).
- [ ] Controlled direct-DID call, then a published-number forwarding call, with the owner.

## Phase 6. Gate to start the POS API work

Do not start until these are ticked:

- [ ] Phases 0-4 done; the restore drill has passed.
- [ ] Square developer app registered; redirect URL `https://<host>/v1/oauth/square/callback`; `SQUARE_OAUTH_CLIENT_ID/SECRET` set.
- [ ] Sandbox proof: OAuth round trip, scopes in `SQUARE_SCOPES` accepted, one itemized checkout, one payment visible in Square, no duplicate Cherry ticket. (This proof is the first step of the POS API work, and it settles whether the scopes are right.)

**Then the POS API order:** Square live per location (`pilot_deploy.py apply --sink square`, `verify`, `checkout-ready`) → Toast (parked until you decide Bun N Run's checkout) → Heartland (Juan Miguel's, on hold).

## Mine (code)

Done since the last version of this list: the resolution log (built, tested on SQLite and Postgres);
per-location plan storage and usage thresholds (below, 2026-09-29);
menu enrichment — the QR agent's prerequisite (below, 2026-09-30).

- [x] Per-location plan storage and usage thresholds — DONE 2026-09-29. `location_plan` table (schema v6), `cost_control.py set-plan --db … --restaurant <location> --plan small|medium|grande`. `plan_reviews` evaluates each location against its own allowance (Small 3,000 / Medium 5,000 / Grande 10,000 minutes a month); the ops monitor raises ONE warning per day when a location reaches its plan's daily figure (50 / 65 / 100 calls) — a usage signal, never a cutoff. The existing `plan-review` job and the alerts job pick both up unchanged.
- [x] Menu enrichment (`MENU_ENRICHMENT.md`) — DONE 2026-09-30. `description`, `allergens` and `dietary` now exist on items (and `description` on modifier options) with closed vocabularies, alias normalisation, rejection of ambiguous values (`nuts`), and contradiction errors that block a config (`vegan` + `milk`). The answer layer returns sentences, never booleans: a declared tag is stated, a missing tag is *"ask at the counter"* — absence of a claim is never a claim of absence. `python menu_enrichment.py report|check|vocabulary` gives the owner a worklist. **No facts were invented**: all 19 shipped menus are at zero declarations, which is the honest starting state. This clears the prerequisite the QR agent was waiting on; the QR agent itself is still sequenced behind the Square bridge and the first pilots.
- [ ] Fill the enrichment in per location with the owner — owner input, not code.
- [ ] Counter QR agent ("your second employee"): web chat on `channel='web'` reusing the session/tool API and the Square pay-link flow; on-screen read-back before payment; answers menu questions only from enriched menu data. Build AFTER the Square bridge and the first pilots. Prerequisite: menu enrichment (allergen/dietary/modifier data) — **built 2026-09-30**. Decision and rules in `QR_CHANNEL.md` (revision 2026-09-29).
- [ ] Inworld adapter, once their event format is known. Waiting on Inworld.
- [ ] Managed secret-manager adapter, only if the developer picks one (files in `CHERRY_SECRET_DIR` work now).

## Owner (you) — decided 2026-09-29, recorded in `OWNER_DECISIONS_2026-09-29.md`

- [x] Tamago Sushi Bowl POS identified: **EPIPay** (hosted web order, `epipay.com/tamagomi/en/WebOrder`, store code 1000). It stays `manual_fallback` — no Cherry checkout — until an EPIPay integration exists; it cannot take phone traffic before then. First developer question: does EPIPay expose an API at all?
- [x] Bun N Run: **waiting on the Toast account API access**; no Square account will be used. Parked until that arrives.
- [x] Remake/refund: no separate policy document. The owner's position: the itemized SMS payment link IS the check — the customer reviews and confirms the order before paying, then it is POS handover. Residual risk accepted: if the AI mishears and the customer still pays, the transcript is the arbiter; the restaurant-contract side of this is the owner's, not Cherry's.
- [x] Direct staff line: the restaurant's **existing phone line** — easy and cheap. Hard constraint unchanged: that number must not forward into Cherry (must differ from the published number and every DID), or a transfer loops.
- [x] Menu and price signoff: **Pink Garlic Oak Park and Allen Park signed off 2026-09-29**; owner confirms both are Square merchants, so authorize links can go out as soon as the Square app exists.
- [ ] Send each restaurant owner their `square_oauth.py authorize-url` link (blocked only on the developer's Phase 6 Square app).

**POS build order after the Phase 6 gate** (replaces the chat-only `POS_LANDSCAPE_2026-09-28.md`): Square live per location → Toast (Bun N Run, when API access arrives) → EPIPay (Tamago, feasibility unknown) → Heartland (Juan Miguel's, on hold for a complete menu). Clover: no merchant needs it today.

## Where the "resolution" data lives

There was no `resolution` table in any copy of the repo (earlier notes from 13-20 Sep said the schema had one; it did not).
It was never data to migrate: it is a log that live calls create. It is now built (schema v5): per caller phrase, what was heard,
the best candidate, score, runner-up, and matched / ambiguous / no match. It fills as real calls happen, in Postgres.
`store.unresolved(restaurant)` and `store.confusions(restaurant)` read it. The `turn` table still holds every utterance.
The matching itself lives in code (`order_engine.py` Matcher) and each restaurant's `menus/*.yaml` aliases; `pilot_deploy.py apply` puts
the menu into Postgres as a `menu_version` row.
