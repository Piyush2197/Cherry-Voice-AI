#!/usr/bin/env python3
"""Checks for operations metrics and actionable alert rules."""

from __future__ import annotations

import json
import traceback
from datetime import datetime, timedelta, timezone
from pathlib import Path

import menu_schema as ms
import ops_monitor as om
from order_engine import OrderEngine
from order_store import OrderStore


HERE = Path(__file__).resolve().parent
_passed = _failed = 0


def check(name, condition, detail=""):
    global _passed, _failed
    if condition:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


def fixture():
    store = OrderStore.sqlite()
    cfg = ms.load_yaml(HERE / "menus" / "tamago-sushi-bowl.yaml")
    store.upsert_restaurant(cfg.id, cfg.name, cfg.cuisine,
                            staff_phone="+13135550100",
                            inbound_phone="+13135550101", active=True)
    mv = store.publish_menu(cfg.id, (HERE / "menus" /
                            "tamago-sushi-bowl.yaml").read_text(),
                            item_count=len(cfg.items))
    return store, cfg, mv


def order(store, cfg, mv, session_id=None):
    engine = OrderEngine(cfg)
    engine.add_line("tg_edamame")
    return store.place_order(cfg.id, mv, engine.to_normalized_order(),
                             session_id=session_id)


def t_snapshot_reconciles_calls_orders_and_restaurants() -> None:
    store, cfg, mv = fixture()
    sid1 = store.start_session(cfg.id, mv, external_id="call-1")
    sid2 = store.start_session(cfg.id, mv, external_id="call-2")
    store.end_session(sid1, "completed")
    store.end_session(sid2, "no_order")
    order(store, cfg, mv, sid1)
    snapshot = om.operations_snapshot(store)
    check("snapshot counts two calls", snapshot["summary"]["calls"] == 2)
    check("snapshot counts one order", snapshot["summary"]["orders"] == 1)
    check("conversion is recomputed from its denominator",
          snapshot["summary"]["conversion_percent"] == 50.0)
    row = snapshot["by_restaurant"][0]
    check("restaurant rollup reconciles to summary",
          (row["calls"], row["orders"]) == (2, 1), str(row))


def t_customer_identifiers_never_enter_the_dashboard_feed() -> None:
    store, cfg, mv = fixture()
    sid = store.start_session(cfg.id, mv, external_id="secret-call-id",
                              caller_phone="+13135550999")
    order(store, cfg, mv, sid)
    payload = json.dumps(om.operations_snapshot(store))
    check("dashboard omits caller phone", "+13135550999" not in payload)
    check("dashboard omits external call id", "secret-call-id" not in payload)


def t_alerts_cover_delivery_payment_session_and_handoff() -> None:
    store, cfg, mv = fixture()
    now = datetime(2026, 9, 20, 18, 0, tzinfo=timezone.utc)
    old = (now - timedelta(hours=3)).isoformat(timespec="seconds")

    sid = store.start_session(cfg.id, mv, external_id="stuck-call")
    store.conn.execute("UPDATE session SET started_at=? WHERE id=?", (old, sid))
    oid1, _ = order(store, cfg, mv)
    store.record_delivery(oid1, "manual", "failed",
                          error_kind="connection", error_detail="offline")
    oid2, _ = order(store, cfg, mv)
    store.record_delivery(oid2, "manual", "sent")
    store.conn.execute("UPDATE order_delivery SET sent_at=? WHERE order_id=?",
                       (old, oid2))
    oid3, _ = order(store, cfg, mv)
    with store.tx() as conn:
        conn.execute("""
            INSERT INTO payment (order_id, method, status, amount_cents, updated_at)
            VALUES (?, 'pay_link', 'link_pending', 530, ?)
        """, (oid3, old))
    store.log_event("voice.handoff_failed", restaurant_id=cfg.id,
                    detail={"reason": "provider rejected transfer"})
    store.log_sms("+13135550123", "ticket", "ticket",
                  restaurant_id=cfg.id, status="failed",
                  error_detail="carrier rejected")
    store.conn.commit()

    alerts = om.scan_alerts(store, now=now)
    categories = {a.category for a in alerts}
    check("all urgent operational categories alert",
          {"delivery", "payment", "call", "handoff", "sms"} <= categories,
          str([a.key for a in alerts]))
    check("critical conditions sort first",
          alerts and alerts[0].severity == "critical")
    check("alert keys are stable and unique",
          len({a.key for a in alerts}) == len(alerts))


def t_checkout_and_square_token_failures_page_the_owner() -> None:
    store, cfg, mv = fixture()
    now = datetime.now(timezone.utc)
    check("nothing failing means no checkout alert",
          not [a for a in om.scan_alerts(store, now=now) if a.category == "checkout"])
    store.log_event("payment.link_failed", restaurant_id=cfg.id, detail={})
    one = [a for a in om.scan_alerts(store, now=now) if a.category == "checkout"]
    check("one failed link is a high alert", len(one) == 1 and one[0].severity == "high", one)
    for _ in range(2):
        store.log_event("payment.no_provider", restaurant_id=cfg.id, detail={})
    three = [a for a in om.scan_alerts(store, now=now) if a.category == "checkout"]
    check("three in an hour is critical, still ONE alert per hour",
          len(three) == 1 and three[0].severity == "critical", three)
    check("the same hour gives the same key so it pages once",
          three[0].key == one[0].key)
    later = [a for a in om.scan_alerts(store, now=now + timedelta(hours=3))
             if a.category == "checkout"]
    check("old failures stop alerting", not later, later)

    store.log_event("square.oauth_refresh_failed", restaurant_id=cfg.id, detail={"error": "x"})
    stale = [a for a in om.scan_alerts(store, now=now) if a.key.startswith("square-token-refresh")]
    check("a failing token refresh is critical", len(stale) == 1 and stale[0].severity == "critical", stale)
    store.log_event("square.oauth_refreshed", restaurant_id=cfg.id, detail={})
    healed = [a for a in om.scan_alerts(store, now=now) if a.key.startswith("square-token-refresh")]
    check("a later successful refresh clears it", not healed, healed)


def t_no_activity_is_unknown_conversion_not_fake_zero() -> None:
    store, cfg, mv = fixture()
    snapshot = om.operations_snapshot(store)
    check("no calls remains a null conversion",
          snapshot["summary"]["conversion_percent"] is None)
    check("an idle healthy restaurant has no alerts", not snapshot["alerts"])


def t_paid_order_with_uncertain_handoff_pages_operator() -> None:
    store, cfg, mv = fixture()
    oid, _ = order(store, cfg, mv)
    now = datetime.now(timezone.utc)
    old = (now - timedelta(minutes=3)).isoformat(timespec="seconds")
    with store.tx() as conn:
        conn.execute("""INSERT INTO payment
            (order_id,method,status,amount_cents,settled_at,updated_at)
            VALUES (?,'pay_link','paid',530,?,?)""", (oid, old, old))
        conn.execute("""INSERT INTO order_release
            (order_id,status,claimed_at) VALUES (?,'claimed',?)""",
            (oid, old))
    alerts = om.scan_alerts(store, now=now)
    check("a paid order with uncertain kitchen send is critical",
          any(a.key == f"paid-not-released:{oid}" and a.severity == "critical"
              for a in alerts))


def t_plan_daily_usage_is_a_warning_signal_never_a_cutoff() -> None:
    import cost_control as cc
    store, cfg, mv = fixture()
    now = datetime.now(timezone.utc).replace(hour=15, minute=0, second=0)
    threshold = cc.PLANS[cc.DEFAULT_PLAN]["daily_calls"]
    for i in range(threshold - 1):
        store.start_session(cfg.id, mv, channel="voice",
                            external_id=f"plan-burst-{i}")
    check("just under the daily figure pages nobody",
          not [a for a in om.scan_alerts(store, now=now) if a.category == "usage"])
    store.start_session(cfg.id, mv, channel="voice",
                        external_id="plan-burst-final")
    alerts = [a for a in om.scan_alerts(store, now=now) if a.category == "usage"]
    check("reaching the daily figure is one warning per day",
          len(alerts) == 1 and alerts[0].severity == "warning"
          and alerts[0].restaurant_id == cfg.id, alerts)
    check("the key is per location and per day so it pages once",
          alerts[0].key == f"plan-daily-usage:{cfg.id}:"
                           f"{now.strftime('%Y%m%d')}", alerts[0].key)
    check("the alert never asks anyone to hang up on a caller",
          "interrupt" in alerts[0].action.lower()
          and "not a limit" in alerts[0].detail.lower(), alerts[0])
    # The location's own plan governs the threshold: moving it to Grande
    # (100 calls a day) clears the Small-tier signal.
    cc.set_plan(store, cfg.id, "grande")
    alert = [a for a in om.scan_alerts(store, now=now) if a.category == "usage"]
    check("a higher plan clears the signal below its own threshold",
          not alert, alert)
    # A call from yesterday does not count into today.
    yesterday = om.scan_alerts(store, now=now - timedelta(days=1))
    check("yesterday's scan shows no usage alert for today's calls",
          not [a for a in yesterday if a.category == "usage"])


def main() -> int:
    for name, fn in sorted(globals().items()):
        if not name.startswith("t_"):
            continue
        try:
            fn()
        except Exception:
            global _failed
            _failed += 1
            print(f"\n--- FAIL {name}\n{traceback.format_exc()}")
    print(f"\n{_passed} passed, {_failed} failed (operations monitoring)")
    return 1 if _failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
