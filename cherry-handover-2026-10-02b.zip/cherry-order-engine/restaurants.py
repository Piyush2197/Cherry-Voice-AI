"""
REAL restaurant configs. Not templates.

cuisine_packs.py holds the eight cuisine templates you copy from. This file
holds actual restaurants you have onboarded, with their real menus, real
prices and real POS identifiers.

WHERE THE MENUS LIVE NOW
------------------------
Six restaurants used to have a hand-written Python module each
(`restaurant_chengs.py`, `restaurant_sams_kabob.py`, `restaurant_juan_miguels.py`,
`restaurant_miyazaki.py`, `restaurant_tamago.py`, `restaurant_pink_garlic.py`).
They were deleted on 2026-09-30. Five of them were **identical to their YAML
across 412 items**, and the sixth had already drifted — the Pink Garlic Python
copy held 51 items while the real locations held 114-144. Nothing on the live
path ever read them; only tests did. See `REDUNDANCY_AUDIT_2026-09-30.md` §2.

The single source of truth for a restaurant menu is now `menus/<id>.yaml`, which
is also what `pilot_deploy.py apply` publishes into the `menu_version` table and
what `order_store.load_live_config()` rebuilds at call time. `REAL_RESTAURANTS`
below loads from that directory, so a test fixture and the deployed menu cannot
disagree any more — which is exactly how the Pink Garlic copy went stale.

`BUN_N_RUN` stays hand-written on purpose: it is a small, deliberately shaped
fixture (9 items, all the modifier shapes) that the conformance invariants
exercise by name. It is a test double, not a copy of a deployed menu.
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict

from cuisine_packs import grp, opt
from order_engine import MenuItem, ModifierOption, RestaurantConfig

MENUS_DIR = Path(__file__).parent / "menus"


def _opt_pos(o: ModifierOption, **refs: str) -> ModifierOption:
    """Attach POS identifiers to a modifier option."""
    import dataclasses
    return dataclasses.replace(o, pos_refs=dict(refs))


def _item(
    id: str,
    name: str,
    price: int,
    *,
    aliases=(),
    groups=(),
    category: str = "entree",
    toast_guid: str = "",
    toast_combo_guid: str = "",
) -> MenuItem:
    refs: Dict[str, str] = {}
    if toast_guid:
        refs["toast_guid"] = toast_guid
    if toast_combo_guid:
        # The combo is a SEPARATE Toast item with its own GUID, not a modifier
        # on the base item. The bridge must submit this GUID instead of
        # toast_guid when the combo option is selected — submitting the base
        # GUID plus a "combo" modifier would be rejected by Toast.
        refs["toast_combo_guid"] = toast_combo_guid
    return MenuItem(
        id=id, name=name, base_price_cents=price, aliases=aliases,
        modifier_group_ids=groups, category=category, pos_refs=refs,
    )


# ---------------------------------------------------------------------------
# Toppings
#
# The old config carried a flat default_toppings list per item, which is why
# it needed two different lists: burgers with cheese and burgers without. The
# new model puts defaults on the GROUP, so the migration is two groups sharing
# one option list — the same pattern the pizza pack uses for its two topping
# groups. No engine change, no per-item special case.
#
# Pickle is deliberately absent. The old config's toast_modifier_name_map
# listed "pickle" -> "Pickle", but Bun N Run's actual Toast modifier group
# (mg-toppings) has no Pickle option, and no item defaulted to it. That
# mismatch is what made "single cheeseburger no pickle" a known bad case in
# the old engine. Leaving pickle off the menu is the correct fix: the matcher
# now finds nothing and Lily says so, instead of accepting a topping change
# Toast cannot represent.
# ---------------------------------------------------------------------------

_TOPPING_IDS = ("bnr_tomato", "bnr_onion", "bnr_ketchup", "bnr_mayo",
                "bnr_cheese", "bnr_bacon")

_PLAIN_DEFAULTS = ("bnr_tomato", "bnr_onion", "bnr_ketchup", "bnr_mayo")
_CHEESE_DEFAULTS = _PLAIN_DEFAULTS + ("bnr_cheese",)

BUN_N_RUN = RestaurantConfig(
    id="bun-n-run-ferndale",
    name="Bun N Run Burger (Ferndale)",
    cuisine="burger",
    # Michigan state sales tax on prepared food; Ferndale adds no local rate.
    # The old engine's tax was an acknowledged hardcoded stand-in.
    tax_rate_bps=600,
    pay_now_threshold_cents=3000,
    pay_now_basis="subtotal",     # OPEN QUESTION 3 — subtotal or post-tax total
    pos_type="toast",
    options=(
        _opt_pos(opt("bnr_tomato", "Tomato", default=True,
                     aliases=("tomatoes",)), toast_guid="mo-tomato"),
        _opt_pos(opt("bnr_onion", "Onion", default=True,
                     aliases=("onions", "raw onion")), toast_guid="mo-onion"),
        _opt_pos(opt("bnr_ketchup", "Ketchup", default=True),
                 toast_guid="mo-ketchup"),
        _opt_pos(opt("bnr_mayo", "Mayo", default=True,
                     aliases=("mayonnaise",)), toast_guid="mo-mayo"),
        # OPEN QUESTION 1 — price unknown. The old config priced no modifier at
        # all and Toast's fixture carries no modifier prices. Zero is a
        # deliberate placeholder that shows up immediately in any test order;
        # an invented $1.00 would ship silently wrong.
        _opt_pos(opt("bnr_cheese", "Cheese", 0,
                     aliases=("american cheese",)), toast_guid="mo-cheese"),
        _opt_pos(opt("bnr_bacon", "Bacon", 0,
                     aliases=("bacon strips",)), toast_guid="mo-bacon"),

        # Combo is a flat +$4.00 on every burger in the old config
        # (5.99->9.99, 6.99->10.99, 7.99->11.99, 8.99->12.99, 6.99->10.99).
        # OPEN QUESTION 2 — the old config let the caller choose no side and no
        # drink, and Toast's combo items carry only the toppings modifier
        # group. Either the combo genuinely is fixed, or Bun N Run's Toast menu
        # is under-modeled. Not inventing a choice here; see MIGRATION.md.
        opt("bnr_combo", "Make it a Combo", 400,
            aliases=("combo", "make it a meal", "meal", "as a combo",
                     "with fries and a drink")),
    ),
    groups=(
        grp("bnr_toppings_plain", "Toppings",
            "Any changes to the toppings?",
            _TOPPING_IDS, mn=0, mx=6, defaults=_PLAIN_DEFAULTS),
        grp("bnr_toppings_cheese", "Toppings",
            "Any changes to the toppings?",
            _TOPPING_IDS, mn=0, mx=6, defaults=_CHEESE_DEFAULTS),
        grp("bnr_combo_group", "Combo",
            "Would you like to make that a combo?",
            ("bnr_combo",), mn=0, mx=1),
    ),
    items=(
        _item("hamburger", "Hamburger", 599,
              aliases=("burger", "plain burger", "single hamburger"),
              groups=("bnr_toppings_plain", "bnr_combo_group"),
              toast_guid="a1b2-hamburger",
              toast_combo_guid="a1b2-hamburger-combo"),
        _item("cheeseburger", "Cheeseburger", 699,
              aliases=("cheese burger", "single cheeseburger",
                       "burger with cheese"),
              groups=("bnr_toppings_cheese", "bnr_combo_group"),
              toast_guid="a1b2-cheeseburger",
              toast_combo_guid="a1b2-cheeseburger-combo"),
        _item("double_hamburger", "Double Hamburger", 799,
              aliases=("double burger", "double plain", "double no cheese"),
              groups=("bnr_toppings_plain", "bnr_combo_group"),
              toast_guid="a1b2-double-hamburger",
              toast_combo_guid="a1b2-double-hamburger-combo"),
        _item("double_cheeseburger", "Double Cheeseburger", 899,
              aliases=("double cheese burger", "double with cheese"),
              groups=("bnr_toppings_cheese", "bnr_combo_group"),
              toast_guid="a1b2-double-cheeseburger",
              toast_combo_guid="a1b2-double-cheeseburger-combo"),
        _item("veggie_burger", "Veggie Burger", 699,
              aliases=("veggie", "vegetarian burger"),
              groups=("bnr_toppings_plain", "bnr_combo_group"),
              toast_guid="a1b2-veggie-burger",
              toast_combo_guid="a1b2-veggie-burger-combo"),

        # "fries" is deliberately NOT an alias here. Bun N Run sells French
        # Fries at $3.99 and Wild Fries at $5.99, so a bare "fries" is a
        # $2.00 guess. Both items floor to the same score and the engine asks.
        _item("french_fries", "French Fries", 399,
              aliases=("regular fries", "plain fries"), category="side",
              toast_guid="a1b2-french-fries"),
        # Toast's fixture had Wild Fries outOfStock, but that is a moment in
        # time, not a menu fact. Availability belongs to the POS sync, not the
        # config — the config says what is on the menu.
        _item("wild_fries", "Wild Fries", 599,
              aliases=("wild fry",), category="side",
              toast_guid="a1b2-wild-fries"),
        _item("shake", "Milkshake", 599,
              aliases=("shake", "milk shake"), category="drink",
              toast_guid="a1b2-milkshake"),
        _item("beverage", "Fountain Drink", 249,
              aliases=("drink", "soda", "pop", "coke", "beverage"),
              category="drink", toast_guid="a1b2-fountain-drink"),
    ),
)


def load_real_restaurants() -> Dict[str, RestaurantConfig]:
    """Every menu in `menus/`, loaded through the same path production uses.

    This replaced a dict assembled from six hand-written Python modules. Loading
    the YAML means a fixture and a deployed menu are the same file, so they
    cannot drift apart the way the Pink Garlic copy did.
    """
    import menu_schema as ms
    return ms.load_all(MENUS_DIR)


def _real_restaurants() -> Dict[str, RestaurantConfig]:
    """Lazy so importing this module never does file I/O.

    `BUN_N_RUN` is a purpose-built fixture and is kept alongside the real
    menus, because the conformance invariants reference its items by name.
    """
    out = load_real_restaurants()
    out.setdefault(BUN_N_RUN.id, BUN_N_RUN)
    return out


class _LazyRealRestaurants(dict):
    """A dict that loads `menus/` on first use.

    Kept as a mapping because callers already treat `REAL_RESTAURANTS` as one
    (`suites.update(REAL_RESTAURANTS)`), and because importing a module should
    not read 19 YAML files as a side effect.
    """

    _loaded = False

    def _ensure(self):
        if not self._loaded:
            self._loaded = True
            dict.update(self, _real_restaurants())

    def __getitem__(self, k):
        self._ensure()
        return dict.__getitem__(self, k)

    def __iter__(self):
        self._ensure()
        return dict.__iter__(self)

    def __len__(self):
        self._ensure()
        return dict.__len__(self)

    def keys(self):
        self._ensure()
        return dict.keys(self)

    def items(self):
        self._ensure()
        return dict.items(self)

    def values(self):
        self._ensure()
        return dict.values(self)

    def get(self, k, default=None):
        self._ensure()
        return dict.get(self, k, default)

    def __contains__(self, k):
        self._ensure()
        return dict.__contains__(self, k)


REAL_RESTAURANTS: Dict[str, RestaurantConfig] = _LazyRealRestaurants()


# ---------------------------------------------------------------------------
# Availability sync
#
# The old engine baked sold-out state into the menu fixture at load time. That
# conflates "not on the menu" with "we ran out tonight". This keeps them
# separate: the config is the menu, and this applies a point-in-time
# availability snapshot from whatever source you have — Toast's outOfStock
# flags, or a human tapping a toggle in the fallback dashboard.
# ---------------------------------------------------------------------------


def apply_availability(
    config: RestaurantConfig,
    unavailable_item_ids: frozenset = frozenset(),
    unavailable_option_ids: frozenset = frozenset(),
) -> RestaurantConfig:
    """Return a copy of config with the given items/options marked sold out."""
    import dataclasses
    return dataclasses.replace(
        config,
        items=tuple(dataclasses.replace(i, available=False)
                    if i.id in unavailable_item_ids else i
                    for i in config.items),
        options=tuple(dataclasses.replace(o, available=False)
                      if o.id in unavailable_option_ids else o
                      for o in config.options),
    )


def from_toast_menu_response(
    config: RestaurantConfig, response: dict
) -> RestaurantConfig:
    """Read Toast's outOfStock flags and apply them to the config.

    Matches on the toast_guid already stored in each item's pos_refs, so it
    cannot silently sync a restaurant against another restaurant's Toast items
    — the failure mode the old engine's default-argument bug allowed.
    """
    out_of_stock = set()
    for menu in response.get("menus", []):
        for group in menu.get("menuGroups", []):
            for mi in group.get("menuItems", []):
                if mi.get("outOfStock"):
                    out_of_stock.add(mi.get("guid"))
    dead = frozenset(
        i.id for i in config.items
        if i.pos_refs.get("toast_guid") in out_of_stock
    )
    return apply_availability(config, unavailable_item_ids=dead)
