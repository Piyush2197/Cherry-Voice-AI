# Cherry — start here

For the current **forwarded-number and checkout-handoff-only** launch, follow
`DEVELOPER_HANDOFF.md` first. Sections below that describe a paid-webhook
kitchen release document the older optional mode and do not describe the
current launch decision.

You are wiring Inworld and Telnyx to an order engine that is already built and
covered by automated checks. The Inworld-specific event/media adapter and
live Telnyx transfer path still need provider proof. `DEVELOPER_HANDOFF.md`
is the current launch sequence; `INTEGRATION.md` has interface detail.

Commercial boundaries, the three pricing tiers and unresolved owner
decisions are in `OPERATING_PLAN.md`.

For a brand-new restaurant, start with `ONBOARDING.md` and
`./cherry.py onboard new ...`. It creates the complete two-business-day case,
deployment packet, acceptance record and launch certificate.

For **draft demonstrations at 20 locations**, use `DEMO_ONBOARDING.md` and
`demo_portfolio.py`. This local practice workflow has ten named locations now,
reports the remaining gap, and does not activate calls, checkout or the POS.

## Run it in 60 seconds

```bash
cd cherry-order-engine
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

python3 test_server.py                                 # HTTP checks, over a real socket
python3 cherry.py deploy menus/bun-n-run-ferndale.yaml \
        --db cherry.db --staff-phone +1313DIRECTLINE --inbound +1313TELNYXNUM
#   --dev-checkout lets a whole order finish with no provider account.
#   It is NOT a payment and the link does not resolve. Never use it for a pilot.
python3 server.py --db cherry.db --port 8080 --key dev-secret --dev-checkout
```

Then, in another terminal, take an order over HTTP:

```bash
K='X-Cherry-Key: dev-secret'; H='Content-Type: application/json'
B=http://localhost:8080

curl -s $B/v1/calls -H "$K" -H "$H" \
  -d '{"call_id":"test-1","to":"+1313TELNYXNUM","from":"+13135550123"}'

curl -s $B/v1/calls/test-1/tools/add_item       -H "$K" -H "$H" -d '{"text":"gimme a double cheeseburger"}'
curl -s $B/v1/calls/test-1/tools/remove_modifier -H "$K" -H "$H" -d '{"text":"no onion"}'
#   This menu has no bacon. Modify only what the restaurant actually sells —
#   the engine will correctly refuse anything else with "We don't have that".
#   confirm_mods answers the topping question; without it the order is not
#   complete and finish() keeps asking, by design.
curl -s $B/v1/calls/test-1/tools/confirm_mods   -H "$K" -H "$H" -d '{}'
curl -s $B/v1/calls/test-1/tools/read_back      -H "$K" -H "$H" -d '{}'
curl -s $B/v1/calls/test-1/finish               -H "$K" -H "$H" -d '{}'
```

`finish` texts the customer a checkout link and holds the ticket:

```json
{"placed": true, "short_code": "5272", "total_cents": 1059,
 "delivered": false, "payment": "link_sent", "awaiting_payment": true}
```

Under `--dev-checkout`, complete that payment the way Square's signed webhook
would — this calls the same `mark_paid()` and `release_paid_order()`:

```bash
curl -s -X POST $B/v1/dev/pay/ORDER_ID -H "$K" -H "$H" -d '{}'
# {"ok": true, "paid": true, "amount_cents": 1059,
#  "release": {"released": true, "sink": "manual", "external_ref": "..."}}
```

The order is now paid and has reached the kitchen sink, exactly once —
`order.released_after_payment` and `payment.paid` are in the event log.

`/v1/dev/pay/...` returns **404** unless the server was started with
`--dev-checkout`, and `/health` reports `"checkout": "dev"` when it is on. The
flag exists to make the product runnable and demonstrable, not to take money.

**Without a checkout provider and without `--dev-checkout`, the order is
recorded but held** — Cherry says so to the caller and escalates:

```json
{"placed": true, "short_code": "5272", "total_cents": 953,
 "delivered": false, "payment": "link_pending", "awaiting_payment": false}
```

That is correct behaviour for a manual-only location, but it is not a live
path. A merchant-authorized Square itemized checkout is required for **every**
pilot order: it texts the customer a secure review link, and Square makes the
paid order available to staff. Cherry ends the call flow after sending the link
and creates no second kitchen ticket. Do not use this manual-only example for
live calls.

The Inworld worker still has to map live call events and tool selections to
these HTTP calls. `voice_gateway.py` defines the current event contract.

## Deploy the next locations

The seven-storefront plan for Bun N Run, Pink Garlic, Miyazaki and Tamago lives in
`deployments/pilot-locations.yaml`. See exactly what is ready or missing:

```bash
python3 pilot_deploy.py plan
```

Each location has a separate environment variable for its Telnyx number. Once
one is assigned, deploy only that storefront:

```bash
export CHERRY_INBOUND_TAMAGO_HALL_RD='+1...'
python3 pilot_deploy.py apply --db cherry.db --only tamago-sushi-bowl
python3 pilot_deploy.py verify --db cherry.db --only tamago-sushi-bowl
python3 pilot_smoke.py --db cherry.db --only tamago-sushi-bowl
```

The command runs the complete menu gate first and refuses partial writes. Pink
Garlic Oak Park and Allen Park now have separate location-specific Cherry files
and pinned regressions. Owner price signoff is still needed; Square variation
ids are optional for ad-hoc checkout, but merchant authorization is not.

`verify` is the final pre-traffic gate. It proves that the live menu, Telnyx
inbound number, database route, active flag, and direct human fallback all
match the manifest. It also rejects a number accidentally assigned to two
selected locations.
`pilot_smoke.py` then prices and reads back a simple menu item without creating
an order, call session, text, payment, or phone call. Add `--base-url` after the
server starts to check its health and tool contract too.

Before any Telnyx traffic, connect an order-specific itemized checkout for the
location, apply `--sink square` if that merchant uses Square, run
`pilot_deploy.py checkout-ready --db cherry.db --only <location>`, and verify
one real review-and-pay call. The default manual sink deliberately fails this
checkout gate. A general website ordering link is not sufficient.

After numbers are configured, prove human fallback entirely offline:

```bash
python3 failover_drill.py --only tamago-sushi-bowl
```

This drives a simulated Cherry outage through the real bridge and transfer
adapter, verifies exactly one transfer to the manifest fallback, and checks
that the result is auditable. It makes no network request.

## The endpoints

| | |
|---|---|
| `POST /v1/calls` | A call arrived. Body: `{call_id, to, from}`. `to` is the dialled number — it picks the restaurant |
| `POST /v1/calls/{call_id}/tools/{tool}` | One of the nineteen ordering, reservation, allergy and host tools. Body is the tool's arguments |
| `POST /v1/calls/{call_id}/finish` | Caller is done. Records the immutable order and sends itemized checkout; no kitchen handoff before payment |
| `POST /v1/orders/{id}/cancel-checkout` | Scoped operator revokes an unpaid link before a corrected replacement order is taken |
| `POST /v1/calls/{call_id}/abandon` | Caller hung up |
| `POST /v1/calls/{call_id}/usage` | Persist provider TTS/STT totals for invoice reconciliation |
| `POST /v1/webhooks/telnyx/sms` | Point Telnyx's messaging webhook here |
| `POST /v1/webhooks/square/payment` | Signed, idempotent Square payment status webhook |
| `GET /v1/tools` | The nineteen tool schemas, to load into Inworld |
| `GET /v1/ops/snapshot?hours=24` | Private, identity-free fleet metrics and actionable alerts |
| `GET /ops` | Operator interface for metrics, alerts and catalog reviews |
| `GET/POST /v1/restaurants/{id}/controls` | Scoped hours, holidays, wait/prep, languages and AI disablement |
| `GET /t/{code}` | Kitchen ticket, accessible only after paid handoff |
| `GET /health` | For your load balancer |

Everything except `/health` and `/t/...` needs the `X-Cherry-Key` header.
`/health` checks the database and reports active restaurant, routed restaurant,
and live-menu counts; it returns HTTP 503 if the database check fails.
The operations snapshot never returns caller phone numbers, names, transcripts,
external call ids, or ticket contents. It is the reviewed source for the fleet
dashboard once live calls exist. Until then, it returns honest empty/null
metrics rather than manufactured demo performance.

## The three rules to build the prompt around

**1. Speak the `say` field verbatim.** Every tool returns one. It carries
prices, clarifying questions and sold-out notices that must be exact. If the
model paraphrases — "that'll be about thirteen dollars" — that is a bug. Test
for it.

**2. Route on `needs`.** If the last response had a non-null `needs`, the
caller's next words are an **answer**, not a new item:

```
if last_response["needs"]:  → POST .../tools/answer   {"text": "..."}
else:                       → POST .../tools/add_item {"text": "..."}
```

Backwards, nothing can be ordered at all. That exact bug bit the internal
harness once already.

**3. Never hang up on `submittable: false`.** `finish` will return
`"placed": false` with the question still to ask. That is not an error — ask it
and call `finish` again.

Two more worth knowing: **ambiguity comes back as a question, not a guess**
("pizza" at a pizzeria returns three candidates to choose between — the model
must ask); and **modifiers are per-unit**, so "three tacos, one with guac"
needs `split_line` *before* `add_modifier`.

## What you own

| Task | Why it matters |
|---|---|
| Connect Inworld call events and tool selections to the gateway | `GET /v1/voice/tools` exposes schemas and prompt, but a provider-specific adapter is still needed; see `VOICE_FORWARDING.md` |
| Set `TELNYX_PUBLIC_KEY` and point Telnyx's messaging webhook at `/v1/webhooks/telnyx/sms` | The public key lets Cherry verify the signed request; the webhook records delivery failures and honours STOP. Keep `X-Cherry-Key` only for local webhook tests. |
| `TELNYX_API_KEY` + `TELNYX_FROM_NUMBER`, then run with `--real-sms` | Until then SMS is faked and nothing is actually sent |
| **Verify the 10DLC campaign, not just the number** | `GET /v2/10dlc/phone_number_campaigns/{number}` must show `assignmentStatus: ASSIGNED`, and the campaign `MNO_PROVISIONED`. A bought-but-unassigned number texts your own phone fine and is **silently filtered** by AT&T and T-Mobile |
| Postgres for production | Install `requirements-postgres.txt`, set `CHERRY_DATABASE_URL`, then use `production_db.py bootstrap`, `verify`, `backup`, and `restore-drill`. The connector and bounded pool are built; provision the managed instance and run the first restore drill. |
| TLS in front of the server | It speaks plain HTTP on purpose; put nginx or a load balancer in front |
| Square OAuth per restaurant | Connect the secret manager to `square_oauth.py` and schedule refresh every seven days or less |

## What is already done, so don't rebuild it

The order engine, the matcher, pricing, the modifier model for twelve menu
shapes, the database, order immutability, the 86 system, the manual SMS
fallback, the Telnyx sender with its error-code table, opt-out suppression, the
Square bridge, the pay-link relay, the ops CLI, this server, and the
credential-free `voice/inworld_bridge.py` relay with human-handoff hook. The
Inworld media/event adapter is still a live integration task.
The hook's Telnyx Call Control implementation is `telnyx_voice.py`. Construct
`TelnyxCallTransfer(routes_from_manifest(...))` and pass it as the bridge's
`handoff`; the bridge `call_id` must be Telnyx's `call_control_id`, not a new
Cherry-only identifier. It transfers to the manifest's direct restaurant
number once if Cherry becomes unavailable.

**Do not edit** `order_engine.py`, `agent_api.py`, `config_validator.py`,
`menu_schema.py`. They are covered by 432 conformance invariants and verified
by mutation testing. If the engine seems wrong, the invariant that should have
caught it needs to change first — tell me instead.

## Two API facts that will otherwise waste your week

**Square will not show an unpaid order to the kitchen.** It needs a fulfillment
*and* a payment. And `CreatePaymentLink` cannot attach to an order you already
created. All seven pilot menus require one itemized Square checkout per order;
Square makes that same POS order available after payment. Cherry does not
submit a second POS order on webhook receipt.

**A Telnyx 200 means queued, not delivered.** The failures that matter —
`40010` (no 10DLC campaign) and `40300` (recipient sent STOP) — arrive on the
**webhook**, not in the response. That is why the webhook is not optional.

## The first live call

1. `python3 test_server.py` — all HTTP checks pass
2. `python3 cherry.py check menus/bun-n-run-ferndale.yaml` — prints READY
3. Deploy, start the server with `--real-sms`, point Inworld at it
4. Call the number. Order a double cheeseburger, no onion.
   Expect **$10.59** — the same total the curl sequence above produces, so if
   the phone call and the curl disagree, the problem is in the voice layer,
   not the engine. (Add "make it a combo" and it becomes $14.83.) These are
   the Bun N Run Ferndale prices as the menu file has them; if the menu
   changes they change with it, so re-read them rather than trusting this
   paragraph.
5. `python3 cherry.py trace <code> --db cherry.db` — every turn, the ticket,
   the delivery and the payment, in one place. This is your debugging tool.

If a customer later disputes what they ordered, export a single support packet:

```bash
python3 cherry.py evidence <code> --db cherry.db --out complaint-<code>.json
```

It joins the immutable final order, transcript, exact menu version and hash,
kitchen delivery attempts and acknowledgement, payment state and audit events.
Customer contact is masked by default; `--include-contact` is a deliberate,
sensitive support export. Cherry stores the transcript, not the original audio.
Provider-side call recording requires an approved consent and retention policy.

## Production database

SQLite remains the zero-setup local and single-pilot option. Production uses
the same repository through a bounded Postgres connection pool:

```bash
pip install -r requirements-postgres.txt
export CHERRY_DATABASE_URL='postgresql://...'
python3 production_db.py bootstrap
python3 production_db.py verify
python3 server.py --key "$CHERRY_API_KEY"
```

Create a restricted backup with `python3 production_db.py backup --out
backups/cherry.dump`. The separate-database restore procedure and its safety
guard are documented in `DATABASE.md`.
