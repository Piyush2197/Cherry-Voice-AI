#!/usr/bin/env python3
"""Rollback and measurable release gates for Cherry deployments."""

from __future__ import annotations

import argparse
import json
import statistics
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, asdict

from order_store import OrderStore


@dataclass
class LoadResult:
    requests: int
    failures: int
    error_percent: float
    p50_ms: float
    p95_ms: float
    max_ms: float
    passes: bool


def evaluate(latencies_ms, failures: int, *, max_error_percent=1.0,
             max_p95_ms=1500.0) -> LoadResult:
    values = sorted(float(x) for x in latencies_ms)
    total = len(values) + failures
    if not total:
        raise ValueError("load test needs at least one request")
    def percentile(p):
        if not values: return float("inf")
        return values[min(len(values)-1, max(0, int((len(values)-1)*p)))]
    error = failures / total * 100
    p95 = percentile(.95)
    return LoadResult(total, failures, round(error, 3), percentile(.5), p95,
                      max(values) if values else float("inf"),
                      error <= max_error_percent and p95 <= max_p95_ms)


def probe(url: str, key: str, *, requests=100, concurrency=10) -> LoadResult:
    """Concurrent authenticated health-path probe for a deployed staging URL."""
    def one(_):
        req=urllib.request.Request(url.rstrip("/")+"/v1/tools",
                                   headers={"X-Cherry-Key":key})
        start=time.perf_counter()
        with urllib.request.urlopen(req,timeout=10) as response:
            if response.status != 200: raise RuntimeError(response.status)
            response.read()
        return (time.perf_counter()-start)*1000
    latencies=[];failures=0
    with ThreadPoolExecutor(max_workers=concurrency) as pool:
        for future in as_completed([pool.submit(one,n) for n in range(requests)]):
            try:latencies.append(future.result())
            except Exception:failures+=1
    return evaluate(latencies,failures)


def main():
    ap=argparse.ArgumentParser(description=__doc__); sub=ap.add_subparsers(dest="cmd",required=True)
    load=sub.add_parser("load-test");load.add_argument("--url",required=True);load.add_argument("--key",required=True);load.add_argument("--requests",type=int,default=100);load.add_argument("--concurrency",type=int,default=10)
    rollback=sub.add_parser("rollback-menu");rollback.add_argument("--db",required=True);rollback.add_argument("--restaurant",required=True);rollback.add_argument("--version-id",type=int,required=True);rollback.add_argument("--by",default="release-operator")
    args=ap.parse_args()
    if args.cmd=="load-test":
        result=probe(args.url,args.key,requests=args.requests,concurrency=args.concurrency);print(json.dumps(asdict(result),indent=2));return 0 if result.passes else 2
    store=OrderStore.open(args.db);store.activate_menu_version(args.restaurant,args.version_id,by=args.by);print(f"ACTIVE {args.restaurant} menu version id {args.version_id}");return 0
if __name__=="__main__":raise SystemExit(main())
