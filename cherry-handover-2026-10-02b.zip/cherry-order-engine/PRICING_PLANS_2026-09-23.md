# Cherry pricing plans

> **SUPERSEDED 28 September 2026 — the pricing decision in force is below.**
> The 23 September table (Small $299 / Medium $399 / Grande $799) is history.
> Owner, finalised 28 Sep 2026, also used in `cherry-clinton-first-field-plan.xlsx`:
>
> | Plan | Up to calls/day | Monthly billing | Annual billing (per month) | Note |
> | --- | ---: | ---: | ---: | --- |
> | Small | 50 | $399/mo | $349/mo | Month-to-month or annual |
> | Medium | 65 | $499/mo | $469/mo | Month-to-month or annual |
> | Large | 100 | $649/mo | $649/mo | Annual commitment only |
>
> Plan fit is set in discovery by **calls per day** (under about 30 a day is
> not a fit yet); **Large is annual only**. The no-surprise-overage stance is
> unchanged: a plan's calls/day figure never causes a call to be cut off —
> exceeding it triggers a plan conversation. `cost_control.py` keeps monthly
> voice minutes as the usage-review measure (3,000 / 5,000 / 10,000 minutes
> from the original tiers) and the 50 / 65 / 100 daily figures as alert
> thresholds. Open question the owner has not answered: whether any monthly
> minute allowance remains part of the sold plan terms under the 28 Sep
> pricing. Do not quote a minute allowance in a contract until it is.

# Historical decision record — 23 September 2026

These are the three plans to retain for Cherry's pickup-order phone service.
Prices and included voice minutes are **per restaurant location**. The annual
option is a twelve-month contract paid in full upfront. Each plan provides its
stated number of voice minutes **per month** during that contract.

| Plan | Month-to-month | Annual contract, paid in full | Included voice minutes per month | Illustrative calls per day |
| --- | ---: | ---: | ---: | ---: |
| Small Tier | $299/month | $2,988/year ($249/month equivalent) | Up to 3,000 | Up to about 40 |
| Medium Tier | $399/month | $4,188/year ($349/month equivalent) | Up to 5,000 | Up to about 65 |
| Grande Tier | $799/month | $8,988/year ($749/month equivalent) | Up to 10,000 | Around 125 |

The daily call figures are **illustrations based on a 2.5-minute average call
and a 30-day month**, rounded conservatively for Medium and Grande. They are
not separate daily call limits or guarantees. For example, 3,000 minutes buys
1,200 calls at exactly 2.5 minutes each, or 40 per day in a 30-day month.
Longer calls lower the number of calls that fit. The monthly minute allowance
is the controlling plan limit. Do not interrupt an active order just because
it passes 2.5 or 3 minutes.

## Annual-payment comparison

| Plan | Twelve month-to-month payments | Annual amount paid upfront | Annual saving |
| --- | ---: | ---: | ---: |
| Small Tier | $3,588 | $2,988 | $600 |
| Medium Tier | $4,788 | $4,188 | $600 |
| Grande Tier | $9,588 | $8,988 | $600 |

## Handover and implementation notes

- Keep the existing no-surprise-overage approach: review a location for a
  higher plan after it exceeds its own included minutes for three consecutive
  **completed** billing months. Communicate rising usage before that point.
  Do not promise a per-minute overage charge or automatic cutoff.
- Since 2026-09-29 the repository stores each location's chosen tier
  (`location_plan` table, schema v6; `cost_control.py set-plan`) and evaluates
  its own allowance (3,000 / 5,000 / 10,000 minutes) in `plan_reviews`; the
  operations monitor raises one warning per day when a location reaches its
  plan's daily figure (50 / 65 / 100 calls). It still does not issue
  subscription invoices or collect annual payment — those remain the
  developer's to implement before automated billing is claimed.
- The older `OPERATING_PLAN.md`, sales materials, and unit-economics scripts
  contain single-plan or earlier call-duration assumptions. This document is
  the pricing decision record for the three plans; update downstream customer
  materials and calculations from it.
- The previously discussed no-implementation-fee launch policy remains in
  `OPERATING_PLAN.md`. This pricing decision does not add a setup charge.
- Contract details such as renewal, cancellation, refunds, and unused-minute
  carryover still need written terms before annual plans are sold. Do not
  invent those terms from the table above.
