# Billing: what each location owes Cherry

`billing.py` works out what every restaurant owes Cherry, issues each invoice exactly once, and
writes the file QuickBooks imports. Cherry never touches a restaurant's customers' money; this is only
the restaurant's own subscription to Cherry.

**Status: built and tested with fakes (119 checks in `test_billing.py`). Never run in production.
The Postgres tables (schema v8 in `db/schema.sql`) have never been run on a real Postgres.** Read the
first real run line by line against the signed contracts before anything is imported into QuickBooks.

## The rules it enforces

| Rule | What the code does |
|---|---|
| Prices | Small $399, Medium $499, Large $649 per month. Annual prepaid: $349, $469, $649 per month (so $4,188, $5,628, $7,788 for the year). Large is annual-only. All in `billing/price_book.yaml`. |
| Onboarding | $500 independent, $1,000 multi-location, charged once, on the first invoice. Waived on an annual contract. |
| When | By anniversary, in advance, due on receipt. A location live on the 15th is invoiced on the 15th each month (annual: every 12 months). No proration, so there is no half-month arithmetic. |
| Once only | One invoice per location per period (database `UNIQUE(restaurant_id, period_start)`). Running it daily, twice a day, or after a month of downtime issues each invoice once. |
| Credits | A credit rides on the next invoice and is applied once. It never takes an invoice below zero; the remainder carries to the next one. |
| Void | Voiding keeps the period occupied, so the run does not re-issue it. Credits it carried return to pending. |
| Pause, resume, cancel | A paused contract is not billed. Resuming bills from the resume date. A cancelled one is billed for periods that start before its end date, none after. |
| Overage | Does not exist. Usage appears as a memo line and in the plan reviews. It is never a charge. |
| Tax | Not calculated. Amounts are before tax; QuickBooks applies the tax code. |
| Revenue | An annual prepayment is deferred and earned by the day across the year. Cents are exact: each month's share is rounded down and the leftover cents go to the months with the biggest fractions, so months always sum to the invoice. Onboarding and one-off charges are counted when invoiced. |

## Decisions that are yours, not the code's

1. **Onboarding on an annual contract.** The pricing sheet says "waived or halved"; the changelog says
   "waived". The price book uses `annual_term: waive` (the later wording). Change it to `halve` or `full`
   in `billing/price_book.yaml` if you meant otherwise. Test it with `run --dry-run` first.
2. **Changing a price.** Add a new block under `books:` with a later `effective_from`. It applies to
   periods that start on or after that date. Invoices already issued never change.
3. **Revenue recognition for onboarding.** It is counted in the month invoiced. Confirm that with your
   accountant before the first month-end close.

## Day to day

```bash
# once per location, when it goes live
python3 billing.py --db "$CHERRY_DATABASE_URL" contract set --restaurant pink-garlic-shelby \
    --customer "Pink Garlic" --plan small --term monthly --starts 2026-10-15 --email owner@example.com
# options: --multi-location (onboarding $1,000), --onboarding-cents N, --price-cents N (negotiated monthly price), --notes

python3 billing.py --db "$CHERRY_DATABASE_URL" contract list
python3 billing.py --db "$CHERRY_DATABASE_URL" contract show --restaurant pink-garlic-shelby

# what would be issued today (changes nothing)
python3 billing.py --db "$CHERRY_DATABASE_URL" run --dry-run
python3 billing.py --db "$CHERRY_DATABASE_URL" run                 # issue it; the cron does this daily at 05:00
# options: --date YYYY-MM-DD (as if run on that day), --lead-days N, --only RESTAURANT_ID (repeatable)

python3 billing.py --db "$CHERRY_DATABASE_URL" list --status issued
python3 billing.py --db "$CHERRY_DATABASE_URL" show INVOICE_NUMBER

# hand to QuickBooks
python3 billing.py --db "$CHERRY_DATABASE_URL" export --out invoices.csv --mark-exported
# QuickBooks Online: Settings > Import Data > Invoices, upload invoices.csv, map the columns.
# --include-exported re-exports invoices already exported (for a lost file).

# adjustments
python3 billing.py --db "$CHERRY_DATABASE_URL" credit --restaurant pink-garlic-shelby --cents 2500 --memo "Outage 3 Oct"
python3 billing.py --db "$CHERRY_DATABASE_URL" credit --restaurant pink-garlic-shelby --cents 5000 --charge --memo "Extra number"
python3 billing.py --db "$CHERRY_DATABASE_URL" contract pause  --restaurant pink-garlic-shelby --on 2026-11-01
python3 billing.py --db "$CHERRY_DATABASE_URL" contract resume --restaurant pink-garlic-shelby --on 2026-12-01
python3 billing.py --db "$CHERRY_DATABASE_URL" contract cancel --restaurant pink-garlic-shelby --on 2027-01-15
python3 billing.py --db "$CHERRY_DATABASE_URL" void INVOICE_NUMBER --reason "wrong plan"

# the month's numbers
python3 billing.py --db "$CHERRY_DATABASE_URL" report --month 2026-11
```

`report` shows recurring revenue (MRR and ARR, by plan), the month's invoicing, the revenue recognised
that month, and the deferred balance from annual prepayments.

## The CSV QuickBooks gets

One row per invoice line, with the invoice fields repeated on each line (QuickBooks wants that):
`InvoiceNo, Customer, InvoiceDate, DueDate, Terms, Location, Memo, Item(Product/Service), ItemDescription,
ItemQuantity, ItemRate, ItemAmount, ServiceDate, Currency`. The `Item(Product/Service)` names must exist as
products or services in your QuickBooks, or the import will ask you to map them. Create these before the
first import: `Cherry Subscription - Small`, `Cherry Subscription - Medium`, `Cherry Subscription - Large`,
`Cherry Onboarding`, `Cherry Adjustment`.

Worked example (checked by running it): a monthly Small contract starting 2026-10-15 gets invoice
`CH-2026-0001` for $899.00 (subscription $399.00 plus onboarding $500.00); the next month's invoice is
$399.00, less any credit. A start date before the price book's first effective date (2026-09-28) is refused.

## Before the first real run

- [ ] Enter every contract with `contract set`, from the signed paperwork, not from memory.
- [ ] `run --dry-run`, then check each line: plan, term, period, onboarding, total.
- [ ] Decide the three points above.
- [ ] Run it against a real Postgres 16 (it has only run on SQLite). Apply `db/schema.sql`, then repeat the dry run.
- [ ] Import the first CSV into a QuickBooks sandbox company, not the real books.
- [ ] Confirm the cron line in `deploy/cron/cherry.cron` is installed (`billing-run`).
