#!/usr/bin/env python3
"""Tests for Toast OAuth client-credentials authentication."""

import io
import json
import urllib.error
from datetime import datetime, timedelta, timezone

from toast_oauth import ToastAuthError, ToastOAuthClient, ToastToken


class Response:
    status = 200
    def __init__(self, body): self.body = body
    def __enter__(self): return self
    def __exit__(self, *_): return False
    def read(self): return json.dumps(self.body).encode()


class Vault:
    def __init__(self): self.values = {}; self.writes = []
    def get(self, name): return self.values.get(name, "")
    def put(self, name, value): self.values[name] = value; self.writes.append((name, value))


def test_authentication_request():
    seen = {}
    def open_(request, timeout):
        seen.update(json.loads(request.data))
        return Response({
            "status": "SUCCESS",
            "token": {
                "accessToken": "test-access-token",
                "refreshToken": "test-refresh-token",
                "expiresIn": 86400,
                "scope": "orders:write,orders:read"
            }
        })
    client = ToastOAuthClient("client-id", "client-secret", opener=open_)
    token = client.authenticate()
    
    assert token.access_token == "test-access-token"
    assert token.refresh_token == "test-refresh-token"
    assert seen["clientId"] == "client-id"
    assert seen["clientSecret"] == "client-secret"
    assert seen["userAccessType"] == "TOAST_MACHINE_CLIENT"


def test_invalid_response_raises_error():
    client = ToastOAuthClient("client-id", "client-secret", 
                            opener=lambda *_a, **_k: Response({"status": "FAILED"}))
    try:
        client.authenticate()
        raise AssertionError("should have raised ToastAuthError")
    except ToastAuthError:
        pass


def test_missing_access_token_raises_error():
    client = ToastOAuthClient("client-id", "client-secret",
                            opener=lambda *_a, **_k: Response({"status": "SUCCESS", "token": {}}))
    try:
        client.authenticate()
        raise AssertionError("should have raised ToastAuthError")
    except ToastAuthError:
        pass


def test_http_failure_is_sanitized():
    def fail(*_a, **_k):
        raise urllib.error.HTTPError("u", 401, "bad", {}, io.BytesIO(b'{"error": "unauthorized"}'))
    client = ToastOAuthClient("client-id", "client-secret", opener=fail)
    try:
        client.authenticate()
        raise AssertionError("should have raised ToastAuthError")
    except ToastAuthError as exc:
        assert "HTTP 401" in str(exc)


def test_required_configuration():
    try:
        ToastOAuthClient("", "secret")
    except ValueError:
        pass
    else:
        raise AssertionError("missing client id accepted")
    
    try:
        ToastOAuthClient("id", "")
    except ValueError:
        pass
    else:
        raise AssertionError("missing client secret accepted")


def test_token_expiry_calculation():
    client = ToastOAuthClient("client-id", "client-secret",
                            opener=lambda *_a, **_k: Response({
                                "status": "SUCCESS",
                                "token": {
                                    "accessToken": "token",
                                    "expiresIn": 3600
                                }
                            }))
    token = client.authenticate()
    now = datetime.now(timezone.utc)
    assert (token.expires_at - now).total_seconds() > 3500
    assert (token.expires_at - now).total_seconds() < 3700


def test_sandbox_vs_production_urls():
    sandbox_client = ToastOAuthClient("id", "secret", sandbox=True)
    assert sandbox_client.auth_url == "https://ws-sandbox-api.eng.toasttab.com/authentication/v1/authentication/login"
    
    prod_client = ToastOAuthClient("id", "secret", sandbox=False)
    assert prod_client.auth_url == "https://ws-api.toasttab.com/authentication/v1/authentication/login"


def test_the_api_base_can_be_overridden_for_the_host_toast_gives_us():
    import os
    os.environ["TOAST_API_BASE"] = "https://toast.example.test/"
    try:
        assert ToastOAuthClient("id", "secret").auth_url == "https://toast.example.test/authentication/v1/authentication/login"
        assert ToastOAuthClient("id", "secret", sandbox=True).auth_url.startswith("https://toast.example.test/")
    finally:
        del os.environ["TOAST_API_BASE"]


# --- Toast's documented behaviour: no refresh token, one cached token, last-minute renewal ---

import tempfile
import threading
import time

import toast_oauth as to
from vault import FileVault

class Toast:
    """A fake Toast login: it returns the SAME token until the last minute of its life."""
    def __init__(self, lifetime=86400, refresh_token=None, scope="", delay=0.0):
        self.calls = 0
        self.lifetime, self.refresh_token, self.scope, self.delay = lifetime, refresh_token, scope, delay
        self.lock = threading.Lock()

    def __call__(self, request, timeout):
        with self.lock:
            self.calls += 1
            n = self.calls
        time.sleep(self.delay)
        return Response({"status": "SUCCESS", "token": {
            "tokenType": "Bearer", "scope": self.scope, "expiresIn": self.lifetime,
            "accessToken": f"tok-{n}", "idToken": "id", "refreshToken": self.refresh_token}})


def real_vault():
    return FileVault(tempfile.mkdtemp() + "/v")


def test_a_login_with_no_refresh_token_and_no_scope_is_stored_in_a_real_vault():
    """Toast's refreshToken is null for partner clients. The first version stored
    that empty string in a vault that refuses empty values and crashed."""
    v = real_vault()
    token = ToastOAuthClient("id", "s", opener=Toast()).authenticate()
    to.store_token(v, token)                       # used to raise ValueError
    got = to.get_stored_token(v)
    assert got is not None and got.access_token == "tok-1" and got.refresh_token == ""
    assert "TOAST_REFRESH_TOKEN" not in v.names() and "TOAST_TOKEN_SCOPES" not in v.names()
    to.store_token(v, ToastOAuthClient("id", "s", opener=Toast(scope="orders:read,orders:write")).authenticate())
    assert to.get_stored_token(v).scopes == ["orders:read", "orders:write"]


def test_one_token_is_cached_and_reused_for_every_call():
    v, t = real_vault(), Toast()
    c = ToastOAuthClient("id", "s", opener=t)
    seen = {to.access_token(c, v) for _ in range(5)}
    assert t.calls == 1 and seen == {"tok-1"}, (t.calls, seen)


def test_it_logs_in_again_only_when_expired_or_in_the_last_minute():
    v, t = real_vault(), Toast(lifetime=3600)
    c = ToastOAuthClient("id", "s", opener=t)
    first = to.access_token(c, v)
    expiry = to.get_stored_token(v).expires_at
    assert to.access_token(c, v, now=expiry - timedelta(minutes=30)) == first and t.calls == 1
    assert to.access_token(c, v, now=expiry - timedelta(minutes=2)) == first and t.calls == 1, \
        "Toast returns the same token before the last minute, so asking earlier is wasted"
    assert to.access_token(c, v, now=expiry - timedelta(seconds=30)) == "tok-2" and t.calls == 2
    assert to.access_token(c, v, now=expiry + timedelta(hours=5)) == "tok-3" and t.calls == 3, "an expired token is replaced"


def test_a_401_forces_a_new_login_even_inside_the_validity_period():
    v, t = real_vault(), Toast()
    c = ToastOAuthClient("id", "s", opener=t)
    to.access_token(c, v)
    assert to.access_token(c, v, force=True) == "tok-2" and t.calls == 2


def test_eight_workers_at_once_log_in_once():
    v, t = real_vault(), Toast(delay=0.15)
    c = ToastOAuthClient("id", "s", opener=t)
    got = []
    threads = [threading.Thread(target=lambda: got.append(to.access_token(c, v))) for _ in range(8)]
    [x.start() for x in threads]
    [x.join() for x in threads]
    assert t.calls == 1 and set(got) == {"tok-1"}, (t.calls, got)


def test_a_missing_or_nonsense_lifetime_is_never_assumed_to_be_a_day():
    for body in ({"accessToken": "t"}, {"accessToken": "t", "expiresIn": "soon"},
                 {"accessToken": "t", "expiresIn": -5}, {"accessToken": "t", "expiresIn": True}):
        tok = ToastOAuthClient("id", "s", opener=lambda *_a, _b=body, **_k: Response({"status": "SUCCESS", "token": _b})).authenticate()
        left = (tok.expires_at - datetime.now(timezone.utc)).total_seconds()
        assert 3500 < left <= 3600, (body, left)


def test_an_unreadable_cached_expiry_means_log_in_again_not_crash():
    v, t = real_vault(), Toast()
    v.put("TOAST_ACCESS_TOKEN", "x")
    v.put("TOAST_TOKEN_EXPIRES_AT", "garbage")
    assert to.get_stored_token(v) is None
    assert to.access_token(ToastOAuthClient("id", "s", opener=t), v) == "tok-1"


def test_the_health_check_logs_in_when_needed_and_skips_when_not():
    v, t = real_vault(), Toast()
    c = ToastOAuthClient("id", "s", opener=t)
    assert to.refresh_if_needed(c, v)["action"] == "authenticated"
    assert to.refresh_if_needed(c, v)["action"] == "skipped" and t.calls == 1
    assert to.refresh_if_needed(c, v, force=True)["action"] == "refreshed" and t.calls == 2


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    failed = 0
    for test in tests:
        try: test()
        except Exception as exc:
            failed += 1; print(f"FAIL {test.__name__}: {exc}")
    print(f"{len(tests)-failed} passed, {failed} failed (Toast OAuth)")
    raise SystemExit(bool(failed))
