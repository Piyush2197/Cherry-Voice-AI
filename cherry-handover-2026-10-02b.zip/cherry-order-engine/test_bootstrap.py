#!/usr/bin/env python3
"""deploy/bootstrap.sh, exercised on a scratch directory with every system command faked.

There is no Hostinger server here, so the script is tested for what can be tested: that it
refuses bad input, that a dry run changes nothing, that a real run creates exactly the
files, modes, services and nginx site it says (and starts nothing, opens no firewall, asks
for no certificate unless told), that it never overwrites an existing env file, that it
leaves .venv/databases out of the copy, and that running it twice is harmless. The faked
commands record what they were asked to do, so the ORDER is checked too (ssh is allowed
before the firewall is enabled; nginx is tested before it is reloaded).
"""

from __future__ import annotations

import os
import shutil
import stat
import subprocess
import tempfile
import traceback
from pathlib import Path

HERE = Path(__file__).resolve().parent
SCRIPT = HERE / "deploy" / "bootstrap.sh"
_passed = _failed = 0


def check(name, cond, detail=""):
    global _passed, _failed
    if cond:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


SHIM = """#!/bin/bash
echo "$(basename "$0") $*" >> "$SHIM_LOG"
"""


class World:
    """A fake server: a root directory, a command log, and shims for every system command."""

    def __init__(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.root, self.bin, self.log = self.tmp / "root", self.tmp / "bin", self.tmp / "commands.log"
        self.root.mkdir(); self.bin.mkdir(); self.log.write_text("")
        for cmd in ("apt-get", "useradd", "usermod", "chown", "systemctl", "nginx", "certbot", "ufw"):
            self._shim(cmd, SHIM)
        # `id cherry` fails until useradd has run, as on a fresh server
        self._shim("id", '#!/bin/bash\nif [ "${1:-}" = "-u" ]; then echo 0; exit 0; fi\n'
                         'echo "id $*" >> "$SHIM_LOG"\n[ -e "$SHIM_STATE/user" ]\n')
        self._shim("useradd", SHIM + 'touch "$SHIM_STATE/user"\n')
        self._shim("getent", "#!/bin/bash\nexit 0\n")
        # a stand-in interpreter: `-m venv DIR` builds a fake venv, everything else is the real python
        self._shim("fakepython", f'''#!/bin/bash
echo "python $*" >> "$SHIM_LOG"
if [ "${{1:-}}" = "-m" ] && [ "${{2:-}}" = "venv" ]; then
  mkdir -p "$3/bin"
  printf '#!/bin/bash\\necho "pip $*" >> "$SHIM_LOG"\\n' > "$3/bin/pip"
  printf '#!/bin/bash\\nexit 0\\n' > "$3/bin/python"
  chmod +x "$3/bin/pip" "$3/bin/python"
  exit 0
fi
exec "{os.sys.executable}" "$@"
''')
        (self.tmp / "state").mkdir()
        self.src = self.tmp / "src"
        self.source()

    def _shim(self, name, body):
        p = self.bin / name
        p.write_text(body)
        p.chmod(0o755)

    def source(self):
        """A small stand-in for the repository: the real deploy kit, and the files the script checks for."""
        shutil.copytree(HERE / "deploy", self.src / "deploy", ignore=shutil.ignore_patterns("__pycache__", "*.db"))
        for f in ("server.py", "requirements.txt", "requirements-postgres.txt"):
            (self.src / f).write_text((HERE / f).read_text() if f.startswith("requirements") else "# server\n")
        (self.src / ".venv" / "bin").mkdir(parents=True)
        (self.src / ".venv" / "bin" / "junk").write_text("x")
        (self.src / "__pycache__").mkdir()
        (self.src / "__pycache__" / "x.pyc").write_text("x")
        (self.src / "stray.db").write_text("a database that must never be copied")

    def run(self, *args, env_extra=None):
        env = {"PATH": f"{self.bin}:{os.environ['PATH']}", "SHIM_LOG": str(self.log), "SHIM_STATE": str(self.tmp / "state"),
               "ROOT_DIR": str(self.root), "PYTHON_BIN": str(self.bin / "fakepython"), "HOME": str(self.tmp)}
        env.update(env_extra or {})
        return subprocess.run(["bash", str(SCRIPT), "--source", str(self.src), *args], env=env, capture_output=True, text=True, timeout=120)

    def calls(self):
        return [l for l in self.log.read_text().splitlines() if l.strip()]

    def p(self, *parts):
        return self.root.joinpath(*[x.lstrip("/") for x in parts])


def mode(path: Path) -> int:
    return stat.S_IMODE(path.stat().st_mode)


def t_the_script_is_valid_shell_and_documents_itself() -> None:
    r = subprocess.run(["bash", "-n", str(SCRIPT)], capture_output=True, text=True)
    check("bash parses it", r.returncode == 0, r.stderr)
    r = subprocess.run(["bash", str(SCRIPT), "--help"], capture_output=True, text=True)
    check("--help prints the purpose and exits 0", r.returncode == 0 and "idempotent" in r.stdout and "--domain" in r.stdout, r.stdout[:200] + r.stderr[:200])
    check("it is executable-safe: strict mode is on", "set -euo pipefail" in SCRIPT.read_text())


def t_bad_input_is_refused_before_anything_changes() -> None:
    w = World()
    cases = [
        ((), "--domain is required"),
        (("--domain", "not a host"), "is not a host name"),
        (("--domain", "localhost"), "is not a host name"),
        (("--domain", "api.example.com", "--tls"), "--tls needs --email"),
        (("--domain", "api.example.com", "--ssh-port", "ssh"), "--ssh-port must be a number"),
        (("--domain", "api.example.com", "--bogus"), "unknown option"),
    ]
    for args, needle in cases:
        r = w.run(*args)
        check(f"refused: {' '.join(args) or '(no arguments)'}", r.returncode != 0 and needle in (r.stderr + r.stdout), r.stderr[-200:])
    r = w.run("--domain", "api.example.com", "--source", str(w.tmp / "nothing"))
    check("a folder that is not the repository is refused", r.returncode != 0 and "is not the Cherry repository" in r.stderr, r.stderr[-200:])
    check("none of that installed or changed anything", w.calls() == [] and not any(w.root.iterdir()), str(w.calls()))
    r = subprocess.run(["bash", str(SCRIPT), "--source", str(w.src), "--domain", "api.example.com", "--dry-run"],
                       env={"PATH": os.environ["PATH"], "HOME": str(w.tmp)}, capture_output=True, text=True)
    check("without a scratch ROOT_DIR it refuses to run off a Linux server as non-root (this machine is not the target)",
          r.returncode != 0 and ("Linux server" in r.stderr or "run as root" in r.stderr), r.stderr[-200:])


def t_a_dry_run_prints_the_plan_and_changes_nothing() -> None:
    w = World()
    r = w.run("--dry-run", "--domain", "api.example.com", "--tls", "--email", "ops@example.com", "--firewall")
    out = r.stdout
    check("it succeeds", r.returncode == 0, r.stderr[-300:])
    check("every step is announced, 1/9 to 9/9", all(f"{n}/9" in out for n in range(1, 10)), out[:300])
    check("the commands are printed, not run", "[dry-run] apt-get install" in out and "[dry-run] systemctl enable cherry-server cherry-gateway" in out
          and "[dry-run] certbot certonly" in out and "[dry-run] ufw --force enable" in out, out)
    mutating = [c for c in w.calls() if c.split()[0] not in ("id", "python")]      # reading the machine (python version, does the user exist) is fine
    check("nothing that changes the machine was executed", mutating == [], str(mutating))
    check("nothing was created under the root", not any(w.root.iterdir()), str(list(w.root.iterdir())))


def t_a_real_run_installs_exactly_what_it_says() -> None:
    w = World()
    r = w.run("--domain", "api.cherry.example")
    check("it succeeds", r.returncode == 0, r.stderr[-400:] + r.stdout[-400:])
    calls = w.calls()
    joined = "\n".join(calls)
    check("the packages are installed", any(c.startswith("apt-get install -y nginx certbot python3-venv") for c in calls), joined)
    check("the cherry user is created (once)", sum(1 for c in calls if c.startswith("useradd")) == 1 and "--system" in joined and "/usr/sbin/nologin" in joined)
    for d in ("/etc/cherry", "/var/lib/cherry/secrets", "/var/lib/cherry/briefs", "/var/lib/cherry/backups", "/var/log/cherry", "/opt/cherry"):
        check(f"{d} exists", w.p(d).is_dir())
    check("the secrets directory is private (700)", mode(w.p("/var/lib/cherry/secrets")) == 0o700, oct(mode(w.p("/var/lib/cherry/secrets"))))
    check("the app was copied", (w.p("/opt/cherry/server.py")).is_file() and w.p("/opt/cherry/deploy/bootstrap.sh").is_file())
    check("…without the source's .venv, caches or databases", not (w.p("/opt/cherry/.venv/bin/junk")).exists()
          and not w.p("/opt/cherry/__pycache__").exists() and not w.p("/opt/cherry/stray.db").exists())
    check("its own virtualenv was built and the Postgres requirements installed",
          w.p("/opt/cherry/.venv/bin/pip").is_file() and any(c.startswith("pip install --quiet -r") and c.endswith("requirements-postgres.txt") for c in calls), joined)
    envf = w.p("/etc/cherry/cherry.env")
    check("the env file is created from the example, private (600), with the placeholders still in it",
          envf.read_text() == (HERE / "deploy" / "cherry.env.example").read_text() and mode(envf) == 0o600 and "CHANGE_ME" in envf.read_text(), oct(mode(envf)))
    for u in ("cherry-server.service", "cherry-gateway.service"):
        check(f"{u} is installed", w.p("/etc/systemd/system", u).read_text() == (HERE / "deploy" / "systemd" / u).read_text())
    check("the units are enabled", "systemctl enable cherry-server cherry-gateway" in joined and "systemctl daemon-reload" in joined)
    check("…and NOT started: the secrets are not filled in yet", not any(c.startswith("systemctl start") or " restart" in c for c in calls), joined)
    conf = w.p("/etc/nginx/sites-available/cherry.conf").read_text()
    check("the nginx site has the domain in it and no placeholder left", "api.cherry.example" in conf and "api.example.com" not in conf)
    check("…keeps the routes (kds, the OAuth redirects) and still does not expose /t/", "location ~ ^/kds" in conf and "/v1/oauth/clover/callback" in conf and "location /t/" not in conf)
    check("the site is enabled by a link", w.p("/etc/nginx/sites-enabled/cherry.conf").is_symlink())
    check("nginx is TESTED, then reloaded (in that order)", calls.index("nginx -t") < calls.index("systemctl reload nginx"), joined)
    check("the cron file is installed", w.p("/etc/cron.d/cherry").read_text() == (HERE / "deploy" / "cron" / "cherry.cron").read_text() and mode(w.p("/etc/cron.d/cherry")) == 0o644)
    check("no certificate was requested and the firewall was not touched, because neither flag was given",
          not any(c.startswith(("certbot", "ufw")) for c in calls), joined)
    check("it tells the operator what is left, naming the database and the secrets",
          "docker compose up -d" in r.stdout and "CHANGE_ME" in r.stdout and "production_db.py bootstrap" in r.stdout and "go-live" in r.stdout, r.stdout[-900:])
    check("no secret appears anywhere in its output", "password" not in r.stdout.lower().replace("real password", ""), r.stdout[-300:])


def t_tls_and_firewall_only_when_asked_and_in_a_safe_order() -> None:
    w = World()
    r = w.run("--domain", "api.cherry.example", "--tls", "--email", "ops@cherry.example", "--firewall", "--ssh-port", "2222")
    check("it succeeds", r.returncode == 0, r.stderr[-300:])
    calls = w.calls()
    cert = [c for c in calls if c.startswith("certbot")]
    check("certbot gets the domain, the email and runs non-interactively",
          len(cert) == 1 and "-d api.cherry.example" in cert[0] and "--email ops@cherry.example" in cert[0] and "--non-interactive" in cert[0] and "--agree-tos" in cert[0], str(cert))
    check("nginx is not reloaded until AFTER the certificate exists (its HTTPS block needs the files)",
          [i for i, c in enumerate(calls) if c == "systemctl reload nginx"][0] > calls.index(cert[0]), "\n".join(calls))
    ufw = [c for c in calls if c.startswith("ufw")]
    check("SSH (the configured port) is allowed BEFORE the firewall is enabled, so it cannot lock the operator out",
          ufw.index("ufw allow 2222/tcp") < ufw.index("ufw --force enable") and "ufw allow 80/tcp" in ufw and "ufw allow 443/tcp" in ufw and "ufw default deny incoming" in ufw, str(ufw))
    check("it opens nothing else (not 8080, 8090 or 5432)", not any(p in " ".join(ufw) for p in ("8080", "8090", "5432")))


def t_it_never_overwrites_what_the_operator_has_done() -> None:
    w = World()
    w.run("--domain", "api.cherry.example")
    envf = w.p("/etc/cherry/cherry.env")
    envf.write_text("CHERRY_API_KEY=my-real-secret\n")
    os.chmod(envf, 0o600)
    r = w.run("--domain", "api.cherry.example")
    check("a second run succeeds", r.returncode == 0, r.stderr[-300:])
    check("the operator's env file is untouched", envf.read_text() == "CHERRY_API_KEY=my-real-secret\n" and "left exactly as it is" in r.stdout)
    check("the user is not created twice", sum(1 for c in w.calls() if c.startswith("useradd")) == 1)
    check("the installed app is refreshed from the source", w.p("/opt/cherry/server.py").read_text() == "# server\n")
    (w.src / "server.py").write_text("# server v2\n")
    w.run("--domain", "api.cherry.example")
    check("a newer source replaces the code (a deploy)", w.p("/opt/cherry/server.py").read_text() == "# server v2\n")
    check("…and the env file STILL is not replaced", envf.read_text() == "CHERRY_API_KEY=my-real-secret\n")


def t_options_that_skip_steps_skip_them() -> None:
    w = World()
    r = w.run("--no-nginx", "--skip-packages")
    check("no domain is needed without nginx", r.returncode == 0, r.stderr[-300:])
    calls = w.calls()
    check("no packages, no nginx", not any(c.startswith(("apt-get", "nginx")) for c in calls) and not w.p("/etc/nginx").exists(), "\n".join(calls))
    check("the services are still installed", w.p("/etc/systemd/system/cherry-server.service").exists())


def main() -> int:
    global _failed
    for name, fn in sorted((k, v) for k, v in globals().items() if k.startswith("t_")):
        try:
            fn()
        except Exception:                                    # noqa: BLE001
            _failed += 1
            print(f"\n--- FAIL {name} raised")
            traceback.print_exc()
    print(f"{_passed} passed, {_failed} failed (VPS bootstrap)")
    return 1 if _failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
