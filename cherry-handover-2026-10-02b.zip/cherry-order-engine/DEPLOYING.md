# Deploying Cherry — the path from a checked-out repo to a live restaurant

Written 2026-09-30. Every command below was run. `cherry.py go-live` is the
one that answers the only question that matters the night before.

---

## The one command

```bash
python3 cherry.py go-live --db "$CHERRY_DATABASE_URL" --url https://cherry.example
```

It checks the whole stack in the order failures actually bite — database,
secrets, menus, routing, providers, the running server, the voice layer — and
prints the exact command or variable that fixes each problem.

```
Database      FAIL  database configured — no --db and no CHERRY_DATABASE_URL
                    fix: set CHERRY_DATABASE_URL=postgresql://... or pass --db
Secrets       FAIL  CHERRY_API_KEY — not set
                    fix: generate one: openssl rand -hex 24  ->  CHERRY_API_KEY=...
Routing       FAIL  tamago-sushi-bowl direct staff line — CHERRY_DIRECT_FALLBACK_TAMAGO_HALL_RD not set;
                    would fall back to the PUBLISHED number +12489388095, which forwards into Cherry
                    fix: set CHERRY_DIRECT_FALLBACK_TAMAGO_HALL_RD=+1...
Providers     FAIL  Telnyx configured — missing TELNYX_API_KEY, TELNYX_FROM_NUMBER
                    fix: the voice gateway refuses to start without TELNYX_API_KEY
Runtime       FAIL  checkout is real — server is running --dev-checkout
                    fix: restart without --dev-checkout and configure Square
```

Exit code is **0 only when nothing blocks**. Three states, and the difference
between them is the point:

| | meaning |
| --- | --- |
| **FAIL** | something is wrong now and will break a call |
| **WARN** | it will work, but you are flying without something you want |
| **WAITING** | a human has to do it — buy a number, get an owner's signature |

Collapsing WAITING into FAIL blocks a launch on an owner's paperwork.
Collapsing it into PASS is how a launch slips silently.

Two checks refuse to be waved through, both because they have already happened
here:

- **A direct staff line equal to the published number.** That number forwards
  into Cherry, so a transfer to it loops. `pilot_deploy.py apply` will write the
  published number when the fallback variable is missing, and the gateway then
  refuses to start — so the deploy "succeeds" into a service that cannot boot.
- **`--dev-checkout` left on.** It marks orders paid without money moving. The
  server reports it in `/health` and `go-live` refuses to call that deployment
  live.

---

## The full path

```bash
# 0. dependencies (the repo ships a venv; the system python3 has no PyYAML)
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements-postgres.txt

# 1. database
python3 production_db.py bootstrap      # reads CHERRY_DATABASE_URL
python3 production_db.py verify         # reads CHERRY_DATABASE_URL

# 2. secrets — at minimum these three, and they must not be placeholders
export CHERRY_API_KEY=$(openssl rand -hex 24)
export CHERRY_VOICE_KEY=$(openssl rand -hex 24)
export CHERRY_OAUTH_STATE_SECRET=$(openssl rand -hex 24)
export CHERRY_SECRET_DIR=/etc/cherry/secrets && chmod 700 "$CHERRY_SECRET_DIR"

# 3. routing — one DID and one DIFFERENT direct staff line per location
export CHERRY_INBOUND_PINK_GARLIC_OAK_PARK=+1...
export CHERRY_DIRECT_FALLBACK_PINK_GARLIC_OAK_PARK=+1...   # not the same number

# 4. check it
python3 cherry.py go-live --db "$CHERRY_DATABASE_URL"

# 5. deploy the menus
python3 pilot_deploy.py plan
python3 pilot_deploy.py apply  --db "$CHERRY_DATABASE_URL" --sink square
python3 pilot_deploy.py verify --db "$CHERRY_DATABASE_URL"

# 6. start, then prove a real call path without placing an order
python3 server.py        --db "$CHERRY_DATABASE_URL" --key "$CHERRY_API_KEY" &
python3 voice_gateway.py --port 8090 &
python3 pilot_smoke.py   --db "$CHERRY_DATABASE_URL" --url http://127.0.0.1:8080
python3 cherry.py go-live --db "$CHERRY_DATABASE_URL" --url http://127.0.0.1:8080
```

`deploy/` holds the systemd units, the nginx TLS config, the cron entries and a
Postgres PITR recipe. `deploy/cherry.env.example` is the environment template;
`deploy/check_env_names.py` fails if it names a variable the code never reads.

---

## The two variable-name traps

Both cost real time if you meet them at 11pm.

**1. The fallback variable is not always the inbound variable with a different
prefix.** The inbound name comes from the manifest (it can be anything); the
fallback name is derived from the location id *unless the manifest declares
`fallback_env`*. For `tamago-sushi-bowl` they deliberately differ:

```
CHERRY_INBOUND_TAMAGO_HALL_RD          <- manifest inbound_env
CHERRY_DIRECT_FALLBACK_TAMAGO_HALL_RD  <- manifest fallback_env
```

Getting it wrong used to silently store the published number. `go-live` and
`pilot_deploy plan` now name the variable they looked for and say what happens
if it is unset.

**2. `--dev-checkout` is not a deployment mode.** It exists so the product can
be demonstrated and rehearsed without a merchant account. It appears in
`START_HERE.md` for exactly that. A pilot must never run with it, and `go-live`
fails the deployment if it sees it.

---

## What "deployable" still depends on that is not code

As of 2026-09-30 no part of Cherry's side of a live call is missing code. What
stands between this repository and a paying restaurant is accounts:

1. **Inworld SIP access** — then capture one real event and run
   `python3 inworld_adapter.py check --file event.json`. If a field is named
   differently it is a variable (`CHERRY_INWORLD_CALL_ID_FIELD=…`), not a patch.
2. **Telnyx** — one DID per location, messaging profile, and 10DLC campaign
   *assigned*. Buying the number is not enough; without the campaign the
   checkout SMS never arrives.
3. **Square merchant authorization** per restaurant, so the checkout link is
   real rather than `--dev-checkout`.
4. **A direct staff line per location** that does not forward into Cherry.

See `FIRST_CUSTOMER.md` for what can be done with a real customer before any of
that lands.
