#!/usr/bin/env python3
"""Telnyx Call Control transfer adapter for Cherry's human fallback.

Pass an instance as ``CherryBridge(..., handoff=transfer)``. The bridge's
``call_id`` must be the Telnyx ``call_control_id`` from the inbound call event.
The adapter is deliberately separate from SMS: voice transfer and messaging
use different Telnyx APIs and different identifiers.
"""

from __future__ import annotations

import asyncio
import json
import os
import re
import urllib.error
import urllib.parse
import urllib.request
import uuid
from typing import Any, Callable, Dict, Iterable, Mapping, Optional, Protocol, Tuple

from pilot_deploy import Location, direct_fallback


TELNYX_API = "https://api.telnyx.com/v2"
_E164 = re.compile(r"^\+[1-9][0-9]{7,14}$")


class TransferTransport(Protocol):
    async def post(self, url: str, headers: Dict[str, str],
                   body: Dict[str, Any], timeout: float) -> Tuple[int, Any]: ...


class UrlLibTransferTransport:
    async def post(self, url: str, headers: Dict[str, str],
                   body: Dict[str, Any], timeout: float) -> Tuple[int, Any]:
        def send() -> Tuple[int, Any]:
            request = urllib.request.Request(
                url, data=json.dumps(body).encode("utf-8"), method="POST",
                headers={**headers, "Content-Type": "application/json"})
            try:
                with urllib.request.urlopen(request, timeout=timeout) as response:
                    status, raw = response.status, response.read()
            except urllib.error.HTTPError as exc:
                status, raw = exc.code, exc.read()
            try:
                return status, json.loads(raw)
            except (TypeError, ValueError):
                return status, {"error": raw.decode("utf-8", "replace")}

        return await asyncio.to_thread(send)


def routes_from_manifest(locations: Iterable[Location],
                         env: Mapping[str, str], *,
                         require_direct: bool = False) -> Dict[str, str]:
    """Build inbound -> human routes, omitting locations not activated yet."""
    locations = list(locations)
    routes: Dict[str, str] = {}
    for loc in locations:
        inbound = str(env.get(loc.inbound_env, "")).strip()
        if not inbound:
            continue
        if inbound in routes:
            raise ValueError(f"duplicate Telnyx inbound number {inbound}")
        if not _E164.fullmatch(inbound):
            raise ValueError(f"invalid Telnyx inbound number {inbound!r}")
        fallback = direct_fallback(loc, dict(env), required=require_direct)
        if not _E164.fullmatch(fallback):
            raise ValueError(f"invalid fallback number for {loc.id}")
        routes[inbound] = fallback
    loop_numbers = set(routes) | {loc.fallback_phone for loc in locations}
    for inbound, fallback in routes.items():
        if require_direct and fallback in loop_numbers:
            raise ValueError(f"forwarding loop from {inbound} to {fallback}")
    return routes


class TelnyxCallTransfer:
    """Callable handoff compatible with ``voice.inworld_bridge.CherryBridge``."""

    def __init__(self, routes: Mapping[str, str], *, api_key: Optional[str] = None,
                 timeout: float = 8.0,
                 transport: Optional[TransferTransport] = None,
                 audit: Optional[Callable[..., None]] = None) -> None:
        self.api_key = api_key or os.getenv("TELNYX_API_KEY", "")
        if not self.api_key:
            raise ValueError("TELNYX_API_KEY is required for voice transfer")
        self.routes = dict(routes)
        for inbound, fallback in self.routes.items():
            if not _E164.fullmatch(inbound) or not _E164.fullmatch(fallback):
                raise ValueError("transfer routes must use E.164 phone numbers")
        self.timeout = timeout
        self.transport = transport or UrlLibTransferTransport()
        self.audit = audit

    def fallback_for(self, dialled: str) -> str:
        """The direct staff line for a dialled DID ('' when unknown)."""
        return self.routes.get(dialled, "")

    def _audit(self, call_control_id: str, dialled: str, fallback: str,
               status: str, reason: str, detail: str = "") -> None:
        if self.audit is None:
            return
        try:
            self.audit(call_control_id=call_control_id, dialled=dialled,
                       fallback=fallback, status=status, reason=reason,
                       detail=detail)
        except Exception:  # audit failure must never block a human transfer
            import logging
            logging.getLogger("cherry.telnyx_voice").exception(
                "could not persist voice handoff audit")

    async def __call__(self, call_control_id: str, dialled: str,
                       reason: str) -> None:
        fallback = self.routes.get(dialled)
        if fallback is None:
            raise LookupError(f"no human fallback route for {dialled}")
        if not call_control_id:
            raise ValueError("Telnyx call_control_id is required")

        # Stable across retries. Telnyx uses command_id to ignore the same
        # command submitted more than once for a call.
        command_id = str(uuid.uuid5(
            uuid.NAMESPACE_URL, f"cherry-transfer:{call_control_id}:{fallback}"))
        encoded = urllib.parse.quote(call_control_id, safe="")
        try:
            status, payload = await self.transport.post(
                f"{TELNYX_API}/calls/{encoded}/actions/transfer",
                {"Authorization": f"Bearer {self.api_key}"},
                {"to": fallback, "timeout_secs": 30,
                 "command_id": command_id}, self.timeout)
        except Exception as exc:
            self._audit(call_control_id, dialled, fallback, "failed", reason,
                        str(exc))
            raise
        if status >= 400:
            detail = payload.get("errors") if isinstance(payload, dict) else payload
            self._audit(call_control_id, dialled, fallback, "failed", reason,
                        str(detail))
            raise RuntimeError(f"Telnyx transfer returned HTTP {status}: {detail}")
        data = payload.get("data") if isinstance(payload, dict) else None
        if not isinstance(data, dict) or data.get("result") != "ok":
            self._audit(call_control_id, dialled, fallback, "failed", reason,
                        "unexpected response")
            raise RuntimeError("Telnyx transfer returned an unexpected response")
        self._audit(call_control_id, dialled, fallback, "succeeded", reason)


class StoreTransferAudit:
    """Write transfer outcomes into Cherry's existing operations event log."""

    def __init__(self, store: Any) -> None:
        self.store = store

    def __call__(self, *, call_control_id: str, dialled: str, fallback: str,
                 status: str, reason: str, detail: str = "") -> None:
        session = self.store.conn.execute(
            "SELECT id, restaurant_id FROM session WHERE external_id=? "
            "ORDER BY started_at DESC LIMIT 1", (call_control_id,)).fetchone()
        self.store.log_event(
            f"voice.handoff_{status}",
            restaurant_id=session["restaurant_id"] if session else None,
            session_id=session["id"] if session else None,
            detail={"dialled": dialled, "fallback": fallback,
                    "provider": "telnyx", "reason": reason,
                    "detail": detail})
