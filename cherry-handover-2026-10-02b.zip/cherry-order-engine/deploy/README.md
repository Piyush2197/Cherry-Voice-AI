# Deployment kit: Hostinger VPS

Everything here is ready to copy onto a fresh Ubuntu VPS. It is **not proven on
Hostinger** (no server was available); what *was* verified is marked below.
Do the steps in order; each ends with a check.

| Piece | Verified how |
|---|---|
| Postgres point-in-time recovery recipe | Run for real on PostgreSQL 16 (`postgres/pitr_recipe_test.sh`): restored to the moment the table held 200 of 300 rows |
| `cherry.env.example` names | `python3 deploy/check_env_names.py` (every name is read by the code; no inline comments, which systemd would keep in the value) |
| `run-job.sh` + `job_failed.py` | Failing job returns its exit code and pages via the alert channels; page wording tested |
| systemd units, nginx, cron, compose | Syntax only (`systemd-analyze verify`, YAML parse). **Not run.** Run `nginx -t`, `docker compose config`, and a real boot |

## 0. Server basics
1. Ubuntu VPS, create user `cherry`, add it to the `docker` group. `ufw allow 22,80,443/tcp`, deny everything else. **Ports 8080, 8090, 5432 must not be reachable from outside** (the Python servers bind to all interfaces; the firewall is what keeps them private).
2. `apt install nginx certbot docker.io docker-compose-v2 rclone python3-venv`, plus the PostgreSQL **16** client (`postgresql-client-16`, from the PGDG apt repository on Ubuntu releases that ship an older one): the nightly backup and the restore drill run the host's `pg_dump`/`pg_restore`, which refuse to talk to a newer server. Python must be 3.9 or newer.
3. Copy the repo to `/opt/cherry`; `python3 -m venv .venv && .venv/bin/pip install -r requirements-postgres.txt`.
4. `mkdir -p /etc/cherry /var/lib/cherry/secrets /var/lib/cherry/briefs /var/lib/cherry/backups /var/log/cherry`; `chown -R cherry /var/lib/cherry /var/log/cherry`; `chmod 700 /var/lib/cherry/secrets`. (The nightly brief writes to `/var/lib/cherry/briefs`; `/opt/cherry` is not writable by `cherry`.)

## 1. Database (`postgres/`)
1. `cp db.env.example db.env` (real password); `mkdir wal-archive backups && chown 999:999 wal-archive backups`; `docker compose up -d`.
2. Put the URL in `/etc/cherry/cherry.env` as `CHERRY_DATABASE_URL`. `cd /opt/cherry && set -a && . /etc/cherry/cherry.env && set +a && .venv/bin/python production_db.py bootstrap && .venv/bin/python production_db.py verify`. **Check:** verify prints `"ok": true` and the schema version, with no error.
3. Create `/etc/cherry/offsite.env` with `OFFSITE=remote:bucket` (an `rclone config` remote on storage OFF this server). Run `postgres/base-backup.sh` once by hand. **Check:** files appear in the bucket.
4. Run the point-in-time restore drill in `postgres/RESTORE_PITR.md`, and the logical drill in `DATABASE.md`. **Check:** you have written down the date and row counts.
5. Disk: the local `wal-archive/` grows forever. Prune what is older than your oldest kept base backup (`pg_archivecleanup`) or monitor free disk. Not automated here.

## 2. Secrets and config
`cp cherry.env.example /etc/cherry/cherry.env; chmod 600 /etc/cherry/cherry.env; chown cherry /etc/cherry/cherry.env`. Fill it in. `python3 deploy/check_env_names.py` before you start. The variable names come from `deployments/pilot-locations.yaml` (Tamago's are `CHERRY_INBOUND_TAMAGO_HALL_RD` and `CHERRY_DIRECT_FALLBACK_TAMAGO_HALL_RD`); `check_env_names.py` fails if the template and the manifest disagree. Leave a location's lines EMPTY until you have its numbers: an empty DID is skipped, but a malformed one stops the gateway starting for every restaurant. Server and cron both need `CHERRY_CHECKOUT_HANDOFF_ONLY=1` in this launch mode, or every paid order raises a CRITICAL page.

## 3. Services and TLS
1. `cp systemd/*.service /etc/systemd/system/; systemctl daemon-reload; systemctl enable --now cherry-server cherry-gateway`.
2. nginx: edit the hostname in `nginx/cherry.conf`, obtain the certificate, `nginx -t`, reload. **Check:** `curl https://HOST/health` is 200; `curl https://HOST/v1/calls` is 404 (private paths are not exposed). Also `curl -o /dev/null -w '%{http_code}' https://HOST/t/1234` is 404 (the four-digit ticket route must stay private) and `https://HOST/kds` is 403 without a device key (`python3 cherry.py kds <restaurant-id> --base-url https://HOST` prints a tablet's URL). `test_nginx_routes.py` checks the config's routes without nginx; it does not replace `nginx -t`.
3. Point the Telnyx SMS webhook, Square webhook and Square OAuth redirect at the public paths in `nginx/cherry.conf`. (Clover's redirect is `/v1/oauth/clover/callback`; only needed when a Clover location exists.)

## 4. Scheduler
`cp cron/cherry.cron /etc/cron.d/cherry`. **Check:** wait 2 minutes, `journalctl`/syslog shows the alerts job; deliberately break a job (wrong path) and confirm the phone is paged.

## What is not in the kit
Real credentials; provider accounts; the Inworld adapter; anything that needs Inworld SIP access. Bun N Run/Toast is parked (owner waits on Toast API access). Tamago's POS is EPIPay (owner, 2026-09-29), not Square; the location stays `manual_fallback` — not in the Square jobs, no phone traffic — until an EPIPay integration exists. Direct staff lines: each restaurant's existing phone line (owner decision); it must not forward into Cherry. See `OWNER_DECISIONS_2026-09-29.md`.
