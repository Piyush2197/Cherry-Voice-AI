import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'
import { SESSION_COOKIE, verifySession } from './lib/session'

// Paths that require authentication. A page sends the visitor to /login; an
// API path answers 401 JSON.
const protectedPaths = ['/admin', '/dashboard', '/api/protected', '/api/cherry']

// Paths that should be accessible without auth
const publicPaths = ['/login', '/api/auth/login', '/api/auth/logout']

const under = (pathname: string, base: string) =>
  pathname === base || pathname.startsWith(base + '/')

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl

  // Allow public paths
  if (publicPaths.some((path) => under(pathname, path))) {
    return NextResponse.next()
  }

  if (!protectedPaths.some((path) => under(pathname, path))) {
    return NextResponse.next()
  }

  // A cookie that merely exists proves nothing: verify the signature, issuer,
  // audience and expiry. With no JWT_SECRET configured nothing verifies, so
  // everything protected stays closed.
  const token = request.cookies.get(SESSION_COOKIE)?.value
  const user = token ? await verifySession(token) : null
  if (user) {
    return NextResponse.next()
  }

  if (pathname.startsWith('/api/')) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }
  const loginUrl = new URL('/login', request.url)
  loginUrl.searchParams.set('redirect', pathname)
  return NextResponse.redirect(loginUrl)
}

export const config = {
  matcher: [
    /*
     * Match all request paths except:
     * - api routes that start with /api/auth
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - public folder
     */
    '/((?!api/auth|_next/static|_next/image|favicon.ico|public).*)',
  ],
}
