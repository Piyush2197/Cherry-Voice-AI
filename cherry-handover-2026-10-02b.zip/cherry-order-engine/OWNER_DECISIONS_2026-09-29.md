# Owner decisions — 2026-09-29

Recorded by the owner in one pass. Every open owner item from
`DEVELOPER_BEFORE_POS_API_2026-09-28.md`, `TASKS.md` and `GAPS_2026-09-28.md`
is decided here; nothing on the owner list is waiting on the owner any more.

## 1. Tamago Sushi Bowl — POS identified: EPIPay

The restaurant is open and takes web orders through EPIPay:
`https://www.epipay.com/tamagomi/en/WebOrder?STORE_CODE=MTAwMA==&table_num=MTAwMA==`
(`MTAwMA==` is base64 for store code `1000`).

- The location list keeps Tamago at `manual_fallback` — it has **no Cherry
  checkout** and **cannot take phone traffic** until an EPIPay integration
  exists. That is unchanged behaviour, now with a named cause.
- First question for the developer's POS work: **does EPIPay expose any API**
  (hosted checkout link, order API, webhook)? Nothing in this repo knows.
  Until that is answered, EPIPay integration is feasibility-unknown.
- Its menu for Cherry would come from the same source the web order page uses.

## 2. Bun N Run — waiting on Toast API access

Decision: Bun N Run stays on Toast and Cherry waits until the owner receives
**Toast account API access**. No Square account will be created for them and
no other checkout provider is chosen. Parked; nothing to build until the
credentials arrive. The existing guard still applies: a Toast Orders bridge is
a menu/catalog source, not a payment checkout — when the API access arrives,
the work is an itemized checkout provider.

## 3. Remake/refund — no separate policy; the payment link is the check

The owner declined a remake/refund policy document and liability cap. The
reasoning: after an order is placed, the customer receives the itemized SMS
payment link, **checks the order and total themselves, and only then pays**;
after payment it is POS handover and Cherry's part is done.

Accepted as the product position. Two facts stay on the record:

- This holds only while checkout is payment-gated handoff
  (`CHERRY_CHECKOUT_HANDOFF_ONLY=1`, the launch mode). Any future automatic
  release on payment must revisit this.
- It settles the customer side. If a caller says "I ordered 12, not 2" after
  paying, the call transcript is the evidence; how that lands with the
  restaurant is between the owner and the restaurant in the sales contract.

## 4. Direct staff line — each restaurant's existing phone line

Cheapest and easiest: the transfer target is the phone the restaurant already
answers. Unchanged hard constraint: that number must not forward into Cherry —
it must differ from the published number and every Telnyx DID, or a transferred
call loops back into the bot. Developer verifies no loop once in a live
transfer and sets `CHERRY_REQUIRE_DIRECT_FALLBACK=1` +
`CHERRY_DIRECT_FALLBACK_<LOCATION>` per location.

## 5. Pink Garlic — signoff done, Square confirmed

Pink Garlic **Oak Park and Allen Park** menus and prices are signed off
(2026-09-29), and the owner confirms both are Square merchants. They are the
first candidates for `square_oauth.py authorize-url` as soon as the developer's
Square app exists (Phase 6). At the counter, current tax/hours still get a
glance before the acceptance call — signoff covers prices and menu content.

## 6. Inworld — wait for SIP access

Confirmed: Phase 3 waits on Inworld. No surrogate work is planned.

## 7. Developer deployment — waiting on the developer

Phases 0–6 of `DEVELOPER_BEFORE_POS_API_2026-09-28.md` are the developer's
work list, ready to execute (deployment kit in `deploy/`, start at
`deploy/README.md`).
