#!/usr/bin/env python3
"""Checks for safe multi-location deployment preflight and application."""

from __future__ import annotations

import tempfile
import traceback
from pathlib import Path

import pilot_deploy as pd
from order_store import OrderStore


_passed = _failed = 0


def check(name, condition, detail=""):
    global _passed, _failed
    if condition:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


def t_manifest_has_all_requested_storefronts() -> None:
    rows = pd.load_manifest()
    check("there are seven requested storefronts", len(rows) == 7, str(rows))
    check("Bun N Run is two separate locations",
          len([x for x in rows if x.group == "bun-n-run"]) == 2)
    check("Pink Garlic is three separate locations",
          len([x for x in rows if x.group == "pink-garlic"]) == 3)
    check("every storefront has its own inbound setting",
          len({x.inbound_env for x in rows}) == len(rows))
    check("every storefront has a human fallback number",
          all(x.fallback_phone.startswith("+1") for x in rows))


def t_known_menus_match_their_location_ids() -> None:
    for loc in pd.load_manifest():
        if loc.catalog_status == "ready":
            check(f"{loc.id} has no catalog blocker",
                  not pd.blockers(loc, {loc.inbound_env: "+13135550100"},
                                  require_inbound=True), loc.id)


def t_pink_garlic_group_is_deployable_without_native_pos() -> None:
    rows = pd.selected(pd.load_manifest(), ["pink-garlic"])
    env = {x.inbound_env: f"+13135550{n:03d}" for n, x in enumerate(rows)}
    with tempfile.TemporaryDirectory() as tmp:
        db = str(Path(tmp) / "pilot.db")
        rc = pd.apply(rows, db, env)
        check("the three-location group deploys through manual fallback", rc == 0, str(rc))
        store = OrderStore.sqlite(db)
        count = store.conn.execute("SELECT count(*) AS n FROM restaurant").fetchone()["n"]
        check("all three Pink Garlic locations are deployed separately",
              count == 3, str(count))


def t_checkout_gate_blocks_manual_only_and_missing_provider_secrets() -> None:
    loc = pd.selected(pd.load_manifest(), ["bun-n-run-ferndale"])[0]
    env = {loc.inbound_env: "+13135550777"}
    with tempfile.TemporaryDirectory() as tmp:
        db = str(Path(tmp) / "pilot.db")
        check("Square activation refuses missing credentials without writes",
              pd.apply([loc], db, env, sink="square") == 2)
        check("failed Square preflight leaves database unopened",
              not Path(db).exists())
        pd.apply([loc], db, env)
        check("manual-only location is not checkout ready",
              pd.checkout_ready([loc], db, env) == 2)
        key = loc.id.upper().replace("-", "_")
        env.update({f"SQUARE_TOKEN_{key}": "test-token",
                    f"SQUARE_LOCATION_{key}": "L-TEST",
                    "SQUARE_WEBHOOK_SIGNATURE_KEY": "test-key",
                    "SQUARE_WEBHOOK_URL": "https://example.test/webhook",
                    "TELNYX_API_KEY": "test-telnyx",
                    "TELNYX_FROM_NUMBER": "+13135550111"})
        check("credentialed Square configuration can be applied",
              pd.apply([loc], db, env, sink="square") == 0)
        check("checkout preflight sees the per-location sink and secrets",
              pd.checkout_ready([loc], db, env) == 0)


def t_ready_location_deploys_with_its_own_numbers() -> None:
    loc = pd.selected(pd.load_manifest(), ["tamago-sushi-bowl"])[0]
    inbound = "+13135550777"
    with tempfile.TemporaryDirectory() as tmp:
        db = str(Path(tmp) / "pilot.db")
        rc = pd.apply([loc], db, {loc.inbound_env: inbound})
        store = OrderStore.sqlite(db)
        row = store.restaurant_for_number(inbound)
        check("a ready selected location deploys", rc == 0, str(rc))
        check("the inbound number routes to Tamago",
              row is not None and row["id"] == loc.id, str(dict(row)) if row else "")
        check("the human fallback is the restaurant phone",
              row is not None and row["staff_phone"] == loc.fallback_phone)
        check("the deployed menu has all 120 items",
              store.load_live_config(loc.id)[0].items.__len__() == 120)


def t_verify_proves_routing_menu_and_fallback() -> None:
    loc = pd.selected(pd.load_manifest(), ["tamago-sushi-bowl"])[0]
    inbound = "+13135550778"
    env = {loc.inbound_env: inbound}
    with tempfile.TemporaryDirectory() as tmp:
        db = str(Path(tmp) / "pilot.db")
        pd.apply([loc], db, env)
        check("a correctly deployed location verifies",
              pd.verify([loc], db, env) == 0)

        store = OrderStore.sqlite(db)
        store.conn.execute("UPDATE restaurant SET staff_phone=? WHERE id=?",
                           ("+13135550000", loc.id))
        store.conn.commit()
        check("a changed fallback fails verification",
              pd.verify([loc], db, env) == 2)


def t_verify_refuses_missing_database_and_duplicate_numbers() -> None:
    ready = [x for x in pd.load_manifest() if x.catalog_status == "ready"][:2]
    with tempfile.TemporaryDirectory() as tmp:
        missing = str(Path(tmp) / "not-created.db")
        env = {x.inbound_env: "+13135550779" for x in ready}
        check("verify does not create a missing database",
              pd.verify(ready, missing, env) == 2)
        check("missing verification database stays absent",
              not Path(missing).exists())

        db = str(Path(tmp) / "pilot.db")
        OrderStore.sqlite(db)  # verification must inspect an existing database
        duplicated = {x.inbound_env: "+13135550809" for x in ready}
        check("duplicate inbound numbers fail verification",
              pd.verify(ready, db, duplicated) == 2)


def main() -> int:
    for name, fn in sorted(globals().items()):
        if not name.startswith("t_"):
            continue
        try:
            fn()
        except Exception:
            global _failed
            _failed += 1
            print(f"\n--- FAIL {name}\n{traceback.format_exc()}")
    print(f"\n{_passed} passed, {_failed} failed (pilot deployment plan)")
    return 1 if _failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
