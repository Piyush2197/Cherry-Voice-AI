"""Provider-neutral guest workflows.

Reservations are deliberately requests, not instant confirmations. Cherry has
no live table inventory, pacing, deposits or no-show rules, so only restaurant
staff can confirm that a table is booked.
"""
from __future__ import annotations

import re
import uuid
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional, Protocol
from zoneinfo import ZoneInfo

from order_store import json_value

PHONE_RE = re.compile(r"\+[1-9]\d{7,14}")
DEFAULT_RESERVATION_POLICY = {
    "enabled": False, "mode": "request_only", "max_party_size": 12,
    "min_notice_minutes": 60, "max_advance_days": 90,
}


@dataclass(frozen=True)
class Address:
    line1: str
    city: str
    state: str
    postal_code: str
    line2: str = ""

    def validate(self) -> None:
        if not self.line1.strip() or not self.city.strip():
            raise ValueError("street and city are required")
        if not re.fullmatch(r"[A-Za-z]{2}", self.state.strip()):
            raise ValueError("two-letter state is required")
        if not re.fullmatch(r"\d{5}(?:-\d{4})?", self.postal_code.strip()):
            raise ValueError("valid US ZIP is required")


@dataclass(frozen=True)
class DeliveryQuote:
    deliverable: bool
    fee_cents: int = 0
    eta_minutes: Optional[int] = None
    reason: str = ""


class DeliveryProvider(Protocol):
    def quote(self, restaurant_id: str, address: Address) -> DeliveryQuote: ...


def quote_delivery(store, restaurant_id: str, address: Address,
                   provider: DeliveryProvider) -> DeliveryQuote:
    address.validate()
    quote = provider.quote(restaurant_id, address)
    if quote.fee_cents < 0 or (quote.deliverable and quote.eta_minutes is None):
        raise ValueError("invalid delivery-provider quote")
    store.log_event("delivery.quoted", restaurant_id=restaurant_id,
                    detail={"deliverable": quote.deliverable,
                            "fee_cents": quote.fee_cents,
                            "eta_minutes": quote.eta_minutes,
                            "reason": quote.reason})
    return quote


def set_reservation_policy(store, restaurant_id: str, *, enabled: bool,
                           max_party_size: int = 12,
                           min_notice_minutes: int = 60,
                           max_advance_days: int = 90,
                           updated_by: str = "operator") -> Dict[str, Any]:
    if not 1 <= int(max_party_size) <= 100:
        raise ValueError("max party size must be 1-100")
    if int(min_notice_minutes) < 0:
        raise ValueError("minimum notice cannot be negative")
    if not 1 <= int(max_advance_days) <= 365:
        raise ValueError("maximum advance window must be 1-365 days")
    with store.tx() as conn:
        conn.execute("""INSERT INTO reservation_policy
            (restaurant_id,enabled,mode,max_party_size,min_notice_minutes,
             max_advance_days,updated_by,updated_at)
            VALUES (?,?,'request_only',?,?,?,?,CURRENT_TIMESTAMP)
            ON CONFLICT(restaurant_id) DO UPDATE SET
              enabled=excluded.enabled,max_party_size=excluded.max_party_size,
              min_notice_minutes=excluded.min_notice_minutes,
              max_advance_days=excluded.max_advance_days,
              updated_by=excluded.updated_by,updated_at=CURRENT_TIMESTAMP""",
            (restaurant_id, bool(enabled), int(max_party_size),
             int(min_notice_minutes), int(max_advance_days), updated_by))
    store.log_event("reservation.policy_updated", restaurant_id=restaurant_id,
                    detail={"enabled": bool(enabled), "updated_by": updated_by})
    return get_reservation_policy(store, restaurant_id)


def get_reservation_policy(store, restaurant_id: str) -> Dict[str, Any]:
    row = store.conn.execute(
        "SELECT * FROM reservation_policy WHERE restaurant_id=?",
        (restaurant_id,)).fetchone()
    if row is None:
        return dict(DEFAULT_RESERVATION_POLICY)
    return {"enabled": bool(row["enabled"]), "mode": row["mode"],
            "max_party_size": int(row["max_party_size"]),
            "min_notice_minutes": int(row["min_notice_minutes"]),
            "max_advance_days": int(row["max_advance_days"])}


def _parse_time(value: str, tz_name: str = "") -> datetime:
    """An ISO 8601 date-time. With no UTC offset it is the RESTAURANT's local
    time: the voice model is never told the restaurant's timezone, so "7 pm
    Friday" arrives as 2026-10-02T19:00:00 and used to be refused outright
    (or, worse, booked at the wrong hour if the model guessed an offset)."""
    try:
        when = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except (TypeError, ValueError) as exc:
        raise ValueError("reservation time must be ISO 8601") from exc
    if when.tzinfo is None:
        if not tz_name:
            raise ValueError("reservation time must include timezone")
        when = when.replace(tzinfo=ZoneInfo(tz_name))
    return when


def _restaurant_tz(store, restaurant_id: str) -> str:
    rest = store.restaurant(restaurant_id)
    return (rest["timezone"] if rest is not None else "") or "UTC"


def _open_at(store, restaurant_id: str, when: datetime) -> bool:
    rest = store.restaurant(restaurant_id)
    if rest is None:
        raise LookupError("restaurant not found")
    row = store.conn.execute(
        "SELECT weekly_hours,holiday_closures FROM restaurant_control "
        "WHERE restaurant_id=?", (restaurant_id,)).fetchone()
    if row is None:
        return True
    local = when.astimezone(ZoneInfo(rest["timezone"] or "UTC"))
    if local.date().isoformat() in set(json_value(row["holiday_closures"]) or []):
        return False
    weekly = json_value(row["weekly_hours"]) or {}
    if not weekly:
        return True                       # hours not configured
    hours = weekly.get(local.strftime("%a").lower())
    if not hours:
        return False                      # configured, and this day is not in it
    sh, sm = map(int, hours[0].split(":"))
    eh, em = map(int, hours[1].split(":"))
    minute, start, end = local.hour * 60 + local.minute, sh * 60 + sm, eh * 60 + em
    return start <= minute < end if end > start else (minute >= start or minute < end)


def create_reservation(store, restaurant_id: str, *, guest_name: str,
                       guest_phone: str, party_size: int, reserved_at: str,
                       notes: str = "", now: Optional[datetime] = None) -> str:
    """Low-level insert retained for back-office and existing callers."""
    name, phone = str(guest_name).strip(), str(guest_phone).strip()
    if not name:
        raise ValueError("guest name is required")
    if not PHONE_RE.fullmatch(phone):
        raise ValueError("guest phone must be E.164")
    if not 1 <= int(party_size) <= 100:
        raise ValueError("party size must be 1-100")
    when = _parse_time(reserved_at, _restaurant_tz(store, restaurant_id))
    if when <= (now or datetime.now(timezone.utc)):
        raise ValueError("reservation must be in the future")
    rid, code = str(uuid.uuid4()), uuid.uuid4().hex[:8].upper()
    with store.tx() as conn:
        conn.execute("""INSERT INTO reservation
          (id,restaurant_id,guest_name,guest_phone,party_size,reserved_at,notes,status,created_at)
          VALUES (?,?,?,?,?,?,?,'requested',CURRENT_TIMESTAMP)""",
          (rid, restaurant_id, name, phone, int(party_size), when.isoformat(),
           str(notes).strip()[:1000]))
        conn.execute("INSERT INTO reservation_reference "
                     "(reservation_id,confirmation_code) VALUES (?,?)",
                     (rid, code))
    store.log_event("reservation.requested", restaurant_id=restaurant_id,
                    detail={"reservation_id": rid, "confirmation_code": code,
                            "party_size": int(party_size),
                            "reserved_at": when.isoformat()})
    return rid


def request_phone_reservation(store, restaurant_id: str, *, guest_name: str,
                              guest_phone: str, party_size: int,
                              reserved_at: str, notes: str = "",
                              now: Optional[datetime] = None) -> Dict[str, Any]:
    policy = get_reservation_policy(store, restaurant_id)
    if not policy["enabled"]:
        raise PermissionError("reservations are not enabled for this location")
    when = _parse_time(reserved_at, _restaurant_tz(store, restaurant_id))
    current = now or datetime.now(timezone.utc)
    if int(party_size) > policy["max_party_size"]:
        raise ValueError(f"party size exceeds this location's limit of {policy['max_party_size']}")
    if when < current + timedelta(minutes=policy["min_notice_minutes"]):
        raise ValueError(f"this location requires {policy['min_notice_minutes']} minutes notice")
    if when > current + timedelta(days=policy["max_advance_days"]):
        raise ValueError(f"reservations can only be requested {policy['max_advance_days']} days ahead")
    if not _open_at(store, restaurant_id, when):
        raise ValueError("the restaurant is closed at that time")
    rid = create_reservation(store, restaurant_id, guest_name=guest_name,
                             guest_phone=guest_phone, party_size=party_size,
                             reserved_at=when.isoformat(), notes=notes, now=current)
    ref = store.conn.execute(
        "SELECT confirmation_code FROM reservation_reference WHERE reservation_id=?",
        (rid,)).fetchone()
    return {"reservation_id": rid, "confirmation_code": ref["confirmation_code"],
            "status": "requested", "reserved_at": when.isoformat(),
            "party_size": int(party_size)}


_TRANSITIONS = {
    "requested": {"confirmed", "declined", "cancelled"},
    "confirmed": {"cancelled", "seated"}, "seated": {"completed"},
    "declined": set(), "cancelled": set(), "completed": set(),
}


def update_reservation(store, reservation_id: str, status: str, *,
                       by: str = "operator") -> None:
    if status not in _TRANSITIONS:
        raise ValueError("invalid reservation status")
    row = store.conn.execute(
        "SELECT restaurant_id,status FROM reservation WHERE id=?",
        (reservation_id,)).fetchone()
    if row is None:
        raise LookupError("reservation not found")
    if status == row["status"]:
        return
    if status not in _TRANSITIONS[row["status"]]:
        raise ValueError(f"cannot change reservation from {row['status']} to {status}")
    with store.tx() as conn:
        conn.execute("UPDATE reservation SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",
                     (status, reservation_id))
    store.log_event("reservation." + status, restaurant_id=row["restaurant_id"],
                    detail={"reservation_id": reservation_id, "by": by})


def reservation_by_code(store, restaurant_id: str, confirmation_code: str,
                        guest_phone: str = ""):
    sql = """SELECT r.*,x.confirmation_code FROM reservation r
             JOIN reservation_reference x ON x.reservation_id=r.id
             WHERE r.restaurant_id=? AND x.confirmation_code=?"""
    params = [restaurant_id, str(confirmation_code).strip().upper()]
    if guest_phone:
        sql += " AND r.guest_phone=?"
        params.append(str(guest_phone).strip())
    return store.conn.execute(sql, tuple(params)).fetchone()


def cancel_phone_reservation(store, restaurant_id: str, *,
                             confirmation_code: str,
                             guest_phone: str) -> Dict[str, Any]:
    row = reservation_by_code(store, restaurant_id, confirmation_code, guest_phone)
    if row is None:
        raise LookupError("reservation request not found")
    update_reservation(store, row["id"], "cancelled", by="guest")
    return {"reservation_id": row["id"],
            "confirmation_code": row["confirmation_code"],
            "status": "cancelled"}


RESERVATION_TOOL_SCHEMAS = [
    {"name": "request_reservation",
     "description": "Submit a reservation request. The restaurant must confirm it; never promise a table.",
     "parameters": {"type": "object", "properties": {
         "guest_name": {"type": "string", "description": "Name for the reservation."},
         "party_size": {"type": "integer", "minimum": 1, "description": "Number of guests."},
         "reserved_at": {"type": "string", "description": "ISO 8601 date/time with UTC offset."},
         "guest_phone": {"type": "string", "description": "E.164 phone only if caller ID is unavailable."},
         "notes": {"type": "string", "description": "Accessibility or seating request; never imply a guarantee."}},
      "required": ["guest_name", "party_size", "reserved_at"]}},
    {"name": "cancel_reservation",
     "description": "Cancel a reservation request using the confirmation code sent to the guest.",
     "parameters": {"type": "object", "properties": {
         "confirmation_code": {"type": "string", "description": "The eight-character confirmation code."},
         "guest_phone": {"type": "string", "description": "E.164 phone only if caller ID is unavailable."}},
      "required": ["confirmation_code"]}},
]
