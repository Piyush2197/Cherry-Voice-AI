#!/usr/bin/env python3
"""
The Inworld event adapter — the translation between Inworld and the engine.

`voice_gateway.py` fixes the contract and `voice/inworld_bridge.py` implements
it, but neither reads an Inworld payload. This suite covers the piece that does,
and it concentrates on the two things that decide whether a live call survives
first contact with a real provider:

  1. Field names. Inworld's exact names are still unconfirmed, so every one of
     them is read through `Dialect`. These tests prove that changing a name is a
     configuration change and nothing else.
  2. Silence. A dropped `call_started` is a caller hearing nothing; a dropped
     `tool_call` is an order that never happens. Every unrecognised shape must
     raise, loudly, with a message that says which knob to turn.

The fake transport is imported from `test_voice.py` rather than copied — a third
copy of it would be exactly the redundancy this repository is being audited for.
"""

from __future__ import annotations

import asyncio
import json
import os

from test_voice import FakeTransport
from voice.inworld_bridge import CherryBridge

from inworld_adapter import (
    CallEvent,
    Dialect,
    InworldAdapter,
    UnknownEvent,
    UnknownTool,
    main as adapter_main,
    normalize_event,
    split_events,
)

_passed = _failed = 0


def check(name, condition, detail=""):
    global _passed, _failed
    if condition:
        _passed += 1
    else:
        _failed += 1
        print(f"  FAIL {name}" + (f" — {detail}" if detail else ""))


def raises(fn, exc=UnknownEvent):
    try:
        fn()
    except exc as e:
        return str(e)
    except Exception as e:                             # noqa: BLE001
        return f"WRONG EXCEPTION {type(e).__name__}: {e}"
    return ""


def bridge(tx=None):
    return CherryBridge("https://test.invalid/", "secret",
                        transport=tx or FakeTransport())


# ---------------------------------------------------------------------------
# Dialect — the only place field names live
# ---------------------------------------------------------------------------


def t_default_dialect_reads_the_documented_shape():
    d = Dialect()
    check("type field", d.type_field == "type")
    check("call id field", d.call_id_field == "call_id")
    check("dialled field", d.dialled_field == "to")
    check("tool types include the common spellings",
          "tool_call" in d.tool_types and "function_call" in d.tool_types)


def t_every_field_name_is_env_overridable():
    """The whole point: an unknown schema costs a variable, not a code change."""
    keys = {
        "CHERRY_INWORLD_TYPE_FIELD": "event_type",
        "CHERRY_INWORLD_CALL_ID_FIELD": "conversation_id",
        "CHERRY_INWORLD_DIALLED_FIELD": "called_number",
        "CHERRY_INWORLD_CALLER_FIELD": "caller_id",
        "CHERRY_INWORLD_TOOL_FIELD": "function",
        "CHERRY_INWORLD_ARGS_FIELD": "parameters",
    }
    saved = {k: os.environ.get(k) for k in keys}
    try:
        os.environ.update(keys)
        d = Dialect.from_env()
        check("type renamed", d.type_field == "event_type")
        check("call id renamed", d.call_id_field == "conversation_id")
        check("dialled renamed", d.dialled_field == "called_number")
        check("tool renamed", d.tool_field == "function")
        check("args renamed", d.args_field == "parameters")

        # And a payload in the NEW names normalises with no other change.
        ev = normalize_event({"event_type": "call_started",
                              "conversation_id": "c1",
                              "called_number": "+12485550111",
                              "caller_id": "+12485551234"}, d)
        check("renamed payload normalises", ev.kind == "call_started"
              and ev.call_id == "c1" and ev.dialled == "+12485550111", str(ev))
    finally:
        for k, v in saved.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v


# ---------------------------------------------------------------------------
# Normalising events
# ---------------------------------------------------------------------------


def t_started_event_carries_routing():
    ev = normalize_event({"type": "call_started", "call_id": "c1",
                          "to": "+12485550111", "from": "+12485551234"})
    check("kind", ev.kind == "call_started")
    check("dialled number kept verbatim", ev.dialled == "+12485550111")
    check("caller kept verbatim", ev.caller == "+12485551234")


def t_tool_event_carries_verbatim_arguments():
    ev = normalize_event({"type": "tool_call", "call_id": "c1",
                          "tool": "add_item",
                          "args": {"text": "butter chikn"}})
    check("kind", ev.kind == "tool_call")
    check("tool name", ev.tool == "add_item")
    check("caller words are not cleaned up",
          ev.args["text"] == "butter chikn", str(ev.args))


def t_tool_arguments_may_arrive_as_json_text():
    ev = normalize_event({"type": "tool_call", "call_id": "c1",
                          "tool": "add_item", "args": '{"text": "naan"}'})
    check("JSON string decoded", ev.args == {"text": "naan"}, str(ev.args))
    check("bad JSON is refused",
          "not valid JSON" in raises(lambda: normalize_event(
              {"type": "tool_call", "call_id": "c1", "tool": "t",
               "args": "{oops"})))


def t_tool_may_be_nested_as_an_object():
    ev = normalize_event({"type": "function_call", "call_id": "c1",
                          "tool": {"name": "read_back"}})
    check("nested tool name read", ev.tool == "read_back", str(ev))


def t_ended_and_handoff_events():
    end = normalize_event({"type": "call_ended", "call_id": "c1"})
    check("ended kind", end.kind == "call_ended")
    check("default reason", end.reason == "caller_hung_up")
    ho = normalize_event({"type": "handoff", "call_id": "c1",
                          "reason": "caller asked for a person"})
    check("handoff kind", ho.kind == "handoff")
    check("handoff reason kept", ho.reason == "caller asked for a person")


def t_unrecognised_events_are_loud():
    """Never a silent no-op: a dropped event is a silent caller."""
    msg = raises(lambda: normalize_event({"type": "call_paused",
                                          "call_id": "c1"}))
    check("unknown type raises", bool(msg), msg)
    check("message names the field to change",
          "CHERRY_INWORLD_TYPE_FIELD" in msg, msg)
    check("message lists what IS known", "call_started" in msg, msg)

    msg = raises(lambda: normalize_event({"call_id": "c1"}))
    check("missing type raises", bool(msg), msg)

    msg = raises(lambda: normalize_event({"type": "call_started"}))
    check("missing call id raises", bool(msg), msg)
    check("and names its field", "CHERRY_INWORLD_CALL_ID_FIELD" in msg, msg)

    msg = raises(lambda: normalize_event({"type": "call_started",
                                          "call_id": "c1"}))
    check("started with no dialled number raises", bool(msg), msg)
    check("because Cherry routes by DID", "routes calls by the DID" in msg, msg)

    msg = raises(lambda: normalize_event({"type": "tool_call",
                                          "call_id": "c1"}))
    check("tool event with no tool raises", bool(msg), msg)


def t_payload_shapes_are_all_accepted():
    one = {"type": "call_ended", "call_id": "c1"}
    check("a single event", len(split_events(one)) == 1)
    check("a bare list", len(split_events([one, one])) == 2)
    check("a wrapper with events", len(split_events({"events": [one, one]})) == 2)
    check("a wrapper with data", len(split_events({"data": [one]})) == 1)
    check("non-objects are refused",
          bool(raises(lambda: split_events("nope"))))


# ---------------------------------------------------------------------------
# Driving the engine
# ---------------------------------------------------------------------------


def t_a_whole_call_runs_from_events():
    async def run():
        tx = FakeTransport()
        a = InworldAdapter(bridge(tx))
        await a.load_tools()
        check("tools loaded from Cherry", a.tool_names is not None
              and "add_item" in a.tool_names)

        said = await a.dispatch(CallEvent(kind="call_started", call_id="c1",
                                          dialled="+12485550001",
                                          caller="+15550001"))
        check("greeting is spoken", "Thanks for calling" in said, said)

        said = await a.dispatch(CallEvent(
            kind="tool_call", call_id="c1", tool="add_item",
            args={"text": "double cheeseburger"}))
        check("tool reply is verbatim", said.startswith("VERBATIM add_item"), said)
        check("caller words survive the hop",
              "double cheeseburger" in said, said)

        await a.dispatch(CallEvent(kind="call_ended", call_id="c1"))
        check("abandon reaches Cherry",
              any(u.endswith("/abandon") for _, u, _, _, _ in tx.requests),
              str([u for _, u, _, _, _ in tx.requests]))
    asyncio.run(run())


def t_unknown_tool_is_refused_before_cherry():
    async def run():
        tx = FakeTransport()
        a = InworldAdapter(bridge(tx))
        await a.load_tools()
        before = len(tx.requests)
        try:
            await a.dispatch(CallEvent(kind="tool_call", call_id="c1",
                                       tool="delete_everything"))
            check("unknown tool raises", False, "no exception")
        except UnknownTool as exc:
            check("unknown tool raises", True)
            check("and says how many tools are known", "loaded)" in str(exc),
                  str(exc))
        check("nothing was sent to Cherry", len(tx.requests) == before,
              f"{len(tx.requests) - before} request(s) leaked")
    asyncio.run(run())


def t_tool_list_is_loaded_lazily_and_failure_is_survivable():
    """The gateway must start even while Cherry is restarting."""
    async def run():
        tx = FakeTransport()
        tx.fail = True
        a = InworldAdapter(bridge(tx))
        await a.ensure_tools()          # must not raise
        check("a failed load leaves the guard open, not the gateway down",
              a.tool_names is None)
    asyncio.run(run())


def t_batch_reports_per_payload_and_survives_a_bad_event():
    async def run():
        tx = FakeTransport()
        a = InworldAdapter(bridge(tx))
        out = await a.handle_payload({"events": [
            {"type": "call_started", "call_id": "c1",
             "to": "+12485550001", "from": "+15550001"},
            {"type": "something_new", "call_id": "c1"},
            {"type": "tool_call", "call_id": "c1", "tool": "add_item",
             "args": {"text": "fries"}},
        ]})
        check("the batch is not ok, because one event was refused",
              out["ok"] is False)
        check("the bad event is reported with a reason",
              out["errors"] and "CHERRY_INWORLD_TYPE_FIELD" in out["errors"][0],
              str(out.get("errors")))
        check("the good events still ran", out["events"] == 2,
              str(out["events"]))
        check("the caller still hears the order",
              out["spoken"] and "VERBATIM add_item" in out["spoken"][-1],
              str(out["spoken"]))
        check("say is the last line", out["say"] == out["spoken"][-1])
    asyncio.run(run())


def t_payload_counts_are_per_call_not_lifetime():
    async def run():
        tx = FakeTransport()
        a = InworldAdapter(bridge(tx))
        one = {"type": "call_ended", "call_id": "c1"}
        first = await a.handle_payload(one)
        second = await a.handle_payload(one)
        check("first payload counts 1", first["events"] == 1, str(first))
        check("second payload counts 1, not 2", second["events"] == 1,
              str(second))
    asyncio.run(run())


def t_handoff_reaches_the_bridge():
    async def run():
        seen = []

        async def handoff(call_id, dialled, reason):
            seen.append((call_id, reason))

        tx = FakeTransport()
        b = CherryBridge("https://test.invalid/", "secret", transport=tx,
                         handoff=handoff)
        a = InworldAdapter(b)
        await a.load_tools()
        # A handoff only means something for a call the engine already knows
        # about, so start it first — the same order a real worker produces.
        await a.dispatch(CallEvent(kind="call_started", call_id="c1",
                                   dialled="+12485550001",
                                   caller="+15550001"))
        said = await a.dispatch(CallEvent(kind="handoff", call_id="c1",
                                          reason="caller asked"))
        check("handoff is attempted", said is not None, str(said))
        # The bridge owns the reason it reports for a handoff; the adapter's
        # job is to route the right call to it.
        check("the transfer named the right call",
              [c for c, _ in seen] == ["c1"], str(seen))
    asyncio.run(run())


# ---------------------------------------------------------------------------
# CLI — what you run the day SIP access lands
# ---------------------------------------------------------------------------


def t_cli_dialect_and_check():
    import contextlib
    import io
    import tempfile
    from pathlib import Path

    def run(argv):
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            rc = adapter_main(argv)
        return rc, buf.getvalue()

    rc, out = run(["dialect"])
    check("dialect prints and exits 0", rc == 0)
    check("dialect output is the live mapping",
          json.loads(out)["call_id_field"] == "call_id")

    rc, out = run(["sample"])
    check("sample prints a usable fixture", rc == 0
          and json.loads(out)[0]["type"] == "call_started")

    rc, out = run(["check"])
    check("check understands the sample", rc == 0, out)

    with tempfile.TemporaryDirectory() as td:
        good = Path(td) / "good.json"
        good.write_text(json.dumps({"type": "call_ended", "call_id": "c"}))
        rc, out = run(["check", "--file", str(good)])
        check("check accepts a real captured event", rc == 0, out)

        bad = Path(td) / "bad.json"
        bad.write_text(json.dumps({"kind": "call_started", "id": "c"}))
        rc, out = run(["check", "--file", str(bad)])
        check("check fails a payload it cannot read", rc == 1, out)
        check("and says which field to change",
              "CHERRY_INWORLD_TYPE_FIELD" in out, out)


def main():
    tests = [v for k, v in sorted(globals().items())
             if k.startswith("t_") and callable(v)]
    for fn in tests:
        try:
            fn()
        except Exception as exc:                       # noqa: BLE001
            import traceback
            check(f"{fn.__name__} raised", False, repr(exc))
            traceback.print_exc()
    if _failed:
        print(f"{_passed} passed, {_failed} failed (inworld adapter)")
        return 1
    print(f"{_passed} passed, 0 failed (inworld adapter)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
