#!/usr/bin/env python3
"""End-to-end rehearsal: the REAL server and voice gateway over real sockets,
a real database, and stand-in Square and Telnyx endpoints.

It plays whole phone calls through the gateway exactly as the Inworld worker
will, and can make the providers fail on demand. Used by test_rehearsal.py.
Only calls to Square and Telnyx are intercepted; everything else is real.
Run against Postgres by setting CHERRY_TEST_POSTGRES_URL (throwaway DB only).
"""

from __future__ import annotations

import io
import json
import os
import sys
import tempfile
import threading
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

REAL_URLOPEN = urllib.request.urlopen


class FakeProviders:
    def __init__(self):
        self.square, self.sms, self.transfers = [], [], []
        self.square_down = False; self.sms_down = False; self.transfer_down = False
        self.total_override = None
        self.orders = {}
    def __call__(self, req, timeout=None, **kw):
        url = req.full_url if hasattr(req, "full_url") else req
        body = json.loads(req.data) if getattr(req, "data", None) else {}
        m = req.get_method() if hasattr(req, "get_method") else "GET"
        def resp(doc, status=200):
            class R:
                def __init__(s): s.status = status
                def __enter__(s): return s
                def __exit__(s, *a): return False
                def read(s): return json.dumps(doc).encode()
            return R()
        def err(code, doc):
            raise urllib.error.HTTPError(url, code, "x", {}, io.BytesIO(json.dumps(doc).encode()))
        if "squareup" in url:
            self.square.append((m, url, body))
            if self.square_down: err(503, {"errors": [{"code": "SERVICE_UNAVAILABLE"}]})
            if url.endswith("/payment-links") and m == "POST":
                order = body["order"]
                sub = 0
                for li in order["line_items"]:
                    unit = int(li["base_price_money"]["amount"]) + sum(
                        int(m["base_price_money"]["amount"]) * int(m.get("quantity", 1))
                        for m in li.get("modifiers", []))
                    sub += unit * int(li["quantity"])
                pct = sum(float(t["percentage"]) for t in order.get("taxes", []))
                total = sub + int(sub * pct / 100 + 0.5)
                oid = f"SQORD{len(self.orders)+1}"
                self.orders[oid] = {"id": oid, "total_money": {"amount": self.total_override or total, "currency": "USD"}, "_lines": order["line_items"]}
                return resp({"payment_link": {"id": f"PL{len(self.orders)}", "url": f"https://square.link/u/{oid}", "order_id": oid}})
            if "/v2/orders/" in url and m == "GET":
                oid = url.rsplit("/", 1)[1]
                o = self.orders[oid]
                return resp({"order": {"id": oid, "total_money": o["total_money"]}})
            if m == "DELETE": return resp({})
            err(404, {"errors": [{"code": "NOT_FOUND"}]})
        if "api.telnyx.com" in url:
            if "/messages" in url:
                self.sms.append(body)
                if self.sms_down: err(500, {"errors": [{"code": "10001"}]})
                return resp({"data": {"id": f"msg{len(self.sms)}"}})
            if "/actions/transfer" in url:
                self.transfers.append((url, body))
                if self.transfer_down: err(500, {"errors": []})
                return resp({"data": {"result": "ok"}})
        return REAL_URLOPEN(req, timeout=timeout, **kw)


URL = ""
_TEMPLATES: dict = {}
_PG_DEPLOYED: set = set()


class Stack:
    def __init__(self, extra_locations=()):
        """``extra_locations``: (location_id, sink, inbound, direct_fallback)
        deployed alongside Pink Garlic Shelby."""
        self.fake = FakeProviders(); urllib.request.urlopen = self.fake
        global URL
        URL = os.environ.get("CHERRY_TEST_POSTGRES_URL", "").strip()
        self._pg_ready = False
        if URL:
            import psycopg
            with psycopg.connect(URL, autocommit=True) as c:
                if (URL, tuple(extra_locations)) in _PG_DEPLOYED:
                    # Deploying runs the slow menu check; keep the deployed
                    # restaurants and menus and only clear call/order data.
                    c.execute("TRUNCATE session, call_journal, voice_usage, turn, "
                              '"order", order_delivery, order_release, payment, '
                              "sms_message, sms_suppression, event, webhook_receipt "
                              "RESTART IDENTITY CASCADE")
                    self._pg_ready = True
                else:
                    c.execute("DROP SCHEMA public CASCADE"); c.execute("CREATE SCHEMA public")
        else:
            URL = tempfile.mkdtemp() + "/rehearsal.db"
        self._saved_env = dict(os.environ)
        self.vault_dir = tempfile.mkdtemp() + "/v"
        self.env = dict(os.environ)
        self.env.update({
          "CHERRY_DATABASE_URL": URL, "CHERRY_SECRET_DIR": self.vault_dir,
          "CHERRY_INBOUND_PINK_GARLIC_SHELBY": "+12485550111",
          "CHERRY_DIRECT_FALLBACK_PINK_GARLIC_SHELBY": "+15869805199",
          "CHERRY_REQUIRE_DIRECT_FALLBACK": "1", "CHERRY_CHECKOUT_HANDOFF_ONLY": "1",
          "TELNYX_API_KEY": "KEY", "TELNYX_FROM_NUMBER": "+12485550100",
          "CHERRY_API_KEY": "apikey", "CHERRY_VOICE_KEY": "voicekey",
          "SQUARE_WEBHOOK_SIGNATURE_KEY": "sigkey-0123456789",
          "SQUARE_WEBHOOK_URL": "https://cherry.example/v1/webhooks/square/payment"})
        for loc, _sink, inbound, fallback in extra_locations:
            key = loc.upper().replace("-", "_")
            self.env[f"CHERRY_INBOUND_{key}"] = inbound
            self.env[f"CHERRY_DIRECT_FALLBACK_{key}"] = fallback
        os.environ.update(self.env)
        from vault import FileVault
        v = FileVault(self.vault_dir); v.put("SQUARE_TOKEN_PINK_GARLIC_SHELBY","tok"); v.put("SQUARE_LOCATION_PINK_GARLIC_SHELBY","LE6")
        from order_store import OrderStore
        if URL.startswith('postgres') and not self._pg_ready:
            OrderStore.postgres(URL, bootstrap=True).close()
        import pilot_deploy, io, contextlib, shutil
        template = _TEMPLATES.get(tuple(extra_locations))
        if self._pg_ready:
            pass
        elif not URL.startswith("postgres") and template and os.path.exists(template):
            # The deployment menu check is slow (it exercises every item);
            # deploy once per process and copy the resulting database.
            shutil.copy(template, URL)
        else:
            with contextlib.redirect_stdout(io.StringIO()):
                assert pilot_deploy.main(["apply", "--only", "pink-garlic-shelby",
                                          "--sink", "square", "--db", URL]) == 0
            for loc, sink, _inbound, _fallback in extra_locations:
                with contextlib.redirect_stdout(io.StringIO()):
                    assert pilot_deploy.main(["apply", "--only", loc, "--sink", sink,
                                              "--db", URL]) == 0, loc
            if URL.startswith("postgres"):
                _PG_DEPLOYED.add((URL, tuple(extra_locations)))
            else:
                _TEMPLATES[tuple(extra_locations)] = URL + ".template"
                shutil.copy(URL, URL + ".template")
        self.start_server(); self.start_gateway()

    def start_server(self):
        import server as srv, telnyx_sms
        from order_store import OrderStore
        self.store = OrderStore.open(URL)
        sms = telnyx_sms.TelnyxSmsSender(store=self.store)
        self.app = srv.Cherry(self.store, sms=sms, api_key="apikey", checkout_handoff_only=True)
        self.httpd = srv.build_server(self.app, 0)
        self.sport = self.httpd.server_address[1]
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()

    def stop_server(self):
        self.httpd.shutdown(); self.httpd.server_close(); self.store.close()

    def restart_server(self):
        port = self.sport; self.stop_server()
        import server as srv, telnyx_sms
        from order_store import OrderStore
        self.store = OrderStore.open(URL)
        self.app = srv.Cherry(self.store, sms=telnyx_sms.TelnyxSmsSender(store=self.store), api_key="apikey", checkout_handoff_only=True)
        self.httpd = srv.build_server(self.app, port)
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()

    def start_gateway(self):
        import voice_gateway as vg
        env = dict(self.env); env["CHERRY_BASE_URL"] = f"http://127.0.0.1:{self.sport}"
        self.gateway = vg.build_gateway(env)
        self.ghttpd = vg.BoundedThreadingHTTPServer(("127.0.0.1", 0), vg.handler_for(self.gateway))
        self.gport = self.ghttpd.server_address[1]
        threading.Thread(target=self.ghttpd.serve_forever, daemon=True).start()

    def gw(self, method, path, body=None, key="voicekey"):
        req = urllib.request.Request(f"http://127.0.0.1:{self.gport}{path}", method=method,
              data=json.dumps(body).encode() if body is not None else None,
              headers={"X-Voice-Key": key, "Content-Type": "application/json"})
        try:
            with REAL_URLOPEN(req, timeout=30) as r: return r.status, json.loads(r.read())
        except urllib.error.HTTPError as e: return e.code, json.loads(e.read() or b"{}")

    def call(self, cid, to="+12485550111", frm="+13135550123"):
        return self.gw("POST", "/v1/voice/calls", {"call_control_id": cid, "to": to, "from": frm})
    def tool(self, cid, name, **args):
        return self.gw("POST", f"/v1/voice/calls/{cid}/tools/{name}", args)
    def finish(self, cid, name="Sam"):
        return self.gw("POST", f"/v1/voice/calls/{cid}/finish", {"customer_name": name})


    def close(self):
        """Stop both services and restore process-wide state."""
        for srv in (getattr(self, "ghttpd", None), getattr(self, "httpd", None)):
            if srv is not None:
                srv.shutdown(); srv.server_close()
        try:
            self.store.close()
        except Exception:                                   # noqa: BLE001
            pass
        urllib.request.urlopen = REAL_URLOPEN
        os.environ.clear(); os.environ.update(self._saved_env)
