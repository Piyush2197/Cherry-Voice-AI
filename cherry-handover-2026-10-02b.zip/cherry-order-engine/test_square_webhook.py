#!/usr/bin/env python3
import base64,hashlib,hmac,json
from datetime import datetime,timezone
from pathlib import Path
import menu_schema as ms
from order_engine import OrderEngine
from order_store import OrderStore
import square_webhook as sw

HERE=Path(__file__).resolve().parent
def main():
    raw=b'{"event_id":"e"}';key="secret";url="https://x.test/v1/webhooks/square/payment"
    sig=base64.b64encode(hmac.new(key.encode(),url.encode()+raw,hashlib.sha256).digest()).decode();sw.verify(raw,sig,key,url)
    try:sw.verify(raw,"bad",key,url);raise AssertionError("accepted bad signature")
    except sw.SquareWebhookError:pass
    s=OrderStore.sqlite();p=HERE/"menus"/"tamago-sushi-bowl.yaml";c=ms.load_yaml(p);s.upsert_restaurant(c.id,c.name,c.cuisine);mv=s.publish_menu(c.id,p.read_text(),item_count=len(c.items));e=OrderEngine(c);e.add_line("tg_edamame");oid,_=s.place_order(c.id,mv,e.to_normalized_order())
    now=datetime.now(timezone.utc).isoformat();s.conn.execute("INSERT INTO payment (order_id,method,status,amount_cents,pos_payment_ref,updated_at) VALUES (?,'pay_link','link_sent',530,'sq-pay',?)",(oid,now));s.conn.commit()
    event={"event_id":"evt-1","type":"payment.updated","data":{"object":{"payment":{"id":"sq-payment","order_id":"sq-pay","status":"COMPLETED","amount_money":{"amount":530,"currency":"USD"}}}}}
    assert sw.handle(s,event)["action"]=="paid" and sw.handle(s,event)["action"]=="duplicate"
    print("3 passed, 0 failed (Square webhook)");return 0
if __name__=="__main__":raise SystemExit(main())
