"""Role and restaurant-scoped API authorization for operators and services."""

from __future__ import annotations

import hashlib
import hmac
import json
from dataclasses import dataclass
from typing import Dict, FrozenSet, Optional


@dataclass(frozen=True)
class Principal:
    name: str
    role: str
    restaurants: FrozenSet[str]

    @property
    def all_restaurants(self) -> bool:
        return "*" in self.restaurants


ROLE_LEVEL = {"viewer": 1, "operator": 2, "service": 2, "admin": 3}


class AccessPolicy:
    """Keys are hashed immediately; plaintext is never retained or logged."""

    def __init__(self, principals: Dict[str, Principal] = None,
                 legacy_admin_key: str = ""):
        self._principals = principals or {}
        if legacy_admin_key:
            self._principals[self._hash(legacy_admin_key)] = Principal(
                "legacy-service", "admin", frozenset({"*"}))

    @staticmethod
    def _hash(key: str) -> str:
        return hashlib.sha256(key.encode()).hexdigest()

    @classmethod
    def from_json(cls, text: str, *, legacy_admin_key: str = ""):
        principals = {}
        if text:
            doc = json.loads(text)
            if not isinstance(doc, list):
                raise ValueError("CHERRY_API_PRINCIPALS must be a JSON list")
            for row in doc:
                role = str(row.get("role") or "")
                key = str(row.get("key") or "")
                restaurants = frozenset(str(x) for x in row.get("restaurants", []))
                if role not in ROLE_LEVEL or not key or not restaurants:
                    raise ValueError("every API principal needs key, valid role and restaurants")
                principals[cls._hash(key)] = Principal(
                    str(row.get("name") or role), role, restaurants)
        return cls(principals, legacy_admin_key)

    def authenticate(self, key: str) -> Optional[Principal]:
        digest = self._hash(key or "")
        # Compare all digests so lookup timing does not reveal a partial key.
        found = None
        for stored, principal in self._principals.items():
            if hmac.compare_digest(digest, stored): found = principal
        return found

    @property
    def configured(self) -> bool:
        return bool(self._principals)

    @staticmethod
    def permits(principal: Optional[Principal], role: str,
                restaurant_id: str = "") -> bool:
        if principal is None or ROLE_LEVEL.get(principal.role, 0) < ROLE_LEVEL[role]:
            return False
        return (not restaurant_id or principal.all_restaurants or
                restaurant_id in principal.restaurants)


def scope_snapshot(snapshot: dict, principal: Principal) -> dict:
    """Remove other tenants and recompute every displayed aggregate."""
    if principal.all_restaurants:
        return snapshot
    allowed = principal.restaurants
    out = dict(snapshot)
    rows = [r for r in snapshot.get("by_restaurant", [])
            if r.get("restaurant_id") in allowed]
    alerts = [a for a in snapshot.get("alerts", [])
              if a.get("restaurant_id") in allowed]
    calls = sum(int(r.get("calls") or 0) for r in rows)
    orders = sum(int(r.get("orders") or 0) for r in rows)
    out["by_restaurant"] = rows
    out["alerts"] = alerts
    out["engine_issues"] = []  # current feed is fleet-grain; never leak it
    out["catalog_reviews"] = [r for r in snapshot.get("catalog_reviews", [])
                              if r.get("restaurant_id") in allowed]
    out["summary"] = {
        "calls": calls, "orders": orders,
        "conversion_percent": round(orders / calls * 100, 1) if calls else None,
        "revenue_cents": sum(int(r.get("revenue_cents") or 0) for r in rows),
        "escalated_calls": sum(int(r.get("escalations") or 0) for r in rows),
        "abandoned_calls": None, "open_alerts": len(alerts),
    }
    return out
