#!/usr/bin/env python3
"""Plan, apply, or verify the multi-location Cherry pilot deployment.

Examples:
    python3 pilot_deploy.py plan
    python3 pilot_deploy.py verify --db pilot.db
    CHERRY_INBOUND_MIYAZAKI_HALL_RD=+1... \
      python3 pilot_deploy.py apply --db pilot.db --only miyazaki-hall-rd

``apply`` is intentionally strict: the location menu must exist and pass the
same gate as ``cherry.py deploy``, and its own Telnyx inbound number must be in
the named environment variable. Missing data produces no partial deployment.
"""

from __future__ import annotations

import _ensure_deps  # noqa: F401  (re-runs under .venv, or says how to install, if PyYAML is missing)
import argparse
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import yaml

import menu_schema as ms
from cherry import cmd_check
from order_store import OrderStore
from vault import overlay_env


ROOT = Path(__file__).resolve().parent
DEFAULT_MANIFEST = ROOT / "deployments" / "pilot-locations.yaml"


@dataclass(frozen=True)
class Location:
    id: str
    group: str
    name: str
    menu: Optional[Path]
    catalog_status: str
    inbound_env: str
    fallback_phone: str
    pos_type: str
    pos_location_id: str = ""
    note: str = ""
    #: Env var holding the DIRECT staff line. Optional in the manifest; when
    #: absent it is derived from the id. It is declared explicitly wherever the
    #: inbound var was named by hand, because the two then look parallel but are
    #: not — Tamago's inbound is CHERRY_INBOUND_TAMAGO_HALL_RD while its
    #: fallback would silently derive to ..._TAMAGO_SUSHI_BOWL. Setting the
    #: wrong one used to fall back to the PUBLISHED number, which forwards into
    #: Cherry, so a transfer would loop.
    fallback_env: str = ""

    @property
    def fallback_env_name(self) -> str:
        return self.fallback_env or (
            "CHERRY_DIRECT_FALLBACK_" + self.id.upper().replace("-", "_"))


def load_manifest(path: Path = DEFAULT_MANIFEST) -> List[Location]:
    doc = yaml.safe_load(path.read_text())
    if not isinstance(doc, dict) or doc.get("schema_version") != 1:
        raise ValueError("deployment manifest must have schema_version: 1")
    rows = doc.get("locations")
    if not isinstance(rows, list) or not rows:
        raise ValueError("deployment manifest has no locations")

    out, seen = [], set()
    for n, row in enumerate(rows):
        if not isinstance(row, dict):
            raise ValueError(f"locations[{n}] must be a mapping")
        for key in ("id", "group", "name", "catalog_status", "inbound_env",
                    "fallback_phone", "pos_type"):
            if not row.get(key):
                raise ValueError(f"locations[{n}].{key} is required")
        if row["id"] in seen:
            raise ValueError(f"duplicate location id {row['id']}")
        seen.add(row["id"])
        menu = ROOT / row["menu"] if row.get("menu") else None
        out.append(Location(
            id=str(row["id"]), group=str(row["group"]), name=str(row["name"]),
            menu=menu, catalog_status=str(row["catalog_status"]),
            inbound_env=str(row["inbound_env"]),
            fallback_phone=str(row["fallback_phone"]),
            pos_type=str(row["pos_type"]),
            pos_location_id=str(row.get("pos_location_id") or ""),
            note=str(row.get("note") or ""),
            fallback_env=str(row.get("fallback_env") or "")))
    return out


#: A pay-now threshold at or above this ($500) means no real phone order ever needs
#: a checkout link: every order is pay-at-pickup.
PAY_AT_PICKUP_FLOOR_CENTS = 50_000


def payment_mode(loc: Location) -> str:
    """How this location's orders are paid, from its menu's `pay_now_threshold_cents`:

    ``pay_now``        threshold 0: EVERY order needs an itemized checkout link
    ``pay_at_pickup``  threshold so high none does: the order goes straight to the
                       kitchen and the customer pays at the counter (Path A in
                       POS_INTEGRATION_PLAN.md: no integration, works for any POS)
    ``mixed``          in between: small orders pay at pickup, big ones need a link
    """
    if not loc.menu or not loc.menu.is_file():
        return "pay_now"
    threshold = int(ms.load_yaml(loc.menu).pay_now_threshold_cents)
    if threshold == 0:
        return "pay_now"
    return "pay_at_pickup" if threshold >= PAY_AT_PICKUP_FLOOR_CENTS else "mixed"


def selected(locations: Iterable[Location], only: List[str]) -> List[Location]:
    locations = list(locations)
    if not only:
        return locations
    wanted = set(only)
    found = [x for x in locations if x.id in wanted or x.group in wanted]
    missing = wanted - {x.id for x in found} - {x.group for x in found}
    if missing:
        raise ValueError("unknown --only value(s): " + ", ".join(sorted(missing)))
    return found


def direct_fallback(location: Location, env: Dict[str, str], *,
                    required: bool = False) -> str:
    """Resolve a staff line that cannot loop through the public forwarding route.

    The manifest contains published restaurant numbers collected before the
    forwarding-only launch decision. Live traffic must supply a separate direct
    number for each location; offline pilot fixtures may still use the manifest.

    The env var name comes from `location.fallback_env_name`, not straight from
    the id, so a location whose inbound var was named by hand can name this one
    to match. See `direct_fallback_source` for which of the two happened.
    """
    key = location.fallback_env_name
    direct = str(env.get(key, "")).strip()
    inbound = str(env.get(location.inbound_env, "")).strip()
    if required and not direct:
        raise ValueError(f"missing_env:{key}")
    if direct:
        import re
        if not re.fullmatch(r"\+[1-9][0-9]{7,14}", direct):
            raise ValueError(f"invalid_direct_fallback:{key}")
        if direct in (inbound, location.fallback_phone):
            raise ValueError(f"forwarding_loop:{key}")
    return direct or location.fallback_phone


def direct_fallback_source(location: Location,
                           env: Dict[str, str]) -> Tuple[str, str]:
    """(number, where it came from) — `env` or `manifest-published`.

    Returned so a deploy can say WHICH number it just wrote into the database
    and why. `manifest-published` is the dangerous answer: that number forwards
    into Cherry, so a staff transfer to it loops, which is why the gateway
    refuses to start on one. A deploy that silently writes it produces a
    restaurant that cannot transfer a caller — and cannot boot its gateway.
    """
    key = location.fallback_env_name
    if str(env.get(key, "")).strip():
        return direct_fallback(location, env), "env"
    return location.fallback_phone, "manifest-published"


def blockers(location: Location, env: Dict[str, str], *, require_inbound: bool) -> List[str]:
    problems = []
    if location.catalog_status != "ready":
        problems.append(location.catalog_status)
    if location.menu is None or not location.menu.exists():
        problems.append("menu_missing")
    else:
        try:
            cfg = ms.load_yaml(location.menu)
            if cfg.id != location.id:
                problems.append(f"menu_id_is_{cfg.id}")
        except Exception as exc:  # all parser failures become preflight output
            problems.append(f"menu_invalid:{exc}")
    if require_inbound and not env.get(location.inbound_env):
        problems.append(f"missing_env:{location.inbound_env}")
    try:
        direct_fallback(location, env,
                        required=env.get("CHERRY_REQUIRE_DIRECT_FALLBACK") == "1")
    except ValueError as exc:
        problems.append(str(exc))
    return problems


def show_plan(locations: Iterable[Location], env: Dict[str, str]) -> int:
    print("Cherry pilot deployment plan")
    for loc in locations:
        issues = blockers(loc, env, require_inbound=True)
        state = "READY" if not issues else "WAITING"
        menu = loc.menu.relative_to(ROOT) if loc.menu else "location catalog"
        inbound = env.get(loc.inbound_env, f"${loc.inbound_env}")
        # Always show the number AND where it came from. Printing only the
        # number hid the failure mode where the fallback env var was named
        # wrongly and the PUBLISHED number was used instead — a number that
        # forwards into Cherry, so a transfer to it loops.
        fallback, source = direct_fallback_source(loc, env)
        shown = f"{fallback} ({source})"
        print(f"{state:7} {loc.id:27} menu={menu} inbound={inbound} "
              f"fallback={shown}")
        print(f"        fallback env: {loc.fallback_env_name}"
              + ("" if source == "env" else
                 "   <-- NOT SET: staff transfers would loop"))
        if issues:
            print("        " + ", ".join(issues))
        if loc.note:
            print("        " + loc.note)
    return 0


def apply(locations: List[Location], db: str, env: Dict[str, str], *,
          sink: str = "manual") -> int:
    all_issues = {loc.id: blockers(loc, env, require_inbound=True)
                  for loc in locations}
    if sink == "square":
        for loc in locations:
            key = loc.id.upper().replace("-", "_")
            names = [f"SQUARE_TOKEN_{key}", f"SQUARE_LOCATION_{key}",
                     "TELNYX_API_KEY", "TELNYX_FROM_NUMBER"]
            if env.get("CHERRY_CHECKOUT_HANDOFF_ONLY") != "1":
                names += ["SQUARE_WEBHOOK_SIGNATURE_KEY", "SQUARE_WEBHOOK_URL"]
            for name in names:
                if not env.get(name):
                    all_issues[loc.id].append(f"missing_env:{name}")
    all_issues = {key: val for key, val in all_issues.items() if val}
    if all_issues:
        for location_id, issues in all_issues.items():
            print(f"BLOCKED {location_id}: {', '.join(issues)}")
        print("Nothing deployed; fix every selected location and run again.")
        return 2

    # Run every menu gate before opening the deployment database. This keeps a
    # later gate failure from leaving half the selected restaurants live.
    for loc in locations:
        args = type("CheckArgs", (), {"menu": str(loc.menu), "verbose": False})()
        if cmd_check(args) != 0:
            print(f"Nothing deployed; gate failed for {loc.id}.")
            return 1

    store = OrderStore.open(db)
    for loc in locations:
        cfg = ms.load_yaml(loc.menu)  # preflight above guarantees this exists
        staff, source = direct_fallback_source(loc, env)
        store.upsert_restaurant(
            cfg.id, cfg.name, cfg.cuisine, tax_rate_bps=cfg.tax_rate_bps,
            pos_type=cfg.pos_type, sink=sink,
            staff_phone=staff,
            inbound_phone=env[loc.inbound_env], active=True)
        version = store.publish_menu(
            cfg.id, loc.menu.read_text(), item_count=len(cfg.items),
            published_by="pilot_deploy")
        print(f"CONFIGURED {cfg.id}: menu v{version}, {len(cfg.items)} items, "
              f"sink={sink}, {env[loc.inbound_env]} -> {staff} ({source}); "
              "live checkout link acceptance still required")
        if source != "env":
            # Says exactly what to set, because the usual cause is a fallback
            # env var named differently from the inbound one, which reads as a
            # typo rather than a mistake.
            print(f"  WARNING {cfg.id}: no direct staff line configured, so the "
                  f"PUBLISHED number {staff} was stored as the transfer target. "
                  f"That number forwards into Cherry, so a staff transfer would "
                  f"loop. Set {loc.fallback_env_name}=+1... before go-live.")
    return 0


def verify(locations: List[Location], db: str, env: Dict[str, str]) -> int:
    """Prove that configured numbers, fallbacks, and live menus agree.

    Unlike ``apply``, verification never creates a database. It is intended
    for the deployment gate immediately before directing Telnyx traffic.
    """
    is_postgres = db.startswith(("postgres://", "postgresql://"))
    path = Path(db)
    if not is_postgres and db != ":memory:" and not path.is_file():
        print(f"FAIL database does not exist: {db}")
        return 2

    inbound_values = [env.get(loc.inbound_env, "") for loc in locations]
    duplicates = {number for number in inbound_values
                  if number and inbound_values.count(number) > 1}
    failures = 0
    store = OrderStore.open(db)
    for loc in locations:
        issues = blockers(loc, env, require_inbound=True)
        inbound = env.get(loc.inbound_env, "")
        if inbound in duplicates:
            issues.append(f"duplicate_inbound:{inbound}")
        row = store.restaurant(loc.id)
        if row is None:
            issues.append("restaurant_not_deployed")
        else:
            if not row["active"]:
                issues.append("restaurant_inactive")
            if row["inbound_phone"] != inbound:
                issues.append("inbound_mismatch")
            if row["staff_phone"] != direct_fallback(loc, env):
                issues.append("fallback_mismatch")
            routed = store.restaurant_for_number(inbound) if inbound else None
            if routed is None or routed["id"] != loc.id:
                issues.append("routing_mismatch")
            try:
                cfg, _ = store.load_live_config(loc.id)
                expected = ms.load_yaml(loc.menu) if loc.menu else None
                if expected is None or cfg.id != expected.id:
                    issues.append("live_menu_id_mismatch")
                elif len(cfg.items) != len(expected.items):
                    issues.append("live_menu_item_count_mismatch")
            except Exception as exc:  # all failures become deployment output
                issues.append(f"live_menu_invalid:{exc}")

        if issues:
            failures += 1
            print(f"FAIL {loc.id}: {', '.join(issues)}")
        else:
            print(f"PASS {loc.id}: {inbound} -> {direct_fallback(loc, env)}, "
                  f"live menu matches")
    return 2 if failures else 0


def checkout_ready(locations: List[Location], db: str,
                   env: Dict[str, str]) -> int:
    """Fail closed before traffic if paid-review checkout is not connected.

    This checks configured credentials and the Square sink without using or
    printing secrets. It cannot substitute for a real itemized checkout test.
    """
    if not db.startswith(("postgres://", "postgresql://")) and not Path(db).is_file():
        print("FAIL deployment database does not exist")
        return 2
    store = OrderStore.open(db)
    failures = 0
    for loc in locations:
        row = store.restaurant(loc.id)
        missing = []
        # A non-Square location whose menu sends every order to pay-at-pickup needs
        # no checkout link at all: only the staff ticket text (Telnyx).
        pickup_only = (row is not None and row["sink"] != "square"
                       and payment_mode(loc) == "pay_at_pickup")
        if (row is None or row["sink"] != "square") and not pickup_only:
            missing.append("itemized_square_checkout_not_connected")
        key = loc.id.upper().replace("-", "_")
        names = ["TELNYX_API_KEY", "TELNYX_FROM_NUMBER"]
        if not pickup_only:
            names = [f"SQUARE_TOKEN_{key}", f"SQUARE_LOCATION_{key}"] + names
            if env.get("CHERRY_CHECKOUT_HANDOFF_ONLY") != "1":
                names += ["SQUARE_WEBHOOK_SIGNATURE_KEY", "SQUARE_WEBHOOK_URL"]
        for name in names:
            if not env.get(name):
                missing.append(f"missing_env:{name}")
        if missing:
            failures += 1
            print(f"BLOCKED {loc.id}: {', '.join(missing)}")
        elif pickup_only:
            print(f"CONFIGURED {loc.id}: pay at pickup. Orders go straight to the kitchen "
                  "(staff text + tablet) and the customer pays at the counter; no checkout "
                  "link is involved. A live test call and ticket are still required")
        else:
            print(f"CONFIGURED {loc.id}: itemized Square checkout credentials present; "
                  "live checkout link test still required")
    return 2 if failures else 0


def main(argv: Optional[List[str]] = None, *, env: Optional[Dict[str, str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("plan", "apply", "verify",
                                             "checkout-ready"))
    parser.add_argument("--manifest", type=Path, default=DEFAULT_MANIFEST)
    parser.add_argument("--db", default=os.getenv("CHERRY_DATABASE_URL", "cherry.db"))
    parser.add_argument("--only", action="append", default=[],
                        help="location id or group; repeat to select more")
    parser.add_argument("--sink", choices=("manual", "square"), default="manual",
                        help="apply only: Square requires per-location secrets")
    args = parser.parse_args(argv)
    environment = dict(os.environ if env is None else env)
    if env is None:                # real run: refreshed secrets live in the vault
        environment = overlay_env(environment)
    try:
        locations = selected(load_manifest(args.manifest), args.only)
    except ValueError as exc:
        parser.error(str(exc))
    if args.command == "plan":
        return show_plan(locations, environment)
    if args.command == "apply":
        return apply(locations, args.db, environment, sink=args.sink)
    if args.command == "checkout-ready":
        return checkout_ready(locations, args.db, environment)
    return verify(locations, args.db, environment)


if __name__ == "__main__":
    raise SystemExit(main())
